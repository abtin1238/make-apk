# Abtin Remote (گوشی)
موس، کیبورد کامل و دسته (کنترل رابط) از طریق Wi-Fi. بلوتوث/HID مرحله‌ی بعد.
بیلد: `flutter pub get && flutter build apk --release`
