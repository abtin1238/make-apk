import 'package:flutter/material.dart';

import 'ir.dart';
import 'ir_map.dart';
import 'mi_library.dart';
import 'theme.dart';

/// آدرس‌های ۸بیتی NEC که روی باکس‌های اندرویدی چینی بیشتر دیده می‌شود.
/// (کد واقعی m4game معلوم نیست؛ اسکن این آدرس‌ها را یکی‌یکی امتحان می‌کند.)
const List<int> kCommonNecAddrs = [
  0x00, 0x01, 0x02, 0x04, 0x05, 0x08, 0x0E, 0x10, 0x18, 0x1A, 0x20, 0x30, 0x40, 0x48, 0x50, 0x70, 0x78, 0x7F, 0x80, 0xFB, 0xFE, 0xFF,
];

Future<void> showIrDialog(BuildContext context, IrController ir) {
  return showDialog<void>(
    context: context,
    builder: (_) => Dialog(
      backgroundColor: const Color(0xff0c1124),
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: kBlue.withOpacity(0.6)),
      ),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 560),
        child: Padding(padding: const EdgeInsets.all(14), child: IrPanel(ir: ir)),
      ),
    ),
  );
}

Future<String?> _askName(BuildContext context, String title, String initial) {
  final ctl = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xff0c1124),
      title: Text(title, style: const TextStyle(fontSize: 15)),
      content: TextField(controller: ctl, autofocus: true, onSubmitted: (v) => Navigator.of(ctx).pop(v)),
      actions: [
        TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('لغو')),
        FilledButton(onPressed: () => Navigator.of(ctx).pop(ctl.text), child: const Text('تأیید')),
      ],
    ),
  );
}

class IrPanel extends StatefulWidget {
  final IrController ir;
  const IrPanel({super.key, required this.ir});
  @override
  State<IrPanel> createState() => _IrPanelState();
}

class _IrPanelState extends State<IrPanel> {
  String target = 'POWER';
  int profileCursor = 0;
  bool profileRunning = false;
  String profileNote = '';
  String proto = 'nec';
  bool scanCommon = true;
  double interval = 350;
  bool running = false;
  int idx = 0;
  IrCode? current;
  String note = '';

  final TextEditingController addrCtl = TextEditingController(text: '00');
  final TextEditingController cmdCtl = TextEditingController(text: '00');

  IrController get ir => widget.ir;

  @override
  void initState() {
    super.initState();
    target = ir.scanTarget;
    proto = ir.scanProto;
    scanCommon = ir.scanCommon;
    interval = ir.scanInterval.clamp(150.0, 900.0).toDouble();
    addrCtl.text = ir.scanAddr;
    cmdCtl.text = ir.scanCmd;
    idx = ir.scanIdx.clamp(0, _total - 1).toInt();
    if (idx > 0) current = _codeAt(idx);
  }

  /// وضعیت اسکن را در کنترلر (و حافظه) نگه می‌دارد تا با بستن پنجره از دست نرود.
  void _persist() {
    ir.scanTarget = target;
    ir.scanProto = proto;
    ir.scanCommon = scanCommon;
    ir.scanInterval = interval;
    ir.scanIdx = idx;
    ir.scanAddr = addrCtl.text;
    ir.scanCmd = cmdCtl.text;
    ir.saveScan();
  }

  String _hx(int v, [int w = 2]) => v.toRadixString(16).toUpperCase().padLeft(w, '0');

  void _moveTo(int i) {
    setState(() {
      idx = i.clamp(0, _total - 1).toInt();
      current = _codeAt(idx);
    });
  }

  @override
  void dispose() {
    running = false;
    profileRunning = false;
    _persist();
    addrCtl.dispose();
    cmdCtl.dispose();
    super.dispose();
  }

  int get _maxAddr => switch (proto) {
        'necx' || 'nec32' || 'panasonic' || 'snowa' => 0xffff,
        'sony20' => 0x1fff,
        'sony12' || 'rc5' => 0x1f,
        _ => 0xff,
      };

  /// تعداد رقم hex آدرس
  int get _addrDigits => (proto == 'necx' || proto == 'nec32' || proto == 'panasonic' || proto == 'snowa' || proto == 'sony20') ? 4 : 2;

  /// تعداد دستورهای هر آدرس (RC5 و Sony فقط ۷ بیت)
  int get _cmds => (proto == 'rc5' || proto.startsWith('sony')) ? 128 : 256;

  /// آدرس پیش‌فرض (معمولاً تی‌وی) برای هر پروتکل
  String _defaultAddr(String p) => switch (p) {
        'samsung' => '07',
        'sony12' || 'sony15' => '01',
        'sony20' => '0001',
        'panasonic' => '0100',
        'snowa' => '0E0E',
        _ => '00',
      };

  /// کدهای ذخیره‌شدهٔ پروفایل فعال، به همان ترتیبی که در فهرست کدها دیده می‌شوند.
  List<MapEntry<String, IrCode>> get _profileEntries => ir.codes.entries.toList(growable: false);

  int get _safeProfileCursor =>
      _profileEntries.isEmpty ? 0 : profileCursor.clamp(0, _profileEntries.length - 1).toInt();

  MapEntry<String, IrCode>? get _currentProfileEntry =>
      _profileEntries.isEmpty ? null : _profileEntries[_safeProfileCursor];

  Future<void> _stepProfileCode(int delta) async {
    final entries = _profileEntries;
    if (entries.isEmpty) return;
    final next = (profileCursor + delta).clamp(0, entries.length - 1).toInt();
    setState(() {
      profileRunning = false;
      profileCursor = next;
      profileNote = '';
    });
    await ir.sendCode(entries[next].value);
  }

  Future<void> _runProfileCodeScan() async {
    if (profileRunning) return;
    final entries = _profileEntries;
    if (!ir.hasEmitter) {
      setState(() => profileNote = 'این گوشی فرستنده‌ی IR ندارد');
      return;
    }
    if (entries.isEmpty) {
      setState(() => profileNote = 'پروفایل فعال هنوز کدی ندارد؛ ابتدا یک پروفایل دارای کد انتخاب یا وارد کنید.');
      return;
    }
    final sourceProfile = ir.activeIdx;
    setState(() {
      running = false;
      if (profileCursor >= entries.length - 1) profileCursor = 0;
      profileCursor = profileCursor.clamp(0, entries.length - 1).toInt();
      profileRunning = true;
      profileNote = 'در حال ارسال کدهای پروفایل یکی‌یکی؛ با واکنش تلویزیون «توقف» را بزنید.';
    });
    while (profileRunning && mounted) {
      if (ir.activeIdx != sourceProfile) break;
      final i = profileCursor.clamp(0, entries.length - 1).toInt();
      await ir.sendCode(entries[i].value);
      await Future<void>.delayed(Duration(milliseconds: interval.round()));
      if (!profileRunning || !mounted) break;
      if (ir.activeIdx != sourceProfile) {
        setState(() {
          profileRunning = false;
          profileNote = 'پروفایل تغییر کرد؛ اسکن متوقف شد.';
        });
        break;
      }
      if (i + 1 >= entries.length) {
        setState(() {
          profileRunning = false;
          profileCursor = i;
          profileNote = 'همهٔ ${entries.length} کد این پروفایل تست شد.';
        });
        break;
      }
      setState(() => profileCursor = i + 1);
    }
  }

  void _stopProfileCodeScan() => setState(() {
        profileRunning = false;
        profileNote = 'تست متوقف شد؛ اگر کد فعلی واکنش درست داد، آن را روی دکمهٔ مقصد ذخیره کنید.';
      });

  void _saveProfileCode() {
    final entry = _currentProfileEntry;
    if (entry == null) return;
    ir.setCode(target, entry.value);
    setState(() {
      profileRunning = false;
      profileNote = 'ذخیره شد: کد «${irButtonLabel(entry.key)}» فقط روی «${irButtonLabel(target)}» در پروفایل «${ir.active.name}». ';
    });
  }

  int _parse(String s, int max) {
    final v = int.tryParse(s.trim().replaceAll('0x', '').replaceAll('0X', ''), radix: 16) ?? 0;
    return v.clamp(0, max).toInt();
  }

  List<int> get _addrs {
    if (scanCommon && proto == 'nec') return kCommonNecAddrs;
    return [_parse(addrCtl.text, _maxAddr)];
  }

  int get _total => _addrs.length * _cmds;

  IrCode _codeAt(int i) {
    final a = _addrs;
    return IrCode(proto, a[(i ~/ _cmds) % a.length], i % _cmds);
  }

  void _resetScan() {
    running = false;
    profileRunning = false;
    profileCursor = 0;
    profileNote = '';
    idx = 0;
    current = null;
    note = '';
    _persist();
  }

  Future<void> _sendIdx(int i) async {
    final c = _codeAt(i);
    if (mounted) setState(() => current = c);
    await ir.sendCode(c);
  }

  Future<void> _run() async {
    if (running) return;
    if (!ir.hasEmitter) {
      setState(() => note = 'این گوشی فرستنده‌ی IR ندارد');
      return;
    }
    setState(() {
      profileRunning = false;
      running = true;
      note = 'در حال اسکن... وقتی باکس واکنش نشان داد «توقف» را بزنید';
    });
    while (running && mounted) {
      if (idx >= _total) {
        setState(() {
          running = false;
          idx = _total - 1;
          note = 'اسکن تمام شد';
        });
        break;
      }
      await _sendIdx(idx);
      await Future<void>.delayed(Duration(milliseconds: interval.round()));
      if (!running || !mounted) break;
      setState(() => idx++);
      if (idx % 16 == 0) _persist();
    }
  }

  void _pause() {
    _persist();
    setState(() {
      running = false;
      note = 'متوقف شد. با ◀ ▶ قدم‌به‌قدم برگردید تا کد دقیق را پیدا کنید، بعد «ذخیره».';
    });
  }

  Future<void> _step(int d) async {
    running = false;
    final i = (idx + d).clamp(0, _total - 1).toInt();
    setState(() {
      idx = i;
      note = '';
    });
    _persist();
    await _sendIdx(i);
  }

  void _saveCurrent() {
    final c = current;
    if (c == null) return;
    ir.setCode(target, c);
    setState(() {
      running = false;
      note = 'ذخیره شد: ${irButtonLabel(target)} ← ${c.label}';
    });
  }

  IrCode _manualCode() => IrCode(proto, _parse(addrCtl.text, _maxAddr), _parse(cmdCtl.text, proto == 'nec32' ? 0xffff : _cmds - 1));

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: ir,
      builder: (context, _) {
        final c = current;
        final profileEntries = _profileEntries;
        final profileEntry = _currentProfileEntry;
        return SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('کنترل مادون قرمز (IR)',
                  textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(
                ir.hasEmitter
                    ? 'فرستنده‌ی IR گوشی فعال است. گوشی را رو به باکس بگیرید.'
                    : 'این گوشی فرستنده‌ی IR ندارد؛ فقط Wi-Fi کار می‌کند.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: ir.hasEmitter ? kHint : const Color(0xffffa23c)),
              ),
              const SizedBox(height: 8),
              Row(children: [
                const SizedBox(width: 62, child: Text('پروفایل')),
                Expanded(
                  child: DropdownButton<int>(
                    isExpanded: true,
                    value: ir.activeIdx,
                    dropdownColor: const Color(0xff141a33),
                    items: [
                      for (var i = 0; i < ir.profiles.length; i++)
                        DropdownMenuItem(value: i, child: Text(ir.profiles[i].name)),
                    ],
                    onChanged: (v) {
                      if (v != null) {
                        ir.selectProfile(v);
                        setState(() {
                          running = false;
                          profileRunning = false;
                          profileCursor = 0;
                          profileNote = '';
                        });
                      }
                    },
                  ),
                ),
                IconButton(
                  tooltip: 'پروفایل جدید',
                  icon: const Icon(Icons.add_circle_outline),
                  onPressed: () async {
                    final n = await _askName(context, 'پروفایل جدید (مثلاً تی‌وی اتاق)', '');
                    if (n != null) {
                      ir.addProfile(n);
                      setState(_resetScan);
                    }
                  },
                ),
                IconButton(
                  tooltip: 'تغییر نام',
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: () async {
                    final n = await _askName(context, 'نام پروفایل', ir.active.name);
                    if (n != null) ir.renameActive(n);
                  },
                ),
                IconButton(
                  tooltip: 'حذف پروفایل',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: ir.profiles.length > 1
                      ? () {
                          ir.deleteActive();
                          setState(_resetScan);
                        }
                      : null,
                ),
              ]),
              SwitchListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: const Text('فقط IR (دستگاه Wi-Fi ندارد، مثل تی‌وی)', style: TextStyle(fontSize: 13)),
                value: ir.active.irOnly,
                onChanged: ir.setActiveIrOnly,
              ),
              Wrap(spacing: 8, runSpacing: 4, alignment: WrapAlignment.center, children: [
                FilledButton.icon(
                  onPressed: () => showMiLibrary(context, ir),
                  icon: const Icon(Icons.library_books_outlined, size: 18),
                  label: const Text('کتابخانه‌ی Mi (۱۰۰۰+ برند)'),
                ),
                FilledButton.tonalIcon(
                  onPressed: () => showIrMapDialog(context, ir),
                  icon: const Icon(Icons.swap_vert, size: 18),
                  label: const Text('تخصیص دکمه‌ها'),
                ),
              ]),
              const SizedBox(height: 6),
              Wrap(spacing: 8, alignment: WrapAlignment.center, children: [
                OutlinedButton(
                  onPressed: () {
                    ir.addPhilips('rc5');
                    setState(() {
                      proto = 'rc5';
                      _resetScan();
                    });
                  },
                  child: const Text('پروفایل آماده: فیلیپس RC5'),
                ),
                OutlinedButton(
                  onPressed: () {
                    ir.addPhilips('rc6');
                    setState(() {
                      proto = 'rc6';
                      _resetScan();
                    });
                  },
                  child: const Text('پروفایل آماده: فیلیپس RC6'),
                ),
                OutlinedButton(
                  onPressed: () {
                    ir.addSamsung();
                    setState(() {
                      proto = 'samsung';
                      addrCtl.text = _defaultAddr(proto);
                      _resetScan();
                    });
                  },
                  child: const Text('پروفایل آماده: سامسونگ'),
                ),
                OutlinedButton(
                  onPressed: () {
                    ir.addLg();
                    setState(() {
                      proto = 'nec';
                      addrCtl.text = '04';
                      scanCommon = false;
                      _resetScan();
                    });
                  },
                  child: const Text('پروفایل آماده: ال‌جی'),
                ),
                OutlinedButton(
                  onPressed: () {
                    ir.addSony();
                    setState(() {
                      proto = 'sony12';
                      addrCtl.text = _defaultAddr(proto);
                      _resetScan();
                    });
                  },
                  child: const Text('پروفایل آماده: سونی'),
                ),
                OutlinedButton(
                  onPressed: () {
                    ir.addPanasonic();
                    setState(() {
                      proto = 'panasonic';
                      addrCtl.text = _defaultAddr(proto);
                      _resetScan();
                    });
                  },
                  child: const Text('پروفایل آماده: پاناسونیک'),
                ),
                OutlinedButton(
                  onPressed: () {
                    ir.addSnowa();
                    setState(() {
                      proto = 'snowa';
                      addrCtl.text = _defaultAddr(proto);
                      _resetScan();
                    });
                  },
                  child: const Text('پروفایل آماده: Snowa HCF-52K'),
                ),
              ]),
              const SizedBox(height: 4),
              SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('خودکار')),
                  ButtonSegment(value: 1, label: Text('فقط Wi-Fi')),
                  ButtonSegment(value: 2, label: Text('فقط IR')),
                ],
                selected: {ir.mode},
                onSelectionChanged: (s) => ir.setMode(s.first),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text(
                  'خودکار: اگر به باکس وصلید Wi-Fi، وگرنه IR. پروفایل «فقط IR» همیشه IR می‌فرستد.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11, color: kHint),
                ),
              ),
              SwitchListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: const Text('پاور همیشه با IR (روشن‌کردن از حالت خاموش)', style: TextStyle(fontSize: 13)),
                value: ir.powerViaIr,
                onChanged: ir.setPowerViaIr,
              ),
              const Divider(height: 18),
              const Text('پیدا کردن / ذخیره‌ی کد دکمه‌ها',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Row(children: [
                const SizedBox(width: 62, child: Text('دکمه')),
                Expanded(
                  child: DropdownButton<String>(
                    isExpanded: true,
                    value: target,
                    dropdownColor: const Color(0xff141a33),
                    items: [
                      for (final e in kIrButtons)
                        DropdownMenuItem(
                          value: e.key,
                          child: Text(ir.codes.containsKey(e.key) ? '${e.value}  ✓' : e.value),
                        ),
                    ],
                    onChanged: (v) {
                      setState(() {
                        target = v ?? target;
                        profileRunning = false;
                        profileNote = '';
                      });
                      _persist();
                    },
                  ),
                ),
              ]),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(18),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [kBlue.withOpacity(0.28), kPurple.withOpacity(0.22), const Color(0xff11172c)],
                  ),
                  border: Border.all(color: kCyan.withOpacity(0.65)),
                  boxShadow: [BoxShadow(color: kBlue.withOpacity(0.12), blurRadius: 18, offset: const Offset(0, 5))],
                ),
                child: Column(children: [
                  Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    const Icon(Icons.radar, color: kCyan, size: 19),
                    const SizedBox(width: 7),
                    const Flexible(
                      child: Text('تست کدهای پروفایل روی دکمهٔ مقصد',
                          textAlign: TextAlign.center, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800)),
                    ),
                  ]),
                  const SizedBox(height: 5),
                  Text(
                    'تمام کدهای «${ir.active.name}» یکی‌یکی فرستاده می‌شوند. وقتی کدی جواب داد، همان را فقط روی «${irButtonLabel(target)}» ذخیره کنید.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 11, color: kHint),
                  ),
                  const SizedBox(height: 9),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                    decoration: BoxDecoration(
                      color: const Color(0xff080d1d).withOpacity(0.75),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.white.withOpacity(0.09)),
                    ),
                    child: Column(children: [
                      Text(
                        profileEntry == null
                            ? 'در این پروفایل هنوز کدی ذخیره نشده'
                            : 'کد ${_safeProfileCursor + 1} از ${profileEntries.length}  •  منبع: ${irButtonLabel(profileEntry.key)}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                      ),
                      if (profileEntry != null) ...[
                        const SizedBox(height: 3),
                        Text(profileEntry.value.label, textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 11, color: kHint)),
                      ],
                      const SizedBox(height: 7),
                      LinearProgressIndicator(
                        value: profileEntries.isEmpty ? 0 : (_safeProfileCursor + 1) / profileEntries.length,
                        minHeight: 4,
                      ),
                    ]),
                  ),
                  const SizedBox(height: 8),
                  Wrap(spacing: 6, runSpacing: 4, alignment: WrapAlignment.center, children: [
                    IconButton.outlined(
                      onPressed: profileEntry == null || _safeProfileCursor == 0 ? null : () => _stepProfileCode(-1),
                      tooltip: 'کد قبلی',
                      icon: const Icon(Icons.chevron_left),
                    ),
                    profileRunning
                        ? FilledButton.icon(
                            onPressed: _stopProfileCodeScan,
                            icon: const Icon(Icons.pause),
                            label: const Text('توقف'),
                          )
                        : FilledButton.icon(
                            onPressed: profileEntries.isEmpty ? null : _runProfileCodeScan,
                            icon: const Icon(Icons.play_arrow),
                            label: Text('تست همهٔ ${profileEntries.length} کد'),
                          ),
                    IconButton.outlined(
                      onPressed: profileEntry == null || _safeProfileCursor >= profileEntries.length - 1
                          ? null
                          : () => _stepProfileCode(1),
                      tooltip: 'کد بعدی',
                      icon: const Icon(Icons.chevron_right),
                    ),
                    FilledButton.icon(
                      onPressed: profileEntry == null ? null : _saveProfileCode,
                      icon: const Icon(Icons.bookmark_add_outlined),
                      label: Text('ذخیره روی ${irButtonLabel(target)}'),
                      style: FilledButton.styleFrom(backgroundColor: const Color(0xff168b63)),
                    ),
                  ]),
                  if (profileNote.isNotEmpty) ...[
                    const SizedBox(height: 5),
                    Text(profileNote, textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 11, color: kHint)),
                  ],
                ]),
              ),
              const SizedBox(height: 8),
              Row(children: [
                const SizedBox(width: 62, child: Text('پروتکل')),
                Expanded(
                  child: DropdownButton<String>(
                    isExpanded: true,
                    value: proto,
                    dropdownColor: const Color(0xff141a33),
                    items: const [
                      DropdownMenuItem(value: 'nec', child: Text('NEC (آدرس ۸بیتی)')),
                      DropdownMenuItem(value: 'necx', child: Text('NEC Extended (آدرس ۱۶بیتی)')),
                      DropdownMenuItem(value: 'nec32', child: Text('NEC ۳۲بیتی کامل (آدرس ۱۶ + دستور ۱۶ بیت)')),
                      DropdownMenuItem(value: 'rc5', child: Text('RC5 (فیلیپس قدیمی، ۳۶kHz)')),
                      DropdownMenuItem(value: 'rc6', child: Text('RC6 (فیلیپس جدید، ۳۶kHz)')),
                      DropdownMenuItem(value: 'samsung', child: Text('Samsung32 (۳۸kHz)')),
                      DropdownMenuItem(value: 'sony12', child: Text('Sony SIRC ۱۲بیتی (۴۰kHz)')),
                      DropdownMenuItem(value: 'sony15', child: Text('Sony SIRC ۱۵بیتی (۴۰kHz)')),
                      DropdownMenuItem(value: 'sony20', child: Text('Sony SIRC ۲۰بیتی (۴۰kHz)')),
                      DropdownMenuItem(value: 'panasonic', child: Text('Panasonic Kaseikyo (۳۷kHz)')),
                      DropdownMenuItem(value: 'snowa', child: Text('Snowa / NEC چینی (۳۷.۹kHz، آدرس 0E0E)')),
                    ],
                    onChanged: (v) => setState(() {
                      proto = v ?? proto;
                      addrCtl.text = _defaultAddr(proto);
                      _resetScan();
                    }),
                  ),
                ),
              ]),
              Row(children: [
                const SizedBox(width: 62, child: Text('آدرس')),
                Expanded(
                  child: TextField(
                    controller: addrCtl,
                    enabled: !(scanCommon && proto == 'nec'),
                    maxLength: _addrDigits,
                    decoration: const InputDecoration(prefixText: '0x ', counterText: '', hintText: '00'),
                    onChanged: (_) => setState(_resetScan),
                  ),
                ),
                const SizedBox(width: 12),
                const Text('دستور'),
                const SizedBox(width: 8),
                SizedBox(
                  width: 80,
                  child: TextField(
                    controller: cmdCtl,
                    maxLength: proto == 'nec32' ? 4 : 2,
                    onChanged: (_) => _persist(),
                    decoration: const InputDecoration(prefixText: '0x ', counterText: '', hintText: '00'),
                  ),
                ),
              ]),
              if (proto == 'nec')
                SwitchListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: const Text('اسکن چند آدرس رایج (آدرس بالا نادیده گرفته می‌شود)', style: TextStyle(fontSize: 12)),
                  value: scanCommon,
                  onChanged: (v) => setState(() {
                    scanCommon = v;
                    _resetScan();
                  }),
                ),
              Wrap(spacing: 8, alignment: WrapAlignment.center, children: [
                OutlinedButton(
                  onPressed: ir.hasEmitter ? () => ir.sendCode(_manualCode()) : null,
                  child: const Text('تست کد دستی'),
                ),
                FilledButton(
                  onPressed: () {
                    final m = _manualCode();
                    ir.setCode(target, m);
                    setState(() => note = 'ذخیره شد: ${irButtonLabel(target)} ← ${m.label}');
                  },
                  child: const Text('ذخیره‌ی کد دستی'),
                ),
              ]),
              const Divider(height: 18),
              const Text('اسکن خودکار (وقتی کد را نمی‌دانید)',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
              Row(children: [
                const Text('فاصله', style: TextStyle(fontSize: 12)),
                Expanded(
                  child: Slider(
                    min: 150,
                    max: 900,
                    divisions: 15,
                    label: '${interval.round()} ms',
                    value: interval,
                    onChanged: (v) => setState(() => interval = v),
                    onChangeEnd: (_) => _persist(),
                  ),
                ),
                Text('${interval.round()} ms', style: const TextStyle(fontSize: 12)),
              ]),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kCyan.withOpacity(0.5)),
                ),
                child: Column(children: [
                  Text(
                    c == null ? 'هنوز چیزی ارسال نشده' : c.label,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 2),
                  Text('${c == null ? 0 : idx + 1} / $_total', style: const TextStyle(fontSize: 11, color: kHint)),
                  LinearProgressIndicator(value: _total == 0 ? 0 : (c == null ? 0 : (idx + 1) / _total)),
                ]),
              ),
              if (_addrs.length > 1)
                Row(children: [
                  const SizedBox(width: 48, child: Text('آدرس', style: TextStyle(fontSize: 12))),
                  Expanded(
                    child: Slider(
                      min: 0,
                      max: (_addrs.length - 1).toDouble(),
                      divisions: _addrs.length - 1,
                      value: (idx ~/ _cmds).clamp(0, _addrs.length - 1).toDouble(),
                      onChanged: (v) => _moveTo(v.round() * _cmds + idx % _cmds),
                      onChangeEnd: (_) => _persist(),
                    ),
                  ),
                  SizedBox(width: 44, child: Text('0x${_hx(_addrs[(idx ~/ _cmds).clamp(0, _addrs.length - 1).toInt()])}', style: const TextStyle(fontSize: 12))),
                ]),
              Row(children: [
                const SizedBox(width: 48, child: Text('دستور', style: TextStyle(fontSize: 12))),
                Expanded(
                  child: Slider(
                    min: 0,
                    max: (_cmds - 1).toDouble(),
                    divisions: _cmds - 1,
                    value: (idx % _cmds).toDouble(),
                    onChanged: (v) => _moveTo((idx ~/ _cmds) * _cmds + v.round()),
                    onChangeEnd: (_) => _persist(),
                  ),
                ),
                SizedBox(width: 44, child: Text('0x${_hx(idx % _cmds)}', style: const TextStyle(fontSize: 12))),
              ]),
              const SizedBox(height: 6),
              Wrap(spacing: 8, runSpacing: 4, alignment: WrapAlignment.center, children: [
                IconButton.outlined(onPressed: () => _step(-1), icon: const Icon(Icons.chevron_left), tooltip: 'قبلی'),
                running
                    ? FilledButton.icon(onPressed: _pause, icon: const Icon(Icons.pause), label: const Text('توقف'))
                    : FilledButton.icon(onPressed: _run, icon: const Icon(Icons.play_arrow), label: const Text('شروع')),
                IconButton.outlined(onPressed: () => _step(1), icon: const Icon(Icons.chevron_right), tooltip: 'بعدی'),
                FilledButton.icon(
                  onPressed: c == null ? null : _saveCurrent,
                  icon: const Icon(Icons.check),
                  label: Text('این بود → ${irButtonLabel(target)}'),
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xff1f9d55)),
                ),
              ]),
              if (note.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(note, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: kHint)),
                ),
              const Divider(height: 18),
              Row(children: [
                const Expanded(
                  child: Text('کدهای ذخیره‌شده‌ی این پروفایل', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                ),
                if (ir.codes.isNotEmpty) TextButton(onPressed: ir.clearCodes, child: const Text('حذف همه')),
              ]),
              if (ir.codes.isEmpty)
                const Text('هنوز کدی ذخیره نشده.', style: TextStyle(fontSize: 12, color: kHint))
              else
                Wrap(spacing: 6, runSpacing: 4, children: [
                  for (final e in ir.codes.entries)
                    InputChip(
                      label: Text('${irButtonLabel(e.key)}  ${e.value.label}', style: const TextStyle(fontSize: 11)),
                      onPressed: () => ir.sendCode(e.value),
                      onDeleted: () => ir.removeCode(e.key),
                    ),
                ]),
              const SizedBox(height: 6),
              TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('بستن')),
            ],
          ),
        );
      },
    );
  }
}
