package ir.abtin.remote.phone

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.hardware.ConsumerIrManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.BatteryManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var gyroListener: SensorEventListener? = null
    private var gravityListener: SensorEventListener? = null
    private var gyroSink: EventChannel.EventSink? = null
    private val grav = floatArrayOf(0f, 9.81f, 0f)
    private var bt: BtHid? = null
    private var btChannel: MethodChannel? = null
    private var pendingInit: MethodChannel.Result? = null
    private val reqBt = 4711
    private val reqRfcomm = 4713
    private val reqRfcommBonded = 4714
    private var pendingRfcommBonded: MethodChannel.Result? = null
    private var pendingRfcommAddress = ""
    private var pendingRfcommResult: MethodChannel.Result? = null
    @Volatile private var rfcommSocket: BluetoothSocket? = null
    @Volatile private var rfcommOutput: OutputStream? = null
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    // UUID اختصاصی گیرنده‌ی Abtin (نسخه‌ی ۲.۹.۶ به بعد)؛ اگر نبود به SPP قدیمی برمی‌گردیم
    private val appUuid: UUID = UUID.fromString("6f2a9c1e-5b7d-4e83-9a14-3c8d2e7b0a51")

    private fun btAdapter(): BluetoothAdapter? =
        (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private val reqScan = 4712
    private var pendingScan: MethodChannel.Result? = null
    private var scanReceiver: android.content.BroadcastReceiver? = null
    private var pairingAddress = ""

    private fun scanPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) arrayOf("android.permission.BLUETOOTH_SCAN", "android.permission.BLUETOOTH_CONNECT")
        else arrayOf("android.permission.ACCESS_FINE_LOCATION")

    private fun hasScanPermissions(): Boolean =
        scanPermissions().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun ensureScanReceiver() {
        if (scanReceiver != null) return
        val r = object : android.content.BroadcastReceiver() {
            @android.annotation.SuppressLint("MissingPermission")
            override fun onReceive(c: Context, i: Intent) {
                try {
                    when (i.action) {
                        android.bluetooth.BluetoothDevice.ACTION_FOUND -> {
                            val d = i.getParcelableExtra<android.bluetooth.BluetoothDevice>(android.bluetooth.BluetoothDevice.EXTRA_DEVICE) ?: return
                            btChannel?.invokeMethod("found", mapOf("name" to (d.name ?: ""), "address" to d.address))
                        }
                        BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> btChannel?.invokeMethod("scanDone", null)
                        android.bluetooth.BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                            val d = i.getParcelableExtra<android.bluetooth.BluetoothDevice>(android.bluetooth.BluetoothDevice.EXTRA_DEVICE) ?: return
                            val st = i.getIntExtra(android.bluetooth.BluetoothDevice.EXTRA_BOND_STATE, -1)
                            btChannel?.invokeMethod("bondChanged", mapOf("address" to d.address, "state" to st))
                            if (d.address == pairingAddress) {
                                if (st == android.bluetooth.BluetoothDevice.BOND_BONDED) {
                                    pairingAddress = ""
                                    try { bt?.connect(d.address) } catch (_: Exception) {}
                                } else if (st == android.bluetooth.BluetoothDevice.BOND_NONE) {
                                    pairingAddress = ""
                                    btChannel?.invokeMethod("state", mapOf("registered" to true, "connected" to false, "msg" to "جفت‌سازی انجام نشد یا رد شد"))
                                }
                            }
                        }
                    }
                } catch (_: Exception) {}
            }
        }
        val f = android.content.IntentFilter().apply {
            addAction(android.bluetooth.BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(android.bluetooth.BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(r, f, Context.RECEIVER_EXPORTED) else registerReceiver(r, f)
        scanReceiver = r
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun startScan(result: MethodChannel.Result) {
        val ad = btAdapter()
        if (ad == null || !ad.isEnabled) {
            try { startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) } catch (_: Exception) {}
            result.success(false)
            return
        }
        ensureScanReceiver()
        try {
            if (ad.isDiscovering) ad.cancelDiscovery()
            result.success(ad.startDiscovery())
        } catch (e: Exception) {
            result.success(false)
        }
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun pairDevice(address: String): Boolean {
        val ad = btAdapter() ?: return false
        val d = try { ad.getRemoteDevice(address) } catch (_: Exception) { return false }
        if (ad.isDiscovering) ad.cancelDiscovery()
        if (d.bondState == android.bluetooth.BluetoothDevice.BOND_BONDED) {
            return bt?.connect(address) ?: false
        }
        ensureScanReceiver()
        pairingAddress = address
        return d.createBond()
    }

    @android.annotation.SuppressLint("MissingPermission")
    private fun unpairDevice(address: String): Boolean {
        val ad = btAdapter() ?: return false
        val d = try { ad.getRemoteDevice(address) } catch (_: Exception) { return false }
        return try {
            if (bt?.isHost(address) == true) bt?.disconnect()
            android.bluetooth.BluetoothDevice::class.java.getMethod("removeBond").invoke(d) as? Boolean ?: false
        } catch (_: Exception) { false }
    }

    private fun btInit(result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT < 28) {
            result.success(false)
            return
        }
        if (bt == null) {
            bt = BtHid(this) { m -> runOnUiThread { btChannel?.invokeMethod("state", m) } }
        }
        if (btAdapter()?.isEnabled == false) {
            try { startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) } catch (_: Exception) {}
        }
        bt!!.start { ok -> result.success(ok) }
    }

    @SuppressLint("MissingPermission")
    private fun connectRfcomm(address: String, result: MethodChannel.Result) {
        val ad = btAdapter()
        if (ad == null || !ad.isEnabled) { result.success(false); return }
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
            pendingRfcommAddress = address
            pendingRfcommResult = result
            requestPermissions(arrayOf("android.permission.BLUETOOTH_CONNECT"), reqRfcomm)
            return
        }
        thread(name = "AbtinRfcommConnect") {
            var ok = false
            var socket: BluetoothSocket? = null
            try {
                val device = ad.getRemoteDevice(address)
                // اولین تلاش گاهی به‌خاطر SDP/کش شکست می‌خورد؛ یک بار دیگر امتحان می‌کنیم
                var last: Exception? = null
                val uuids = listOf(appUuid, appUuid, sppUuid)
                for ((attempt, uuid) in uuids.withIndex()) {
                    try { ad.cancelDiscovery() } catch (_: Exception) {}
                    val s = device.createRfcommSocketToServiceRecord(uuid)
                    try {
                        s.connect()
                        socket = s
                        last = null
                        break
                    } catch (e: Exception) {
                        last = e
                        try { s.close() } catch (_: Exception) {}
                        if (attempt < uuids.size - 1) Thread.sleep(700)
                    }
                }
                if (last != null || socket == null) throw last ?: java.io.IOException("connect failed")
                val sock: BluetoothSocket = socket
                try { rfcommSocket?.close() } catch (_: Exception) {}
                rfcommSocket = sock
                rfcommOutput = sock.outputStream
                ok = true
                runOnUiThread { btChannel?.invokeMethod("rfcommState", mapOf("connected" to true, "name" to (device.name ?: address), "address" to address)) }
                thread(name = "AbtinRfcommReader", isDaemon = true) {
                    try {
                        val reader = BufferedReader(InputStreamReader(sock.inputStream, Charsets.UTF_8))
                        while (rfcommSocket === sock) {
                            val line = reader.readLine() ?: break
                            runOnUiThread { btChannel?.invokeMethod("rfcommLine", line) }
                        }
                    } catch (_: Exception) {
                    } finally {
                        if (rfcommSocket === sock) {
                            rfcommSocket = null
                            rfcommOutput = null
                            try { sock.close() } catch (_: Exception) {}
                            runOnUiThread { btChannel?.invokeMethod("rfcommState", mapOf("connected" to false, "name" to "")) }
                        }
                    }
                }
            } catch (e: Exception) {
                // سوکت جدید را ببند، نه اتصال قبلیِ سالم را
                try { socket?.close() } catch (_: Exception) {}
            }
            runOnUiThread { result.success(ok) }
        }
    }

    @SuppressLint("MissingPermission")
    private fun readRfcommBonded(): List<Map<String, String>> = try {
        btAdapter()?.bondedDevices?.map { mapOf("name" to (it.name ?: ""), "address" to it.address) } ?: emptyList()
    } catch (_: Exception) { emptyList() }

    private fun getRfcommBonded(result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED) {
            pendingRfcommBonded = result
            requestPermissions(arrayOf("android.permission.BLUETOOTH_CONNECT"), reqRfcommBonded)
        } else result.success(readRfcommBonded())
    }

    private fun disconnectRfcomm(): Boolean {
        val s = rfcommSocket
        rfcommSocket = null
        rfcommOutput = null
        return try { s?.close(); true } catch (_: Exception) { false }
    }

    // نوشتن روی ترد جدا تا حرکت موس ترد اصلی را بلاک نکند؛ ترتیب پیام‌ها حفظ می‌شود
    private val rfcommWriter = java.util.concurrent.Executors.newSingleThreadExecutor()

    private fun sendRfcomm(data: String): Boolean {
        val out = rfcommOutput ?: return false
        val bytes = (data + "\n").toByteArray(Charsets.UTF_8)
        rfcommWriter.execute {
            try {
                out.write(bytes)
                out.flush()
            } catch (_: Exception) {
                if (rfcommOutput === out) {
                    disconnectRfcomm()
                    runOnUiThread { btChannel?.invokeMethod("rfcommState", mapOf("connected" to false, "name" to "")) }
                }
            }
        }
        return true
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqRfcommBonded) {
            val r = pendingRfcommBonded
            pendingRfcommBonded = null
            if (r != null) {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) r.success(readRfcommBonded())
                else r.success(emptyList<Map<String, String>>())
            }
        }
        if (requestCode == reqRfcomm) {
            val r = pendingRfcommResult
            val address = pendingRfcommAddress
            pendingRfcommResult = null
            pendingRfcommAddress = ""
            if (r != null) {
                if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) connectRfcomm(address, r)
                else r.success(false)
            }
        }
        if (requestCode == reqScan) {
            val r = pendingScan
            pendingScan = null
            if (r != null) {
                if (grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) startScan(r)
                else r.success(false)
            }
        }
        if (requestCode == reqBt) {
            val r = pendingInit
            pendingInit = null
            if (r != null) {
                val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
                if (ok) btInit(r) else r.success(false)
            }
        }
    }

    override fun onDestroy() {
        try { scanReceiver?.let { unregisterReceiver(it) } } catch (_: Exception) {}
        scanReceiver = null
        bt?.stop()
        disconnectRfcomm()
        super.onDestroy()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        MethodChannel(messenger, "abtin/device").setMethodCallHandler { call, result ->
            when (call.method) {
                "battery" -> {
                    val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                    result.success(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
                }
                "hasGyro" -> {
                    val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
                    result.success(sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null)
                }
                else -> result.notImplemented()
            }
        }

        // بلوتوث HID (کیبورد/موس/رسانه/دسته)
        val btCh = MethodChannel(messenger, "abtin/bt")
        btChannel = btCh
        btCh.setMethodCallHandler { call, result ->
            when (call.method) {
                "supported" -> result.success(Build.VERSION.SDK_INT >= 28 && btAdapter() != null)
                "rfcommConnect" -> connectRfcomm(call.argument<String>("address") ?: "", result)
                "rfcommBonded" -> getRfcommBonded(result)
                "rfcommSend" -> result.success(sendRfcomm(call.argument<String>("data") ?: ""))
                "rfcommDisconnect" -> result.success(disconnectRfcomm())
                "init" -> {
                    if (Build.VERSION.SDK_INT >= 31 &&
                        checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED
                    ) {
                        pendingInit?.success(false)
                        pendingInit = result
                        requestPermissions(
                            arrayOf("android.permission.BLUETOOTH_CONNECT", "android.permission.BLUETOOTH_ADVERTISE"),
                            reqBt
                        )
                    } else {
                        btInit(result)
                    }
                }
                "scan" -> {
                    if (hasScanPermissions()) startScan(result)
                    else {
                        pendingScan?.success(false)
                        pendingScan = result
                        requestPermissions(scanPermissions(), reqScan)
                    }
                }
                "stopScan" -> {
                    try { btAdapter()?.cancelDiscovery() } catch (_: Exception) {}
                    result.success(true)
                }
                "pair" -> result.success(try { pairDevice(call.argument<String>("address") ?: "") } catch (e: Exception) { false })
                "unpair" -> result.success(try { unpairDevice(call.argument<String>("address") ?: "") } catch (e: Exception) { false })
                "diag" -> result.success(bt?.diag() ?: "Android ${Build.VERSION.SDK_INT} | ${Build.MANUFACTURER} ${Build.MODEL} | آماده‌سازی هنوز انجام نشده")
                "bonded" -> result.success(try { bt?.bonded() ?: emptyList<Map<String, String>>() } catch (e: Exception) { emptyList<Map<String, String>>() })
                "connect" -> result.success(try { bt?.connect(call.argument<String>("address") ?: "") ?: false } catch (e: Exception) { false })
                "disconnect" -> result.success(try { bt?.disconnect() ?: false } catch (e: Exception) { false })
                "report" -> {
                    val id = call.argument<Int>("id") ?: 0
                    val data = call.argument<ByteArray>("data")
                    result.success(if (data == null) false else try { bt?.report(id, data) ?: false } catch (e: Exception) { false })
                }
                "discoverable" -> {
                    try {
                        val i = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                        i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
                        startActivity(i)
                        result.success(true)
                    } catch (e: Exception) {
                        result.success(false)
                    }
                }
                "settings" -> {
                    try {
                        startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                        result.success(true)
                    } catch (e: Exception) {
                        result.success(false)
                    }
                }
                else -> result.notImplemented()
            }
        }

        // فرستنده‌ی مادون قرمز (IR Blaster)
        MethodChannel(messenger, "abtin/ir").setMethodCallHandler { call, result ->
            val ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
            when (call.method) {
                "hasIr" -> result.success(try { ir?.hasIrEmitter() == true } catch (e: Exception) { false })
                "transmit" -> {
                    val freq = call.argument<Int>("freq") ?: 38000
                    val pattern = call.argument<List<Int>>("pattern")
                    if (ir == null || pattern == null) {
                        result.success(false)
                    } else {
                        try {
                            if (!ir.hasIrEmitter()) {
                                result.success(false)
                            } else {
                                ir.transmit(freq, pattern.toIntArray())
                                result.success(true)
                            }
                        } catch (e: Exception) {
                            result.success(false)
                        }
                    }
                }
                else -> result.notImplemented()
            }
        }

        // جریان داده‌ی ژیروسکوپ (rad/s) به‌صورت [x, y, z]
        EventChannel(messenger, "abtin/gyro").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
                if (sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) == null) {
                    events?.error("NO_GYRO", "gyroscope not available", null)
                    return
                }
                gyroSink = events
                registerGyro()
            }

            override fun onCancel(arguments: Any?) {
                unregisterGyro()
                gyroSink = null
            }
        })
    }

    // ژیرو: [سرعت چرخش حول محور x (بالا/پایین)، حول محور قائم واقعی (چپ/راست)، حول z]
    // محور قائم از جاذبه به‌دست می‌آید، پس چه گوشی عمودی باشد چه صاف/مایل، چرخش چپ‌وراست درست حس می‌شود.
    private fun registerGyro() {
        val sink = gyroSink ?: return
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) ?: return
        unregisterGyro()
        val gSensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val isAccel = gSensor?.type == Sensor.TYPE_ACCELEROMETER
        if (gSensor != null) {
            val gl = object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) {
                    if (isAccel) {
                        for (i in 0..2) grav[i] = 0.9f * grav[i] + 0.1f * e.values[i]
                    } else {
                        for (i in 0..2) grav[i] = e.values[i]
                    }
                }
                override fun onAccuracyChanged(s: Sensor?, a: Int) {}
            }
            gravityListener = gl
            sm.registerListener(gl, gSensor, SensorManager.SENSOR_DELAY_GAME)
        }
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val n = Math.sqrt((grav[0] * grav[0] + grav[1] * grav[1] + grav[2] * grav[2]).toDouble()).toFloat()
                val ux = if (n < 1f) 0f else grav[0] / n
                val uy = if (n < 1f) 1f else grav[1] / n
                val uz = if (n < 1f) 0f else grav[2] / n
                val wx = e.values[0]
                val wy = e.values[1]
                val wz = e.values[2]
                val yaw = wx * ux + wy * uy + wz * uz
                sink.success(listOf(wx.toDouble(), yaw.toDouble(), wz.toDouble()))
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        gyroListener = l
        sm.registerListener(l, gyro, SensorManager.SENSOR_DELAY_GAME)
    }

    private fun unregisterGyro() {
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        gyroListener?.let { sm.unregisterListener(it) }
        gravityListener?.let { sm.unregisterListener(it) }
        gyroListener = null
        gravityListener = null
    }

    override fun onPause() {
        super.onPause()
        unregisterGyro()
    }

    override fun onResume() {
        super.onResume()
        if (gyroSink != null) registerGyro()
    }
}
