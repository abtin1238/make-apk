package ir.abtin.remote.phone

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context

/** گوشی را به‌صورت دستگاه HID بلوتوث (کیبورد + موس + رسانه + دسته) معرفی می‌کند. Android 9+ */
@SuppressLint("MissingPermission")
class BtHid(private val ctx: Context, private val emit: (Map<String, Any?>) -> Unit) {
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null
    private var registered = false
    private var pending: ((Boolean) -> Unit)? = null

    // ID 1 کیبورد، ID 2 موس، ID 3 Consumer، ID 4 دسته
    private val descriptor: ByteArray = (
        "05 01 09 06 A1 01 85 01 05 07 19 E0 29 E7 15 00 25 01 75 01 95 08 81 02 " +
        "95 01 75 08 81 01 95 06 75 08 15 00 25 65 05 07 19 00 29 65 81 00 C0 " +
        "05 01 09 02 A1 01 85 02 09 01 A1 00 05 09 19 01 29 03 15 00 25 01 95 03 75 01 81 02 " +
        "95 01 75 05 81 03 05 01 09 30 09 31 09 38 15 81 25 7F 75 08 95 03 81 06 C0 C0 " +
        "05 0C 09 01 A1 01 85 03 15 00 26 FF 03 19 00 2A FF 03 75 10 95 01 81 00 C0 " +
        "05 01 09 05 A1 01 85 04 05 09 19 01 29 10 15 00 25 01 75 01 95 10 81 02 " +
        "05 01 09 39 15 01 25 08 35 00 46 3B 01 65 14 75 04 95 01 81 42 75 04 95 01 81 03 " +
        "65 00 35 00 45 00 09 30 09 31 09 32 09 35 15 81 25 7F 75 08 95 04 81 02 C0"
        ).trim().split(" ").map { it.toInt(16).toByte() }.toByteArray()

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            this@BtHid.registered = registered
            if (registered) host = hid?.connectedDevices?.firstOrNull()
            push(if (registered) "" else "ثبت دستگاه HID لغو شد")
        }

        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            when (state) {
                BluetoothProfile.STATE_CONNECTED -> host = device
                BluetoothProfile.STATE_DISCONNECTED -> if (host?.address == device.address) host = null
            }
            push(if (state == BluetoothProfile.STATE_CONNECTING) "در حال اتصال..." else "")
        }
    }

    private fun push(msg: String) {
        emit(
            mapOf(
                "registered" to registered,
                "connected" to (host != null),
                "name" to (host?.name ?: ""),
                "address" to (host?.address ?: ""),
                "msg" to msg
            )
        )
    }

    fun start(done: (Boolean) -> Unit) {
        val ad = adapter
        if (ad == null || !ad.isEnabled) {
            done(false)
            return
        }
        if (hid != null) {
            done(true)
            return
        }
        pending = done
        val ok = ad.getProfileProxy(ctx, object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                if (profile != BluetoothProfile.HID_DEVICE) return
                val h = proxy as BluetoothHidDevice
                hid = h
                val sdp = BluetoothHidDeviceAppSdpSettings(
                    "Abtin Pad", "Abtin Remote", "Abtin",
                    BluetoothHidDevice.SUBCLASS1_COMBO, descriptor
                )
                val reg = h.registerApp(sdp, null, null, ctx.mainExecutor, callback)
                pending?.invoke(reg)
                pending = null
            }

            override fun onServiceDisconnected(profile: Int) {
                hid = null
                host = null
                registered = false
                push("سرویس بلوتوث قطع شد")
            }
        }, BluetoothProfile.HID_DEVICE)
        if (!ok) {
            pending = null
            done(false)
        }
    }

    fun bonded(): List<Map<String, String>> =
        (adapter?.bondedDevices ?: emptySet()).map {
            mapOf("name" to (it.name ?: it.address), "address" to it.address)
        }

    fun connect(address: String): Boolean {
        val h = hid ?: return false
        val dev = adapter?.getRemoteDevice(address) ?: return false
        return h.connect(dev)
    }

    fun disconnect(): Boolean {
        val h = hid ?: return false
        val d = host ?: return false
        return h.disconnect(d)
    }

    fun report(id: Int, data: ByteArray): Boolean {
        val h = hid ?: return false
        val d = host ?: return false
        return h.sendReport(d, id, data)
    }

    fun stop() {
        try {
            hid?.unregisterApp()
        } catch (_: Exception) {
        }
        try {
            if (hid != null) adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, hid)
        } catch (_: Exception) {
        }
        hid = null
        host = null
        registered = false
    }
}
