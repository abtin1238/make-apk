package ir.abtin.remote.phone

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothProfile
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.Executors

class MainActivity : FlutterActivity() {
    private val channel = "ir.abtin.remote/hid"
    private var hid: BluetoothHidDevice? = null
    private var registered = false
    private val executor = Executors.newSingleThreadExecutor()
    private var pressed = 0
    private val descriptor = byteArrayOf(
        0x05,0x01,0x09,0x05,0xA1.toByte(),0x01,0xA1.toByte(),0x00,
        0x05,0x09,0x19,0x01,0x29,0x10,0x15,0x00,0x25,0x01,0x95,0x10,0x75,0x01,0x81.toByte(),0x02,
        0x05,0x01,0x15,0x81.toByte(),0x25,0x7F,0x75,0x08,0x95,0x04,0x09,0x30,0x09,0x31,0x09,0x33,0x09,0x34,0x81.toByte(),0x02,
        0xC0.toByte(),0xC0.toByte()
    )
    private val buttons = mapOf("CROSS" to 0,"CIRCLE" to 1,"SQUARE" to 2,"TRIANGLE" to 3,"L1" to 4,"R1" to 5,"L2" to 6,"R2" to 7,"SELECT" to 8,"START" to 9,"UP" to 10,"RIGHT" to 11,"DOWN" to 12,"LEFT" to 13)
    private val callback = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            if (profile != BluetoothProfile.HID_DEVICE) return
            hid = proxy as BluetoothHidDevice
            val sdp = BluetoothHidDeviceAppSdpSettings("Abtin Remote", "Gamepad", "Abtin", BluetoothHidDevice.SUBCLASS1_GAMEPAD, descriptor)
            hid?.registerApp(sdp, null, null, executor, object : BluetoothHidDevice.Callback() {
                override fun onAppStatusChanged(device: android.bluetooth.BluetoothDevice?, isRegistered: Boolean) { registered = isRegistered }
                override fun onConnectionStateChanged(device: android.bluetooth.BluetoothDevice?, state: Int) { }
            })
        }
        override fun onServiceDisconnected(profile: Int) { hid = null; registered = false }
    }
    override fun configureFlutterEngine(engine: FlutterEngine) {
        super.configureFlutterEngine(engine)
        MethodChannel(engine.dartExecutor.binaryMessenger, channel).setMethodCallHandler { call, result ->
            when (call.method) {
                "startHid" -> {
                    if (Build.VERSION.SDK_INT < 28) { result.success(false); return@setMethodCallHandler }
                    val adapter = BluetoothAdapter.getDefaultAdapter()
                    if (adapter == null || !adapter.isEnabled) { result.success(false); return@setMethodCallHandler }
                    result.success(adapter.getProfileProxy(this, callback, BluetoothProfile.HID_DEVICE))
                }
                "gameButton" -> {
                    val index = buttons[call.argument<String>("key") ?: ""]
                    if (index != null) {
                        pressed = if (call.argument<Boolean>("down") == true) pressed or (1 shl index) else pressed and (1 shl index).inv()
                        hid?.connectedDevices?.firstOrNull()?.let { hid?.sendReport(it, 1, byteArrayOf((pressed and 255).toByte(), ((pressed ushr 8) and 255).toByte(), 0, 0, 0, 0)) }
                    }
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }
    }
    override fun onDestroy() {
        hid?.let { BluetoothAdapter.getDefaultAdapter()?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) }
        executor.shutdown()
        super.onDestroy()
    }
}
