package ir.abtin.remote.phone

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.BatteryManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var gyroListener: SensorEventListener? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        MethodChannel(messenger, "abtin/device").setMethodCallHandler { call, result ->
            when (call.method) {
                "battery" -> {
                    val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                    result.success(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
                }
                "hasGyro" -> {
                    val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
                    result.success(sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null)
                }
                else -> result.notImplemented()
            }
        }

        // جریان داده‌ی ژیروسکوپ (rad/s) به‌صورت [x, y, z]
        EventChannel(messenger, "abtin/gyro").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
                val sensor = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
                if (sensor == null) {
                    events?.error("NO_GYRO", "gyroscope not available", null)
                    return
                }
                val l = object : SensorEventListener {
                    override fun onSensorChanged(e: SensorEvent) {
                        events?.success(listOf(e.values[0].toDouble(), e.values[1].toDouble(), e.values[2].toDouble()))
                    }
                    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
                }
                gyroListener = l
                sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
            }

            override fun onCancel(arguments: Any?) {
                val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
                gyroListener?.let { sm.unregisterListener(it) }
                gyroListener = null
            }
        })
    }

    override fun onPause() {
        super.onPause()
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        gyroListener?.let { sm.unregisterListener(it) }
    }
}
