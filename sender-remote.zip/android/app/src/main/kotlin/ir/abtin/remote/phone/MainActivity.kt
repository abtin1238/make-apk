package ir.abtin.remote.phone

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
