package ir.abtin.remote.phone

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.hardware.ConsumerIrManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.BatteryManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private var gyroListener: SensorEventListener? = null
    private var gravityListener: SensorEventListener? = null
    private var gyroSink: EventChannel.EventSink? = null
    private val grav = floatArrayOf(0f, 9.81f, 0f)
    private var bt: BtHid? = null
    private var btChannel: MethodChannel? = null
    private var pendingInit: MethodChannel.Result? = null
    private val reqBt = 4711

    private fun btAdapter(): BluetoothAdapter? =
        (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    private fun btInit(result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT < 28) {
            result.success(false)
            return
        }
        if (bt == null) {
            bt = BtHid(this) { m -> runOnUiThread { btChannel?.invokeMethod("state", m) } }
        }
        bt!!.start { ok -> result.success(ok) }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqBt) {
            val r = pendingInit
            pendingInit = null
            if (r != null) {
                val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
                if (ok) btInit(r) else r.success(false)
            }
        }
    }

    override fun onDestroy() {
        bt?.stop()
        super.onDestroy()
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger

        MethodChannel(messenger, "abtin/device").setMethodCallHandler { call, result ->
            when (call.method) {
                "battery" -> {
                    val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                    result.success(bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
                }
                "hasGyro" -> {
                    val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
                    result.success(sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) != null)
                }
                else -> result.notImplemented()
            }
        }

        // بلوتوث HID (کیبورد/موس/رسانه/دسته)
        val btCh = MethodChannel(messenger, "abtin/bt")
        btChannel = btCh
        btCh.setMethodCallHandler { call, result ->
            when (call.method) {
                "supported" -> result.success(Build.VERSION.SDK_INT >= 28 && btAdapter() != null)
                "init" -> {
                    if (Build.VERSION.SDK_INT >= 31 &&
                        checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED
                    ) {
                        pendingInit = result
                        requestPermissions(
                            arrayOf("android.permission.BLUETOOTH_CONNECT", "android.permission.BLUETOOTH_ADVERTISE"),
                            reqBt
                        )
                    } else {
                        btInit(result)
                    }
                }
                "bonded" -> result.success(try { bt?.bonded() ?: emptyList<Map<String, String>>() } catch (e: Exception) { emptyList<Map<String, String>>() })
                "connect" -> result.success(try { bt?.connect(call.argument<String>("address") ?: "") ?: false } catch (e: Exception) { false })
                "disconnect" -> result.success(try { bt?.disconnect() ?: false } catch (e: Exception) { false })
                "report" -> {
                    val id = call.argument<Int>("id") ?: 0
                    val data = call.argument<ByteArray>("data")
                    result.success(if (data == null) false else try { bt?.report(id, data) ?: false } catch (e: Exception) { false })
                }
                "discoverable" -> {
                    try {
                        val i = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                        i.putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 120)
                        startActivity(i)
                        result.success(true)
                    } catch (e: Exception) {
                        result.success(false)
                    }
                }
                "settings" -> {
                    try {
                        startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                        result.success(true)
                    } catch (e: Exception) {
                        result.success(false)
                    }
                }
                else -> result.notImplemented()
            }
        }

        // فرستنده‌ی مادون قرمز (IR Blaster)
        MethodChannel(messenger, "abtin/ir").setMethodCallHandler { call, result ->
            val ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
            when (call.method) {
                "hasIr" -> result.success(try { ir?.hasIrEmitter() == true } catch (e: Exception) { false })
                "transmit" -> {
                    val freq = call.argument<Int>("freq") ?: 38000
                    val pattern = call.argument<List<Int>>("pattern")
                    if (ir == null || pattern == null) {
                        result.success(false)
                    } else {
                        try {
                            if (!ir.hasIrEmitter()) {
                                result.success(false)
                            } else {
                                ir.transmit(freq, pattern.toIntArray())
                                result.success(true)
                            }
                        } catch (e: Exception) {
                            result.success(false)
                        }
                    }
                }
                else -> result.notImplemented()
            }
        }

        // جریان داده‌ی ژیروسکوپ (rad/s) به‌صورت [x, y, z]
        EventChannel(messenger, "abtin/gyro").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
                if (sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) == null) {
                    events?.error("NO_GYRO", "gyroscope not available", null)
                    return
                }
                gyroSink = events
                registerGyro()
            }

            override fun onCancel(arguments: Any?) {
                unregisterGyro()
                gyroSink = null
            }
        })
    }

    // ژیرو: [سرعت چرخش حول محور x (بالا/پایین)، حول محور قائم واقعی (چپ/راست)، حول z]
    // محور قائم از جاذبه به‌دست می‌آید، پس چه گوشی عمودی باشد چه صاف/مایل، چرخش چپ‌وراست درست حس می‌شود.
    private fun registerGyro() {
        val sink = gyroSink ?: return
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val gyro = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE) ?: return
        unregisterGyro()
        val gSensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val isAccel = gSensor?.type == Sensor.TYPE_ACCELEROMETER
        if (gSensor != null) {
            val gl = object : SensorEventListener {
                override fun onSensorChanged(e: SensorEvent) {
                    if (isAccel) {
                        for (i in 0..2) grav[i] = 0.9f * grav[i] + 0.1f * e.values[i]
                    } else {
                        for (i in 0..2) grav[i] = e.values[i]
                    }
                }
                override fun onAccuracyChanged(s: Sensor?, a: Int) {}
            }
            gravityListener = gl
            sm.registerListener(gl, gSensor, SensorManager.SENSOR_DELAY_GAME)
        }
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val n = Math.sqrt((grav[0] * grav[0] + grav[1] * grav[1] + grav[2] * grav[2]).toDouble()).toFloat()
                val ux = if (n < 1f) 0f else grav[0] / n
                val uy = if (n < 1f) 1f else grav[1] / n
                val uz = if (n < 1f) 0f else grav[2] / n
                val wx = e.values[0]
                val wy = e.values[1]
                val wz = e.values[2]
                val yaw = wx * ux + wy * uy + wz * uz
                sink.success(listOf(wx.toDouble(), yaw.toDouble(), wz.toDouble()))
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        gyroListener = l
        sm.registerListener(l, gyro, SensorManager.SENSOR_DELAY_GAME)
    }

    private fun unregisterGyro() {
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        gyroListener?.let { sm.unregisterListener(it) }
        gravityListener?.let { sm.unregisterListener(it) }
        gyroListener = null
        gravityListener = null
    }

    override fun onPause() {
        super.onPause()
        unregisterGyro()
    }

    override fun onResume() {
        super.onResume()
        if (gyroSink != null) registerGyro()
    }
}
