import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'gamepad_page.dart';
import 'ir.dart';
import 'keyboard_page.dart';
import 'link.dart';
import 'mouse_page.dart';
import 'sheets.dart';
import 'tv_remote_page.dart';
import 'theme.dart';
import 'touchpad.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // تمام‌صفحه و افقی
  await SystemChrome.setPreferredOrientations(
      [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  runApp(const AbtinRemoteApp());
}

class AppState extends ChangeNotifier {
  final WifiLink link = WifiLink();
  final PadSettings settings = PadSettings();
  final IrController ir = IrController();
  String host = '';
  String pin = '';

  AppState() {
    link.addListener(notifyListeners);
    ir.addListener(notifyListeners);
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      host = p.getString('host') ?? '';
      pin = p.getString('pin') ?? '';
      settings.update(
        sens: p.getDouble('sens'),
        scroll: p.getDouble('scroll'),
        natural: p.getBool('natural'),
        hap: p.getBool('haptics'),
        gyro: p.getDouble('gyro'),
        invX: p.getBool('ginvx'),
        invY: p.getBool('ginvy'),
      );
      settings.addListener(_saveSettings);
      notifyListeners();
    } catch (_) {}
  }

  Future<void> _saveSettings() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setDouble('sens', settings.sensitivity);
      await p.setDouble('scroll', settings.scrollSpeed);
      await p.setBool('natural', settings.naturalScroll);
      await p.setBool('haptics', settings.haptics);
      await p.setDouble('gyro', settings.gyroSens);
      await p.setBool('ginvx', settings.gyroInvX);
      await p.setBool('ginvy', settings.gyroInvY);
    } catch (_) {}
  }

  Future<void> save(String h, String p) async {
    host = h;
    pin = p;
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString('host', h);
      await sp.setString('pin', p);
    } catch (_) {}
  }

  @override
  void dispose() {
    link.removeListener(notifyListeners);
    ir.removeListener(notifyListeners);
    settings.removeListener(_saveSettings);
    link.dispose();
    ir.dispose();
    settings.dispose();
    super.dispose();
  }
}

class AbtinRemoteApp extends StatefulWidget {
  const AbtinRemoteApp({super.key});
  @override
  State<AbtinRemoteApp> createState() => _AbtinRemoteAppState();
}

class _AbtinRemoteAppState extends State<AbtinRemoteApp> {
  final AppState state = AppState();

  @override
  void dispose() {
    state.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        scaffoldMessengerKey: irMessengerKey,
        title: 'Abtin GamePad',
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          scaffoldBackgroundColor: kBg,
          colorScheme: ColorScheme.fromSeed(seedColor: kBlue, brightness: Brightness.dark),
        ),
        home: RemoteHome(state: state),
      );
}

class RemoteHome extends StatefulWidget {
  final AppState state;
  const RemoteHome({super.key, required this.state});
  @override
  State<RemoteHome> createState() => _RemoteHomeState();
}

class _RemoteHomeState extends State<RemoteHome> {
  int mode = 0; // 0 کیبورد+موس، 1 دسته، 2 موس کامل، 3 ریموت تی‌وی
  bool _askedOnce = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      // کمی صبر تا تنظیمات ذخیره‌شده (IP/PIN) خوانده شود
      await Future<void>.delayed(const Duration(milliseconds: 400));
      if (mounted && !_askedOnce && !widget.state.link.connected) {
        _askedOnce = true;
        _openConnect();
      }
    });
  }

  void _openConnect() {
    final s = widget.state;
    showDialog<void>(
      context: context,
      builder: (_) => ConnectDialog(link: s.link, host: s.host, pin: s.pin, onSave: s.save),
    );
  }

  void _openSettings() => showSettingsDialog(context, widget.state.settings);

  // موس جدا و ریموت تی‌وی عمودی‌اند؛ کیبورد و دسته افقی
  Future<void> _setMode(int i) async {
    await SystemChrome.setPreferredOrientations(i >= 2
        ? [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]
        : [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    if (mounted) setState(() => mode = i);
  }

  void _openMenu() => showModeMenu(
        context,
        current: mode,
        onSelect: _setMode,
        link: widget.state.link,
        settings: widget.state.settings,
        ir: widget.state.ir,
      );

  @override
  Widget build(BuildContext context) {
    final s = widget.state;
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) {
        return Scaffold(
          backgroundColor: kBg,
          body: SafeArea(
            child: switch (mode) {
              0 => KeyboardPage(
                  link: s.link,
                  settings: s.settings,
                  onMenu: _openMenu,
                  onConnect: _openConnect,
                  onSettings: _openSettings,
                ),
              1 => GamepadPage(
                  link: s.link,
                  settings: s.settings,
                  onMenu: _openMenu,
                  onConnect: _openConnect,
                  onSettings: _openSettings,
                ),
              2 => MousePage(link: s.link, settings: s.settings, onMenu: _openMenu),
              _ => TvRemotePage(
                  link: s.link,
                  settings: s.settings,
                  ir: s.ir,
                  onMenu: _openMenu,
                  onConnect: _openConnect,
                ),
            },
          ),
        );
      },
    );
  }
}
