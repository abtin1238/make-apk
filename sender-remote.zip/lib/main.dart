import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const AbtinRemoteApp());

class AbtinRemoteApp extends StatelessWidget {
  const AbtinRemoteApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'Abtin Remote',
    theme: ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xff0b1020),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff4b8cff), brightness: Brightness.dark)),
    home: const RemoteHome());
}

class RemoteHome extends StatefulWidget {
  const RemoteHome({super.key});
  @override State<RemoteHome> createState() => _RemoteHomeState();
}
class _RemoteHomeState extends State<RemoteHome> {
  static const hid = MethodChannel('ir.abtin.remote/hid');
  Socket? socket; RawDatagramSocket? discovery;
  String status='آماده اتصال', ip='192.168.43.1', mode='Mouse';
  bool connected=false, hidReady=false;
  final address=TextEditingController(text:'192.168.43.1');
  Timer? heartbeat;
  Future<void> connect() async {
    await disconnect();
    try {
      socket=await Socket.connect(address.text.trim(),39877,timeout:const Duration(seconds:4));
      socket!.listen((d){},onDone:()=>setState(()=>connected=false),onError:(_)=>setState(()=>connected=false));
      setState(()=>{connected=true,status:'متصل به Android Box'});
      _send({'type':'hello','client':'AbtinRemote','version':1});
      heartbeat=Timer.periodic(const Duration(seconds:10),(_)=>_send({'type':'ping'}));
    } catch(e){setState(()=>{connected=false,status:'اتصال ناموفق: ${e.toString()}' });}
  }
  Future<void> disconnect() async {
    heartbeat?.cancel(); heartbeat=null; await socket?.close(); socket=null;
    if(mounted)setState(()=>connected=false);
  }
  void _send(Map<String,dynamic> data) {
    if(socket==null)return;
    socket!.write('${jsonEncode(data)}\n');
  }
  void pointer(double dx,double dy) => _send({'type':'pointer','dx':dx,'dy':dy});
  void button(String name,bool down) => _send({'type':'key','key':name,'down':down});
  Future<void> hidStart() async {
    try { final ok=await hid.invokeMethod<bool>('startHid')??false;
      setState(()=>{hidReady=ok,status:ok?'Bluetooth HID فعال شد؛ از تنظیمات باکس Pair کنید':'این گوشی Bluetooth HID را پشتیبانی نکرد'}); }
    on PlatformException catch(e){setState(()=>status='خطای Bluetooth HID: ${e.message}');}
  }
  Future<void> game(String key,bool down) async {
    try { await hid.invokeMethod('gameButton',{'key':key,'down':down}); }
    catch(_){}
  }
  @override void dispose(){disconnect();address.dispose();super.dispose();}
  Widget pad(String label,VoidCallback down,VoidCallback up,{double size=62}) =>
    GestureDetector(onTapDown:(_)=>down(),onTapUp:(_)=>up(),onTapCancel:up,
      child:Container(width:size,height:size,alignment:Alignment.center,
        decoration:BoxDecoration(color:const Color(0xff202d4a),borderRadius:BorderRadius.circular(18),
          border:Border.all(color:const Color(0xff4b8cff))),child:Text(label,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold))));
  Widget action(String text,String key)=>pad(text,()=>game(key,true),()=>game(key,false));
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('Abtin Remote'),centerTitle:true),
    body:SafeArea(child:Column(children:[
      Padding(padding:const EdgeInsets.all(12),child:Column(children:[
        Row(children:[Expanded(child:TextField(controller:address,decoration:const InputDecoration(labelText:'IP گیرنده',hintText:'192.168.43.1'))),
          const SizedBox(width:8),FilledButton(onPressed:connected?disconnect:connect,child:Text(connected?'قطع':'اتصال'))]),
        const SizedBox(height:6),Row(children:[Icon(Icons.circle,size:10,color:connected?Colors.green:Colors.orange),const SizedBox(width:8),Expanded(child:Text(status,style:const TextStyle(fontSize:12)))]),
        const SizedBox(height:8),Wrap(spacing:8,children:['Mouse','Keyboard','Gamepad'].map((m)=>ChoiceChip(label:Text(m),selected:mode==m,onSelected:(_)=>setState(()=>mode=m))).toList()),
      ])),
      Expanded(child:mode=='Mouse'?_mouse():mode=='Keyboard'?_keyboard():_gamepad()),
      Padding(padding:const EdgeInsets.all(10),child:OutlinedButton.icon(onPressed:hidStart,icon:const Icon(Icons.bluetooth),label:Text(hidReady?'Bluetooth HID آماده است':'فعال‌سازی Bluetooth HID')))
    ])));
  Widget _mouse()=>Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
    Container(width:270,height:220,decoration:BoxDecoration(color:const Color(0xff151f36),borderRadius:BorderRadius.circular(24)),
      child:GestureDetector(onPanUpdate:(d)=>pointer(d.delta.dx,d.delta.dy),onTap:()=>_send({'type':'click','button':'left'}),
        onLongPress:()=>_send({'type':'click','button':'right'}),child:const Center(child:Icon(Icons.mouse,size:70,color:Color(0xff79aaff))))),
    const SizedBox(height:18),Row(mainAxisAlignment:MainAxisAlignment.center,children:[
      FilledButton(onPressed:()=>_send({'type':'click','button':'left'}),child:const Text('چپ')),
      const SizedBox(width:12),FilledButton(onPressed:()=>_send({'type':'click','button':'right'}),child:const Text('راست'))]),
    const SizedBox(height:12),Row(mainAxisAlignment:MainAxisAlignment.center,children:[
      IconButton(onPressed:()=>_send({'type':'scroll','dy':-3}),icon:const Icon(Icons.keyboard_arrow_up,size:34)),
      const Text('اسکرول'),IconButton(onPressed:()=>_send({'type':'scroll','dy':3}),icon:const Icon(Icons.keyboard_arrow_down,size:34))])
  ]));
  Widget _keyboard()=>Padding(padding:const EdgeInsets.all(12),child:Column(children:[
    TextField(onSubmitted:(v)=>_send({'type':'text','text':v}),decoration:const InputDecoration(labelText:'متن را بنویسید و ارسال کنید',suffixIcon:Icon(Icons.send))),
    const SizedBox(height:20),Wrap(spacing:10,runSpacing:10,alignment:WrapAlignment.center,children:[
      for(final k in ['ESC','TAB','ENTER','BACKSPACE','SPACE','UP','DOWN','LEFT','RIGHT','HOME','BACK'])
        FilledButton.tonal(onPressed:()=>_send({'type':'key','key':k,'down':true}),child:Text(k))
    ])
  ]));
  Widget _gamepad()=>SingleChildScrollView(child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[
    Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[
      Column(children:[action('▲','UP'),Row(children:[action('◀','LEFT'),const SizedBox(width:8),action('▶','RIGHT')]),action('▼','DOWN')]),
      Column(children:[action('△','TRIANGLE'),Row(children:[action('□','SQUARE'),const SizedBox(width:8),action('○','CIRCLE')]),action('×','CROSS')])
    ]),
    const SizedBox(height:20),Row(mainAxisAlignment:MainAxisAlignment.spaceEvenly,children:[
      action('L1','L1'),action('L2','L2'),action('R1','R1'),action('R2','R2')]),
    const SizedBox(height:18),Row(mainAxisAlignment:MainAxisAlignment.center,children:[
      action('SELECT','SELECT',),const SizedBox(width:35),action('START','START')]),
    const SizedBox(height:18),const Text('آنالوگ چپ و راست: در نسخه فعلی به‌صورت محورهای لمسی پیاده‌سازی می‌شوند؛ ePSXe باید کنترلر Bluetooth را شناسایی کند.')
  ])));
}
