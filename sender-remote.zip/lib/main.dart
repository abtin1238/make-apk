import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'link.dart';
import 'pages.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AbtinRemoteApp());
}

class AppState extends ChangeNotifier {
  final WifiLink link = WifiLink();
  String host = '';
  String pin = '';

  AppState() {
    link.addListener(notifyListeners);
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await SharedPreferences.getInstance();
      host = p.getString('host') ?? '';
      pin = p.getString('pin') ?? '';
      notifyListeners();
    } catch (_) {}
  }

  Future<void> save(String h, String p) async {
    host = h;
    pin = p;
    try {
      final sp = await SharedPreferences.getInstance();
      await sp.setString('host', h);
      await sp.setString('pin', p);
    } catch (_) {}
  }

  @override
  void dispose() {
    link.removeListener(notifyListeners);
    link.dispose();
    super.dispose();
  }
}

class AbtinRemoteApp extends StatefulWidget {
  const AbtinRemoteApp({super.key});
  @override
  State<AbtinRemoteApp> createState() => _AbtinRemoteAppState();
}

class _AbtinRemoteAppState extends State<AbtinRemoteApp> {
  final AppState state = AppState();

  @override
  void dispose() {
    state.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Abtin Remote',
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          scaffoldBackgroundColor: const Color(0xff0b1020),
          colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xff4b8cff), brightness: Brightness.dark),
        ),
        home: RemoteHome(state: state),
      );
}

class RemoteHome extends StatefulWidget {
  final AppState state;
  const RemoteHome({super.key, required this.state});
  @override
  State<RemoteHome> createState() => _RemoteHomeState();
}

class _RemoteHomeState extends State<RemoteHome> {
  int tab = 0;

  void _openConnect() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => ConnectSheet(state: widget.state),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = widget.state;
    return ListenableBuilder(
      listenable: state,
      builder: (context, _) {
        final link = state.link;
        return Scaffold(
          appBar: AppBar(
            title: const Text('Abtin Remote'),
            centerTitle: true,
            actions: [
              IconButton(
                tooltip: 'اتصال',
                onPressed: _openConnect,
                icon: Icon(link.connected ? Icons.wifi : Icons.wifi_off,
                    color: link.connected ? Colors.greenAccent : Colors.orangeAccent),
              ),
            ],
          ),
          body: SafeArea(
            child: Column(children: [
              if (!link.connected)
                Material(
                  color: const Color(0xff3a2a10),
                  child: ListTile(
                    dense: true,
                    leading: const Icon(Icons.info_outline),
                    title: Text(link.status),
                    trailing: TextButton(onPressed: _openConnect, child: const Text('اتصال')),
                  ),
                )
              else if (!link.accessibilityOn)
                const Material(
                  color: Color(0xff3a2a10),
                  child: ListTile(
                    dense: true,
                    leading: Icon(Icons.warning_amber),
                    title: Text('سرویس دسترس‌پذیری روی باکس فعال نیست؛ در اپ گیرنده فعالش کنید'),
                  ),
                ),
              Expanded(
                child: IndexedStack(index: tab, children: [
                  MousePage(link: link),
                  KeyboardPage(link: link),
                  GamepadPage(link: link),
                ]),
              ),
            ]),
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            destinations: const [
              NavigationDestination(icon: Icon(Icons.mouse), label: 'موس'),
              NavigationDestination(icon: Icon(Icons.keyboard), label: 'کیبورد'),
              NavigationDestination(icon: Icon(Icons.sports_esports), label: 'دسته'),
            ],
          ),
        );
      },
    );
  }
}

class ConnectSheet extends StatefulWidget {
  final AppState state;
  const ConnectSheet({super.key, required this.state});
  @override
  State<ConnectSheet> createState() => _ConnectSheetState();
}

class _ConnectSheetState extends State<ConnectSheet> {
  late final TextEditingController host =
      TextEditingController(text: widget.state.host);
  late final TextEditingController pin =
      TextEditingController(text: widget.state.pin);
  bool searching = false;
  List<FoundBox> found = const [];

  @override
  void dispose() {
    host.dispose();
    pin.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    setState(() {
      searching = true;
      found = const [];
    });
    final r = await WifiLink.discover();
    if (!mounted) return;
    setState(() {
      searching = false;
      found = r;
      if (r.length == 1) host.text = r.first.ip;
    });
  }

  Future<void> _connect() async {
    final link = widget.state.link;
    if (link.connected) {
      await link.disconnect();
      return;
    }
    await widget.state.save(host.text.trim(), pin.text.trim());
    await link.connect(host.text, pin.text);
    if (link.connected && mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final link = widget.state.link;
    return Padding(
      padding: EdgeInsets.only(
          left: 16, right: 16, top: 16, bottom: MediaQuery.of(context).viewInsets.bottom + 16),
      child: ListenableBuilder(
        listenable: link,
        builder: (context, _) => SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('اتصال به Android Box', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            const Text('IP و PIN روی صفحه‌ی اپ گیرنده نمایش داده می‌شود.', style: TextStyle(fontSize: 12)),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: searching ? null : _search,
              icon: searching
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.search),
              label: Text(searching ? 'در حال جستجو...' : 'جستجوی خودکار'),
            ),
            if (found.isNotEmpty)
              Wrap(spacing: 8, children: [
                for (final f in found)
                  ActionChip(label: Text('${f.name}  ${f.ip}'), onPressed: () => setState(() => host.text = f.ip)),
              ])
            else if (!searching)
              const SizedBox.shrink(),
            const SizedBox(height: 8),
            TextField(
              controller: host,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'IP باکس', hintText: '192.168.1.20'),
            ),
            TextField(
              controller: pin,
              keyboardType: TextInputType.number,
              maxLength: 4,
              decoration: const InputDecoration(labelText: 'PIN (۴ رقم)'),
            ),
            const SizedBox(height: 4),
            FilledButton(
              onPressed: link.connecting ? null : _connect,
              child: Text(link.connected ? 'قطع اتصال' : (link.connecting ? 'در حال اتصال...' : 'اتصال')),
            ),
            const SizedBox(height: 8),
            Text(link.status, textAlign: TextAlign.center),
          ]),
        ),
      ),
    );
  }
}
