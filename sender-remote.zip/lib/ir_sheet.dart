import 'package:flutter/material.dart';

import 'ir.dart';
import 'theme.dart';

/// آدرس‌های ۸بیتی NEC که روی باکس‌های اندرویدی چینی بیشتر دیده می‌شود.
/// (کد واقعی m4game معلوم نیست؛ اسکن این آدرس‌ها را یکی‌یکی امتحان می‌کند.)
const List<int> kCommonNecAddrs = [0x00, 0x01, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0xFE, 0xFF];

Future<void> showIrDialog(BuildContext context, IrController ir) {
  return showDialog<void>(
    context: context,
    builder: (_) => Dialog(
      backgroundColor: const Color(0xff0c1124),
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: kBlue.withOpacity(0.6)),
      ),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 560),
        child: Padding(padding: const EdgeInsets.all(14), child: IrPanel(ir: ir)),
      ),
    ),
  );
}

Future<String?> _askName(BuildContext context, String title, String initial) {
  final ctl = TextEditingController(text: initial);
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: const Color(0xff0c1124),
      title: Text(title, style: const TextStyle(fontSize: 15)),
      content: TextField(controller: ctl, autofocus: true, onSubmitted: (v) => Navigator.of(ctx).pop(v)),
      actions: [
        TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('لغو')),
        FilledButton(onPressed: () => Navigator.of(ctx).pop(ctl.text), child: const Text('تأیید')),
      ],
    ),
  );
}

class IrPanel extends StatefulWidget {
  final IrController ir;
  const IrPanel({super.key, required this.ir});
  @override
  State<IrPanel> createState() => _IrPanelState();
}

class _IrPanelState extends State<IrPanel> {
  String target = 'POWER';
  String proto = 'nec';
  bool scanCommon = true;
  double interval = 350;
  bool running = false;
  int idx = 0;
  IrCode? current;
  String note = '';

  final TextEditingController addrCtl = TextEditingController(text: '00');
  final TextEditingController cmdCtl = TextEditingController(text: '00');

  IrController get ir => widget.ir;

  @override
  void initState() {
    super.initState();
    target = ir.scanTarget;
    proto = ir.scanProto;
    scanCommon = ir.scanCommon;
    interval = ir.scanInterval.clamp(150.0, 900.0).toDouble();
    addrCtl.text = ir.scanAddr;
    cmdCtl.text = ir.scanCmd;
    idx = ir.scanIdx.clamp(0, _total - 1).toInt();
    if (idx > 0) current = _codeAt(idx);
  }

  /// وضعیت اسکن را در کنترلر (و حافظه) نگه می‌دارد تا با بستن پنجره از دست نرود.
  void _persist() {
    ir.scanTarget = target;
    ir.scanProto = proto;
    ir.scanCommon = scanCommon;
    ir.scanInterval = interval;
    ir.scanIdx = idx;
    ir.scanAddr = addrCtl.text;
    ir.scanCmd = cmdCtl.text;
    ir.saveScan();
  }

  String _hx(int v, [int w = 2]) => v.toRadixString(16).toUpperCase().padLeft(w, '0');

  void _moveTo(int i) {
    setState(() {
      idx = i.clamp(0, _total - 1).toInt();
      current = _codeAt(idx);
    });
  }

  @override
  void dispose() {
    running = false;
    _persist();
    addrCtl.dispose();
    cmdCtl.dispose();
    super.dispose();
  }

  int get _maxAddr => proto == 'necx' ? 0xffff : 0xff;

  int _parse(String s, int max) {
    final v = int.tryParse(s.trim().replaceAll('0x', '').replaceAll('0X', ''), radix: 16) ?? 0;
    return v.clamp(0, max).toInt();
  }

  List<int> get _addrs {
    if (scanCommon && proto == 'nec') return kCommonNecAddrs;
    return [_parse(addrCtl.text, _maxAddr)];
  }

  int get _total => _addrs.length * 256;

  IrCode _codeAt(int i) {
    final a = _addrs;
    return IrCode(proto, a[(i ~/ 256) % a.length], i % 256);
  }

  void _resetScan() {
    running = false;
    idx = 0;
    current = null;
    note = '';
    _persist();
  }

  Future<void> _sendIdx(int i) async {
    final c = _codeAt(i);
    if (mounted) setState(() => current = c);
    await ir.sendCode(c);
  }

  Future<void> _run() async {
    if (running) return;
    if (!ir.hasEmitter) {
      setState(() => note = 'این گوشی فرستنده‌ی IR ندارد');
      return;
    }
    setState(() {
      running = true;
      note = 'در حال اسکن... وقتی باکس واکنش نشان داد «توقف» را بزنید';
    });
    while (running && mounted) {
      if (idx >= _total) {
        setState(() {
          running = false;
          idx = _total - 1;
          note = 'اسکن تمام شد';
        });
        break;
      }
      await _sendIdx(idx);
      await Future<void>.delayed(Duration(milliseconds: interval.round()));
      if (!running || !mounted) break;
      setState(() => idx++);
      if (idx % 16 == 0) _persist();
    }
  }

  void _pause() {
    _persist();
    setState(() {
      running = false;
      note = 'متوقف شد. با ◀ ▶ قدم‌به‌قدم برگردید تا کد دقیق را پیدا کنید، بعد «ذخیره».';
    });
  }

  Future<void> _step(int d) async {
    running = false;
    final i = (idx + d).clamp(0, _total - 1).toInt();
    setState(() {
      idx = i;
      note = '';
    });
    _persist();
    await _sendIdx(i);
  }

  void _saveCurrent() {
    final c = current;
    if (c == null) return;
    ir.setCode(target, c);
    setState(() {
      running = false;
      note = 'ذخیره شد: ${irButtonLabel(target)} ← ${c.label}';
    });
  }

  IrCode _manualCode() => IrCode(proto, _parse(addrCtl.text, _maxAddr), _parse(cmdCtl.text, 0xff));

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: ir,
      builder: (context, _) {
        final c = current;
        return SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('کنترل مادون قرمز (IR)',
                  textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(
                ir.hasEmitter
                    ? 'فرستنده‌ی IR گوشی فعال است. گوشی را رو به باکس بگیرید.'
                    : 'این گوشی فرستنده‌ی IR ندارد؛ فقط Wi-Fi کار می‌کند.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: ir.hasEmitter ? kHint : const Color(0xffffa23c)),
              ),
              const SizedBox(height: 8),
              Row(children: [
                const SizedBox(width: 62, child: Text('پروفایل')),
                Expanded(
                  child: DropdownButton<int>(
                    isExpanded: true,
                    value: ir.activeIdx,
                    dropdownColor: const Color(0xff141a33),
                    items: [
                      for (var i = 0; i < ir.profiles.length; i++)
                        DropdownMenuItem(value: i, child: Text(ir.profiles[i].name)),
                    ],
                    onChanged: (v) {
                      if (v != null) {
                        ir.selectProfile(v);
                        setState(() => running = false);
                      }
                    },
                  ),
                ),
                IconButton(
                  tooltip: 'پروفایل جدید',
                  icon: const Icon(Icons.add_circle_outline),
                  onPressed: () async {
                    final n = await _askName(context, 'پروفایل جدید (مثلاً تی‌وی اتاق)', '');
                    if (n != null) {
                      ir.addProfile(n);
                      setState(_resetScan);
                    }
                  },
                ),
                IconButton(
                  tooltip: 'تغییر نام',
                  icon: const Icon(Icons.edit_outlined),
                  onPressed: () async {
                    final n = await _askName(context, 'نام پروفایل', ir.active.name);
                    if (n != null) ir.renameActive(n);
                  },
                ),
                IconButton(
                  tooltip: 'حذف پروفایل',
                  icon: const Icon(Icons.delete_outline),
                  onPressed: ir.profiles.length > 1
                      ? () {
                          ir.deleteActive();
                          setState(_resetScan);
                        }
                      : null,
                ),
              ]),
              SwitchListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: const Text('فقط IR (دستگاه Wi-Fi ندارد، مثل تی‌وی)', style: TextStyle(fontSize: 13)),
                value: ir.active.irOnly,
                onChanged: ir.setActiveIrOnly,
              ),
              const SizedBox(height: 4),
              SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('خودکار')),
                  ButtonSegment(value: 1, label: Text('فقط Wi-Fi')),
                  ButtonSegment(value: 2, label: Text('فقط IR')),
                ],
                selected: {ir.mode},
                onSelectionChanged: (s) => ir.setMode(s.first),
              ),
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text(
                  'خودکار: اگر به باکس وصلید Wi-Fi، وگرنه IR. پروفایل «فقط IR» همیشه IR می‌فرستد.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11, color: kHint),
                ),
              ),
              SwitchListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: const Text('پاور همیشه با IR (روشن‌کردن از حالت خاموش)', style: TextStyle(fontSize: 13)),
                value: ir.powerViaIr,
                onChanged: ir.setPowerViaIr,
              ),
              const Divider(height: 18),
              const Text('پیدا کردن / ذخیره‌ی کد دکمه‌ها',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              Row(children: [
                const SizedBox(width: 62, child: Text('دکمه')),
                Expanded(
                  child: DropdownButton<String>(
                    isExpanded: true,
                    value: target,
                    dropdownColor: const Color(0xff141a33),
                    items: [
                      for (final e in kIrButtons)
                        DropdownMenuItem(
                          value: e.key,
                          child: Text(ir.codes.containsKey(e.key) ? '${e.value}  ✓' : e.value),
                        ),
                    ],
                    onChanged: (v) {
                      setState(() => target = v ?? target);
                      _persist();
                    },
                  ),
                ),
              ]),
              Row(children: [
                const SizedBox(width: 62, child: Text('پروتکل')),
                Expanded(
                  child: DropdownButton<String>(
                    isExpanded: true,
                    value: proto,
                    dropdownColor: const Color(0xff141a33),
                    items: const [
                      DropdownMenuItem(value: 'nec', child: Text('NEC (آدرس ۸بیتی)')),
                      DropdownMenuItem(value: 'necx', child: Text('NEC Extended (آدرس ۱۶بیتی)')),
                    ],
                    onChanged: (v) => setState(() {
                      proto = v ?? proto;
                      _resetScan();
                    }),
                  ),
                ),
              ]),
              Row(children: [
                const SizedBox(width: 62, child: Text('آدرس')),
                Expanded(
                  child: TextField(
                    controller: addrCtl,
                    enabled: !(scanCommon && proto == 'nec'),
                    maxLength: proto == 'necx' ? 4 : 2,
                    decoration: const InputDecoration(prefixText: '0x ', counterText: '', hintText: '00'),
                    onChanged: (_) => setState(_resetScan),
                  ),
                ),
                const SizedBox(width: 12),
                const Text('دستور'),
                const SizedBox(width: 8),
                SizedBox(
                  width: 80,
                  child: TextField(
                    controller: cmdCtl,
                    maxLength: 2,
                    onChanged: (_) => _persist(),
                    decoration: const InputDecoration(prefixText: '0x ', counterText: '', hintText: '00'),
                  ),
                ),
              ]),
              if (proto == 'nec')
                SwitchListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: const Text('اسکن چند آدرس رایج (آدرس بالا نادیده گرفته می‌شود)', style: TextStyle(fontSize: 12)),
                  value: scanCommon,
                  onChanged: (v) => setState(() {
                    scanCommon = v;
                    _resetScan();
                  }),
                ),
              Wrap(spacing: 8, alignment: WrapAlignment.center, children: [
                OutlinedButton(
                  onPressed: ir.hasEmitter ? () => ir.sendCode(_manualCode()) : null,
                  child: const Text('تست کد دستی'),
                ),
                FilledButton(
                  onPressed: () {
                    final m = _manualCode();
                    ir.setCode(target, m);
                    setState(() => note = 'ذخیره شد: ${irButtonLabel(target)} ← ${m.label}');
                  },
                  child: const Text('ذخیره‌ی کد دستی'),
                ),
              ]),
              const Divider(height: 18),
              const Text('اسکن خودکار (وقتی کد را نمی‌دانید)',
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
              Row(children: [
                const Text('فاصله', style: TextStyle(fontSize: 12)),
                Expanded(
                  child: Slider(
                    min: 150,
                    max: 900,
                    divisions: 15,
                    label: '${interval.round()} ms',
                    value: interval,
                    onChanged: (v) => setState(() => interval = v),
                    onChangeEnd: (_) => _persist(),
                  ),
                ),
                Text('${interval.round()} ms', style: const TextStyle(fontSize: 12)),
              ]),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kCyan.withOpacity(0.5)),
                ),
                child: Column(children: [
                  Text(
                    c == null ? 'هنوز چیزی ارسال نشده' : c.label,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 2),
                  Text('${c == null ? 0 : idx + 1} / $_total', style: const TextStyle(fontSize: 11, color: kHint)),
                  LinearProgressIndicator(value: _total == 0 ? 0 : (c == null ? 0 : (idx + 1) / _total)),
                ]),
              ),
              if (_addrs.length > 1)
                Row(children: [
                  const SizedBox(width: 48, child: Text('آدرس', style: TextStyle(fontSize: 12))),
                  Expanded(
                    child: Slider(
                      min: 0,
                      max: (_addrs.length - 1).toDouble(),
                      divisions: _addrs.length - 1,
                      value: (idx ~/ 256).clamp(0, _addrs.length - 1).toDouble(),
                      onChanged: (v) => _moveTo(v.round() * 256 + idx % 256),
                      onChangeEnd: (_) => _persist(),
                    ),
                  ),
                  SizedBox(width: 44, child: Text('0x${_hx(_addrs[(idx ~/ 256).clamp(0, _addrs.length - 1).toInt()])}', style: const TextStyle(fontSize: 12))),
                ]),
              Row(children: [
                const SizedBox(width: 48, child: Text('دستور', style: TextStyle(fontSize: 12))),
                Expanded(
                  child: Slider(
                    min: 0,
                    max: 255,
                    divisions: 255,
                    value: (idx % 256).toDouble(),
                    onChanged: (v) => _moveTo((idx ~/ 256) * 256 + v.round()),
                    onChangeEnd: (_) => _persist(),
                  ),
                ),
                SizedBox(width: 44, child: Text('0x${_hx(idx % 256)}', style: const TextStyle(fontSize: 12))),
              ]),
              const SizedBox(height: 6),
              Wrap(spacing: 8, runSpacing: 4, alignment: WrapAlignment.center, children: [
                IconButton.outlined(onPressed: () => _step(-1), icon: const Icon(Icons.chevron_left), tooltip: 'قبلی'),
                running
                    ? FilledButton.icon(onPressed: _pause, icon: const Icon(Icons.pause), label: const Text('توقف'))
                    : FilledButton.icon(onPressed: _run, icon: const Icon(Icons.play_arrow), label: const Text('شروع')),
                IconButton.outlined(onPressed: () => _step(1), icon: const Icon(Icons.chevron_right), tooltip: 'بعدی'),
                FilledButton.icon(
                  onPressed: c == null ? null : _saveCurrent,
                  icon: const Icon(Icons.check),
                  label: Text('این بود → ${irButtonLabel(target)}'),
                  style: FilledButton.styleFrom(backgroundColor: const Color(0xff1f9d55)),
                ),
              ]),
              if (note.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(note, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: kHint)),
                ),
              const Divider(height: 18),
              Row(children: [
                const Expanded(
                  child: Text('کدهای ذخیره‌شده‌ی این پروفایل', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                ),
                if (ir.codes.isNotEmpty) TextButton(onPressed: ir.clearCodes, child: const Text('حذف همه')),
              ]),
              if (ir.codes.isEmpty)
                const Text('هنوز کدی ذخیره نشده.', style: TextStyle(fontSize: 12, color: kHint))
              else
                Wrap(spacing: 6, runSpacing: 4, children: [
                  for (final e in ir.codes.entries)
                    InputChip(
                      label: Text('${irButtonLabel(e.key)}  ${e.value.label}', style: const TextStyle(fontSize: 11)),
                      onPressed: () => ir.sendCode(e.value),
                      onDeleted: () => ir.removeCode(e.key),
                    ),
                ]),
              const SizedBox(height: 6),
              TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('بستن')),
            ],
          ),
        );
      },
    );
  }
}
