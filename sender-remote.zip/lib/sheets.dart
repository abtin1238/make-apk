import 'package:flutter/material.dart';

import 'keycap.dart';
import 'bt_sheet.dart';
import 'ir.dart';
import 'ir_sheet.dart';
import 'link.dart';
import 'theme.dart';
import 'touchpad.dart';

Dialog _dialog(Widget child, {double width = 460}) => Dialog(
      backgroundColor: const Color(0xff0c1124),
      insetPadding: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: kBlue.withOpacity(0.6)),
      ),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: width),
        child: Padding(padding: const EdgeInsets.all(14), child: child),
      ),
    );

// ---------------- منوی حالت‌ها ----------------
Future<void> showModeMenu(
  BuildContext context, {
  required int current,
  required ValueChanged<int> onSelect,
  required WifiLink link,
  required PadSettings settings,
  required IrController ir,
}) {
  Widget mode(BuildContext ctx, int i, IconData icon, String label, Color c) {
    final on = i == current;
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(4),
        child: GestureDetector(
          onTap: () {
            Navigator.of(ctx).pop();
            onSelect(i);
          },
          child: Container(
            height: 88,
            decoration: neonBox(c, pressed: on, radius: 14),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(icon, size: 30, color: Colors.white),
              const SizedBox(height: 4),
              Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12)),
            ]),
          ),
        ),
      ),
    );
  }

  Widget q(IconData icon, String key) => Padding(
        padding: const EdgeInsets.all(3),
        child: SizedBox(
          width: 52,
          height: 40,
          child: KeyCap(label: key, icon: icon, color: kBlue, fontScale: 0.7, haptics: settings.haptics, onDown: () => link.key(key)),
        ),
      );

  return showDialog<void>(
    context: context,
    builder: (ctx) => _dialog(
      SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            mode(ctx, 0, Icons.keyboard, 'کیبورد + موس', kCyan),
            mode(ctx, 1, Icons.sports_esports, 'دسته بازی', kPurple),
            mode(ctx, 2, Icons.mouse, 'موس کامل', kMagenta),
            mode(ctx, 3, Icons.tv, 'ریموت TV', kBlue),
          ]),
          const SizedBox(height: 8),
          Wrap(alignment: WrapAlignment.center, children: [
            q(Icons.arrow_back, 'BACK'),
            q(Icons.home, 'HOME'),
            q(Icons.crop_square, 'RECENTS'),
            q(Icons.notifications_none, 'NOTIFICATIONS'),
            q(Icons.volume_down, 'VOL_DOWN'),
            q(Icons.volume_up, 'VOL_UP'),
            q(Icons.volume_off, 'MUTE'),
            q(Icons.skip_previous, 'PREV'),
            q(Icons.play_arrow, 'PLAY_PAUSE'),
            q(Icons.skip_next, 'NEXT'),
          ]),
          Wrap(alignment: WrapAlignment.center, spacing: 8, children: [
            TextButton.icon(
              onPressed: () {
                Navigator.of(ctx).pop();
                showBtDialog(context, link.bt);
              },
              icon: const Icon(Icons.bluetooth, size: 18),
              label: const Text('بلوتوث'),
            ),
            TextButton.icon(
              onPressed: () {
                Navigator.of(ctx).pop();
                showIrDialog(context, ir);
              },
              icon: const Icon(Icons.settings_remote, size: 18),
              label: const Text('کنترل IR'),
            ),
            TextButton.icon(
              onPressed: () {
                Navigator.of(ctx).pop();
                showSettingsDialog(context, settings);
              },
              icon: const Icon(Icons.settings, size: 18),
              label: const Text('تنظیمات'),
            ),
          ]),
        ]),
      ),
      width: 620,
    ),
  );
}

// ---------------- تنظیمات ----------------
Future<void> showSettingsDialog(BuildContext context, PadSettings s) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => _dialog(
      ListenableBuilder(
        listenable: s,
        builder: (_, __) => SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('تنظیمات', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Row(children: [
              const SizedBox(width: 90, child: Text('حساسیت موس')),
              Expanded(child: Slider(min: 0.6, max: 4, value: s.sensitivity, onChanged: (v) => s.update(sens: v))),
            ]),
            Row(children: [
              const SizedBox(width: 90, child: Text('سرعت اسکرول')),
              Expanded(child: Slider(min: 0.4, max: 3, value: s.scrollSpeed, onChanged: (v) => s.update(scroll: v))),
            ]),
            Row(children: [
              const SizedBox(width: 90, child: Text('حساسیت ژیرو')),
              Expanded(child: Slider(min: 0.3, max: 3, value: s.gyroSens, onChanged: (v) => s.update(gyro: v))),
            ]),
            SwitchListTile(
              dense: true,
              title: const Text('ژیرو: وارونه کردن چپ/راست'),
              value: s.gyroInvX,
              onChanged: (v) => s.update(invX: v),
            ),
            SwitchListTile(
              dense: true,
              title: const Text('ژیرو: وارونه کردن بالا/پایین'),
              value: s.gyroInvY,
              onChanged: (v) => s.update(invY: v),
            ),
            SwitchListTile(
              dense: true,
              title: const Text('اسکرول طبیعی (جهت معکوس)'),
              value: s.naturalScroll,
              onChanged: (v) => s.update(natural: v),
            ),
            SwitchListTile(
              dense: true,
              title: const Text('لرزش هنگام لمس'),
              value: s.haptics,
              onChanged: (v) => s.update(hap: v),
            ),
            TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('بستن')),
          ]),
        ),
      ),
    ),
  );
}

// ---------------- اتصال ----------------
class ConnectDialog extends StatefulWidget {
  final WifiLink link;
  final String host;
  final String pin;
  final Future<void> Function(String host, String pin) onSave;
  const ConnectDialog({super.key, required this.link, required this.host, required this.pin, required this.onSave});
  @override
  State<ConnectDialog> createState() => _ConnectDialogState();
}

class _ConnectDialogState extends State<ConnectDialog> {
  late final TextEditingController host = TextEditingController(text: widget.host);
  late final TextEditingController pin = TextEditingController(text: widget.pin);
  bool searching = false;
  List<FoundBox> found = const [];

  @override
  void dispose() {
    host.dispose();
    pin.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    setState(() {
      searching = true;
      found = const [];
    });
    final r = await WifiLink.discover();
    if (!mounted) return;
    setState(() {
      searching = false;
      found = r;
      if (r.length == 1) host.text = r.first.ip;
    });
  }

  Future<void> _connect() async {
    final link = widget.link;
    if (link.connected) {
      await link.disconnect();
      return;
    }
    await widget.onSave(host.text.trim(), pin.text.trim());
    await link.connect(host.text, pin.text);
    if (link.connected && mounted) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final link = widget.link;
    return _dialog(
      ListenableBuilder(
        listenable: link,
        builder: (context, _) => SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Text('اتصال به Android Box', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const Text('IP و PIN روی صفحه‌ی اپ گیرنده نمایش داده می‌شود.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: kHint)),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: searching ? null : _search,
              icon: searching
                  ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.search),
              label: Text(searching ? 'در حال جستجو...' : 'جستجوی خودکار'),
            ),
            if (found.isNotEmpty)
              Wrap(spacing: 8, children: [
                for (final f in found)
                  ActionChip(label: Text('${f.name}  ${f.ip}'), onPressed: () => setState(() => host.text = f.ip)),
              ]),
            Row(children: [
              Expanded(
                flex: 3,
                child: TextField(
                  controller: host,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'IP باکس', hintText: '192.168.1.20'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: TextField(
                  controller: pin,
                  keyboardType: TextInputType.number,
                  maxLength: 4,
                  decoration: const InputDecoration(labelText: 'PIN (۴ رقم)', counterText: ''),
                ),
              ),
            ]),
            const SizedBox(height: 8),
            FilledButton(
              onPressed: link.connecting ? null : _connect,
              child: Text(link.connected ? 'قطع اتصال' : (link.connecting ? 'در حال اتصال...' : 'اتصال')),
            ),
            const SizedBox(height: 6),
            OutlinedButton.icon(
              onPressed: () => showBtDialog(context, link.bt),
              icon: const Icon(Icons.bluetooth),
              label: Text(link.bt.connected ? 'بلوتوث: ${link.bt.hostName}' : 'اتصال با بلوتوث (بدون Wi-Fi)'),
            ),
            const SizedBox(height: 6),
            Text(link.status, textAlign: TextAlign.center),
            if (link.connected && !link.accessibilityOn)
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text('سرویس دسترس‌پذیری روی باکس فعال نیست؛ در اپ گیرنده فعالش کنید',
                    textAlign: TextAlign.center, style: TextStyle(color: Color(0xffffa23c), fontSize: 12)),
              ),
          ]),
        ),
      ),
    );
  }
}
