import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'link.dart';
import 'theme.dart';
import 'touchpad.dart';

/// ریموت اندروید باکس / اندروید تی‌وی (عمودی) به‌شکل ریموت فیزیکی Abtin.
class TvRemotePage extends StatelessWidget {
  final WifiLink link;
  final PadSettings settings;
  final VoidCallback onMenu;
  final VoidCallback onConnect;
  const TvRemotePage({
    super.key,
    required this.link,
    required this.settings,
    required this.onMenu,
    required this.onConnect,
  });

  void _key(String k) => link.key(k);

  void _none(BuildContext context) {
    ScaffoldMessenger.of(context)
      ..clearSnackBars()
      ..showSnackBar(const SnackBar(
        duration: Duration(milliseconds: 1400),
        content: Text('این کلید روی اندروید باکس فرمانی ندارد'),
      ));
  }

  Future<void> _typeDialog(BuildContext context) {
    final ctl = TextEditingController();
    return showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xff0c1124),
        title: const Text('تایپ روی باکس'),
        content: TextField(
          controller: ctl,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'متن را بنویسید'),
          onSubmitted: (v) {
            link.text(v);
            Navigator.of(ctx).pop();
          },
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('بستن')),
          FilledButton(
            onPressed: () {
              link.text(ctl.text);
              Navigator.of(ctx).pop();
            },
            child: const Text('ارسال'),
          ),
          TextButton(
            onPressed: () => link.key('ENTER'),
            child: const Text('Enter'),
          ),
        ],
      ),
    );
  }

  // ---------- ساخت اجزا ----------
  Widget _b(Widget child, VoidCallback f,
      {bool repeat = false, Color? fill, Color? border, double radius = 16, bool circle = false}) {
    return _RBtn(
      onDown: f,
      repeat: repeat,
      fill: fill,
      border: border,
      radius: radius,
      circle: circle,
      haptics: settings.haptics,
      child: child,
    );
  }

  Widget _ic(IconData i, {double size = 24, Color c = Colors.white}) => Icon(i, size: size, color: c);

  Widget _txt(String t, {double size = 18}) => FittedBox(
        fit: BoxFit.scaleDown,
        child: Text(t, style: TextStyle(fontSize: size, fontWeight: FontWeight.w700, color: Colors.white)),
      );

  Widget _cell(Widget w, {int flex = 1}) =>
      Expanded(flex: flex, child: Padding(padding: const EdgeInsets.all(3), child: w));

  Widget _row(List<Widget> cells, {int flex = 10}) => Expanded(flex: flex, child: Row(children: cells));

  @override
  Widget build(BuildContext context) {
    final connected = link.connected;
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xff040a24), Color(0xff0b0630), Color(0xff1a0a3c)],
        ),
      ),
      child: LayoutBuilder(builder: (context, c) {
        final h = math.max(c.maxHeight, 720.0);
        final w = ((h - 36) / 2.6).clamp(230.0, math.max(230.0, c.maxWidth - 8)).toDouble();
        return SingleChildScrollView(
          child: SizedBox(
            height: h,
            child: Center(
              child: SizedBox(
                width: w,
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(14, 6, 14, 8),
                  child: Column(children: [
                    // وضعیت اتصال
                    SizedBox(
                      height: 28,
                      child: GestureDetector(
                        onTap: onConnect,
                        behavior: HitTestBehavior.opaque,
                        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                          Icon(connected ? Icons.wifi : Icons.wifi_off,
                              size: 16, color: connected ? const Color(0xff3dff8f) : const Color(0xffffa23c)),
                          const SizedBox(width: 6),
                          Text(connected ? link.boxName : 'متصل نیستید',
                              style: const TextStyle(fontSize: 12, color: Colors.white70)),
                        ]),
                      ),
                    ),
                    Expanded(child: _body(context)),
                  ]),
                ),
              ),
            ),
          ),
        );
      }),
    );
  }

  Widget _body(BuildContext context) {
    const nums = [
      ['1', '2', '3'],
      ['4', '5', '6'],
      ['7', '8', '9'],
    ];
    return Container(
      padding: const EdgeInsets.all(2.5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(34),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [kBlue, kCyan, kPurple, kMagenta],
        ),
        boxShadow: [BoxShadow(color: kPurple.withOpacity(0.5), blurRadius: 22)],
      ),
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 10, 10, 6),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(32),
          gradient: const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xff23262f), Color(0xff14161d)],
          ),
        ),
        child: Column(children: [
          // ردیف ۱: پاور / بی‌صدا / ورودی
          _row([
            _cell(_b(_ic(Icons.power_settings_new, size: 26), () => _key('POWER'),
                fill: const Color(0xffe01818), border: const Color(0xffff6a6a), circle: true)),
            _cell(_b(_ic(Icons.volume_off), () => _key('MUTE'), circle: true)),
            _cell(_b(_ic(Icons.tv), () => _key('NOTIFICATIONS'), circle: true)),
          ], flex: 9),
          // ردیف ۲: خانه / منو / تنظیمات
          _row([
            _cell(_b(_ic(Icons.home), () => _key('HOME'), circle: true)),
            _cell(_b(_ic(Icons.menu), () => _key('RECENTS'), circle: true)),
            _cell(_b(_ic(Icons.settings), () => _key('QUICK_SETTINGS'), circle: true)),
          ], flex: 9),
          // حلقه‌ی جهت‌ها
          Expanded(flex: 52, child: Center(child: AspectRatio(aspectRatio: 1, child: _ring()))),
          // برگشت / منوی حالت‌ها
          _row([
            _cell(_b(_ic(Icons.undo), () => _key('BACK'), radius: 22), flex: 1),
            _cell(_b(_ic(Icons.tv_outlined), onMenu, radius: 22), flex: 1),
          ], flex: 8),
          // صدا / میکروفون / کانال
          Expanded(
            flex: 20,
            child: Row(children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(3),
                  child: _split(
                    top: _ic(Icons.add),
                    mid: _ic(Icons.volume_up, size: 20),
                    bottom: _ic(Icons.remove),
                    onTop: () => _key('VOL_UP'),
                    onBottom: () => _key('VOL_DOWN'),
                  ),
                ),
              ),
              Expanded(
                child: Center(
                  child: AspectRatio(
                    aspectRatio: 1,
                    child: Padding(
                      padding: const EdgeInsets.all(6),
                      child: _b(_ic(Icons.mic, size: 28, c: kCyan), () => _none(context),
                          circle: true, border: kCyan.withOpacity(0.7)),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.all(3),
                  child: _split(
                    top: _ic(Icons.arrow_drop_up, size: 30),
                    mid: _txt('CH', size: 15),
                    bottom: _ic(Icons.arrow_drop_down, size: 30),
                    onTop: () => _key('PAGEUP'),
                    onBottom: () => _key('PAGEDOWN'),
                  ),
                ),
              ),
            ]),
          ),
          // مدیا
          _row([
            _cell(_b(_ic(Icons.fast_rewind), () => _key('PREV'), radius: 18)),
            _cell(_b(_ic(Icons.play_arrow), () => _key('PLAY_PAUSE'), radius: 18)),
            _cell(_b(_ic(Icons.fast_forward), () => _key('NEXT'), radius: 18)),
          ], flex: 8),
          // دکمه‌های رنگی
          _row([
            for (final col in const [Color(0xffe8262a), Color(0xff2bc43d), Color(0xfff5d21a), Color(0xff2a86ff)])
              _cell(_b(const SizedBox.shrink(), () => _none(context), fill: col, border: Colors.white24, radius: 14)),
          ], flex: 6),
          // صفحه‌شماره
          for (final r in nums)
            _row([
              for (final n in r) _cell(_b(_txt(n, size: 20), () => link.text(n), radius: 18)),
            ], flex: 9),
          _row([
            _cell(_b(_txt('INFO', size: 13), () => _none(context), radius: 18)),
            _cell(_b(_txt('0', size: 20), () => link.text('0'), radius: 18)),
            _cell(_b(_txt('DEL', size: 14), () => _key('BACKSPACE'), repeat: true, radius: 18)),
          ], flex: 9),
          _row([
            _cell(_b(_txt('TEXT', size: 13), () => _none(context), radius: 18)),
            _cell(_b(_ic(Icons.keyboard_alt_outlined), () => _typeDialog(context), radius: 18)),
            _cell(_b(_txt('EPG', size: 14), () => _none(context), radius: 18)),
          ], flex: 9),
          // لوگو
          Expanded(
            flex: 7,
            child: Center(
              child: FittedBox(
                child: Text('Abtin',
                    style: TextStyle(
                      fontSize: 22,
                      fontStyle: FontStyle.italic,
                      fontWeight: FontWeight.w800,
                      color: Colors.white.withOpacity(0.55),
                    )),
              ),
            ),
          ),
        ]),
      ),
    );
  }

  // دکمه‌ی دوتکه‌ی عمودی (صدا / کانال)
  Widget _split({
    required Widget top,
    required Widget mid,
    required Widget bottom,
    required VoidCallback onTop,
    required VoidCallback onBottom,
  }) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xff1b1e29), Color(0xff0c0e16)],
        ),
        border: Border.all(color: Colors.white12),
      ),
      child: Column(children: [
        Expanded(child: _RBtn(onDown: onTop, repeat: true, flat: true, haptics: settings.haptics, radius: 18, child: top)),
        SizedBox(height: 22, child: Center(child: mid)),
        Expanded(child: _RBtn(onDown: onBottom, repeat: true, flat: true, haptics: settings.haptics, radius: 18, child: bottom)),
      ]),
    );
  }

  // حلقه‌ی نئونی جهت‌ها + OK
  Widget _ring() {
    return Container(
      padding: const EdgeInsets.all(3.5),
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: SweepGradient(colors: [kCyan, kBlue, kPurple, kMagenta, kPurple, kBlue, kCyan]),
        boxShadow: [BoxShadow(color: Color(0x663c6bff), blurRadius: 20)],
      ),
      child: Container(
        decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xff0a0c13)),
        child: LayoutBuilder(builder: (context, c) {
          final s = c.maxWidth;
          final hit = s * 0.30;
          Widget arrow(Alignment a, IconData i, String k) => Align(
                alignment: a,
                child: SizedBox(
                  width: hit,
                  height: hit,
                  child: _RBtn(
                    onDown: () => _key(k),
                    repeat: true,
                    flat: true,
                    circle: true,
                    haptics: settings.haptics,
                    child: Icon(i, size: s * 0.12, color: Colors.white),
                  ),
                ),
              );
          return Stack(children: [
            arrow(const Alignment(0, -0.86), Icons.arrow_drop_up, 'UP'),
            arrow(const Alignment(0, 0.86), Icons.arrow_drop_down, 'DOWN'),
            arrow(const Alignment(-0.86, 0), Icons.arrow_left, 'LEFT'),
            arrow(const Alignment(0.86, 0), Icons.arrow_right, 'RIGHT'),
            Center(
              child: SizedBox(
                width: s * 0.38,
                height: s * 0.38,
                child: _RBtn(
                  onDown: () => _key('ENTER'),
                  circle: true,
                  haptics: settings.haptics,
                  border: Colors.white24,
                  child: Text('OK', style: TextStyle(fontSize: s * 0.10, fontWeight: FontWeight.w700, color: Colors.white)),
                ),
              ),
            ),
          ]);
        }),
      ),
    );
  }
}

/// دکمه‌ی ریموت: فشردن = روشن شدن، نگه‌داشتن = تکرار (اختیاری)
class _RBtn extends StatefulWidget {
  final Widget child;
  final VoidCallback onDown;
  final bool repeat;
  final bool flat;
  final bool circle;
  final bool haptics;
  final Color? fill;
  final Color? border;
  final double radius;
  const _RBtn({
    required this.child,
    required this.onDown,
    this.repeat = false,
    this.flat = false,
    this.circle = false,
    this.haptics = true,
    this.fill,
    this.border,
    this.radius = 16,
  });
  @override
  State<_RBtn> createState() => _RBtnState();
}

class _RBtnState extends State<_RBtn> {
  bool down = false;
  Timer? _delay;
  Timer? _rep;

  void _stop() {
    _delay?.cancel();
    _rep?.cancel();
    _delay = null;
    _rep = null;
  }

  void _press() {
    if (down) return;
    setState(() => down = true);
    if (widget.haptics) HapticFeedback.selectionClick();
    widget.onDown();
    if (widget.repeat) {
      _delay = Timer(const Duration(milliseconds: 420), () {
        _rep = Timer.periodic(const Duration(milliseconds: 90), (_) => widget.onDown());
      });
    }
  }

  void _release() {
    _stop();
    if (down && mounted) setState(() => down = false);
  }

  @override
  void dispose() {
    _stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final fill = widget.fill;
    BoxDecoration deco;
    if (widget.flat) {
      deco = BoxDecoration(
        shape: widget.circle ? BoxShape.circle : BoxShape.rectangle,
        borderRadius: widget.circle ? null : BorderRadius.circular(widget.radius),
        color: down ? Colors.white12 : Colors.transparent,
      );
    } else {
      deco = BoxDecoration(
        shape: widget.circle ? BoxShape.circle : BoxShape.rectangle,
        borderRadius: widget.circle ? null : BorderRadius.circular(widget.radius),
        gradient: fill != null
            ? LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [fill.withOpacity(down ? 1 : 0.95), fill.withOpacity(down ? 0.8 : 0.7)],
              )
            : LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: down
                    ? const [Color(0xff3a4a7a), Color(0xff1d2748)]
                    : const [Color(0xff1b1e29), Color(0xff0a0c13)],
              ),
        border: Border.all(color: widget.border ?? Colors.white12, width: 1.2),
        boxShadow: down ? [BoxShadow(color: (fill ?? kBlue).withOpacity(0.6), blurRadius: 12)] : const [],
      );
    }
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (_) => _press(),
      onPointerUp: (_) => _release(),
      onPointerCancel: (_) => _release(),
      child: Container(alignment: Alignment.center, decoration: deco, child: widget.child),
    );
  }
}
