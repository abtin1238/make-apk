import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'link.dart';

const Color _panel = Color(0xff151f36);
const Color _btn = Color(0xff202d4a);
const Color _accent = Color(0xff4b8cff);

// ======================= موس =======================

class MousePage extends StatefulWidget {
  final WifiLink link;
  const MousePage({super.key, required this.link});
  @override
  State<MousePage> createState() => _MousePageState();
}

class _MousePageState extends State<MousePage> {
  double sens = 1.6;

  Widget _hold(String label, String button) => Expanded(
        child: _HoldButton(
          label: label,
          onChange: (d) => widget.link.mouseButton(button, d),
        ),
      );

  Widget _quick(String label, IconData icon, String key) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 3),
          child: FilledButton.tonal(
            onPressed: () => widget.link.key(key),
            child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 20), Text(label, style: const TextStyle(fontSize: 11))]),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(children: [
        Expanded(
          child: Container(
            decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(24)),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: Touchpad(link: widget.link, sensitivity: sens),
            ),
          ),
        ),
        const SizedBox(height: 8),
        const Text(
          'یک انگشت: حرکت و کلیک  •  دو انگشت: اسکرول  •  تپ با دو انگشت: کلیک راست\nتپ و بلافاصله نگه‌داشتن و کشیدن: درگ',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 11, color: Color(0xff9fb3d9)),
        ),
        Row(children: [
          const Icon(Icons.speed, size: 18),
          Expanded(child: Slider(min: 0.6, max: 4, value: sens, onChanged: (v) => setState(() => sens = v))),
        ]),
        SizedBox(
          height: 54,
          child: Row(children: [
            _hold('چپ', 'left'),
            const SizedBox(width: 8),
            _hold('وسط (بک)', 'middle'),
            const SizedBox(width: 8),
            _hold('راست', 'right'),
          ]),
        ),
        const SizedBox(height: 8),
        Row(children: [
          _quick('بک', Icons.arrow_back, 'BACK'),
          _quick('خانه', Icons.home, 'HOME'),
          _quick('اخیر', Icons.crop_square, 'RECENTS'),
          _quick('بالا', Icons.keyboard_double_arrow_up, 'PAGEUP'),
          _quick('پایین', Icons.keyboard_double_arrow_down, 'PAGEDOWN'),
        ]),
      ]),
    );
  }
}

class _HoldButton extends StatefulWidget {
  final String label;
  final void Function(bool down) onChange;
  const _HoldButton({required this.label, required this.onChange});
  @override
  State<_HoldButton> createState() => _HoldButtonState();
}

class _HoldButtonState extends State<_HoldButton> {
  bool down = false;

  void _set(bool v) {
    if (down == v) return;
    setState(() => down = v);
    widget.onChange(v);
    if (v) HapticFeedback.selectionClick();
  }

  @override
  Widget build(BuildContext context) => Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (_) => _set(true),
        onPointerUp: (_) => _set(false),
        onPointerCancel: (_) => _set(false),
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: down ? _accent : _btn,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: _accent),
          ),
          child: Text(widget.label, style: const TextStyle(fontWeight: FontWeight.bold)),
        ),
      );
}

class Touchpad extends StatefulWidget {
  final WifiLink link;
  final double sensitivity;
  const Touchpad({super.key, required this.link, required this.sensitivity});
  @override
  State<Touchpad> createState() => _TouchpadState();
}

class _TouchpadState extends State<Touchpad> {
  final Map<int, Offset> _pos = {};
  final Map<int, Offset> _start = {};
  bool _moved = false;
  bool _dragging = false;
  int _maxPointers = 0;
  int _downMs = 0;
  int _lastTapMs = 0;

  int _now() => DateTime.now().millisecondsSinceEpoch;

  void _down(PointerDownEvent e) {
    final now = _now();
    if (_pos.isEmpty) {
      _moved = false;
      _maxPointers = 0;
      _downMs = now;
      if (now - _lastTapMs < 280) {
        _dragging = true;
        widget.link.mouseButton('left', true);
      }
    }
    _pos[e.pointer] = e.localPosition;
    _start[e.pointer] = e.localPosition;
    _maxPointers = math.max(_maxPointers, _pos.length);
  }

  void _move(PointerMoveEvent e) {
    final prev = _pos[e.pointer];
    if (prev == null) return;
    final d = e.localPosition - prev;
    _pos[e.pointer] = e.localPosition;
    final st = _start[e.pointer];
    if (st != null && (e.localPosition - st).distance > 6) _moved = true;
    if (_pos.length >= 2) {
      if (e.pointer == _pos.keys.first) {
        widget.link.scroll(-d.dx / 18, -d.dy / 18);
      }
    } else {
      final speed = d.distance;
      final gain = widget.sensitivity * (speed > 9 ? 1.7 : (speed > 4 ? 1.3 : 1.0));
      widget.link.move(d.dx * gain, d.dy * gain);
    }
  }

  void _up(PointerEvent e) {
    final now = _now();
    _pos.remove(e.pointer);
    _start.remove(e.pointer);
    if (_pos.isEmpty) {
      if (_dragging) {
        widget.link.mouseButton('left', false);
        _dragging = false;
        _lastTapMs = 0;
      } else if (!_moved && now - _downMs < 260) {
        if (_maxPointers >= 2) {
          widget.link.click('right');
        } else {
          widget.link.click('left');
          _lastTapMs = now;
        }
      }
    }
  }

  void _cancel(PointerCancelEvent e) {
    _pos.remove(e.pointer);
    _start.remove(e.pointer);
    if (_pos.isEmpty && _dragging) {
      widget.link.mouseButton('left', false);
      _dragging = false;
    }
  }

  @override
  Widget build(BuildContext context) => Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: _down,
        onPointerMove: _move,
        onPointerUp: _up,
        onPointerCancel: _cancel,
        child: const SizedBox.expand(
          child: Center(child: Icon(Icons.touch_app, size: 72, color: Color(0xff2d4577))),
        ),
      );
}

// ======================= کیبورد =======================

class KeyboardPage extends StatefulWidget {
  final WifiLink link;
  const KeyboardPage({super.key, required this.link});
  @override
  State<KeyboardPage> createState() => _KeyboardPageState();
}

class _KeyboardPageState extends State<KeyboardPage> {
  final TextEditingController ctl = TextEditingController();
  final FocusNode focus = FocusNode();
  String prev = '';

  @override
  void dispose() {
    ctl.dispose();
    focus.dispose();
    super.dispose();
  }

  void _changed(String v) {
    final old = prev;
    var i = 0;
    final m = math.min(old.length, v.length);
    while (i < m && old.codeUnitAt(i) == v.codeUnitAt(i)) {
      i++;
    }
    final removed = old.length - i;
    final added = v.substring(i);
    for (var k = 0; k < removed; k++) {
      widget.link.key('BACKSPACE');
    }
    if (added.isNotEmpty) widget.link.text(added);
    prev = v;
  }

  void _clear() {
    ctl.clear();
    prev = '';
  }

  void _enter() {
    widget.link.key('ENTER');
    _clear();
    focus.requestFocus();
  }

  Widget _k(String label, String key, {IconData? icon}) => FilledButton.tonal(
        onPressed: () => widget.link.key(key),
        style: FilledButton.styleFrom(minimumSize: const Size(56, 44), padding: const EdgeInsets.symmetric(horizontal: 12)),
        child: icon != null ? Icon(icon, size: 20) : Text(label),
      );

  Widget _group(String title, List<Widget> children) => Padding(
        padding: const EdgeInsets.only(top: 14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(fontSize: 12, color: Color(0xff9fb3d9))),
          const SizedBox(height: 6),
          Wrap(spacing: 8, runSpacing: 8, children: children),
        ]),
      );

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        TextField(
          controller: ctl,
          focusNode: focus,
          onChanged: _changed,
          onSubmitted: (_) => _enter(),
          autocorrect: false,
          enableSuggestions: false,
          minLines: 1,
          maxLines: 3,
          decoration: InputDecoration(
            labelText: 'اینجا تایپ کنید؛ هر حرف همان لحظه روی باکس نوشته می‌شود',
            border: const OutlineInputBorder(),
            suffixIcon: IconButton(onPressed: _clear, icon: const Icon(Icons.clear)),
          ),
        ),
        const SizedBox(height: 6),
        const Text(
          'قبل از تایپ، روی باکس در کادر متن (مثلاً نوار جستجو) کلیک کنید تا نشانگر داخل آن باشد. فارسی هم پشتیبانی می‌شود.',
          style: TextStyle(fontSize: 11, color: Color(0xff9fb3d9)),
        ),
        _group('کلیدهای اصلی', [
          _k('Enter', 'ENTER'),
          _k('Backspace', 'BACKSPACE'),
          _k('Delete', 'DELETE'),
          _k('Space', 'SPACE'),
          _k('Tab', 'TAB'),
          _k('Esc', 'ESC'),
        ]),
        _group('جهت‌ها', [
          _k('', 'LEFT', icon: Icons.arrow_back),
          _k('', 'UP', icon: Icons.arrow_upward),
          _k('', 'DOWN', icon: Icons.arrow_downward),
          _k('', 'RIGHT', icon: Icons.arrow_forward),
          _k('Home', 'LINE_START'),
          _k('End', 'LINE_END'),
          _k('PgUp', 'PAGEUP'),
          _k('PgDn', 'PAGEDOWN'),
        ]),
        _group('ویرایش', [
          _k('انتخاب همه', 'SELECT_ALL'),
          _k('کپی', 'COPY'),
          _k('کات', 'CUT'),
          _k('پیست', 'PASTE'),
        ]),
        _group('سیستم', [
          _k('بک', 'BACK'),
          _k('خانه', 'HOME'),
          _k('اخیر', 'RECENTS'),
          _k('اعلان‌ها', 'NOTIFICATIONS'),
        ]),
        _group('صدا و مدیا', [
          _k('', 'VOL_DOWN', icon: Icons.volume_down),
          _k('', 'VOL_UP', icon: Icons.volume_up),
          _k('', 'MUTE', icon: Icons.volume_off),
          _k('', 'PREV', icon: Icons.skip_previous),
          _k('', 'PLAY_PAUSE', icon: Icons.play_arrow),
          _k('', 'NEXT', icon: Icons.skip_next),
        ]),
      ]),
    );
  }
}

// ======================= دسته =======================

class GamepadPage extends StatefulWidget {
  final WifiLink link;
  const GamepadPage({super.key, required this.link});
  @override
  State<GamepadPage> createState() => _GamepadPageState();
}

class _GamepadPageState extends State<GamepadPage> {
  final Map<String, int> _lastStick = {};

  void _stick(String side, double x, double y) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final zero = x == 0 && y == 0;
    final last = _lastStick[side] ?? 0;
    if (zero || now - last >= 30) {
      _lastStick[side] = now;
      widget.link.stick(side, x, y);
    }
  }

  Widget _b(String label, String name, double x, double y, {double w = 56, double h = 56, double r = 16}) =>
      Positioned(
        left: x,
        top: y,
        child: PadButton(label: label, width: w, height: h, radius: r, onChange: (d) => widget.link.pad(name, d)),
      );

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      const Padding(
        padding: EdgeInsets.fromLTRB(12, 8, 12, 0),
        child: Text(
          'کنترل رابط با دسته: استیک چپ = نشانگر، استیک راست = اسکرول، ✕ = کلیک، ○ = بک، △ = خانه، □ = کلیک راست.\nبازی‌های واقعی (مثل ePSXe) در مرحله‌ی بعد با بلوتوث اضافه می‌شود.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 11, color: Color(0xff9fb3d9)),
        ),
      ),
      Expanded(
        child: FittedBox(
          fit: BoxFit.contain,
          child: SizedBox(
            width: 760,
            height: 340,
            child: Stack(children: [
              _b('L2', 'L2', 20, 8, w: 100, h: 44),
              _b('L1', 'L1', 130, 8, w: 100, h: 44),
              _b('R1', 'R1', 530, 8, w: 100, h: 44),
              _b('R2', 'R2', 640, 8, w: 100, h: 44),
              _b('▲', 'UP', 82, 70),
              _b('◀', 'LEFT', 26, 126),
              _b('▶', 'RIGHT', 138, 126),
              _b('▼', 'DOWN', 82, 182),
              _b('△', 'TRIANGLE', 622, 70, r: 28),
              _b('□', 'SQUARE', 566, 126, r: 28),
              _b('○', 'CIRCLE', 678, 126, r: 28),
              _b('✕', 'CROSS', 622, 182, r: 28),
              _b('SELECT', 'SELECT', 290, 120, w: 80, h: 36),
              _b('START', 'START', 390, 120, w: 80, h: 36),
              _b('HOME', 'MODE', 340, 70, w: 80, h: 36),
              Positioned(left: 190, top: 190, child: PadStick(onChanged: (x, y) => _stick('left', x, y))),
              Positioned(left: 450, top: 190, child: PadStick(onChanged: (x, y) => _stick('right', x, y))),
            ]),
          ),
        ),
      ),
    ]);
  }
}

class PadButton extends StatefulWidget {
  final String label;
  final double width;
  final double height;
  final double radius;
  final void Function(bool down) onChange;
  const PadButton({
    super.key,
    required this.label,
    required this.width,
    required this.height,
    required this.radius,
    required this.onChange,
  });
  @override
  State<PadButton> createState() => _PadButtonState();
}

class _PadButtonState extends State<PadButton> {
  bool down = false;

  void _set(bool v) {
    if (down == v) return;
    setState(() => down = v);
    widget.onChange(v);
    if (v) HapticFeedback.selectionClick();
  }

  @override
  Widget build(BuildContext context) => Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (_) => _set(true),
        onPointerUp: (_) => _set(false),
        onPointerCancel: (_) => _set(false),
        child: Container(
          width: widget.width,
          height: widget.height,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: down ? _accent : _btn,
            borderRadius: BorderRadius.circular(widget.radius),
            border: Border.all(color: _accent),
          ),
          child: Text(widget.label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ),
      );
}

class PadStick extends StatefulWidget {
  final void Function(double x, double y) onChanged;
  const PadStick({super.key, required this.onChanged});
  @override
  State<PadStick> createState() => _PadStickState();
}

class _PadStickState extends State<PadStick> {
  static const double size = 120;
  static const double maxR = 45;
  Offset knob = Offset.zero;

  void _update(Offset local) {
    var v = local - const Offset(size / 2, size / 2);
    if (v.distance > maxR) v = v / v.distance * maxR;
    setState(() => knob = v);
    widget.onChanged(v.dx / maxR, v.dy / maxR);
  }

  void _release() {
    setState(() => knob = Offset.zero);
    widget.onChanged(0, 0);
  }

  @override
  Widget build(BuildContext context) => Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (e) => _update(e.localPosition),
        onPointerMove: (e) => _update(e.localPosition),
        onPointerUp: (_) => _release(),
        onPointerCancel: (_) => _release(),
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _panel,
            border: Border.all(color: const Color(0xff2d4577), width: 2),
          ),
          child: Transform.translate(
            offset: knob,
            child: Center(
              child: Container(
                width: 50,
                height: 50,
                decoration: const BoxDecoration(shape: BoxShape.circle, color: _accent),
              ),
            ),
          ),
        ),
      );
}
