import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';

import 'bt.dart';

class FoundBox {
  final String ip;
  final String name;
  const FoundBox(this.ip, this.name);
}

/// اتصال Wi-Fi (TCP) به اپ گیرنده روی Android Box.
class WifiLink extends ChangeNotifier {
  static const int port = 39877;
  static const int discoveryPort = 39878;

  final BtHidLink bt = BtHidLink();

  WifiLink() {
    bt.addListener(notifyListeners);
  }

  @override
  void dispose() {
    bt.removeListener(notifyListeners);
    bt.dispose();
    super.dispose();
  }

  /// وصل بودن به باکس با Wi-Fi یا بلوتوث
  bool get live => connected || bt.connected;

  /// فرمان‌ها از بلوتوث بروند؟ (بلوتوث وصل است و یا Wi-Fi نیست، یا کاربر بلوتوث را ترجیح داده)
  bool get useBt => bt.connected && (!connected || bt.preferBt);

  Socket? _socket;
  StreamSubscription<String>? _sub;
  Completer<bool>? _hello;
  bool _wrongPin = false;
  Timer? _ping;
  Timer? _moveTimer;
  Timer? _scrollTimer;
  double _mx = 0, _my = 0, _sx = 0, _sy = 0;

  bool connected = false;
  bool connecting = false;
  bool accessibilityOn = true;
  String status = 'آماده اتصال';
  String boxName = '';

  // ---------- اتصال ----------
  Future<void> connect(String host, String pin) async {
    if (connecting) return;
    await disconnect(silent: true);
    connecting = true;
    status = 'در حال اتصال...';
    notifyListeners();
    try {
      final s = await Socket.connect(host.trim(), port,
          timeout: const Duration(seconds: 4));
      s.setOption(SocketOption.tcpNoDelay, true);
      _socket = s;
      _wrongPin = false;
      final hello = Completer<bool>();
      _hello = hello;
      _sub = s
          .cast<List<int>>()
          .transform(utf8.decoder)
          .transform(const LineSplitter())
          .listen(_onLine,
              onDone: _onClosed,
              onError: (Object _) => _onClosed(),
              cancelOnError: true);
      send({'type': 'hello', 'pin': pin.trim(), 'client': 'AbtinRemote', 'version': 2});
      final ok = await hello.future
          .timeout(const Duration(seconds: 4), onTimeout: () => false);
      if (ok) {
        connected = true;
        status = 'متصل به $boxName';
        _ping = Timer.periodic(
            const Duration(seconds: 10), (_) => send({'type': 'ping'}));
      } else {
        final wrong = _wrongPin;
        await disconnect(silent: true);
        status = wrong ? 'PIN اشتباه است' : 'گیرنده پاسخ نداد';
      }
    } catch (_) {
      await disconnect(silent: true);
      status = 'اتصال ناموفق؛ IP و شبکه را بررسی کنید';
    }
    connecting = false;
    notifyListeners();
  }

  Future<void> disconnect({bool silent = false}) async {
    _ping?.cancel();
    _moveTimer?.cancel();
    _scrollTimer?.cancel();
    _ping = null;
    _moveTimer = null;
    _scrollTimer = null;
    _mx = _my = _sx = _sy = 0;
    final s = _socket;
    final sub = _sub;
    _socket = null;
    _sub = null;
    await sub?.cancel();
    try {
      s?.destroy();
    } catch (_) {}
    final was = connected;
    connected = false;
    if (!silent) {
      if (was) status = 'اتصال قطع شد';
      notifyListeners();
    }
  }

  void _onClosed() {
    final was = connected;
    _ping?.cancel();
    _ping = null;
    _socket = null;
    _sub = null;
    connected = false;
    if (was) status = 'اتصال قطع شد';
    final h = _hello;
    if (h != null && !h.isCompleted) h.complete(false);
    notifyListeners();
  }

  void _onLine(String line) {
    try {
      final j = jsonDecode(line);
      if (j is Map && j['type'] == 'hello') {
        final h = _hello;
        if (j['ok'] == true) {
          boxName = (j['name'] ?? 'Android Box').toString();
          accessibilityOn = j['accessibility'] == true;
          if (h != null && !h.isCompleted) h.complete(true);
        } else {
          _wrongPin = true;
          if (h != null && !h.isCompleted) h.complete(false);
        }
      }
    } catch (_) {}
  }

  void send(Map<String, Object?> data) {
    final t = data['type'];
    if (t != 'hello' && t != 'ping' && useBt) {
      bt.handle(data);
      return;
    }
    final s = _socket;
    if (s == null) return;
    try {
      s.write('${jsonEncode(data)}\n');
    } catch (_) {
      _onClosed();
    }
  }

  // ---------- موس ----------
  double _r(double v) => (v * 10).roundToDouble() / 10;

  void move(double dx, double dy) {
    _mx += dx;
    _my += dy;
    _moveTimer ??= Timer(const Duration(milliseconds: 16), () {
      _moveTimer = null;
      if (_mx != 0 || _my != 0) {
        send({'type': 'move', 'dx': _r(_mx), 'dy': _r(_my)});
        _mx = 0;
        _my = 0;
      }
    });
  }

  /// dy مثبت = اسکرول به پایین. واحد: «ضربه‌ی چرخ موس»
  void scroll(double dx, double dy) {
    _sx += dx;
    _sy += dy;
    _scrollTimer ??= Timer(const Duration(milliseconds: 170), () {
      _scrollTimer = null;
      if (_sx != 0 || _sy != 0) {
        send({'type': 'scroll', 'dx': _r(_sx), 'dy': _r(_sy)});
        _sx = 0;
        _sy = 0;
      }
    });
  }

  void mouseButton(String button, bool down) =>
      send({'type': 'mouse', 'button': button, 'down': down});

  void click(String button) {
    mouseButton(button, true);
    mouseButton(button, false);
  }

  // ---------- کیبورد ----------
  void key(String name) => send({'type': 'key', 'key': name});
  void text(String value) {
    if (value.isNotEmpty) send({'type': 'text', 'text': value});
  }

  // ---------- دسته بازی (کنترل رابط) ----------
  void stick(String side, double x, double y) =>
      send({'type': 'stick', 'side': side, 'x': _r(x), 'y': _r(y)});
  void pad(String button, bool down) =>
      send({'type': 'pad', 'button': button, 'down': down});

  // ---------- پیدا کردن خودکار ----------
  static Future<List<FoundBox>> discover() async {
    final found = <String, String>{};
    RawDatagramSocket? sock;
    try {
      sock = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
      sock.broadcastEnabled = true;
      final s = sock;
      final sub = s.listen((RawSocketEvent e) {
        if (e == RawSocketEvent.read) {
          final d = s.receive();
          if (d == null) return;
          final t = utf8.decode(d.data, allowMalformed: true);
          if (t.startsWith('ABTIN_RECEIVER')) {
            final p = t.split(';');
            found[d.address.address] = p.length > 1 ? p[1] : 'Android Box';
          }
        }
      });
      final targets = <String>{'255.255.255.255'};
      try {
        for (final ni in await NetworkInterface.list(type: InternetAddressType.IPv4)) {
          for (final a in ni.addresses) {
            final o = a.address.split('.');
            if (o.length == 4) targets.add('${o[0]}.${o[1]}.${o[2]}.255');
          }
        }
      } catch (_) {}
      final msg = utf8.encode('ABTIN_DISCOVER');
      for (var i = 0; i < 3; i++) {
        for (final t in targets) {
          try {
            s.send(msg, InternetAddress(t), discoveryPort);
          } catch (_) {}
        }
        await Future<void>.delayed(const Duration(milliseconds: 500));
      }
      await Future<void>.delayed(const Duration(milliseconds: 600));
      await sub.cancel();
    } catch (_) {
    } finally {
      sock?.close();
    }
    return found.entries.map((e) => FoundBox(e.key, e.value)).toList();
  }
}
