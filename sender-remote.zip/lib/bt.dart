import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BtDevice {
  final String name;
  final String address;
  const BtDevice(this.name, this.address);
}

/// گوشی را به‌صورت کیبورد + موس + کنترل رسانه + دسته‌ی بازی بلوتوث (HID) به باکس/تی‌وی معرفی می‌کند.
/// فرمان‌هایی که برای Wi-Fi ساخته می‌شوند (move, scroll, mouse, key, text, stick, pad) اینجا
/// به گزارش HID تبدیل می‌شوند. روی باکس هیچ اپ گیرنده‌ای لازم نیست. (Android 9+ روی گوشی)
class BtHidLink extends ChangeNotifier {
  static const MethodChannel _ch = MethodChannel('abtin/bt');

  bool supported = false;
  bool ready = false;
  bool connected = false;
  bool preferBt = false;
  String hostName = '';
  String status = 'بلوتوث آماده نیست';
  List<BtDevice> bonded = const [];
  List<BtDevice> found = const [];
  bool scanning = false;
  String lastAddress = '';

  BtHidLink() {
    _ch.setMethodCallHandler(_onCall);
    _boot();
  }

  Future<void> _boot() async {
    try {
      supported = (await _ch.invokeMethod<bool>('supported')) ?? false;
    } catch (_) {
      supported = false;
    }
    try {
      final p = await SharedPreferences.getInstance();
      preferBt = p.getBool('bt_prefer') ?? false;
      lastAddress = p.getString('bt_last') ?? '';
    } catch (_) {}
    notifyListeners();
    // قبلاً با بلوتوث وصل شده بودید: خودکار آماده شود و دوباره وصل شود
    if (supported && lastAddress.isNotEmpty) {
      await init();
    }
  }

  Future<dynamic> _onCall(MethodCall c) async {
    if (c.method == 'state') {
      final a = c.arguments;
      if (a is Map) {
        ready = a['registered'] == true;
        connected = a['connected'] == true;
        hostName = (a['name'] ?? '').toString();
        final msg = (a['msg'] ?? '').toString();
        status = connected ? 'متصل به $hostName' : (msg.isNotEmpty ? msg : (ready ? 'آماده؛ هنوز وصل نیست' : 'بلوتوث آماده نیست'));
        if (connected) {
          final addr = (a['address'] ?? '').toString();
          if (addr.isNotEmpty) _saveLast(addr);
        }
        notifyListeners();
      }
    }
    if (c.method == 'found') {
      final a = c.arguments;
      if (a is Map) {
        final addr = (a['address'] ?? '').toString();
        final name = (a['name'] ?? '').toString();
        if (addr.isNotEmpty && !found.any((d) => d.address == addr)) {
          found = [...found, BtDevice(name.isEmpty ? addr : name, addr)];
          notifyListeners();
        }
      }
    } else if (c.method == 'scanDone') {
      scanning = false;
      notifyListeners();
    } else if (c.method == 'bondChanged') {
      await refreshBonded();
    }
    return null;
  }

  Future<void> scan() async {
    found = const [];
    scanning = true;
    status = 'در حال جستجوی دستگاه‌ها... (روی تی‌وی صفحه‌ی بلوتوث را باز نگه دارید)';
    notifyListeners();
    var ok = false;
    try {
      ok = (await _ch.invokeMethod<bool>('scan')) ?? false;
    } catch (_) {}
    if (!ok) {
      scanning = false;
      status = 'جستجو ممکن نشد؛ بلوتوث را روشن کنید و اجازه‌ی «دستگاه‌های اطراف» را بدهید';
      notifyListeners();
    }
  }

  Future<void> stopScan() async {
    try {
      await _ch.invokeMethod<bool>('stopScan');
    } catch (_) {}
    scanning = false;
    notifyListeners();
  }

  /// جفت‌سازی + اتصال HID، همه داخل اپ
  Future<void> pair(String address) async {
    if (!ready) {
      status = 'اول «آماده‌سازی بلوتوث» را بزنید';
      notifyListeners();
      return;
    }
    status = 'در حال جفت‌سازی... اگر روی تی‌وی یا گوشی کد/تأیید آمد، تأیید کنید';
    notifyListeners();
    var ok = false;
    try {
      ok = (await _ch.invokeMethod<bool>('pair', {'address': address})) ?? false;
    } catch (_) {}
    if (!ok) {
      status = 'جفت‌سازی شروع نشد؛ تی‌وی باید در صفحه‌ی بلوتوث (قابل‌مشاهده) باشد';
      notifyListeners();
    }
  }

  Future<void> unpair(String address) async {
    try {
      await _ch.invokeMethod<bool>('unpair', {'address': address});
    } catch (_) {}
    await Future<void>.delayed(const Duration(milliseconds: 600));
    await refreshBonded();
  }

  Future<void> _saveLast(String addr) async {
    lastAddress = addr;
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('bt_last', addr);
    } catch (_) {}
  }

  Future<void> setPreferBt(bool v) async {
    preferBt = v;
    notifyListeners();
    try {
      final p = await SharedPreferences.getInstance();
      await p.setBool('bt_prefer', v);
    } catch (_) {}
  }

  /// ثبت گوشی به‌عنوان دستگاه HID (اجازه‌ی بلوتوث را هم می‌پرسد).
  Future<bool> init() async {
    if (!supported) return false;
    bool ok = false;
    try {
      ok = (await _ch.invokeMethod<bool>('init')) ?? false;
    } catch (_) {}
    if (!ok) {
      String d = '';
      try {
        d = (await _ch.invokeMethod<String>('diag')) ?? '';
      } catch (_) {}
      status = 'ثبت بلوتوث ناموفق بود (اجازه‌ی «دستگاه‌های اطراف» را بدهید و بلوتوث را روشن کنید)\n$d';
      ready = false;
      notifyListeners();
      return false;
    }
    ready = true;
    if (!connected) status = 'آماده؛ هنوز وصل نیست';
    notifyListeners();
    await refreshBonded();
    if (!connected && lastAddress.isNotEmpty) {
      for (final d in bonded) {
        if (d.address == lastAddress) {
          await connect(d.address);
          break;
        }
      }
    }
    return true;
  }

  Future<void> refreshBonded() async {
    try {
      final r = await _ch.invokeMethod<List<Object?>>('bonded');
      final out = <BtDevice>[];
      for (final e in r ?? const <Object?>[]) {
        if (e is Map) out.add(BtDevice((e['name'] ?? '').toString(), (e['address'] ?? '').toString()));
      }
      bonded = out;
    } catch (_) {
      bonded = const [];
    }
    notifyListeners();
  }

  Future<void> connect(String address) async {
    status = 'در حال اتصال...';
    notifyListeners();
    try {
      await _ch.invokeMethod<bool>('connect', {'address': address});
    } catch (_) {
      status = 'اتصال ناموفق';
      notifyListeners();
    }
    // اگر بعد از چند ثانیه وصل نشد، راه حل را نشان بده
    Future<void>.delayed(const Duration(seconds: 8), () {
      if (!connected) {
        status = 'وصل نشد. جفت‌سازی قدیمی احتمالاً قبل از ثبت HID بوده: آن را روی گوشی و باکس حذف (Forget) کنید و طبق مراحل ۱ تا ۳ از نو انجام دهید.';
        notifyListeners();
      }
    });
  }

  Future<void> disconnect() async {
    try {
      await _ch.invokeMethod<bool>('disconnect');
    } catch (_) {}
  }

  Future<void> makeDiscoverable() async {
    try {
      await _ch.invokeMethod<bool>('discoverable');
    } catch (_) {}
  }

  Future<void> openSettings() async {
    try {
      await _ch.invokeMethod<bool>('settings');
    } catch (_) {}
  }

  // ======================= ارسال گزارش HID =======================
  Future<void> _q = Future<void>.value();

  void _enqueue(Future<void> Function() f) {
    _q = _q.then((_) => f()).catchError((Object _) {});
  }

  Future<void> _report(int id, List<int> data) async {
    try {
      await _ch.invokeMethod<bool>('report', {'id': id, 'data': Uint8List.fromList(data)});
    } catch (_) {}
  }

  int _mb = 0; // دکمه‌های موس
  double _rx = 0, _ry = 0, _sy = 0;
  int _gb = 0; // دکمه‌های دسته (بیت i = دکمه‌ی i+1)
  final Set<String> _dirs = {};
  final List<int> _ax = [0, 0, 0, 0];

  static double _n(Object? v) => v is num ? v.toDouble() : 0;

  /// نقطه‌ی ورود: همان نقشه‌های JSON ای که برای Wi-Fi ساخته می‌شود.
  void handle(Map<String, Object?> d) {
    switch (d['type']) {
      case 'move':
        _move(_n(d['dx']), _n(d['dy']));
      case 'scroll':
        _scroll(_n(d['dy']));
      case 'mouse':
        _mouse((d['button'] ?? 'left').toString(), d['down'] == true);
      case 'key':
        _keyByName((d['key'] ?? '').toString());
      case 'text':
        _typeText((d['text'] ?? '').toString());
      case 'stick':
        _stick((d['side'] ?? 'left').toString(), _n(d['x']), _n(d['y']));
      case 'pad':
        _pad((d['button'] ?? '').toString(), d['down'] != false);
    }
  }

  void _move(double dx, double dy) {
    _rx += dx;
    _ry += dy;
    var ix = _rx.truncate();
    var iy = _ry.truncate();
    _rx -= ix;
    _ry -= iy;
    while (ix != 0 || iy != 0) {
      final cx = ix.clamp(-127, 127).toInt();
      final cy = iy.clamp(-127, 127).toInt();
      ix -= cx;
      iy -= cy;
      final b = _mb;
      _enqueue(() => _report(2, [b, cx & 0xff, cy & 0xff, 0]));
    }
  }

  void _scroll(double dy) {
    _sy += dy;
    final n = _sy.truncate();
    if (n == 0) return;
    _sy -= n;
    final w = (-n).clamp(-127, 127).toInt();
    final b = _mb;
    _enqueue(() => _report(2, [b, 0, 0, w & 0xff]));
  }

  void _mouse(String button, bool down) {
    final bit = switch (button) { 'right' => 2, 'middle' => 4, _ => 1 };
    _mb = down ? (_mb | bit) : (_mb & ~bit);
    final b = _mb;
    _enqueue(() => _report(2, [b, 0, 0, 0]));
  }

  // ---------- کیبورد ----------
  void _tapKey(int mod, int usage) {
    _enqueue(() async {
      await _report(1, [mod, 0, usage, 0, 0, 0, 0, 0]);
      await Future<void>.delayed(const Duration(milliseconds: 12));
      await _report(1, [0, 0, 0, 0, 0, 0, 0, 0]);
      await Future<void>.delayed(const Duration(milliseconds: 8));
    });
  }

  void _tapConsumer(int usage) {
    _enqueue(() async {
      await _report(3, [usage & 0xff, (usage >> 8) & 0xff]);
      await Future<void>.delayed(const Duration(milliseconds: 30));
      await _report(3, [0, 0]);
    });
  }

  static const Map<String, int> _kb = {
    'ENTER': 0x28,
    'ESC': 0x29,
    'BACKSPACE': 0x2A,
    'TAB': 0x2B,
    'SPACE': 0x2C,
    'DELETE': 0x4C,
    'RIGHT': 0x4F,
    'LEFT': 0x50,
    'DOWN': 0x51,
    'UP': 0x52,
    'PAGEUP': 0x4B,
    'PAGEDOWN': 0x4E,
    'LINE_START': 0x4A,
    'LINE_END': 0x4D,
  };

  // صفحه‌ی Consumer: Home، Back، صدا، مدیا، کانال، پاور، منو، اطلاعات ...
  static const Map<String, int> _cons = {
    'HOME': 0x223,
    'BACK': 0x224,
    'RECENTS': 0x40, // منو
    'VOL_UP': 0xE9,
    'VOL_DOWN': 0xEA,
    'MUTE': 0xE2,
    'PLAY_PAUSE': 0xCD,
    'NEXT': 0xB5,
    'PREV': 0xB6,
    'CH_UP': 0x9C,
    'CH_DOWN': 0x9D,
    'POWER': 0x30,
    'INFO': 0x1BD,
    'EPG': 0x8D,
  };

  // ترکیب‌های Ctrl
  static const Map<String, int> _ctrl = {'SELECT_ALL': 0x04, 'COPY': 0x06, 'PASTE': 0x19, 'CUT': 0x1B};

  void _keyByName(String name) {
    final k = _kb[name];
    if (k != null) {
      _tapKey(0, k);
      return;
    }
    final c = _cons[name];
    if (c != null) {
      _tapConsumer(c);
      return;
    }
    final t = _ctrl[name];
    if (t != null) {
      _tapKey(0x01, t);
      return;
    }
    if (name.length == 1) {
      final u = _ascii(name);
      if (u != null) _tapKey(u.$1, u.$2);
    }
  }

  void _typeText(String t) {
    for (final r in t.runes) {
      final ch = String.fromCharCode(r);
      final u = _ascii(ch);
      if (u != null) _tapKey(u.$1, u.$2); // حروف غیر لاتین (مثل فارسی) روی HID قابل ارسال نیست
    }
  }

  /// (modifier, usage) برای کاراکترهای ASCII با چیدمان US. null = پشتیبانی نمی‌شود.
  static (int, int)? _ascii(String ch) {
    if (ch.isEmpty) return null;
    final c = ch.codeUnitAt(0);
    if (c >= 0x61 && c <= 0x7A) return (0, 0x04 + (c - 0x61));
    if (c >= 0x41 && c <= 0x5A) return (0x02, 0x04 + (c - 0x41));
    if (c >= 0x31 && c <= 0x39) return (0, 0x1E + (c - 0x31));
    if (c == 0x30) return (0, 0x27);
    const plain = {
      ' ': 0x2C,
      '-': 0x2D,
      '=': 0x2E,
      '[': 0x2F,
      ']': 0x30,
      '\\': 0x31,
      ';': 0x33,
      "'": 0x34,
      '`': 0x35,
      ',': 0x36,
      '.': 0x37,
      '/': 0x38,
      '\n': 0x28,
    };
    const shifted = {
      '!': 0x1E,
      '@': 0x1F,
      '#': 0x20,
      '\$': 0x21,
      '%': 0x22,
      '^': 0x23,
      '&': 0x24,
      '*': 0x25,
      '(': 0x26,
      ')': 0x27,
      '_': 0x2D,
      '+': 0x2E,
      '{': 0x2F,
      '}': 0x30,
      '|': 0x31,
      ':': 0x33,
      '"': 0x34,
      '~': 0x35,
      '<': 0x36,
      '>': 0x37,
      '?': 0x38,
    };
    final p = plain[ch];
    if (p != null) return (0, p);
    final s = shifted[ch];
    if (s != null) return (0x02, s);
    return null;
  }

  // ---------- دسته‌ی بازی ----------
  static const Map<String, int> _padBit = {
    'CROSS': 0, // A
    'CIRCLE': 1, // B
    'SQUARE': 3, // X
    'TRIANGLE': 4, // Y
    'L1': 6,
    'R1': 7,
    'L2': 8,
    'R2': 9,
    'SELECT': 10,
    'START': 11,
    'MODE': 12,
  };

  void _sendPad() {
    final u = _dirs.contains('UP');
    final d = _dirs.contains('DOWN');
    final l = _dirs.contains('LEFT');
    final r = _dirs.contains('RIGHT');
    int hat = 0;
    if (u && r) {
      hat = 2;
    } else if (r && d) {
      hat = 4;
    } else if (d && l) {
      hat = 6;
    } else if (l && u) {
      hat = 8;
    } else if (u) {
      hat = 1;
    } else if (r) {
      hat = 3;
    } else if (d) {
      hat = 5;
    } else if (l) {
      hat = 7;
    }
    final gb = _gb;
    final ax = List<int>.from(_ax);
    _enqueue(() => _report(4, [gb & 0xff, (gb >> 8) & 0xff, hat, ax[0] & 0xff, ax[1] & 0xff, ax[2] & 0xff, ax[3] & 0xff]));
  }

  void _pad(String name, bool down) {
    final n = name.toUpperCase();
    if (n == 'UP' || n == 'DOWN' || n == 'LEFT' || n == 'RIGHT') {
      if (down) {
        _dirs.add(n);
      } else {
        _dirs.remove(n);
      }
    } else {
      final bit = _padBit[n];
      if (bit == null) return;
      _gb = down ? (_gb | (1 << bit)) : (_gb & ~(1 << bit));
    }
    _sendPad();
  }

  void _stick(String side, double x, double y) {
    int c(double v) => (v.clamp(-1.0, 1.0) * 127).round();
    if (side == 'right') {
      _ax[2] = c(x);
      _ax[3] = c(y);
    } else {
      _ax[0] = c(x);
      _ax[1] = c(y);
    }
    _sendPad();
  }
}
