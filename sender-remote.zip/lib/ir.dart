import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// برای نمایش پیام (مثلاً «برای این دکمه کد IR ذخیره نشده») از هرجا.
final GlobalKey<ScaffoldMessengerState> irMessengerKey = GlobalKey<ScaffoldMessengerState>();

/// دکمه‌هایی که می‌شود برایشان کد IR ذخیره کرد (نام‌ها همان کلیدهای Wi-Fi هستند).
const List<MapEntry<String, String>> kIrButtons = [
  MapEntry('POWER', 'پاور (خاموش / اصلی)'),
  MapEntry('POWER_ON', 'روشن‌کردن (Wake) — نگه‌داشتن پاور'),
  MapEntry('MUTE', 'بی‌صدا'),
  MapEntry('HOME', 'خانه'),
  MapEntry('BACK', 'برگشت'),
  MapEntry('RECENTS', 'منو'),
  MapEntry('QUICK_SETTINGS', 'تنظیمات'),
  MapEntry('NOTIFICATIONS', 'ورودی / TV'),
  MapEntry('UP', 'بالا'),
  MapEntry('DOWN', 'پایین'),
  MapEntry('LEFT', 'چپ'),
  MapEntry('RIGHT', 'راست'),
  MapEntry('ENTER', 'OK'),
  MapEntry('VOL_UP', 'صدا +'),
  MapEntry('VOL_DOWN', 'صدا −'),
  MapEntry('CH_UP', 'کانال +'),
  MapEntry('CH_DOWN', 'کانال −'),
  MapEntry('PLAY_PAUSE', 'پخش / مکث'),
  MapEntry('PREV', 'قبلی'),
  MapEntry('NEXT', 'بعدی'),
  MapEntry('MIC', 'میکروفون'),
  MapEntry('RED', 'قرمز'),
  MapEntry('GREEN', 'سبز'),
  MapEntry('YELLOW', 'زرد'),
  MapEntry('BLUE', 'آبی'),
  MapEntry('INFO', 'INFO'),
  MapEntry('TEXT', 'TEXT'),
  MapEntry('EPG', 'EPG'),
  MapEntry('BACKSPACE', 'DEL'),
  MapEntry('0', '0'),
  MapEntry('1', '1'),
  MapEntry('2', '2'),
  MapEntry('3', '3'),
  MapEntry('4', '4'),
  MapEntry('5', '5'),
  MapEntry('6', '6'),
  MapEntry('7', '7'),
  MapEntry('8', '8'),
  MapEntry('9', '9'),
];

String irButtonLabel(String key) {
  for (final e in kIrButtons) {
    if (e.key == key) return e.value;
  }
  return key;
}

/// یک کد IR. proto: 'nec' (آدرس ۸بیتی + معکوس) یا 'necx' (آدرس ۱۶بیتی).
class IrCode {
  final String proto;
  final int addr;
  final int cmd;
  const IrCode(this.proto, this.addr, this.cmd);

  Map<String, Object> toJson() => {'p': proto, 'a': addr, 'c': cmd};

  static IrCode? fromJson(Object? j) {
    if (j is! Map) return null;
    final p = j['p'];
    final a = j['a'];
    final c = j['c'];
    if (p is! String || a is! int || c is! int) return null;
    return IrCode(p, a, c);
  }

  String get label {
    final a = addr.toRadixString(16).toUpperCase().padLeft(proto == 'necx' ? 4 : 2, '0');
    final c = cmd.toRadixString(16).toUpperCase().padLeft(2, '0');
    return '${proto == 'necx' ? 'NECx' : 'NEC'}  A=0x$a  C=0x$c';
  }

  /// الگوی زمانی (میکروثانیه): روشن، خاموش، روشن، ...
  List<int> pattern() {
    final bytes = <int>[];
    if (proto == 'necx') {
      bytes.addAll([addr & 0xff, (addr >> 8) & 0xff]);
    } else {
      bytes.addAll([addr & 0xff, (~addr) & 0xff]);
    }
    bytes.addAll([cmd & 0xff, (~cmd) & 0xff]);
    final p = <int>[9000, 4500];
    for (final b in bytes) {
      for (var i = 0; i < 8; i++) {
        p.add(560);
        p.add(((b >> i) & 1) == 1 ? 1690 : 560);
      }
    }
    p.add(560);
    p.add(40000); // فاصله‌ی پایانی (الگو زوج می‌ماند)
    return p;
  }
}

/// یک پروفایل دستگاه (مثلاً «تی‌وی اتاق»، «Android Box») با کدهای IR خودش.
class IrProfile {
  String name;

  /// true = دستگاه Wi-Fi ندارد (مثلاً تی‌وی معمولی)؛ همیشه با IR ارسال شود.
  bool irOnly;
  final Map<String, IrCode> codes;
  IrProfile(this.name, {this.irOnly = false, Map<String, IrCode>? codes}) : codes = codes ?? {};

  Map<String, Object> toJson() => {
        'n': name,
        'o': irOnly,
        'k': {for (final e in codes.entries) e.key: e.value.toJson()},
      };

  static IrProfile? fromJson(Object? j) {
    if (j is! Map) return null;
    final n = j['n'];
    if (n is! String) return null;
    final pr = IrProfile(n, irOnly: j['o'] == true);
    final k = j['k'];
    if (k is Map) {
      for (final e in k.entries) {
        final c = IrCode.fromJson(e.value);
        if (c != null) pr.codes[e.key.toString()] = c;
      }
    }
    return pr;
  }
}

/// کنترل ارسال IR + ذخیره‌ی کدها + انتخاب حالت (خودکار / فقط Wi-Fi / فقط IR).
class IrController extends ChangeNotifier {
  static const MethodChannel _ch = MethodChannel('abtin/ir');

  bool hasEmitter = false;

  /// 0 = خودکار (Wi-Fi وصل بود Wi-Fi، وگرنه IR) ، 1 = فقط Wi-Fi ، 2 = فقط IR
  int mode = 0;

  /// پاور (در صورت داشتن کد) همیشه با IR فرستاده شود تا از حالت خاموش هم روشن کند.
  bool powerViaIr = true;

  // وضعیت اسکن (تا با بستن پنجره از صفر شروع نشود)
  String scanTarget = 'POWER';
  String scanProto = 'nec';
  bool scanCommon = true;
  double scanInterval = 350;
  int scanIdx = 0;
  String scanAddr = '00';
  String scanCmd = '00';

  final List<IrProfile> profiles = [];
  int activeIdx = 0;
  IrProfile get active => profiles[activeIdx];
  Map<String, IrCode> get codes => active.codes;
  DateTime _lastToast = DateTime.fromMillisecondsSinceEpoch(0);

  IrController() {
    _load();
  }

  Future<void> _load() async {
    try {
      hasEmitter = (await _ch.invokeMethod<bool>('hasIr')) ?? false;
    } catch (_) {
      hasEmitter = false;
    }
    try {
      final p = await SharedPreferences.getInstance();
      mode = p.getInt('ir_mode') ?? 0;
      powerViaIr = p.getBool('ir_power') ?? true;
      scanTarget = p.getString('scan_target') ?? 'POWER';
      scanProto = p.getString('scan_proto') ?? 'nec';
      scanCommon = p.getBool('scan_common') ?? true;
      scanInterval = p.getDouble('scan_interval') ?? 350;
      scanIdx = p.getInt('scan_idx') ?? 0;
      scanAddr = p.getString('scan_addr') ?? '00';
      scanCmd = p.getString('scan_cmd') ?? '00';
      final rawP = p.getString('ir_profiles');
      if (rawP != null) {
        final j = jsonDecode(rawP);
        if (j is List) {
          for (final e in j) {
            final pr = IrProfile.fromJson(e);
            if (pr != null) profiles.add(pr);
          }
        }
      } else {
        // مهاجرت از نسخه‌ی ۲.۷.۰ (یک مجموعه کد)
        final raw = p.getString('ir_codes');
        final pr = IrProfile('Android Box');
        if (raw != null) {
          final j = jsonDecode(raw);
          if (j is Map) {
            for (final e in j.entries) {
              final c = IrCode.fromJson(e.value);
              if (c != null) pr.codes[e.key.toString()] = c;
            }
          }
        }
        profiles.add(pr);
      }
      activeIdx = p.getInt('ir_active') ?? 0;
    } catch (_) {}
    if (profiles.isEmpty) profiles.add(IrProfile('Android Box'));
    if (activeIdx < 0 || activeIdx >= profiles.length) activeIdx = 0;
    notifyListeners();
  }

  Future<void> _save() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt('ir_mode', mode);
      await p.setBool('ir_power', powerViaIr);
      await p.setString('ir_profiles', jsonEncode([for (final pr in profiles) pr.toJson()]));
      await p.setInt('ir_active', activeIdx);
    } catch (_) {}
  }

  Future<void> saveScan() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('scan_target', scanTarget);
      await p.setString('scan_proto', scanProto);
      await p.setBool('scan_common', scanCommon);
      await p.setDouble('scan_interval', scanInterval);
      await p.setInt('scan_idx', scanIdx);
      await p.setString('scan_addr', scanAddr);
      await p.setString('scan_cmd', scanCmd);
    } catch (_) {}
  }

  void setMode(int m) {
    mode = m;
    notifyListeners();
    _save();
  }

  void setPowerViaIr(bool v) {
    powerViaIr = v;
    notifyListeners();
    _save();
  }

  void selectProfile(int i) {
    if (i < 0 || i >= profiles.length) return;
    activeIdx = i;
    notifyListeners();
    _save();
  }

  void addProfile(String name, {bool irOnly = false}) {
    final n = name.trim().isEmpty ? 'دستگاه ${profiles.length + 1}' : name.trim();
    profiles.add(IrProfile(n, irOnly: irOnly));
    activeIdx = profiles.length - 1;
    notifyListeners();
    _save();
  }

  void renameActive(String name) {
    final n = name.trim();
    if (n.isEmpty) return;
    active.name = n;
    notifyListeners();
    _save();
  }

  void setActiveIrOnly(bool v) {
    active.irOnly = v;
    notifyListeners();
    _save();
  }

  /// حذف پروفایل فعال (حداقل یکی می‌ماند).
  void deleteActive() {
    if (profiles.length <= 1) return;
    profiles.removeAt(activeIdx);
    activeIdx = 0;
    notifyListeners();
    _save();
  }

  void setCode(String key, IrCode c) {
    codes[key] = c;
    notifyListeners();
    _save();
  }

  void removeCode(String key) {
    codes.remove(key);
    notifyListeners();
    _save();
  }

  void clearCodes() {
    codes.clear();
    notifyListeners();
    _save();
  }

  /// این کلید با IR فرستاده شود یا Wi-Fi؟
  bool useIrFor(String key, bool wifiConnected) {
    if (!hasEmitter) return false;
    if (active.irOnly) return true;
    if (key == 'POWER' && powerViaIr && codes.containsKey('POWER') && mode != 1) return true;
    if (mode == 1) return false;
    if (mode == 2) return true;
    return !wifiConnected;
  }

  Future<bool> sendCode(IrCode c) async {
    try {
      final ok = await _ch.invokeMethod<bool>('transmit', {'freq': 38000, 'pattern': c.pattern()});
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  /// ارسال کد ذخیره‌شده‌ی یک دکمه. اگر کدی نباشد پیام می‌دهد.
  Future<void> sendKey(String key) async {
    final c = codes[key];
    if (c == null) {
      _toast('برای «${irButtonLabel(key)}» هنوز کد IR ذخیره نشده');
      return;
    }
    final ok = await sendCode(c);
    if (!ok) _toast('ارسال IR انجام نشد؛ گوشی فرستنده‌ی IR ندارد؟');
  }

  void _toast(String msg) {
    final now = DateTime.now();
    if (now.difference(_lastToast).inMilliseconds < 1500) return;
    _lastToast = now;
    irMessengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));
  }
}
