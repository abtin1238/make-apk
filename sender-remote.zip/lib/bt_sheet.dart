import 'package:flutter/material.dart';

import 'bt.dart';
import 'theme.dart';

Future<void> showBtDialog(BuildContext context, BtHidLink bt) {
  return showDialog<void>(
    context: context,
    builder: (_) => Dialog(
      backgroundColor: const Color(0xff0c1124),
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: kBlue.withOpacity(0.6)),
      ),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 520),
        child: Padding(padding: const EdgeInsets.all(14), child: _BtPanel(bt: bt)),
      ),
    ),
  );
}

class _BtPanel extends StatefulWidget {
  final BtHidLink bt;
  const _BtPanel({required this.bt});
  @override
  State<_BtPanel> createState() => _BtPanelState();
}

class _BtPanelState extends State<_BtPanel> {
  bool busy = false;

  BtHidLink get bt => widget.bt;

  Future<void> _prepare() async {
    setState(() => busy = true);
    await bt.init();
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: bt,
      builder: (context, _) {
        return SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('اتصال بلوتوث', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(
                bt.status,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: bt.connected ? const Color(0xff3dff8f) : kHint),
              ),
              const SizedBox(height: 8),
              if (!bt.supported)
                const Text(
                  'این گوشی از حالت «دستگاه HID بلوتوث» پشتیبانی نمی‌کند (نیاز به Android 9 یا بالاتر و بلوتوث روشن).',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xffffa23c), fontSize: 12),
                )
              else ...[
                const Text(
                  'گوشی خودش را به‌صورت کیبورد + موس + ریموت + دسته‌ی بازی بلوتوث نشان می‌دهد؛ روی باکس/تی‌وی اپ گیرنده لازم نیست.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: kHint),
                ),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: busy ? null : _prepare,
                  icon: const Icon(Icons.bluetooth),
                  label: Text(bt.ready ? 'آماده است (دوباره ثبت)' : '۱) آماده‌سازی بلوتوث'),
                ),
                const SizedBox(height: 6),
                const Text(
                  '۲) روی باکس/تی‌وی: تنظیمات ← بلوتوث / Remotes & Accessories ← افزودن دستگاه. گوشی را قابل‌مشاهده کنید تا باکس پیدایش کند و جفت شوید.',
                  style: TextStyle(fontSize: 12, color: kHint),
                ),
                const SizedBox(height: 6),
                Wrap(spacing: 8, runSpacing: 4, alignment: WrapAlignment.center, children: [
                  OutlinedButton.icon(
                    onPressed: bt.makeDiscoverable,
                    icon: const Icon(Icons.visibility, size: 18),
                    label: const Text('قابل‌مشاهده (۲ دقیقه)'),
                  ),
                  OutlinedButton.icon(
                    onPressed: bt.openSettings,
                    icon: const Icon(Icons.settings_bluetooth, size: 18),
                    label: const Text('تنظیمات بلوتوث'),
                  ),
                ]),
                const Divider(height: 18),
                Row(children: [
                  const Expanded(
                    child: Text('۳) دستگاه‌های جفت‌شده (روی باکس بزنید)', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  ),
                  IconButton(onPressed: bt.refreshBonded, icon: const Icon(Icons.refresh), tooltip: 'تازه‌سازی'),
                ]),
                if (bt.bonded.isEmpty)
                  const Text('دستگاه جفت‌شده‌ای نیست. اول ۱ و ۲ را انجام دهید و تازه‌سازی کنید.',
                      style: TextStyle(fontSize: 12, color: kHint))
                else
                  for (final d in bt.bonded)
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.bluetooth),
                      title: Text(d.name),
                      subtitle: Text(d.address, style: const TextStyle(fontSize: 11)),
                      trailing: bt.connected && bt.hostName == d.name
                          ? const Icon(Icons.check_circle, color: Color(0xff3dff8f))
                          : null,
                      onTap: bt.ready ? () => bt.connect(d.address) : null,
                    ),
                if (bt.connected)
                  TextButton(onPressed: bt.disconnect, child: const Text('قطع اتصال بلوتوث')),
                SwitchListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: const Text('اگر Wi-Fi هم وصل بود، بلوتوث استفاده شود', style: TextStyle(fontSize: 13)),
                  value: bt.preferBt,
                  onChanged: bt.setPreferBt,
                ),
                const Text(
                  'توجه: با بلوتوث فقط حروف انگلیسی تایپ می‌شود (تایپ فارسی فقط با Wi-Fi). دکمه‌های قرمز/سبز/زرد/آبی، TEXT، میکروفون، Quick Settings و منوی خاموش/ری‌استارت روی بلوتوث فرمان ندارند. دسته‌ی بازی روی باکس یک دسته‌ی واقعی دیده می‌شود.',
                  style: TextStyle(fontSize: 11, color: kHint),
                ),
              ],
              const SizedBox(height: 6),
              TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('بستن')),
            ],
          ),
        );
      },
    );
  }
}
