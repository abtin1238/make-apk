PRoot 5.5.0 + Abtin patch (arm64, static) - build kit

1. Create a new GitHub repo and push this folder as-is (keep the .github and tools folders).
2. Actions -> "Build PRoot from source ZIP (arm64, static)" -> Run workflow
   (zip_path stays tools/proot/v5_5_0_source_code.zip).
3. Download artifact "proot-arm64-static": libproot.so (+ libproot-loader.so).
4. Send me both files (or put them in android/app/src/main/jniLibs/arm64-v8a/).

The patch (tools/proot/abtin-arm64-void.patch, src/tracee/reg.c): proot no longer gives
syscall number -1 to the kernel (Android seccomp -> SIGSYS in PROOT_NO_SECCOMP mode);
it writes getpid (172) instead. The build fails if the patch does not apply.
