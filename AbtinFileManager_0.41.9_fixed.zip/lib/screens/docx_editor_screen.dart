import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import 'package:xml/xml.dart';
import '../core/l10n.dart';
import '../core/layouts.dart' show tr2;
import '../widgets/office_chrome.dart';
import '../services/file_ops.dart';
import '../widgets/ui.dart';

/// Paragraph-level formatting (alignment, list). Character formatting lives in [_CF].
class _Fmt {
  String? align; // left | center | right | both (as seen on screen)
  int list; // 0 none, 1 bullet, 2 numbered
  _Fmt({this.align, this.list = 0});
  _Fmt copy() => _Fmt(align: align, list: list);
  bool eq(_Fmt o) => align == o.align && list == o.list;
}

/// Character (run-level) formatting of one UTF-16 unit of a paragraph.
class _CF {
  final bool b, i, u;
  final double? size; // points
  final Color? color;
  final String? link; // external URL, or '#anchor'
  final XmlElement? base; // original <w:rPr>: fonts, language, styles are preserved
  const _CF({this.b = false, this.i = false, this.u = false, this.size, this.color, this.link, this.base});

  _CF with_({bool? b, bool? i, bool? u, double? size, bool noSize = false, Color? color, bool noColor = false, String? link, bool noLink = false}) => _CF(
        b: b ?? this.b,
        i: i ?? this.i,
        u: u ?? this.u,
        size: noSize ? null : (size ?? this.size),
        color: noColor ? null : (color ?? this.color),
        link: noLink ? null : (link ?? this.link),
        base: base,
      );

  /// Same look on screen.
  bool vis(_CF o) => b == o.b && i == o.i && u == o.u && size == o.size && color?.value == o.color?.value && link == o.link;

  /// Same look and same source run properties (safe to merge into one run).
  bool same(_CF o) => vis(o) && identical(base, o.base);

  TextStyle style(double scale) => TextStyle(
        fontSize: size == null ? null : size! * scale,
        fontWeight: b ? FontWeight.bold : null,
        fontStyle: i ? FontStyle.italic : null,
        decoration: (u || link != null) ? TextDecoration.underline : null,
        color: color ?? (link != null ? const Color(0xFF0563C1) : null),
      );
}

bool _cfEq(List<_CF> a, List<_CF> b) {
  if (identical(a, b)) return true;
  if (a.length != b.length) return false;
  for (var k = 0; k < a.length; k++) {
    if (!a[k].same(b[k])) return false;
  }
  return true;
}

/// Text controller that keeps one [_CF] per character, follows edits (insert / delete / replace)
/// and paints every character with its own format.
class _RunController extends TextEditingController {
  _RunController(String text, List<_CF> cf)
      : _cf = cf,
        super(text: text);

  List<_CF> _cf; // never mutated in place (copy-on-write) so undo snapshots can share it
  _CF ins = const _CF(); // format for text typed into an empty paragraph
  double scale = 1;
  bool _silent = false;

  List<_CF> get cf => _cf;
  set cf(List<_CF> v) {
    _cf = v;
    notifyListeners();
  }

  /// Replace text and formats together (undo / find & replace).
  void setAll(String t, List<_CF> f) {
    _silent = true;
    _cf = f;
    value = value.copyWith(text: t, selection: TextSelection.collapsed(offset: t.length), composing: TextRange.empty);
    _silent = false;
  }

  @override
  set value(TextEditingValue v) {
    if (!_silent && v.text != text) _adjust(text, v.text);
    super.value = v;
  }

  void _adjust(String o, String n) {
    if (_cf.length != o.length) {
      _cf = List<_CF>.filled(n.length, ins);
      return;
    }
    final m = math.min(o.length, n.length);
    var p = 0;
    while (p < m && o.codeUnitAt(p) == n.codeUnitAt(p)) {
      p++;
    }
    var s = 0;
    while (s < m - p && o.codeUnitAt(o.length - 1 - s) == n.codeUnitAt(n.length - 1 - s)) {
      s++;
    }
    final removed = o.length - p - s, added = n.length - p - s;
    final src = _cf.isEmpty ? ins : _cf[p > 0 ? p - 1 : 0];
    final next = <_CF>[..._cf.sublist(0, p), ...List<_CF>.filled(added, src), ..._cf.sublist(p + removed)];
    if (next.isEmpty) ins = src;
    _cf = next;
  }

  @override
  TextSpan buildTextSpan({required BuildContext context, TextStyle? style, required bool withComposing}) {
    final t = text;
    if (t.isEmpty || _cf.length != t.length) {
      return super.buildTextSpan(context: context, style: style, withComposing: withComposing);
    }
    final comp = value.composing;
    final useC = withComposing && comp.isValid && !comp.isCollapsed;
    bool inC(int i) => useC && i >= comp.start && i < comp.end;
    final kids = <InlineSpan>[];
    var s = 0;
    while (s < t.length) {
      var e = s + 1;
      while (e < t.length && _cf[e].vis(_cf[s]) && inC(e) == inC(s)) {
        e++;
      }
      var st = _cf[s].style(scale);
      if (inC(s)) st = st.merge(const TextStyle(decoration: TextDecoration.underline));
      kids.add(TextSpan(text: t.substring(s, e), style: st));
      s = e;
    }
    return TextSpan(style: style, children: kids);
  }
}

/// A comment from word/comments.xml anchored in a paragraph.
class _Cmt {
  final String id, author, date, text;
  _Cmt(this.id, this.author, this.date, this.text);
}

/// A tracked change (insertion / deletion / move / formatting) found in a paragraph.
class _Rev {
  final String kind; // ins | del | moveFrom | moveTo | fmt
  final String author, date, text;
  _Rev(this.kind, this.author, this.date, this.text);
}

class _Para {
  /// Where the paragraph lives when it is not plain body text: content control or text box.
  String? tag;
  List<_Cmt> cmts = const [];
  List<_Rev> revs = const [];
  XmlElement el;
  final String orig;
  final _RunController c;
  final FocusNode focus = FocusNode();
  _Fmt fmt;
  final _Fmt origFmt;
  final List<_CF> origCf;
  final bool heading, isNew, bidi;
  final List<Uint8List> images;
  bool deleted = false;
  _Para(this.el, this.orig, this.fmt, this.heading, {List<_CF> cf = const [], this.isNew = false, this.images = const [], this.bidi = false})
      : c = _RunController(orig, cf),
        origCf = cf,
        origFmt = fmt.copy() {
    if (cf.isNotEmpty) c.ins = cf.last;
  }
}

class _Tbl {
  final XmlElement el;
  final List<List<List<_Para>>> rows; // rows -> cells -> paragraphs
  _Tbl(this.el, this.rows);
}

class _PState {
  final String t;
  final _Fmt f;
  final bool del;
  final List<_CF> cf;
  _PState(this.t, this.f, this.del, this.cf);
}

/// View + edit .docx/.docm/.dotx/.dotm.
/// Text, bold/italic/underline/size/colour per paragraph, tables (cell text),
/// images (shown), undo/redo, find & replace, add/delete paragraphs.
/// Everything not touched (styles, images, numbering, headers) is preserved.
class DocxEditorScreen extends StatefulWidget {
  final String path;
  const DocxEditorScreen({super.key, required this.path});
  @override
  State<DocxEditorScreen> createState() => _DocxEditorScreenState();
}

class _DocxEditorScreenState extends State<DocxEditorScreen> {
  Archive? arc;
  XmlDocument? doc;
  final blocks = <Object>[]; // _Para | _Tbl
  final rels = <String, String>{};
  bool loading = true, dirty = false;
  double font = 16;
  final _scroll = ScrollController();
  _Para? cur;
  XmlDocument? numDoc;
  bool numDirty = false;
  final numFmtOf = <String, String>{};
  int _nextNum = 9100;
  int? _bulletId, _numGrp;
  XmlDocument? relsDoc, ctDoc;
  bool relsDirty = false, ctDirty = false;
  final pending = <String, List<int>>{};
  int _uid = 0;

  // undo / redo
  final undo = <Map<_Para, _PState>>[];
  final redo = <Map<_Para, _PState>>[];
  Map<_Para, _PState> _cur = {};
  Timer? _deb;

  static const _palette = <Color?>[null, Color(0xFF000000), Color(0xFFD32F2F), Color(0xFF1976D2), Color(0xFF388E3C), Color(0xFFF57C00), Color(0xFF7B1FA2), Color(0xFF616161)];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _scroll.dispose();
    _deb?.cancel();
    super.dispose();
  }

  Iterable<_Para> get allParas sync* {
    for (final b in blocks) {
      if (b is _Para) {
        yield b;
      } else if (b is _Tbl) {
        for (final r in b.rows) {
          for (final c in r) {
            yield* c;
          }
        }
      }
    }
  }

  // ---------- XML helpers ----------
  static bool _hasMedia(XmlElement r) =>
      r.findAllElements('w:drawing').isNotEmpty || r.findAllElements('w:pict').isNotEmpty || r.findAllElements('mc:AlternateContent').isNotEmpty;

  /// Text runs of this paragraph only (not runs of text boxes nested in it), without pictures.
  static Iterable<XmlElement> _textRuns(XmlElement p) =>
      p.descendants.whereType<XmlElement>().where((e) => e.name.qualified == 'w:r' && _anc(e, 'w:p') == p && !_hasMedia(e) && !_isRefRun(e) && !_inDeleted(e, p));

  /// Run that only anchors a comment / footnote / endnote: never rewritten.
  static bool _isRefRun(XmlElement r) => r.children.whereType<XmlElement>().any((c) => const {'w:commentReference', 'w:footnoteReference', 'w:endnoteReference', 'w:annotationRef'}.contains(c.name.qualified));

  /// Run inside a tracked deletion / move-from: it stays in the file untouched.
  static bool _inDeleted(XmlElement r, XmlElement p) {
    for (final a in r.ancestors) {
      if (a == p) return false;
      if (a is XmlElement && (a.name.qualified == 'w:del' || a.name.qualified == 'w:moveFrom')) return true;
    }
    return false;
  }

  static String _runText(XmlElement r) {
    final b = StringBuffer();
    for (final n in r.children.whereType<XmlElement>()) {
      switch (n.name.qualified) {
        case 'w:t': b.write(n.innerText); break;
        case 'w:tab': b.write('\t'); break;
        case 'w:br': case 'w:cr': b.write('\n'); break;
      }
    }
    return b.toString();
  }

  static bool _flag(XmlElement? rpr, String tag) {
    final e = rpr?.findElements(tag).firstOrNull;
    if (e == null) return false;
    final v = e.getAttribute('w:val');
    return v == null || (v != '0' && v != 'false' && v != 'none');
  }

  static _CF _cfOfRpr(XmlElement? rpr) {
    double? size;
    final sz = int.tryParse(rpr?.findElements('w:sz').firstOrNull?.getAttribute('w:val') ?? '');
    if (sz != null) size = sz / 2;
    Color? color;
    final hex = rpr?.findElements('w:color').firstOrNull?.getAttribute('w:val');
    if (hex != null && RegExp(r'^[0-9A-Fa-f]{6}$').hasMatch(hex)) color = Color(0xFF000000 | int.parse(hex, radix: 16));
    return _CF(b: _flag(rpr, 'w:b'), i: _flag(rpr, 'w:i'), u: _flag(rpr, 'w:u'), size: size, color: color, base: rpr);
  }

  _Fmt _readFmt(XmlElement p) => _Fmt(align: _readAlign(p), list: _readList(p));

  /// Paragraph text + one format per UTF-16 unit (hyperlink targets included).
  (String, List<_CF>) _scan(XmlElement p) {
    final sb = StringBuffer();
    final cf = <_CF>[];
    for (final r in _textRuns(p)) {
      final t = _runText(r);
      if (t.isEmpty) continue;
      var c = _cfOfRpr(r.findElements('w:rPr').firstOrNull);
      final h = _anc(r, 'w:hyperlink');
      if (h != null) {
        final id = h.getAttribute('r:id');
        final an = h.getAttribute('w:anchor');
        final url = id != null ? rels[id] : (an != null ? '#$an' : null);
        if (url != null) c = c.with_(link: url);
      }
      sb.write(t);
      for (var k = 0; k < t.length; k++) {
        cf.add(c);
      }
    }
    return (sb.toString(), cf);
  }

  // ---------- paragraph props / numbering ----------
  static XmlElement _el(String n, [Map<String, String> a = const {}, List<XmlNode> c = const []]) =>
      XmlElement(XmlName(n), a.entries.map((e) => XmlAttribute(XmlName(e.key), e.value)), c);

  static bool _isBidi(XmlElement p) => p.findElements('w:pPr').firstOrNull?.findElements('w:bidi').firstOrNull != null;

  static String? _readAlign(XmlElement p) {
    final v = p.findElements('w:pPr').firstOrNull?.findElements('w:jc').firstOrNull?.getAttribute('w:val');
    final bidi = _isBidi(p);
    switch (v) {
      case 'center': return 'center';
      case 'both': case 'distribute': case 'justify': return 'both';
      case 'left': case 'start': return bidi ? 'right' : 'left';
      case 'right': case 'end': return bidi ? 'left' : 'right';
    }
    return null;
  }

  int _readList(XmlElement p) {
    final id = p.findElements('w:pPr').firstOrNull?.findElements('w:numPr').firstOrNull?.findElements('w:numId').firstOrNull?.getAttribute('w:val');
    if (id == null || id == '0') return 0;
    return numFmtOf[id] == 'bullet' ? 1 : 2;
  }

  void _readNums() {
    numFmtOf.clear();
    final nd = numDoc;
    if (nd == null) return;
    final abs = <String, String>{};
    for (final a in nd.findAllElements('w:abstractNum')) {
      final id = a.getAttribute('w:abstractNumId');
      final lvl = a.findElements('w:lvl').where((l) => (l.getAttribute('w:ilvl') ?? '0') == '0').firstOrNull;
      final fmt = lvl?.findElements('w:numFmt').firstOrNull?.getAttribute('w:val');
      if (id != null && fmt != null) abs[id] = fmt;
    }
    for (final n in nd.findAllElements('w:num')) {
      final id = n.getAttribute('w:numId');
      final a = n.findElements('w:abstractNumId').firstOrNull?.getAttribute('w:val');
      if (id == null) continue;
      numFmtOf[id] = abs[a] ?? 'decimal';
      final v = int.tryParse(id);
      if (v != null && v >= _nextNum) _nextNum = v + 1;
    }
  }

  static const _pOrder = ['w:pStyle', 'w:keepNext', 'w:keepLines', 'w:pageBreakBefore', 'w:framePr', 'w:widowControl', 'w:numPr', 'w:suppressLineNumbers', 'w:pBdr', 'w:shd', 'w:tabs', 'w:suppressAutoHyphens', 'w:kinsoku', 'w:wordWrap', 'w:overflowPunct', 'w:topLinePunct', 'w:autoSpaceDE', 'w:autoSpaceDN', 'w:bidi', 'w:adjustRightInd', 'w:snapToGrid', 'w:spacing', 'w:ind', 'w:contextualSpacing', 'w:mirrorIndents', 'w:suppressOverlap', 'w:jc', 'w:textDirection', 'w:textAlignment', 'w:textboxTightWrap', 'w:outlineLvl', 'w:divId', 'w:cnfStyle', 'w:rPr', 'w:sectPr', 'w:pPrChange'];

  static void _putP(XmlElement para, String name, XmlElement? el) {
    var ppr = para.findElements('w:pPr').firstOrNull;
    if (ppr == null) {
      if (el == null) return;
      ppr = XmlElement(XmlName('w:pPr'));
      para.children.insert(0, ppr);
    }
    ppr.children.removeWhere((n) => n is XmlElement && n.name.qualified == name);
    if (el == null) return;
    final idx = _pOrder.indexOf(name);
    var pos = ppr.children.length;
    for (var k = 0; k < ppr.children.length; k++) {
      final n = ppr.children[k];
      if (n is XmlElement && _pOrder.indexOf(n.name.qualified) > idx) {
        pos = k;
        break;
      }
    }
    ppr.children.insert(pos, el);
  }

  static XmlElement _numPr(int id) => _el('w:numPr', {}, [_el('w:ilvl', {'w:val': '0'}), _el('w:numId', {'w:val': '$id'})]);

  int _addNum(int abstractId, bool restart) {
    numDoc ??= XmlDocument.parse('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"></w:numbering>');
    final root = numDoc!.rootElement;
    final bullet = abstractId == 9001;
    if (!root.findElements('w:abstractNum').any((a) => a.getAttribute('w:abstractNumId') == '$abstractId')) {
      final lvl = _el('w:lvl', {'w:ilvl': '0'}, [
        _el('w:start', {'w:val': '1'}),
        _el('w:numFmt', {'w:val': bullet ? 'bullet' : 'decimal'}),
        _el('w:lvlText', {'w:val': bullet ? '\u2022' : '%1.'}),
        _el('w:lvlJc', {'w:val': 'left'}),
        _el('w:pPr', {}, [_el('w:ind', {'w:left': '720', 'w:hanging': '360'})]),
      ]);
      final a = _el('w:abstractNum', {'w:abstractNumId': '$abstractId'}, [_el('w:multiLevelType', {'w:val': 'hybridMultilevel'}), lvl]);
      final first = root.children.indexWhere((n) => n is XmlElement && (n.name.qualified == 'w:num' || n.name.qualified == 'w:numIdMacAtCleanup'));
      root.children.insert(first < 0 ? root.children.length : first, a);
    }
    final id = _nextNum++;
    final num = _el('w:num', {'w:numId': '$id'}, [
      _el('w:abstractNumId', {'w:val': '$abstractId'}),
      if (restart) _el('w:lvlOverride', {'w:ilvl': '0'}, [_el('w:startOverride', {'w:val': '1'})]),
    ]);
    final mac = root.children.indexWhere((n) => n is XmlElement && n.name.qualified == 'w:numIdMacAtCleanup');
    root.children.insert(mac < 0 ? root.children.length : mac, num);
    numFmtOf['$id'] = bullet ? 'bullet' : 'decimal';
    numDirty = true;
    return id;
  }

  void _applyPara(_Para q) {
    final f = q.fmt, o = q.origFmt;
    if (f.align != o.align) {
      final a = f.align;
      String? v = a;
      if (q.bidi && a == 'left') v = 'right';
      if (q.bidi && a == 'right') v = 'left';
      _putP(q.el, 'w:jc', v == null ? null : _el('w:jc', {'w:val': v}));
    }
    if (f.list != o.list) {
      if (f.list == 0) {
        _putP(q.el, 'w:numPr', _numPr(0));
      } else if (f.list == 1) {
        _bulletId ??= _addNum(9001, false);
        _putP(q.el, 'w:numPr', _numPr(_bulletId!));
      } else {
        _numGrp ??= _addNum(9002, true);
        _putP(q.el, 'w:numPr', _numPr(_numGrp!));
      }
    }
    if (!(f.list == 2 && f.list != o.list)) _numGrp = null;
  }

  void _rebuild() {
    _readNums();
    blocks.clear();
    cur = null;
    final body = doc!.findAllElements('w:body').first;
    _collect(body, blocks);
    undo.clear();
    redo.clear();
    _cur = _capture();
  }

  static const _order = ['w:rStyle', 'w:rFonts', 'w:b', 'w:bCs', 'w:i', 'w:iCs', 'w:caps', 'w:smallCaps', 'w:strike', 'w:dstrike', 'w:outline', 'w:shadow', 'w:emboss', 'w:imprint', 'w:noProof', 'w:snapToGrid', 'w:vanish', 'w:webHidden', 'w:color', 'w:spacing', 'w:w', 'w:kern', 'w:position', 'w:sz', 'w:szCs', 'w:highlight', 'w:u', 'w:effect', 'w:bdr', 'w:shd', 'w:fitText', 'w:vertAlign', 'w:rtl', 'w:cs', 'w:em', 'w:lang'];

  static void _put(XmlElement rpr, String name, Map<String, String>? attrs) {
    rpr.children.removeWhere((n) => n is XmlElement && n.name.qualified == name);
    if (attrs == null) return;
    final el = XmlElement(XmlName(name), attrs.entries.map((e) => XmlAttribute(XmlName(e.key), e.value)));
    final idx = _order.indexOf(name);
    var pos = rpr.children.length;
    for (var k = 0; k < rpr.children.length; k++) {
      final n = rpr.children[k];
      if (n is XmlElement && _order.indexOf(n.name.qualified) > idx) {
        pos = k;
        break;
      }
    }
    rpr.children.insert(pos, el);
  }

  /// <w:rPr> for a character format: starts from the original rPr, only changed properties are rewritten.
  XmlElement? _rprFor(_CF c) {
    final o = _cfOfRpr(c.base);
    final r = c.base?.copy() ?? _el('w:rPr');
    if (c.b != o.b) {
      _put(r, 'w:b', c.b ? {} : null);
      _put(r, 'w:bCs', c.b ? {} : null);
    }
    if (c.i != o.i) {
      _put(r, 'w:i', c.i ? {} : null);
      _put(r, 'w:iCs', c.i ? {} : null);
    }
    if (c.u != o.u) _put(r, 'w:u', c.u ? {'w:val': 'single'} : null);
    if (c.color?.value != o.color?.value) {
      final hex = c.color == null ? null : (c.color!.value & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase();
      _put(r, 'w:color', hex == null ? null : {'w:val': hex});
    }
    if (c.size != o.size) {
      final hp = c.size == null ? null : (c.size! * 2).round().toString();
      _put(r, 'w:sz', hp == null ? null : {'w:val': hp});
      _put(r, 'w:szCs', hp == null ? null : {'w:val': hp});
    }
    if (c.link == null) {
      r.children.removeWhere((n) => n is XmlElement && n.name.qualified == 'w:rStyle' && n.getAttribute('w:val') == 'Hyperlink');
    }
    return r.children.isEmpty ? null : r;
  }

  static List<XmlElement> _textKids(String s) {
    final out = <XmlElement>[];
    final buf = StringBuffer();
    void flush() {
      if (buf.isEmpty) return;
      out.add(XmlElement(XmlName('w:t'), [XmlAttribute(XmlName('xml:space'), 'preserve')], [XmlText(buf.toString())]));
      buf.clear();
    }
    for (var k = 0; k < s.length; k++) {
      final ch = s[k];
      if (ch == '\t') {
        flush();
        out.add(XmlElement(XmlName('w:tab')));
      } else if (ch == '\n') {
        flush();
        out.add(XmlElement(XmlName('w:br')));
      } else {
        buf.write(ch);
      }
    }
    flush();
    return out;
  }

  /// Existing relationship id for a hyperlink target, or a new one.
  String _relForUrl(String url) {
    for (final r in relsDoc?.rootElement.findElements('Relationship') ?? <XmlElement>[]) {
      if ((r.getAttribute('Type') ?? '').endsWith('/hyperlink') && r.getAttribute('Target') == url) {
        final id = r.getAttribute('Id');
        if (id != null) return id;
      }
    }
    return _addRel('hyperlink', url, external: true);
  }

  XmlElement _linkEl(String url) => url.startsWith('#')
      ? _el('w:hyperlink', {'w:anchor': url.substring(1), 'w:history': '1'})
      : _el('w:hyperlink', {'r:id': _relForUrl(url), 'w:history': '1'});

  /// Runs (grouped by equal format, hyperlinks wrapped) for text + per-character formats.
  List<XmlNode> _runsFor(String text, List<_CF> cf0) {
    final cf = cf0.length == text.length ? cf0 : List<_CF>.filled(text.length, const _CF());
    final out = <XmlNode>[];
    XmlElement? link;
    String? linkUrl;
    var s = 0;
    while (s < text.length) {
      var e = s + 1;
      while (e < text.length && cf[e].same(cf[s])) {
        e++;
      }
      final c = cf[s];
      final rpr = _rprFor(c);
      final run = _el('w:r', {}, [if (rpr != null) rpr, ..._textKids(text.substring(s, e))]);
      if (c.link == null) {
        out.add(run);
        link = null;
        linkUrl = null;
      } else {
        if (link == null || linkUrl != c.link) {
          link = _linkEl(c.link!);
          linkUrl = c.link;
          out.add(link);
        }
        link.children.add(run);
      }
      s = e;
    }
    return out;
  }

  /// Removes all text runs (also field runs / <w:fldSimple>, i.e. fields become plain text) of the paragraph
  /// and returns the child index where new runs belong. Pictures, bookmarks and paragraph properties stay.
  int _stripRuns(XmlElement para) {
    final runs = _textRuns(para).toList();
    if (runs.isEmpty) return para.children.length;
    XmlNode top = runs.first;
    while (top.parent != para) {
      top = top.parent!;
    }
    final marker = XmlComment('abtin');
    para.children.insert(para.children.indexOf(top), marker);
    for (final r in runs) {
      r.remove();
    }
    const wrappers = {'w:hyperlink', 'w:fldSimple', 'w:smartTag', 'w:ins'};
    for (final w in para.descendants.whereType<XmlElement>().where((e) => wrappers.contains(e.name.qualified) && e.children.whereType<XmlElement>().isEmpty).toList()) {
      w.remove();
    }
    final at = para.children.indexOf(marker);
    marker.remove();
    return at;
  }

  void _rebuildRuns(XmlElement para, String text, List<_CF> cf) {
    final at = _stripRuns(para);
    para.children.insertAll(at, _runsFor(text, cf));
  }

  // ---------- load ----------
  List<Uint8List> _imagesOf(XmlElement p) {
    final out = <Uint8List>[];
    for (final n in p.descendants.whereType<XmlElement>()) {
      String? id;
      if (n.name.qualified == 'a:blip') id = n.getAttribute('r:embed');
      if (n.name.qualified == 'v:imagedata') id = n.getAttribute('r:id');
      if (id == null) continue;
      var t = rels[id];
      if (t == null) continue;
      t = t.startsWith('/') ? t.substring(1) : 'word/$t';
      final data = pending[t] ?? (arc!.findFile(t)?.content as List<int>?);
      if (data != null && const {'png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp'}.contains(p_ext(t))) {
        out.add(Uint8List.fromList(data));
      }
    }
    return out;
  }

  static String p_ext(String s) => s.contains('.') ? s.split('.').last.toLowerCase() : '';

  _Para _mkPara(XmlElement e, [String? tag]) {
    final style = e.findAllElements('w:pStyle').firstOrNull?.getAttribute('w:val') ?? '';
    final sc = _scan(e);
    final q = _Para(e, sc.$1, _readFmt(e), style.startsWith('Heading') || style == 'Title', cf: sc.$2, images: _imagesOf(e), bidi: _isBidi(e));
    q.tag = tag;
    _annotate(q);
    q.focus.addListener(() {
      if (q.focus.hasFocus && mounted) setState(() => cur = q);
    });
    return q;
  }

  // ---------- comments / tracked changes ----------
  final comments = <String, _Cmt>{};
  bool showMarkup = true;

  static String _date(String? d) => d == null ? '' : d.replaceFirst('T', ' ').replaceFirst('Z', '').split('+').first;

  static String _joinT(XmlElement e, String tag) => e.findAllElements(tag).map((t) => t.innerText).join();

  void _annotate(_Para q) {
    final e = q.el;
    final cm = <_Cmt>[], rv = <_Rev>[];
    final seen = <String>{};
    for (final n in e.descendants.whereType<XmlElement>()) {
      final nm = n.name.qualified;
      if (nm == 'w:p' || _anc(n, 'w:p') != e) continue;
      if (nm == 'w:commentReference') {
        final c = comments[n.getAttribute('w:id') ?? ''];
        if (c != null && seen.add(c.id)) cm.add(c);
      } else if (nm == 'w:ins' || nm == 'w:del' || nm == 'w:moveFrom' || nm == 'w:moveTo') {
        final mark = n.parent is XmlElement && (n.parent as XmlElement).name.qualified == 'w:rPr';
        final t = mark ? '\u00b6' : (nm == 'w:del' || nm == 'w:moveFrom' ? _joinT(n, 'w:delText') : _joinT(n, 'w:t'));
        if (t.isEmpty && !mark) continue;
        rv.add(_Rev(nm.substring(2), n.getAttribute('w:author') ?? '', _date(n.getAttribute('w:date')), t));
      } else if (nm == 'w:rPrChange' || nm == 'w:pPrChange' || nm == 'w:sectPrChange' || nm == 'w:tblPrChange') {
        rv.add(_Rev('fmt', n.getAttribute('w:author') ?? '', _date(n.getAttribute('w:date')), ''));
      }
    }
    q.cmts = cm;
    q.revs = rv;
  }

  void _loadComments() {
    comments.clear();
    final cf = arc?.findFile('word/comments.xml');
    if (cf == null) return;
    try {
      final cd = XmlDocument.parse(utf8.decode(cf.content as List<int>));
      for (final c in cd.findAllElements('w:comment')) {
        final id = c.getAttribute('w:id');
        if (id == null) continue;
        final text = c.findAllElements('w:p').map((p) => _joinT(p, 'w:t')).join('\n').trim();
        comments[id] = _Cmt(id, c.getAttribute('w:author') ?? '', _date(c.getAttribute('w:date')), text);
      }
    } catch (_) {}
  }

  // ---------- content controls and text boxes ----------
  /// Block-level paragraphs of [parent] (body / cell): w:p, w:sdt (content controls, recursively), text boxes.
  List<XmlElement> _cellParas(XmlElement parent) {
    final out = <XmlElement>[];
    for (final n in parent.children.whereType<XmlElement>()) {
      final nm = n.name.qualified;
      if (nm == 'w:p') {
        out.add(n);
      } else if (nm == 'w:sdt') {
        final c = n.findElements('w:sdtContent').firstOrNull;
        if (c != null) out.addAll(_cellParas(c));
      } else if (nm == 'w:customXml' || nm == 'w:smartTag') {
        out.addAll(_cellParas(n));
      }
    }
    return out;
  }

  /// <w:txbxContent> of the DrawingML / VML text boxes of paragraph [p] (the VML fallback copy is skipped).
  static List<XmlElement> _textBoxes(XmlElement p) {
    final out = <XmlElement>[];
    for (final n in p.descendants.whereType<XmlElement>()) {
      if (n.name.qualified != 'w:txbxContent') continue;
      var ok = true;
      for (final a in n.ancestors) {
        if (a == p) break;
        if (a is XmlElement && (a.name.qualified == 'w:txbxContent' || a.name.qualified == 'mc:Fallback')) {
          ok = false;
          break;
        }
      }
      if (ok) out.add(n);
    }
    return out;
  }

  String? _sdtLabel(XmlElement sdt) {
    final pr = sdt.findElements('w:sdtPr').firstOrNull;
    final name = pr?.findElements('w:alias').firstOrNull?.getAttribute('w:val') ?? pr?.findElements('w:tag').firstOrNull?.getAttribute('w:val');
    final base = L.t('contentControl');
    return name == null || name.isEmpty ? base : '$base: $name';
  }

  void _collect(XmlElement parent, List<Object> out, {String? tag}) {
    for (final n in parent.children.whereType<XmlElement>()) {
      switch (n.name.qualified) {
        case 'w:p':
          out.add(_mkPara(n, tag));
          for (final tb in _textBoxes(n)) {
            _collect(tb, out, tag: L.t('textBox'));
          }
          break;
        case 'w:tbl':
          out.add(_mkTbl(n));
          break;
        case 'w:sdt':
          final c = n.findElements('w:sdtContent').firstOrNull;
          if (c != null) _collect(c, out, tag: tag ?? _sdtLabel(n));
          break;
        case 'w:customXml':
        case 'w:smartTag':
          _collect(n, out, tag: tag);
          break;
      }
    }
  }

  _Tbl _mkTbl(XmlElement t) {
    final rows = <List<List<_Para>>>[];
    for (final tr in t.findElements('w:tr')) {
      final cells = <List<_Para>>[];
      for (final tc in tr.findElements('w:tc')) {
        cells.add(_cellParas(tc).map((e) => _mkPara(e)).toList());
      }
      rows.add(cells);
    }
    return _Tbl(t, rows);
  }

  Future<void> _load() async {
    try {
      final bytes = await File(widget.path).readAsBytes();
      arc = ZipDecoder().decodeBytes(bytes);
      final f = arc!.findFile('word/document.xml');
      if (f == null) throw Exception('word/document.xml not found');
      doc = XmlDocument.parse(utf8.decode(f.content as List<int>));
      rels.clear();
      pending.clear();
      relsDirty = false;
      ctDirty = false;
      final rf = arc!.findFile('word/_rels/document.xml.rels');
      relsDoc = rf == null ? null : XmlDocument.parse(utf8.decode(rf.content as List<int>));
      final cf = arc!.findFile('[Content_Types].xml');
      ctDoc = cf == null ? null : XmlDocument.parse(utf8.decode(cf.content as List<int>));
      for (final r in relsDoc?.findAllElements('Relationship') ?? <XmlElement>[]) {
        final id = r.getAttribute('Id'), t = r.getAttribute('Target');
        if (id != null && t != null) rels[id] = t;
      }
      final nf = arc!.findFile('word/numbering.xml');
      numDoc = nf == null ? null : XmlDocument.parse(utf8.decode(nf.content as List<int>));
      numDirty = false;
      _bulletId = null;
      _numGrp = null;
      _nextNum = 9100;
      _loadComments();
      _rebuild();
      setState(() => loading = false);
    } catch (e) {
      if (mounted) {
        snack(context, '${L.t('error')}: $e');
        Navigator.pop(context);
      }
    }
  }

  // ---------- undo / redo ----------
  Map<_Para, _PState> _capture() => {for (final q in allParas) q: _PState(q.c.text, q.fmt.copy(), q.deleted, q.c.cf)};

  bool _same(Map<_Para, _PState> a, Map<_Para, _PState> b) {
    if (a.length != b.length) return false;
    for (final e in a.entries) {
      final o = b[e.key];
      if (o == null || o.t != e.value.t || o.del != e.value.del || !o.f.eq(e.value.f) || !_cfEq(o.cf, e.value.cf)) return false;
    }
    return true;
  }

  void _commit() {
    _deb?.cancel();
    _deb = null;
    final now = _capture();
    if (_same(now, _cur)) return;
    undo.add(_cur);
    if (undo.length > 80) undo.removeAt(0);
    redo.clear();
    _cur = now;
  }

  void _touch() {
    if (!dirty) setState(() => dirty = true);
    _deb?.cancel();
    _deb = Timer(const Duration(milliseconds: 700), () {
      if (mounted) setState(_commit);
    });
  }

  void _restore(Map<_Para, _PState> s) {
    setState(() {
      for (final q in allParas) {
        final st = s[q];
        if (st == null) {
          q.deleted = true; // created after this snapshot
          continue;
        }
        q.c.setAll(st.t, st.cf);
        q.fmt = st.f.copy();
        q.deleted = st.del;
      }
      dirty = true;
    });
  }

  void _doUndo() {
    _commit();
    if (undo.isEmpty) return;
    redo.add(_cur);
    _cur = undo.removeLast();
    _restore(_cur);
  }

  void _doRedo() {
    _commit();
    if (redo.isEmpty) return;
    undo.add(_cur);
    _cur = redo.removeLast();
    _restore(_cur);
  }

  // ---------- formatting ----------
  void _fmt(void Function(_Fmt f) fn) {
    final q = cur;
    if (q == null) {
      snack(context, L.t('tapPara'));
      return;
    }
    setState(() {
      fn(q.fmt);
      dirty = true;
      _commit();
    });
  }

  static const _linkBlue = Color(0xFF0563C1);

  // ---------- selection-level character formatting ----------
  (int, int) _range(_Para q) {
    final n = q.c.text.length;
    final s = q.c.selection;
    if (s.isValid && !s.isCollapsed && s.end <= n) return (s.start, s.end);
    return (0, n);
  }

  bool _hasSel(_Para q) {
    final s = q.c.selection;
    return s.isValid && !s.isCollapsed && s.end <= q.c.text.length;
  }

  List<_CF> _cfOf(_Para q) => q.c.cf.length == q.c.text.length ? q.c.cf : List<_CF>.filled(q.c.text.length, q.c.ins);

  /// Every character of the selection (or of the whole paragraph) satisfies [t].
  bool _all(_Para q, bool Function(_CF) t) {
    final (a, b) = _range(q);
    final cf = _cfOf(q);
    if (cf.isEmpty || a == b) return t(cf.isEmpty ? q.c.ins : cf[math.min(a, cf.length - 1)]);
    for (var k = a; k < b && k < cf.length; k++) {
      if (!t(cf[k])) return false;
    }
    return true;
  }

  /// Size shown in the toolbar: common size of the range, null when mixed / default.
  double? _sizeOf(_Para q) {
    final (a, b) = _range(q);
    final cf = _cfOf(q);
    if (cf.isEmpty || a == b) return (cf.isEmpty ? q.c.ins : cf[math.min(a, cf.length - 1)]).size;
    final first = cf[a].size;
    for (var k = a; k < b && k < cf.length; k++) {
      if (cf[k].size != first) return null;
    }
    return first;
  }

  Color? _colorOf(_Para q) {
    final (a, b) = _range(q);
    final cf = _cfOf(q);
    if (cf.isEmpty || a == b) return (cf.isEmpty ? q.c.ins : cf[math.min(a, cf.length - 1)]).color;
    final first = cf[a].color;
    for (var k = a; k < b && k < cf.length; k++) {
      if (cf[k].color?.value != first?.value) return null;
    }
    return first;
  }

  /// Applies [fn] to the selected characters, or to the whole paragraph when nothing is selected.
  void _cfEdit(_CF Function(_CF c) fn, {_Para? para, (int, int)? range}) {
    final q = para ?? cur;
    if (q == null) {
      snack(context, L.t('tapPara'));
      return;
    }
    final (a, b) = range ?? _range(q);
    final old = _cfOf(q);
    final nc = List<_CF>.of(old);
    for (var k = a; k < b && k < nc.length; k++) {
      nc[k] = fn(old[k]);
    }
    setState(() {
      q.c.ins = fn(q.c.ins);
      q.c.cf = nc;
      dirty = true;
      _commit();
    });
  }

  void _toggle(bool Function(_CF) get, _CF Function(_CF, bool) set) {
    final q = cur;
    if (q == null) {
      snack(context, L.t('tapPara'));
      return;
    }
    final on = !_all(q, get);
    _cfEdit((c) => set(c, on));
  }

  void _unlink() {
    final q = cur;
    if (q == null) {
      snack(context, L.t('tapPara'));
      return;
    }
    _cfEdit((c) => c.link == null ? c : c.with_(noLink: true, u: false, noColor: c.color?.value == _linkBlue.value));
  }

  Future<void> _findReplace() async {
    final a = TextEditingController(), b = TextEditingController();
    final go = await showDialog<bool>(
      context: context,
      builder: (dc) => AlertDialog(
        title: Text(L.t('findReplace')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: a, autofocus: true, decoration: InputDecoration(labelText: L.t('find'))),
          const SizedBox(height: 8),
          TextField(controller: b, decoration: InputDecoration(labelText: L.t('replaceWith'))),
        ]),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(dc, false)),
          FilledButton(onPressed: () => Navigator.pop(dc, true), child: Text(L.t('replaceAll'))),
        ],
      ),
    );
    if (go != true || a.text.isEmpty) return;
    var n = 0;
    setState(() {
      for (final q in allParas) {
        if (q.deleted) continue;
        final t = q.c.text;
        if (t.contains(a.text)) {
          final old = q.c.cf.length == t.length ? q.c.cf : List<_CF>.filled(t.length, q.c.ins);
          final nt = StringBuffer();
          final ncf = <_CF>[];
          var i = 0;
          while (true) {
            final k = t.indexOf(a.text, i);
            final end = k < 0 ? t.length : k;
            nt.write(t.substring(i, end));
            ncf.addAll(old.sublist(i, end));
            if (k < 0) break;
            n++;
            nt.write(b.text);
            ncf.addAll(List<_CF>.filled(b.text.length, old[k]));
            i = k + a.text.length;
          }
          q.c.setAll(nt.toString(), ncf);
        }
      }
      if (n > 0) {
        dirty = true;
        _commit();
      }
    });
    if (mounted) snack(context, '${L.t('replaced')}: $n');
  }

  // ---------- flush / structure ----------
  void _flush() {
    final body = doc!.findAllElements('w:body').first;
    _numGrp = null;
    for (final q in allParas) {
      if (q.deleted) {
        if (!q.isNew) {
          final par = q.el.parent;
          if (par is XmlElement && const {'w:tc', 'w:sdtContent', 'w:txbxContent'}.contains(par.name.qualified) && par.findElements('w:p').length == 1) {
            _rebuildRuns(q.el, '', const []);
          } else {
            q.el.remove();
          }
        }
      } else if (q.isNew) {
        q.el = XmlElement(XmlName('w:p'));
        _rebuildRuns(q.el, q.c.text, q.c.cf);
        final sect = body.children.whereType<XmlElement>().where((e) => e.name.qualified == 'w:sectPr').lastOrNull;
        final at = sect != null ? body.children.indexOf(sect) : body.children.length;
        body.children.insert(at, q.el);
        _applyPara(q);
      } else {
        if (q.c.text != q.orig || !_cfEq(q.c.cf, q.origCf)) {
          _rebuildRuns(q.el, q.c.text, q.c.cf);
          _afterTextEdit(q);
        }
        _applyPara(q);
      }
    }
  }

  /// A content control that showed its placeholder is no longer a placeholder once edited;
  /// a text box edited in its DrawingML copy is mirrored into the VML fallback copy.
  void _afterTextEdit(_Para q) {
    try {
      final sdt = _anc(q.el, 'w:sdt');
      sdt?.findElements('w:sdtPr').firstOrNull?.findElements('w:showingPlcHdr').toList().forEach((e) => e.remove());
      final tx = _anc(q.el, 'w:txbxContent');
      final choice = _anc(q.el, 'mc:Choice');
      final ac = choice?.parent;
      if (tx == null || choice == null || ac is! XmlElement) return;
      final fb = ac.findElements('mc:Fallback').firstOrNull;
      if (fb == null) return;
      List<XmlElement> boxes(XmlElement r) => r.descendants.whereType<XmlElement>().where((e) => e.name.qualified == 'w:txbxContent').toList();
      final i = boxes(choice).indexOf(tx);
      final fbs = boxes(fb);
      if (i < 0 || i >= fbs.length) return;
      final k = tx.findElements('w:p').toList().indexOf(q.el);
      final tp = fbs[i].findElements('w:p').toList();
      if (k >= 0 && k < tp.length) _rebuildRuns(tp[k], q.c.text, q.c.cf);
    } catch (_) {}
  }

  String _addRel(String type, String target, {bool external = false}) {
    relsDoc ??= XmlDocument.parse('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"></Relationships>');
    var n = 1;
    while (rels.containsKey('rIdA$n')) {
      n++;
    }
    final id = 'rIdA$n';
    relsDoc!.rootElement.children.add(_el('Relationship', {
      'Id': id,
      'Type': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/$type',
      'Target': target,
      if (external) 'TargetMode': 'External',
    }));
    rels[id] = target;
    relsDirty = true;
    return id;
  }

  void _ensureCt(String type, {String? ext, String? part}) {
    final r = ctDoc?.rootElement;
    if (r == null) return;
    if (ext != null) {
      if (r.findElements('Default').any((e) => (e.getAttribute('Extension') ?? '').toLowerCase() == ext)) return;
      r.children.insert(0, _el('Default', {'Extension': ext, 'ContentType': type}));
    } else if (part != null) {
      if (r.findElements('Override').any((e) => e.getAttribute('PartName') == part)) return;
      r.children.add(_el('Override', {'PartName': part, 'ContentType': type}));
    }
    ctDirty = true;
  }

  void _wireNumbering() {
    _ensureCt('application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml', part: '/word/numbering.xml');
    if (!rels.values.any((t) => t.endsWith('numbering.xml'))) _addRel('numbering', 'numbering.xml');
  }

  /// Structural edit: write pending text edits into the XML, change the XML, rebuild the view. Clears undo history.
  void _struct(void Function() fn) {
    _commit();
    _flush();
    fn();
    setState(() {
      _rebuild();
      dirty = true;
    });
  }

  static XmlElement? _anc(XmlNode e, String name) {
    for (final a in e.ancestors) {
      if (a is XmlElement && a.name.qualified == name) return a;
    }
    return null;
  }

  static void _blankCell(XmlElement tc) {
    for (final t in tc.findElements('w:tbl').toList()) {
      t.remove();
    }
    final ps = tc.findElements('w:p').toList();
    if (ps.isEmpty) {
      tc.children.add(_el('w:p'));
    } else {
      for (var k = 1; k < ps.length; k++) {
        ps[k].remove();
      }
      for (final c in ps.first.children.toList()) {
        if (c is XmlText || (c is XmlElement && c.name.qualified != 'w:pPr')) c.remove();
      }
    }
    for (final m in (tc.findElements('w:tcPr').firstOrNull?.findElements('w:vMerge').toList() ?? <XmlElement>[])) {
      m.remove();
    }
  }

  static XmlElement _blankRow(XmlElement tr) {
    final n = tr.copy();
    for (final c in n.findElements('w:tc').toList()) {
      _blankCell(c);
    }
    return n;
  }

  static XmlElement _newTable(int rows, int cols) {
    final w = (9000 / cols).floor();
    XmlElement cell() => _el('w:tc', {}, [_el('w:tcPr', {}, [_el('w:tcW', {'w:w': '$w', 'w:type': 'dxa'})]), _el('w:p')]);
    XmlElement bd(String n) => _el(n, {'w:val': 'single', 'w:sz': '4', 'w:space': '0', 'w:color': '808080'});
    return _el('w:tbl', {}, [
      _el('w:tblPr', {}, [
        _el('w:tblW', {'w:w': '${w * cols}', 'w:type': 'dxa'}),
        _el('w:tblBorders', {}, [bd('w:top'), bd('w:left'), bd('w:bottom'), bd('w:right'), bd('w:insideH'), bd('w:insideV')]),
        _el('w:tblLook', {'w:val': '04A0'}),
      ]),
      _el('w:tblGrid', {}, [for (var k = 0; k < cols; k++) _el('w:gridCol', {'w:w': '$w'})]),
      for (var r = 0; r < rows; r++) _el('w:tr', {}, [for (var k = 0; k < cols; k++) cell()]),
    ]);
  }

  Future<void> _insertTable() async {
    final r = TextEditingController(text: '3'), c = TextEditingController(text: '3');
    final go = await showDialog<bool>(
      context: context,
      builder: (dc) => AlertDialog(
        title: Text(L.t('insertTable')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: r, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: L.t('rows'))),
          const SizedBox(height: 8),
          TextField(controller: c, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: L.t('cols'))),
        ]),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(dc, false)),
          FilledButton(onPressed: () => Navigator.pop(dc, true), child: Text(L.t('ok'))),
        ],
      ),
    );
    if (go != true || !mounted) return;
    final rows = (int.tryParse(r.text) ?? 3).clamp(1, 50).toInt();
    final cols = (int.tryParse(c.text) ?? 3).clamp(1, 12).toInt();
    final anchor = cur;
    _struct(() {
      final body = doc!.findAllElements('w:body').first;
      XmlNode? n = anchor?.el;
      while (n != null && n.parent != body) {
        n = n.parent;
      }
      var at = body.children.length;
      if (n != null) {
        at = body.children.indexOf(n) + 1;
      } else {
        final sect = body.children.whereType<XmlElement>().where((e) => e.name.qualified == 'w:sectPr').lastOrNull;
        if (sect != null) at = body.children.indexOf(sect);
      }
      body.children.insert(at, _newTable(rows, cols));
      final next = body.children.skip(at + 1).whereType<XmlElement>().firstOrNull;
      if (next == null || next.name.qualified != 'w:p') body.children.insert(at + 1, _el('w:p'));
    });
  }

  void _tableOp(String op) {
    final q = cur;
    final tc = q == null ? null : _anc(q.el, 'w:tc');
    final tr = tc == null ? null : _anc(tc, 'w:tr');
    final tbl = tr == null ? null : _anc(tr, 'w:tbl');
    if (tc == null || tr == null || tbl == null) {
      snack(context, L.t('tapCell'));
      return;
    }
    _struct(() {
      final host = tr.parent!;
      final ri = host.children.indexOf(tr);
      final tcs = tr.findElements('w:tc').toList();
      final ci = tcs.indexOf(tc);
      final grid = tbl.findElements('w:tblGrid').firstOrNull;
      final gcs = grid?.findElements('w:gridCol').toList() ?? <XmlElement>[];
      switch (op) {
        case 'rowAbove':
          host.children.insert(ri, _blankRow(tr));
          break;
        case 'rowBelow':
          host.children.insert(ri + 1, _blankRow(tr));
          break;
        case 'delRow':
          if (tbl.findElements('w:tr').length <= 1) {
            tbl.remove();
          } else {
            tr.remove();
          }
          break;
        case 'delTable':
          tbl.remove();
          break;
        case 'colBefore':
        case 'colAfter':
          {
            final after = op == 'colAfter';
            for (final r in tbl.findElements('w:tr').toList()) {
              final cs = r.findElements('w:tc').toList();
              if (cs.isEmpty) continue;
              final src = ci < cs.length ? cs[ci] : cs.last;
              final nc = src.copy();
              _blankCell(nc);
              for (final gsp in (nc.findElements('w:tcPr').firstOrNull?.findElements('w:gridSpan').toList() ?? <XmlElement>[])) {
                gsp.remove();
              }
              r.children.insert(r.children.indexOf(src) + (after ? 1 : 0), nc);
            }
            if (grid != null && gcs.isNotEmpty) {
              final g = ci < gcs.length ? gcs[ci] : gcs.last;
              grid.children.insert(grid.children.indexOf(g) + (after ? 1 : 0), g.copy());
            }
            break;
          }
        case 'delCol':
          {
            if (tcs.length <= 1) {
              tbl.remove();
              break;
            }
            for (final r in tbl.findElements('w:tr').toList()) {
              final cs = r.findElements('w:tc').toList();
              if (cs.length > 1 && ci < cs.length) cs[ci].remove();
            }
            if (gcs.length > 1 && ci < gcs.length) gcs[ci].remove();
            break;
          }
      }
    });
  }

  String? _mark(int i) {
    final b = blocks[i];
    if (b is! _Para || b.deleted || b.fmt.list == 0) return null;
    if (b.fmt.list == 1) return '\u2022';
    var n = 1;
    for (var k = i - 1; k >= 0; k--) {
      final x = blocks[k];
      if (x is! _Para) break;
      if (x.deleted) continue;
      if (x.fmt.list != 2) break;
      n++;
    }
    return '$n.';
  }

  static TextAlign _ta(String? a) => a == 'center' ? TextAlign.center : a == 'right' ? TextAlign.right : a == 'both' ? TextAlign.justify : a == 'left' ? TextAlign.left : TextAlign.start;

  // ---------- insert: image / link / header-footer ----------
  static const _nsW = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';

  static String _esc(String t) => t.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');

  int _insAt(XmlElement body, _Para? anchor) {
    XmlNode? n = anchor?.el;
    while (n != null && n.parent != body) {
      n = n.parent;
    }
    if (n != null) return body.children.indexOf(n) + 1;
    final sect = body.children.whereType<XmlElement>().where((e) => e.name.qualified == 'w:sectPr').lastOrNull;
    return sect != null ? body.children.indexOf(sect) : body.children.length;
  }

  Future<void> _insertImage() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['png', 'jpg', 'jpeg', 'gif', 'bmp']);
    final path = res?.files.single.path;
    if (path == null || !mounted) return;
    final bytes = await File(path).readAsBytes();
    final ext = p_ext(path);
    var w = 400, h = 300;
    final im = img.decodeImage(bytes);
    if (im != null) {
      w = im.width;
      h = im.height;
    }
    var cx = w * 9525, cy = h * 9525;
    const maxW = 5029200;
    if (cx > maxW) {
      cy = (cy * maxW / cx).round();
      cx = maxW;
    }
    var k = 1;
    while (arc!.findFile('word/media/abtin$k.$ext') != null || pending.containsKey('word/media/abtin$k.$ext')) {
      k++;
    }
    final name = 'abtin$k.$ext';
    final ct = ext == 'png' ? 'image/png' : ext == 'gif' ? 'image/gif' : ext == 'bmp' ? 'image/bmp' : 'image/jpeg';
    final anchor = cur;
    _struct(() {
      pending['word/media/$name'] = bytes;
      _ensureCt(ct, ext: ext);
      final rid = _addRel('image', 'media/$name');
      final id = 1000 + (++_uid);
      final xml = '<w:p $_nsW xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture">'
          '<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="$cx" cy="$cy"/><wp:docPr id="$id" name="Picture $id"/>'
          '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr><pic:cNvPr id="0" name="$name"/><pic:cNvPicPr/></pic:nvPicPr>'
          '<pic:blipFill><a:blip r:embed="$rid"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
          '<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="$cx" cy="$cy"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r></w:p>';
      final body = doc!.findAllElements('w:body').first;
      body.children.insert(_insAt(body, anchor), XmlDocument.parse(xml).rootElement.copy());
    });
  }

  Future<void> _insertLink() async {
    final q = cur;
    final sel = q != null && _hasSel(q);
    final range = sel ? _range(q) : null;
    final a = TextEditingController(), b = TextEditingController(text: 'https://');
    final go = await showDialog<bool>(
      context: context,
      builder: (dc) => AlertDialog(
        title: Text(L.t('link')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          if (!sel) ...[
            TextField(controller: a, autofocus: true, decoration: InputDecoration(labelText: L.t('linkText'))),
            const SizedBox(height: 8),
          ],
          TextField(controller: b, autofocus: sel, keyboardType: TextInputType.url, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'URL')),
        ]),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(dc, false)),
          FilledButton(onPressed: () => Navigator.pop(dc, true), child: Text(L.t('ok'))),
        ],
      ),
    );
    var url = b.text.trim();
    if (go != true || !mounted || url.isEmpty || url == 'https://') return;
    if (!RegExp(r'^[a-zA-Z][a-zA-Z0-9+.-]*:').hasMatch(url)) url = 'https://$url';
    if (sel) {
      // link on the selected text itself
      _cfEdit((c) => c.with_(link: url, color: _linkBlue, u: true), para: q, range: range);
      return;
    }
    final text = a.text.trim().isEmpty ? url : a.text.trim();
    final anchor = cur;
    _struct(() {
      final rid = _addRel('hyperlink', url, external: true);
      final xml = '<w:p $_nsW><w:hyperlink r:id="$rid" w:history="1"><w:r><w:rPr><w:color w:val="0563C1"/><w:u w:val="single"/></w:rPr><w:t xml:space="preserve">${_esc(text)}</w:t></w:r></w:hyperlink></w:p>';
      final body = doc!.findAllElements('w:body').first;
      body.children.insert(_insAt(body, anchor), XmlDocument.parse(xml).rootElement.copy());
    });
  }

  XmlDocument? _partDoc(String part) {
    final d = pending[part] ?? (arc!.findFile(part)?.content as List<int>?);
    return d == null ? null : XmlDocument.parse(utf8.decode(d));
  }

  // ----- header / footer text <-> {PAGE} / {NUMPAGES} tokens -----
  static String? _fieldToken(String instr) {
    if (RegExp(r'^\s*PAGE(\s|$)', caseSensitive: false).hasMatch(instr)) return '{PAGE}';
    if (RegExp(r'^\s*NUMPAGES(\s|$)', caseSensitive: false).hasMatch(instr)) return '{NUMPAGES}';
    return null;
  }

  /// One header/footer paragraph as text; page-number fields become {PAGE} / {NUMPAGES}.
  static String _hfLine(XmlElement p) {
    final b = StringBuffer();
    var depth = 0;
    var collecting = false, skipResult = false;
    var instr = '';
    for (final r in _textRuns(p)) {
      final simple = _anc(r, 'w:fldSimple');
      if (simple != null) {
        final tok = _fieldToken(simple.getAttribute('w:instr') ?? '');
        if (tok != null) {
          // emit once, at the first run of the field
          if (simple.descendants.whereType<XmlElement>().firstWhere((e) => e.name.qualified == 'w:r') == r) b.write(tok);
          continue;
        }
      }
      final fc = r.findElements('w:fldChar').firstOrNull?.getAttribute('w:fldCharType');
      if (fc == 'begin') {
        depth++;
        collecting = true;
        skipResult = false;
        instr = '';
        continue;
      }
      if (fc == 'separate') {
        collecting = false;
        final tok = _fieldToken(instr);
        if (tok != null) {
          b.write(tok);
          skipResult = true;
        }
        continue;
      }
      if (fc == 'end') {
        if (depth > 0) depth--;
        collecting = false;
        skipResult = false;
        continue;
      }
      if (collecting) {
        instr += r.findElements('w:instrText').map((e) => e.innerText).join();
        continue;
      }
      if (skipResult) continue;
      b.write(_runText(r));
    }
    return b.toString();
  }

  /// Rewrites a header/footer paragraph from text (tokens become real page-number fields).
  void _hfFill(XmlElement para, String line) {
    final rpr0 = _textRuns(para).map((r) => r.findElements('w:rPr').firstOrNull).whereType<XmlElement>().firstOrNull?.copy();
    final at = _stripRuns(para);
    final nodes = <XmlNode>[];
    XmlElement mk(List<XmlNode> kids) => _el('w:r', {}, [if (rpr0 != null) rpr0.copy(), ...kids]);
    void addText(String s) {
      if (s.isNotEmpty) nodes.add(mk(_textKids(s)));
    }
    var i = 0;
    for (final m in RegExp(r'\{(PAGE|NUMPAGES)\}').allMatches(line)) {
      addText(line.substring(i, m.start));
      nodes.add(_el('w:fldSimple', {'w:instr': m.group(1) == 'PAGE' ? ' PAGE ' : ' NUMPAGES '}, [
        mk([_el('w:t', {}, [XmlText('1')])]),
      ]));
      i = m.end;
    }
    addText(line.substring(i));
    para.children.insertAll(at.clamp(0, para.children.length).toInt(), nodes);
  }

  static bool _on(XmlElement e) {
    final v = e.getAttribute('w:val');
    return v == null || (v != '0' && v != 'false');
  }

  static const _afterEven = ['w:bookFoldRevPrinting', 'w:bookFoldPrinting', 'w:bookFoldPrintingSheets', 'w:drawingGridHorizontalSpacing', 'w:drawingGridVerticalSpacing', 'w:displayHorizontalDrawingGridEvery', 'w:displayVerticalDrawingGridEvery', 'w:doNotUseMarginsForDrawingGridOrigin', 'w:drawingGridHorizontalOrigin', 'w:drawingGridVerticalOrigin', 'w:doNotShadeFormData', 'w:noPunctuationKerning', 'w:characterSpacingControl', 'w:printTwoOnOne', 'w:strictFirstAndLastChars', 'w:noLineBreaksAfter', 'w:noLineBreaksBefore', 'w:savePreviewPicture', 'w:doNotValidateAgainstSchema', 'w:saveInvalidXml', 'w:ignoreMixedContent', 'w:alwaysShowPlaceholderText', 'w:doNotDemarcateInvalidXml', 'w:saveXmlDataOnly', 'w:useXSLTWhenSaving', 'w:saveThroughXslt', 'w:showXMLTags', 'w:alwaysMergeEmptyNamespace', 'w:updateFields', 'w:hdrShapeDefaults', 'w:footnotePr', 'w:endnotePr', 'w:compat', 'w:docVars', 'w:rsids', 'm:mathPr', 'w:attachedSchema', 'w:themeFontLang', 'w:clrSchemeMapping', 'w:doNotIncludeSubdocsInStats', 'w:doNotAutoCompressPictures', 'w:forceUpgrade', 'w:captions', 'w:readModeInkLockDown', 'w:smartTagType', 'sl:schemaLibrary', 'w:shapeDefaults', 'w:doNotEmbedSmartTags', 'w:decimalSymbol', 'w:listSeparator'];
  static const _afterTitlePg = ['w:textDirection', 'w:bidi', 'w:rtlGutter', 'w:docGrid', 'w:printerSettings', 'w:sectPrChange'];

  Future<void> _headerFooter() async {
    final body = doc!.findAllElements('w:body').first;
    var sect = body.children.whereType<XmlElement>().where((e) => e.name.qualified == 'w:sectPr').lastOrNull;
    XmlElement ensureSect() {
      if (sect == null) {
        sect = _el('w:sectPr');
        body.children.add(sect!);
      }
      return sect!;
    }

    String? partOf(String tag, String type) {
      final ref = sect?.findElements(tag).where((e) => (e.getAttribute('w:type') ?? 'default') == type).firstOrNull;
      final id = ref?.getAttribute('r:id');
      final t = id == null ? null : rels[id];
      if (t == null) return null;
      return t.startsWith('/') ? t.substring(1) : 'word/$t';
    }

    String textOf(String? part) {
      final d = part == null ? null : _partDoc(part);
      return d == null ? '' : d.rootElement.findElements('w:p').map(_hfLine).join('\n');
    }

    const types = ['default', 'first', 'even'];
    final hp = {for (final t in types) t: partOf('w:headerReference', t)};
    final fp = {for (final t in types) t: partOf('w:footerReference', t)};
    final h0 = {for (final t in types) t: textOf(hp[t])};
    final f0 = {for (final t in types) t: textOf(fp[t])};
    final hc = {for (final t in types) t: TextEditingController(text: h0[t])};
    final fc = {for (final t in types) t: TextEditingController(text: f0[t])};

    final setRel = rels.values.where((t) => t.endsWith('settings.xml')).firstOrNull;
    final setPath = setRel == null ? 'word/settings.xml' : (setRel.startsWith('/') ? setRel.substring(1) : 'word/$setRel');
    final setDoc = setRel == null ? null : _partDoc(setPath);
    final titlePg0 = sect?.findElements('w:titlePg').any(_on) ?? false;
    final even0 = setDoc?.rootElement.findElements('w:evenAndOddHeaders').any(_on) ?? false;
    var first = titlePg0, even = even0;

    final focusNodes = <TextEditingController, FocusNode>{};
    TextEditingController last = hc['default']!;
    for (final c in [...hc.values, ...fc.values]) {
      final n = FocusNode();
      n.addListener(() {
        if (n.hasFocus) last = c;
      });
      focusNodes[c] = n;
    }
    void insTok(String tok) {
      final t = last.text;
      final s = last.selection;
      final a = s.isValid ? math.min(s.start, s.end) : t.length;
      final b = s.isValid ? math.max(s.start, s.end) : t.length;
      last.value = TextEditingValue(text: t.replaceRange(a, b, tok), selection: TextSelection.collapsed(offset: a + tok.length));
    }

    Widget fld(String label, TextEditingController c) => Padding(
          padding: const EdgeInsets.only(top: 8),
          child: TextField(controller: c, focusNode: focusNodes[c], maxLines: null, decoration: InputDecoration(labelText: label)),
        );

    final go = await showDialog<bool>(
      context: context,
      builder: (dc) => StatefulBuilder(
        builder: (dc, set) => AlertDialog(
          title: Text(L.t('headerFooter')),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                fld(L.t('header'), hc['default']!),
                fld(L.t('footer'), fc['default']!),
                Wrap(spacing: 4, children: [
                  ActionChip(label: Text(L.t('insPageNum')), onPressed: () => insTok('{PAGE}')),
                  ActionChip(label: Text(L.t('insPageCount')), onPressed: () => insTok('{NUMPAGES}')),
                ]),
                CheckboxListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  value: first,
                  title: Text(L.t('diffFirst')),
                  onChanged: (v) => set(() => first = v ?? false),
                ),
                if (first) ...[fld(L.t('firstHeader'), hc['first']!), fld(L.t('firstFooter'), fc['first']!)],
                CheckboxListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  value: even,
                  title: Text(L.t('diffEven')),
                  onChanged: (v) => set(() => even = v ?? false),
                ),
                if (even) ...[fld(L.t('evenHeader'), hc['even']!), fld(L.t('evenFooter'), fc['even']!)],
              ]),
            ),
          ),
          actions: [
            CancelButton(onPressed: () => Navigator.pop(dc, false)),
            FilledButton(onPressed: () => Navigator.pop(dc, true), child: Text(L.t('ok'))),
          ],
        ),
      ),
    );
    if (go != true || !mounted) return;
    _commit();
    _flush();

    void apply(String? part, String kind, String type, String text, String old) {
      if (text == old) return;
      XmlDocument? d;
      var fresh = false;
      if (part == null) {
        if (text.trim().isEmpty) return;
        var n = 1;
        while (arc!.findFile('word/$kind$n.xml') != null || pending.containsKey('word/$kind$n.xml')) {
          n++;
        }
        part = 'word/$kind$n.xml';
        final tag = kind == 'header' ? 'w:hdr' : 'w:ftr';
        d = XmlDocument.parse('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><$tag $_nsW><w:p/></$tag>');
        _ensureCt('application/vnd.openxmlformats-officedocument.wordprocessingml.$kind+xml', part: '/$part');
        final rid = _addRel(kind, '$kind$n.xml');
        ensureSect().children.insert(0, _el('w:${kind}Reference', {'w:type': type, 'r:id': rid}));
        fresh = true;
      } else {
        d = _partDoc(part);
      }
      if (d == null) return;
      final root = d.rootElement;
      final ps = root.findElements('w:p').toList();
      final lines = text.split('\n');
      for (var i = 0; i < lines.length; i++) {
        if (i < ps.length) {
          if (_hfLine(ps[i]) != lines[i]) _hfFill(ps[i], lines[i]);
        } else {
          final np = _el('w:p');
          root.children.add(np);
          _hfFill(np, lines[i]);
        }
      }
      for (var i = lines.length; i < ps.length; i++) {
        ps[i].remove();
      }
      if (fresh && kind == 'footer' && text.contains('{')) {
        for (final pp in root.findElements('w:p')) {
          _putP(pp, 'w:jc', _el('w:jc', {'w:val': 'center'}));
        }
      }
      pending[part] = utf8.encode(d.toXmlString());
    }

    for (final t in types) {
      if (t == 'first' && !first) continue;
      if (t == 'even' && !even) continue;
      apply(hp[t], 'header', t, hc[t]!.text, h0[t]!);
      apply(fp[t], 'footer', t, fc[t]!.text, f0[t]!);
    }

    if (first != titlePg0) {
      final s = ensureSect();
      s.children.removeWhere((n) => n is XmlElement && n.name.qualified == 'w:titlePg');
      if (first) {
        final idx = s.children.indexWhere((n) => n is XmlElement && _afterTitlePg.contains(n.name.qualified));
        s.children.insert(idx < 0 ? s.children.length : idx, _el('w:titlePg'));
      }
    }

    if (even != even0) {
      var sd = setDoc;
      if (sd == null) {
        sd = XmlDocument.parse('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:settings $_nsW></w:settings>');
        _ensureCt('application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml', part: '/$setPath');
        _addRel('settings', 'settings.xml');
      }
      final root = sd.rootElement;
      root.children.removeWhere((n) => n is XmlElement && n.name.qualified == 'w:evenAndOddHeaders');
      if (even) {
        final idx = root.children.indexWhere((n) => n is XmlElement && _afterEven.contains(n.name.qualified));
        root.children.insert(idx < 0 ? root.children.length : idx, _el('w:evenAndOddHeaders'));
      }
      pending[setPath] = utf8.encode(sd.toXmlString());
    }

    setState(() {
      _rebuild();
      dirty = true;
    });
  }

  // ---------- save ----------
  Future<void> _save({bool copy = false}) async {
    if (!await ensureSdAll(context, [widget.path])) return;
    if (!mounted) return;
    _commit();
    final ok = await busy(context, () async {
      _flush();
      final extra = <String, List<int>>{...pending};
      if (numDirty && numDoc != null) {
        extra['word/numbering.xml'] = utf8.encode(numDoc!.toXmlString());
        _wireNumbering();
      }
      if (relsDirty && relsDoc != null) extra['word/_rels/document.xml.rels'] = utf8.encode(relsDoc!.toXmlString());
      if (ctDirty && ctDoc != null) extra['[Content_Types].xml'] = utf8.encode(ctDoc!.toXmlString());
      final out = Archive();
      final seen = <String>{};
      for (final f in arc!.files) {
        final List<int>? b = f.name == 'word/document.xml' ? utf8.encode(doc!.toXmlString()) : extra[f.name];
        if (b != null) {
          out.addFile(ArchiveFile(f.name, b.length, b));
          seen.add(f.name);
        } else {
          out.addFile(f);
        }
      }
      for (final e in extra.entries) {
        if (!seen.contains(e.key)) out.addFile(ArchiveFile(e.key, e.value.length, e.value));
      }
      final enc = ZipEncoder().encode(out)!;
      final target = copy ? FileOps.unique(p.dirname(widget.path), '${p.basenameWithoutExtension(widget.path)} (edited)${p.extension(widget.path)}') : widget.path;
      await Saf.writeBytes(target, enc);
    });
    if (ok && mounted) {
      snack(context, L.t('done'));
      setState(() { loading = true; dirty = false; });
      await _load();
    }
  }

  // ---------- UI ----------
  static TextDirection _dir(String t) {
    for (final r in t.runes) {
      if ((r >= 0x0590 && r <= 0x08FF) || (r >= 0xFB50 && r <= 0xFEFF)) return TextDirection.rtl;
      if ((r >= 0x41 && r <= 0x5A) || (r >= 0x61 && r <= 0x7A)) return TextDirection.ltr;
    }
    return L.rtl ? TextDirection.rtl : TextDirection.ltr;
  }

  Widget _field(_Para q) {
    final f = q.fmt;
    final base = q.heading ? font + 6 : font;
    q.c.scale = font / 12;
    final empty = q.c.text.isEmpty;
    return TextField(
      controller: q.c,
      focusNode: q.focus,
      maxLines: null,
      textDirection: _dir(q.c.text),
      textAlign: _ta(f.align),
      onChanged: (_) => _touch(),
      style: TextStyle(
        fontSize: empty && q.c.ins.size != null ? q.c.ins.size! * font / 12 : base,
        fontWeight: (empty && q.c.ins.b) || q.heading ? FontWeight.bold : FontWeight.normal,
        fontStyle: empty && q.c.ins.i ? FontStyle.italic : FontStyle.normal,
        decoration: empty && q.c.ins.u ? TextDecoration.underline : TextDecoration.none,
        color: empty ? q.c.ins.color : null,
      ),
      decoration: const InputDecoration(border: InputBorder.none, filled: false, isDense: true, contentPadding: EdgeInsets.symmetric(vertical: 6)),
    );
  }

  static const _cInsC = Color(0xFF2E7D32), _cDelC = Color(0xFFC62828), _cCmtC = Color(0xFFF9A825);

  static String _revName(String k) => L.t(k == 'ins' ? 'revInserted' : k == 'del' ? 'revDeleted' : k == 'moveFrom' ? 'revMovedFrom' : k == 'moveTo' ? 'revMovedTo' : 'revFormatted');

  Widget _revLine(_Rev r, {bool snippet = true}) {
    final del = r.kind == 'del' || r.kind == 'moveFrom';
    final col = r.kind == 'fmt' ? Colors.blueGrey : del ? _cDelC : _cInsC;
    final who = [r.author, r.date].where((e) => e.isNotEmpty).join(' · ');
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1),
      child: Text.rich(TextSpan(children: [
        TextSpan(text: '${_revName(r.kind)}${r.text.isEmpty ? '' : ': '}', style: TextStyle(color: col, fontWeight: FontWeight.w600)),
        if (r.text.isNotEmpty) TextSpan(text: r.text, style: TextStyle(color: col, decoration: del ? TextDecoration.lineThrough : TextDecoration.underline)),
        if (who.isNotEmpty) TextSpan(text: '  ($who)', style: const TextStyle(color: Colors.grey)),
      ]), style: const TextStyle(fontSize: 12.5)),
    );
  }

  Widget _cmtCard(_Cmt c) => Container(
        margin: const EdgeInsets.only(top: 3),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(color: _cCmtC.withOpacity(0.14), border: Border(left: BorderSide(color: _cCmtC, width: 3)), borderRadius: BorderRadius.circular(4)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            const Icon(Icons.comment_rounded, size: 14, color: _cCmtC),
            const SizedBox(width: 4),
            Expanded(child: Text([c.author, c.date].where((e) => e.isNotEmpty).join(' · '), style: const TextStyle(fontSize: 11.5, color: Colors.grey))),
          ]),
          SelectableText(c.text, style: const TextStyle(fontSize: 13.5)),
        ]),
      );

  /// Comments and tracked changes of a paragraph (read-only), shown under it.
  Widget _markupW(_Para q) {
    if (!showMarkup || q.deleted || (q.cmts.isEmpty && q.revs.isEmpty)) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 6),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        for (final r in q.revs) _revLine(r),
        for (final c in q.cmts) _cmtCard(c),
      ]),
    );
  }

  Widget _cellW(_Para q) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [_field(q), _markupW(q)]);

  int get _markupCount => allParas.fold<int>(0, (n, q) => n + q.cmts.length + q.revs.length);

  void _markupSheet() {
    final items = <Widget>[];
    for (final q in allParas) {
      if (q.cmts.isEmpty && q.revs.isEmpty) continue;
      final snip = q.c.text.length > 70 ? '${q.c.text.substring(0, 70)}…' : q.c.text;
      items.add(Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 2),
        child: Text(snip.isEmpty ? '¶' : snip, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
      ));
      for (final r in q.revs) {
        items.add(Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: _revLine(r)));
      }
      for (final c in q.cmts) {
        items.add(Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: _cmtCard(c)));
      }
      items.add(const Divider(height: 14));
    }
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (c) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.7,
        builder: (c, sc) => Column(children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text('${L.t('commentsChanges')} (${_markupCount})', style: Theme.of(context).textTheme.titleMedium),
          ),
          Expanded(
            child: items.isEmpty
                ? Center(child: Text(L.t('noComments')))
                : ListView(controller: sc, children: items),
          ),
        ]),
      ),
    );
  }

  Widget _paraW(_Para q, [String? mark]) {
    if (q.deleted) return const SizedBox.shrink();
    final tag = q.tag;
    final box = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      for (final img in q.images)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: ConstrainedBox(constraints: const BoxConstraints(maxHeight: 320), child: Image.memory(img, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_rounded))),
        ),
      Directionality(
        textDirection: _dir(q.c.text),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (mark != null)
            Padding(padding: const EdgeInsets.fromLTRB(6, 6, 6, 0), child: Text(mark, style: TextStyle(fontSize: font))),
          Expanded(child: _field(q)),
          IconButton(
            visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.close_rounded, size: 16),
            onPressed: () => setState(() { q.deleted = true; dirty = true; _commit(); }),
          ),
        ]),
      ),
      _markupW(q),
    ]);
    if (tag == null) return box;
    final tb = tag == L.t('textBox');
    final col = Theme.of(context).colorScheme.primary;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 3),
      padding: const EdgeInsetsDirectional.only(start: 8),
      decoration: BoxDecoration(
        border: tb ? Border.all(color: col.withOpacity(0.5)) : BorderDirectional(start: BorderSide(color: col.withOpacity(0.6), width: 3)),
        borderRadius: tb ? BorderRadius.circular(6) : null,
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.only(top: 3),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(tb ? Icons.crop_square_rounded : Icons.edit_note_rounded, size: 13, color: col),
            const SizedBox(width: 4),
            Text(tag, style: TextStyle(fontSize: 11, color: col)),
          ]),
        ),
        box,
      ]),
    );
  }

  Widget _tblW(_Tbl t) {
    final cols = t.rows.fold<int>(0, (m, r) => r.length > m ? r.length : m);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Table(
          defaultColumnWidth: const FixedColumnWidth(160),
          border: TableBorder.all(color: Colors.grey.shade600),
          children: [
            for (final r in t.rows)
              TableRow(children: [
                for (var i = 0; i < cols; i++)
                  i < r.length
                      ? Padding(padding: const EdgeInsets.symmetric(horizontal: 6), child: Column(children: [for (final q in r[i]) _cellW(q)]))
                      : const SizedBox(height: 40),
              ]),
          ],
        ),
      ),
    );
  }

  static const _sizes = <double>[8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 72];

  Widget _vDivider() => const SizedBox(height: 26, child: VerticalDivider(width: 14, thickness: 1, color: Color(0xFFD3D8E3)));

  Widget _toolbar() {
    final q = cur;
    final f = q?.fmt;
    bool on(bool Function(_CF) t) => q != null && _all(q, t);
    final sz = q == null ? null : _sizeOf(q);
    final col = q == null ? null : _colorOf(q);
    const ink = kOfficeInk;
    Widget letter(String t, {FontWeight? w, FontStyle? st, TextDecoration? d}) =>
        Text(t, style: TextStyle(fontSize: 22, color: ink, fontWeight: w, fontStyle: st, decoration: d, decorationThickness: 2, height: 1.1));
    Widget align(IconData ic, String v, String tip) => OfficeToolButton(
          selected: f?.align == v,
          tip: tip,
          onTap: () => _fmt((x) => x.align = x.align == v ? null : v),
          child: Icon(ic, size: 26, color: ink),
        );
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
        color: kOfficeStrip,
        height: 56,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [
            const SizedBox(width: 8),
            OfficeToolButton(width: 44, selected: on((c) => c.b), tip: L.t('bold'), onTap: () => _toggle((c) => c.b, (c, v) => c.with_(b: v)), child: letter('B', w: FontWeight.w900)),
            OfficeToolButton(width: 44, selected: on((c) => c.i), tip: L.t('italic'), onTap: () => _toggle((c) => c.i, (c, v) => c.with_(i: v)), child: letter('I', st: FontStyle.italic)),
            OfficeToolButton(width: 44, selected: on((c) => c.u), tip: L.t('underline'), onTap: () => _toggle((c) => c.u, (c, v) => c.with_(u: v)), child: letter('U', d: TextDecoration.underline)),
            PopupMenuButton<double>(
              tooltip: tr2('اندازه قلم', 'Font size'),
              onSelected: (v) => _cfEdit((c) => c.with_(size: v)),
              itemBuilder: (_) => [for (final v in _sizes) PopupMenuItem(value: v, child: Text(faDigits(v.round())))],
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(faDigits((sz ?? 14).round()), style: const TextStyle(fontSize: 19, color: ink)),
                  const Icon(Icons.keyboard_arrow_down_rounded, size: 24, color: ink),
                ]),
              ),
            ),
            PopupMenuButton<int>(
              tooltip: L.t('color'),
              onSelected: (i) => _cfEdit((c) => _palette[i] == null ? c.with_(noColor: true) : c.with_(color: _palette[i])),
              itemBuilder: (_) => [
                for (var i = 0; i < _palette.length; i++)
                  PopupMenuItem(value: i, child: Row(children: [Icon(Icons.circle, color: _palette[i] ?? Colors.grey, size: 18), const SizedBox(width: 8), Text(_palette[i] == null ? 'Auto' : '#${(_palette[i]!.value & 0xFFFFFF).toRadixString(16).padLeft(6, '0')}')])),
              ],
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Column(mainAxisSize: MainAxisSize.min, children: [
                    const Text('A', style: TextStyle(fontSize: 26, color: ink, fontWeight: FontWeight.w500, height: 1)),
                    Container(width: 24, height: 4, margin: const EdgeInsets.only(top: 2), color: col ?? const Color(0xFFE53935)),
                  ]),
                  const Icon(Icons.keyboard_arrow_down_rounded, size: 24, color: ink),
                ]),
              ),
            ),
            _vDivider(),
            align(Icons.format_align_left_rounded, 'left', L.t('alignLeft')),
            align(Icons.format_align_center_rounded, 'center', L.t('alignCenter')),
            align(Icons.format_align_right_rounded, 'right', L.t('alignRight')),
            _vDivider(),
            OfficeToolButton(
              tip: L.t('undo'),
              onTap: undo.isEmpty && _deb == null ? null : _doUndo,
              child: Icon(Icons.undo_rounded, size: 26, color: undo.isEmpty && _deb == null ? ink.withOpacity(.35) : ink),
            ),
            const SizedBox(width: 8),
          ]),
        ),
      ),
    );
  }

  void _addPara() => setState(() {
        final q = _Para(XmlElement(XmlName('w:p')), '', _Fmt(), false, isNew: true);
        q.focus.addListener(() {
          if (q.focus.hasFocus && mounted) setState(() => cur = q);
        });
        blocks.add(q);
        dirty = true;
        _commit();
      });

  Future<void> _sheet(String title, List<(IconData, String, VoidCallback)> rows) {
    return showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (c) => Theme(
        data: officeTheme(context),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(padding: const EdgeInsets.only(bottom: 6), child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
              for (final r in rows)
                ListTile(
                  leading: Icon(r.$1, color: kOfficeBlue),
                  title: Text(r.$2),
                  onTap: () {
                    Navigator.pop(c);
                    r.$3();
                  },
                ),
              const SizedBox(height: 8),
            ]),
          ),
        ),
      ),
    );
  }

  void _toolsSheet() => _sheet(tr2('ابزارها', 'Tools'), [
        (Icons.add_circle_outline_rounded, L.t('addPara'), _addPara),
        (Icons.redo_rounded, L.t('redo'), () { if (redo.isNotEmpty) _doRedo(); }),
        (Icons.format_list_bulleted_rounded, L.t('bullets'), () => _fmt((x) => x.list = x.list == 1 ? 0 : 1)),
        (Icons.format_list_numbered_rounded, L.t('numbering'), () => _fmt((x) => x.list = x.list == 2 ? 0 : 2)),
        (Icons.format_align_justify_rounded, L.t('justify'), () => _fmt((x) => x.align = x.align == 'both' ? null : 'both')),
        (Icons.link_rounded, L.t('link'), _insertLink),
        (Icons.link_off_rounded, L.t('removeLink'), _unlink),
        (Icons.vertical_split_rounded, L.t('headerFooter'), _headerFooter),
        (Icons.find_replace_rounded, L.t('findReplace'), _findReplace),
        (Icons.text_decrease_rounded, tr2('کوچک‌کردن نمایش متن', 'Zoom out'), () => setState(() => font = (font - 1).clamp(10, 36).toDouble())),
        (Icons.text_increase_rounded, tr2('بزرگ‌کردن نمایش متن', 'Zoom in'), () => setState(() => font = (font + 1).clamp(10, 36).toDouble())),
      ]);

  void _tableSheet() => _sheet(L.t('table'), [
        for (final e in const {'insert': 'insertTable', 'rowAbove': 'rowAbove', 'rowBelow': 'rowBelow', 'colBefore': 'colBefore', 'colAfter': 'colAfter', 'delRow': 'delRow', 'delCol': 'delCol', 'delTable': 'delTable'}.entries)
          (e.key == 'insert' ? Icons.table_chart_outlined : e.key.startsWith('del') ? Icons.delete_outline_rounded : Icons.add_box_outlined, L.t(e.value), () => e.key == 'insert' ? _insertTable() : _tableOp(e.key)),
      ]);

  /// Outline: first words of every non-empty paragraph; tapping one scrolls the page to that place.
  void _outlineSheet() {
    final items = <(int, String, bool)>[];
    for (var i = 0; i < blocks.length; i++) {
      final b = blocks[i];
      if (b is _Para && !b.deleted && b.c.text.trim().isNotEmpty) {
        final t = b.c.text.trim().replaceAll('\n', ' ');
        items.add((i, t.length > 60 ? '${t.substring(0, 60)}…' : t, b.heading));
      } else if (b is _Tbl) {
        items.add((i, tr2('جدول', 'Table'), true));
      }
    }
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (c) => Theme(
        data: officeTheme(context),
        child: SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .7),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(tr2('فهرست', 'Outline'), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              const SizedBox(height: 6),
              Flexible(
                child: items.isEmpty
                    ? Padding(padding: const EdgeInsets.all(24), child: Text(L.t('empty')))
                    : ListView.builder(
                        shrinkWrap: true,
                        itemCount: items.length,
                        itemBuilder: (_, k) {
                          final it = items[k];
                          return ListTile(
                            dense: true,
                            leading: Icon(it.$3 ? Icons.title_rounded : Icons.notes_rounded, color: kOfficeBlue, size: 20),
                            title: Text(it.$2, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: it.$3 ? FontWeight.w700 : FontWeight.w400)),
                            onTap: () {
                              Navigator.pop(c);
                              if (_scroll.hasClients) {
                                final max = _scroll.position.maxScrollExtent;
                                final y = blocks.length <= 1 ? 0.0 : max * it.$1 / (blocks.length - 1);
                                _scroll.animateTo(y.clamp(0.0, max).toDouble(), duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
                              }
                            },
                          );
                        },
                      ),
              ),
            ]),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: !dirty,
        onPopInvokedWithResult: (did, _) async {
          if (did) return;
          if (await confirm(context, '${L.t('save')}?') && mounted) await _save();
          if (mounted) Navigator.pop(context);
        },
        child: Theme(
          data: officeTheme(context),
          child: Scaffold(
            backgroundColor: kOfficeBg,
            bottomNavigationBar: loading
                ? null
                : OfficeBottomBar(items: [
                    OfficeBarItem(Icons.format_list_bulleted_rounded, tr2('فهرست', 'Outline'), _outlineSheet),
                    OfficeBarItem(Icons.image_outlined, tr2('افزودن تصویر', 'Add image'), _insertImage),
                    OfficeBarItem(Icons.grid_view_rounded, tr2('جدول', 'Table'), _tableSheet),
                    OfficeBarItem(Icons.chat_bubble_outline_rounded, tr2('نظر', 'Comments'), _markupSheet),
                    OfficeBarItem(Icons.note_add_outlined, tr2('ابزارها', 'Tools'), _toolsSheet),
                  ]),
            body: Column(children: [
              OfficeTopBar(
                title: p.basename(widget.path),
                onBack: () => Navigator.maybePop(context),
                actions: [
                  officeAction(Icons.save_rounded, loading ? null : _save, tip: L.t('save'), color: dirty ? const Color(0xFFFFD54F) : null),
                  PopupMenuButton<int>(
                    icon: const Icon(Icons.more_vert_rounded, color: Colors.white, size: 26),
                    onSelected: (v) => v == 2 ? setState(() => showMarkup = !showMarkup) : _save(copy: v == 1),
                    itemBuilder: (_) => [
                      PopupMenuItem(value: 1, child: Text(L.t('saveCopy'))),
                      CheckedPopupMenuItem(value: 2, checked: showMarkup, child: Text(L.t('showMarkup'))),
                    ],
                  ),
                ],
              ),
              if (loading)
                const Expanded(child: Center(child: CircularProgressIndicator()))
              else ...[
                _toolbar(),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 12, 12, 0),
                    child: Material(
                      color: Colors.white,
                      elevation: 1.5,
                      borderRadius: const BorderRadius.vertical(top: Radius.circular(6)),
                      child: ListView.builder(
                        controller: _scroll,
                        padding: const EdgeInsets.fromLTRB(18, 30, 18, 40),
                        itemCount: blocks.length,
                        itemBuilder: (c, i) {
                          final b = blocks[i];
                          return b is _Para ? _paraW(b, _mark(i)) : _tblW(b as _Tbl);
                        },
                      ),
                    ),
                  ),
                ),
              ],
            ]),
          ),
        ),
      );
}
