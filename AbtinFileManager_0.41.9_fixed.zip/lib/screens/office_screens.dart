import 'dart:io';
export 'pptx_screen.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../core/layouts.dart';
import '../widgets/office_chrome.dart';
import '../services/doc_legacy.dart' show DocPara, DocRun;
import '../services/file_ops.dart';
import '../services/legacy_office.dart';
import '../services/odf_service.dart';
import '../services/rtf_doc.dart';
import '../services/native.dart';
import '../services/office_service.dart';
import '../widgets/ui.dart';

Future<String?> _editDialog(BuildContext c, String initial, {String? title}) {
  final ctl = TextEditingController(text: initial);
  return showDialog<String>(
    context: c,
    builder: (_) => AlertDialog(
      title: title == null ? null : Text(title),
      content: TextField(controller: ctl, autofocus: true, minLines: 1, maxLines: 10),
      actions: [
        CancelButton(onPressed: () => Navigator.pop(c)),
        FilledButton(onPressed: () => Navigator.pop(c, ctl.text), child: Text(L.t('ok'))),
      ],
    ),
  );
}

Future<void> _saved(BuildContext c, String target) async {
  Native.scan(target);
  if (c.mounted) snack(c, '${L.t('saved')}: ${p.basename(target)}');
}

/// .xlsx / .xlsm: sheet tabs, grid, tap a cell to edit; saving creates "<name> (edited).xlsx".
class XlsxScreen extends StatefulWidget {
  final String path;
  const XlsxScreen({super.key, required this.path});
  @override
  State<XlsxScreen> createState() => _XlsxScreenState();
}

class _XlsxScreenState extends State<XlsxScreen> {
  XlsxFile? x;
  int cur = 0;
  String selectedRef = 'A1';
  static const rh = 36.0, hw = 46.0;
  static const _line = Color(0xFFD9DDE6);
  static const _headBg = Color(0xFFEEF0F5);
  static const _rowOneBg = Color(0xFFE4F1E8);

  @override
  void initState() {
    super.initState();
    XlsxFile.open(widget.path).then((v) { if (mounted) setState(() => x = v); }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  (int, int) _selRC() {
    final m = RegExp(r'^([A-Z]+)(\d+)$').firstMatch(selectedRef);
    if (m == null) return (0, 1);
    return (colIndex(m[1]!), int.parse(m[2]!));
  }

  Future<void> _edit(XSheet sh, String ref, {String? initial}) async {
    selectedRef = ref.toUpperCase();
    final r = await _editDialog(context, initial ?? (sh.formulas.containsKey(ref) ? '=${sh.formulas[ref]}' : (sh.cells[ref] ?? '')), title: ref);
    if (r != null) setState(() => x!.setCell(sh, ref, r));
    else if (mounted) setState(() {});
  }

  void _setCell(XSheet sh, String ref, String value) {
    setState(() {
      selectedRef = ref.toUpperCase();
      x!.setCell(sh, selectedRef, value);
    });
  }

  static const _fills = [0xFFF176, 0xA5D6A7, 0x90CAF9, 0xEF9A9A, 0xCE93D8, 0xFFCC80];

  /// Bottom sheet for the selected cell: [format] = bold + fill colour, [insert] = rows / columns.
  Future<void> _cellMenu(XSheet sh, int c, int r, {bool format = true, bool insert = true}) async {
    final ref = '${colName(c)}$r';
    if (mounted) setState(() => selectedRef = ref);
    final st = sh.styles[ref];
    Widget item(IconData ic, String t, VoidCallback f) => ListTile(dense: true, leading: Icon(ic, color: kOfficeGreen), title: Text(t), onTap: () { Navigator.pop(context); setState(f); });
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => Theme(
        data: officeTheme(context),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(ref, style: const TextStyle(fontWeight: FontWeight.bold))),
              if (format) ...[
                item(Icons.format_bold_rounded, L.t('bold'), () => x!.setStyle(sh, ref, bold: !(st?.bold ?? false))),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Wrap(spacing: 10, children: [
                    for (final col in _fills)
                      GestureDetector(
                        onTap: () { Navigator.pop(context); setState(() => x!.setStyle(sh, ref, fill: col)); },
                        child: CircleAvatar(radius: 15, backgroundColor: Color(0xFF000000 | col)),
                      ),
                    GestureDetector(
                      onTap: () { Navigator.pop(context); setState(() => x!.setStyle(sh, ref, fill: -1)); },
                      child: const CircleAvatar(radius: 15, backgroundColor: Colors.black26, child: Icon(Icons.format_color_reset_rounded, size: 16)),
                    ),
                  ]),
                ),
              ],
              if (insert) ...[
                item(Icons.table_rows_rounded, L.t('rowAbove'), () => x!.shiftRows(sh, r, insert: true)),
                item(Icons.table_rows_rounded, L.t('rowBelow'), () => x!.shiftRows(sh, r + 1, insert: true)),
                item(Icons.delete_outline_rounded, L.t('delRow'), () => x!.shiftRows(sh, r, insert: false)),
                item(Icons.view_column_rounded, L.t('colLeft'), () => x!.shiftCols(sh, c, insert: true)),
                item(Icons.view_column_rounded, L.t('colRight'), () => x!.shiftCols(sh, c + 1, insert: true)),
                item(Icons.delete_outline_rounded, L.t('delCol'), () => x!.shiftCols(sh, c, insert: false)),
              ],
              const SizedBox(height: 8),
            ]),
          ),
        ),
      ),
    );
  }

  static const _funcs = <(String, String, String)>[
    ('SUM', 'جمع اعداد', 'Sum of numbers'),
    ('AVERAGE', 'میانگین', 'Average'),
    ('COUNT', 'شمارش اعداد', 'Count numbers'),
    ('MAX', 'بیشترین مقدار', 'Largest value'),
    ('MIN', 'کمترین مقدار', 'Smallest value'),
    ('ROUND', 'گرد کردن', 'Round'),
    ('IF', 'شرط', 'Condition'),
    ('CONCAT', 'چسباندن متن', 'Join text'),
  ];

  Future<void> _functionsSheet(XSheet sh) async {
    final (c, r) = _selRC();
    final col = colName(c);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => Theme(
        data: officeTheme(context),
        child: SafeArea(
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Padding(padding: const EdgeInsets.only(bottom: 6), child: Text(tr2('توابع', 'Functions'), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
              for (final fn in _funcs)
                ListTile(
                  dense: true,
                  leading: const Text('fx', style: TextStyle(fontStyle: FontStyle.italic, fontFamily: 'serif', fontSize: 20, color: kOfficeGreen)),
                  title: Text(fn.$1, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(tr2(fn.$2, fn.$3)),
                  onTap: () {
                    Navigator.pop(context);
                    final range = r > 2 ? '${col}2:$col${r - 1}' : '';
                    final body = fn.$1 == 'IF' ? '${colName(c)}${r > 1 ? r - 1 : 1}>0,1,0' : (fn.$1 == 'ROUND' ? '$col${r > 1 ? r - 1 : 1},0' : range);
                    _edit(sh, selectedRef, initial: '=${fn.$1}($body)');
                  },
                ),
              const SizedBox(height: 8),
            ]),
          ),
        ),
      ),
    );
  }

  Future<void> _gotoCell() async {
    final v = await promptText(context, tr2('رفتن به سلول', 'Go to cell'), initial: selectedRef);
    if (v == null || !mounted) return;
    final ref = v.trim().toUpperCase();
    if (!RegExp(r'^[A-Z]{1,3}[1-9]\d{0,5}$').hasMatch(ref)) {
      snack(context, tr2('آدرس سلول نامعتبر است', 'Invalid cell address'));
      return;
    }
    setState(() => selectedRef = ref);
  }

  Future<void> _sheetsList(XlsxFile f) async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (c) => Theme(
        data: officeTheme(context),
        child: SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (var i = 0; i < f.sheets.length; i++)
              ListTile(
                leading: Icon(Icons.grid_on_rounded, color: i == cur ? kOfficeGreen : null),
                title: Text(f.sheets[i].name, style: TextStyle(fontWeight: i == cur ? FontWeight.w800 : FontWeight.w400, color: i == cur ? kOfficeGreen : null)),
                onTap: () { Navigator.pop(c); setState(() { cur = i; selectedRef = 'A1'; }); },
              ),
            const SizedBox(height: 8),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    final sh = (f != null && f.sheets.isNotEmpty) ? f.sheets[cur.clamp(0, f.sheets.length - 1).toInt()] : null;
    return Theme(
      data: officeTheme(context),
      child: Scaffold(
        backgroundColor: Colors.white,
        bottomNavigationBar: sh == null
            ? null
            : Column(mainAxisSize: MainAxisSize.min, children: [
                _tabs(f!),
                OfficeBottomBar(dark: true, items: [
                  OfficeBarItem(Icons.keyboard_alt_outlined, tr2('صفحه‌کلید', 'Keyboard'), () => _edit(sh, selectedRef)),
                  OfficeBarItem(Icons.grid_view_rounded, tr2('درج', 'Insert'), () { final (c, r) = _selRC(); _cellMenu(sh, c, r, format: false); }),
                  OfficeBarItem(Icons.format_color_text_rounded, tr2('قالب سلول', 'Cell format'), () { final (c, r) = _selRC(); _cellMenu(sh, c, r, insert: false); }),
                  OfficeBarItem(Icons.functions_rounded, tr2('توابع', 'Functions'), () => _functionsSheet(sh)),
                ]),
              ]),
        body: Column(children: [
          OfficeTopBar(
            title: p.basename(widget.path),
            actions: [
              officeAction(Icons.save_rounded, f == null || !f.z.changed ? null : () async {
                if (!await ensureSdAll(context, [widget.path])) return;
                final t = await f.saveCopy();
                if (mounted) await _saved(context, t);
              }, tip: L.t('saveCopy')),
              PopupMenuButton<String>(
                icon: const Icon(Icons.more_vert_rounded, color: Colors.white, size: 26),
                onSelected: (v) async {
                  if (v == 'open') Native.openWith(widget.path, title: L.t('openWith'));
                  if (v == 'copy' && f != null) {
                    if (!await ensureSdAll(context, [widget.path])) return;
                    final t = await f.saveCopy();
                    if (mounted) await _saved(context, t);
                  }
                },
                itemBuilder: (_) => [
                  PopupMenuItem(value: 'open', child: Text(L.t('openWith'))),
                  PopupMenuItem(value: 'copy', child: Text(L.t('saveCopy'))),
                ],
              ),
            ],
          ),
          if (f == null)
            const Expanded(child: Center(child: CircularProgressIndicator()))
          else if (f.sheets.isEmpty)
            Expanded(child: Center(child: Text(L.t('empty'))))
          else ...[
            _formulaBar(sh!),
            Expanded(child: _grid(sh)),
          ],
        ]),
      ),
    );
  }

  Widget _tabs(XlsxFile f) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
        height: 50,
        decoration: const BoxDecoration(color: _headBg, border: Border(top: BorderSide(color: _line))),
        child: Row(children: [
          IconButton(icon: const Icon(Icons.menu_rounded, color: kOfficeInk), onPressed: () => _sheetsList(f)),
          Flexible(
            child: ListView(scrollDirection: Axis.horizontal, shrinkWrap: true, children: [
              for (var i = 0; i < f.sheets.length; i++)
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => setState(() { cur = i; selectedRef = 'A1'; }),
                  child: Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(horizontal: 22),
                    decoration: BoxDecoration(
                      color: i == cur ? Colors.white : null,
                      border: Border(bottom: BorderSide(color: i == cur ? kOfficeGreen : Colors.transparent, width: 3)),
                    ),
                    child: Text(f.sheets[i].name, style: TextStyle(fontSize: 17, fontWeight: i == cur ? FontWeight.w800 : FontWeight.w500, color: i == cur ? kOfficeGreen : kOfficeInk)),
                  ),
                ),
            ]),
          ),
          IconButton(
            icon: const Icon(Icons.add_rounded, color: kOfficeInk, size: 30),
            tooltip: tr2('برگه جدید', 'New sheet'),
            onPressed: () => snack(context, tr2('افزودن برگهٔ جدید در این نسخه پشتیبانی نمی‌شود', 'Adding a new sheet is not supported yet')),
          ),
        ]),
      ),
    );
  }

  Widget _formulaBar(XSheet sh) {
    final ref = selectedRef;
    final value = sh.formulas.containsKey(ref) ? '=${sh.formulas[ref]}' : (sh.cells[ref] ?? '');
    final ctlKey = ValueKey('$ref:$value');
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
        decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: _line))),
        child: Row(children: [
          InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: _gotoCell,
            child: Container(
              width: 84,
              height: 44,
              padding: const EdgeInsets.only(left: 12, right: 4),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), border: Border.all(color: const Color(0xFFC7CCD8))),
              child: Row(children: [
                Expanded(child: Text(ref, style: const TextStyle(fontSize: 17, color: kOfficeInk))),
                const Icon(Icons.arrow_drop_down_rounded, color: kOfficeInk),
              ]),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Container(
              height: 44,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), border: Border.all(color: const Color(0xFFC7CCD8))),
              child: Row(children: [
                Container(
                  width: 52,
                  alignment: Alignment.center,
                  decoration: const BoxDecoration(color: _headBg, borderRadius: BorderRadius.horizontal(left: Radius.circular(7)), border: Border(right: BorderSide(color: Color(0xFFC7CCD8)))),
                  child: const Text('fx', style: TextStyle(fontSize: 24, fontStyle: FontStyle.italic, fontFamily: 'serif', color: kOfficeInk)),
                ),
                Expanded(
                  child: TextFormField(
                    key: ctlKey,
                    initialValue: value,
                    maxLines: 1,
                    textInputAction: TextInputAction.done,
                    style: const TextStyle(fontSize: 16, color: kOfficeInk),
                    decoration: const InputDecoration(isDense: true, border: InputBorder.none, contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12)),
                    onFieldSubmitted: (v) => _setCell(sh, ref, v),
                  ),
                ),
              ]),
            ),
          ),
        ]),
      ),
    );
  }

  Widget _grid(XSheet sh) {
    final rows = (sh.rows + 20).clamp(40, 5000).toInt();
    final cols = (sh.cols + 3).clamp(8, 200).toInt();
    final (selC, selR) = _selRC();
    return LayoutBuilder(builder: (context, cons) {
      final fit = (cons.maxWidth - hw) / 4;
      final cw = fit < 84 ? 84.0 : fit;
      return SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SizedBox(
          width: hw + cols * cw,
          child: ListView.builder(
            itemCount: rows + 1,
            itemExtent: rh,
            itemBuilder: (_, r) {
              if (r == 0) {
                return Row(children: [
                  Container(width: hw, decoration: const BoxDecoration(color: _headBg, border: Border(bottom: BorderSide(color: _line, width: .8), left: BorderSide(color: _line, width: .5)))),
                  for (var c = 0; c < cols; c++)
                    Container(
                      width: cw,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(color: c == selC ? const Color(0xFFD3E9DB) : _headBg, border: Border.all(color: _line, width: .5)),
                      child: Text(colName(c), style: TextStyle(fontSize: 16, color: c == selC ? kOfficeGreen : kOfficeInk, fontWeight: c == selC ? FontWeight.w800 : FontWeight.w500)),
                    ),
                ]);
              }
              return Row(children: [
                Container(
                  width: hw,
                  height: rh,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: r == selR ? const Color(0xFFD3E9DB) : _headBg, border: Border.all(color: _line, width: .5)),
                  child: Text(faDigits(r), style: TextStyle(fontSize: 15, color: r == selR ? kOfficeGreen : kOfficeInk, fontWeight: r == selR ? FontWeight.w800 : FontWeight.w500)),
                ),
                for (var c = 0; c < cols; c++) _cell(sh, c, r, cw),
              ]);
            },
          ),
        ),
      );
    });
  }

  Widget _cell(XSheet sh, int c, int r, double cw) {
    final ref = '${colName(c)}$r';
    final st = sh.styles[ref];
    final sel = selectedRef == ref;
    final fill = st?.fill != null ? Color(0xFF000000 | st!.fill!) : (r == 1 ? _rowOneBg : Colors.white);
    final bold = (st?.bold ?? false) || (r == 1 && sh.cells[ref] != null);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => setState(() => selectedRef = ref),
      onDoubleTap: () => _edit(sh, ref),
      onLongPress: () => _cellMenu(sh, c, r),
      child: Container(
        width: cw,
        height: rh,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        alignment: Alignment.center,
        decoration: BoxDecoration(color: fill, border: Border.all(color: sel ? kOfficeGreen : _line, width: sel ? 2.2 : .5)),
        child: Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
          Text(sh.cells[ref] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: TextStyle(fontSize: 15, fontWeight: bold ? FontWeight.w700 : FontWeight.w400, color: Colors.black87)),
          if (sel) Positioned(left: -6, bottom: -8, child: Container(width: 10, height: 10, color: kOfficeGreen)),
        ]),
      ),
    );
  }
}

/// .odt: paragraphs and headings; tap to edit (the edited paragraph loses inline formatting).
class OdtScreen extends StatefulWidget {
  final String path;
  const OdtScreen({super.key, required this.path});
  @override
  State<OdtScreen> createState() => _OdtScreenState();
}

class _OdtScreenState extends State<OdtScreen> {
  OdtFile? x;

  @override
  void initState() {
    super.initState();
    OdtFile.open(widget.path).then((v) { if (mounted) setState(() => x = v); }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
        IconButton(
          icon: const Icon(Icons.save_rounded),
          tooltip: L.t('saveCopy'),
          onPressed: f == null || !f.z.changed ? null : () async {
            if (!await ensureSdAll(context, [f.z.path])) return;
            final t = await f.z.saveCopy();
            if (mounted) await _saved(context, t);
          },
        ),
      ]),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(14),
              itemCount: f.blocks.length,
              itemBuilder: (_, i) {
                final bl = f.blocks[i];
                if (bl.image != null) {
                  return Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Image.memory(bl.image!, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const SizedBox()));
                }
                if (bl.table != null) {
                  final line = Theme.of(context).dividerColor;
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Table(
                      border: TableBorder.all(color: line, width: .5),
                      defaultColumnWidth: const IntrinsicColumnWidth(flex: 1),
                      children: [
                        for (final row in bl.table!)
                          TableRow(children: [
                            for (final cell in row)
                              InkWell(
                                onTap: cell.isEmpty ? null : () async {
                                  final t = cell.map(paraText).join('\n');
                                  final r = await _editDialog(context, t);
                                  if (r != null) {
                                    setState(() {
                                      f.setText(cell.first, r);
                                      for (final extra in cell.skip(1)) {
                                        f.setText(extra, '');
                                      }
                                    });
                                  }
                                },
                                child: Padding(padding: const EdgeInsets.all(6), child: Text(cell.map(paraText).join('\n'), style: const TextStyle(fontSize: 13))),
                              ),
                          ]),
                      ],
                    ),
                  );
                }
                final para = bl.para!;
                final t = paraText(para);
                final h = f.isHeading(para);
                return InkWell(
                  onTap: () async {
                    final r = await _editDialog(context, t);
                    if (r != null) setState(() => f.setText(para, r));
                  },
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: h ? 10 : 4),
                    child: Text(t.isEmpty ? ' ' : t, style: TextStyle(fontSize: h ? 20 : 15, fontWeight: h ? FontWeight.bold : FontWeight.normal)),
                  ),
                );
              },
            ),
    );
  }
}

/// .rtf: formatted view (bold / italic / underline / size / colour / alignment / RTL); tap a paragraph to edit
/// its text (edited paragraph keeps the format of its first run). Saving writes "<name> (edited).rtf".
class RtfScreen extends StatefulWidget {
  final String path;
  const RtfScreen({super.key, required this.path});
  @override
  State<RtfScreen> createState() => _RtfScreenState();
}

class _RtfScreenState extends State<RtfScreen> {
  List<DocPara> paras = [];
  bool loaded = false, dirty = false;
  double font = 16;

  @override
  void initState() {
    super.initState();
    File(widget.path).readAsBytes().then((b) {
      final ps = RtfDoc.parse(String.fromCharCodes(b));
      if (mounted) setState(() { paras = ps; loaded = true; });
    }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  Future<void> _edit(DocPara p) async {
    final r = await _editDialog(context, p.text);
    if (r == null) return;
    final first = p.runs.isEmpty ? DocRun('') : p.runs.first;
    setState(() {
      p.runs
        ..clear()
        ..add(DocRun(r, b: first.b, i: first.i, u: first.u, sz: first.sz, color: first.color));
      if (RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(r) && !RegExp(r'[A-Za-z]').hasMatch(r)) p.rtl = true;
      dirty = true;
    });
  }

  Future<void> _menu(int i) async {
    final a = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.add_rounded), title: Text(L.t('addParaAfter')), onTap: () => Navigator.pop(context, 'add')),
          ListTile(leading: const Icon(Icons.delete_outline_rounded), title: Text(L.t('delete')), onTap: () => Navigator.pop(context, 'del')),
        ]),
      ),
    );
    if (a == 'add') {
      final src = paras[i];
      final np = DocPara(rtl: src.rtl)..jc = src.jc;
      final f = src.runs.isEmpty ? DocRun('') : src.runs.last;
      np.runs.add(DocRun(' ', b: f.b, i: f.i, u: f.u, sz: f.sz, color: f.color));
      setState(() { paras.insert(i + 1, np); dirty = true; });
    } else if (a == 'del') {
      setState(() { paras.removeAt(i); dirty = true; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
          IconButton(icon: const Icon(Icons.text_decrease_rounded), onPressed: () => setState(() => font = (font - 1).clamp(10, 36))),
          IconButton(icon: const Icon(Icons.text_increase_rounded), onPressed: () => setState(() => font = (font + 1).clamp(10, 36))),
          IconButton(
            icon: const Icon(Icons.save_rounded),
            tooltip: L.t('saveCopy'),
            onPressed: !dirty ? null : () async {
              if (!await ensureSdAll(context, [widget.path])) return;
              final t = FileOps.unique(p.dirname(widget.path), '${p.basenameWithoutExtension(widget.path)} (edited).rtf');
              await Saf.writeString(t, RtfDoc.write(paras));
              if (mounted) { setState(() => dirty = false); await _saved(context, t); }
            },
          ),
        ]),
        body: !loaded
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                padding: const EdgeInsets.all(14),
                itemCount: paras.length,
                itemBuilder: (_, i) {
                  final pa = paras[i];
                  final align = switch (pa.jc) { 1 => TextAlign.center, 2 => TextAlign.end, 3 => TextAlign.justify, _ => TextAlign.start };
                  return Directionality(
                    textDirection: pa.rtl ? TextDirection.rtl : TextDirection.ltr,
                    child: InkWell(
                      onTap: () => _edit(pa),
                      onLongPress: () => _menu(i),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: SizedBox(
                          width: double.infinity,
                          child: Text.rich(
                            TextSpan(children: [
                              for (final r in pa.runs)
                                TextSpan(
                                  text: r.text,
                                  style: TextStyle(
                                    fontWeight: r.b ? FontWeight.bold : null,
                                    fontStyle: r.i ? FontStyle.italic : null,
                                    decoration: r.u ? TextDecoration.underline : null,
                                    fontSize: r.sz > 0 ? r.sz / 2 * (font / 12) : font,
                                    color: r.color != null ? Color(0xFF000000 | r.color!) : null,
                                  ),
                                ),
                              if (pa.runs.isEmpty) const TextSpan(text: ' '),
                            ], style: TextStyle(fontSize: font)),
                            textAlign: align,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
      );
}

// ====================================================================== legacy / ODF screens

/// .xls (Excel 97-2003): read-only grid; "convert" writes a .xlsx next to it and opens the editor.
class XlsScreen extends StatefulWidget {
  final String path;
  const XlsScreen({super.key, required this.path});
  @override
  State<XlsScreen> createState() => _XlsScreenState();
}

class _XlsScreenState extends State<XlsScreen> {
  List<XlsSheet>? sheets;
  int cur = 0;
  String selectedRef = 'A1';
  static const cw = 110.0, rh = 36.0, hw = 46.0;

  @override
  void initState() {
    super.initState();
    File(widget.path).readAsBytes().then((b) {
      try {
        final s = XlsLegacy.parse(b);
        if (mounted) setState(() => sheets = s);
      } catch (e) {
        if (mounted) { snack(context, '$e'); Navigator.pop(context); }
      }
    });
  }

  Future<void> _convert() async {
    if (!await ensureSdAll(context, [widget.path])) return;
    final t = FileOps.unique(p.dirname(widget.path), '${p.basenameWithoutExtension(widget.path)}.xlsx');
    await Saf.writeBytes(t, XlsLegacy.toXlsx(sheets!));
    Native.scan(t);
    if (!mounted) return;
    snack(context, '${L.t('saved')}: ${p.basename(t)}');
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => XlsxScreen(path: t)));
  }

  @override
  Widget build(BuildContext context) {
    final f = sheets;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
        if (f != null) IconButton(icon: const Icon(Icons.edit_note_rounded), tooltip: L.t('convertEdit'), onPressed: _convert),
      ]),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : f.isEmpty
              ? Center(child: Text(L.t('empty')))
              : Column(children: [
                  Container(width: double.infinity, color: Colors.amber.withOpacity(.15), padding: const EdgeInsets.all(8), child: Text(L.t('legacyXlsNote'), style: const TextStyle(fontSize: 12))),
                  SizedBox(
                    height: 44,
                    child: ListView(scrollDirection: Axis.horizontal, children: [
                      for (var i = 0; i < f.length; i++) Padding(padding: const EdgeInsets.all(4), child: ChoiceChip(label: Text(f[i].name), selected: i == cur, onSelected: (_) => setState(() => cur = i))),
                    ]),
                  ),
                  Expanded(child: _grid(f[cur])),
                ]),
    );
  }

  Widget _grid(XlsSheet sh) {
    final rows = (sh.rows + 5).clamp(20, 5000);
    final cols = (sh.cols + 1).clamp(6, 200);
    final line = Theme.of(context).dividerColor;
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: hw + cols * cw,
        child: ListView.builder(
          itemCount: rows + 1,
          itemExtent: rh,
          itemBuilder: (_, r) {
            if (r == 0) {
              return Row(children: [
                SizedBox(width: hw),
                for (var c = 0; c < cols; c++) Container(width: cw, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.black26, border: Border.all(color: line, width: .5)), child: Text(colName(c), style: const TextStyle(fontWeight: FontWeight.bold))),
              ]);
            }
            return Row(children: [
              Container(width: hw, height: rh, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.black26, border: Border.all(color: line, width: .5)), child: Text('$r', style: const TextStyle(fontSize: 11))),
              for (var c = 0; c < cols; c++)
                Container(
                  width: cw,
                  height: rh,
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  alignment: AlignmentDirectional.centerStart,
                  decoration: BoxDecoration(border: Border.all(color: line, width: .5)),
                  child: Text(sh.at(r - 1, c), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                ),
            ]);
          },
        ),
      ),
    );
  }
}

/// .ppt (PowerPoint 97-2003): read-only text per slide, copy-all.
class PptScreen extends StatefulWidget {
  final String path;
  const PptScreen({super.key, required this.path});
  @override
  State<PptScreen> createState() => _PptScreenState();
}

class _PptScreenState extends State<PptScreen> {
  List<List<String>>? slides;

  @override
  void initState() {
    super.initState();
    File(widget.path).readAsBytes().then((b) {
      try {
        final s = PptLegacy.parse(b);
        if (mounted) setState(() => slides = s);
      } catch (e) {
        if (mounted) { snack(context, '$e'); Navigator.pop(context); }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final f = slides;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
        if (f != null)
          IconButton(
            icon: const Icon(Icons.copy_rounded),
            tooltip: L.t('copy'),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: [for (var i = 0; i < f.length; i++) '— ${i + 1} —\n${f[i].join('\n')}'].join('\n\n')));
              snack(context, L.t('copied'));
            },
          ),
      ]),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: f.length + 1,
              itemBuilder: (_, i) {
                if (i == 0) return Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(L.t('legacyPptNote'), style: const TextStyle(fontSize: 12, color: Colors.amber)));
                final s = f[i - 1];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('$i / ${f.length}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                      for (final t in s) Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: SelectableText(t)),
                      if (s.isEmpty) const Text('…'),
                    ]),
                  ),
                );
              },
            ),
    );
  }
}

/// .ods: sheet tabs and grid, tap a cell to edit (values; formulas are replaced by the typed value).
class OdsScreen extends StatefulWidget {
  final String path;
  const OdsScreen({super.key, required this.path});
  @override
  State<OdsScreen> createState() => _OdsScreenState();
}

class _OdsScreenState extends State<OdsScreen> {
  OdsFile? x;
  int cur = 0;
  String selectedRef = 'A1';
  static const cw = 110.0, rh = 36.0, hw = 46.0;

  @override
  void initState() {
    super.initState();
    OdsFile.open(widget.path).then((v) { if (mounted) setState(() => x = v); }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
        IconButton(
          icon: const Icon(Icons.save_rounded),
          tooltip: L.t('saveCopy'),
          onPressed: f == null || !f.z.changed ? null : () async {
            if (!await ensureSdAll(context, [f.z.path])) return;
            final t = await f.z.saveCopy();
            if (mounted) await _saved(context, t);
          },
        ),
      ]),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : f.sheets.isEmpty
              ? Center(child: Text(L.t('empty')))
              : Column(children: [
                  SizedBox(
                    height: 44,
                    child: ListView(scrollDirection: Axis.horizontal, children: [
                      for (var i = 0; i < f.sheets.length; i++) Padding(padding: const EdgeInsets.all(4), child: ChoiceChip(label: Text(f.sheets[i].name), selected: i == cur, onSelected: (_) => setState(() => cur = i))),
                    ]),
                  ),
                  Expanded(child: _grid(f, f.sheets[cur])),
                ]),
    );
  }

  Widget _grid(OdsFile f, OSheet sh) {
    final rows = (sh.rows + 20).clamp(40, 5000).toInt();
    final cols = (sh.cols + 3).clamp(8, 200).toInt();
    final line = Theme.of(context).dividerColor;
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: hw + cols * cw,
        child: ListView.builder(
          itemCount: rows + 1,
          itemExtent: rh,
          itemBuilder: (_, r) {
            if (r == 0) {
              return Row(children: [
                SizedBox(width: hw),
                for (var c = 0; c < cols; c++) Container(width: cw, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.black26, border: Border.all(color: line, width: .5)), child: Text(colName(c), style: const TextStyle(fontWeight: FontWeight.bold))),
              ]);
            }
            return Row(children: [
              Container(width: hw, height: rh, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.black26, border: Border.all(color: line, width: .5)), child: Text('$r', style: const TextStyle(fontSize: 11))),
              for (var c = 0; c < cols; c++)
                InkWell(
                  onTap: () async {
                    final ref = '${colName(c)}$r';
                    final v = await _editDialog(context, sh.cells[ref] ?? '', title: ref);
                    if (v != null) setState(() => f.setCell(sh, ref, v));
                  },
                  child: Container(
                    width: cw,
                    height: rh,
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    alignment: AlignmentDirectional.centerStart,
                    decoration: BoxDecoration(border: Border.all(color: line, width: .5)),
                    child: Text(sh.cells['${colName(c)}$r'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                  ),
                ),
            ]);
          },
        ),
      ),
    );
  }
}

/// .odp: pages with images and text; tap a paragraph to edit.
class OdpScreen extends StatefulWidget {
  final String path;
  const OdpScreen({super.key, required this.path});
  @override
  State<OdpScreen> createState() => _OdpScreenState();
}

class _OdpScreenState extends State<OdpScreen> {
  OdpFile? x;

  @override
  void initState() {
    super.initState();
    OdpFile.open(widget.path).then((v) { if (mounted) setState(() => x = v); }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
        IconButton(
          icon: const Icon(Icons.save_rounded),
          tooltip: L.t('saveCopy'),
          onPressed: f == null || !f.z.changed ? null : () async {
            if (!await ensureSdAll(context, [f.z.path])) return;
            final t = await f.z.saveCopy();
            if (mounted) await _saved(context, t);
          },
        ),
      ]),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: f.pages.length,
              itemBuilder: (_, i) {
                final pg = f.pages[i];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${i + 1} / ${f.pages.length}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                      for (final im in pg.images) Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Image.memory(im, height: 180, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const SizedBox())),
                      for (final para in pg.paras)
                        InkWell(
                          onTap: () async {
                            final r = await _editDialog(context, paraText(para));
                            if (r != null) setState(() => f.setText(para, r));
                          },
                          child: Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Text(paraText(para).isEmpty ? '…' : paraText(para))),
                        ),
                    ]),
                  ),
                );
              },
            ),
    );
  }
}
