package ir.abtin.sms

import android.Manifest
import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds as CDK
import android.telecom.TelecomManager
import android.telecom.VideoProfile
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val CGREEN = Color(0xFF34C77B)

// =====================================================================
// Actions shared by contact screens
// =====================================================================
/** Video call through the carrier (VoLTE/ViLTE) via Telecom; falls back to the dialer with the video flag. */
fun videoCall(ctx: Context, number: String) {
    if (number.isBlank()) return
    val u = Uri.fromParts("tel", number.trim(), null)
    val b = Bundle().apply { putInt(TelecomManager.EXTRA_START_CALL_WITH_VIDEO_STATE, VideoProfile.STATE_BIDIRECTIONAL) }
    val fallback = {
        runCatching { ctx.startActivity(Intent(Intent.ACTION_DIAL, u).putExtra(TelecomManager.EXTRA_START_CALL_WITH_VIDEO_STATE, VideoProfile.STATE_BIDIRECTIONAL).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        Unit
    }
    if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED)
        runCatching { ctx.getSystemService(TelecomManager::class.java).placeCall(u, b) }.onFailure { fallback() }
    else fallback()
}

/** Messages always open in the SMS app (separate launcher/task), whichever app the user is in. */
fun openChat(ctx: Context, number: String) {
    ctx.startActivity(Intent(ctx, MainActivity::class.java).putExtra("address", number).putExtra("thread", 0L).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

private fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_LONG).show()

// =====================================================================
// Model + repository
// =====================================================================
class LV(var value: String, var type: Int)
class FullContact(
    val id: Long, val name: String, val phones: List<LV>, val emails: List<LV>, val org: String, val title: String,
    val address: String, val note: String, val birthday: String, val website: String, val nick: String, val starred: Boolean
)

private val PHONE_TYPES = listOf(CDK.Phone.TYPE_MOBILE, CDK.Phone.TYPE_HOME, CDK.Phone.TYPE_WORK, CDK.Phone.TYPE_OTHER)
private val EMAIL_TYPES = listOf(CDK.Email.TYPE_HOME, CDK.Email.TYPE_WORK, CDK.Email.TYPE_OTHER)
private fun phoneTypeName(t: Int) = when (t) {
    CDK.Phone.TYPE_MOBILE -> tr("موبایل", "Mobile"); CDK.Phone.TYPE_HOME -> tr("خانه", "Home"); CDK.Phone.TYPE_WORK -> tr("محل کار", "Work")
    CDK.Phone.TYPE_WORK_MOBILE -> tr("موبایل کار", "Work mobile"); CDK.Phone.TYPE_MAIN -> tr("اصلی", "Main"); else -> tr("سایر", "Other")
}
private fun emailTypeName(t: Int) = when (t) {
    CDK.Email.TYPE_HOME -> tr("شخصی", "Home"); CDK.Email.TYPE_WORK -> tr("کاری", "Work"); CDK.Email.TYPE_MOBILE -> tr("موبایل", "Mobile"); else -> tr("سایر", "Other")
}

private fun SmsRepo.canRead() = ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
private fun SmsRepo.canWrite() = ctx.checkSelfPermission(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED

fun SmsRepo.contactFull(id: Long): FullContact? {
    if (!canRead()) return null
    var name = ""; var starred = false; var found = false
    cr.query(ContactsContract.Contacts.CONTENT_URI, arrayOf(ContactsContract.Contacts.DISPLAY_NAME, ContactsContract.Contacts.STARRED),
        ContactsContract.Contacts._ID + "=?", arrayOf(id.toString()), null)?.use {
        if (it.moveToFirst()) { found = true; name = it.getString(0) ?: ""; starred = it.getInt(1) == 1 }
    }
    if (!found) return null
    val phones = ArrayList<LV>(); val emails = ArrayList<LV>()
    var org = ""; var title = ""; var addr = ""; var note = ""; var bday = ""; var web = ""; var nick = ""
    val D = ContactsContract.Data
    cr.query(D.CONTENT_URI, arrayOf(D.MIMETYPE, D.DATA1, D.DATA2, D.DATA4), D.CONTACT_ID + "=?", arrayOf(id.toString()), null)?.use { c ->
        while (c.moveToNext()) {
            val v = c.getString(1) ?: ""
            if (v.isBlank()) continue
            when (c.getString(0)) {
                CDK.Phone.CONTENT_ITEM_TYPE -> if (phones.none { it.value.filter(Char::isDigit) == v.filter(Char::isDigit) }) phones += LV(v, c.getInt(2))
                CDK.Email.CONTENT_ITEM_TYPE -> if (emails.none { it.value == v }) emails += LV(v, c.getInt(2))
                CDK.Organization.CONTENT_ITEM_TYPE -> { if (org.isEmpty()) org = v; if (title.isEmpty()) title = c.getString(3) ?: "" }
                CDK.StructuredPostal.CONTENT_ITEM_TYPE -> if (addr.isEmpty()) addr = v
                CDK.Note.CONTENT_ITEM_TYPE -> if (note.isEmpty()) note = v
                CDK.Event.CONTENT_ITEM_TYPE -> if (c.getInt(2) == CDK.Event.TYPE_BIRTHDAY && bday.isEmpty()) bday = v
                CDK.Website.CONTENT_ITEM_TYPE -> if (web.isEmpty()) web = v
                CDK.Nickname.CONTENT_ITEM_TYPE -> if (nick.isEmpty()) nick = v
            }
        }
    }
    return FullContact(id, name, phones, emails, org, title, addr, note, bday, web, nick, starred)
}

/** Creates (f.id == 0) or rewrites a contact. Returns the contact id, or -1 on failure. */
fun SmsRepo.saveFull(f: FullContact): Long {
    if (!canWrite()) return -1
    return try {
        val D = ContactsContract.Data
        val ops = ArrayList<ContentProviderOperation>()
        var raws = emptyList<Long>()
        if (f.id == 0L) {
            ops += ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI)
                .withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null).withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null).build()
        } else {
            val l = ArrayList<Long>()
            cr.query(ContactsContract.RawContacts.CONTENT_URI, arrayOf(ContactsContract.RawContacts._ID), ContactsContract.RawContacts.CONTACT_ID + "=? AND deleted=0",
                arrayOf(f.id.toString()), null)?.use { while (it.moveToNext()) l += it.getLong(0) }
            if (l.isEmpty()) return -1
            raws = l
            val kinds = arrayOf(CDK.StructuredName.CONTENT_ITEM_TYPE, CDK.Phone.CONTENT_ITEM_TYPE, CDK.Email.CONTENT_ITEM_TYPE, CDK.Organization.CONTENT_ITEM_TYPE,
                CDK.StructuredPostal.CONTENT_ITEM_TYPE, CDK.Note.CONTENT_ITEM_TYPE, CDK.Website.CONTENT_ITEM_TYPE, CDK.Nickname.CONTENT_ITEM_TYPE)
            for (r in l) {
                ops += ContentProviderOperation.newDelete(D.CONTENT_URI)
                    .withSelection(D.RAW_CONTACT_ID + "=? AND " + D.MIMETYPE + " IN (" + kinds.joinToString(",") { "?" } + ")", arrayOf(r.toString()) + kinds).build()
                ops += ContentProviderOperation.newDelete(D.CONTENT_URI)
                    .withSelection(D.RAW_CONTACT_ID + "=? AND " + D.MIMETYPE + "=? AND " + D.DATA2 + "=?", arrayOf(r.toString(), CDK.Event.CONTENT_ITEM_TYPE, CDK.Event.TYPE_BIRTHDAY.toString())).build()
            }
        }
        fun ins(mime: String, build: ContentProviderOperation.Builder.() -> Unit) {
            val b = ContentProviderOperation.newInsert(D.CONTENT_URI)
            if (f.id == 0L) b.withValueBackReference(D.RAW_CONTACT_ID, 0) else b.withValue(D.RAW_CONTACT_ID, raws.first())
            b.withValue(D.MIMETYPE, mime); b.build2(build).let { ops += it }
        }
        ins(CDK.StructuredName.CONTENT_ITEM_TYPE) { withValue(CDK.StructuredName.DISPLAY_NAME, f.name) }
        f.phones.filter { it.value.isNotBlank() }.forEach { ph -> ins(CDK.Phone.CONTENT_ITEM_TYPE) { withValue(CDK.Phone.NUMBER, ph.value.trim()); withValue(CDK.Phone.TYPE, ph.type) } }
        f.emails.filter { it.value.isNotBlank() }.forEach { em -> ins(CDK.Email.CONTENT_ITEM_TYPE) { withValue(CDK.Email.ADDRESS, em.value.trim()); withValue(CDK.Email.TYPE, em.type) } }
        if (f.org.isNotBlank() || f.title.isNotBlank()) ins(CDK.Organization.CONTENT_ITEM_TYPE) { withValue(CDK.Organization.COMPANY, f.org.trim()); withValue(CDK.Organization.TITLE, f.title.trim()) }
        if (f.address.isNotBlank()) ins(CDK.StructuredPostal.CONTENT_ITEM_TYPE) { withValue(CDK.StructuredPostal.FORMATTED_ADDRESS, f.address.trim()) }
        if (f.note.isNotBlank()) ins(CDK.Note.CONTENT_ITEM_TYPE) { withValue(CDK.Note.NOTE, f.note.trim()) }
        if (f.website.isNotBlank()) ins(CDK.Website.CONTENT_ITEM_TYPE) { withValue(CDK.Website.URL, f.website.trim()) }
        if (f.nick.isNotBlank()) ins(CDK.Nickname.CONTENT_ITEM_TYPE) { withValue(CDK.Nickname.NAME, f.nick.trim()) }
        if (f.birthday.isNotBlank()) ins(CDK.Event.CONTENT_ITEM_TYPE) { withValue(CDK.Event.START_DATE, f.birthday.trim()); withValue(CDK.Event.TYPE, CDK.Event.TYPE_BIRTHDAY) }
        val res = cr.applyBatch(ContactsContract.AUTHORITY, ops)
        var cid = f.id
        if (cid == 0L) {
            val raw = ContentUris.parseId(res[0].uri!!)
            cr.query(ContactsContract.RawContacts.CONTENT_URI, arrayOf(ContactsContract.RawContacts.CONTACT_ID), ContactsContract.RawContacts._ID + "=?", arrayOf(raw.toString()), null)
                ?.use { if (it.moveToFirst()) cid = it.getLong(0) }
        }
        if (cid > 0 && f.starred) setStarred(cid, true)
        cid
    } catch (e: Exception) { -1 }
}

private fun ContentProviderOperation.Builder.build2(f: ContentProviderOperation.Builder.() -> Unit): ContentProviderOperation { f(); return build() }

fun SmsRepo.setStarred(id: Long, v: Boolean): Boolean = try {
    canWrite() && cr.update(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id), ContentValues().apply { put(ContactsContract.Contacts.STARRED, if (v) 1 else 0) }, null, null) > 0
} catch (e: Exception) { false }

/** Joins contacts that share the same phone number (Android keeps them together as one aggregated contact). Returns number of links made. */
fun SmsRepo.mergeDuplicates(): Int {
    if (!canRead() || !canWrite()) return 0
    val byNum = HashMap<String, MutableList<Pair<Long, Long>>>()  // key -> (contactId, rawId)
    cr.query(CDK.Phone.CONTENT_URI, arrayOf(CDK.Phone.CONTACT_ID, CDK.Phone.RAW_CONTACT_ID, CDK.Phone.NUMBER), null, null, null)?.use { c ->
        while (c.moveToNext()) {
            val d = (c.getString(2) ?: "").filter { it.isDigit() }
            if (d.length < 7) continue
            byNum.getOrPut(d.takeLast(9)) { ArrayList() } += Pair(c.getLong(0), c.getLong(1))
        }
    }
    var n = 0
    for ((_, l) in byNum) {
        val u = l.distinctBy { it.first }
        if (u.size < 2) continue
        for (i in 1 until u.size) runCatching {
            cr.update(ContactsContract.AggregationExceptions.CONTENT_URI, ContentValues().apply {
                put(ContactsContract.AggregationExceptions.RAW_CONTACT_ID1, u[0].second)
                put(ContactsContract.AggregationExceptions.RAW_CONTACT_ID2, u[i].second)
                put(ContactsContract.AggregationExceptions.TYPE, ContactsContract.AggregationExceptions.TYPE_KEEP_TOGETHER)
            }, null, null); n++
        }
    }
    return n
}

// ---------- vCard ----------
private fun vEsc(s: String) = s.replace("\\", "\\\\").replace("\n", "\\n").replace(",", "\\,").replace(";", "\\;")
private fun vUnesc(s: String) = s.replace("\\n", "\n").replace("\\N", "\n").replace("\\,", ",").replace("\\;", ";").replace("\\\\", "\\")

fun FullContact.toVCard(): String = buildString {
    append("BEGIN:VCARD\r\nVERSION:3.0\r\n")
    append("FN:").append(vEsc(name)).append("\r\nN:;").append(vEsc(name)).append(";;;\r\n")
    phones.forEach { append("TEL;TYPE=").append(when (it.type) { CDK.Phone.TYPE_HOME -> "HOME"; CDK.Phone.TYPE_WORK -> "WORK"; CDK.Phone.TYPE_MOBILE -> "CELL"; else -> "VOICE" }).append(":").append(it.value).append("\r\n") }
    emails.forEach { append("EMAIL;TYPE=").append(if (it.type == CDK.Email.TYPE_WORK) "WORK" else "HOME").append(":").append(it.value).append("\r\n") }
    if (org.isNotBlank()) append("ORG:").append(vEsc(org)).append("\r\n")
    if (title.isNotBlank()) append("TITLE:").append(vEsc(title)).append("\r\n")
    if (address.isNotBlank()) append("ADR;TYPE=HOME:;;").append(vEsc(address)).append(";;;;\r\n")
    if (website.isNotBlank()) append("URL:").append(website).append("\r\n")
    if (birthday.isNotBlank()) append("BDAY:").append(birthday).append("\r\n")
    if (note.isNotBlank()) append("NOTE:").append(vEsc(note)).append("\r\n")
    append("END:VCARD\r\n")
}

fun parseVCards(text: String): List<FullContact> {
    val out = ArrayList<FullContact>()
    // unfold lines
    val lines = text.replace("\r\n", "\n").replace("\n ", "").replace("\n\t", "").split('\n')
    var cur: MutableMap<String, MutableList<Pair<String, String>>>? = null
    for (raw in lines) {
        val line = raw.trim()
        if (line.equals("BEGIN:VCARD", true)) { cur = HashMap(); continue }
        if (line.equals("END:VCARD", true)) {
            val m = cur ?: continue; cur = null
            fun first(k: String) = m[k]?.firstOrNull()?.second ?: ""
            val n = first("FN").ifBlank { first("N").split(';').filter { it.isNotBlank() }.joinToString(" ") }
            val phones = (m["TEL"] ?: emptyList()).map { LV(it.second, if (it.first.contains("HOME")) CDK.Phone.TYPE_HOME else if (it.first.contains("WORK")) CDK.Phone.TYPE_WORK else CDK.Phone.TYPE_MOBILE) }
            val emails = (m["EMAIL"] ?: emptyList()).map { LV(it.second, if (it.first.contains("WORK")) CDK.Email.TYPE_WORK else CDK.Email.TYPE_HOME) }
            if (n.isNotBlank() || phones.isNotEmpty())
                out += FullContact(0, n.ifBlank { phones.firstOrNull()?.value ?: "" }, phones, emails, first("ORG").split(';').firstOrNull() ?: "", first("TITLE"),
                    first("ADR").split(';').filter { it.isNotBlank() }.joinToString(" "), first("NOTE"), first("BDAY"), first("URL"), first("NICKNAME"), false)
            continue
        }
        val m = cur ?: continue
        val i = line.indexOf(':'); if (i <= 0) continue
        val head = line.substring(0, i).uppercase(); val value = vUnesc(line.substring(i + 1))
        val key = head.substringBefore(';').substringAfterLast('.')
        m.getOrPut(key) { ArrayList() } += Pair(head, value)
    }
    return out
}

private fun shareVcf(ctx: Context, cards: String, fileName: String) {
    runCatching {
        val dir = File(ctx.cacheDir, "vcf").apply { mkdirs() }
        val f = File(dir, fileName).apply { writeText(cards) }
        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/x-vcard").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

// =====================================================================
// Contacts list
// =====================================================================
@Composable
fun ContactsScreen(repo: SmsRepo, nav: MutableState<Screen>) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tick = Bus.tick.intValue
    var q by remember { mutableStateOf("") }
    var favOnly by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var contacts by remember { mutableStateOf<List<ContactItem>>(emptyList()) }
    LaunchedEffect(tick) { contacts = withContext(Dispatchers.IO) { runCatching { repo.contacts().distinctBy { if (it.id != 0L) it.id.toString() else it.number } }.getOrDefault(emptyList()) } }

    val importL = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) scope.launch(Dispatchers.IO) {
            val n = runCatching {
                val txt = ctx.contentResolver.openInputStream(u)!!.bufferedReader().use { it.readText() }
                parseVCards(txt).count { repo.saveFull(it) > 0 }
            }.getOrDefault(0)
            withContext(Dispatchers.Main) { Bus.tick.intValue++; toast(ctx, tr("$n مخاطب وارد شد", "$n contacts imported")) }
        }
    }
    val permL = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { Bus.tick.intValue++ }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("مخاطبین", "Contacts"), color = p.text, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            CircleBtn(Icons.Default.PersonAdd, { nav.value = Screen.ContactForm() }, size = 44.dp); Spacer(Modifier.width(8.dp))
            Box {
                CircleBtn(Icons.Default.MoreVert, { menu = true }, size = 44.dp)
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text(tr("ورود مخاطبین (vCard)", "Import (vCard)")) }, onClick = { menu = false; importL.launch("*/*") })
                    DropdownMenuItem(text = { Text(tr("خروجی همه مخاطبین", "Export all contacts")) }, onClick = {
                        menu = false
                        scope.launch(Dispatchers.IO) {
                            val all = repo.contacts().distinctBy { it.id }.mapNotNull { repo.contactFull(it.id) }
                            withContext(Dispatchers.Main) { if (all.isEmpty()) toast(ctx, tr("مخاطبی نیست", "No contacts")) else shareVcf(ctx, all.joinToString("") { it.toVCard() }, "abtin-contacts.vcf") }
                        }
                    })
                    DropdownMenuItem(text = { Text(tr("ادغام مخاطبین تکراری", "Merge duplicates")) }, onClick = {
                        menu = false
                        scope.launch(Dispatchers.IO) { val n = repo.mergeDuplicates(); withContext(Dispatchers.Main) { Bus.tick.intValue++; toast(ctx, if (n > 0) tr("$n مورد ادغام شد", "$n merged") else tr("مورد تکراری پیدا نشد", "No duplicates found")) } }
                    })
                    DropdownMenuItem(text = { Text(tr("ارسال پیام جدید", "New message")) }, onClick = { menu = false; nav.value = Screen.New })
                }
            }
        }
        PillField(q, { q = it }, tr("جستجوی مخاطب…", "Search contacts…"), Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp), Icons.Default.Search)
        Row(Modifier.padding(horizontal = 20.dp).padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChipX(tr("همه", "All") + " (${contacts.size})", null, !favOnly) { favOnly = false }
            FilterChipX(tr("علاقه‌مندی‌ها", "Favorites"), null, favOnly) { favOnly = true }
        }
        val list = contacts.filter { (!favOnly || it.starred) && (q.isBlank() || it.name.contains(q, true) || it.number.contains(q)) }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            Text(tr("برای نمایش مخاطبین، مجوز دسترسی بدهید (برای تنظیم ضربه بزنید)", "Grant contacts permission (tap)"), color = p.primary, modifier = Modifier.fillMaxWidth().clickable { permL.launch(Manifest.permission.READ_CONTACTS) }.padding(24.dp))
        else if (list.isEmpty()) Text(if (favOnly) tr("هنوز مخاطب مورد علاقه‌ای ندارید", "No favorites yet") else tr("مخاطبی پیدا نشد", "No contacts"), color = p.sub, modifier = Modifier.padding(24.dp))
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 16.dp)) {
            var last = ""
            list.forEachIndexed { idx, c ->
                val letter = c.name.firstOrNull { it.isLetter() }?.uppercase() ?: "#"
                val header = letter != last; last = letter
                item(key = "c" + c.id + c.number + idx) {
                    if (header && !favOnly) Text(letter, color = p.primary, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(start = 26.dp, top = 12.dp, bottom = 4.dp))
                    val shape = RoundedCornerShape(20.dp)
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 3.5.dp).clip(shape).background(p.surface).border(1.dp, p.line, shape)
                        .clickable { if (c.id != 0L) nav.value = Screen.ContactDetail(c.id) else nav.value = Screen.ContactForm(0, c.name, c.number) }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Avatar(repo, c.number, c.name, 47.dp); Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(c.name, color = p.text, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content), modifier = Modifier.weight(1f, false))
                                if (c.starred) Icon(Icons.Default.Star, null, tint = Color(0xFFFFC145), modifier = Modifier.padding(start = 6.dp).size(16.dp))
                            }
                            Text(c.number, color = p.sub, fontSize = 14.sp, style = TextStyle(textDirection = TextDirection.Ltr))
                        }
                        CircleBtn(Icons.Default.ChatBubble, { openChat(ctx, c.number) }, size = 40.dp); Spacer(Modifier.width(8.dp))
                        CircleBtn(Icons.Default.Call, { dial(ctx, c.number) }, size = 40.dp, tint = p.primary)
                        Spacer(Modifier.width(4.dp))
                    }
                }
            }
        }
    }
}

// =====================================================================
// Contact detail
// =====================================================================
@Composable
private fun ActionTile(icon: ImageVector, label: String, tint: Color?, onClick: () -> Unit) {
    val p = LocalPal.current
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(76.dp).clickable(onClick = onClick)) {
        CircleBtn(icon, onClick, size = 56.dp, tint = tint)
        Text(label, color = p.sub, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun InfoCard(content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(22.dp)
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).clip(shape).background(p.surface).border(1.dp, p.line, shape).padding(vertical = 6.dp), content = content)
}

@Composable
private fun InfoRow(icon: ImageVector, title: String, sub: String, onClick: (() -> Unit)? = null, trailing: @Composable RowScope.() -> Unit = {}) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = p.primary, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = p.text, fontSize = 17.sp, style = TextStyle(textDirection = TextDirection.Content))
            if (sub.isNotEmpty()) Text(sub, color = p.sub, fontSize = 13.sp)
        }
        trailing()
    }
}

@Composable
fun ContactDetailScreen(repo: SmsRepo, act: ComponentActivity, s: Screen.ContactDetail, nav: MutableState<Screen>) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    val tick = Bus.tick.intValue
    var c by remember { mutableStateOf<FullContact?>(null) }
    var loaded by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf(false) }
    LaunchedEffect(s.id, tick) { c = withContext(Dispatchers.IO) { runCatching { repo.contactFull(s.id) }.getOrNull() }; loaded = true }
    val f = c
    val first = f?.phones?.firstOrNull()?.value ?: ""

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, { nav.value = Screen.Contacts })
            Spacer(Modifier.weight(1f))
            if (f != null) {
                CircleBtn(if (f.starred) Icons.Default.Star else Icons.Default.StarBorder, {
                    scope.launch(Dispatchers.IO) { repo.setStarred(f.id, !f.starred); withContext(Dispatchers.Main) { Bus.tick.intValue++ } }
                }, tint = if (f.starred) Color(0xFFFFC145) else null); Spacer(Modifier.width(8.dp))
                CircleBtn(Icons.Default.Edit, { nav.value = Screen.ContactForm(f.id, f.name, first) }); Spacer(Modifier.width(8.dp))
                CircleBtn(Icons.Default.Share, { shareVcf(act, f.toVCard(), "contact-${f.id}.vcf") }); Spacer(Modifier.width(8.dp))
                CircleBtn(Icons.Default.Delete, { confirmDel = true }, tint = p.danger)
            }
        }
        if (f == null) {
            if (loaded) Text(tr("مخاطب پیدا نشد", "Contact not found"), color = p.sub, modifier = Modifier.padding(24.dp))
        } else Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Avatar(repo, first, f.name, 112.dp)
            Text(f.name, color = p.text, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 12.dp), style = TextStyle(textDirection = TextDirection.Content))
            val sub = listOf(f.title, f.org).filter { it.isNotBlank() }.joinToString(" · ")
            if (sub.isNotEmpty()) Text(sub, color = p.sub, fontSize = 15.sp, style = TextStyle(textDirection = TextDirection.Content))
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                ActionTile(Icons.Default.Call, tr("تماس", "Call"), CGREEN) { dial(act, first) }
                ActionTile(Icons.Default.Videocam, tr("تصویری", "Video"), null) { videoCall(act, first) }
                ActionTile(Icons.Default.ChatBubble, tr("پیام", "Message"), null) { openChat(act, first) }
                ActionTile(Icons.Default.Email, tr("ایمیل", "Email"), null) {
                    f.emails.firstOrNull()?.let { e -> runCatching { act.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + e.value))) } } ?: toast(act, tr("ایمیلی ثبت نشده", "No email saved"))
                }
            }
            Spacer(Modifier.height(8.dp))
            if (f.phones.isNotEmpty()) InfoCard {
                f.phones.forEach { ph ->
                    InfoRow(Icons.Default.Phone, ph.value, phoneTypeName(ph.type), { dial(act, ph.value) }) {
                        CircleBtn(Icons.Default.Videocam, { videoCall(act, ph.value) }, size = 38.dp); Spacer(Modifier.width(8.dp))
                        CircleBtn(Icons.Default.ChatBubble, { openChat(act, ph.value) }, size = 38.dp)
                    }
                }
            }
            if (f.emails.isNotEmpty()) InfoCard {
                f.emails.forEach { em -> InfoRow(Icons.Default.Email, em.value, emailTypeName(em.type), { runCatching { act.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + em.value))) } }) }
            }
            if (f.address.isNotBlank() || f.birthday.isNotBlank() || f.website.isNotBlank() || f.nick.isNotBlank()) InfoCard {
                if (f.address.isNotBlank()) InfoRow(Icons.Default.Place, f.address, tr("آدرس", "Address"), { runCatching { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(f.address)))) } })
                if (f.birthday.isNotBlank()) InfoRow(Icons.Default.Cake, f.birthday, tr("تاریخ تولد", "Birthday"))
                if (f.website.isNotBlank()) InfoRow(Icons.Default.Language, f.website, tr("وب‌سایت", "Website"), { runCatching { act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(if (f.website.startsWith("http")) f.website else "https://" + f.website))) } })
                if (f.nick.isNotBlank()) InfoRow(Icons.Default.Badge, f.nick, tr("نام مستعار", "Nickname"))
            }
            if (f.note.isNotBlank()) InfoCard { InfoRow(Icons.Default.Notes, f.note, tr("یادداشت", "Notes")) }
            Spacer(Modifier.height(24.dp))
        }
    }
    if (confirmDel) AlertDialog(onDismissRequest = { confirmDel = false }, containerColor = p.surface, titleContentColor = p.text, textContentColor = p.sub,
        title = { Text(tr("حذف مخاطب", "Delete contact")) }, text = { Text(tr("این مخاطب حذف شود؟", "Delete this contact?")) },
        confirmButton = {
            TextButton({
                confirmDel = false
                scope.launch(Dispatchers.IO) { val ok = repo.deleteContact(s.id); withContext(Dispatchers.Main) { if (ok) { Bus.tick.intValue++; nav.value = Screen.Contacts } else toast(act, tr("حذف ممکن نشد", "Could not delete")) } }
            }) { Text(tr("حذف", "Delete"), color = p.danger) }
        }, dismissButton = { TextButton({ confirmDel = false }) { Text(tr("لغو", "Cancel"), color = p.text) } })
}

// =====================================================================
// Contact form (create / edit, multi-field)
// =====================================================================
@Composable
fun ContactFormScreen(repo: SmsRepo, act: ComponentActivity, s: Screen.ContactForm, nav: MutableState<Screen>) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(s.name) }
    val phones = remember { mutableStateListOf(LV(s.number, CDK.Phone.TYPE_MOBILE)) }
    val emails = remember { mutableStateListOf<LV>() }
    var org by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var birthday by remember { mutableStateOf("") }
    var website by remember { mutableStateOf("") }
    var nick by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var starred by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    var ready by remember { mutableStateOf(s.id == 0L) }
    LaunchedEffect(s.id) {
        if (s.id != 0L) {
            val f = withContext(Dispatchers.IO) { runCatching { repo.contactFull(s.id) }.getOrNull() }
            if (f != null) {
                name = f.name; phones.clear(); phones.addAll(f.phones.map { LV(it.value, it.type) }.ifEmpty { listOf(LV("", CDK.Phone.TYPE_MOBILE)) })
                emails.clear(); emails.addAll(f.emails.map { LV(it.value, it.type) }); org = f.org; title = f.title; address = f.address
                birthday = f.birthday; website = f.website; nick = f.nick; note = f.note; starred = f.starred
                more = listOf(f.org, f.title, f.address, f.birthday, f.website, f.nick, f.note).any { it.isNotBlank() }
            }
            ready = true
        }
    }
    fun save() {
        val firstNum = phones.firstOrNull { it.value.isNotBlank() }?.value ?: ""
        if (name.isBlank() && firstNum.isBlank() && emails.none { it.value.isNotBlank() }) return
        val f = FullContact(s.id, name.trim().ifEmpty { firstNum.ifEmpty { emails.first { it.value.isNotBlank() }.value } }, phones.map { LV(it.value, it.type) }, emails.map { LV(it.value, it.type) },
            org, title, address, note, birthday, website, nick, starred)
        scope.launch(Dispatchers.IO) {
            val id = repo.saveFull(f)
            withContext(Dispatchers.Main) {
                if (id > 0) { Bus.tick.intValue++; nav.value = Screen.ContactDetail(id) }
                else toast(act, tr("ذخیره مخاطب ممکن نشد (مجوز مخاطبین؟)", "Could not save contact (contacts permission?)"))
            }
        }
    }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) save() }
    fun trySave() { if (act.checkSelfPermission(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED) save() else perm.launch(Manifest.permission.WRITE_CONTACTS) }
    val back = { nav.value = if (s.id != 0L) Screen.ContactDetail(s.id) else Screen.Contacts }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().padding(horizontal = 20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 12.dp)) {
            CircleBtn(Icons.Default.Close, back)
            Text(if (s.id == 0L) tr("مخاطب جدید", "New contact") else tr("ویرایش مخاطب", "Edit contact"), color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(horizontal = 14.dp))
            CircleBtn(if (starred) Icons.Default.Star else Icons.Default.StarBorder, { starred = !starred }, tint = if (starred) Color(0xFFFFC145) else null)
        }
        if (!ready) return@Column
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) { Avatar(repo, phones.firstOrNull()?.value ?: "", name.ifEmpty { phones.firstOrNull()?.value ?: "" }, 96.dp) }
            PillField(name, { name = it }, tr("نام", "Name"), Modifier.fillMaxWidth().padding(vertical = 5.dp), Icons.Default.Person)
            phones.forEachIndexed { i, ph ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    PillField(ph.value, { phones[i] = LV(it, ph.type) }, tr("شماره تلفن", "Phone number"), Modifier.weight(1f), Icons.Default.Phone, KeyboardOptions(keyboardType = KeyboardType.Phone))
                    Text(phoneTypeName(ph.type), color = p.primary, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp).clip(RoundedCornerShape(50)).clickable {
                        phones[i] = LV(ph.value, PHONE_TYPES[(PHONE_TYPES.indexOf(ph.type) + 1) % PHONE_TYPES.size])
                    }.padding(horizontal = 8.dp, vertical = 10.dp))
                    if (phones.size > 1) Icon(Icons.Default.RemoveCircleOutline, null, tint = p.danger, modifier = Modifier.size(34.dp).clip(CircleShape).clickable { phones.removeAt(i) }.padding(5.dp))
                }
            }
            TextButton({ phones.add(LV("", CDK.Phone.TYPE_MOBILE)) }) { Icon(Icons.Default.Add, null, tint = p.primary); Text(" " + tr("افزودن شماره", "Add phone"), color = p.primary) }
            emails.forEachIndexed { i, em ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    PillField(em.value, { emails[i] = LV(it, em.type) }, tr("ایمیل", "Email"), Modifier.weight(1f), Icons.Default.Email, KeyboardOptions(keyboardType = KeyboardType.Email))
                    Text(emailTypeName(em.type), color = p.primary, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp).clip(RoundedCornerShape(50)).clickable {
                        emails[i] = LV(em.value, EMAIL_TYPES[(EMAIL_TYPES.indexOf(em.type) + 1) % EMAIL_TYPES.size])
                    }.padding(horizontal = 8.dp, vertical = 10.dp))
                    Icon(Icons.Default.RemoveCircleOutline, null, tint = p.danger, modifier = Modifier.size(34.dp).clip(CircleShape).clickable { emails.removeAt(i) }.padding(5.dp))
                }
            }
            TextButton({ emails.add(LV("", CDK.Email.TYPE_HOME)) }) { Icon(Icons.Default.Add, null, tint = p.primary); Text(" " + tr("افزودن ایمیل", "Add email"), color = p.primary) }
            if (!more) TextButton({ more = true }) { Icon(Icons.Default.ExpandMore, null, tint = p.primary); Text(" " + tr("فیلدهای بیشتر", "More fields"), color = p.primary) }
            else {
                PillField(org, { org = it }, tr("شرکت / سازمان", "Company"), Modifier.fillMaxWidth().padding(vertical = 5.dp), Icons.Default.Business)
                PillField(title, { title = it }, tr("سمت", "Job title"), Modifier.fillMaxWidth().padding(vertical = 5.dp), Icons.Default.Work)
                PillField(nick, { nick = it }, tr("نام مستعار", "Nickname"), Modifier.fillMaxWidth().padding(vertical = 5.dp), Icons.Default.Badge)
                PillField(address, { address = it }, tr("آدرس", "Address"), Modifier.fillMaxWidth().padding(vertical = 5.dp), Icons.Default.Place)
                PillField(birthday, { birthday = it }, tr("تاریخ تولد (YYYY-MM-DD)", "Birthday (YYYY-MM-DD)"), Modifier.fillMaxWidth().padding(vertical = 5.dp), Icons.Default.Cake, KeyboardOptions(keyboardType = KeyboardType.Number))
                PillField(website, { website = it }, tr("وب‌سایت", "Website"), Modifier.fillMaxWidth().padding(vertical = 5.dp), Icons.Default.Language, KeyboardOptions(keyboardType = KeyboardType.Uri))
                PillField(note, { note = it }, tr("یادداشت", "Notes"), Modifier.fillMaxWidth().padding(vertical = 5.dp), Icons.Default.Notes, maxLines = 4)
            }
            Spacer(Modifier.height(12.dp))
        }
        Box(Modifier.fillMaxWidth().padding(vertical = 10.dp).height(54.dp).clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(p.primary, p.primary2))).clickable { trySave() }, contentAlignment = Alignment.Center) {
            Text(tr("ذخیره", "Save"), color = p.onPrimary, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
    }
}
