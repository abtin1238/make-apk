package ir.abtin.sms

import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------- building blocks ----------
@Composable
fun SPage(title: String, back: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (back != null) { CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, back); Spacer(Modifier.width(14.dp)) }
            Text(title, color = p.text, fontSize = if (back == null) 38.sp else 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp), content = content)
    }
}

@Composable
fun SGroup(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(20.dp)
    if (title != null) Text(title, color = p.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 28.dp, end = 28.dp, top = 16.dp, bottom = 6.dp))
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp).clip(shape).background(p.surface).border(1.dp, p.line, shape), content = content)
}

@Composable
fun SNav(icon: ImageVector, title: String, sub: String?, onClick: () -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(p.primary.copy(alpha = .16f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = p.primary, modifier = Modifier.size(22.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) { Text(title, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); if (sub != null) Text(sub, color = p.sub, fontSize = 13.sp) }
    }
}

@Composable
fun SSwitch(title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, color = p.text, fontSize = 16.sp); if (sub != null) Text(sub, color = p.sub, fontSize = 12.sp) }
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = p.primary, checkedThumbColor = Color.White, uncheckedTrackColor = p.line, uncheckedThumbColor = p.sub, uncheckedBorderColor = p.line))
    }
}

@Composable
fun SAction(title: String, sub: String? = null, danger: Boolean = false, onClick: () -> Unit) {
    val p = LocalPal.current
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 13.dp)) {
        Text(title, color = if (danger) p.danger else p.text, fontSize = 16.sp); if (sub != null) Text(sub, color = p.sub, fontSize = 12.sp)
    }
}

@Composable
fun SChoice(title: String, options: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit) {
    val p = LocalPal.current
    Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text(title, color = p.text, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (k, label) ->
                val sel = k == selected
                Text(label, color = if (sel) Color.White else p.text, fontSize = 14.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) p.primary else p.bg.copy(alpha = .5f)).border(1.dp, if (sel) p.primary else p.line, RoundedCornerShape(50)).clickable { onPick(k) }.padding(horizontal = 16.dp, vertical = 8.dp))
            }
        }
    }
}

/** HSV sliders (hue / saturation / brightness) for a stored ARGB color; 0 = default. */
@Composable
fun ColorSliders(title: String, value: Int, default: Color, onChange: (Int) -> Unit) {
    val p = LocalPal.current
    val cur = if (value == 0) default else Color(value)
    val hsv = remember(value) { FloatArray(3).also { android.graphics.Color.colorToHSV(android.graphics.Color.argb(255, (cur.red * 255).toInt(), (cur.green * 255).toInt(), (cur.blue * 255).toInt()), it) } }
    var h by remember(value) { mutableFloatStateOf(hsv[0]) }
    var sat by remember(value) { mutableFloatStateOf(hsv[1]) }
    var v by remember(value) { mutableFloatStateOf(hsv[2]) }
    fun push() { onChange(android.graphics.Color.HSVToColor(floatArrayOf(h, sat, v))) }
    val live = Color(android.graphics.Color.HSVToColor(floatArrayOf(h, sat, v)))
    Column(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(26.dp).clip(CircleShape).background(live).border(1.dp, p.line, CircleShape))
            Spacer(Modifier.width(12.dp))
            Text(title, color = p.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
            if (value != 0) Text(tr("پیش‌فرض", "Reset"), color = p.primary, fontSize = 14.sp, modifier = Modifier.clip(RoundedCornerShape(50)).clickable { onChange(0) }.padding(horizontal = 10.dp, vertical = 4.dp))
        }
        val sc = SliderDefaults.colors(thumbColor = live, activeTrackColor = live, inactiveTrackColor = p.line)
        Text(tr("طیف رنگ", "Hue"), color = p.sub, fontSize = 12.sp)
        Slider(h, { h = it; push() }, valueRange = 0f..360f, colors = sc)
        Text(tr("اشباع", "Saturation"), color = p.sub, fontSize = 12.sp)
        Slider(sat, { sat = it; push() }, valueRange = 0f..1f, colors = sc)
        Text(tr("روشنایی", "Brightness"), color = p.sub, fontSize = 12.sp)
        Slider(v, { v = it; push() }, valueRange = 0f..1f, colors = sc)
    }
}

@Composable
fun BubbleShapePicker(selected: String, onPick: (String) -> Unit) {
    val p = LocalPal.current
    val opts = listOf("tail" to tr("دم‌دار", "Tail"), "rounded" to tr("نرم", "Rounded"), "pill" to tr("کپسولی", "Pill"), "square" to tr("چهارگوش", "Square"))
    Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text(tr("شکل حباب پیام", "Bubble shape"), color = p.text, fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            opts.forEach { (k, label) ->
                val sel = k == selected
                val cardShape = RoundedCornerShape(16.dp)
                Column(Modifier.weight(1f).clip(cardShape).background(if (sel) p.primary.copy(alpha = .16f) else p.bg.copy(alpha = .5f))
                    .border(if (sel) 2.dp else 1.dp, if (sel) p.primary else p.line, cardShape).clickable { onPick(k) }.padding(vertical = 10.dp, horizontal = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.fillMaxWidth().height(22.dp), contentAlignment = Alignment.CenterStart) {
                        Box(Modifier.width(46.dp).height(20.dp).background(SolidColor(p.inBubble), BubbleShape(false, k)))
                    }
                    Spacer(Modifier.height(5.dp))
                    Box(Modifier.fillMaxWidth().height(22.dp), contentAlignment = Alignment.CenterEnd) {
                        Box(Modifier.width(46.dp).height(20.dp).background(Brush.linearGradient(listOf(p.out1, p.out2)), BubbleShape(true, k)))
                    }
                    Text(label, color = if (sel) p.primary else p.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

// ---------- screens ----------
@Composable
fun SettingsScreen(repo: SmsRepo, act: ComponentActivity, nav: MutableState<Screen>, askDefault: () -> Unit) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    val page = Bus.page.value
    val back = { Bus.page.value = "" }
    val isDef = remember(Bus.tick.intValue) { isDefaultSms(act) }
    fun toast(n: Int) = Toast.makeText(act, if (n >= 0) "$n ✓" else "✗", Toast.LENGTH_LONG).show()
    val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) scope.launch(Dispatchers.IO) { val n = runCatching { repo.backup(u) }.getOrDefault(-1); withContext(Dispatchers.Main) { toast(n) } }
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch(Dispatchers.IO) { val n = runCatching { repo.restore(u) }.getOrDefault(-1); withContext(Dispatchers.Main) { toast(n) } }
    }
    val ring = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            @Suppress("DEPRECATION") val u = r.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            Prefs.notifSound.value = u?.toString() ?: ""
        }
    }
    when (page) {
        "general" -> SPage(tr("عمومی", "General"), back) {
            SGroup {
                SSwitch(tr("برنامه پیش‌فرض پیامک", "Default SMS app"), if (isDef) tr("آبتین SMS پیش‌فرض است ✓", "Abtin SMS is the default ✓") else tr("برای ارسال و دریافت لازم است", "Required to send & receive"), isDef) { if (!isDef) askDefault() }
            }
            SGroup(tr("ارسال و دریافت", "SEND & RECEIVE")) {
                SSwitch(tr("گزارش تحویل", "SMS delivery reports"), tr("نمایش ✓ ارسال و ✓✓ تحویل", "Show ✓ sent and ✓✓ delivered"), Prefs.deliveryReports.value) { Prefs.deliveryReports.value = it }
                SSwitch(tr("ارسال با دکمه Enter", "Enter key sends"), null, Prefs.enterSends.value) { Prefs.enterSends.value = it }
                SSwitch(tr("صدای ارسال پیام", "Outgoing message sounds"), null, Prefs.sendSound.value) { Prefs.sendSound.value = it }
                SSwitch(tr("پیام گروهی به‌صورت MMS", "Group messaging (MMS)"), tr("خاموش = ارسال جداگانه به هر نفر", "Off = send separately to each person"), Prefs.groupMms.value) { Prefs.groupMms.value = it }
                val simList = remember { repo.sims() }
                if (simList.size > 1) SChoice(tr("سیم‌کارت پیش‌فرض ارسال", "Default SIM for SMS"), listOf("-1" to tr("پیش‌فرض سیستم", "System default")) + simList.map { it.subId.toString() to "SIM ${it.slot} · ${it.name}" }, Prefs.sim.value.toString()) { Prefs.sim.value = it.toIntOrNull() ?: -1 }
            }
            SGroup(tr("نمایش", "DISPLAY")) {
                SSwitch(tr("نمایش آواتار مخاطب", "Show contact avatars"), null, Prefs.showAvatars.value) { Prefs.showAvatars.value = it }
                SSwitch(tr("ارقام فارسی در فهرست", "Persian digits in list"), null, Prefs.persianDigits.value) { Prefs.persianDigits.value = it }
                SChoice(tr("زبان", "Language"), listOf("system" to tr("سیستم", "System"), "fa" to "فارسی", "en" to "English"), Prefs.language.value) { Prefs.language.value = it }
            }
        }
        "notif" -> SPage(tr("اعلان‌ها", "Notifications"), back) {
            SGroup {
                SSwitch(tr("اعلان پیام‌ها", "Message notifications"), null, Prefs.notifications.value) { Prefs.notifications.value = it }
                SSwitch(tr("نمایش متن پیام در اعلان", "Show message preview"), tr("برای حریم خصوصی خاموش کنید", "Turn off for privacy"), Prefs.showPreview.value) { Prefs.showPreview.value = it }
                SSwitch(tr("نمایش محتوا در صفحه قفل", "Show content on lock screen"), null, Prefs.lockPreview.value) { Prefs.lockPreview.value = it }
                SSwitch(tr("لرزش", "Vibrate"), null, Prefs.vibrate.value) { Prefs.vibrate.value = it }
            }
            SGroup(tr("صدا", "SOUND")) {
                SAction(tr("صدای اعلان", "Notification sound"), if (Prefs.notifSound.value.isEmpty()) tr("پیش‌فرض", "Default") else tr("سفارشی", "Custom")) {
                    ring.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER).putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION))
                }
                if (Prefs.notifSound.value.isNotEmpty()) SAction(tr("بازگشت به صدای پیش‌فرض", "Reset to default sound")) { Prefs.notifSound.value = "" }
                if (Build.VERSION.SDK_INT >= 26) SAction(tr("تنظیمات اعلان سیستم", "System notification settings"), tr("اولویت، پاپ‌آپ و ...", "Importance, pop-up, …")) {
                    act.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName))
                }
            }
        }
        "suggest" -> SPage(tr("پیشنهادها در گفتگو", "Suggestions in chat"), back) {
            SGroup {
                SSwitch(tr("پاسخ‌های سریع", "Quick replies"), tr("نمایش چیپ‌های پاسخ بالای کادر پیام", "Show reply chips above the composer"), Prefs.showQuickReplies.value) { Prefs.showQuickReplies.value = it }
                SSwitch(tr("لینک‌ها و شماره‌های قابل لمس", "Suggested actions (links & numbers)"), tr("باز کردن لینک و شماره‌گیری با لمس", "Tap to open links and dial numbers"), Prefs.smartLinks.value) { Prefs.smartLinks.value = it }
                SSwitch(tr("دکمه کپی کد تأیید", "Copy verification codes"), tr("روی پیام‌های دارای کد یکبارمصرف", "Chip on one-time-code messages"), Prefs.codeChip.value) { Prefs.codeChip.value = it }
            }
            SGroup(tr("قالب‌های پاسخ سریع", "QUICK REPLY TEMPLATES")) {
                OutlinedTextField(Prefs.templates.value, { Prefs.templates.value = it }, minLines = 2, placeholder = { Text(tr("هر خط یک قالب (خالی = پیش‌فرض)", "One per line (empty = defaults)")) },
                    modifier = Modifier.fillMaxWidth().padding(14.dp))
            }
        }
        "spam" -> SPage(tr("اسپم و مسدود", "Spam & blocked"), back) {
            SGroup {
                SSwitch(tr("محافظت در برابر اسپم", "Spam protection"), tr("اسپم بی‌صدا به دستهٔ «اسپم» می‌رود", "Spam goes silently to the Spam category"), Prefs.spamFilter.value) { Prefs.spamFilter.value = it }
                OutlinedTextField(Prefs.spamWords.value, { Prefs.spamWords.value = it }, minLines = 2, placeholder = { Text(tr("کلمات اسپم دلخواه (هر خط یک کلمه)", "Custom spam words (one per line)")) },
                    modifier = Modifier.fillMaxWidth().padding(14.dp))
            }
            val blocked = csv(Prefs.blocked).toList(); val spam = csv(Prefs.spam).toList()
            SGroup(tr("شماره‌های مسدود", "BLOCKED NUMBERS")) {
                if (blocked.isEmpty()) Text(tr("موردی نیست", "None"), color = p.sub, modifier = Modifier.padding(18.dp))
                blocked.forEach { n -> SAction(n, tr("لمس برای رفع مسدودی", "Tap to unblock")) { removeFrom(Prefs.blocked, n) } }
            }
            SGroup(tr("شماره‌های اسپم", "SPAM NUMBERS")) {
                if (spam.isEmpty()) Text(tr("موردی نیست", "None"), color = p.sub, modifier = Modifier.padding(18.dp))
                spam.forEach { n -> SAction(n, tr("لمس برای «اسپم نیست»", "Tap for “Not spam”")) { markSpam(n, false) } }
            }
        }
        "look" -> SPage(tr("ظاهر", "Appearance"), back) {
            SGroup(tr("پیش‌نمایش", "PREVIEW")) {
                Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(p.bg, p.bg2))).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val tw = if (Prefs.bubbleShape.value == "tail") TAIL_DP.dp else 0.dp
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                        Text(tr("سلام عزیزم! امروز وقت داری؟", "Hi! Are you free today?"), color = p.text, fontSize = 16.sp,
                            modifier = Modifier.background(SolidColor(p.inBubble), BubbleShape(false, Prefs.bubbleShape.value)).padding(start = 12.dp + tw, end = 12.dp, top = 8.dp, bottom = 8.dp))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Text(tr("بله حتماً 🙂", "Sure 🙂"), color = p.text, fontSize = 16.sp,
                            modifier = Modifier.background(Brush.linearGradient(listOf(p.out1, p.out2)), BubbleShape(true, Prefs.bubbleShape.value)).padding(start = 12.dp, end = 12.dp + tw, top = 8.dp, bottom = 8.dp))
                    }
                }
                BubbleShapePicker(Prefs.bubbleShape.value) { Prefs.bubbleShape.value = it }
            }
            SGroup(tr("رنگ‌ها", "COLORS")) {
                ColorSliders(tr("رنگ اصلی (دکمه‌ها و تأکید)", "Accent color"), Prefs.accentColor.value, Def.accent) { Prefs.accentColor.value = it }
                HorizontalDivider(color = p.line)
                ColorSliders(tr("رنگ پس‌زمینه", "Background"), Prefs.chatBackground.value, Def.bg) { Prefs.chatBackground.value = it }
                HorizontalDivider(color = p.line)
                ColorSliders(tr("حباب دریافتی", "Incoming bubble"), Prefs.incomingBubble.value, Def.inBubble) { Prefs.incomingBubble.value = it }
                HorizontalDivider(color = p.line)
                ColorSliders(tr("حباب ارسالی", "Outgoing bubble"), Prefs.outgoingBubble.value, Def.out) { Prefs.outgoingBubble.value = it }
                HorizontalDivider(color = p.line)
                SAction(tr("بازنشانی همه رنگ‌ها", "Reset all colors"), danger = true) { Prefs.accentColor.value = 0; Prefs.chatBackground.value = 0; Prefs.incomingBubble.value = 0; Prefs.outgoingBubble.value = 0; Prefs.bubbleShape.value = "tail" }
            }
            SGroup(tr("متن", "TEXT")) {
                Column(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
                    Text(tr("اندازه متن", "Text size") + "  ${(Prefs.fontScale.value * 100).toInt()}%", color = p.text)
                    Slider(Prefs.fontScale.value, { Prefs.fontScale.value = it }, valueRange = 0.8f..1.4f, steps = 5, colors = SliderDefaults.colors(thumbColor = p.primary, activeTrackColor = p.primary, inactiveTrackColor = p.line))
                }
            }
        }
        "swipe" -> SPage(tr("اکشن‌های کشیدن", "Swipe actions"), back) {
            val opts = listOf("delete" to tr("حذف", "Delete"), "archive" to tr("بایگانی", "Archive"), "read" to tr("خوانده/نخوانده", "Read / unread"), "none" to tr("هیچ", "None"))
            SGroup {
                SChoice(tr("کشیدن به چپ", "Swipe left"), opts, Prefs.swipeLeft.value) { Prefs.swipeLeft.value = it }
                SChoice(tr("کشیدن به راست", "Swipe right"), opts, Prefs.swipeRight.value) { Prefs.swipeRight.value = it }
                SSwitch(tr("نمایش راهنمای کشیدن در فهرست", "Show swipe hint in list"), null, !Prefs.swipeHintDone.value) { Prefs.swipeHintDone.value = !it }
            }
            Text(tr("با کشیدن نصفه، دکمه نمایش داده می‌شود؛ با ادامه کشیدن، عمل انجام می‌شود.", "A short swipe reveals the button; keep swiping to run the action."), color = p.sub, fontSize = 13.sp, modifier = Modifier.padding(28.dp, 10.dp))
        }
        "adv" -> SPage(tr("پیشرفته", "Advanced"), back) {
            SGroup(tr("MMS", "MMS")) {
                SSwitch(tr("دانلود خودکار MMS", "Auto-download MMS"), tr("خاموش = اعلان برای دانلود دستی", "Off = notification to download manually"), Prefs.autoDownloadMms.value) { Prefs.autoDownloadMms.value = it }
                SSwitch(tr("دانلود خودکار در رومینگ", "Auto-download MMS when roaming"), null, Prefs.autoDownloadRoaming.value) { Prefs.autoDownloadRoaming.value = it }
            }
            SGroup(tr("پیام‌ها", "MESSAGES")) {
                SSwitch(tr("استفاده از نویسه‌های ساده", "Use simple characters"), tr("علائم نگارشی و حروف لاتین تزئینی به ASCII تبدیل می‌شوند", "Convert smart punctuation and accents in outgoing SMS"), Prefs.simpleChars.value) { Prefs.simpleChars.value = it }
                SSwitch(tr("حذف خودکار کدهای تأیید بعد از ۲۴ ساعت", "Auto-delete OTPs after 24 hours"), null, Prefs.autoDeleteOtp.value) { Prefs.autoDeleteOtp.value = it }
            }
            SGroup(tr("داده‌ها", "DATA")) {
                SAction(tr("علامت‌گذاری همه به‌عنوان خوانده‌شده", "Mark all as read")) { scope.launch(Dispatchers.IO) { runCatching { repo.markAllRead() } } }
                SAction(tr("پشتیبان‌گیری از پیامک‌ها", "Back up messages")) { exp.launch("abtin-sms-backup.json") }
                SAction(tr("بازیابی از فایل پشتیبان", "Restore from backup")) { imp.launch(arrayOf("application/json", "*/*")) }
                SAction(tr("پاک‌کردن لیست پیام‌های ستاره‌دار", "Clear starred list"), danger = true) { Prefs.starred.value = "" }
            }
        }
        "privacy" -> SPage(tr("حریم خصوصی و امنیت", "Privacy & security"), back) {
            var pinIn by remember { mutableStateOf("") }
            SGroup(tr("قفل برنامه با پین", "APP LOCK")) {
                OutlinedTextField(pinIn, { pinIn = it.filter { ch -> ch.isDigit() }.take(8) }, singleLine = true, label = { Text(tr("پین جدید (۴ تا ۸ رقم)", "New PIN (4-8 digits)")) },
                    modifier = Modifier.fillMaxWidth().padding(14.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                Row(Modifier.padding(horizontal = 14.dp).padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button({ if (pinIn.length >= 4) { Prefs.pin.value = pinIn; pinIn = "" } }, colors = ButtonDefaults.buttonColors(containerColor = p.primary, contentColor = Color.White)) { Text(tr("تنظیم پین", "Set PIN")) }
                    if (Prefs.pin.value.isNotEmpty()) TextButton({ Prefs.pin.value = "" }) { Text(tr("حذف پین", "Remove PIN"), color = p.danger) }
                }
            }
        }
        "about" -> SPage(tr("درباره", "About"), back) {
            SGroup {
                Column(Modifier.padding(18.dp)) {
                    Text("آبتین SMS · 1.2.0", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(tr("برنامه پیش‌فرض SMS/MMS", "Default SMS/MMS app"), color = p.sub)
                }
            }
        }
        else -> SPage(tr("تنظیمات", "Settings"), null) {
            SGroup {
                SSwitch(tr("برنامه پیش‌فرض پیامک", "Default SMS app"), if (isDef) tr("آبتین SMS پیش‌فرض است ✓", "Abtin SMS is the default ✓") else tr("آبتین SMS پیش‌فرض نیست", "Abtin SMS is not the default"), isDef) { if (!isDef) askDefault() }
            }
            SGroup {
                SNav(Icons.Default.Tune, tr("عمومی", "General"), tr("ارسال، سیم‌کارت، زبان", "Send, SIM, language")) { Bus.page.value = "general" }
                SNav(Icons.Default.Notifications, tr("اعلان‌ها", "Notifications"), tr("صدا، پیش‌نمایش، صفحه قفل", "Sound, preview, lock screen")) { Bus.page.value = "notif" }
                SNav(Icons.Default.Lightbulb, tr("پیشنهادها در گفتگو", "Suggestions in chat"), tr("پاسخ سریع، لینک، کد تأیید", "Quick replies, links, codes")) { Bus.page.value = "suggest" }
                SNav(Icons.Default.Report, tr("اسپم و مسدود", "Spam & blocked"), tr("فیلتر و شماره‌های مسدود", "Filter and blocked numbers")) { Bus.page.value = "spam" }
                SNav(Icons.Default.Palette, tr("ظاهر", "Appearance"), tr("رنگ‌ها، شکل حباب، اندازه متن", "Colors, bubble shape, text size")) { Bus.page.value = "look" }
                SNav(Icons.Default.TouchApp, tr("اکشن‌های کشیدن", "Swipe actions"), tr("حذف، بایگانی، خوانده", "Delete, archive, read")) { Bus.page.value = "swipe" }
                SNav(Icons.Default.Sms, tr("پیشرفته", "Advanced"), tr("MMS، نویسه‌ها، پشتیبان‌گیری", "MMS, characters, backup")) { Bus.page.value = "adv" }
                SNav(Icons.Default.Lock, tr("حریم خصوصی و امنیت", "Privacy & security"), tr("قفل با پین", "PIN lock")) { Bus.page.value = "privacy" }
                SNav(Icons.Default.Info, tr("درباره", "About"), "1.2.0") { Bus.page.value = "about" }
            }
        }
    }
}
