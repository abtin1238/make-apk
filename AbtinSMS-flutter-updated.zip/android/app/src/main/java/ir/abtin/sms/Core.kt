package ir.abtin.sms

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SmsMessage
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

class AbtinApp : Application() {
    override fun onCreate() { super.onCreate(); Prefs.init(this); Notifier.channel(this) }
}

/** Persistent + observable settings. */
class Setting<T : Any>(private val key: String, private val def: T) {
    private var st: MutableState<T>? = null
    @Suppress("UNCHECKED_CAST")
    private fun s(): MutableState<T> = st ?: run {
        val sp = Prefs.sp
        val v = when (def) {
            is Boolean -> sp.getBoolean(key, def)
            is String -> sp.getString(key, def) ?: def
            is Float -> sp.getFloat(key, def)
            is Int -> sp.getInt(key, def)
            else -> def
        } as T
        mutableStateOf(v).also { st = it }
    }
    var value: T
        get() = s().value
        set(v) {
            s().value = v
            val e = Prefs.sp.edit()
            when (v) { is Boolean -> e.putBoolean(key, v); is String -> e.putString(key, v); is Float -> e.putFloat(key, v); is Int -> e.putInt(key, v) }
            e.apply()
        }
}

object Prefs {
    lateinit var sp: SharedPreferences
    fun init(c: Context) { if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("abtin", 0) }
    val language = Setting("language", "system")    // system | fa | en
    val fontScale = Setting("fontScale", 1.0f)
    val showAvatars = Setting("showAvatars", true)
    val deliveryReports = Setting("deliveryReports", true)
    val enterSends = Setting("enterSends", false)
    val notifications = Setting("notifications", true)
    val vibrate = Setting("vibrate", true)
    val showPreview = Setting("showPreview", true)
    val pinned = Setting("pinned", "")              // thread ids, comma separated
    val archived = Setting("archived", "")          // thread ids
    val pin = Setting("pin", "")
    val templates = Setting("templates", "")
    val blocked = Setting("blocked", "")            // normalized numbers
    val spamFilter = Setting("spamFilter", true)
    val spam = Setting("spam", "")                  // normalized numbers flagged as spam
    val spamOk = Setting("spamOk", "")              // user whitelist (not spam)
    val spamWords = Setting("spamWords", "")        // custom words, one per line
    val sim = Setting("sim", -1)                    // default subscription id, -1 = system default
    val groupMms = Setting("groupMms", true)
    val bubbleShape = Setting("bubbleShape", "tail")     // tail | rounded | pill | square
    val chatBackground = Setting("chatBackground", 0)    // ARGB; 0 = default
    val incomingBubble = Setting("incomingBubble", 0)
    val outgoingBubble = Setting("outgoingBubble", 0)
    val accentColor = Setting("accentColor", 0)
    val swipeLeft = Setting("swipeLeft", "delete")       // delete | archive | read | none
    val swipeRight = Setting("swipeRight", "archive")
    val swipeHintDone = Setting("swipeHintDone", false)
    val showQuickReplies = Setting("showQuickReplies", false)
    val smartLinks = Setting("smartLinks", true)
    val codeChip = Setting("codeChip", true)             // "copy code" chip on OTP messages
    val sendSound = Setting("sendSound", false)
    val lockPreview = Setting("lockPreview", true)
    val notifSound = Setting("notifSound", "")
    val autoDownloadMms = Setting("autoDownloadMms", true)
    val autoDownloadRoaming = Setting("autoDownloadRoaming", false)
    val simpleChars = Setting("simpleChars", false)
    val autoDeleteOtp = Setting("autoDeleteOtp", false)
    val persianDigits = Setting("persianDigits", true)
    val starred = Setting("starred", "")                 // "s<id>" / "m<id>"
    val muted = Setting("muted", "")                     // thread ids
    val sendDelay = Setting("sendDelay", 0)              // seconds of undo window, 0 = off
}

fun csv(s: Setting<String>): Set<String> = s.value.split(',').filter { it.isNotBlank() }.toSet()
fun toggle(s: Setting<String>, k: String) { val c = csv(s).toMutableSet(); if (!c.add(k)) c.remove(k); s.value = c.joinToString(",") }
fun addTo(s: Setting<String>, k: String) { val c = csv(s).toMutableSet(); c.add(k); s.value = c.joinToString(",") }
fun removeFrom(s: Setting<String>, k: String) { val c = csv(s).toMutableSet(); c.remove(k); s.value = c.joinToString(",") }
fun markSpam(n: String, spam: Boolean) {
    if (spam) { addTo(Prefs.spam, n); removeFrom(Prefs.spamOk, n) } else { removeFrom(Prefs.spam, n); addTo(Prefs.spamOk, n) }
}
fun norm(a: String): String = a.filter { it.isDigit() }.takeLast(9).ifEmpty { a }

data class Conv(val threadId: Long, val address: String, val name: String?, val snippet: String, val date: Long, val unread: Int)
data class Msg(val id: Long, val threadId: Long, val address: String, val body: String, val date: Long, val type: Int, val status: Int,
               val mms: Boolean = false, val atts: List<Att> = emptyList())
data class ContactItem(val name: String, val number: String)

class SmsRepo(val ctx: Context) {
    val cr = ctx.contentResolver
    private val nameCache = HashMap<String, String?>()
    companion object {
        const val ACTION_SENT = "ir.abtin.sms.SENT"
        const val ACTION_DELIVERED = "ir.abtin.sms.DELIVERED"
        private val rc = AtomicInteger(1)
    }

    fun name(address: String): String? = nameCache.getOrPut(address) {
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) null
        else try {
            cr.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }

    fun conversations(): List<Conv> = try { convsThreads() } catch (e: Exception) { convsSmsOnly() }

    private fun convsThreads(): List<Conv> {
        val canon = HashMap<String, String>()
        cr.query(Uri.parse("content://mms-sms/canonical-addresses"), arrayOf("_id", "address"), null, null, null)?.use { c ->
            while (c.moveToNext()) canon[c.getString(0)] = c.getString(1) ?: ""
        }
        val unread = HashMap<Long, Int>()
        listOf(Telephony.Sms.CONTENT_URI to "read=0", Telephony.Mms.CONTENT_URI to "read=0 AND msg_box=1").forEach { (u, w) ->
            cr.query(u, arrayOf("thread_id"), w, null, null)?.use { c ->
                while (c.moveToNext()) { val t = c.getLong(0); unread[t] = (unread[t] ?: 0) + 1 }
            }
        }
        val out = ArrayList<Conv>()
        cr.query(Uri.parse("content://mms-sms/conversations?simple=true"),
            arrayOf("_id", "date", "message_count", "recipient_ids", "snippet", "has_attachment"), null, null, "date DESC")?.use { c ->
            while (c.moveToNext()) {
                if (c.getInt(2) == 0) continue
                val addrs = (c.getString(3) ?: "").split(' ').mapNotNull { canon[it] }.filter { it.isNotBlank() }
                if (addrs.isEmpty()) continue
                var sn = c.getString(4) ?: ""
                if (sn.isBlank() && c.getInt(5) == 1) sn = "📎 MMS"
                val tid = c.getLong(0)
                val nm = if (addrs.size == 1) name(addrs[0]) else addrs.joinToString(", ") { name(it) ?: it }
                out.add(Conv(tid, addrs.joinToString(","), nm, sn, c.getLong(1), unread[tid] ?: 0))
            }
        } ?: throw IllegalStateException("no threads")
        return out
    }

    private fun convsSmsOnly(): List<Conv> {
        val out = LinkedHashMap<Long, Conv>(); val unread = HashMap<Long, Int>()
        cr.query(Telephony.Sms.CONTENT_URI, arrayOf("thread_id", "address", "body", "date", "read"), null, null, "date DESC")?.use { c ->
            while (c.moveToNext()) {
                val t = c.getLong(0)
                if (c.getInt(4) == 0) unread[t] = (unread[t] ?: 0) + 1
                if (t !in out) { val a = c.getString(1) ?: ""; out[t] = Conv(t, a, name(a), c.getString(2) ?: "", c.getLong(3), 0) }
            }
        }
        return out.values.map { it.copy(unread = unread[it.threadId] ?: 0) }
    }

    fun messages(threadId: Long): List<Msg> {
        val l = ArrayList<Msg>()
        cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "thread_id", "address", "body", "date", "type", "status"),
            "thread_id=?", arrayOf(threadId.toString()), "date ASC")?.use { c ->
            while (c.moveToNext()) l += Msg(c.getLong(0), c.getLong(1), c.getString(2) ?: "", c.getString(3) ?: "", c.getLong(4), c.getInt(5), c.getInt(6))
        }
        return (l + runCatching { mmsMessages(threadId) }.getOrDefault(emptyList())).sortedBy { it.date }
    }

    fun searchMessages(q: String): List<Msg> {
        val l = ArrayList<Msg>()
        cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "thread_id", "address", "body", "date", "type", "status"),
            "body LIKE ?", arrayOf("%" + q + "%"), "date DESC LIMIT 100")?.use { c ->
            while (c.moveToNext()) l += Msg(c.getLong(0), c.getLong(1), c.getString(2) ?: "", c.getString(3) ?: "", c.getLong(4), c.getInt(5), c.getInt(6))
        }
        return l
    }

    fun backup(u: Uri): Int {
        val arr = org.json.JSONArray()
        cr.query(Telephony.Sms.CONTENT_URI, arrayOf("address", "body", "date", "date_sent", "type", "read"), null, null, "date ASC")?.use { c ->
            while (c.moveToNext()) arr.put(org.json.JSONObject().put("a", c.getString(0) ?: "").put("b", c.getString(1) ?: "")
                .put("d", c.getLong(2)).put("ds", c.getLong(3)).put("t", c.getInt(4)).put("r", c.getInt(5)))
        }
        val out = cr.openOutputStream(u) ?: throw java.io.IOException("open failed")
        out.use { it.write(arr.toString().toByteArray(Charsets.UTF_8)) }
        return arr.length()
    }

    fun restore(u: Uri): Int {
        val inp = cr.openInputStream(u) ?: return -1
        val arr = org.json.JSONArray(inp.use { String(it.readBytes(), Charsets.UTF_8) })
        var n = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val a = o.getString("a"); val d = o.getLong("d"); val t = o.getInt("t")
            val dup = cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id"), "address=? AND date=? AND type=?",
                arrayOf(a, d.toString(), t.toString()), null)?.use { it.count > 0 } ?: false
            if (dup) continue
            val v = ContentValues().apply {
                put("address", a); put("body", o.getString("b")); put("date", d); put("date_sent", o.optLong("ds"))
                put("type", t); put("read", o.optInt("r", 1)); put("thread_id", threadIdFor(a))
            }
            if (cr.insert(Telephony.Sms.CONTENT_URI, v) != null) n++
        }
        return n
    }

    fun threadIdFor(address: String): Long = try {
        Telephony.Threads.getOrCreateThreadId(ctx, address.split(',', ';').map { it.trim() }.filter { it.isNotEmpty() }.toSet())
    } catch (e: Exception) { 0L }

    fun contacts(): List<ContactItem> {
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return emptyList()
        val l = ArrayList<ContactItem>()
        cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")?.use { c ->
            while (c.moveToNext()) l += ContactItem(c.getString(0) ?: "", c.getString(1) ?: "")
        }
        return l.distinctBy { it.number.filter { ch -> ch.isDigit() } }
    }

    fun markRead(threadId: Long) {
        val v = ContentValues().apply { put("read", 1); put("seen", 1) }
        cr.update(Telephony.Sms.CONTENT_URI, v, "thread_id=? AND read=0", arrayOf(threadId.toString()))
        runCatching { cr.update(Telephony.Mms.CONTENT_URI, v, "thread_id=? AND read=0", arrayOf(threadId.toString())) }
    }
    fun markAllRead() {
        val v = ContentValues().apply { put("read", 1); put("seen", 1) }
        cr.update(Telephony.Sms.CONTENT_URI, v, "read=0", null)
        runCatching { cr.update(Telephony.Mms.CONTENT_URI, v, "read=0", null) }
    }
    fun deleteThread(threadId: Long) {
        cr.delete(Telephony.Sms.CONTENT_URI, "thread_id=?", arrayOf(threadId.toString()))
        runCatching { cr.delete(Telephony.Mms.CONTENT_URI, "thread_id=?", arrayOf(threadId.toString())) }
        runCatching { cr.delete(Uri.parse("content://mms-sms/conversations/$threadId"), null, null) }
    }
    fun deleteMessage(id: Long, mms: Boolean = false) {
        if (mms) cr.delete(Telephony.Mms.CONTENT_URI, "_id=?", arrayOf(id.toString()))
        else cr.delete(Telephony.Sms.CONTENT_URI, "_id=?", arrayOf(id.toString()))
    }

    fun send(address: String, body0: String, subId: Int = Prefs.sim.value) {
        val body = if (Prefs.simpleChars.value) simplify(body0) else body0
        val reports = Prefs.deliveryReports.value
        val v = ContentValues().apply {
            put("address", address); put("body", body); put("date", System.currentTimeMillis()); put("read", 1)
            put("type", Telephony.Sms.MESSAGE_TYPE_OUTBOX); put("thread_id", threadIdFor(address))
            put("status", if (reports) Telephony.Sms.STATUS_PENDING else Telephony.Sms.STATUS_NONE)
            if (subId >= 0) put("sub_id", subId)
        }
        val uri = cr.insert(Telephony.Sms.CONTENT_URI, v) ?: throw SecurityException("not default SMS app")
        val sm = smsManagerFor(ctx, subId)
        val parts = sm.divideMessage(body)
        val sent = ArrayList<PendingIntent>(); val del = ArrayList<PendingIntent>()
        for (i in parts.indices) {
            sent += pi(ACTION_SENT, uri, i == parts.size - 1)
            if (reports) del += pi(ACTION_DELIVERED, uri, i == parts.size - 1, true)
        }
        sm.sendMultipartTextMessage(address, null, parts, sent, if (reports) del else null)
    }

    private fun pi(action: String, uri: Uri, last: Boolean, mutable: Boolean = false): PendingIntent =
        PendingIntent.getBroadcast(ctx, rc.getAndIncrement(),
            Intent(ctx, StatusReceiver::class.java).setAction(action).setData(uri).putExtra("last", last),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (!mutable) PendingIntent.FLAG_IMMUTABLE else if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0))
}

/** Updates sent / delivery state of outgoing messages. */
class StatusReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == ACTION_MMS_DL) {
            val code = resultCode; val pr = goAsync()
            Thread { try { Prefs.init(c); SmsRepo(c).onMmsDownloaded(i, code) } catch (e: Exception) { } finally { pr.finish() } }.start()
            return
        }
        val uri = i.data ?: return
        val last = i.getBooleanExtra("last", true)
        val v = ContentValues()
        when (i.action) {
            ACTION_MMS_SENT -> {
                v.put("msg_box", if (resultCode == Activity.RESULT_OK) 2 else 5)
                i.getStringExtra("file")?.let { File(it).delete() }
            }
            SmsRepo.ACTION_SENT ->
                if (resultCode == Activity.RESULT_OK) { if (last) v.put("type", Telephony.Sms.MESSAGE_TYPE_SENT) }
                else { v.put("type", Telephony.Sms.MESSAGE_TYPE_FAILED); v.put("error_code", resultCode) }
            SmsRepo.ACTION_DELIVERED -> if (last) {
                val ok = try {
                    val pdu = i.getByteArrayExtra("pdu"); val fmt = i.getStringExtra("format")
                    pdu == null || SmsMessage.createFromPdu(pdu, fmt).status == 0
                } catch (e: Exception) { true }
                v.put("status", if (ok) Telephony.Sms.STATUS_COMPLETE else Telephony.Sms.STATUS_FAILED)
                v.put("date_sent", System.currentTimeMillis())
            }
        }
        if (v.size() > 0) try { c.contentResolver.update(uri, v, null, null) } catch (e: Exception) {}
    }
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        Prefs.init(c)
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        val sub = i.getIntExtra("subscription", -1)
        val repo = SmsRepo(c)
        msgs.groupBy { it.originatingAddress ?: "" }.forEach { (addr, list) ->
            val body = list.joinToString("") { it.messageBody ?: "" }
            val blocked = norm(addr) in csv(Prefs.blocked)
            val spam = !blocked && Spam.check(repo, addr, body)
            if (spam) addTo(Prefs.spam, norm(addr))
            val quiet = blocked || spam
            val v = ContentValues().apply {
                put("address", addr); put("body", body); put("date", System.currentTimeMillis())
                put("date_sent", list[0].timestampMillis); put("read", if (quiet) 1 else 0); put("seen", if (quiet) 1 else 0); put("type", 1)
                if (sub >= 0) put("sub_id", sub)
            }
            try { c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v) } catch (e: Exception) { return@forEach }
            if (quiet) return@forEach
            Notifier.show(c, repo.threadIdFor(addr), addr, repo.name(addr), body)
        }
    }
}

class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.WAP_PUSH_DELIVER_ACTION) return
        Prefs.init(c)
        val data = i.getByteArrayExtra("data") ?: return
        val n = Pdu.parse(data).takeIf { it.type == 0x82 } ?: Pdu.fromPush(data)?.takeIf { it.type == 0x82 } ?: return
        val loc = n.loc ?: return
        val sub = i.getIntExtra("subscription", -1)
        val roaming = try { c.getSystemService(android.telephony.TelephonyManager::class.java)?.isNetworkRoaming == true } catch (e: Exception) { false }
        if (!Prefs.autoDownloadMms.value || (roaming && !Prefs.autoDownloadRoaming.value)) { Notifier.mmsPending(c, loc, n.from ?: "", sub, n.tx ?: ""); return }
        val pr = goAsync()
        Thread { try { SmsRepo(c).downloadMms(loc, n.from ?: "", sub, n.tx ?: "") } catch (e: Exception) { } finally { pr.finish() } }.start()
    }
}

class RespondService : Service() {
    override fun onBind(i: Intent?) = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val to = i?.data?.schemeSpecificPart?.substringBefore('?')
        val msg = i?.getStringExtra(Intent.EXTRA_TEXT)
        Prefs.init(this)
        if (!to.isNullOrBlank() && !msg.isNullOrBlank()) runCatching { SmsRepo(this).sendAny(to, msg) }
        stopSelf(); return START_NOT_STICKY
    }
}

object Notifier {
    const val CH = "messages"
    var activeThread = -1L
    var foreground = false

    fun channel(c: Context) { chId(c) }

    fun chId(c: Context): String {
        val snd = Prefs.notifSound.value
        val id = if (snd.isEmpty()) CH else CH + "_" + snd.hashCode().toUInt().toString(16)
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(id) == null) {
                val ch = NotificationChannel(id, "Messages / پیام‌ها", NotificationManager.IMPORTANCE_HIGH)
                if (snd.isNotEmpty()) ch.setSound(Uri.parse(snd), android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION).build())
                nm.createNotificationChannel(ch)
            }
        }
        return id
    }

    fun mmsPending(c: Context, loc: String, from: String, sub: Int, tx: String) {
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val pi = PendingIntent.getBroadcast(c, 777, Intent(c, NotifActionReceiver::class.java).setAction("MMS_DL")
            .putExtra("loc", loc).putExtra("from", from).putExtra("sub", sub).putExtra("tx", tx), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = NotificationCompat.Builder(c, chId(c)).setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(if (isFa()) "پیام چندرسانه‌ای جدید" else "New multimedia message")
            .setContentText(if (isFa()) "برای دریافت لمس کنید" else "Tap to download").setContentIntent(pi).setAutoCancel(true).build()
        c.getSystemService(NotificationManager::class.java).notify(777, n)
    }

    fun show(c: Context, thread: Long, address: String, name: String?, body: String) {
        Prefs.init(c)
        if (!Prefs.notifications.value) return
        if (thread.toString() in csv(Prefs.muted)) return
        if (foreground && activeThread == thread) return
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val id = thread.toInt()
        val open = PendingIntent.getActivity(c, id, Intent(c, MainActivity::class.java)
            .putExtra("thread", thread).putExtra("address", address)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val read = PendingIntent.getBroadcast(c, id, Intent(c, NotifActionReceiver::class.java)
            .setAction("READ").putExtra("thread", thread), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val replyFlags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
        val reply = PendingIntent.getBroadcast(c, id + 1_000_000, Intent(c, NotifActionReceiver::class.java)
            .setAction("REPLY").putExtra("thread", thread).putExtra("address", address), replyFlags)
        val ri = RemoteInput.Builder("reply").setLabel("Reply / پاسخ").build()
        val n = NotificationCompat.Builder(c, chId(c))
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle(name ?: address)
            .setContentText(if (Prefs.showPreview.value) body else "New message / پیام جدید")
            .setStyle(NotificationCompat.BigTextStyle().bigText(if (Prefs.showPreview.value) body else "New message / پیام جدید"))
            .setCategory(NotificationCompat.CATEGORY_MESSAGE).setAutoCancel(true).setContentIntent(open)
            .setVisibility(if (Prefs.lockPreview.value) NotificationCompat.VISIBILITY_PUBLIC else NotificationCompat.VISIBILITY_PRIVATE)
            .setDefaults(if (Prefs.vibrate.value) Notification.DEFAULT_ALL else Notification.DEFAULT_SOUND)
            .also { if (Prefs.notifSound.value.isNotEmpty()) it.setSound(Uri.parse(Prefs.notifSound.value)) }
            .addAction(NotificationCompat.Action.Builder(0, "Reply / پاسخ", reply).addRemoteInput(ri).build())
            .addAction(0, "Read / خوانده شد", read)
            .build()
        c.getSystemService(NotificationManager::class.java).notify(id, n)
    }
}

class NotifActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Prefs.init(c)
        if (i.action == "MMS_DL") {
            c.getSystemService(NotificationManager::class.java).cancel(777)
            val pr = goAsync()
            Thread { try { SmsRepo(c).downloadMms(i.getStringExtra("loc") ?: return@Thread, i.getStringExtra("from") ?: "", i.getIntExtra("sub", -1), i.getStringExtra("tx") ?: "") } catch (e: Exception) { } finally { pr.finish() } }.start()
            return
        }
        val thread = i.getLongExtra("thread", 0)
        val repo = SmsRepo(c)
        when (i.action) {
            "READ" -> runCatching { repo.markRead(thread) }
            "REPLY" -> {
                val t = RemoteInput.getResultsFromIntent(i)?.getCharSequence("reply")?.toString()
                val a = i.getStringExtra("address")
                if (!t.isNullOrBlank() && a != null) runCatching { repo.sendAny(a, t); repo.markRead(thread) }
            }
        }
        c.getSystemService(NotificationManager::class.java).cancel(thread.toInt())
    }
}
