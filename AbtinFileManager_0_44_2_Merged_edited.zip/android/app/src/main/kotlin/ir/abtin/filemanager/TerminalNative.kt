package ir.abtin.filemanager

import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/** Owns interactive (pipe-based, non-PTY) /system/bin/sh sessions for one Activity. */
class TerminalNative(messenger: BinaryMessenger) : EventChannel.StreamHandler {
    private val main = Handler(Looper.getMainLooper())
    private val sessions = ConcurrentHashMap<String, Session>()
    @Volatile private var eventSink: EventChannel.EventSink? = null

    init {
        MethodChannel(messenger, "abtin/terminal").setMethodCallHandler(::onMethodCall)
        EventChannel(messenger, "abtin/terminal/events").setStreamHandler(this)
    }

    private fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "start" -> start(call, result)
            "writeLine" -> write(call, result, appendNewline = true)
            "writeRaw" -> write(call, result, appendNewline = false)
            "close" -> {
                val id = call.argument<String>("sessionId")
                result.success(id != null && closeSession(id))
            }
            "closeAll" -> {
                closeAll()
                result.success(true)
            }
            else -> result.notImplemented()
        }
    }

    private fun start(call: MethodCall, result: MethodChannel.Result) {
        var started: Process? = null
        var created: Session? = null
        try {
            val requested = call.argument<String>("cwd")
                ?: throw IllegalArgumentException("مسیر کاری مشخص نشده است")
            val directory = File(requested).canonicalFile
            if (!directory.exists() || !directory.isDirectory) {
                throw IllegalArgumentException("مسیر کاری باید پوشه‌ای موجود باشد")
            }
            if (!directory.canRead() || !directory.canExecute()) {
                throw IllegalArgumentException("دسترسی لازم برای ورود به این پوشه وجود ندارد")
            }

            val process = ProcessBuilder("/system/bin/sh")
                .directory(directory)
                .redirectErrorStream(true)
                .start()
            started = process
            val id = UUID.randomUUID().toString()
            val session = Session(
                id = id,
                process = process,
                writer = BufferedWriter(OutputStreamWriter(process.outputStream, StandardCharsets.UTF_8)),
                reader = BufferedReader(InputStreamReader(process.inputStream, StandardCharsets.UTF_8)),
            )
            created = session
            sessions[id] = session
            session.readerThread = Thread({ readOutput(session) }, "terminal-reader-$id").apply {
                isDaemon = true
                start()
            }
            result.success(mapOf("sessionId" to id, "cwd" to directory.path))
        } catch (e: Throwable) {
            val session = created
            if (session != null) {
                sessions.remove(session.id, session)
                session.terminate()
            } else {
                try { started?.destroy() } catch (_: Throwable) {}
                try { started?.inputStream?.close() } catch (_: Throwable) {}
                try { started?.outputStream?.close() } catch (_: Throwable) {}
            }
            result.error("TERMINAL_START", e.message ?: "راه‌اندازی shell ناموفق بود", null)
        }
    }

    private fun write(call: MethodCall, result: MethodChannel.Result, appendNewline: Boolean) {
        val id = call.argument<String>("sessionId")
        val text = call.argument<String>("text")
        if (id == null || text == null) {
            result.error("TERMINAL_ARGUMENT", "شناسهٔ نشست یا متن ورودی نامعتبر است", null)
            return
        }
        val session = sessions[id]
        if (session == null || !isProcessAlive(session.process)) {
            result.error("TERMINAL_CLOSED", "نشست shell فعال نیست", null)
            return
        }
        try {
            synchronized(session.writeLock) {
                if (session.closed || !isProcessAlive(session.process)) {
                    throw IllegalStateException("نشست shell فعال نیست")
                }
                session.writer.write(text)
                if (appendNewline) session.writer.newLine()
                session.writer.flush()
            }
            result.success(true)
        } catch (e: Throwable) {
            result.error("TERMINAL_WRITE", e.message ?: "نوشتن در stdin ناموفق بود", null)
        }
    }

    private fun readOutput(session: Session) {
        val buffer = CharArray(2048)
        try {
            while (true) {
                val count = session.reader.read(buffer)
                if (count < 0) break
                if (count > 0) emit(mapOf(
                    "sessionId" to session.id,
                    "type" to "output",
                    "text" to String(buffer, 0, count),
                ))
            }
        } catch (_: Throwable) {
            // Closing a session closes its pipes; this is an expected reader exit.
        } finally {
            val exitCode = try {
                session.process.waitFor()
            } catch (_: InterruptedException) {
                Thread.currentThread().interrupt()
                null
            } catch (_: Throwable) {
                null
            }
            sessions.remove(session.id, session)
            session.closeStreams()
            emit(mapOf("sessionId" to session.id, "type" to "exit", "exitCode" to exitCode))
        }
    }

    private fun emit(event: Map<String, Any?>) {
        main.post { eventSink?.success(event) }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }

    private fun closeSession(id: String): Boolean {
        val session = sessions.remove(id) ?: return false
        session.terminate()
        return true
    }

    // Process.isAlive is newer than this app's minSdk; exitValue works on all supported APIs.
    private fun isProcessAlive(process: Process): Boolean = try {
        process.exitValue()
        false
    } catch (_: IllegalThreadStateException) {
        true
    } catch (_: Throwable) {
        false
    }

    /** Immediately requests termination; stream cleanup is completed off the UI thread. */
    fun closeAll() {
        val toClose = sessions.values.toList()
        for (session in toClose) {
            if (sessions.remove(session.id, session)) session.terminate()
        }
    }

    private inner class Session(
        val id: String,
        val process: Process,
        val writer: BufferedWriter,
        val reader: BufferedReader,
    ) {
        val writeLock = Any()
        @Volatile var closed = false
        @Volatile var readerThread: Thread? = null

        fun closeStreams() {
            synchronized(writeLock) {
                if (closed) return
                closed = true
                try { writer.close() } catch (_: Throwable) {}
            }
            try { reader.close() } catch (_: Throwable) {}
        }

        fun terminate() {
            synchronized(writeLock) {
                if (closed) return
                closed = true
                try { writer.close() } catch (_: Throwable) {}
            }
            try { process.destroy() } catch (_: Throwable) {}
            // Reflective fallback keeps this compatible with Android versions lacking the API.
            try {
                if (isProcessAlive(process)) {
                    Process::class.java.getMethod("destroyForcibly").invoke(process)
                }
            } catch (_: Throwable) {
                try { process.destroy() } catch (_: Throwable) {}
            }
            try { process.inputStream.close() } catch (_: Throwable) {}
            Thread({
                try {
                    process.waitFor()
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                } catch (_: Throwable) {
                } finally {
                    try { reader.close() } catch (_: Throwable) {}
                }
            }, "terminal-killer-$id").apply {
                isDaemon = true
                start()
            }
        }
    }
}
