import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart' show BuildContext, showDialog, AlertDialog, Text, TextButton, Navigator;
import 'package:permission_handler/permission_handler.dart';
import '../core/l10n.dart';

class WfdPeer {
  final String name, addr;
  final int status; // 0 connected 1 invited 2 failed 3 available 4 unavailable
  const WfdPeer(this.name, this.addr, this.status);
}

/// Bluetooth sharing + Wi-Fi Direct. Native side: NearbyNative.kt, channel abtin/nearby.
/// Wi-Fi Direct only builds the link; files then travel over the normal LAN transfer (HTTP).
class Nearby extends ChangeNotifier {
  static const _c = MethodChannel('abtin/nearby');
  List<WfdPeer> peers = [];
  bool scanning = false, connected = false, isOwner = false, p2pEnabled = true;
  String? ownerIp;

  Nearby() {
    _c.setMethodCallHandler((call) async {
      switch (call.method) {
        case 'peers':
          peers = [
            for (final m in (call.arguments as List)) WfdPeer('${(m as Map)['name']}', '${m['addr']}', (m['status'] as num).toInt()),
          ];
        case 'state':
          p2pEnabled = call.arguments == true;
        case 'conn':
          final m = call.arguments as Map;
          connected = m['connected'] == true;
          isOwner = m['owner'] == true;
          ownerIp = m['ownerIp'] as String?;
      }
      notifyListeners();
    });
  }

  // ── Bluetooth
  static Future<bool> btEnabled() async => await _c.invokeMethod<bool>('btEnabled') ?? false;
  static Future<void> btSend(List<String> paths) => _c.invokeMethod('btSend', {'paths': paths});
  static Future<void> btSettings() => _c.invokeMethod('btSettings');


  // ── Readiness (Wi-Fi + Location must be on for Wi-Fi Direct discovery)
  static Future<bool> _flag(String m) async {
    try {
      return await _c.invokeMethod<bool>(m) ?? false;
    } catch (_) {
      return true; // unknown -> do not block the user
    }
  }

  static Future<bool> _ask(BuildContext context, String msgKey, String openMethod) async {
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Text(L.t(msgKey)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(L.t('cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(L.t('settings'))),
        ],
      ),
    );
    if (go == true) {
      try {
        await _c.invokeMethod(openMethod);
      } catch (_) {}
    }
    return false;
  }

  /// Returns true when Wi-Fi and Location are on; otherwise asks the user to enable them.
  static Future<bool> ensureReady(BuildContext context) async {
    if (!await _flag('wifiOn')) {
      if (!context.mounted) return false;
      return _ask(context, 'wfdNeedWifi', 'openWifi');
    }
    if (!await _flag('locationOn')) {
      if (!context.mounted) return false;
      return _ask(context, 'wfdNeedLocation', 'openLocation');
    }
    return true;
  }

  // ── Wi-Fi Direct
  Future<void> start() async {
    await [Permission.locationWhenInUse, Permission.nearbyWifiDevices].request();
    scanning = true;
    notifyListeners();
    try {
      await _c.invokeMethod('wfdStart');
    } catch (_) {
      scanning = false;
      notifyListeners();
      rethrow;
    }
  }

  Future<void> stop() async {
    scanning = false;
    await _c.invokeMethod('wfdStop');
    notifyListeners();
  }

  Future<void> connect(String addr) => _c.invokeMethod('wfdConnect', {'addr': addr});

  Future<void> disconnect() async {
    await _c.invokeMethod('wfdDisconnect');
    connected = false;
    ownerIp = null;
    notifyListeners();
  }
}
