/// Excel number-format renderer (General, 0.00, #,##0, percent, currency, scientific, dates, times, text).
/// Used by the sheet grid for display and by the TEXT() function.
class XNumFmt {
  static const Map<int, String> builtIn = {
    0: 'General',
    1: '0',
    2: '0.00',
    3: '#,##0',
    4: '#,##0.00',
    9: '0%',
    10: '0.00%',
    11: '0.00E+00',
    14: 'm/d/yyyy',
    15: 'd-mmm-yy',
    16: 'd-mmm',
    17: 'mmm-yy',
    18: 'h:mm AM/PM',
    19: 'h:mm:ss AM/PM',
    20: 'h:mm',
    21: 'h:mm:ss',
    22: 'm/d/yyyy h:mm',
    37: '#,##0;(#,##0)',
    38: '#,##0;[Red](#,##0)',
    39: '#,##0.00;(#,##0.00)',
    40: '#,##0.00;[Red](#,##0.00)',
    45: 'mm:ss',
    46: '[h]:mm:ss',
    47: 'mmss.0',
    48: '##0.0E+0',
    49: '@',
  };

  static const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  static const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

  /// Excel serial number -> DateTime (1900 system, with the leap-year bug offset).
  static DateTime fromSerial(double s) {
    final whole = s.floor();
    final frac = s - whole;
    final base = DateTime.utc(1899, 12, 30);
    return base.add(Duration(days: whole, milliseconds: (frac * 86400000).round()));
  }

  static double toSerial(DateTime d) {
    final u = DateTime.utc(d.year, d.month, d.day, d.hour, d.minute, d.second);
    return u.difference(DateTime.utc(1899, 12, 30)).inSeconds / 86400.0;
  }

  static List<String> _sections(String code) {
    final out = <String>[];
    final b = StringBuffer();
    var q = false;
    for (var i = 0; i < code.length; i++) {
      final ch = code[i];
      if (ch == '"') q = !q;
      if (ch == ';' && !q) {
        out.add(b.toString());
        b.clear();
      } else {
        b.write(ch);
      }
    }
    out.add(b.toString());
    return out;
  }

  static String _strip(String sec) {
    // removes [Red] style tags, keeps currency from [$X-409]
    return sec.replaceAllMapped(RegExp(r'\[([^\]]*)\]'), (m) {
      final t = m[1]!;
      if (t.startsWith(r'$')) {
        final cur = t.substring(1).split('-').first;
        return cur;
      }
      return t.toLowerCase() == 'h' || t.toLowerCase() == 'm' || t.toLowerCase() == 'mm' || t.toLowerCase() == 's' || t.toLowerCase() == 'hh' ? '[$t]' : '';
    });
  }

  static bool isDateCode(String code) {
    if (code.isEmpty || code == 'General') return false;
    final s = _sections(code).first.replaceAll(RegExp(r'"[^"]*"'), '').replaceAll(RegExp(r'\[[^\]]*\]'), '').replaceAll(RegExp(r'\\.'), '');
    return RegExp(r'[ymdhs]', caseSensitive: false).hasMatch(s) && !RegExp(r'^[#0?,.%E+\-() $]*$').hasMatch(s);
  }

  static String general(dynamic v) {
    if (v == null) return '';
    if (v is bool) return v ? 'TRUE' : 'FALSE';
    if (v is int) return '$v';
    if (v is double) {
      if (v.isNaN) return '#NUM!';
      if (v.isInfinite) return '#NUM!';
      if (v == v.truncateToDouble() && v.abs() < 1e11) return v.toInt().toString();
      final a = v.abs();
      if (a != 0 && (a >= 1e11 || a < 1e-9)) {
        var s = v.toStringAsExponential(5);
        final m = RegExp(r'^(-?[\d.]+?)0*e([+-])(\d+)$').firstMatch(s);
        if (m != null) {
          var mant = m[1]!;
          if (mant.endsWith('.')) mant = mant.substring(0, mant.length - 1);
          s = '${mant}E${m[2]}${m[3]!.padLeft(2, '0')}';
        }
        return s;
      }
      final p = double.parse(v.toStringAsPrecision(10));
      var s = p.toString();
      if (s.contains('e')) s = p.toStringAsFixed(10).replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
      return s;
    }
    return '$v';
  }

  /// Formats [v] (num / String / bool) with an Excel format code. Empty code or "General" = general.
  static String format(dynamic v, String code) {
    if (v == null) return '';
    if (code.isEmpty || code == 'General') return general(v);
    final secs = _sections(code);
    if (v is String) {
      final num? n = double.tryParse(v);
      if (n == null) {
        final t = secs.length >= 4 ? secs[3] : (secs.first.contains('@') ? secs.first : '@');
        return _text(v, t);
      }
      v = n.toDouble();
    }
    if (v is bool) return general(v);
    final d = (v as num).toDouble();
    String sec;
    var neg = false;
    if (secs.length == 1) {
      sec = secs[0];
      neg = d < 0;
    } else if (secs.length == 2) {
      if (d < 0) {
        sec = secs[1];
      } else {
        sec = secs[0];
      }
    } else {
      sec = d > 0 ? secs[0] : (d < 0 ? secs[1] : secs[2]);
    }
    sec = _strip(sec);
    final abs = secs.length == 1 ? d.abs() : d.abs();
    if (isDateCode(sec)) return _date(d, sec);
    if (sec.trim() == '@') return general(v);
    return _number(abs, sec, neg && secs.length == 1);
  }

  static String _text(String s, String sec) {
    sec = _strip(sec);
    final out = StringBuffer();
    var i = 0;
    while (i < sec.length) {
      final c = sec[i];
      if (c == '@') {
        out.write(s);
      } else if (c == '"') {
        final j = sec.indexOf('"', i + 1);
        out.write(sec.substring(i + 1, j < 0 ? sec.length : j));
        i = j < 0 ? sec.length : j;
      } else if (c == r'\' && i + 1 < sec.length) {
        out.write(sec[++i]);
      } else if (c == '_' || c == '*') {
        i++;
        if (c == '_') out.write(' ');
      } else {
        out.write(c);
      }
      i++;
    }
    return out.toString();
  }

  static String _literal(String s) {
    final out = StringBuffer();
    for (var i = 0; i < s.length; i++) {
      final c = s[i];
      if (c == '"') {
        final j = s.indexOf('"', i + 1);
        out.write(s.substring(i + 1, j < 0 ? s.length : j));
        i = j < 0 ? s.length : j;
      } else if (c == r'\' && i + 1 < s.length) {
        out.write(s[++i]);
      } else if (c == '_') {
        i++;
        out.write(' ');
      } else if (c == '*') {
        i++;
      } else if (c != '%') {
        out.write(c);
      }
    }
    return out.toString();
  }

  static String _number(double v, String sec, bool negSign) {
    final pct = '%'.allMatches(sec.replaceAll(RegExp(r'"[^"]*"'), '')).length;
    var x = v;
    for (var i = 0; i < pct; i++) {
      x *= 100;
    }
    final pm = RegExp(r'[#0?,]*\.?[0#?]*(?:E[+-]0+)?').allMatches(sec).where((m) => RegExp(r'[0#?]').hasMatch(m[0]!)).firstOrNull;
    if (pm == null) {
      return (negSign ? '-' : '') + _literal(sec) + (pct > 0 ? '%' * pct : '');
    }
    final prefix = _literal(sec.substring(0, pm.start));
    var suffixRaw = sec.substring(pm.end);
    var suffix = _literal(suffixRaw);
    if (pct > 0) {
      // keep % where it was in the original string
      final before = sec.substring(0, pm.start).contains('%');
      if (before) {
        // percent before the number: rare; append to prefix side
      }
    }
    final pat = pm[0]!;
    final sci = RegExp(r'E([+-])(0+)$').firstMatch(pat);
    var body = sci == null ? pat : pat.substring(0, sci.start);
    final dot = body.indexOf('.');
    var ip = dot < 0 ? body : body.substring(0, dot);
    final dp = dot < 0 ? '' : body.substring(dot + 1);
    var trailingCommas = 0;
    while (ip.endsWith(',')) {
      trailingCommas++;
      ip = ip.substring(0, ip.length - 1);
    }
    final thousands = ip.contains(',');
    ip = ip.replaceAll(',', '');
    for (var i = 0; i < trailingCommas; i++) {
      x /= 1000;
    }
    final decCount = dp.length;
    String intStr, decStr = '';
    String expStr = '';
    if (sci != null) {
      var e = 0;
      if (x != 0) {
        while (x >= 10) {
          x /= 10;
          e++;
        }
        while (x < 1) {
          x *= 10;
          e--;
        }
      }
      final s = x.toStringAsFixed(decCount);
      final sp = s.split('.');
      intStr = sp[0];
      decStr = sp.length > 1 ? sp[1] : '';
      expStr = 'E${e < 0 ? '-' : (sci[1] == '+' ? '+' : '')}${e.abs().toString().padLeft(sci[2]!.length, '0')}';
    } else {
      final s = x.toStringAsFixed(decCount);
      final sp = s.split('.');
      intStr = sp[0];
      decStr = sp.length > 1 ? sp[1] : '';
    }
    // trim optional decimals (#)
    var keep = decStr.length;
    while (keep > 0 && dp.length >= keep && dp[keep - 1] != '0' && decStr[keep - 1] == '0') {
      keep--;
    }
    decStr = decStr.substring(0, keep);
    final minInt = '0'.allMatches(ip).length;
    if (intStr == '0' && minInt == 0 && (decStr.isNotEmpty || ip.isNotEmpty)) intStr = '';
    while (intStr.length < minInt) {
      intStr = '0$intStr';
    }
    if (thousands && intStr.isNotEmpty) {
      final b = StringBuffer();
      for (var i = 0; i < intStr.length; i++) {
        if (i > 0 && (intStr.length - i) % 3 == 0) b.write(',');
        b.write(intStr[i]);
      }
      intStr = b.toString();
    }
    final res = StringBuffer();
    if (negSign) res.write('-');
    // percent signs sit where they were typed: after the number by default
    final pctBefore = pct > 0 && sec.indexOf('%') < pm.start;
    res.write(prefix);
    if (pctBefore) res.write('%' * pct);
    res.write(intStr);
    if (decStr.isNotEmpty || (dp.isNotEmpty && keep == dp.length)) {
      if (decStr.isNotEmpty) {
        res.write('.');
        res.write(decStr);
      }
    }
    res.write(expStr);
    if (pct > 0 && !pctBefore) res.write('%' * pct);
    res.write(suffix);
    return res.toString();
  }

  static String _date(double serial, String sec) {
    final dt = fromSerial(serial);
    // tokenise
    final toks = <String>[];
    var i = 0;
    while (i < sec.length) {
      final c = sec[i];
      if (c == '"') {
        final j = sec.indexOf('"', i + 1);
        toks.add('"${sec.substring(i + 1, j < 0 ? sec.length : j)}');
        i = j < 0 ? sec.length : j + 1;
        continue;
      }
      if (c == r'\' && i + 1 < sec.length) {
        toks.add('"${sec[i + 1]}');
        i += 2;
        continue;
      }
      if (c == '[') {
        final j = sec.indexOf(']', i);
        toks.add(sec.substring(i, j < 0 ? sec.length : j + 1).toLowerCase());
        i = j < 0 ? sec.length : j + 1;
        continue;
      }
      final low = c.toLowerCase();
      if ('ymdhs'.contains(low)) {
        var j = i;
        while (j < sec.length && sec[j].toLowerCase() == low) {
          j++;
        }
        toks.add(sec.substring(i, j).toLowerCase());
        i = j;
        continue;
      }
      if (sec.substring(i).toUpperCase().startsWith('AM/PM')) {
        toks.add('AM/PM');
        i += 5;
        continue;
      }
      if (sec.substring(i).toUpperCase().startsWith('A/P')) {
        toks.add('A/P');
        i += 3;
        continue;
      }
      if (c == '_') {
        toks.add('" ');
        i += 2;
        continue;
      }
      if (c == '*') {
        i += 2;
        continue;
      }
      toks.add('"$c');
      i++;
    }
    final ampm = toks.contains('AM/PM') || toks.contains('A/P');
    final out = StringBuffer();
    String two(int n) => n.toString().padLeft(2, '0');
    for (var k = 0; k < toks.length; k++) {
      final t = toks[k];
      if (t.startsWith('"')) {
        out.write(t.substring(1));
      } else if (t == 'yyyy' || t == 'yyy') {
        out.write(dt.year.toString().padLeft(4, '0'));
      } else if (t == 'yy' || t == 'y') {
        out.write(two(dt.year % 100));
      } else if (t.startsWith('m')) {
        // minute when next to h or s
        var minute = false;
        for (var b = k - 1; b >= 0; b--) {
          if (toks[b].startsWith('"')) continue;
          minute = toks[b].startsWith('h') || toks[b] == '[h]';
          break;
        }
        if (!minute) {
          for (var a = k + 1; a < toks.length; a++) {
            if (toks[a].startsWith('"')) continue;
            minute = toks[a].startsWith('s');
            break;
          }
        }
        if (minute) {
          out.write(t.length >= 2 ? two(dt.minute) : '${dt.minute}');
        } else if (t == 'mmmmm') {
          out.write(months[dt.month - 1][0]);
        } else if (t == 'mmmm') {
          out.write(months[dt.month - 1]);
        } else if (t == 'mmm') {
          out.write(months[dt.month - 1].substring(0, 3));
        } else if (t == 'mm') {
          out.write(two(dt.month));
        } else {
          out.write('${dt.month}');
        }
      } else if (t.startsWith('d')) {
        if (t.length >= 4) {
          out.write(days[dt.weekday - 1]);
        } else if (t.length == 3) {
          out.write(days[dt.weekday - 1].substring(0, 3));
        } else if (t.length == 2) {
          out.write(two(dt.day));
        } else {
          out.write('${dt.day}');
        }
      } else if (t == '[h]' || t == '[hh]') {
        out.write('${(serial * 24).floor()}');
      } else if (t == '[m]' || t == '[mm]') {
        out.write('${(serial * 1440).floor()}');
      } else if (t == '[s]' || t == '[ss]') {
        out.write('${(serial * 86400).floor()}');
      } else if (t.startsWith('h')) {
        var h = dt.hour;
        if (ampm) {
          h = h % 12;
          if (h == 0) h = 12;
        }
        out.write(t.length >= 2 ? two(h) : '$h');
      } else if (t.startsWith('s')) {
        out.write(t.length >= 2 ? two(dt.second) : '${dt.second}');
      } else if (t == 'AM/PM') {
        out.write(dt.hour < 12 ? 'AM' : 'PM');
      } else if (t == 'A/P') {
        out.write(dt.hour < 12 ? 'A' : 'P');
      } else {
        out.write(t);
      }
    }
    return out.toString();
  }

  /// Format codes offered in the UI: (id, fa label, en label, code).
  static const List<(String, String, String, String)> presets = [
    ('general', 'عمومی', 'General', 'General'),
    ('number', 'عدد', 'Number', '0.00'),
    ('thousands', 'عدد با جداکننده هزارگان', 'Number with separator', '#,##0'),
    ('thousands2', 'عدد با جداکننده و اعشار', 'Number with separator and decimals', '#,##0.00'),
    ('currency', 'ارز', r'Currency', r'"$"#,##0.00'),
    ('accounting', 'حسابداری', 'Accounting', r'#,##0.00;(#,##0.00)'),
    ('percent', 'درصد', 'Percent', '0%'),
    ('percent2', 'درصد با اعشار', 'Percent 0.00', '0.00%'),
    ('sci', 'علمی', 'Scientific', '0.00E+00'),
    ('date', 'تاریخ کوتاه', 'Short date', 'yyyy-mm-dd'),
    ('datel', 'تاریخ بلند', 'Long date', 'dddd, mmmm d, yyyy'),
    ('time', 'زمان', 'Time', 'h:mm:ss'),
    ('time12', 'زمان ۱۲ ساعته', 'Time 12h', 'h:mm AM/PM'),
    ('datetime', 'تاریخ و زمان', 'Date and time', 'yyyy-mm-dd h:mm'),
    ('text', 'متن', 'Text', '@'),
  ];
}
