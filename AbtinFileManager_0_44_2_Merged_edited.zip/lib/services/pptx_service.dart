import 'dart:convert';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:path/path.dart' as p;
import 'package:xml/xml.dart';
import 'office_service.dart';

part 'pptx_extras.dart';

// ---------------------------------------------------------------- PPTX model
// Everything is in EMU (1 pt = 12700 EMU) unless a field says otherwise.

enum PKind { text, pic, table, chart, smart }

/// A path of a custom (freeform) geometry.
class PCust {
  final double w, h;
  final List<(String, List<double>)> cmds; // moveTo | lnTo | cubicBezTo | quadBezTo | close, flat x,y list
  PCust(this.w, this.h, this.cmds);
}

class PCell {
  final XmlElement el;
  final List<XmlElement> paras = [];
  int gridSpan = 1, rowSpan = 1;
  bool hMerge = false, vMerge = false;
  int? fill;
  PCell(this.el);
}

class PTable {
  final List<double> colW = [];
  final List<double> rowH = [];
  final List<List<PCell>> rows = [];
  bool firstRow = false, bandRow = false;
  int accent = 0x4472C4;
}

class PSeries {
  final String name;
  final List<double> vals;
  final List<double> xs;
  final int? color;
  final Map<int, int> pointColors;
  const PSeries(this.name, this.vals, this.xs, this.color, this.pointColors);
}

class PChartGroup {
  final String kind; // col | bar | line | area | pie | doughnut | scatter
  final bool stacked, percent;
  final List<PSeries> series;
  const PChartGroup(this.kind, this.stacked, this.percent, this.series);
}

class PChart {
  final List<PChartGroup> groups = [];
  final List<String> cats = [];
  String? title;
  bool legend = false;
  List<int> palette = const [0x4472C4, 0xED7D31, 0xA5A5A5, 0xFFC000, 0x5B9BD5, 0x70AD47];
}

/// One drawn node of a SmartArt diagram (position relative to the diagram frame).
class PSmartNode {
  double x = 0, y = 0, w = 0, h = 0, rot = 0;
  String geom = 'rect';
  int? fill, line;
  final List<XmlElement> paras = [];
  String plain = '';
}

class PShape {
  final XmlElement el;
  final PKind kind;
  double x, y, w, h; // absolute box on the slide, before rotation
  double rot = 0; // degrees, clockwise
  bool flipH = false, flipV = false;
  double sx = 1, sy = 1, ox = 0, oy = 0; // slide = child * s + o   (shapes inside groups)
  bool locked = false; // inside a rotated / flipped group: can not be moved or resized
  bool inherited = false; // comes from the layout / master: drawn, never edited
  final List<XmlElement> paras = [];
  Uint8List? image;
  String? phType;
  XmlElement? phLayout, phMaster;
  String geom = 'rect';
  double adj = 16667;
  final List<PCust> cust = [];
  int? fill, line, fontClr;
  double fillAlpha = 1, lineW = 0;
  List<int>? grad;
  double gradAngle = 90;
  String anchor = 't';
  double insL = 91440, insT = 45720, insR = 91440, insB = 45720;
  double fontScale = 1;
  PTable? table;
  PChart? chart;
  List<PSmartNode>? smart;
  PShape(this.el, this.kind, this.x, this.y, this.w, this.h);
  bool get isPic => kind == PKind.pic;
  bool get hasText => paras.isNotEmpty && (kind == PKind.text || kind == PKind.table);
  bool get movable => !inherited && !locked;
}

class PRun {
  final String text;
  final double sizePt;
  final bool bold, italic, underline, strike;
  final int? rgb;
  final int baseline; // percent, + = superscript
  final String? font; // typeface written in the file (null = inherited)
  const PRun(this.text, this.sizePt, this.bold, this.italic, this.underline, this.strike, this.rgb, this.baseline, {this.font});
}

class PPara {
  final List<PRun> runs;
  final String align; // l | r | ctr | just
  final bool rtl;
  final String? bullet;
  final int? bulletRgb;
  final double marL, indent; // EMU
  final double spcBef, spcAft; // pt
  final double lineSpacing; // 1.0 = single
  final double sizePt; // size of an empty paragraph / the first run
  const PPara(this.runs, this.align, this.rtl, this.bullet, this.bulletRgb, this.marL, this.indent, this.spcBef, this.spcAft, this.lineSpacing, this.sizePt);
}

/// First-run formatting for the format dialog.
class PParaInfo {
  final double sizePt;
  final bool bold, italic, rtl;
  final int? rgb;
  final String align;
  const PParaInfo(this.sizePt, this.bold, this.italic, this.rgb, this.align, this.rtl);
}

class PBackground {
  int? rgb;
  List<int>? grad;
  double gradAngle = 90;
  Uint8List? image;
}

class PSlide {
  final String part;
  final XmlDocument doc;
  final XmlElement sldId;
  final String rid;
  final List<PShape> shapes = [];
  final List<PShape> backShapes = []; // decorative shapes of the layout / master
  PBackground bg = PBackground();
  int? bgRgb; // kept for callers that only need a colour
  PSlide(this.part, this.doc, this.sldId, this.rid);
}

// ---------------------------------------------------------------- theme / colours
class _Ctx {
  String? layout, master;
  final Map<String, int> theme = {};
  final Map<String, String> map = {
    'bg1': 'lt1', 'tx1': 'dk1', 'bg2': 'lt2', 'tx2': 'dk2',
    'accent1': 'accent1', 'accent2': 'accent2', 'accent3': 'accent3', 'accent4': 'accent4', 'accent5': 'accent5', 'accent6': 'accent6',
    'hlink': 'hlink', 'folHlink': 'folHlink',
  };
}

const Map<String, int> _prst = {
  'black': 0x000000, 'white': 0xFFFFFF, 'red': 0xFF0000, 'green': 0x008000, 'blue': 0x0000FF, 'yellow': 0xFFFF00, 'gray': 0x808080, 'grey': 0x808080,
  'orange': 0xFFA500, 'purple': 0x800080, 'cyan': 0x00FFFF, 'magenta': 0xFF00FF, 'brown': 0xA52A2A, 'pink': 0xFFC0CB, 'darkBlue': 0x00008B,
  'darkGreen': 0x006400, 'darkRed': 0x8B0000, 'lightGray': 0xD3D3D3, 'dkGray': 0xA9A9A9, 'ltGray': 0xD3D3D3,
};

const _defaultTheme = <String, int>{
  'dk1': 0x000000, 'lt1': 0xFFFFFF, 'dk2': 0x44546A, 'lt2': 0xE7E6E6,
  'accent1': 0x4472C4, 'accent2': 0xED7D31, 'accent3': 0xA5A5A5, 'accent4': 0xFFC000, 'accent5': 0x5B9BD5, 'accent6': 0x70AD47,
  'hlink': 0x0563C1, 'folHlink': 0x954F72,
};

List<double> _toHsl(int rgb) {
  final r = ((rgb >> 16) & 255) / 255, g = ((rgb >> 8) & 255) / 255, b = (rgb & 255) / 255;
  final mx = math.max(r, math.max(g, b)), mn = math.min(r, math.min(g, b));
  final l = (mx + mn) / 2;
  var h = 0.0, s = 0.0;
  if (mx != mn) {
    final d = mx - mn;
    s = l > .5 ? d / (2 - mx - mn) : d / (mx + mn);
    if (mx == r) {
      h = (g - b) / d + (g < b ? 6 : 0);
    } else if (mx == g) {
      h = (b - r) / d + 2;
    } else {
      h = (r - g) / d + 4;
    }
    h /= 6;
  }
  return [h, s, l];
}

double _hue(double p0, double q, double t) {
  if (t < 0) t += 1;
  if (t > 1) t -= 1;
  if (t < 1 / 6) return p0 + (q - p0) * 6 * t;
  if (t < 1 / 2) return q;
  if (t < 2 / 3) return p0 + (q - p0) * (2 / 3 - t) * 6;
  return p0;
}

int _fromHsl(double h, double s, double l) {
  s = s.clamp(0.0, 1.0).toDouble();
  l = l.clamp(0.0, 1.0).toDouble();
  double r, g, b;
  if (s == 0) {
    r = g = b = l;
  } else {
    final q = l < .5 ? l * (1 + s) : l + s - l * s;
    final p0 = 2 * l - q;
    r = _hue(p0, q, h + 1 / 3);
    g = _hue(p0, q, h);
    b = _hue(p0, q, h - 1 / 3);
  }
  return ((r * 255).round() << 16) | ((g * 255).round() << 8) | (b * 255).round();
}

int _mix(int c, int to, double t) {
  int ch(int sh) => ((((c >> sh) & 255) * (1 - t)) + (((to >> sh) & 255) * t)).round().clamp(0, 255).toInt();
  return (ch(16) << 16) | (ch(8) << 8) | ch(0);
}

// ---------------------------------------------------------------- PptxFile
class PptxFile {
  final OfficeZip z;
  final slides = <PSlide>[];
  double slideW = 9144000, slideH = 6858000;
  final _imgCache = <String, Uint8List?>{};
  final _ctxCache = <String, _Ctx>{};
  PptxFile._(this.z);

  static Future<PptxFile> open(String path) async {
    final x = PptxFile._(await OfficeZip.open(path));
    x._load();
    return x;
  }

  XmlDocument get _pres => z.xml('ppt/presentation.xml')!;

  // ---- xml helpers
  static XmlElement? _first(XmlElement? e, String name) {
    if (e == null) return null;
    for (final c in e.findElements(name, namespace: '*')) {
      return c;
    }
    return null;
  }

  static List<XmlElement> _kids(XmlElement? e, String name) => e == null ? <XmlElement>[] : e.findElements(name, namespace: '*').toList();

  static XmlElement? _deep(XmlElement? e, String name) {
    if (e == null) return null;
    for (final c in e.findAllElements(name, namespace: '*')) {
      return c;
    }
    return null;
  }

  static String? _rAttr(XmlElement e, String local) {
    for (final a in e.attributes) {
      if (a.name.local == local && (a.name.prefix == 'r' || a.name.prefix == null)) return a.value;
    }
    return null;
  }

  static double? _num(String? s) => s == null ? null : double.tryParse(s);

  static bool _isTitle(String? t) => t == 'title' || t == 'ctrTitle';

  // ---- loading
  void _load() {
    slides.clear();
    _ctxCache.clear();
    final pres = z.xml('ppt/presentation.xml');
    if (pres == null) throw 'Not a valid pptx';
    final rels = z.rels('ppt/presentation.xml');
    for (final e in pres.findAllElements('sldSz', namespace: '*')) {
      final cx = _num(e.getAttribute('cx')), cy = _num(e.getAttribute('cy'));
      if (cx != null && cy != null && cx > 0 && cy > 0) {
        slideW = cx;
        slideH = cy;
      }
    }
    for (final s in pres.findAllElements('sldId', namespace: '*')) {
      String? rid;
      for (final a in s.attributes) {
        if (a.name.local == 'id' && a.name.prefix == 'r') rid = a.value;
      }
      final part = rels[rid];
      final doc = part == null ? null : z.xml(part);
      if (doc == null) continue;
      final sl = PSlide(part!, doc, s, rid!);
      try {
        _loadSlide(sl);
      } catch (_) {
        // a damaged shape must not make the whole file unreadable
      }
      slides.add(sl);
    }
  }

  (List<int>, Set<String>) snapshot() => z.snapshot();

  void restore((List<int>, Set<String>) snap) {
    z.restore(snap);
    _imgCache.clear();
    _load();
  }

  Uint8List? _img(String path) => _imgCache.putIfAbsent(path, () => z.bytes(path));

  _Ctx _ctxFor(String part) {
    final sr = z.rels(part);
    String? layout, master;
    for (final t in sr.values) {
      if (t.contains('/slideLayouts/')) layout = t;
    }
    if (layout != null) {
      for (final t in z.rels(layout).values) {
        if (t.contains('/slideMasters/')) master = t;
      }
    }
    final key = '${layout ?? ''}|${master ?? ''}|$part';
    final cached = _ctxCache[key];
    if (cached != null) return cached;
    final c = _Ctx()..layout = layout..master = master;
    c.theme.addAll(_defaultTheme);
    if (master != null) {
      String? themePart;
      for (final t in z.rels(master).values) {
        if (t.contains('/theme/')) themePart = t;
      }
      final th = themePart == null ? null : z.xml(themePart);
      final cs = th == null ? null : _deep(th.rootElement, 'clrScheme');
      if (cs != null) {
        for (final e in cs.children.whereType<XmlElement>()) {
          final v = _first(e, 'srgbClr')?.getAttribute('val') ?? _first(e, 'sysClr')?.getAttribute('lastClr');
          final n = v == null ? null : int.tryParse(v, radix: 16);
          if (n != null) c.theme[e.name.local] = n;
        }
      }
      final cm = z.xml(master);
      final m = cm == null ? null : _deep(cm.rootElement, 'clrMap');
      if (m != null) {
        for (final a in m.attributes) {
          c.map[a.name.local] = a.value;
        }
      }
    }
    for (final part2 in [layout, part]) {
      if (part2 == null) continue;
      final d = z.xml(part2);
      final o = d == null ? null : _deep(d.rootElement, 'overrideClrMapping');
      if (o != null) {
        for (final a in o.attributes) {
          c.map[a.name.local] = a.value;
        }
      }
    }
    return _ctxCache[key] = c;
  }

  // ---- colours
  int? _clr(XmlElement? holder, _Ctx c) {
    if (holder == null) return null;
    XmlElement? e;
    for (final k in holder.children.whereType<XmlElement>()) {
      const names = {'srgbClr', 'schemeClr', 'sysClr', 'prstClr', 'scrgbClr', 'hslClr'};
      if (names.contains(k.name.local)) {
        e = k;
        break;
      }
    }
    if (e == null) return null;
    int? base;
    switch (e.name.local) {
      case 'srgbClr':
        base = int.tryParse(e.getAttribute('val') ?? '', radix: 16);
        break;
      case 'schemeClr':
        final v = e.getAttribute('val') ?? '';
        if (v == 'phClr') return null;
        final mapped = c.map[v] ?? v;
        base = c.theme[mapped] ?? c.theme[v];
        break;
      case 'sysClr':
        base = int.tryParse(e.getAttribute('lastClr') ?? '', radix: 16);
        if (base == null) base = (e.getAttribute('val') ?? '') == 'window' ? 0xFFFFFF : 0x000000;
        break;
      case 'prstClr':
        base = _prst[e.getAttribute('val') ?? ''] ?? 0x000000;
        break;
      case 'scrgbClr':
        int ch(String n) => (((_num(e!.getAttribute(n)) ?? 0) / 100000) * 255).round().clamp(0, 255).toInt();
        base = (ch('r') << 16) | (ch('g') << 8) | ch('b');
        break;
    }
    if (base == null) return null;
    var rgb = base;
    for (final m in e.children.whereType<XmlElement>()) {
      final v = (_num(m.getAttribute('val')) ?? 100000) / 100000;
      switch (m.name.local) {
        case 'lumMod':
          final h = _toHsl(rgb);
          rgb = _fromHsl(h[0], h[1], h[2] * v);
          break;
        case 'lumOff':
          final h = _toHsl(rgb);
          rgb = _fromHsl(h[0], h[1], h[2] + v);
          break;
        case 'satMod':
          final h = _toHsl(rgb);
          rgb = _fromHsl(h[0], h[1] * v, h[2]);
          break;
        case 'tint':
          rgb = _mix(rgb, 0xFFFFFF, 1 - v);
          break;
        case 'shade':
          rgb = _mix(rgb, 0x000000, 1 - v);
          break;
      }
    }
    return rgb & 0xFFFFFF;
  }

  double _alphaOf(XmlElement? holder) {
    if (holder == null) return 1;
    for (final k in holder.children.whereType<XmlElement>()) {
      for (final a in k.children.whereType<XmlElement>()) {
        if (a.name.local == 'alpha') return ((_num(a.getAttribute('val')) ?? 100000) / 100000).clamp(0.0, 1.0).toDouble();
      }
    }
    return 1;
  }

  /// Colour of a fill element (solidFill / gradFill first stop); null = noFill or unknown.
  int? _solid(XmlElement? parent, _Ctx c) => _clr(_first(parent, 'solidFill'), c);

  List<int>? _gradOf(XmlElement? parent, _Ctx c) {
    final g = _first(parent, 'gradFill');
    if (g == null) return null;
    final out = <int>[];
    for (final gs in _kids(_first(g, 'gsLst'), 'gs')) {
      final v = _clr(gs, c);
      if (v != null) out.add(v);
    }
    return out.length >= 2 ? out : null;
  }

  double _gradAngle(XmlElement? parent) {
    final g = _first(parent, 'gradFill');
    final lin = _first(g, 'lin');
    return (_num(lin?.getAttribute('ang')) ?? 5400000) / 60000;
  }

  // ---- backgrounds
  PBackground _bgOf(String part, _Ctx c) {
    final bg = PBackground();
    final d = z.xml(part);
    final b = d == null ? null : _deep(d.rootElement, 'bg');
    if (b == null) return bg;
    final pr = _first(b, 'bgPr');
    if (pr != null) {
      bg.rgb = _solid(pr, c);
      bg.grad = _gradOf(pr, c);
      bg.gradAngle = _gradAngle(pr);
      final bf = _first(pr, 'blipFill');
      final blip = _first(bf, 'blip');
      final id = blip == null ? null : _rAttr(blip, 'embed');
      final t = id == null ? null : z.rels(part)[id];
      if (t != null) bg.image = _img(t);
    }
    final ref = _first(b, 'bgRef');
    if (ref != null && bg.rgb == null && bg.grad == null && bg.image == null) bg.rgb = _clr(ref, c);
    return bg;
  }

  // ---- slide
  void _loadSlide(PSlide sl) {
    final c = _ctxFor(sl.part);
    var bg = _bgOf(sl.part, c);
    if (bg.rgb == null && bg.grad == null && bg.image == null && c.layout != null) bg = _bgOf(c.layout!, c);
    if (bg.rgb == null && bg.grad == null && bg.image == null && c.master != null) bg = _bgOf(c.master!, c);
    sl.bg = bg;
    sl.bgRgb = bg.rgb;
    final root = sl.doc.rootElement;
    final hideMaster = root.getAttribute('showMasterSp') == '0';
    final layDoc = c.layout == null ? null : z.xml(c.layout!);
    final hideMaster2 = layDoc?.rootElement.getAttribute('showMasterSp') == '0';
    if (c.master != null && !hideMaster && !hideMaster2) _loadTree(z.xml(c.master!), c.master!, c, sl.backShapes, inherited: true);
    if (c.layout != null && !hideMaster) _loadTree(layDoc, c.layout!, c, sl.backShapes, inherited: true);
    _loadTree(sl.doc, sl.part, c, sl.shapes, inherited: false);
  }

  void _loadTree(XmlDocument? doc, String part, _Ctx c, List<PShape> out, {required bool inherited}) {
    if (doc == null) return;
    final trees = doc.findAllElements('spTree', namespace: '*').toList();
    if (trees.isEmpty) return;
    final rels = z.rels(part);
    _walk(trees.first, <_Grp>[], part, rels, c, out, inherited);
  }

  void _walk(XmlElement parent, List<_Grp> groups, String part, Map<String, String> rels, _Ctx c, List<PShape> out, bool inherited) {
    for (final n in parent.children.whereType<XmlElement>()) {
      final l = n.name.local;
      try {
        if (l == 'grpSp') {
          final g = _grpOf(n);
          _walk(n, [...groups, g], part, rels, c, out, inherited);
        } else if (l == 'AlternateContent') {
          final ch = _first(n, 'Choice') ?? _first(n, 'Fallback');
          if (ch != null) _walk(ch, groups, part, rels, c, out, inherited);
        } else if (l == 'sp' || l == 'pic' || l == 'cxnSp' || l == 'graphicFrame') {
          final sh = _shapeOf(n, groups, part, rels, c, inherited);
          if (sh != null) out.add(sh);
        }
      } catch (_) {
        // skip the shape that could not be read
      }
    }
  }

  _Grp _grpOf(XmlElement g) {
    final xf = _first(_first(g, 'grpSpPr'), 'xfrm');
    final grp = _Grp();
    if (xf == null) return grp;
    final off = _first(xf, 'off'), ext = _first(xf, 'ext'), co = _first(xf, 'chOff'), ce = _first(xf, 'chExt');
    grp.ox = _num(off?.getAttribute('x')) ?? 0;
    grp.oy = _num(off?.getAttribute('y')) ?? 0;
    grp.w = _num(ext?.getAttribute('cx')) ?? 0;
    grp.h = _num(ext?.getAttribute('cy')) ?? 0;
    grp.cox = _num(co?.getAttribute('x')) ?? grp.ox;
    grp.coy = _num(co?.getAttribute('y')) ?? grp.oy;
    grp.cw = _num(ce?.getAttribute('cx')) ?? grp.w;
    grp.ch = _num(ce?.getAttribute('cy')) ?? grp.h;
    grp.rot = (_num(xf.getAttribute('rot')) ?? 0) / 60000;
    grp.flipH = xf.getAttribute('flipH') == '1';
    grp.flipV = xf.getAttribute('flipV') == '1';
    return grp;
  }

  /// The xfrm element of a shape (a:xfrm in spPr / pic, p:xfrm in a graphicFrame).
  XmlElement? _xfrmEl(XmlElement n) {
    if (n.name.local == 'graphicFrame') return _first(n, 'xfrm');
    return _first(_first(n, 'spPr'), 'xfrm');
  }

  ({double x, double y, double w, double h, double rot, bool fh, bool fv})? _box(XmlElement? xf) {
    if (xf == null) return null;
    final off = _first(xf, 'off'), ext = _first(xf, 'ext');
    if (off == null || ext == null) return null;
    final x = _num(off.getAttribute('x')), y = _num(off.getAttribute('y')), w = _num(ext.getAttribute('cx')), h = _num(ext.getAttribute('cy'));
    if (x == null || y == null || w == null || h == null) return null;
    return (x: x, y: y, w: w, h: h, rot: (_num(xf.getAttribute('rot')) ?? 0) / 60000, fh: xf.getAttribute('flipH') == '1', fv: xf.getAttribute('flipV') == '1');
  }

  /// The placeholder [type]/[idx] of a layout or master part (the whole p:sp).
  XmlElement? _findPh(String? part, String? type, String? idx) {
    if (part == null || part.isEmpty) return null;
    final d = z.xml(part);
    if (d == null) return null;
    XmlElement? byType;
    for (final sp in d.findAllElements('sp', namespace: '*')) {
      final ph = _deep(_first(_first(sp, 'nvSpPr'), 'nvPr'), 'ph');
      if (ph == null) continue;
      final i = ph.getAttribute('idx'), t = ph.getAttribute('type');
      if (idx != null && i == idx) return sp;
      final same = t == type || (_isTitle(t) && _isTitle(type)) || (t == null && type == 'body') || (t == 'body' && type == null);
      if (same && byType == null) byType = sp;
    }
    return byType;
  }

  PShape? _shapeOf(XmlElement n, List<_Grp> groups, String part, Map<String, String> rels, _Ctx c, bool inherited) {
    final l = n.name.local;
    String? type, idx;
    final ph = _deep(_first(_first(n, l == 'pic' ? 'nvPicPr' : (l == 'cxnSp' ? 'nvCxnSpPr' : (l == 'graphicFrame' ? 'nvGraphicFramePr' : 'nvSpPr'))), 'nvPr'), 'ph');
    final hasPh = ph != null;
    if (ph != null) {
      type = ph.getAttribute('type');
      idx = ph.getAttribute('idx');
    }
    if (inherited && hasPh) return null; // placeholders of layout / master are templates, not content
    XmlElement? phL, phM;
    if (hasPh && !inherited) {
      phL = _findPh(c.layout, type, idx);
      phM = _findPh(c.master, type, idx);
    }
    var box = _box(_xfrmEl(n));
    if (box == null && hasPh) {
      box = _box(_first(_first(phL, 'spPr'), 'xfrm')) ?? _box(_first(_first(phM, 'spPr'), 'xfrm'));
    }
    box ??= _isTitle(type)
        ? (x: slideW * .05, y: slideH * .05, w: slideW * .9, h: slideH * .2, rot: 0.0, fh: false, fv: false)
        : (x: slideW * .05, y: slideH * .28, w: slideW * .9, h: slideH * .6, rot: 0.0, fh: false, fv: false);

    // ---- group transforms (inner -> outer)
    var cx = box.x + box.w / 2, cy = box.y + box.h / 2, w = box.w, h = box.h, rot = box.rot;
    var s1x = 1.0, s1y = 1.0, o1x = 0.0, o1y = 0.0;
    var locked = false;
    for (var gi = groups.length - 1; gi >= 0; gi--) {
      final g = groups[gi];
      final sgx = g.cw == 0 ? 1.0 : g.w / g.cw, sgy = g.ch == 0 ? 1.0 : g.h / g.ch;
      var nx = g.ox + (cx - g.cox) * sgx, ny = g.oy + (cy - g.coy) * sgy;
      w *= sgx;
      h *= sgy;
      if (g.flipH) nx = g.ox + g.w - (nx - g.ox);
      if (g.flipV) ny = g.oy + g.h - (ny - g.oy);
      if (g.rot != 0) {
        final gcx = g.ox + g.w / 2, gcy = g.oy + g.h / 2, a = g.rot * math.pi / 180;
        final dx = nx - gcx, dy = ny - gcy;
        nx = gcx + dx * math.cos(a) - dy * math.sin(a);
        ny = gcy + dx * math.sin(a) + dy * math.cos(a);
        rot += g.rot;
      }
      if (g.rot != 0 || g.flipH || g.flipV) locked = true;
      o1x = g.ox + (o1x - g.cox) * sgx;
      o1y = g.oy + (o1y - g.coy) * sgy;
      s1x *= sgx;
      s1y *= sgy;
      cx = nx;
      cy = ny;
    }

    final kind = l == 'pic'
        ? PKind.pic
        : (l == 'graphicFrame' ? _frameKind(n) : PKind.text);
    if (kind == PKind.text && l == 'graphicFrame') return null;
    final sh = PShape(n, kind, cx - w / 2, cy - h / 2, w, h);
    sh.rot = rot;
    sh.flipH = box.fh;
    sh.flipV = box.fv;
    sh.sx = s1x;
    sh.sy = s1y;
    sh.ox = o1x;
    sh.oy = o1y;
    sh.locked = locked;
    sh.inherited = inherited;
    sh.phType = type;
    sh.phLayout = phL;
    sh.phMaster = phM;

    if (kind == PKind.pic) {
      final blip = _deep(n, 'blip');
      final id = blip == null ? null : _rAttr(blip, 'embed');
      final t = id == null ? null : rels[id];
      if (t != null) sh.image = _img(t);
      return sh;
    }
    if (kind == PKind.chart) {
      final id = _rAttr(_deep(n, 'chart')!, 'id');
      final t = id == null ? null : rels[id];
      if (t != null) sh.chart = _parseChart(t, c);
      return sh;
    }
    if (kind == PKind.smart) {
      sh.smart = _parseSmart(n, rels, c);
      return sh;
    }
    if (kind == PKind.table) {
      sh.table = _parseTable(n, c, sh);
      return sh;
    }

    // ---- ordinary shape / text box / placeholder
    _readGeometry(n, sh);
    _readLook(n, sh, c, phL, phM);
    if (l != 'cxnSp') {
      for (final para in _kids(_first(n, 'txBody'), 'p')) {
        sh.paras.add(para);
      }
    }
    final bodies = <XmlElement?>[_first(_first(n, 'txBody'), 'bodyPr'), _first(_first(phL, 'txBody'), 'bodyPr'), _first(_first(phM, 'txBody'), 'bodyPr')];
    String? attr(String a) {
      for (final b in bodies) {
        final v = b?.getAttribute(a);
        if (v != null) return v;
      }
      return null;
    }

    sh.anchor = attr('anchor') ?? 't';
    sh.insL = _num(attr('lIns')) ?? 91440;
    sh.insR = _num(attr('rIns')) ?? 91440;
    sh.insT = _num(attr('tIns')) ?? 45720;
    sh.insB = _num(attr('bIns')) ?? 45720;
    for (final b in bodies) {
      final na = _first(b, 'normAutofit');
      if (na != null) {
        sh.fontScale = (_num(na.getAttribute('fontScale')) ?? 100000) / 100000;
        break;
      }
    }
    // a shape with neither text, fill, line nor a placeholder role is invisible -> skip it
    final visible = sh.paras.any((e) => text(e).trim().isNotEmpty) || sh.fill != null || sh.grad != null || (sh.line != null && sh.lineW > 0) || hasPh || (!inherited && sh.paras.isNotEmpty);
    if (!visible) return null;
    return sh;
  }

  PKind _frameKind(XmlElement n) {
    final gd = _deep(n, 'graphicData');
    if (gd == null) return PKind.text;
    final uri = gd.getAttribute('uri') ?? '';
    if (_deep(gd, 'tbl') != null) return PKind.table;
    if (uri.contains('chart') || _deep(gd, 'chart') != null) return PKind.chart;
    if (uri.contains('diagram') || _deep(gd, 'relIds') != null) return PKind.smart;
    return PKind.text;
  }

  void _readGeometry(XmlElement n, PShape sh) {
    final spPr = _first(n, 'spPr');
    final pg = _first(spPr, 'prstGeom');
    if (pg != null) {
      sh.geom = pg.getAttribute('prst') ?? 'rect';
      for (final gd in _deep(pg, 'avLst')?.children.whereType<XmlElement>() ?? <XmlElement>[]) {
        final f = gd.getAttribute('fmla') ?? '';
        final m = RegExp(r'val\s+(-?\d+)').firstMatch(f);
        if (m != null) {
          sh.adj = double.parse(m[1]!);
          break;
        }
      }
    }
    if (n.name.local == 'cxnSp' && pg == null) sh.geom = 'line';
    final cg = _first(spPr, 'custGeom');
    if (cg != null) {
      sh.geom = 'cust';
      for (final path in _kids(_first(cg, 'pathLst'), 'path')) {
        final pw = _num(path.getAttribute('w')) ?? sh.w, ph = _num(path.getAttribute('h')) ?? sh.h;
        final cmds = <(String, List<double>)>[];
        for (final k in path.children.whereType<XmlElement>()) {
          final pts = <double>[];
          for (final pt in _kids(k, 'pt')) {
            pts.add(_num(pt.getAttribute('x')) ?? 0);
            pts.add(_num(pt.getAttribute('y')) ?? 0);
          }
          final nm = k.name.local;
          if (nm == 'moveTo' || nm == 'lnTo' || nm == 'cubicBezTo' || nm == 'quadBezTo' || nm == 'close') cmds.add((nm, pts));
        }
        if (cmds.isNotEmpty) sh.cust.add(PCust(pw <= 0 ? 1 : pw, ph <= 0 ? 1 : ph, cmds));
      }
      if (sh.cust.isEmpty) sh.geom = 'rect';
    }
  }

  void _readLook(XmlElement n, PShape sh, _Ctx c, XmlElement? phL, XmlElement? phM) {
    final spPr = _first(n, 'spPr');
    final style = _first(n, 'style');
    bool? noFill;
    for (final pr in [spPr, _first(phL, 'spPr'), _first(phM, 'spPr')]) {
      if (pr == null) continue;
      if (_first(pr, 'noFill') != null) {
        noFill = true;
        break;
      }
      final s = _first(pr, 'solidFill');
      if (s != null) {
        sh.fill = _clr(s, c);
        sh.fillAlpha = _alphaOf(s);
        break;
      }
      final g = _gradOf(pr, c);
      if (g != null) {
        sh.grad = g;
        sh.gradAngle = _gradAngle(pr);
        break;
      }
    }
    if (sh.fill == null && sh.grad == null && noFill != true) {
      final fr = _first(style, 'fillRef');
      if (fr != null && (fr.getAttribute('idx') ?? '0') != '0') sh.fill = _clr(fr, c);
    }
    // line
    final ln = _first(spPr, 'ln');
    final lr = _first(style, 'lnRef');
    final lrOn = lr != null && (lr.getAttribute('idx') ?? '0') != '0';
    if (ln != null) {
      if (_first(ln, 'noFill') != null) {
        sh.lineW = 0;
      } else {
        sh.lineW = _num(ln.getAttribute('w')) ?? 12700;
        sh.line = _solid(ln, c) ?? (lrOn ? _clr(lr, c) : null);
      }
    } else if (lrOn) {
      sh.line = _clr(lr, c);
      sh.lineW = 12700;
    }
    final fr = _first(style, 'fontRef');
    if (fr != null) sh.fontClr = _clr(fr, c);
  }

  // ---- tables
  PTable _parseTable(XmlElement frame, _Ctx c, PShape sh) {
    final t = PTable();
    final tbl = _deep(frame, 'tbl')!;
    final pr = _first(tbl, 'tblPr');
    t.firstRow = pr?.getAttribute('firstRow') == '1';
    t.bandRow = pr?.getAttribute('bandRow') == '1';
    t.accent = c.theme['accent1'] ?? 0x4472C4;
    for (final g in _kids(_first(tbl, 'tblGrid'), 'gridCol')) {
      t.colW.add(_num(g.getAttribute('w')) ?? 914400);
    }
    for (final tr in _kids(tbl, 'tr')) {
      t.rowH.add(_num(tr.getAttribute('h')) ?? 370840);
      final row = <PCell>[];
      for (final tc in _kids(tr, 'tc')) {
        final cell = PCell(tc);
        cell.gridSpan = int.tryParse(tc.getAttribute('gridSpan') ?? '1') ?? 1;
        cell.rowSpan = int.tryParse(tc.getAttribute('rowSpan') ?? '1') ?? 1;
        cell.hMerge = tc.getAttribute('hMerge') == '1';
        cell.vMerge = tc.getAttribute('vMerge') == '1';
        final tcPr = _first(tc, 'tcPr');
        cell.fill = _solid(tcPr, c);
        for (final para in _kids(_first(tc, 'txBody'), 'p')) {
          cell.paras.add(para);
          sh.paras.add(para);
        }
        row.add(cell);
      }
      t.rows.add(row);
    }
    if (t.colW.isEmpty && t.rows.isNotEmpty) {
      for (var i = 0; i < t.rows.first.length; i++) {
        t.colW.add(sh.w / t.rows.first.length);
      }
    }
    return t;
  }

  // ---- charts
  List<String> _cache(XmlElement? e) {
    // e = c:cat / c:val / c:xVal / c:yVal
    final cacheEl = _deep(e, 'strCache') ?? _deep(e, 'numCache');
    if (cacheEl == null) return [];
    final count = int.tryParse(_first(cacheEl, 'ptCount')?.getAttribute('val') ?? '') ?? 0;
    final out = List<String>.filled(count, '');
    for (final pt in _kids(cacheEl, 'pt')) {
      final i = int.tryParse(pt.getAttribute('idx') ?? '') ?? -1;
      final v = _first(pt, 'v')?.innerText ?? '';
      if (i >= 0 && i < out.length) {
        out[i] = v;
      } else if (i >= out.length) {
        out.addAll(List<String>.filled(i - out.length, ''));
        out.add(v);
      }
    }
    return out;
  }

  PChart? _parseChart(String part, _Ctx c) {
    final d = z.xml(part);
    if (d == null) return null;
    final chart = _first(d.rootElement, 'chart');
    final plot = _first(chart, 'plotArea');
    if (plot == null) return null;
    final out = PChart();
    out.palette = [for (var i = 1; i <= 6; i++) c.theme['accent$i'] ?? 0x4472C4];
    if (_first(chart, 'autoTitleDeleted')?.getAttribute('val') != '1') {
      final tt = _first(chart, 'title');
      if (tt != null) {
        final s = tt.findAllElements('t', namespace: '*').map((e) => e.innerText).join();
        if (s.trim().isNotEmpty) out.title = s;
      }
    }
    out.legend = _first(chart, 'legend') != null;
    for (final g in plot.children.whereType<XmlElement>()) {
      final nm = g.name.local;
      if (!nm.endsWith('Chart')) continue;
      var kind = 'col';
      if (nm.startsWith('bar')) {
        kind = (_first(g, 'barDir')?.getAttribute('val') ?? 'col') == 'bar' ? 'bar' : 'col';
      } else if (nm.startsWith('line') || nm.startsWith('radar') || nm.startsWith('stock')) {
        kind = 'line';
      } else if (nm.startsWith('area')) {
        kind = 'area';
      } else if (nm.startsWith('doughnut')) {
        kind = 'doughnut';
      } else if (nm.startsWith('pie') || nm.startsWith('ofPie')) {
        kind = 'pie';
      } else if (nm.startsWith('scatter') || nm.startsWith('bubble')) {
        kind = 'scatter';
      }
      final grouping = _first(g, 'grouping')?.getAttribute('val') ?? 'clustered';
      final series = <PSeries>[];
      for (final ser in _kids(g, 'ser')) {
        final name = _first(_first(ser, 'tx'), 'strRef') != null ? _cache(_first(ser, 'tx')).join() : (_deep(_first(ser, 'tx'), 'v')?.innerText ?? '');
        final isXy = kind == 'scatter';
        final vals = [for (final s in _cache(_first(ser, isXy ? 'yVal' : 'val'))) double.tryParse(s) ?? 0.0];
        final xs = isXy ? [for (final s in _cache(_first(ser, 'xVal'))) double.tryParse(s) ?? 0.0] : <double>[];
        if (!isXy && out.cats.isEmpty) out.cats.addAll(_cache(_first(ser, 'cat')));
        final sp = _first(ser, 'spPr');
        final col = _solid(sp, c) ?? _solid(_first(sp, 'ln'), c);
        final pc = <int, int>{};
        for (final dp in _kids(ser, 'dPt')) {
          final i = int.tryParse(_first(dp, 'idx')?.getAttribute('val') ?? '');
          final v = _solid(_first(dp, 'spPr'), c);
          if (i != null && v != null) pc[i] = v;
        }
        series.add(PSeries(name, vals, xs, col, pc));
      }
      if (series.isNotEmpty) out.groups.add(PChartGroup(kind, grouping.contains('tacked'), grouping == 'percentStacked', series));
    }
    return out.groups.isEmpty ? null : out;
  }

  // ---- SmartArt
  List<PSmartNode> _parseSmart(XmlElement frame, Map<String, String> slideRels, _Ctx c) {
    final nodes = <PSmartNode>[];
    final rel = _deep(frame, 'relIds');
    final dm = rel == null ? null : _rAttr(rel, 'dm');
    final dmPart = slideRels[dm ?? ''];
    final dmDoc = dmPart == null ? null : z.xml(dmPart);
    // 1) the pre-drawn diagram (dsp:drawing)
    String? drawing;
    final ext = dmDoc == null ? null : _deep(dmDoc.rootElement, 'dataModelExt');
    final rid = ext?.getAttribute('relId');
    if (rid != null) drawing = slideRels[rid];
    if (drawing == null) {
      for (final t in slideRels.values) {
        if (t.contains('/diagrams/drawing')) drawing = t;
      }
    }
    final dd = drawing == null ? null : z.xml(drawing);
    if (dd != null) {
      for (final sp in dd.findAllElements('sp', namespace: '*')) {
        final spPr = _first(sp, 'spPr');
        final b = _box(_first(spPr, 'xfrm'));
        if (b == null) continue;
        final n = PSmartNode()..x = b.x..y = b.y..w = b.w..h = b.h..rot = b.rot;
        n.geom = _first(spPr, 'prstGeom')?.getAttribute('prst') ?? 'rect';
        final f = _solid(spPr, c);
        n.fill = f;
        final ln = _first(spPr, 'ln');
        n.line = ln == null || _first(ln, 'noFill') != null ? null : _solid(ln, c);
        if (f == null && _first(spPr, 'noFill') == null) {
          final st = _first(sp, 'style');
          final fr = _first(st, 'fillRef');
          if (fr != null) n.fill = _clr(fr, c);
        }
        for (final para in _kids(_first(sp, 'txBody'), 'p')) {
          n.paras.add(para);
        }
        nodes.add(n);
      }
      if (nodes.isNotEmpty) return nodes;
    }
    // 2) fallback: the node texts of the data model laid out as a row of boxes
    final texts = <String>[];
    if (dmDoc != null) {
      for (final pt in dmDoc.findAllElements('pt', namespace: '*')) {
        final ty = pt.getAttribute('type');
        if (ty != null && ty != 'node') continue;
        final tx = _first(pt, 't');
        final s = tx == null ? '' : tx.findAllElements('t', namespace: '*').map((e) => e.innerText).join(' ').trim();
        if (s.isNotEmpty) texts.add(s);
      }
    }
    final box = _box(_first(frame, 'xfrm'));
    final fw = box?.w ?? 1, fh = box?.h ?? 1;
    final cnt = texts.length;
    for (var i = 0; i < cnt; i++) {
      final n = PSmartNode();
      final gap = fw * .03;
      n.w = (fw - gap * (cnt + 1)) / cnt;
      n.h = fh * .5;
      n.x = gap + i * (n.w + gap);
      n.y = fh * .25;
      n.geom = 'roundRect';
      n.fill = c.theme['accent1'];
      n.plain = texts[i];
      nodes.add(n);
    }
    return nodes;
  }

  // ---------------------------------------------------------------- text layout
  /// Level style containers (elements that hold lvl1pPr..lvl9pPr) for [sh], most specific first.
  List<XmlElement?> _lstChain(PShape sh) => <XmlElement?>[
        _first(_first(sh.el, 'txBody'), 'lstStyle'),
        _first(_first(sh.phLayout, 'txBody'), 'lstStyle'),
        _first(_first(sh.phMaster, 'txBody'), 'lstStyle'),
      ];

  XmlElement? _txStyles(PShape sh, PSlide? s) {
    final part = s?.part;
    if (part == null) return null;
    final c = _ctxFor(part);
    final m = c.master == null ? null : z.xml(c.master!);
    final ts = m == null ? null : _deep(m.rootElement, 'txStyles');
    if (ts == null) return null;
    final t = sh.phType;
    if (_isTitle(t)) return _first(ts, 'titleStyle');
    if (t != null || sh.phLayout != null) return _first(ts, 'bodyStyle');
    return _first(ts, 'otherStyle');
  }

  static String? _a(List<XmlElement?> els, String name) {
    for (final e in els) {
      final v = e?.getAttribute(name);
      if (v != null) return v;
    }
    return null;
  }

  static const Map<String, String> _wing = {'§': '▪', 'Ø': '➢', 'q': '❑', 'v': '❖', 'ü': '✓', 'l': '●', 'n': '■', 'u': '◆', 'þ': '☑', 'o': '○', '¡': '•'};

  String _roman(int n, bool upper) {
    const v = [1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1];
    const s = ['m', 'cm', 'd', 'cd', 'c', 'xc', 'l', 'xl', 'x', 'ix', 'v', 'iv', 'i'];
    var out = '';
    var k = n;
    for (var i = 0; i < v.length; i++) {
      while (k >= v[i]) {
        out += s[i];
        k -= v[i];
      }
    }
    return upper ? out.toUpperCase() : out;
  }

  String _autoNum(String type, int n) {
    String alpha(bool up) {
      var s = '';
      var k = n;
      while (k > 0) {
        final r = (k - 1) % 26;
        s = String.fromCharCode((up ? 65 : 97) + r) + s;
        k = (k - 1) ~/ 26;
      }
      return s;
    }

    String core;
    if (type.startsWith('alphaLc')) {
      core = alpha(false);
    } else if (type.startsWith('alphaUc')) {
      core = alpha(true);
    } else if (type.startsWith('romanLc')) {
      core = _roman(n, false);
    } else if (type.startsWith('romanUc')) {
      core = _roman(n, true);
    } else {
      core = '$n';
    }
    if (type.endsWith('ParenBoth')) return '($core)';
    if (type.endsWith('ParenR')) return '$core)';
    if (type.endsWith('Period')) return '$core.';
    return core;
  }

  /// Lays out [paras] with inherited text styles. [lst]: style containers (most specific first); [txStyles]: the master's
  /// title / body / other style; [fontClr]: default colour from the shape style.
  List<PPara> layoutParas(List<XmlElement> paras, {List<XmlElement?> lst = const [], XmlElement? txStyles, double fontScale = 1, int? fontClr, int? defRgb, PSlide? slide, double defaultPt = 18}) {
    final ctx = slide == null ? null : _ctxFor(slide.part);
    int? colorOf(XmlElement? e) => e == null ? null : (ctx == null ? _clrNoCtx(e) : _solid(e, ctx));
    final out = <PPara>[];
    final counters = <int, int>{};
    for (final para in paras) {
      final pPr = _first(para, 'pPr');
      final lvl = int.tryParse(pPr?.getAttribute('lvl') ?? '0') ?? 0;
      final name = 'lvl${lvl + 1}pPr';
      final chain = <XmlElement?>[pPr];
      for (final l in [...lst, txStyles]) {
        chain.add(_first(l, name));
      }
      final rtl = _a(chain, 'rtl') == '1';
      final algn = _a(chain, 'algn') ?? (rtl ? 'r' : 'l');
      final marL = _num(_a(chain, 'marL')) ?? 0;
      final indent = _num(_a(chain, 'indent')) ?? 0;
      double spc(String tag) {
        for (final e in chain) {
          final s = _first(e, tag);
          if (s == null) continue;
          final pts = _first(s, 'spcPts');
          if (pts != null) return (_num(pts.getAttribute('val')) ?? 0) / 100;
          final pct = _first(s, 'spcPct');
          if (pct != null) return -((_num(pct.getAttribute('val')) ?? 0) / 100000); // negative = fraction of the font size
          return 0;
        }
        return 0;
      }

      var lnSpc = 1.0;
      for (final e in chain) {
        final s = _first(e, 'lnSpc');
        if (s == null) continue;
        final pct = _first(s, 'spcPct');
        if (pct != null) lnSpc = (_num(pct.getAttribute('val')) ?? 100000) / 100000;
        break;
      }
      // defaults of the runs
      final defs = <XmlElement?>[for (final e in chain) _first(e, 'defRPr')];
      final endRpr = _first(para, 'endParaRPr');
      double sizeOf(XmlElement? rpr) {
        final v = _num(rpr?.getAttribute('sz')) ?? _num(_a(defs, 'sz'));
        return (v == null ? defaultPt : v / 100) * fontScale;
      }

      int? colorFor(XmlElement? rpr) {
        final own = colorOf(rpr);
        if (own != null) return own;
        for (final d in defs) {
          final v = colorOf(d);
          if (v != null) return v;
        }
        return fontClr ?? defRgb;
      }

      bool flag(XmlElement? rpr, String a) {
        final v = rpr?.getAttribute(a) ?? _a(defs, a);
        return v == '1' || v == 'true';
      }

      final runs = <PRun>[];
      for (final k in para.children.whereType<XmlElement>()) {
        final nm = k.name.local;
        if (nm == 'r' || nm == 'fld') {
          final rpr = _first(k, 'rPr');
          final t = _first(k, 't')?.innerText ?? '';
          final u = (rpr?.getAttribute('u') ?? _a(defs, 'u') ?? 'none') != 'none';
          final st = (rpr?.getAttribute('strike') ?? 'noStrike') != 'noStrike';
          final base = int.tryParse(rpr?.getAttribute('baseline') ?? '0') ?? 0;
          final tf = _first(rpr, 'latin')?.getAttribute('typeface') ?? _first(rpr, 'cs')?.getAttribute('typeface');
          runs.add(PRun(t, sizeOf(rpr), flag(rpr, 'b'), flag(rpr, 'i'), u, st, colorFor(rpr), base ~/ 1000, font: tf == null || tf.startsWith('+') ? null : tf));
        } else if (nm == 'br') {
          final rpr = _first(k, 'rPr');
          runs.add(PRun('\n', sizeOf(rpr), false, false, false, false, null, 0));
        }
      }
      // bullets
      String? bullet;
      int? bulletRgb;
      var hasBu = false;
      for (final e in chain) {
        if (e == null) continue;
        if (_first(e, 'buNone') != null) {
          hasBu = true;
          break;
        }
        final ch = _first(e, 'buChar');
        final an = _first(e, 'buAutoNum');
        if (ch != null) {
          var s = ch.getAttribute('char') ?? '•';
          final font = _first(e, 'buFont')?.getAttribute('typeface') ?? '';
          if (font.toLowerCase().contains('wingdings') || font.toLowerCase().contains('symbol')) s = _wing[s] ?? '•';
          bullet = s;
          hasBu = true;
        } else if (an != null) {
          final start = int.tryParse(an.getAttribute('startAt') ?? '1') ?? 1;
          counters.removeWhere((k, _) => k > lvl);
          final n = (counters[lvl] ?? (start - 1)) + 1;
          counters[lvl] = n;
          bullet = _autoNum(an.getAttribute('type') ?? 'arabicPeriod', n);
          hasBu = true;
        }
        if (hasBu) {
          final bc = _first(e, 'buClr');
          if (bc != null) bulletRgb = ctx == null ? _clrNoCtx(bc) : _clr(bc, ctx);
          break;
        }
      }
      if (bullet == null) counters.removeWhere((k, _) => k >= lvl);
      final firstSize = runs.isNotEmpty ? runs.first.sizePt : sizeOf(endRpr);
      var bef = spc('spcBef'), aft = spc('spcAft');
      if (bef < 0) bef = -bef * firstSize;
      if (aft < 0) aft = -aft * firstSize;
      out.add(PPara(runs, algn, rtl, bullet, bulletRgb ?? (runs.isNotEmpty ? runs.first.rgb : null), marL, indent, bef, aft, lnSpc, firstSize));
    }
    return out;
  }

  int? _clrNoCtx(XmlElement holder) {
    // colour of a solidFill child without theme (srgb only)
    final sf = _first(holder, 'solidFill') ?? holder;
    final s = _first(sf, 'srgbClr');
    return s == null ? null : int.tryParse(s.getAttribute('val') ?? '', radix: 16);
  }

  /// Paragraph layout of a shape on [slide].
  List<PPara> paraList(PSlide slide, PShape sh) {
    if (sh.paras.isEmpty) return const [];
    return layoutParas(sh.paras,
        lst: _lstChain(sh), txStyles: _txStyles(sh, slide), fontScale: sh.fontScale, fontClr: sh.fontClr, slide: slide, defaultPt: _isTitle(sh.phType) ? 44 : 18);
  }

  /// Paragraph layout of the paragraphs of one table cell / SmartArt node.
  List<PPara> cellParas(PSlide slide, List<XmlElement> paras, {double defaultPt = 18}) {
    final tmp = PShape(slide.doc.rootElement, PKind.text, 0, 0, 0, 0);
    return layoutParas(paras, lst: const [], txStyles: _txStyles(tmp, slide), slide: slide, defaultPt: defaultPt);
  }

  /// Formatting of the first run of [para] (for the format dialog).
  PParaInfo paraInfo(PSlide slide, PShape sh, XmlElement para) {
    final l = layoutParas([para], lst: _lstChain(sh), txStyles: _txStyles(sh, slide), fontScale: sh.fontScale, fontClr: sh.fontClr, slide: slide, defaultPt: _isTitle(sh.phType) ? 44 : 18);
    final pp = l.first;
    final r = pp.runs.isEmpty ? null : pp.runs.first;
    return PParaInfo(r?.sizePt ?? pp.sizePt, r?.bold ?? false, r?.italic ?? false, r?.rgb, pp.align, pp.rtl);
  }

  // ---------------------------------------------------------------- editing
  void _writeBox(PSlide s, PShape sh) {
    final spPr = sh.el.name.local == 'graphicFrame' ? null : _first(sh.el, 'spPr');
    XmlElement? xf = sh.el.name.local == 'graphicFrame' ? _first(sh.el, 'xfrm') : _first(spPr, 'xfrm');
    if (xf == null) {
      if (spPr == null) return;
      xf = XmlElement(XmlName('xfrm', 'a'), [], [XmlElement(XmlName('off', 'a')), XmlElement(XmlName('ext', 'a'))]);
      spPr.children.insert(0, xf);
    }
    final off = _first(xf, 'off'), ext = _first(xf, 'ext');
    if (off == null || ext == null) return;
    final sx = sh.sx == 0 ? 1.0 : sh.sx, sy = sh.sy == 0 ? 1.0 : sh.sy;
    off.setAttribute('x', '${((sh.x - sh.ox) / sx).round()}');
    off.setAttribute('y', '${((sh.y - sh.oy) / sy).round()}');
    ext.setAttribute('cx', '${(sh.w / sx).round()}');
    ext.setAttribute('cy', '${(sh.h / sy).round()}');
    z.touch(s.part);
  }

  /// Moves a shape by [dx] / [dy] EMU (drag and arrow buttons).
  void moveBy(PSlide s, PShape sh, double dx, double dy) {
    if (!sh.movable) return;
    sh.x = (sh.x + dx).clamp(-sh.w + slideW * .02, slideW - slideW * .02).toDouble();
    sh.y = (sh.y + dy).clamp(-sh.h + slideH * .02, slideH - slideH * .02).toDouble();
    _writeBox(s, sh);
  }

  /// Moves a shape by a fraction of the slide size.
  void moveShape(PSlide s, PShape sh, double dxFrac, double dyFrac) => moveBy(s, sh, dxFrac * slideW, dyFrac * slideH);

  /// Resizes by dragging the bottom-right corner ([dw] / [dh] EMU).
  void resizeBy(PSlide s, PShape sh, double dw, double dh, {bool keepAspect = false}) {
    if (!sh.movable) return;
    var nw = (sh.w + dw).clamp(slideW * .02, slideW * 2).toDouble();
    var nh = (sh.h + dh).clamp(slideH * .02, slideH * 2).toDouble();
    if (keepAspect && sh.w > 0) {
      nh = nw * sh.h / sh.w;
    }
    sh.w = nw;
    sh.h = nh;
    _writeBox(s, sh);
  }

  /// Scales a shape around its top-left corner.
  void scaleShape(PSlide s, PShape sh, double f) {
    if (!sh.movable) return;
    sh.w = (sh.w * f).clamp(slideW * .03, slideW * 2).toDouble();
    sh.h = (sh.h * f).clamp(slideH * .03, slideH * 2).toDouble();
    _writeBox(s, sh);
  }

  /// Rotates by [deg] degrees (clockwise).
  void rotateBy(PSlide s, PShape sh, double deg) {
    if (!sh.movable) return;
    sh.rot = (sh.rot + deg) % 360;
    XmlElement? xf = sh.el.name.local == 'graphicFrame' ? _first(sh.el, 'xfrm') : _first(_first(sh.el, 'spPr'), 'xfrm');
    if (xf == null) {
      _writeBox(s, sh);
      xf = sh.el.name.local == 'graphicFrame' ? _first(sh.el, 'xfrm') : _first(_first(sh.el, 'spPr'), 'xfrm');
    }
    if (xf == null) return;
    xf.setAttribute('rot', '${(sh.rot * 60000).round()}');
    z.touch(s.part);
  }

  void deleteShape(PSlide s, PShape sh) {
    sh.el.parent?.children.remove(sh.el);
    z.touch(s.part);
    _load();
  }

  int _maxId(PSlide s) {
    var maxId = 1;
    for (final e in s.doc.findAllElements('cNvPr', namespace: '*')) {
      final v = int.tryParse(e.getAttribute('id') ?? '') ?? 0;
      if (v > maxId) maxId = v;
    }
    return maxId;
  }

  /// Adds a text box (centred, 24 pt) to the slide and returns its index in [PSlide.shapes].
  int addTextBox(PSlide s, String text) {
    final trees = s.doc.findAllElements('spTree', namespace: '*').toList();
    if (trees.isEmpty) return -1;
    final maxId = _maxId(s);
    final w = (slideW * .6).round(), h = (slideH * .15).round();
    final x = ((slideW - w) / 2).round(), y = ((slideH - h) / 2).round();
    final esc = XmlText(text).toXmlString();
    final xml = '<p:sp xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
        '<p:nvSpPr><p:cNvPr id="${maxId + 1}" name="TextBox ${maxId + 1}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
        '<p:spPr><a:xfrm><a:off x="$x" y="$y"/><a:ext cx="$w" cy="$h"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
        '<p:txBody><a:bodyPr wrap="square" rtlCol="0"><a:spAutoFit/></a:bodyPr><a:lstStyle/>'
        '<a:p><a:r><a:rPr lang="en-US" sz="2400" dirty="0"/><a:t>$esc</a:t></a:r></a:p></p:txBody></p:sp>';
    trees.first.children.add(XmlDocument.parse(xml).rootElement.copy());
    z.touch(s.part);
    _load();
    final i = slides.indexWhere((e) => e.part == s.part);
    return i < 0 ? -1 : slides[i].shapes.length - 1;
  }

  static const _imgTypes = {'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'gif': 'image/gif', 'bmp': 'image/bmp', 'webp': 'image/webp'};

  /// Adds a picture ([ext]: png / jpg / gif / bmp / webp) centred on the slide; [pxW] / [pxH] give the aspect ratio.
  /// Returns the index of the new shape in [PSlide.shapes], or -1.
  int addPicture(PSlide s, Uint8List bytes, String ext, int pxW, int pxH) {
    final trees = s.doc.findAllElements('spTree', namespace: '*').toList();
    final e = ext.toLowerCase().replaceAll('.', '');
    if (trees.isEmpty || !_imgTypes.containsKey(e)) return -1;
    var n = 1;
    while (z.file('ppt/media/abtin$n.$e') != null) {
      n++;
    }
    final media = 'ppt/media/abtin$n.$e';
    z.put(media, bytes);
    // content type default for the extension
    final ct = z.xml('[Content_Types].xml');
    if (ct != null) {
      final has = ct.findAllElements('Default', namespace: '*').any((d) => (d.getAttribute('Extension') ?? '').toLowerCase() == e);
      if (!has) {
        ct.rootElement.children.insert(0, XmlElement(XmlName('Default'), [XmlAttribute(XmlName('Extension'), e), XmlAttribute(XmlName('ContentType'), _imgTypes[e]!)]));
        z.touch('[Content_Types].xml');
      }
    }
    // relationship
    final relPath = _relsOf(s.part);
    var rels = z.xml(relPath);
    if (rels == null) {
      z.put(relPath, utf8.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>'));
      rels = z.xml(relPath);
    }
    if (rels == null) return -1;
    var maxRid = 0;
    for (final r in rels.findAllElements('Relationship', namespace: '*')) {
      final m = RegExp(r'(\d+)$').firstMatch(r.getAttribute('Id') ?? '');
      if (m != null && int.parse(m[1]!) > maxRid) maxRid = int.parse(m[1]!);
    }
    final rid = 'rId${maxRid + 1}';
    rels.rootElement.children.add(XmlElement(XmlName('Relationship'), [
      XmlAttribute(XmlName('Id'), rid),
      XmlAttribute(XmlName('Type'), 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/image'),
      XmlAttribute(XmlName('Target'), '../media/abtin$n.$e'),
    ]));
    z.touch(relPath);
    // fit into 60 % of the slide, keep the aspect ratio
    final ar = pxW > 0 && pxH > 0 ? pxW / pxH : 1.0;
    var w = slideW * .6, h = w / ar;
    if (h > slideH * .6) {
      h = slideH * .6;
      w = h * ar;
    }
    final x = ((slideW - w) / 2).round(), y = ((slideH - h) / 2).round();
    final id = _maxId(s) + 1;
    final xml = '<p:pic xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
        '<p:nvPicPr><p:cNvPr id="$id" name="Picture $id"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>'
        '<p:blipFill><a:blip r:embed="$rid"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>'
        '<p:spPr><a:xfrm><a:off x="$x" y="$y"/><a:ext cx="${w.round()}" cy="${h.round()}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>';
    trees.first.children.add(XmlDocument.parse(xml).rootElement.copy());
    z.touch(s.part);
    _load();
    final i = slides.indexWhere((e2) => e2.part == s.part);
    return i < 0 ? -1 : slides[i].shapes.length - 1;
  }

  /// Applies an edited paragraph list to a shape: entries with src >= 0 keep that original paragraph
  /// (and its formatting), src < 0 are new paragraphs (formatted like the previous one); originals not listed are removed.
  void applyParas(PSlide s, PShape sh, List<({int src, String text})> entries) {
    final orig = List<XmlElement>.from(sh.paras);
    if (orig.isEmpty) return;
    final keep = <int>{for (final e in entries) if (e.src >= 0) e.src};
    XmlElement? prev;
    for (final e in entries) {
      if (e.src >= 0 && e.src < orig.length) {
        final para = orig[e.src];
        if (text(para) != e.text) setText(s, para, e.text);
        prev = para;
      } else {
        final tmpl = prev ?? orig.first;
        final c = tmpl.copy();
        setText(s, c, e.text);
        final par = tmpl.parent;
        if (par == null) continue;
        par.children.insert(prev == null ? par.children.indexOf(tmpl) : par.children.indexOf(tmpl) + 1, c);
        prev = c;
      }
    }
    for (var i = 0; i < orig.length; i++) {
      if (!keep.contains(i)) orig[i].parent?.children.remove(orig[i]);
    }
    z.touch(s.part);
    _load();
  }

  /// Sets size / bold / italic / colour / alignment on every run of the shape (null = leave as is).
  void setFormat(PSlide s, PShape sh, {double? sizePt, bool? bold, bool? italic, int? rgb, String? align}) {
    for (final para in sh.paras) {
      if (align != null) {
        var ppr = _first(para, 'pPr');
        if (ppr == null) {
          ppr = XmlElement(XmlName('pPr', 'a'));
          para.children.insert(0, ppr);
        }
        ppr.setAttribute('algn', align);
      }
      for (final r in para.findElements('r', namespace: '*')) {
        var rpr = _first(r, 'rPr');
        if (rpr == null) {
          rpr = XmlElement(XmlName('rPr', 'a'));
          r.children.insert(0, rpr);
        }
        if (sizePt != null) rpr.setAttribute('sz', '${(sizePt * 100).round()}');
        if (bold != null) rpr.setAttribute('b', bold ? '1' : '0');
        if (italic != null) rpr.setAttribute('i', italic ? '1' : '0');
        if (rgb != null) {
          rpr.children.removeWhere((c) => c is XmlElement && (c.name.local == 'solidFill' || c.name.local == 'gradFill' || c.name.local == 'noFill'));
          final hex = (rgb & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase();
          rpr.children.insert(0, XmlElement(XmlName('solidFill', 'a'), [], [XmlElement(XmlName('srgbClr', 'a'), [XmlAttribute(XmlName('val'), hex)])]));
        }
      }
    }
    z.touch(s.part);
  }

  String _relsOf(String part) => '${p.posix.dirname(part)}/_rels/${p.posix.basename(part)}.rels';

  void move(int i, int delta) {
    final j = i + delta;
    if (j < 0 || j >= slides.length) return;
    final el = slides[i].sldId, ref = slides[j].sldId;
    final lst = el.parent!;
    lst.children.remove(el);
    final idx = lst.children.indexOf(ref);
    lst.children.insert(delta > 0 ? idx + 1 : idx, el);
    z.touch('ppt/presentation.xml');
    _load();
  }

  void delete(int i) {
    final s = slides[i];
    s.sldId.parent!.children.remove(s.sldId);
    final rl = z.xml('ppt/_rels/presentation.xml.rels');
    rl?.findAllElements('Relationship', namespace: '*').where((e) => e.getAttribute('Id') == s.rid).toList().forEach((e) => e.parent!.children.remove(e));
    z.touch('ppt/_rels/presentation.xml.rels');
    z.touch('ppt/presentation.xml');
    // notes slide of this slide goes with it
    for (final t in z.rels(s.part).values) {
      if (t.contains('/notesSlides/')) {
        z.drop.add(t);
        z.drop.add(_relsOf(t));
        z.removeOverride(t);
      }
    }
    z.drop.add(s.part);
    z.drop.add(_relsOf(s.part));
    z.removeOverride(s.part);
    _load();
  }

  /// Copies slide [i] right after itself; with [blank] all text is cleared (pictures stay).
  void duplicate(int i, {bool blank = false}) {
    final s = slides[i];
    var n = 1;
    while (z.file('ppt/slides/slide$n.xml') != null) {
      n++;
    }
    final name = 'ppt/slides/slide$n.xml';
    final doc = XmlDocument.parse(s.doc.toXmlString());
    if (blank) {
      for (final t in doc.findAllElements('t', namespace: '*')) {
        if (t.name.prefix == 'a') t.children.clear();
      }
    }
    z.put(name, utf8.encode(doc.toXmlString()));
    final src = z.xml(_relsOf(s.part));
    if (src != null) {
      final c = XmlDocument.parse(src.toXmlString());
      c.findAllElements('Relationship', namespace: '*').where((e) => (e.getAttribute('Type') ?? '').endsWith('/notesSlide')).toList().forEach((e) => e.parent!.children.remove(e));
      z.put(_relsOf(name), utf8.encode(c.toXmlString()));
    }
    z.addOverride('/$name', 'application/vnd.openxmlformats-officedocument.presentationml.slide+xml');
    final rl = z.xml('ppt/_rels/presentation.xml.rels')!;
    var maxId = 0;
    for (final r in rl.findAllElements('Relationship', namespace: '*')) {
      final m = RegExp(r'(\d+)$').firstMatch(r.getAttribute('Id') ?? '');
      if (m != null && int.parse(m[1]!) > maxId) maxId = int.parse(m[1]!);
    }
    final rid = 'rId${maxId + 1}';
    rl.rootElement.children.add(XmlElement(XmlName('Relationship'), [
      XmlAttribute(XmlName('Id'), rid),
      XmlAttribute(XmlName('Type'), 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide'),
      XmlAttribute(XmlName('Target'), 'slides/slide$n.xml'),
    ]));
    var maxSld = 255;
    for (final e in _pres.findAllElements('sldId', namespace: '*')) {
      final v = int.tryParse(e.getAttribute('id') ?? '') ?? 0;
      if (v > maxSld) maxSld = v;
    }
    final el = XmlElement(XmlName('sldId', 'p'), [XmlAttribute(XmlName('id'), '${maxSld + 1}'), XmlAttribute(XmlName('id', 'r'), rid)]);
    final lst = s.sldId.parent!;
    lst.children.insert(lst.children.indexOf(s.sldId) + 1, el);
    z.touch('ppt/_rels/presentation.xml.rels');
    z.touch('ppt/presentation.xml');
    _load();
  }

  String text(XmlElement para) => para.findAllElements('t', namespace: '*').map((e) => e.innerText).join();

  void setText(PSlide s, XmlElement para, String text) {
    final ts = para.findAllElements('t', namespace: '*').toList();
    if (ts.isEmpty) {
      final r = XmlElement(XmlName('r', 'a'), [], [XmlElement(XmlName('t', 'a'), [], [XmlText(text)])]);
      final end = para.children.whereType<XmlElement>().where((e) => e.name.local == 'endParaRPr').toList();
      if (end.isEmpty) {
        para.children.add(r);
      } else {
        para.children.insert(para.children.indexOf(end.first), r);
      }
    } else {
      ts.first.children
        ..clear()
        ..add(XmlText(text));
      for (final t in ts.skip(1)) {
        t.children.clear();
      }
    }
    z.touch(s.part);
  }
}

class _Grp {
  double ox = 0, oy = 0, w = 0, h = 0, cox = 0, coy = 0, cw = 0, ch = 0, rot = 0;
  bool flipH = false, flipV = false;
}
