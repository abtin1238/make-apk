import 'package:xml/xml.dart';

/// Column letters -> 0-based index ("A" = 0).
int colIndex(String letters) {
  var n = 0;
  for (final c in letters.toUpperCase().codeUnits) {
    n = n * 26 + (c - 64);
  }
  return n - 1;
}

/// 0-based column index -> letters.
String colName(int i) {
  var s = '';
  var n = i + 1;
  while (n > 0) {
    final r = (n - 1) % 26;
    s = String.fromCharCode(65 + r) + s;
    n = (n - 1) ~/ 26;
  }
  return s;
}

/// "B7" -> (1, 7) (0-based column, 1-based row); null when invalid.
(int, int)? parseRef(String ref) {
  final m = RegExp(r'^\$?([A-Za-z]{1,3})\$?(\d{1,7})$').firstMatch(ref.trim());
  if (m == null) return null;
  return (colIndex(m[1]!), int.parse(m[2]!));
}

String refOf(int c, int r) => '${colName(c)}$r';

/// Rectangular cell range (columns 0-based, rows 1-based, always normalised c1<=c2, r1<=r2).
class XRange {
  final int c1, r1, c2, r2;
  const XRange(this.c1, this.r1, this.c2, this.r2);
  factory XRange.cell(int c, int r) => XRange(c, r, c, r);
  factory XRange.of(int ca, int ra, int cb, int rb) => XRange(ca < cb ? ca : cb, ra < rb ? ra : rb, ca < cb ? cb : ca, ra < rb ? rb : ra);

  static XRange? parse(String s) {
    final parts = s.replaceAll(r'$', '').split(':');
    final a = parseRef(parts[0]);
    if (a == null) return null;
    final b = parts.length > 1 ? parseRef(parts[1]) : a;
    if (b == null) return null;
    return XRange.of(a.$1, a.$2, b.$1, b.$2);
  }

  int get cols => c2 - c1 + 1;
  int get rows => r2 - r1 + 1;
  bool get isCell => c1 == c2 && r1 == r2;
  String get ref => isCell ? refOf(c1, r1) : '${refOf(c1, r1)}:${refOf(c2, r2)}';
  bool contains(int c, int r) => c >= c1 && c <= c2 && r >= r1 && r <= r2;
  bool intersects(XRange o) => !(o.c2 < c1 || o.c1 > c2 || o.r2 < r1 || o.r1 > r2);
  Iterable<String> get refs sync* {
    for (var r = r1; r <= r2; r++) {
      for (var c = c1; c <= c2; c++) {
        yield refOf(c, r);
      }
    }
  }

  @override
  bool operator ==(Object other) => other is XRange && other.c1 == c1 && other.r1 == r1 && other.c2 == c2 && other.r2 == r2;
  @override
  int get hashCode => Object.hash(c1, r1, c2, r2);
}

/// Border sides bit mask.
class XBorder {
  static const left = 1, right = 2, top = 4, bottom = 8, all = 15;
}

/// Everything about how one cell looks. Colours are 0xRRGGBB (no alpha).
class XStyle {
  final bool bold, italic, underline, strike, wrap;
  final double? size;
  final int? color, fill;
  final String font; // '' = workbook default
  final String h; // '', left, center, right, justify
  final String v; // '', top, center, bottom
  final String numFmt; // '' / General = general
  final int border;
  final int indent;
  const XStyle({
    this.bold = false,
    this.italic = false,
    this.underline = false,
    this.strike = false,
    this.wrap = false,
    this.size,
    this.color,
    this.fill,
    this.font = '',
    this.h = '',
    this.v = '',
    this.numFmt = '',
    this.border = 0,
    this.indent = 0,
  });

  static const plain = XStyle();

  bool get isPlain =>
      !bold && !italic && !underline && !strike && !wrap && size == null && color == null && fill == null && font.isEmpty && h.isEmpty && v.isEmpty && (numFmt.isEmpty || numFmt == 'General') && border == 0 && indent == 0;

  XStyle copyWith({
    bool? bold,
    bool? italic,
    bool? underline,
    bool? strike,
    bool? wrap,
    double? size,
    int? color,
    int? fill,
    String? font,
    String? h,
    String? v,
    String? numFmt,
    int? border,
    int? indent,
    bool clearSize = false,
    bool clearColor = false,
    bool clearFill = false,
  }) =>
      XStyle(
        bold: bold ?? this.bold,
        italic: italic ?? this.italic,
        underline: underline ?? this.underline,
        strike: strike ?? this.strike,
        wrap: wrap ?? this.wrap,
        size: clearSize ? null : (size ?? this.size),
        color: clearColor ? null : (color ?? this.color),
        fill: clearFill ? null : (fill ?? this.fill),
        font: font ?? this.font,
        h: h ?? this.h,
        v: v ?? this.v,
        numFmt: numFmt ?? this.numFmt,
        border: border ?? this.border,
        indent: indent ?? this.indent,
      );

  String get key => '$bold$italic$underline$strike$wrap|$size|$color|$fill|$font|$h|$v|$numFmt|$border|$indent';

  @override
  bool operator ==(Object other) => other is XStyle && other.key == key;
  @override
  int get hashCode => key.hashCode;
}

/// Conditional-formatting rule (cell is / text contains / duplicates / colour scale).
class XCond {
  final String type; // cellIs, containsText, duplicate, unique, colorScale, top10, aboveAverage
  final XRange range;
  final String op; // greaterThan, lessThan, equal, between, ... (cellIs)
  final String v1, v2;
  final int? fill, color;
  final bool bold;
  final List<int> scale; // 2 or 3 RGB colours for colorScale
  const XCond({required this.type, required this.range, this.op = '', this.v1 = '', this.v2 = '', this.fill, this.color, this.bold = false, this.scale = const []});
}

/// Data-validation rule of a range.
class XValidation {
  final XRange range;
  final String type; // list, whole, decimal, textLength, date, custom
  final String op; // between, notBetween, equal, notEqual, greaterThan, lessThan, greaterThanOrEqual, lessThanOrEqual
  final String f1, f2;
  final bool allowBlank, dropdown;
  final String title, message;
  const XValidation({required this.range, required this.type, this.op = 'between', this.f1 = '', this.f2 = '', this.allowBlank = true, this.dropdown = true, this.title = '', this.message = ''});
  List<String> get items => f1.startsWith('"') ? f1.replaceAll('"', '').split(',').map((e) => e.trim()).toList() : const [];
}

class XSeries {
  String name;
  List<String> cats;
  List<double> vals;
  String? nameRef, catRef, valRef; // worksheet references, e.g. Sheet1!$B$2:$B$6 (live data)
  XSeries(this.name, this.cats, this.vals, {this.nameRef, this.catRef, this.valRef});
}

/// A chart placed on a sheet (anchored between two cells).
class XChart {
  final String part, drawingPart, anchorId;
  int c1, r1, c2, r2; // 0-based col / 0-based row of the anchor corners
  String type; // col, bar, line, pie, area, doughnut, scatter
  String title;
  final List<XSeries> series;
  XChart({required this.part, required this.drawingPart, required this.anchorId, required this.c1, required this.r1, required this.c2, required this.r2, required this.type, required this.title, required this.series});
}

class XSheet {
  String name;
  final String part;
  final XmlDocument doc;
  final Map<String, String> cells = {};
  final Map<String, String> formulas = {}; // ref -> formula (without '=')
  final Map<String, XStyle> styles = {};
  final Map<String, dynamic> computed = {}; // evaluated formula results for display and cached XLSX values
  final Map<int, double> colWidths = {}; // 0-based column -> px
  final Map<int, double> rowHeights = {}; // 1-based row -> px
  final Set<int> hiddenCols = {}, hiddenRows = {};
  final List<XRange> merges = [];
  final List<XCond> conds = [];
  final List<XValidation> validations = [];
  final List<XChart> charts = [];
  int frozenRows = 0, frozenCols = 0;
  bool rtl = false, showGrid = true, hidden = false;
  int? tabColor;
  double defColW = 80;
  XRange? filter; // auto-filter range
  final Map<int, Set<String>> filterValues = {}; // column -> allowed display values
  int rows = 0, cols = 0;
  XSheet(this.name, this.part, this.doc);

  XRange? mergeAt(int c, int r) {
    for (final m in merges) {
      if (m.contains(c, r)) return m;
    }
    return null;
  }

  double colW(int c) => hiddenCols.contains(c) ? 0.0 : (colWidths[c] ?? defColW);
  double rowH(int r) => hiddenRows.contains(r) ? 0.0 : (rowHeights[r] ?? 30.0);
}

/// Copied cells (clipboard of the grid).
class XClip {
  final int rows, cols;
  final List<List<XClipCell>> cells;
  final bool cut;
  final XRange source;
  XClip(this.rows, this.cols, this.cells, this.cut, this.source);
}

class XClipCell {
  final String content; // "=SUM(A1)" for formulas, plain text otherwise
  final XStyle style;
  const XClipCell(this.content, this.style);
}
