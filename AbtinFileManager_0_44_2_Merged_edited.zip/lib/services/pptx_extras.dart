part of 'pptx_service.dart';

// ---------------------------------------------------------------- designs (ready-made themes)
class PDesign {
  final String id, fa, en;
  final bool dark;
  final int dk1, lt1, dk2, lt2;
  final List<int> accents; // 6
  final List<int>? grad; // background gradient (top -> bottom), null = flat
  final String major, minor;
  const PDesign(this.id, this.fa, this.en, this.dark, this.dk1, this.lt1, this.dk2, this.lt2, this.accents, {this.grad, this.major = 'Calibri', this.minor = 'Calibri'});

  /// Background colour of the slides (flat designs) / first gradient stop.
  int get bg => grad?.first ?? (dark ? dk1 : lt1);
}

const List<PDesign> kPptxDesigns = [
  PDesign('office', 'آفیس (روشن)', 'Office (light)', false, 0x000000, 0xFFFFFF, 0x44546A, 0xE7E6E6, [0x4472C4, 0xED7D31, 0xA5A5A5, 0xFFC000, 0x5B9BD5, 0x70AD47]),
  PDesign('ocean', 'اقیانوس (تیره)', 'Ocean (dark)', true, 0x0F2A47, 0xFFFFFF, 0x16395F, 0xCFE8F5, [0x21B6C9, 0xF59E3F, 0x4FD1C5, 0x7AA7FF, 0xF26B6B, 0xA0E26B], grad: [0x0F2A47, 0x17406B]),
  PDesign('sunset', 'غروب (روشن)', 'Sunset (light)', false, 0x3B2A20, 0xFFF7EC, 0x7A3E1D, 0xFBE3C8, [0xE4572E, 0xF29E4C, 0xF7C873, 0xA8423F, 0x6C8E3E, 0x3E7CB1]),
  PDesign('forest', 'جنگل (روشن)', 'Forest (light)', false, 0x1E2F23, 0xF3F8F1, 0x2F5D3A, 0xDDEBD8, [0x2E7D32, 0x66A34C, 0xA8C66C, 0x8D6E3F, 0x3F8F8A, 0xD4A017]),
  PDesign('graphite', 'گرافیت (تیره)', 'Graphite (dark)', true, 0x1E2228, 0xF2F4F7, 0x2B3139, 0xC9CFD8, [0x4C86F5, 0x36C2B4, 0xF5A623, 0xE5546B, 0xA78BFA, 0x8BC34A]),
  PDesign('violet', 'بنفش (تیره)', 'Violet (dark)', true, 0x231A44, 0xFFFFFF, 0x3B2A7A, 0xE3DBFF, [0x8A6BFF, 0xFF6BD6, 0x4DD0E1, 0xFFC857, 0x6BE4A8, 0xFF8A65], grad: [0x231A44, 0x3B2A7A]),
  PDesign('gold', 'طلایی (تیره)', 'Gold (dark)', true, 0x14110C, 0xF7EBD2, 0x2A2318, 0xE8D5A8, [0xD4A537, 0xB5812A, 0xE9C46A, 0x8C6A2E, 0xC97B3C, 0xA3B18A]),
  PDesign('mint', 'نعنایی (روشن)', 'Mint (light)', false, 0x1F2933, 0xFFFFFF, 0x0F766E, 0xE6F4F1, [0x14B8A6, 0x0EA5E9, 0xF59E0B, 0xEF4444, 0x8B5CF6, 0x64748B]),
];

/// Kinds of slide transition ("slide effects"): id -> (fa, en).
const Map<String, (String, String)> kPptxTransitions = {
  'none': ('بدون افکت', 'None'),
  'fade': ('محو شدن', 'Fade'),
  'push': ('هل دادن', 'Push'),
  'wipe': ('پاک کردن', 'Wipe'),
  'cover': ('پوشاندن', 'Cover'),
  'uncover': ('کنار زدن', 'Uncover'),
  'split': ('شکافتن', 'Split'),
  'zoom': ('بزرگ‌نمایی', 'Zoom'),
  'dissolve': ('حل شدن', 'Dissolve'),
  'circle': ('دایره', 'Circle'),
  'diamond': ('لوزی', 'Diamond'),
  'plus': ('بعلاوه', 'Plus'),
  'randomBar': ('نوارهای تصادفی', 'Random bars'),
  'wheel': ('چرخ', 'Wheel'),
};

/// Fonts offered in the font picker (typeface names written to the file).
const List<String> kPptxFonts = [
  'Calibri', 'Arial', 'Tahoma', 'Verdana', 'Segoe UI', 'Times New Roman', 'Georgia', 'Courier New',
  'Vazir', 'B Titr', 'B Nazanin', 'B Yekan',
];

const _nsA = 'http://schemas.openxmlformats.org/drawingml/2006/main';
const _nsP = 'http://schemas.openxmlformats.org/presentationml/2006/main';

XmlElement _frag(String xml) {
  final d = XmlDocument.parse('<r xmlns:a="$_nsA" xmlns:p="$_nsP">$xml</r>');
  return d.rootElement.children.whereType<XmlElement>().first.copy();
}

String _hex(int v) => (v & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase();

const _pprOrder = ['lnSpc', 'spcBef', 'spcAft', 'buClrTx', 'buClr', 'buSzTx', 'buSzPct', 'buSzPts', 'buFontTx', 'buFont', 'buNone', 'buAutoNum', 'buChar', 'buBlip', 'tabLst', 'defRPr', 'extLst'];
const _rprOrder = ['ln', 'noFill', 'solidFill', 'gradFill', 'blipFill', 'pattFill', 'grpFill', 'effectLst', 'effectDag', 'highlight', 'uLnTx', 'uLn', 'uFillTx', 'uFill', 'latin', 'ea', 'cs', 'sym', 'hlinkClick', 'hlinkMouseOver', 'rtl', 'extLst'];

void _putOrdered(XmlElement parent, XmlElement el, List<String> order) {
  final rank = order.indexOf(el.name.local);
  var at = parent.children.length;
  for (var i = 0; i < parent.children.length; i++) {
    final c = parent.children[i];
    if (c is XmlElement) {
      final r = order.indexOf(c.name.local);
      if (r > rank) {
        at = i;
        break;
      }
    }
  }
  parent.children.insert(at, el);
}

XmlElement _pprOf(XmlElement para) {
  var ppr = PptxFile._first(para, 'pPr');
  if (ppr == null) {
    ppr = XmlElement(XmlName('pPr', 'a'));
    para.children.insert(0, ppr);
  }
  return ppr;
}

extension PptxExtras on PptxFile {
  // ---- font family of every run (and of the empty-paragraph end mark)
  void setFont(PSlide s, PShape sh, String typeface) {
    for (final para in sh.paras) {
      final rprs = <XmlElement>[];
      for (final r in para.findElements('r', namespace: '*')) {
        var rpr = PptxFile._first(r, 'rPr');
        if (rpr == null) {
          rpr = XmlElement(XmlName('rPr', 'a'));
          r.children.insert(0, rpr);
        }
        rprs.add(rpr);
      }
      final end = PptxFile._first(para, 'endParaRPr');
      if (end != null) rprs.add(end);
      for (final rpr in rprs) {
        rpr.children.removeWhere((c) => c is XmlElement && const ['latin', 'ea', 'cs'].contains(c.name.local));
        for (final tag in const ['latin', 'cs']) {
          _putOrdered(rpr, XmlElement(XmlName(tag, 'a'), [XmlAttribute(XmlName('typeface'), typeface)]), _rprOrder);
        }
      }
    }
    z.touch(s.part);
  }

  /// First run's font family of [sh] (null = inherited).
  String? fontOf(PShape sh) {
    for (final para in sh.paras) {
      for (final r in para.findElements('r', namespace: '*')) {
        final f = PptxFile._first(PptxFile._first(r, 'rPr'), 'latin')?.getAttribute('typeface');
        if (f != null && !f.startsWith('+')) return f;
      }
    }
    return null;
  }

  // ---- paragraph options: bullet 'none' | 'dot' | 'num', line spacing (1.0 = single), space before / after (pt), rtl
  void setParagraph(PSlide s, PShape sh, {String? bullet, double? lineSpacing, double? spcBef, double? spcAft, bool? rtl, int? level}) {
    for (final para in sh.paras) {
      final ppr = _pprOf(para);
      if (bullet != null) {
        ppr.children.removeWhere((c) => c is XmlElement && const ['buNone', 'buAutoNum', 'buChar', 'buBlip', 'buFont', 'buFontTx'].contains(c.name.local));
        if (bullet == 'none') {
          ppr.setAttribute('marL', '0');
          ppr.setAttribute('indent', '0');
          _putOrdered(ppr, _frag('<a:buNone/>'), _pprOrder);
        } else if (bullet == 'dot') {
          ppr.setAttribute('marL', '342900');
          ppr.setAttribute('indent', '-342900');
          _putOrdered(ppr, _frag('<a:buFont typeface="Arial"/>'), _pprOrder);
          _putOrdered(ppr, _frag('<a:buChar char="&#8226;"/>'), _pprOrder);
        } else {
          ppr.setAttribute('marL', '457200');
          ppr.setAttribute('indent', '-457200');
          _putOrdered(ppr, _frag('<a:buFont typeface="+mj-lt"/>'), _pprOrder);
          _putOrdered(ppr, _frag('<a:buAutoNum type="arabicPeriod"/>'), _pprOrder);
        }
      }
      void put(String tag, String inner) {
        ppr.children.removeWhere((c) => c is XmlElement && c.name.local == tag);
        _putOrdered(ppr, _frag('<a:$tag>$inner</a:$tag>'), _pprOrder);
      }

      if (lineSpacing != null) put('lnSpc', '<a:spcPct val="${(lineSpacing * 100000).round()}"/>');
      if (spcBef != null) put('spcBef', '<a:spcPts val="${(spcBef * 100).round()}"/>');
      if (spcAft != null) put('spcAft', '<a:spcPts val="${(spcAft * 100).round()}"/>');
      if (rtl != null) ppr.setAttribute('rtl', rtl ? '1' : '0');
      if (level != null) ppr.setAttribute('lvl', '${level.clamp(0, 8)}');
    }
    z.touch(s.part);
  }

  // ---- slide transitions
  String transitionOf(PSlide s) {
    final t = PptxFile._deep(s.doc.rootElement, 'transition');
    if (t == null) return 'none';
    for (final c in t.children.whereType<XmlElement>()) {
      final n = c.name.local;
      if (n == 'pull') return 'uncover';
      if (kPptxTransitions.containsKey(n)) return n;
    }
    return 'fade'; // some other (newer) effect: shown as a fade
  }

  String transitionSpeedOf(PSlide s) => PptxFile._deep(s.doc.rootElement, 'transition')?.getAttribute('spd') ?? 'med';

  void setTransition(PSlide s, String kind, {String speed = 'med'}) {
    final root = s.doc.rootElement;
    // drop the old one (also when wrapped in mc:AlternateContent)
    root.children.removeWhere((c) => c is XmlElement && ((c.name.local == 'transition') || (c.name.local == 'AlternateContent' && PptxFile._deep(c, 'transition') != null)));
    if (kind != 'none') {
      final inner = switch (kind) {
        'push' => '<p:push dir="l"/>',
        'wipe' => '<p:wipe dir="l"/>',
        'cover' => '<p:cover dir="l"/>',
        'uncover' => '<p:pull dir="l"/>',
        'split' => '<p:split orient="horz" dir="out"/>',
        'zoom' => '<p:zoom dir="in"/>',
        'randomBar' => '<p:randomBar dir="horz"/>',
        'wheel' => '<p:wheel spokes="4"/>',
        _ => '<p:$kind/>',
      };
      final el = _frag('<p:transition spd="$speed">$inner</p:transition>');
      var at = root.children.length;
      for (var i = 0; i < root.children.length; i++) {
        final c = root.children[i];
        if (c is XmlElement && const ['timing', 'extLst'].contains(c.name.local)) {
          at = i;
          break;
        }
      }
      root.children.insert(at, el);
    }
    z.touch(s.part);
  }

  void setTransitionAll(String kind, {String speed = 'med'}) {
    for (final s in slides) {
      setTransition(s, kind, speed: speed);
    }
  }

  // ---- design: theme colours + fonts + background of the master, light / dark colour map
  void applyDesign(PDesign d, {bool clearSlideBackgrounds = true}) {
    final masters = <String>{};
    for (final s in slides) {
      final c = _ctxFor(s.part);
      if (c.master != null) masters.add(c.master!);
    }
    if (masters.isEmpty) return;
    for (final m in masters) {
      final rels = z.rels(m);
      // theme
      String? themePart;
      for (final t in rels.values) {
        if (t.contains('/theme/')) themePart = t;
      }
      final th = themePart == null ? null : z.xml(themePart);
      final cs = th == null ? null : PptxFile._deep(th.rootElement, 'clrScheme');
      if (cs != null && themePart != null) {
        final vals = <String, int>{
          'dk1': d.dk1, 'lt1': d.lt1, 'dk2': d.dk2, 'lt2': d.lt2,
          for (var i = 0; i < 6; i++) 'accent${i + 1}': d.accents[i],
          'hlink': d.accents[0], 'folHlink': d.accents[3],
        };
        for (final e in cs.children.whereType<XmlElement>().toList()) {
          final v = vals[e.name.local];
          if (v == null) continue;
          e.children.clear();
          e.children.add(XmlElement(XmlName('srgbClr', 'a'), [XmlAttribute(XmlName('val'), _hex(v))]));
        }
        final fs = PptxFile._deep(th!.rootElement, 'fontScheme');
        if (fs != null) {
          for (final pair in [('majorFont', d.major), ('minorFont', d.minor)]) {
            final lat = PptxFile._first(PptxFile._first(fs, pair.$1), 'latin');
            lat?.setAttribute('typeface', pair.$2);
          }
        }
        z.touch(themePart);
      }
      // master: colour map + background
      final md = z.xml(m);
      if (md == null) continue;
      final map = PptxFile._deep(md.rootElement, 'clrMap');
      if (map != null) {
        map.setAttribute('bg1', d.dark ? 'dk1' : 'lt1');
        map.setAttribute('tx1', d.dark ? 'lt1' : 'dk1');
        map.setAttribute('bg2', d.dark ? 'dk2' : 'lt2');
        map.setAttribute('tx2', d.dark ? 'lt2' : 'dk2');
      }
      _setBg(md, d);
      z.touch(m);
      // layouts of this master: their own backgrounds would hide the design
      for (final t in rels.values) {
        if (!t.contains('/slideLayouts/')) continue;
        final ld = z.xml(t);
        if (ld == null) continue;
        final csld = PptxFile._first(ld.rootElement, 'cSld');
        final had = csld?.children.any((c) => c is XmlElement && c.name.local == 'bg') ?? false;
        if (had) {
          csld!.children.removeWhere((c) => c is XmlElement && c.name.local == 'bg');
          z.touch(t);
        }
      }
    }
    if (clearSlideBackgrounds) {
      for (final s in slides) {
        final csld = PptxFile._first(s.doc.rootElement, 'cSld');
        if (csld != null && csld.children.any((c) => c is XmlElement && c.name.local == 'bg')) {
          csld.children.removeWhere((c) => c is XmlElement && c.name.local == 'bg');
          z.touch(s.part);
        }
      }
    }
    _load();
  }

  void _setBg(XmlDocument doc, PDesign d) {
    final csld = PptxFile._first(doc.rootElement, 'cSld');
    if (csld == null) return;
    csld.children.removeWhere((c) => c is XmlElement && c.name.local == 'bg');
    final fill = d.grad == null
        ? '<a:solidFill><a:srgbClr val="${_hex(d.bg)}"/></a:solidFill>'
        : '<a:gradFill rotWithShape="1"><a:gsLst>'
            '<a:gs pos="0"><a:srgbClr val="${_hex(d.grad!.first)}"/></a:gs>'
            '<a:gs pos="100000"><a:srgbClr val="${_hex(d.grad!.last)}"/></a:gs>'
            '</a:gsLst><a:lin ang="5400000" scaled="0"/></a:gradFill>';
    csld.children.insert(0, _frag('<p:bg><p:bgPr>$fill<a:effectLst/></p:bgPr></p:bg>'));
  }
}
