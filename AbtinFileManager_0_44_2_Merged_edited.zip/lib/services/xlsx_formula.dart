import 'dart:math' as math;
import 'xlsx_format.dart';

/// Local Excel-compatible formula evaluator. Returns Excel error values ("#DIV/0!" ...) instead of throwing.
/// Supports operators, cell / range / cross-sheet references, defined names and ~190 worksheet functions
/// (math, statistics, logical, text, lookup, date / time, financial, information).
class XlsxFormulaEngine {
  static const errors = {'#DIV/0!', '#VALUE!', '#REF!', '#NAME?', '#NUM!', '#N/A', '#NULL!', '#CIRCULAR!'};

  static dynamic evaluate(
    String source, {
    required dynamic Function(String ref) cell,
    required List<dynamic> Function(String from, String to) range,
    dynamic Function(String sheet, String ref)? sheetCell,
    List<dynamic> Function(String sheet, String from, String to)? sheetRange,
    String? Function(String name)? name,
    String currentRef = 'A1',
    DateTime? now,
  }) {
    try {
      final parser = _FormulaParser(source, cell, range, sheetCell, sheetRange, name, currentRef, now ?? DateTime.now());
      final value = parser.parse();
      if (!parser.done) return '#VALUE!';
      if (value is _RangeValue) return value.values.isEmpty ? '' : value.values.first;
      if (value is _Err) return value.code;
      return value;
    } on _FormulaError catch (e) {
      return e.value;
    } catch (_) {
      return '#VALUE!';
    }
  }

  /// Function names understood by the engine (used by the function picker and tests).
  static const supported = <String>[
    'SUM', 'AVERAGE', 'COUNT', 'COUNTA', 'COUNTBLANK', 'MAX', 'MIN', 'PRODUCT', 'ROUND', 'ROUNDUP', 'ROUNDDOWN', 'INT', 'TRUNC', 'CEILING', 'FLOOR', 'MROUND',
    'ABS', 'SQRT', 'POWER', 'MOD', 'SIGN', 'EXP', 'LN', 'LOG', 'LOG10', 'FACT', 'COMBIN', 'PERMUT', 'GCD', 'LCM', 'EVEN', 'ODD', 'QUOTIENT', 'PI', 'RAND', 'RANDBETWEEN',
    'SIN', 'COS', 'TAN', 'ASIN', 'ACOS', 'ATAN', 'ATAN2', 'DEGREES', 'RADIANS', 'SUMPRODUCT', 'SUMSQ', 'SUBTOTAL',
    'MEDIAN', 'MODE', 'STDEV', 'STDEVP', 'VAR', 'VARP', 'LARGE', 'SMALL', 'RANK', 'PERCENTILE', 'QUARTILE', 'CORREL', 'SLOPE', 'INTERCEPT', 'GEOMEAN',
    'IF', 'IFS', 'IFERROR', 'IFNA', 'AND', 'OR', 'NOT', 'XOR', 'SWITCH', 'TRUE', 'FALSE',
    'COUNTIF', 'SUMIF', 'AVERAGEIF', 'COUNTIFS', 'SUMIFS', 'AVERAGEIFS', 'MAXIFS', 'MINIFS',
    'LEN', 'LEFT', 'RIGHT', 'MID', 'UPPER', 'LOWER', 'PROPER', 'TRIM', 'CLEAN', 'FIND', 'SEARCH', 'SUBSTITUTE', 'REPLACE', 'REPT', 'TEXT', 'VALUE', 'CONCAT', 'CONCATENATE',
    'TEXTJOIN', 'EXACT', 'CHAR', 'CODE', 'UNICHAR', 'UNICODE', 'T', 'N', 'FIXED', 'HYPERLINK',
    'VLOOKUP', 'HLOOKUP', 'LOOKUP', 'XLOOKUP', 'MATCH', 'INDEX', 'CHOOSE', 'ROW', 'COLUMN', 'ROWS', 'COLUMNS', 'INDIRECT',
    'TODAY', 'NOW', 'DATE', 'TIME', 'YEAR', 'MONTH', 'DAY', 'HOUR', 'MINUTE', 'SECOND', 'WEEKDAY', 'WEEKNUM', 'DAYS', 'DATEDIF', 'EDATE', 'EOMONTH', 'NETWORKDAYS', 'DATEVALUE', 'TIMEVALUE',
    'PMT', 'FV', 'PV', 'NPV', 'IRR', 'NPER', 'SLN',
    'ISBLANK', 'ISNUMBER', 'ISTEXT', 'ISLOGICAL', 'ISERROR', 'ISERR', 'ISNA', 'ISEVEN', 'ISODD', 'NA',
  ];
}

class _FormulaError implements Exception {
  final String value;
  const _FormulaError(this.value);
}

/// An error captured while evaluating a function argument (so IFERROR & co. can look at it).
class _Err {
  final String code;
  const _Err(this.code);
}

class _RangeValue {
  final List<dynamic> values;
  final int rows, cols;
  const _RangeValue(this.values, this.rows, this.cols);
  dynamic at(int r, int c) => (r < 0 || c < 0 || r >= rows || c >= cols || r * cols + c >= values.length) ? const _Err('#REF!') : values[r * cols + c];
}

class _FormulaParser {
  final String source;
  final dynamic Function(String) cell;
  final List<dynamic> Function(String, String) range;
  final dynamic Function(String, String)? sheetCell;
  final List<dynamic> Function(String, String, String)? sheetRange;
  final String? Function(String)? nameOf;
  final String currentRef;
  final DateTime now;
  final List<String> tokens = [];
  int at = 0;
  static final _rng = math.Random();

  _FormulaParser(this.source, this.cell, this.range, this.sheetCell, this.sheetRange, this.nameOf, this.currentRef, this.now) {
    _tokenize(source.startsWith('=') ? source.substring(1) : source);
  }

  bool get done => at >= tokens.length;
  String get token => done ? '' : tokens[at];
  bool take(String value) {
    if (token.toUpperCase() != value.toUpperCase()) return false;
    at++;
    return true;
  }

  // ------------------------------------------------------------------ tokenizer
  void _tokenize(String s) {
    var i = 0;
    while (i < s.length) {
      if (s[i].trim().isEmpty) {
        i++;
        continue;
      }
      final rest = s.substring(i);
      final number = RegExp(r'^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?').firstMatch(rest);
      if (number != null) {
        tokens.add(number[0]!);
        i += number[0]!.length;
        continue;
      }
      if (s[i] == '"' || s[i] == "'") {
        final quote = s[i];
        var j = i + 1;
        final b = StringBuffer();
        while (j < s.length) {
          if (s[j] == quote && j + 1 < s.length && s[j + 1] == quote) {
            b.write(quote);
            j += 2;
            continue;
          }
          if (s[j] == quote) break;
          b.write(s[j++]);
        }
        if (j >= s.length) throw const _FormulaError('#VALUE!');
        tokens.add('${quote == '"' ? '\u0001' : '\u0002'}${b.toString()}');
        i = j + 1;
        continue;
      }
      if (s[i] == '#') {
        final e = RegExp(r'^#(?:DIV/0!|VALUE!|REF!|NAME\?|NUM!|N/A|NULL!)').firstMatch(rest);
        if (e != null) {
          tokens.add('\u0003${e[0]}');
          i += e[0]!.length;
          continue;
        }
      }
      final id = RegExp(r'^\$?[\p{L}_][\p{L}\p{N}_.$]*', unicode: true).firstMatch(rest);
      if (id != null) {
        tokens.add(id[0]!);
        i += id[0]!.length;
        continue;
      }
      var op = '';
      for (final candidate in ['<=', '>=', '<>']) {
        if (rest.startsWith(candidate)) {
          op = candidate;
          break;
        }
      }
      if (op.isNotEmpty) {
        tokens.add(op);
        i += op.length;
        continue;
      }
      if ('+-*/^&%=(),:<>!;'.contains(s[i])) {
        tokens.add(s[i] == ';' ? ',' : s[i]);
        i++;
        continue;
      }
      throw const _FormulaError('#VALUE!');
    }
  }

  dynamic parse() {
    if (tokens.isEmpty) return 0;
    return _comparison();
  }

  // ------------------------------------------------------------------ grammar
  dynamic _comparison() {
    var v = _concat();
    while (['=', '<>', '<', '>', '<=', '>='].contains(token)) {
      final op = tokens[at++];
      final b = _concat();
      final cmp = _compare(_scalar(v), _scalar(b));
      v = switch (op) {
        '=' => cmp == 0,
        '<>' => cmp != 0,
        '<' => cmp < 0,
        '>' => cmp > 0,
        '<=' => cmp <= 0,
        '>=' => cmp >= 0,
        _ => false,
      };
    }
    return v;
  }

  dynamic _concat() {
    var v = _add();
    while (take('&')) {
      v = _string(_scalar(v)) + _string(_scalar(_add()));
    }
    return v;
  }

  dynamic _add() {
    var v = _multiply();
    while (token == '+' || token == '-') {
      final op = tokens[at++];
      final b = _multiply();
      v = op == '+' ? _num(_scalar(v)) + _num(_scalar(b)) : _num(_scalar(v)) - _num(_scalar(b));
    }
    return v;
  }

  dynamic _multiply() {
    var v = _power();
    while (token == '*' || token == '/') {
      final op = tokens[at++];
      final b = _power();
      if (op == '/') {
        if (_num(_scalar(b)) == 0) throw const _FormulaError('#DIV/0!');
        v = _num(_scalar(v)) / _num(_scalar(b));
      } else {
        v = _num(_scalar(v)) * _num(_scalar(b));
      }
    }
    return v;
  }

  dynamic _power() {
    var v = _unary();
    while (take('^')) {
      final b = _unary();
      final r = math.pow(_num(_scalar(v)), _num(_scalar(b))).toDouble();
      if (r.isNaN || r.isInfinite) throw const _FormulaError('#NUM!');
      v = r;
    }
    return v;
  }

  dynamic _unary() {
    if (take('+')) return _num(_scalar(_unary()));
    if (take('-')) return -_num(_scalar(_unary()));
    var v = _primary();
    while (take('%')) {
      v = _num(_scalar(v)) / 100;
    }
    return v;
  }

  /// A range used where one value is needed -> its first cell (Excel would use implicit intersection).
  dynamic _scalar(dynamic v) {
    if (v is _RangeValue) return v.values.isEmpty ? '' : v.values.first;
    if (v is _Err) throw _FormulaError(v.code);
    return v;
  }

  dynamic _arg() {
    if (token == ',' || token == ')') return null; // omitted argument
    try {
      return _comparison();
    } on _FormulaError catch (e) {
      return _Err(e.value);
    }
  }

  static bool _isCell(String s) => RegExp(r'^\$?[A-Za-z]{1,3}\$?[1-9]\d{0,6}$').hasMatch(s);

  _RangeValue _makeRange(String? sheet, String a, String b) {
    String clean(String s) => s.replaceAll(r'$', '').toUpperCase();
    final ma = RegExp(r'^([A-Z]+)(\d+)$').firstMatch(clean(a)), mb = RegExp(r'^([A-Z]+)(\d+)$').firstMatch(clean(b));
    if (ma == null || mb == null) throw const _FormulaError('#REF!');
    int ci(String l) {
      var n = 0;
      for (final u in l.codeUnits) {
        n = n * 26 + (u - 64);
      }
      return n - 1;
    }

    String cn(int i) {
      var s = '';
      var n = i + 1;
      while (n > 0) {
        s = String.fromCharCode(65 + (n - 1) % 26) + s;
        n = (n - 1) ~/ 26;
      }
      return s;
    }

    final c1 = math.min(ci(ma[1]!), ci(mb[1]!)), c2 = math.max(ci(ma[1]!), ci(mb[1]!));
    final r1 = math.min(int.parse(ma[2]!), int.parse(mb[2]!)), r2 = math.max(int.parse(ma[2]!), int.parse(mb[2]!));
    final from = '${cn(c1)}$r1', to = '${cn(c2)}$r2';
    final List<dynamic> vals;
    if (sheet == null) {
      vals = range(from, to);
    } else if (sheetRange == null) {
      throw const _FormulaError('#REF!');
    } else {
      vals = sheetRange!(sheet, from, to);
    }
    return _RangeValue(vals, r2 - r1 + 1, c2 - c1 + 1);
  }

  dynamic _refText(String text) {
    // "Sheet1!A1:B3", "A1", "'My sheet'!A1" -> value or range
    var s = text.trim();
    String? sheet;
    final bang = s.lastIndexOf('!');
    if (bang > 0) {
      sheet = s.substring(0, bang);
      if (sheet.startsWith("'") && sheet.endsWith("'") && sheet.length >= 2) sheet = sheet.substring(1, sheet.length - 1).replaceAll("''", "'");
      s = s.substring(bang + 1);
    }
    final parts = s.split(':');
    if (parts.length == 2 && _isCell(parts[0]) && _isCell(parts[1])) return _makeRange(sheet, parts[0], parts[1]);
    if (parts.length == 1 && _isCell(parts[0])) {
      final r = parts[0].replaceAll(r'$', '').toUpperCase();
      if (sheet == null) return cell(r);
      if (sheetCell == null) throw const _FormulaError('#REF!');
      return sheetCell!(sheet, r);
    }
    throw const _FormulaError('#REF!');
  }

  dynamic _primary() {
    if (take('(')) {
      final v = _comparison();
      if (!take(')')) throw const _FormulaError('#VALUE!');
      return v;
    }
    if (done) throw const _FormulaError('#VALUE!');
    var t = tokens[at++];
    if (t.startsWith('\u0001')) return t.substring(1);
    if (t.startsWith('\u0003')) throw _FormulaError(t.substring(1));
    if (RegExp(r'^[\d.]').hasMatch(t)) {
      final n = double.tryParse(t);
      if (n != null) return n;
      throw const _FormulaError('#VALUE!');
    }
    // sheet-qualified reference
    String? sheet;
    if (t.startsWith('\u0002')) {
      sheet = t.substring(1);
      if (!take('!')) throw const _FormulaError('#NAME?');
      t = tokens.length > at ? tokens[at++] : '';
    } else if (token == '!') {
      sheet = t;
      at++;
      t = tokens.length > at ? tokens[at++] : '';
    }
    if (sheet == null && token == '(') {
      at++;
      return _call(t.toUpperCase());
    }
    if (_isCell(t)) {
      if (take(':')) {
        if (done) throw const _FormulaError('#REF!');
        final end = tokens[at++];
        if (!_isCell(end)) throw const _FormulaError('#REF!');
        return _makeRange(sheet, t, end);
      }
      final r = t.replaceAll(r'$', '').toUpperCase();
      final dynamic v;
      if (sheet == null) {
        v = cell(r);
      } else if (sheetCell == null) {
        throw const _FormulaError('#REF!');
      } else {
        v = sheetCell!(sheet, r);
      }
      if (v is String && XlsxFormulaEngine.errors.contains(v)) throw _FormulaError(v);
      return v;
    }
    if (sheet != null) throw const _FormulaError('#REF!');
    switch (t.toUpperCase()) {
      case 'TRUE':
        return true;
      case 'FALSE':
        return false;
      case 'PI':
        return math.pi;
    }
    final nm = nameOf?.call(t);
    if (nm != null) return _refText(nm);
    throw const _FormulaError('#NAME?');
  }

  // ------------------------------------------------------------------ calls
  dynamic _call(String name) {
    if (name == 'ROW' || name == 'COLUMN') {
      if (take(')')) return _rowCol(name, currentRef);
      if (_isCell(token)) {
        final r = tokens[at++];
        if (take(':')) at++;
        if (!take(')')) throw const _FormulaError('#VALUE!');
        return _rowCol(name, r.replaceAll(r'$', '').toUpperCase());
      }
    }
    final args = <dynamic>[];
    if (!take(')')) {
      do {
        args.add(_arg());
      } while (take(','));
      if (!take(')')) throw const _FormulaError('#VALUE!');
    }
    return _function(name, args);
  }

  double _rowCol(String name, String ref) {
    final m = RegExp(r'^([A-Z]+)(\d+)$').firstMatch(ref);
    if (m == null) throw const _FormulaError('#REF!');
    if (name == 'ROW') return double.parse(m[2]!);
    var n = 0;
    for (final u in m[1]!.codeUnits) {
      n = n * 26 + (u - 64);
    }
    return n.toDouble();
  }

  static const _tolerant = {
    'COUNT', 'COUNTA', 'COUNTBLANK', 'IFERROR', 'IFNA', 'ISERROR', 'ISERR', 'ISNA', 'ISNUMBER', 'ISTEXT', 'ISLOGICAL', 'ISBLANK', 'IF', 'IFS', 'CHOOSE', 'SWITCH',
    'COUNTIF', 'COUNTIFS', 'SUMIF', 'SUMIFS', 'AVERAGEIF', 'AVERAGEIFS', 'MAXIFS', 'MINIFS', 'VLOOKUP', 'HLOOKUP', 'LOOKUP', 'XLOOKUP', 'MATCH', 'INDEX', 'AND', 'OR', 'XOR', 'NOT', 'ISEVEN', 'ISODD',
  };

  List<dynamic> _flat(List<dynamic> args) => args.expand((v) => v is _RangeValue ? v.values : [v]).toList();

  /// Numbers of the arguments: from ranges only real numbers, from direct arguments also booleans / numeric text.
  List<double> _nums(List<dynamic> args) {
    final out = <double>[];
    for (final a in args) {
      if (a is _RangeValue) {
        for (final v in a.values) {
          if (v is num) out.add(v.toDouble());
        }
      } else if (a is num) {
        out.add(a.toDouble());
      } else if (a is bool) {
        out.add(a ? 1 : 0);
      } else if (a is String && a.isNotEmpty) {
        final d = double.tryParse(a);
        if (d == null) throw const _FormulaError('#VALUE!');
        out.add(d);
      }
    }
    return out;
  }

  double _a(List<dynamic> args, int i, [double? def]) {
    if (i >= args.length || args[i] == null) {
      if (def != null) return def;
      throw const _FormulaError('#VALUE!');
    }
    return _num(_scalar(args[i]));
  }

  dynamic _s(List<dynamic> args, int i) => i < args.length ? _scalar(args[i]) : null;

  _RangeValue _r(List<dynamic> args, int i) {
    if (i >= args.length) throw const _FormulaError('#VALUE!');
    final v = args[i];
    if (v is _RangeValue) return v;
    if (v is _Err) throw _FormulaError(v.code);
    return _RangeValue([v], 1, 1);
  }

  dynamic _function(String name, List<dynamic> args) {
    if (!_tolerant.contains(name)) {
      for (final v in _flat(args)) {
        if (v is _Err) throw _FormulaError(v.code);
        if (v is String && XlsxFormulaEngine.errors.contains(v)) throw _FormulaError(v);
      }
    }
    double sum(List<double> l) => l.fold<double>(0, (a, b) => a + b);
    switch (name) {
      // ---------------------------------------------------------------- aggregates
      case 'SUM':
        return sum(_nums(args));
      case 'AVERAGE':
        {
          final n = _nums(args);
          if (n.isEmpty) throw const _FormulaError('#DIV/0!');
          return sum(n) / n.length;
        }
      case 'COUNT':
        {
          var c = 0;
          for (final a in args) {
            if (a is _RangeValue) {
              c += a.values.where((v) => v is num).length;
            } else if (a is num || (a is String && double.tryParse(a) != null)) {
              c++;
            }
          }
          return c;
        }
      case 'COUNTA':
        return _flat(args).where((v) => v != null && v is! _Err && v.toString().isNotEmpty).length;
      case 'COUNTBLANK':
        return _flat(args).where((v) => v == null || v.toString().isEmpty).length;
      case 'MAX':
        {
          final n = _nums(args);
          return n.isEmpty ? 0 : n.reduce((a, b) => math.max(a, b));
        }
      case 'MIN':
        {
          final n = _nums(args);
          return n.isEmpty ? 0 : n.reduce((a, b) => math.min(a, b));
        }
      case 'PRODUCT':
        return _nums(args).fold<double>(1, (a, b) => a * b);
      case 'SUMSQ':
        return _nums(args).fold<double>(0, (a, b) => a + b * b);
      case 'MEDIAN':
        {
          final n = _nums(args)..sort();
          if (n.isEmpty) throw const _FormulaError('#NUM!');
          final m = n.length ~/ 2;
          return n.length.isOdd ? n[m] : (n[m - 1] + n[m]) / 2;
        }
      case 'MODE':
        {
          final n = _nums(args);
          final cnt = <double, int>{};
          for (final v in n) {
            cnt[v] = (cnt[v] ?? 0) + 1;
          }
          double? best;
          var bc = 1;
          for (final v in n) {
            if (cnt[v]! > bc) {
              bc = cnt[v]!;
              best = v;
            }
          }
          if (best == null) throw const _FormulaError('#N/A');
          return best;
        }
      case 'GEOMEAN':
        {
          final n = _nums(args);
          if (n.isEmpty || n.any((v) => v <= 0)) throw const _FormulaError('#NUM!');
          return math.exp(n.map(math.log).reduce((a, b) => a + b) / n.length);
        }
      case 'VAR':
      case 'VARP':
      case 'STDEV':
      case 'STDEVP':
        {
          final n = _nums(args);
          final pop = name.endsWith('P');
          if (n.length < (pop ? 1 : 2)) throw const _FormulaError('#DIV/0!');
          final mean = sum(n) / n.length;
          final ss = n.fold<double>(0, (a, b) => a + (b - mean) * (b - mean));
          final v = ss / (pop ? n.length : n.length - 1);
          return name.startsWith('STDEV') ? math.sqrt(v) : v;
        }
      case 'LARGE':
      case 'SMALL':
        {
          final n = _nums([args[0]])..sort();
          final k = _a(args, 1).toInt();
          if (k < 1 || k > n.length) throw const _FormulaError('#NUM!');
          return name == 'LARGE' ? n[n.length - k] : n[k - 1];
        }
      case 'RANK':
        {
          final x = _a(args, 0);
          final n = _nums([args[1]]);
          final asc = args.length > 2 && _a(args, 2) != 0;
          if (!n.contains(x)) throw const _FormulaError('#N/A');
          return n.where((v) => asc ? v < x : v > x).length + 1;
        }
      case 'PERCENTILE':
      case 'QUARTILE':
        {
          final n = _nums([args[0]])..sort();
          if (n.isEmpty) throw const _FormulaError('#NUM!');
          final k = name == 'QUARTILE' ? _a(args, 1) / 4 : _a(args, 1);
          if (k < 0 || k > 1) throw const _FormulaError('#NUM!');
          final pos = k * (n.length - 1);
          final lo = pos.floor(), hi = pos.ceil();
          return n[lo] + (n[hi] - n[lo]) * (pos - lo);
        }
      case 'CORREL':
      case 'SLOPE':
      case 'INTERCEPT':
        {
          final ys = _nums([args[0]]), xs = _nums([args[1]]);
          if (ys.length != xs.length || ys.length < 2) throw const _FormulaError('#N/A');
          final mx = sum(xs) / xs.length, my = sum(ys) / ys.length;
          var sxy = 0.0, sxx = 0.0, syy = 0.0;
          for (var i = 0; i < xs.length; i++) {
            sxy += (xs[i] - mx) * (ys[i] - my);
            sxx += (xs[i] - mx) * (xs[i] - mx);
            syy += (ys[i] - my) * (ys[i] - my);
          }
          if (name == 'CORREL') {
            if (sxx == 0 || syy == 0) throw const _FormulaError('#DIV/0!');
            return sxy / math.sqrt(sxx * syy);
          }
          if (sxx == 0) throw const _FormulaError('#DIV/0!');
          final slope = sxy / sxx;
          return name == 'SLOPE' ? slope : my - slope * mx;
        }
      case 'SUBTOTAL':
        {
          final f = _a(args, 0).toInt() % 100;
          const map = {1: 'AVERAGE', 2: 'COUNT', 3: 'COUNTA', 4: 'MAX', 5: 'MIN', 6: 'PRODUCT', 7: 'STDEV', 8: 'STDEVP', 9: 'SUM', 10: 'VAR', 11: 'VARP'};
          final fn = map[f];
          if (fn == null) throw const _FormulaError('#VALUE!');
          return _function(fn, args.sublist(1));
        }
      case 'SUMPRODUCT':
        {
          final arrs = [for (final a in args) _r([a], 0)];
          final len = arrs.first.values.length;
          if (arrs.any((a) => a.values.length != len)) throw const _FormulaError('#VALUE!');
          var t = 0.0;
          for (var i = 0; i < len; i++) {
            var p = 1.0;
            for (final a in arrs) {
              final v = a.values[i];
              p *= v is num ? v.toDouble() : 0;
            }
            t += p;
          }
          return t;
        }
      // ---------------------------------------------------------------- math
      case 'ROUND':
      case 'ROUNDUP':
      case 'ROUNDDOWN':
        {
          final x = _a(args, 0);
          final f = math.pow(10, _a(args, 1, 0).toInt()).toDouble();
          final y = x * f;
          final r = name == 'ROUND' ? y.roundToDouble() : (name == 'ROUNDUP' ? (y < 0 ? y.floorToDouble() : y.ceilToDouble()) : y.truncateToDouble());
          return r / f;
        }
      case 'INT':
        return _a(args, 0).floorToDouble();
      case 'TRUNC':
        {
          final f = math.pow(10, _a(args, 1, 0).toInt()).toDouble();
          return (_a(args, 0) * f).truncateToDouble() / f;
        }
      case 'CEILING':
      case 'FLOOR':
      case 'MROUND':
        {
          final x = _a(args, 0), s = _a(args, 1, 1);
          if (s == 0) return 0;
          if (name == 'CEILING') return (x / s).ceilToDouble() * s;
          if (name == 'FLOOR') return (x / s).floorToDouble() * s;
          return (x / s).roundToDouble() * s;
        }
      case 'ABS':
        return _a(args, 0).abs();
      case 'SQRT':
        if (_a(args, 0) < 0) throw const _FormulaError('#NUM!');
        return math.sqrt(_a(args, 0));
      case 'POWER':
        {
          final r = math.pow(_a(args, 0), _a(args, 1)).toDouble();
          if (r.isNaN || r.isInfinite) throw const _FormulaError('#NUM!');
          return r;
        }
      case 'MOD':
        {
          final d = _a(args, 1);
          if (d == 0) throw const _FormulaError('#DIV/0!');
          final x = _a(args, 0);
          return x - d * (x / d).floorToDouble();
        }
      case 'QUOTIENT':
        {
          if (_a(args, 1) == 0) throw const _FormulaError('#DIV/0!');
          return (_a(args, 0) / _a(args, 1)).truncateToDouble();
        }
      case 'SIGN':
        return _a(args, 0).sign;
      case 'EXP':
        return math.exp(_a(args, 0));
      case 'LN':
        if (_a(args, 0) <= 0) throw const _FormulaError('#NUM!');
        return math.log(_a(args, 0));
      case 'LOG10':
        if (_a(args, 0) <= 0) throw const _FormulaError('#NUM!');
        return math.log(_a(args, 0)) / math.ln10;
      case 'LOG':
        if (_a(args, 0) <= 0) throw const _FormulaError('#NUM!');
        return math.log(_a(args, 0)) / math.log(_a(args, 1, 10));
      case 'FACT':
        {
          final n = _a(args, 0).floor();
          if (n < 0 || n > 170) throw const _FormulaError('#NUM!');
          var f = 1.0;
          for (var i = 2; i <= n; i++) {
            f *= i;
          }
          return f;
        }
      case 'COMBIN':
      case 'PERMUT':
        {
          final n = _a(args, 0).floor(), k = _a(args, 1).floor();
          if (k < 0 || n < k) throw const _FormulaError('#NUM!');
          var r = 1.0;
          for (var i = 0; i < k; i++) {
            r *= (n - i);
            if (name == 'COMBIN') r /= (i + 1);
          }
          return r.roundToDouble();
        }
      case 'GCD':
      case 'LCM':
        {
          final n = _nums(args).map((v) => v.floor().abs()).toList();
          int g(int a, int b) => b == 0 ? a : g(b, a % b);
          var r = n.first;
          for (final v in n.skip(1)) {
            r = name == 'GCD' ? g(r, v) : (r == 0 || v == 0 ? 0 : r ~/ g(r, v) * v);
          }
          return r.toDouble();
        }
      case 'EVEN':
      case 'ODD':
        {
          final x = _a(args, 0);
          var r = x.abs().ceil();
          if (name == 'EVEN' && r.isOdd) r++;
          if (name == 'ODD' && r.isEven) r++;
          return x < 0 ? -r.toDouble() : r.toDouble();
        }
      case 'PI':
        return math.pi;
      case 'RAND':
        return _rng.nextDouble();
      case 'RANDBETWEEN':
        {
          final lo = _a(args, 0).ceil(), hi = _a(args, 1).floor();
          if (hi < lo) throw const _FormulaError('#NUM!');
          return (lo + _rng.nextInt(hi - lo + 1)).toDouble();
        }
      case 'SIN':
        return math.sin(_a(args, 0));
      case 'COS':
        return math.cos(_a(args, 0));
      case 'TAN':
        return math.tan(_a(args, 0));
      case 'ASIN':
        if (_a(args, 0).abs() > 1) throw const _FormulaError('#NUM!');
        return math.asin(_a(args, 0));
      case 'ACOS':
        if (_a(args, 0).abs() > 1) throw const _FormulaError('#NUM!');
        return math.acos(_a(args, 0));
      case 'ATAN':
        return math.atan(_a(args, 0));
      case 'ATAN2':
        return math.atan2(_a(args, 1), _a(args, 0));
      case 'DEGREES':
        return _a(args, 0) * 180 / math.pi;
      case 'RADIANS':
        return _a(args, 0) * math.pi / 180;
      // ---------------------------------------------------------------- logical
      case 'IF':
        {
          if (args.isEmpty) throw const _FormulaError('#VALUE!');
          final c = args[0];
          if (c is _Err) throw _FormulaError(c.code);
          final pick = _truth(_scalar(c)) ? (args.length > 1 ? args[1] : true) : (args.length > 2 ? args[2] : false);
          if (pick is _Err) throw _FormulaError(pick.code);
          return pick ?? 0;
        }
      case 'IFS':
        {
          for (var i = 0; i + 1 < args.length; i += 2) {
            if (args[i] is _Err) throw _FormulaError((args[i] as _Err).code);
            if (_truth(_scalar(args[i]))) {
              if (args[i + 1] is _Err) throw _FormulaError((args[i + 1] as _Err).code);
              return args[i + 1];
            }
          }
          throw const _FormulaError('#N/A');
        }
      case 'IFERROR':
        {
          final v = args.isEmpty ? null : args[0];
          final bad = v is _Err || (v is String && XlsxFormulaEngine.errors.contains(v));
          return bad ? (args.length > 1 ? args[1] : '') : v;
        }
      case 'IFNA':
        {
          final v = args.isEmpty ? null : args[0];
          final bad = (v is _Err && v.code == '#N/A') || v == '#N/A';
          return bad ? (args.length > 1 ? args[1] : '') : v;
        }
      case 'AND':
      case 'OR':
      case 'XOR':
        {
          final vals = _flat(args).where((v) => v != null && v.toString().isNotEmpty).toList();
          for (final v in vals) {
            if (v is _Err) throw _FormulaError(v.code);
          }
          final b = vals.map(_truth).toList();
          if (b.isEmpty) throw const _FormulaError('#VALUE!');
          if (name == 'AND') return b.every((x) => x);
          if (name == 'OR') return b.any((x) => x);
          return b.where((x) => x).length.isOdd;
        }
      case 'NOT':
        return !_truth(_s(args, 0));
      case 'TRUE':
        return true;
      case 'FALSE':
        return false;
      case 'SWITCH':
        {
          final v = _s(args, 0);
          for (var i = 1; i + 1 < args.length; i += 2) {
            if (_compare(v, _scalar(args[i])) == 0) return args[i + 1];
          }
          if (args.length.isEven) return args.last;
          throw const _FormulaError('#N/A');
        }
      // ---------------------------------------------------------------- info
      case 'ISBLANK':
        {
          final v = args.isEmpty ? null : _scalarSoft(args[0]);
          return v == null || v == '';
        }
      case 'ISNUMBER':
        return _scalarSoft(args.first) is num;
      case 'ISTEXT':
        {
          final v = _scalarSoft(args.first);
          return v is String && v.isNotEmpty && !XlsxFormulaEngine.errors.contains(v);
        }
      case 'ISLOGICAL':
        return _scalarSoft(args.first) is bool;
      case 'ISERROR':
      case 'ISERR':
      case 'ISNA':
        {
          final v = _scalarSoft(args.first);
          final code = v is _Err ? v.code : (v is String && XlsxFormulaEngine.errors.contains(v) ? v : null);
          if (code == null) return false;
          if (name == 'ISNA') return code == '#N/A';
          if (name == 'ISERR') return code != '#N/A';
          return true;
        }
      case 'ISEVEN':
        return _a(args, 0).floor().isEven;
      case 'ISODD':
        return _a(args, 0).floor().isOdd;
      case 'NA':
        throw const _FormulaError('#N/A');
      // ---------------------------------------------------------------- conditional aggregates
      case 'COUNTIF':
        {
          final rg = _r(args, 0);
          return rg.values.where((v) => _criteria(v, _s(args, 1))).length;
        }
      case 'SUMIF':
      case 'AVERAGEIF':
        {
          final rg = _r(args, 0);
          final vals = args.length > 2 ? _r(args, 2).values : rg.values;
          var total = 0.0, cnt = 0;
          for (var i = 0; i < rg.values.length && i < vals.length; i++) {
            if (_criteria(rg.values[i], _s(args, 1))) {
              final v = vals[i];
              if (v is num) {
                total += v;
                cnt++;
              }
            }
          }
          if (name == 'AVERAGEIF') {
            if (cnt == 0) throw const _FormulaError('#DIV/0!');
            return total / cnt;
          }
          return total;
        }
      case 'COUNTIFS':
        return _ifs(args, 0).length;
      case 'SUMIFS':
      case 'AVERAGEIFS':
      case 'MAXIFS':
      case 'MINIFS':
        {
          final target = _r(args, 0).values;
          final idx = _ifs(args, 1);
          final v = <double>[for (final i in idx) if (i < target.length && target[i] is num) (target[i] as num).toDouble()];
          if (name == 'SUMIFS') return sum(v);
          if (name == 'AVERAGEIFS') {
            if (v.isEmpty) throw const _FormulaError('#DIV/0!');
            return sum(v) / v.length;
          }
          if (v.isEmpty) return 0;
          return name == 'MAXIFS' ? v.reduce((a, b) => math.max(a, b)) : v.reduce((a, b) => math.min(a, b));
        }
      // ---------------------------------------------------------------- text
      case 'LEN':
        return _string(_s(args, 0)).length;
      case 'LEFT':
        {
          final s = _string(_s(args, 0));
          final n = _a(args, 1, 1).toInt();
          if (n < 0) throw const _FormulaError('#VALUE!');
          return s.substring(0, math.min(n, s.length));
        }
      case 'RIGHT':
        {
          final s = _string(_s(args, 0));
          final n = _a(args, 1, 1).toInt();
          if (n < 0) throw const _FormulaError('#VALUE!');
          return s.substring(s.length - math.min(n, s.length));
        }
      case 'MID':
        {
          final s = _string(_s(args, 0));
          final start = _a(args, 1).toInt() - 1, len = _a(args, 2).toInt();
          if (start < 0 || len < 0) throw const _FormulaError('#VALUE!');
          if (start >= s.length) return '';
          return s.substring(start, math.min(s.length, start + len));
        }
      case 'UPPER':
        return _string(_s(args, 0)).toUpperCase();
      case 'LOWER':
        return _string(_s(args, 0)).toLowerCase();
      case 'PROPER':
        return _string(_s(args, 0)).toLowerCase().replaceAllMapped(RegExp(r'(^|[^\p{L}])(\p{L})', unicode: true), (m) => '${m[1]}${m[2]!.toUpperCase()}');
      case 'TRIM':
        return _string(_s(args, 0)).trim().replaceAll(RegExp(r' +'), ' ');
      case 'CLEAN':
        return _string(_s(args, 0)).replaceAll(RegExp(r'[\x00-\x1F]'), '');
      case 'FIND':
      case 'SEARCH':
        {
          final hay = _string(_s(args, 1)), needle = _string(_s(args, 0));
          final start = _a(args, 2, 1).toInt() - 1;
          if (start < 0 || start > hay.length) throw const _FormulaError('#VALUE!');
          int i;
          if (name == 'SEARCH') {
            final re = RegExp(RegExp.escape(needle.toLowerCase()).replaceAll(r'\*', '.*').replaceAll(r'\?', '.'));
            final m = re.firstMatch(hay.toLowerCase().substring(start));
            i = m == null ? -1 : m.start + start;
          } else {
            i = hay.indexOf(needle, start);
          }
          if (i < 0) throw const _FormulaError('#VALUE!');
          return (i + 1).toDouble();
        }
      case 'SUBSTITUTE':
        {
          final s = _string(_s(args, 0)), o = _string(_s(args, 1)), n = _string(_s(args, 2));
          if (o.isEmpty) return s;
          if (args.length > 3 && args[3] != null) {
            final k = _a(args, 3).toInt();
            var idx = -1, from = 0;
            for (var i = 0; i < k; i++) {
              idx = s.indexOf(o, from);
              if (idx < 0) return s;
              from = idx + o.length;
            }
            return s.replaceRange(idx, idx + o.length, n);
          }
          return s.replaceAll(o, n);
        }
      case 'REPLACE':
        {
          final s = _string(_s(args, 0));
          final st = _a(args, 1).toInt() - 1, len = _a(args, 2).toInt();
          if (st < 0 || len < 0) throw const _FormulaError('#VALUE!');
          final a = math.min(st, s.length), b = math.min(s.length, st + len);
          return s.replaceRange(a, b, _string(_s(args, 3)));
        }
      case 'REPT':
        {
          final n = _a(args, 1).toInt();
          if (n < 0 || n > 10000) throw const _FormulaError('#VALUE!');
          return _string(_s(args, 0)) * n;
        }
      case 'TEXT':
        return XNumFmt.format(_s(args, 0), _string(_s(args, 1)));
      case 'VALUE':
        {
          final v = _s(args, 0);
          if (v is num) return v.toDouble();
          var s = _string(v).trim().replaceAll(',', '');
          var pct = false;
          if (s.endsWith('%')) {
            pct = true;
            s = s.substring(0, s.length - 1);
          }
          final d = double.tryParse(s);
          if (d == null) throw const _FormulaError('#VALUE!');
          return pct ? d / 100 : d;
        }
      case 'CONCAT':
      case 'CONCATENATE':
        return _flat(args).map(_string).join();
      case 'TEXTJOIN':
        {
          final sep = _string(_s(args, 0));
          final skip = _truth(_s(args, 1));
          final items = _flat(args.sublist(2)).map(_string).where((s) => !skip || s.isNotEmpty);
          return items.join(sep);
        }
      case 'EXACT':
        return _string(_s(args, 0)) == _string(_s(args, 1));
      case 'CHAR':
      case 'UNICHAR':
        return String.fromCharCode(_a(args, 0).toInt());
      case 'CODE':
      case 'UNICODE':
        {
          final s = _string(_s(args, 0));
          if (s.isEmpty) throw const _FormulaError('#VALUE!');
          return s.runes.first.toDouble();
        }
      case 'T':
        {
          final v = _s(args, 0);
          return v is String ? v : '';
        }
      case 'N':
        {
          final v = _s(args, 0);
          return v is num ? v.toDouble() : (v is bool ? (v ? 1.0 : 0.0) : 0.0);
        }
      case 'FIXED':
        {
          final d = _a(args, 1, 2).toInt().clamp(0, 15).toInt();
          final noCommas = args.length > 2 && _truth(_s(args, 2));
          return XNumFmt.format(_a(args, 0), '${noCommas ? '0' : '#,##0'}${d > 0 ? '.${'0' * d}' : ''}');
        }
      case 'HYPERLINK':
        return args.length > 1 && args[1] != null ? _scalar(args[1]) : _scalar(args[0]);
      // ---------------------------------------------------------------- lookup
      case 'VLOOKUP':
      case 'HLOOKUP':
        {
          final key = _s(args, 0);
          final tb = _r(args, 1);
          final idx = _a(args, 2).toInt() - 1;
          final approx = args.length < 4 || args[3] == null || _truth(_scalar(args[3]));
          final vertical = name == 'VLOOKUP';
          final n = vertical ? tb.rows : tb.cols;
          final span = vertical ? tb.cols : tb.rows;
          if (idx < 0 || idx >= span) throw const _FormulaError('#REF!');
          dynamic keyAt(int i) => vertical ? tb.at(i, 0) : tb.at(0, i);
          var found = -1;
          if (approx) {
            for (var i = 0; i < n; i++) {
              if (_compare(keyAt(i), key) <= 0) {
                found = i;
              } else {
                break;
              }
            }
          } else {
            for (var i = 0; i < n; i++) {
              if (_looseEq(keyAt(i), key)) {
                found = i;
                break;
              }
            }
          }
          if (found < 0) throw const _FormulaError('#N/A');
          final v = vertical ? tb.at(found, idx) : tb.at(idx, found);
          if (v is _Err) throw _FormulaError(v.code);
          return v;
        }
      case 'LOOKUP':
        {
          final key = _s(args, 0);
          final lv = _r(args, 1).values;
          final rv = args.length > 2 ? _r(args, 2).values : lv;
          var found = -1;
          for (var i = 0; i < lv.length; i++) {
            if (_compare(lv[i], key) <= 0) {
              found = i;
            } else {
              break;
            }
          }
          if (found < 0 || found >= rv.length) throw const _FormulaError('#N/A');
          return rv[found];
        }
      case 'XLOOKUP':
        {
          final key = _s(args, 0);
          final lv = _r(args, 1).values, rv = _r(args, 2).values;
          for (var i = 0; i < lv.length && i < rv.length; i++) {
            if (_looseEq(lv[i], key)) return rv[i];
          }
          if (args.length > 3 && args[3] != null) return _scalar(args[3]);
          throw const _FormulaError('#N/A');
        }
      case 'MATCH':
        {
          final key = _s(args, 0);
          final vals = _r(args, 1).values;
          final type = _a(args, 2, 1).toInt();
          if (type == 0) {
            for (var i = 0; i < vals.length; i++) {
              if (_looseEq(vals[i], key)) return (i + 1).toDouble();
            }
            throw const _FormulaError('#N/A');
          }
          var found = -1;
          for (var i = 0; i < vals.length; i++) {
            final c = _compare(vals[i], key);
            if (type > 0 ? c <= 0 : c >= 0) {
              found = i;
            } else {
              break;
            }
          }
          if (found < 0) throw const _FormulaError('#N/A');
          return (found + 1).toDouble();
        }
      case 'INDEX':
        {
          final rg = _r(args, 0);
          var r = _a(args, 1, 0).toInt(), c = _a(args, 2, 0).toInt();
          if (rg.rows == 1 && args.length == 2) {
            c = r;
            r = 1;
          }
          if (r == 0) r = 1;
          if (c == 0) c = 1;
          final v = rg.at(r - 1, c - 1);
          if (v is _Err) throw _FormulaError(v.code);
          return v;
        }
      case 'CHOOSE':
        {
          final i = _a(args, 0).toInt();
          if (i < 1 || i >= args.length) throw const _FormulaError('#VALUE!');
          final v = args[i];
          if (v is _Err) throw _FormulaError(v.code);
          return v;
        }
      case 'ROWS':
        return _r(args, 0).rows;
      case 'COLUMNS':
        return _r(args, 0).cols;
      case 'INDIRECT':
        return _refText(_string(_s(args, 0)));
      // ---------------------------------------------------------------- date / time
      case 'TODAY':
        return XNumFmt.toSerial(DateTime(now.year, now.month, now.day)).floorToDouble();
      case 'NOW':
        return XNumFmt.toSerial(now);
      case 'DATE':
        {
          var y = _a(args, 0).toInt();
          final m = _a(args, 1).toInt(), d = _a(args, 2).toInt();
          if (y >= 0 && y < 1900) y += 1900;
          return XNumFmt.toSerial(DateTime.utc(y, m, d));
        }
      case 'TIME':
        return (_a(args, 0) * 3600 + _a(args, 1) * 60 + _a(args, 2)) / 86400;
      case 'YEAR':
        return XNumFmt.fromSerial(_dateArg(args, 0)).year.toDouble();
      case 'MONTH':
        return XNumFmt.fromSerial(_dateArg(args, 0)).month.toDouble();
      case 'DAY':
        return XNumFmt.fromSerial(_dateArg(args, 0)).day.toDouble();
      case 'HOUR':
        return XNumFmt.fromSerial(_dateArg(args, 0)).hour.toDouble();
      case 'MINUTE':
        return XNumFmt.fromSerial(_dateArg(args, 0)).minute.toDouble();
      case 'SECOND':
        return XNumFmt.fromSerial(_dateArg(args, 0)).second.toDouble();
      case 'WEEKDAY':
        {
          final wd = XNumFmt.fromSerial(_dateArg(args, 0)).weekday; // Mon=1..Sun=7
          final type = _a(args, 1, 1).toInt();
          if (type == 2) return wd.toDouble();
          if (type == 3) return (wd - 1).toDouble();
          return (wd % 7 + 1).toDouble();
        }
      case 'WEEKNUM':
        {
          final d = XNumFmt.fromSerial(_dateArg(args, 0));
          final jan1 = DateTime.utc(d.year, 1, 1);
          final off = jan1.weekday % 7;
          return ((d.difference(jan1).inDays + off) ~/ 7 + 1).toDouble();
        }
      case 'DAYS':
        return (_dateArg(args, 0).floor() - _dateArg(args, 1).floor()).toDouble();
      case 'DATEDIF':
        {
          final a = XNumFmt.fromSerial(_dateArg(args, 0)), b = XNumFmt.fromSerial(_dateArg(args, 1));
          final u = _string(_s(args, 2)).toUpperCase();
          if (b.isBefore(a)) throw const _FormulaError('#NUM!');
          var months = (b.year - a.year) * 12 + b.month - a.month;
          if (b.day < a.day) months--;
          switch (u) {
            case 'D':
              return b.difference(a).inDays.toDouble();
            case 'M':
              return months.toDouble();
            case 'Y':
              return (months ~/ 12).toDouble();
            case 'MD':
              return (b.day >= a.day ? b.day - a.day : DateTime.utc(b.year, b.month, 0).day - a.day + b.day).toDouble();
            case 'YM':
              return (months % 12).toDouble();
            case 'YD':
              {
                var y = DateTime.utc(b.year, a.month, a.day);
                if (y.isAfter(b)) y = DateTime.utc(b.year - 1, a.month, a.day);
                return b.difference(y).inDays.toDouble();
              }
          }
          throw const _FormulaError('#NUM!');
        }
      case 'EDATE':
      case 'EOMONTH':
        {
          final d = XNumFmt.fromSerial(_dateArg(args, 0));
          final k = _a(args, 1).toInt();
          final total = d.year * 12 + d.month - 1 + k;
          final y = total ~/ 12, m = total % 12 + 1;
          if (name == 'EOMONTH') return XNumFmt.toSerial(DateTime.utc(y, m + 1, 0));
          final last = DateTime.utc(y, m + 1, 0).day;
          return XNumFmt.toSerial(DateTime.utc(y, m, math.min(d.day, last)));
        }
      case 'NETWORKDAYS':
        {
          var a = _dateArg(args, 0).floor(), b = _dateArg(args, 1).floor();
          final sign = a <= b ? 1 : -1;
          if (a > b) {
            final t = a;
            a = b;
            b = t;
          }
          var c = 0;
          for (var s = a; s <= b; s++) {
            final wd = XNumFmt.fromSerial(s.toDouble()).weekday;
            if (wd < 6) c++;
          }
          return (c * sign).toDouble();
        }
      case 'DATEVALUE':
      case 'TIMEVALUE':
        {
          final d = _parseDate(_string(_s(args, 0)));
          if (d == null) throw const _FormulaError('#VALUE!');
          final s = XNumFmt.toSerial(d);
          return name == 'DATEVALUE' ? s.floorToDouble() : s - s.floorToDouble();
        }
      // ---------------------------------------------------------------- financial
      case 'PMT':
        {
          final r = _a(args, 0), n = _a(args, 1), pv = _a(args, 2), fv = _a(args, 3, 0), type = _a(args, 4, 0);
          if (n == 0) throw const _FormulaError('#NUM!');
          if (r == 0) return -(pv + fv) / n;
          final f = math.pow(1 + r, n).toDouble();
          return -(pv * f + fv) * r / ((f - 1) * (1 + r * type));
        }
      case 'FV':
        {
          final r = _a(args, 0), n = _a(args, 1), pmt = _a(args, 2), pv = _a(args, 3, 0), type = _a(args, 4, 0);
          if (r == 0) return -(pv + pmt * n);
          final f = math.pow(1 + r, n).toDouble();
          return -(pv * f + pmt * (1 + r * type) * (f - 1) / r);
        }
      case 'PV':
        {
          final r = _a(args, 0), n = _a(args, 1), pmt = _a(args, 2), fv = _a(args, 3, 0), type = _a(args, 4, 0);
          if (r == 0) return -(fv + pmt * n);
          final f = math.pow(1 + r, n).toDouble();
          return -(fv + pmt * (1 + r * type) * (f - 1) / r) / f;
        }
      case 'NPER':
        {
          final r = _a(args, 0), pmt = _a(args, 1), pv = _a(args, 2), fv = _a(args, 3, 0), type = _a(args, 4, 0);
          if (r == 0) return -(pv + fv) / pmt;
          final k = pmt * (1 + r * type);
          final v = (k - fv * r) / (k + pv * r);
          if (v <= 0) throw const _FormulaError('#NUM!');
          return math.log(v) / math.log(1 + r);
        }
      case 'NPV':
        {
          final r = _a(args, 0);
          final flows = _nums(args.sublist(1));
          var t = 0.0;
          for (var i = 0; i < flows.length; i++) {
            t += flows[i] / math.pow(1 + r, i + 1);
          }
          return t;
        }
      case 'IRR':
        {
          final cf = _nums([args[0]]);
          if (cf.length < 2 || !cf.any((v) => v > 0) || !cf.any((v) => v < 0)) throw const _FormulaError('#NUM!');
          var rate = args.length > 1 ? _a(args, 1) : 0.1;
          for (var it = 0; it < 100; it++) {
            var f = 0.0, df = 0.0;
            for (var i = 0; i < cf.length; i++) {
              f += cf[i] / math.pow(1 + rate, i);
              df -= i * cf[i] / math.pow(1 + rate, i + 1);
            }
            if (df == 0) break;
            final next = rate - f / df;
            if ((next - rate).abs() < 1e-10) return next;
            rate = next;
          }
          throw const _FormulaError('#NUM!');
        }
      case 'SLN':
        {
          final life = _a(args, 2);
          if (life == 0) throw const _FormulaError('#DIV/0!');
          return (_a(args, 0) - _a(args, 1)) / life;
        }
      default:
        throw const _FormulaError('#NAME?');
    }
  }

  dynamic _scalarSoft(dynamic v) {
    if (v is _RangeValue) return v.values.isEmpty ? '' : v.values.first;
    return v;
  }

  double _dateArg(List<dynamic> args, int i) {
    final v = _s(args, i);
    if (v is num) return v.toDouble();
    final d = _parseDate(_string(v));
    if (d == null) throw const _FormulaError('#VALUE!');
    return XNumFmt.toSerial(d);
  }

  static DateTime? _parseDate(String s) {
    final m = RegExp(r'^\s*(\d{4})[-/](\d{1,2})[-/](\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?\s*$').firstMatch(s);
    if (m != null) return DateTime.utc(int.parse(m[1]!), int.parse(m[2]!), int.parse(m[3]!), int.parse(m[4] ?? '0'), int.parse(m[5] ?? '0'), int.parse(m[6] ?? '0'));
    final t = RegExp(r'^\s*(\d{1,2}):(\d{2})(?::(\d{2}))?\s*$').firstMatch(s);
    if (t != null) return DateTime.utc(1899, 12, 30, int.parse(t[1]!), int.parse(t[2]!), int.parse(t[3] ?? '0'));
    return null;
  }

  /// Indexes matching every (range, criteria) pair starting at args[from].
  List<int> _ifs(List<dynamic> args, int from) {
    if ((args.length - from) < 2 || (args.length - from).isOdd) throw const _FormulaError('#VALUE!');
    List<int>? ok;
    for (var i = from; i + 1 < args.length; i += 2) {
      final rg = _r(args, i).values;
      final crit = _scalar(args[i + 1]);
      final hit = <int>[for (var k = 0; k < rg.length; k++) if (_criteria(rg[k], crit)) k];
      ok = ok == null ? hit : ok.where(hit.contains).toList();
    }
    return ok ?? const [];
  }

  // ------------------------------------------------------------------ value helpers
  static bool _criteria(dynamic v, dynamic criteria) {
    final s = _string(criteria);
    final m = RegExp(r'^(>=|<=|<>|>|<|=)?(.*)$', dotAll: true).firstMatch(s)!;
    final op = m.group(1) ?? '=';
    final c = m.group(2)!;
    final rhsNum = criteria is num ? criteria.toDouble() : double.tryParse(c);
    if (rhsNum != null) {
      final ln = v is num ? v.toDouble() : null;
      if (ln == null) return op == '<>';
      final cmp = ln.compareTo(rhsNum);
      return switch (op) { '>' => cmp > 0, '<' => cmp < 0, '>=' => cmp >= 0, '<=' => cmp <= 0, '<>' => cmp != 0, _ => cmp == 0 };
    }
    final text = _string(v);
    if ((op == '=' || op == '<>') && (c.contains('*') || c.contains('?'))) {
      final re = RegExp('^${RegExp.escape(c).replaceAll(r'\*', '.*').replaceAll(r'\?', '.')}\$', caseSensitive: false);
      final hit = re.hasMatch(text);
      return op == '=' ? hit : !hit;
    }
    if (c.isEmpty) {
      final blank = v == null || (v is String && v.isEmpty);
      return op == '<>' ? !blank : blank;
    }
    if (v is num) return op == '<>';
    final cmp = text.toLowerCase().compareTo(c.toLowerCase());
    return switch (op) { '>' => cmp > 0, '<' => cmp < 0, '>=' => cmp >= 0, '<=' => cmp <= 0, '<>' => cmp != 0, _ => cmp == 0 };
  }

  static double _num(dynamic v) {
    if (v is num) return v.toDouble();
    if (v is bool) return v ? 1 : 0;
    if (v == null || v == '') return 0;
    if (v is _Err) throw _FormulaError(v.code);
    final n = double.tryParse(v.toString());
    if (n == null) throw const _FormulaError('#VALUE!');
    return n;
  }

  static String _string(dynamic v) {
    if (v == null) return '';
    if (v is bool) return v ? 'TRUE' : 'FALSE';
    if (v is num) return XNumFmt.general(v);
    return '$v';
  }

  static bool _truth(dynamic v) {
    if (v is bool) return v;
    if (v is num) return v != 0;
    if (v == null) return false;
    final s = v.toString();
    if (s.toUpperCase() == 'TRUE') return true;
    if (s.toUpperCase() == 'FALSE' || s.isEmpty) return false;
    final d = double.tryParse(s);
    if (d != null) return d != 0;
    throw const _FormulaError('#VALUE!');
  }

  static bool _looseEq(dynamic a, dynamic b) {
    if (a is num && b is num) return a == b;
    return _string(a).toLowerCase() == _string(b).toLowerCase();
  }

  static int _compare(dynamic a, dynamic b) {
    final an = a is num ? a.toDouble() : null, bn = b is num ? b.toDouble() : null;
    if (an != null && bn != null) return an.compareTo(bn);
    final aBlank = a == null || (a is String && a.isEmpty), bBlank = b == null || (b is String && b.isEmpty);
    if (an != null && bBlank) return an.compareTo(0);
    if (bn != null && aBlank) return 0.0.compareTo(bn);
    if (an != null && b is String) return -1; // numbers sort before text
    if (bn != null && a is String) return 1;
    return _string(a).toLowerCase().compareTo(_string(b).toLowerCase());
  }
}
