part of 'office_service.dart';

/// Cached statistics for conditional formatting (cleared by the screen after every edit).
class XCondCache {
  final dup = <XCond, Map<String, int>>{};
  final span = <XCond, (double, double, double)>{};
  void clear() {
    dup.clear();
    span.clear();
  }
}

final xCondCache = XCondCache();

const xChartTypes = <String>['col', 'bar', 'line', 'area', 'pie', 'doughnut'];
const xChartColors = <int>[0x4472C4, 0xED7D31, 0xA5A5A5, 0xFFC000, 0x5B9BD5, 0x70AD47, 0x264478, 0x9E480E];

extension XlsxObjects on XlsxFile {
  // ==================================================================================================
  // Sheets
  // ==================================================================================================
  String _quoteSheet(String n) => RegExp(r'^[A-Za-z_][A-Za-z0-9_.]*$').hasMatch(n) ? n : "'${n.replaceAll("'", "''")}'";

  /// Returns null on success, otherwise 'invalid' / 'exists'.
  String? renameSheet(XSheet sh, String name) {
    name = name.trim();
    if (name.isEmpty || name.length > 31 || RegExp(r'[\[\]:*?/\\]').hasMatch(name) || name.startsWith("'") || name.endsWith("'")) return 'invalid';
    if (sheets.any((s) => s != sh && s.name.toLowerCase() == name.toLowerCase())) return 'exists';
    final old = sh.name;
    if (old == name) return null;
    final wb = z.xml('xl/workbook.xml')!;
    for (final e in wb.findAllElements('sheet', namespace: '*')) {
      if (e.getAttribute('name') == old) e.setAttribute('name', name);
    }
    final re = RegExp("(?<![A-Za-z0-9_.])(?:'${RegExp.escape(old.replaceAll("'", "''"))}'|${RegExp.escape(old)})!");
    final to = '${_quoteSheet(name)}!';
    String fix(String f) {
      final parts = f.split('"');
      for (var i = 0; i < parts.length; i += 2) {
        parts[i] = parts[i].replaceAll(re, to);
      }
      return parts.join('"');
    }

    for (final o in sheets) {
      for (final ref in o.formulas.keys.toList()) {
        final nf = fix(o.formulas[ref]!);
        if (nf != o.formulas[ref]) {
          o.formulas[ref] = nf;
          final fe = _child(_cellEl(o, ref), 'f');
          fe?.children
            ?..clear()
            ..add(XmlText(nf));
          z.touch(o.part);
        }
      }
      for (final ch in o.charts) {
        final doc = z.xml(ch.part);
        if (doc == null) continue;
        for (final f in doc.findAllElements('f', namespace: '*')) {
          final nf = fix(f.innerText);
          if (nf != f.innerText) {
            f.children
              ..clear()
              ..add(XmlText(nf));
            z.touch(ch.part);
          }
        }
        for (final s in ch.series) {
          s.nameRef = s.nameRef == null ? null : fix(s.nameRef!);
          s.catRef = s.catRef == null ? null : fix(s.catRef!);
          s.valRef = s.valRef == null ? null : fix(s.valRef!);
        }
      }
    }
    for (final e in wb.findAllElements('definedName', namespace: '*')) {
      final nf = fix(e.innerText);
      if (nf != e.innerText) {
        e.children
          ..clear()
          ..add(XmlText(nf));
        definedNames[e.getAttribute('name') ?? ''] = nf;
      }
    }
    sh.name = name;
    z.touch('xl/workbook.xml');
    recalculateAll();
    return null;
  }

  bool deleteSheet(XSheet sh) {
    if (sheets.length <= 1 || sheets.where((s) => !s.hidden).length <= (sh.hidden ? 0 : 1)) return false;
    final idx = sheets.indexOf(sh);
    final wb = z.xml('xl/workbook.xml')!;
    String? rid;
    for (final e in wb.findAllElements('sheet', namespace: '*').toList()) {
      if (e.getAttribute('name') == sh.name) {
        for (final a in e.attributes) {
          if (a.name.local == 'id') rid = a.value;
        }
        e.parent!.children.remove(e);
      }
    }
    final rl = z.xml('xl/_rels/workbook.xml.rels');
    if (rl != null && rid != null) {
      for (final r in rl.findAllElements('Relationship', namespace: '*').toList()) {
        if (r.getAttribute('Id') == rid) r.parent!.children.remove(r);
      }
      z.touch('xl/_rels/workbook.xml.rels');
    }
    // charts / drawings of the sheet
    final drawings = <String>{};
    for (final ch in sh.charts) {
      z.drop.add(ch.part);
      z.removeOverride(ch.part);
      final cr = '${p.posix.dirname(ch.part)}/_rels/${p.posix.basename(ch.part)}.rels';
      z.drop.add(cr);
      drawings.add(ch.drawingPart);
    }
    for (final d in drawings) {
      z.drop.add(d);
      z.removeOverride(d);
      z.drop.add('${p.posix.dirname(d)}/_rels/${p.posix.basename(d)}.rels');
    }
    z.drop.add(sh.part);
    z.removeOverride(sh.part);
    z.drop.add('${p.posix.dirname(sh.part)}/_rels/${p.posix.basename(sh.part)}.rels');
    // defined names scoped to sheets
    for (final e in wb.findAllElements('definedName', namespace: '*').toList()) {
      final ls = int.tryParse(e.getAttribute('localSheetId') ?? '');
      if (ls == null) continue;
      if (ls == idx) {
        e.parent!.children.remove(e);
      } else if (ls > idx) {
        e.setAttribute('localSheetId', '${ls - 1}');
      }
    }
    for (final v in wb.findAllElements('workbookView', namespace: '*')) {
      v.setAttribute('activeTab', '0');
      v.removeAttribute('firstSheet');
    }
    z.touch('xl/workbook.xml');
    sheets.removeAt(idx);
    recalculateAll();
    return true;
  }

  XSheet duplicateSheet(XSheet sh) {
    var name = '${sh.name} (2)';
    var i = 2;
    while (sheets.any((s) => s.name == name) || name.length > 31) {
      i++;
      final base = sh.name.length > 26 ? sh.name.substring(0, 26) : sh.name;
      name = '$base ($i)';
    }
    final doc = XmlDocument.parse(sh.doc.toXmlString());
    final root = doc.rootElement;
    for (final n in ['drawing', 'legacyDrawing', 'legacyDrawingHF', 'tableParts', 'hyperlinks', 'picture', 'oleObjects', 'controls']) {
      root.children.removeWhere((e) => e is XmlElement && e.name.local == n);
    }
    for (final v in root.findAllElements('sheetView', namespace: '*')) {
      v.removeAttribute('tabSelected');
    }
    final copy = _registerSheet(name, doc.toXmlString());
    copy.tabColor = sh.tabColor;
    return copy;
  }

  void moveSheet(XSheet sh, int delta) {
    final i = sheets.indexOf(sh), j = i + delta;
    if (i < 0 || j < 0 || j >= sheets.length) return;
    final wb = z.xml('xl/workbook.xml')!;
    final se = wb.findAllElements('sheets', namespace: '*').first;
    final els = se.findElements('sheet', namespace: '*').toList();
    final a = els[i], b = els[j];
    final ai = se.children.indexOf(a), bi = se.children.indexOf(b);
    se.children[ai] = b.copy();
    se.children[bi] = a.copy();
    for (final e in wb.findAllElements('definedName', namespace: '*')) {
      final ls = int.tryParse(e.getAttribute('localSheetId') ?? '');
      if (ls == i) {
        e.setAttribute('localSheetId', '$j');
      } else if (ls == j) {
        e.setAttribute('localSheetId', '$i');
      }
    }
    final t = sheets[i];
    sheets[i] = sheets[j];
    sheets[j] = t;
    z.touch('xl/workbook.xml');
  }

  bool setSheetHidden(XSheet sh, bool hidden) {
    if (hidden && sheets.where((s) => !s.hidden && s != sh).isEmpty) return false;
    final wb = z.xml('xl/workbook.xml')!;
    for (final e in wb.findAllElements('sheet', namespace: '*')) {
      if (e.getAttribute('name') == sh.name) {
        if (hidden) {
          e.setAttribute('state', 'hidden');
        } else {
          e.removeAttribute('state');
        }
      }
    }
    sh.hidden = hidden;
    z.touch('xl/workbook.xml');
    return true;
  }

  void setTabColor(XSheet sh, int? rgb) {
    final root = sh.doc.rootElement;
    var pr = _child(root, 'sheetPr');
    if (rgb == null) {
      pr?.children.removeWhere((e) => e is XmlElement && e.name.local == 'tabColor');
    } else {
      if (pr == null) {
        pr = XmlElement(XmlName('sheetPr'));
        root.children.insert(0, pr);
      }
      pr.children.removeWhere((e) => e is XmlElement && e.name.local == 'tabColor');
      pr.children.insert(0, XmlElement(XmlName('tabColor'), [XmlAttribute(XmlName('rgb'), _rgbHex(rgb))]));
    }
    sh.tabColor = rgb;
    z.touch(sh.part);
  }

  // ==================================================================================================
  // Conditional formatting
  // ==================================================================================================
  int _dxfIndex(int? fill, int? color, bool bold) {
    final root = z.xml('xl/styles.xml')!.rootElement;
    var dxfs = _child(root, 'dxfs');
    if (dxfs == null) {
      dxfs = XmlElement(XmlName('dxfs'), [XmlAttribute(XmlName('count'), '0')]);
      var at = root.children.length;
      for (var i = 0; i < root.children.length; i++) {
        final ch = root.children[i];
        if (ch is XmlElement && ['tableStyles', 'colors', 'extLst'].contains(ch.name.local)) {
          at = i;
          break;
        }
      }
      root.children.insert(at, dxfs);
    }
    final d = XmlElement(XmlName('dxf'));
    if (color != null || bold) {
      d.children.add(XmlElement(XmlName('font'), [], [
        if (bold) XmlElement(XmlName('b')),
        if (color != null) XmlElement(XmlName('color'), [XmlAttribute(XmlName('rgb'), _rgbHex(color))]),
      ]));
    }
    if (fill != null) {
      d.children.add(XmlElement(XmlName('fill'), [], [
        XmlElement(XmlName('patternFill'), [], [XmlElement(XmlName('bgColor'), [XmlAttribute(XmlName('rgb'), _rgbHex(fill))])])
      ]));
    }
    final idx = _addUnique(dxfs, 'dxf', d);
    z.touch('xl/styles.xml');
    return idx;
  }

  /// Rewrites all conditional-format elements of [sh] from [XSheet.conds].
  void writeConditionalFormats(XSheet sh) {
    final root = sh.doc.rootElement;
    _removeWs(root, 'conditionalFormatting');
    var prio = 1;
    for (final c in sh.conds) {
      final rule = XmlElement(XmlName('cfRule'));
      final tl = refOf(c.range.c1, c.range.r1);
      switch (c.type) {
        case 'cellIs':
          rule.setAttribute('type', 'cellIs');
          rule.setAttribute('dxfId', '${_dxfIndex(c.fill, c.color, c.bold)}');
          rule.setAttribute('priority', '${prio++}');
          rule.setAttribute('operator', c.op);
          rule.children.add(XmlElement(XmlName('formula'), [], [XmlText(c.v1)]));
          if (c.op == 'between' || c.op == 'notBetween') rule.children.add(XmlElement(XmlName('formula'), [], [XmlText(c.v2)]));
        case 'containsText':
          rule.setAttribute('type', 'containsText');
          rule.setAttribute('dxfId', '${_dxfIndex(c.fill, c.color, c.bold)}');
          rule.setAttribute('priority', '${prio++}');
          rule.setAttribute('operator', 'containsText');
          rule.setAttribute('text', c.v1);
          rule.children.add(XmlElement(XmlName('formula'), [], [XmlText('NOT(ISERROR(SEARCH("${c.v1.replaceAll('"', '""')}",$tl)))')]));
        case 'duplicate':
        case 'unique':
          rule.setAttribute('type', c.type == 'duplicate' ? 'duplicateValues' : 'uniqueValues');
          rule.setAttribute('dxfId', '${_dxfIndex(c.fill, c.color, c.bold)}');
          rule.setAttribute('priority', '${prio++}');
        case 'colorScale':
          rule.setAttribute('type', 'colorScale');
          rule.setAttribute('priority', '${prio++}');
          final three = c.scale.length >= 3;
          rule.children.add(XmlElement(XmlName('colorScale'), [], [
            XmlElement(XmlName('cfvo'), [XmlAttribute(XmlName('type'), 'min')]),
            if (three) XmlElement(XmlName('cfvo'), [XmlAttribute(XmlName('type'), 'percentile'), XmlAttribute(XmlName('val'), '50')]),
            XmlElement(XmlName('cfvo'), [XmlAttribute(XmlName('type'), 'max')]),
            for (final col in c.scale.take(three ? 3 : 2)) XmlElement(XmlName('color'), [XmlAttribute(XmlName('rgb'), _rgbHex(col))]),
          ]));
        default:
          continue;
      }
      _placeWs(root, XmlElement(XmlName('conditionalFormatting'), [XmlAttribute(XmlName('sqref'), c.range.ref)], [rule]));
    }
    z.touch(sh.part);
    xCondCache.clear();
  }

  dynamic _condOperand(XSheet sh, String f) {
    final n = double.tryParse(f);
    if (n != null) return n;
    if (f.length >= 2 && f.startsWith('"') && f.endsWith('"')) return f.substring(1, f.length - 1);
    return XlsxFormulaEngine.evaluate(f, cell: (r) => _evalCell(sh, r, <String>{}), range: (a, b) => _rangeValues(sh, a, b, <String>{}));
  }

  /// Fill / font colour / bold produced by conditional-format rules for one cell (null = none).
  ({int? fill, int? color, bool bold})? condFormat(XSheet sh, int c, int r) {
    if (sh.conds.isEmpty) return null;
    int? fill, color;
    var bold = false, hit = false;
    for (final cd in sh.conds) {
      if (!cd.range.contains(c, r)) continue;
      final ref = refOf(c, r);
      final v = this.cellValue(sh, ref);
      var match = false;
      switch (cd.type) {
        case 'cellIs':
          if (v == null || v == '') break;
          final a = _condOperand(sh, cd.v1), b = cd.op.contains('etween') ? _condOperand(sh, cd.v2) : null;
          int cmp(dynamic x, dynamic y) => x is num && y is num ? x.compareTo(y) : '$x'.toLowerCase().compareTo('$y'.toLowerCase());
          match = switch (cd.op) {
            'greaterThan' => v is num && cmp(v, a) > 0,
            'lessThan' => v is num && cmp(v, a) < 0,
            'greaterThanOrEqual' => v is num && cmp(v, a) >= 0,
            'lessThanOrEqual' => v is num && cmp(v, a) <= 0,
            'equal' => cmp(v, a) == 0,
            'notEqual' => cmp(v, a) != 0,
            'between' => v is num && cmp(v, a) >= 0 && cmp(v, b) <= 0,
            'notBetween' => v is num && (cmp(v, a) < 0 || cmp(v, b) > 0),
            _ => false,
          };
        case 'containsText':
          match = cd.v1.isNotEmpty && this.displayText(sh, ref).toLowerCase().contains(cd.v1.toLowerCase());
        case 'duplicate':
        case 'unique':
          if (v == null || v == '') break;
          final m = xCondCache.dup.putIfAbsent(cd, () {
            final cnt = <String, int>{};
            for (final rr in cd.range.refs) {
              final t = this.displayText(sh, rr).toLowerCase();
              if (t.isNotEmpty) cnt[t] = (cnt[t] ?? 0) + 1;
            }
            return cnt;
          });
          final n = m[this.displayText(sh, ref).toLowerCase()] ?? 0;
          match = cd.type == 'duplicate' ? n > 1 : n == 1;
        case 'colorScale':
          if (v is! num) break;
          final (lo, mid, hi) = xCondCache.span.putIfAbsent(cd, () {
            final nums = <double>[];
            for (final rr in cd.range.refs) {
              final x = this.cellValue(sh, rr);
              if (x is num) nums.add(x.toDouble());
            }
            if (nums.isEmpty) return (0.0, 0.0, 0.0);
            nums.sort();
            return (nums.first, nums[nums.length ~/ 2], nums.last);
          });
          final double t = hi == lo ? 0.0 : ((v.toDouble() - lo) / (hi - lo)).clamp(0.0, 1.0).toDouble();
          int mix(int a, int b, double k) {
            int ch(int s) => (((a >> s) & 255) + ((((b >> s) & 255) - ((a >> s) & 255)) * k)).round().clamp(0, 255);
            return (ch(16) << 16) | (ch(8) << 8) | ch(0);
          }

          if (cd.scale.length >= 3) {
            final midT = hi == lo ? 0.5 : ((mid - lo) / (hi - lo)).clamp(0.01, 0.99);
            fill = t < midT ? mix(cd.scale[0], cd.scale[1], t / midT) : mix(cd.scale[1], cd.scale[2], (t - midT) / (1 - midT));
          } else {
            fill = mix(cd.scale[0], cd.scale[1], t);
          }
          hit = true;
      }
      if (match) {
        hit = true;
        fill ??= cd.fill;
        color ??= cd.color;
        bold = bold || cd.bold;
      }
    }
    return hit ? (fill: fill, color: color, bold: bold) : null;
  }

  // ==================================================================================================
  // Data validation
  // ==================================================================================================
  void writeValidations(XSheet sh) {
    final root = sh.doc.rootElement;
    _removeWs(root, 'dataValidations');
    if (sh.validations.isNotEmpty) {
      final dv = XmlElement(XmlName('dataValidations'), [XmlAttribute(XmlName('count'), '${sh.validations.length}')]);
      for (final v in sh.validations) {
        dv.children.add(XmlElement(XmlName('dataValidation'), [
          XmlAttribute(XmlName('type'), v.type),
          if (v.type != 'list' && v.type != 'custom') XmlAttribute(XmlName('operator'), v.op),
          if (v.allowBlank) XmlAttribute(XmlName('allowBlank'), '1'),
          if (!v.dropdown) XmlAttribute(XmlName('showDropDown'), '1'),
          XmlAttribute(XmlName('showInputMessage'), '1'),
          XmlAttribute(XmlName('showErrorMessage'), '1'),
          if (v.title.isNotEmpty) XmlAttribute(XmlName('promptTitle'), v.title),
          if (v.message.isNotEmpty) XmlAttribute(XmlName('prompt'), v.message),
          XmlAttribute(XmlName('sqref'), v.range.ref),
        ], [
          XmlElement(XmlName('formula1'), [], [XmlText(v.f1)]),
          if (v.f2.isNotEmpty && (v.op == 'between' || v.op == 'notBetween')) XmlElement(XmlName('formula2'), [], [XmlText(v.f2)]),
        ]));
      }
      _placeWs(root, dv);
    }
    z.touch(sh.part);
  }

  XValidation? validationAt(XSheet sh, int c, int r) {
    for (final v in sh.validations) {
      if (v.range.contains(c, r)) return v;
    }
    return null;
  }

  /// Allowed values of a list validation (literal "a,b,c" or a range reference).
  List<String> validationItems(XSheet sh, XValidation v) {
    if (v.type != 'list') return const [];
    if (v.f1.startsWith('"')) return v.items;
    var f = v.f1.replaceAll(r'$', '');
    var target = sh;
    final bang = f.lastIndexOf('!');
    if (bang > 0) {
      var n = f.substring(0, bang);
      if (n.startsWith("'") && n.endsWith("'")) n = n.substring(1, n.length - 1);
      target = _sheetByName(n) ?? sh;
      f = f.substring(bang + 1);
    }
    final named = definedNames[f];
    if (named != null && XRange.parse(named.split('!').last.replaceAll(r'$', '')) != null) {
      final nm = named.split('!');
      if (nm.length > 1) {
        var sn = nm.first;
        if (sn.startsWith("'") && sn.endsWith("'")) sn = sn.substring(1, sn.length - 1);
        target = _sheetByName(sn) ?? sh;
      }
      f = nm.last.replaceAll(r'$', '');
    }
    final rg = XRange.parse(f);
    if (rg == null) return const [];
    return [for (final ref in rg.refs) if ((target.cells[ref] ?? '').isNotEmpty) this.displayText(target, ref)];
  }

  /// Error message when [text] violates the validation of the cell; null when allowed.
  String? validate(XSheet sh, int c, int r, String text) {
    final v = validationAt(sh, c, r);
    if (v == null) return null;
    if (text.isEmpty) return v.allowBlank ? null : 'blank';
    if (text.startsWith('=')) return null;
    switch (v.type) {
      case 'list':
        final items = validationItems(sh, v);
        return items.any((e) => e.toLowerCase() == text.toLowerCase()) ? null : 'list';
      case 'whole':
      case 'decimal':
      case 'date':
      case 'textLength':
        double? x;
        if (v.type == 'textLength') {
          x = text.length.toDouble();
        } else {
          x = double.tryParse(text);
          if (x == null && v.type == 'date') {
            final d = XlsxFormulaEngine.evaluate('DATEVALUE("$text")', cell: (_) => '', range: (a, b) => const []);
            if (d is num) x = d.toDouble();
          }
        }
        if (x == null) return 'number';
        if (v.type == 'whole' && x != x.truncateToDouble()) return 'number';
        final a = _condOperand(sh, v.f1), b = v.f2.isEmpty ? null : _condOperand(sh, v.f2);
        if (a is! num) return null;
        final ok = switch (v.op) {
          'between' => b is num && x >= a && x <= b,
          'notBetween' => b is num && (x < a || x > b),
          'equal' => x == a,
          'notEqual' => x != a,
          'greaterThan' => x > a,
          'lessThan' => x < a,
          'greaterThanOrEqual' => x >= a,
          'lessThanOrEqual' => x <= a,
          _ => true,
        };
        return ok ? null : 'range';
    }
    return null;
  }

  // ==================================================================================================
  // Charts
  // ==================================================================================================
  String _relsPathOf(String part) => '${p.posix.dirname(part)}/_rels/${p.posix.basename(part)}.rels';

  /// Adds a relationship to [owner] and returns its id.
  String _addRel(String owner, String type, String targetPart) {
    final rp = _relsPathOf(owner);
    var doc = z.xml(rp);
    if (doc == null) {
      z.put(rp, utf8.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"/>'));
      doc = z.xml(rp)!;
    }
    final used = {for (final r in doc.findAllElements('Relationship', namespace: '*')) r.getAttribute('Id') ?? ''};
    var n = 1;
    while (used.contains('rId$n')) {
      n++;
    }
    doc.rootElement.children.add(XmlElement(XmlName('Relationship'), [
      XmlAttribute(XmlName('Id'), 'rId$n'),
      XmlAttribute(XmlName('Type'), type),
      XmlAttribute(XmlName('Target'), p.posix.relative(targetPart, from: p.posix.dirname(owner))),
    ]));
    z.touch(rp);
    return 'rId$n';
  }

  void _loadCharts(XSheet sh) {
    sh.charts.clear();
    final dr = _child(sh.doc.rootElement, 'drawing');
    if (dr == null) return;
    String? rid;
    for (final a in dr.attributes) {
      if (a.name.local == 'id') rid = a.value;
    }
    final drawingPart = z.rels(sh.part)[rid];
    final ddoc = drawingPart == null ? null : z.xml(drawingPart);
    if (ddoc == null) return;
    final drels = z.rels(drawingPart!);
    for (final anchor in ddoc.rootElement.childElements) {
      final an = anchor.name.local;
      if (an != 'twoCellAnchor' && an != 'oneCellAnchor') continue;
      final ce = anchor.findAllElements('chart', namespace: '*').firstOrNull;
      if (ce == null) continue;
      String? cid;
      for (final a in ce.attributes) {
        if (a.name.local == 'id') cid = a.value;
      }
      final chartPart = drels[cid];
      final cdoc = chartPart == null ? null : z.xml(chartPart);
      if (cdoc == null) continue;
      int num_(XmlElement? e, String n) => int.tryParse(_child(e, n)?.innerText ?? '') ?? 0;
      final from = _child(anchor, 'from'), to = _child(anchor, 'to');
      final c1 = num_(from, 'col'), r1 = num_(from, 'row');
      final c2 = to == null ? c1 + 8 : num_(to, 'col'), r2 = to == null ? r1 + 15 : num_(to, 'row');
      final chart = XChart(part: chartPart!, drawingPart: drawingPart, anchorId: cid!, c1: c1, r1: r1, c2: math.max(c2, c1 + 1), r2: math.max(r2, r1 + 1), type: 'col', title: '', series: []);
      final plot = cdoc.findAllElements('plotArea', namespace: '*').firstOrNull;
      if (plot != null) {
        for (final e in plot.childElements) {
          final n = e.name.local;
          if (n == 'barChart' || n == 'bar3DChart') {
            chart.type = _child(e, 'barDir')?.getAttribute('val') == 'bar' ? 'bar' : 'col';
          } else if (n == 'lineChart' || n == 'line3DChart' || n == 'scatterChart') {
            chart.type = 'line';
          } else if (n == 'pieChart' || n == 'pie3DChart') {
            chart.type = 'pie';
          } else if (n == 'doughnutChart') {
            chart.type = 'doughnut';
          } else if (n == 'areaChart' || n == 'area3DChart') {
            chart.type = 'area';
          } else {
            continue;
          }
          for (final ser in e.findElements('ser', namespace: '*')) {
            String? refOf_(XmlElement? n) => n?.findAllElements('f', namespace: '*').firstOrNull?.innerText;
            List<String> pts(XmlElement? n) => [for (final pt in n?.findAllElements('pt', namespace: '*') ?? const <XmlElement>[]) _child(pt, 'v')?.innerText ?? ''];
            final tx = _child(ser, 'tx');
            final cat = _child(ser, 'cat') ?? _child(ser, 'xVal');
            final val = _child(ser, 'val') ?? _child(ser, 'yVal');
            chart.series.add(XSeries(
              pts(tx).firstOrNull ?? tx?.innerText ?? '',
              pts(cat),
              [for (final s in pts(val)) double.tryParse(s) ?? 0.0],
              nameRef: refOf_(tx),
              catRef: refOf_(cat),
              valRef: refOf_(val),
            ));
          }
          break;
        }
        final tt = cdoc.findAllElements('title', namespace: '*').firstOrNull;
        if (tt != null) {
          chart.title = tt.findAllElements('t', namespace: '*').map((t) => t.innerText).join();
        }
      }
      sh.charts.add(chart);
    }
  }

  (XSheet, XRange)? _refToRange(XSheet from, String? f) {
    if (f == null || f.isEmpty) return null;
    var s = f.replaceAll(r'$', '');
    var sheet = from;
    final bang = s.lastIndexOf('!');
    if (bang > 0) {
      var n = s.substring(0, bang);
      if (n.startsWith("'") && n.endsWith("'")) n = n.substring(1, n.length - 1).replaceAll("''", "'");
      final o = _sheetByName(n);
      if (o == null) return null;
      sheet = o;
      s = s.substring(bang + 1);
    }
    final rg = XRange.parse(s);
    return rg == null ? null : (sheet, rg);
  }

  void refreshChart(XSheet sh, XChart ch) {
    for (final s in ch.series) {
      final n = _refToRange(sh, s.nameRef);
      if (n != null) s.name = this.displayText(n.$1, n.$2.refs.first);
      final c = _refToRange(sh, s.catRef);
      if (c != null) s.cats = [for (final r in c.$2.refs) this.displayText(c.$1, r)];
      final v = _refToRange(sh, s.valRef);
      if (v != null) {
        s.vals = [
          for (final r in v.$2.refs)
            () {
              final x = this.cellValue(v.$1, r);
              return x is num ? x.toDouble() : 0.0;
            }()
        ];
      }
    }
  }

  void refreshAllCharts() {
    for (final sh in sheets) {
      for (final ch in sh.charts) {
        refreshChart(sh, ch);
      }
    }
  }

  String _esc(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');

  String _chartXml(XChart ch) {
    final b = StringBuffer('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n');
    b.write('<c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">');
    b.write('<c:roundedCorners val="0"/><c:chart>');
    if (ch.title.isNotEmpty) {
      b.write('<c:title><c:tx><c:rich><a:bodyPr/><a:p><a:r><a:t>${_esc(ch.title)}</a:t></a:r></a:p></c:rich></c:tx><c:overlay val="0"/></c:title>');
    }
    b.write('<c:autoTitleDeleted val="${ch.title.isEmpty ? 1 : 0}"/><c:plotArea><c:layout/>');
    final pie = ch.type == 'pie' || ch.type == 'doughnut';
    final series = pie ? ch.series.take(1).toList() : ch.series;
    String strCache(List<String> l) => '<c:strCache><c:ptCount val="${l.length}"/>${[for (var i = 0; i < l.length; i++) '<c:pt idx="$i"><c:v>${_esc(l[i])}</c:v></c:pt>'].join()}</c:strCache>';
    String numCache(List<double> l) => '<c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="${l.length}"/>${[for (var i = 0; i < l.length; i++) '<c:pt idx="$i"><c:v>${l[i]}</c:v></c:pt>'].join()}</c:numCache>';
    final sers = StringBuffer();
    for (var i = 0; i < series.length; i++) {
      final s = series[i];
      sers.write('<c:ser><c:idx val="$i"/><c:order val="$i"/>');
      if (s.nameRef != null) {
        sers.write('<c:tx><c:strRef><c:f>${_esc(s.nameRef!)}</c:f>${strCache([s.name])}</c:strRef></c:tx>');
      } else {
        sers.write('<c:tx><c:v>${_esc(s.name)}</c:v></c:tx>');
      }
      if (!pie) {
        final col = xChartColors[i % xChartColors.length].toRadixString(16).padLeft(6, '0').toUpperCase();
        sers.write(ch.type == 'line' ? '<c:spPr><a:ln w="28575"><a:solidFill><a:srgbClr val="$col"/></a:solidFill></a:ln></c:spPr><c:marker><c:symbol val="circle"/><c:size val="5"/></c:marker>' : '<c:spPr><a:solidFill><a:srgbClr val="$col"/></a:solidFill></c:spPr>');
      }
      if (s.cats.isNotEmpty) {
        sers.write('<c:cat>${s.catRef != null ? '<c:strRef><c:f>${_esc(s.catRef!)}</c:f>${strCache(s.cats)}</c:strRef>' : '<c:strLit><c:ptCount val="${s.cats.length}"/>${[for (var k = 0; k < s.cats.length; k++) '<c:pt idx="$k"><c:v>${_esc(s.cats[k])}</c:v></c:pt>'].join()}</c:strLit>'}</c:cat>');
      }
      sers.write('<c:val>${s.valRef != null ? '<c:numRef><c:f>${_esc(s.valRef!)}</c:f>${numCache(s.vals)}</c:numRef>' : '<c:numLit><c:formatCode>General</c:formatCode><c:ptCount val="${s.vals.length}"/>${[for (var k = 0; k < s.vals.length; k++) '<c:pt idx="$k"><c:v>${s.vals[k]}</c:v></c:pt>'].join()}</c:numLit>'}</c:val>');
      if (ch.type == 'line') sers.write('<c:smooth val="0"/>');
      sers.write('</c:ser>');
    }
    const ax = '<c:axId val="50010"/><c:axId val="50020"/>';
    switch (ch.type) {
      case 'pie':
        b.write('<c:pieChart><c:varyColors val="1"/>$sers<c:firstSliceAng val="0"/></c:pieChart>');
      case 'doughnut':
        b.write('<c:doughnutChart><c:varyColors val="1"/>$sers<c:firstSliceAng val="0"/><c:holeSize val="50"/></c:doughnutChart>');
      case 'line':
        b.write('<c:lineChart><c:grouping val="standard"/><c:varyColors val="0"/>$sers<c:marker val="1"/>$ax</c:lineChart>');
      case 'area':
        b.write('<c:areaChart><c:grouping val="standard"/><c:varyColors val="0"/>$sers$ax</c:areaChart>');
      default:
        b.write('<c:barChart><c:barDir val="${ch.type == 'bar' ? 'bar' : 'col'}"/><c:grouping val="clustered"/><c:varyColors val="0"/>$sers<c:gapWidth val="150"/>$ax</c:barChart>');
    }
    if (!pie) {
      final h = ch.type == 'bar';
      b.write('<c:catAx><c:axId val="50010"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="${h ? 'l' : 'b'}"/><c:numFmt formatCode="General" sourceLinked="0"/><c:majorTickMark val="out"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:crossAx val="50020"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/><c:noMultiLvlLbl val="0"/></c:catAx>');
      b.write('<c:valAx><c:axId val="50020"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="${h ? 'b' : 'l'}"/><c:majorGridlines/><c:numFmt formatCode="General" sourceLinked="1"/><c:majorTickMark val="out"/><c:minorTickMark val="none"/><c:tickLblPos val="nextTo"/><c:crossAx val="50010"/><c:crosses val="autoZero"/><c:crossBetween val="between"/></c:valAx>');
    }
    b.write('</c:plotArea><c:legend><c:legendPos val="${pie ? 'r' : 'b'}"/><c:overlay val="0"/></c:legend><c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/></c:chart></c:chartSpace>');
    return b.toString();
  }

  String _a1Abs(XSheet sh, XRange r) => '${_quoteSheet(sh.name)}!\$${colName(r.c1)}\$${r.r1}${r.isCell ? '' : ':\$${colName(r.c2)}\$${r.r2}'}';

  /// Inserts a chart for the numbers of [data]. The first column holds category labels and the first row series names
  /// when [labels] / [header] are true. Returns the new chart.
  XChart addChart(XSheet sh, {required String type, required XRange data, bool header = true, bool labels = true, String title = '', int? atCol, int? atRow, int spanCols = 8, int spanRows = 16}) {
    final firstDataRow = header ? data.r1 + 1 : data.r1;
    final firstDataCol = labels ? data.c1 + 1 : data.c1;
    final series = <XSeries>[];
    final catRange = labels && firstDataRow <= data.r2 ? XRange(data.c1, firstDataRow, data.c1, data.r2) : null;
    for (var c = firstDataCol; c <= data.c2; c++) {
      final valRange = XRange(c, firstDataRow, c, data.r2);
      final nameRef = header ? XRange.cell(c, data.r1) : null;
      final s = XSeries(header ? this.displayText(sh, refOf(c, data.r1)) : 'Series ${series.length + 1}', [], [],
          nameRef: nameRef == null ? null : _a1Abs(sh, nameRef), catRef: catRange == null ? null : _a1Abs(sh, catRange), valRef: _a1Abs(sh, valRange));
      series.add(s);
    }
    if (series.isEmpty) throw 'No numeric columns';
    final col0 = atCol ?? (data.c2 + 2), row0 = atRow ?? (data.r1 - 1);
    // chart part
    var n = 1;
    while (z.file('xl/charts/chart$n.xml') != null) {
      n++;
    }
    final chartPart = 'xl/charts/chart$n.xml';
    // drawing part (existing or new)
    String? drawingPart;
    final dr = _child(sh.doc.rootElement, 'drawing');
    if (dr != null) {
      String? rid;
      for (final a in dr.attributes) {
        if (a.name.local == 'id') rid = a.value;
      }
      drawingPart = z.rels(sh.part)[rid];
    }
    if (drawingPart == null || z.xml(drawingPart) == null) {
      var m = 1;
      while (z.file('xl/drawings/drawing$m.xml') != null) {
        m++;
      }
      drawingPart = 'xl/drawings/drawing$m.xml';
      z.put(drawingPart, utf8.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"/>'));
      z.addOverride('/$drawingPart', 'application/vnd.openxmlformats-officedocument.drawing+xml');
      final rid = _addRel(sh.part, 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing', drawingPart);
      final root = sh.doc.rootElement;
      if (root.getAttribute('xmlns:r') == null) root.setAttribute('xmlns:r', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships');
      _placeWs(root, XmlElement(XmlName('drawing'), [XmlAttribute(XmlName.fromString('r:id'), rid)]));
      z.touch(sh.part);
    }
    final chart = XChart(part: chartPart, drawingPart: drawingPart, anchorId: '', c1: col0, r1: math.max(0, row0), c2: col0 + spanCols, r2: math.max(0, row0) + spanRows, type: type, title: title, series: series);
    refreshChart(sh, chart);
    z.put(chartPart, utf8.encode(_chartXml(chart)));
    z.addOverride('/$chartPart', 'application/vnd.openxmlformats-officedocument.drawingml.chart+xml');
    final crid = _addRel(drawingPart, 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart', chartPart);
    final ddoc = z.xml(drawingPart)!;
    var shapeId = 2;
    for (final e in ddoc.findAllElements('cNvPr', namespace: '*')) {
      shapeId = math.max(shapeId, (int.tryParse(e.getAttribute('id') ?? '') ?? 0) + 1);
    }
    final anchorXml = '<xdr:twoCellAnchor xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
        '<xdr:from><xdr:col>${chart.c1}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${chart.r1}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from>'
        '<xdr:to><xdr:col>${chart.c2}</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>${chart.r2}</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to>'
        '<xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="$shapeId" name="Chart ${shapeId - 1}"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr>'
        '<xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart">'
        '<c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:id="$crid"/>'
        '</a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor>';
    ddoc.rootElement.children.add(XmlDocument.parse(anchorXml).rootElement.copy());
    z.touch(drawingPart);
    final done = XChart(part: chartPart, drawingPart: drawingPart, anchorId: crid, c1: chart.c1, r1: chart.r1, c2: chart.c2, r2: chart.r2, type: type, title: title, series: series);
    sh.charts.add(done);
    return done;
  }

  XmlElement? _anchorOf(XChart ch) {
    final d = z.xml(ch.drawingPart);
    if (d == null) return null;
    for (final a in d.rootElement.childElements) {
      final ce = a.findAllElements('chart', namespace: '*').firstOrNull;
      if (ce == null) continue;
      for (final at in ce.attributes) {
        if (at.name.local == 'id' && at.value == ch.anchorId) return a;
      }
    }
    return null;
  }

  /// Rewrites the chart part after type / title / data changes.
  void updateChart(XSheet sh, XChart ch, {String? type, String? title}) {
    if (type != null) ch.type = type;
    if (title != null) ch.title = title;
    refreshChart(sh, ch);
    z.put(ch.part, utf8.encode(_chartXml(ch)));
    z.touch(ch.part);
  }

  void setChartAnchor(XChart ch, int c1, int r1, int c2, int r2) {
    ch.c1 = c1;
    ch.r1 = r1;
    ch.c2 = c2;
    ch.r2 = r2;
    final a = _anchorOf(ch);
    if (a == null || a.name.local != 'twoCellAnchor') return;
    void set(String corner, int col, int row) {
      final e = _child(a, corner);
      _child(e, 'col')?.children
        ?..clear()
        ..add(XmlText('$col'));
      _child(e, 'row')?.children
        ?..clear()
        ..add(XmlText('$row'));
      _child(e, 'colOff')?.children
        ?..clear()
        ..add(XmlText('0'));
      _child(e, 'rowOff')?.children
        ?..clear()
        ..add(XmlText('0'));
    }

    set('from', c1, r1);
    set('to', c2, r2);
    z.touch(ch.drawingPart);
  }

  void deleteChart(XSheet sh, XChart ch) {
    final a = _anchorOf(ch);
    if (a != null) {
      a.parent!.children.remove(a);
      z.touch(ch.drawingPart);
    }
    final rp = _relsPathOf(ch.drawingPart);
    final rd = z.xml(rp);
    if (rd != null) {
      for (final r in rd.findAllElements('Relationship', namespace: '*').toList()) {
        if (r.getAttribute('Id') == ch.anchorId) r.parent!.children.remove(r);
      }
      z.touch(rp);
    }
    z.drop.add(ch.part);
    z.drop.add(_relsPathOf(ch.part));
    z.removeOverride(ch.part);
    sh.charts.remove(ch);
  }
}
