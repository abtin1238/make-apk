import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Colours of the Office screens (Word / Excel / PowerPoint viewers and editors).
/// Every colour can be changed in Settings -> Office appearance; a missing key = the default of the design.
class OfficePrefs {
  /// key -> (fa label, en label, default ARGB)
  static const Map<String, (String, String, int)> spec = {
    'navy': ('نوار عنوان', 'Title bar', 0xFF1B2B4B),
    'navyDeep': ('نوار پایین تیره (اکسل)', 'Dark bottom bar (Excel)', 0xFF1F2F4F),
    'strip': ('نوار ابزار و نوار پایین', 'Tool strip & bottom bar', 0xFFF4F6FA),
    'bg': ('پس‌زمینهٔ کار', 'Workspace background', 0xFFEEF0F5),
    'ink': ('رنگ متن و آیکون‌ها', 'Text & icon colour', 0xFF2A3350),
    'blue': ('رنگ تأکید (ورد / پاورپوینت)', 'Accent (Word / PowerPoint)', 0xFF1F5FBF),
    'sel': ('کادر اسلاید انتخاب‌شده', 'Selected slide frame', 0xFF2D7DF0),
    'green': ('رنگ تأکید (اکسل)', 'Accent (Excel)', 0xFF107C41),
    'head': ('سرستون و شمارهٔ ردیف', 'Column / row headers', 0xFFEEF0F5),
    'rowOne': ('ردیف عنوان جدول', 'Table header row', 0xFFE4F1E8),
    'line': ('خطوط جدول', 'Grid lines', 0xFFD9DDE6),
    'paper': ('برگهٔ سند (ورد)', 'Page (Word)', 0xFFFFFFFF),
    'paperInk': ('متن سند (ورد)', 'Document text (Word)', 0xFF1B1B1B),
    'cell': ('زمینهٔ سلول‌ها (اکسل)', 'Cell background (Excel)', 0xFFFFFFFF),
    'cellInk': ('متن سلول‌ها (اکسل)', 'Cell text (Excel)', 0xFF1B1B1B),
  };

  /// Defaults of the dark mode (keys missing here fall back to [spec]).
  static const Map<String, int> darkDef = {
    'navy': 0xFF121A2B,
    'navyDeep': 0xFF0E1522,
    'strip': 0xFF1B2232,
    'bg': 0xFF0F1420,
    'ink': 0xFFDCE3F2,
    'blue': 0xFF5B9BFF,
    'sel': 0xFF4C9AFF,
    'green': 0xFF3DBE7A,
    'head': 0xFF1E2636,
    'rowOne': 0xFF1E3A2B,
    'line': 0xFF2D3648,
    'paper': 0xFF1A2030,
    'paperInk': 0xFFE8ECF5,
    'cell': 0xFF161C28,
    'cellInk': 0xFFE8ECF5,
  };

  static const List<String> keys = ['navy', 'navyDeep', 'strip', 'bg', 'ink', 'blue', 'sel', 'green', 'head', 'rowOne', 'line', 'paper', 'paperInk', 'cell', 'cellInk'];

  /// 'light' | 'dark' | 'system'
  static String mode = 'system';
  static bool dark = false;

  /// Resolves [mode] (system = the phone's brightness). Called by [officeTheme] before every Office screen paints.
  static void resolve(Brightness system) => dark = mode == 'dark' || (mode == 'system' && system == Brightness.dark);

  static final Map<String, int> _ovLight = {};
  static final Map<String, int> _ovDark = {};
  static Map<String, int> get _ov => dark ? _ovDark : _ovLight;

  static Color c(String k) => Color(_ov[k] ?? (dark ? (darkDef[k] ?? spec[k]!.$3) : spec[k]!.$3));
  static bool isCustom(String k) => _ov.containsKey(k);
  static bool get anyCustom => _ov.isNotEmpty;

  static Color get paper => c('paper');
  static Color get paperInk => c('paperInk');
  static Color get cell => c('cell');
  static Color get cellInk => c('cellInk');

  static Color get navy => c('navy');
  static Color get navyDeep => c('navyDeep');
  static Color get strip => c('strip');
  static Color get bg => c('bg');
  static Color get ink => c('ink');
  static Color get blue => c('blue');
  static Color get sel => c('sel');
  static Color get green => c('green');
  static Color get head => c('head');
  static Color get rowOne => c('rowOne');
  static Color get line => c('line');

  /// Slightly darker / lighter helpers derived from the chosen colours.
  static Color get greenTint => Color.alphaBlend(green.withOpacity(.16), dark ? strip : Colors.white);
  static Color get blueTint => Color.alphaBlend(blue.withOpacity(.16), dark ? strip : Colors.white);

  static void set(String k, int? argb) {
    if (!spec.containsKey(k)) return;
    if (argb == null || argb == (dark ? (darkDef[k] ?? spec[k]!.$3) : spec[k]!.$3)) {
      _ov.remove(k);
    } else {
      _ov[k] = argb | 0xFF000000;
    }
  }

  static void clear() => _ov.clear();

  /// Near-black / near-white document colours are flipped in dark mode so text never vanishes on the page.
  static Color? visible(Color? col) {
    if (col == null || !dark) return col;
    return col.computeLuminance() < .12 ? paperInk : col;
  }

  static void apply(Map<String, int> m) {
    _ov.clear();
    m.forEach(set);
  }

  static String encode() => jsonEncode(_ovLight);
  static String encodeDark() => jsonEncode(_ovDark);

  static void _loadInto(Map<String, int> t, String? raw) {
    t.clear();
    try {
      final m = jsonDecode(raw ?? '{}') as Map;
      m.forEach((k, v) {
        if (spec.containsKey('$k') && v is num) t['$k'] = v.toInt();
      });
    } catch (_) {}
  }

  static void load(SharedPreferences p) {
    _loadInto(_ovLight, p.getString('officeColors'));
    _loadInto(_ovDark, p.getString('officeColorsDark'));
    mode = p.getString('officeMode') ?? 'system';
    if (mode != 'light' && mode != 'dark') mode = 'system';
    resolve(WidgetsBinding.instance.platformDispatcher.platformBrightness);
  }

  /// Ready-made colour sets shown as quick choices.
  static const List<(String, String, Map<String, int>)> presets = [
    ('پیش‌فرض (مطابق طرح)', 'Default (design)', {}),
    ('اقیانوس', 'Ocean', {'navy': 0xFF0B3C5D, 'navyDeep': 0xFF0E4A72, 'blue': 0xFF0E7C86, 'sel': 0xFF1CA6B5, 'green': 0xFF0E8A5F, 'ink': 0xFF16324A}),
    ('بنفش', 'Violet', {'navy': 0xFF2B1F4D, 'navyDeep': 0xFF35275E, 'blue': 0xFF6A4CD6, 'sel': 0xFF8A6BFF, 'green': 0xFF2E9E6B, 'ink': 0xFF2C2547}),
    ('گرافیت', 'Graphite', {'navy': 0xFF262B33, 'navyDeep': 0xFF2F353F, 'blue': 0xFF3F6FD8, 'sel': 0xFF4C86F5, 'green': 0xFF2E8B57, 'ink': 0xFF262B33, 'strip': 0xFFF2F3F5, 'bg': 0xFFE9EAED}),
    ('گرم', 'Warm', {'navy': 0xFF4A2C1B, 'navyDeep': 0xFF5A3724, 'blue': 0xFFC2571A, 'sel': 0xFFF08A3C, 'green': 0xFF5E8C2A, 'ink': 0xFF3E2A1E, 'strip': 0xFFFAF5EF, 'bg': 0xFFF2ECE4}),
  ];
}
