import 'package:flutter/material.dart';
import 'font_prefs.dart';

class AppColors {
  static const bg = Color(0xFF070B1A);
  static const card = Color(0xFF111A33);
  static const blue = Color(0xFF2F6BFF);
  static const purple = Color(0xFF8B5CF6);
  static const gold = Color(0xFFF5A623);
  static const danger = Color(0xFFFF4D5E);
  static const grad = LinearGradient(colors: [blue, purple], begin: Alignment.topLeft, end: Alignment.bottomRight);
}

/// A selectable colour theme. Works in both light and dark mode.
class AppPalette {
  final String fa, en;
  final Color primary, secondary;
  final Color darkBg, darkCard, darkNav;
  final Color lightBg;
  const AppPalette(this.fa, this.en, this.primary, this.secondary, this.darkBg, this.darkCard, this.darkNav, this.lightBg);
}

const List<AppPalette> appPalettes = [
  AppPalette('نئون', 'Neon', Color(0xFF18B8FF), Color(0xFF8B3DFF), Color(0xFF000003), Color(0xFF080C1C), Color(0xFF03050F), Color(0xFFF1F6FF)),
  AppPalette('شیشه‌ای', 'Glass', Color(0xFF7C6CFF), Color(0xFF2DD4BF), Color(0xFF0F1219), Color(0xFF141A2B), Color(0xFF0F1424), Color(0xFFF3F5FB)),
];

/// Keys of the user colour overrides (AppSettings.themeOv). A missing key = follow the palette.
const List<String> themeOvKeys = ['primary', 'secondary', 'bgD', 'cardD', 'bgL', 'cardL'];

/// Colours of the palette [id] after the user's own colour changes [ov] (keys: [themeOvKeys]).
class ResolvedColors {
  final Color primary, secondary, bg, card, nav;
  const ResolvedColors(this.primary, this.secondary, this.bg, this.card, this.nav);
}

ResolvedColors resolveColors(bool dark, int id, [Map<String, int>? ov]) {
  final p = appPalettes[(id >= 0 && id < appPalettes.length) ? id : 0];
  Color? o(String k) => ov == null || ov[k] == null ? null : Color(ov[k]!);
  final bg = dark ? (o('bgD') ?? p.darkBg) : (o('bgL') ?? p.lightBg);
  final card = dark ? (o('cardD') ?? p.darkCard) : (o('cardL') ?? Colors.white);
  final navChanged = dark && (o('bgD') != null || o('cardD') != null);
  final nav = dark ? (navChanged ? Color.lerp(bg, card, .5)! : p.darkNav) : (o('cardL') ?? Colors.white);
  return ResolvedColors(o('primary') ?? p.primary, o('secondary') ?? p.secondary, bg, card, nav);
}

/// [btnColor] / [btnText]: user-chosen ARGB values for buttons (0 = follow the palette / automatic).
/// [ov]: the user's own colours on top of the palette; [look]: neon | glass | abtin (core/looks.dart).
ThemeData buildTheme(bool dark, [int btnColor = 0, int btnText = 0, String look = 'neon']) {
  final rc = resolveColors(dark, look == 'glass' ? 1 : 0);
  final scheme = ColorScheme.fromSeed(seedColor: rc.primary, brightness: dark ? Brightness.dark : Brightness.light, primary: rc.primary, secondary: rc.secondary);
  final bg = rc.bg;
  final surf = rc.card;
  // Every button in the app is a rounded, coloured pill (text buttons are tinted, filled ones solid).
  final bc = btnColor != 0 ? Color(btnColor) : rc.primary;
  final bt = btnText != 0 ? Color(btnText) : null;
  final onSolid = bt ?? (bc.computeLuminance() > .6 ? Colors.black : Colors.white);
  final onSoft = bt ?? (dark ? Color.lerp(bc, Colors.white, .3)! : Color.lerp(bc, Colors.black, .15)!);
  final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(14));
  const pad = EdgeInsets.symmetric(horizontal: 16, vertical: 10);
  const label = TextStyle(fontWeight: FontWeight.w600);
  return ThemeData(
    useMaterial3: true,
    // UI font chosen in Settings -> Font (bundled in assets/fonts).
    fontFamily: FontPrefs.family(),
    colorScheme: scheme,
    scaffoldBackgroundColor: bg,
    cardColor: surf,
    iconTheme: IconThemeData(color: scheme.onSurface),
    appBarTheme: AppBarTheme(backgroundColor: bg, elevation: 0, scrolledUnderElevation: 0, centerTitle: look == 'neon' || look == 'abtin' || look == 'gradient' ? true : null),
    navigationBarTheme: NavigationBarThemeData(backgroundColor: look == 'neon' || look == 'abtin' ? bg : rc.nav, indicatorColor: rc.primary.withOpacity(look == 'neon' || look == 'abtin' ? .18 : .25)),
    dialogTheme: DialogThemeData(
      backgroundColor: surf,
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(look == 'glass' ? 28 : 24),
          side: look == 'neon' || look == 'abtin' ? BorderSide(color: rc.primary.withOpacity(.6), width: 1.2) : BorderSide.none),
    ),
    bottomSheetTheme: BottomSheetThemeData(
      backgroundColor: surf,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    ),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: onSoft,
        backgroundColor: bc.withOpacity(dark ? .20 : .12),
        shape: shape,
        padding: pad,
        textStyle: label,
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(backgroundColor: bc, foregroundColor: onSolid, elevation: 0, shape: shape, padding: pad, textStyle: label),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(backgroundColor: bc, foregroundColor: onSolid, shape: shape, padding: pad, textStyle: label),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: onSoft,
        backgroundColor: bc.withOpacity(dark ? .10 : .06),
        side: BorderSide(color: bc.withOpacity(.85), width: 1.2),
        shape: shape,
        padding: pad,
        textStyle: label,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: dark ? rc.nav : const Color(0xFFEAEEF8), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
  );
}
