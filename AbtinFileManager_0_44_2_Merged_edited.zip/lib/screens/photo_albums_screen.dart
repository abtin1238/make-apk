import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../core/theme.dart';
import '../services/file_ops.dart';
import '../widgets/file_thumb.dart';
import 'gallery_screen.dart';

/// Gallery: photos grouped into albums (one album per folder, like Camera / Screenshots / WhatsApp Images).
class PhotoAlbumsScreen extends StatefulWidget {
  const PhotoAlbumsScreen({super.key});
  @override
  State<PhotoAlbumsScreen> createState() => _PhotoAlbumsScreenState();
}

class _PhotoAlbumsScreenState extends State<PhotoAlbumsScreen> {
  List<FItem>? all;
  Map<String, List<FItem>> albums = {};
  String q = '';

  @override
  void initState() {
    super.initState();
    FileOps.scanCat(Cat.images).then((r) {
      if (!mounted) return;
      final m = <String, List<FItem>>{};
      for (final i in r) {
        m.putIfAbsent(p.dirname(i.path), () => []).add(i); // already newest-first
      }
      setState(() {
        all = r;
        albums = m;
      });
    });
  }

  /// Camera and Screenshots first, then by size of the album.
  int _rank(String dir) {
    final n = p.basename(dir).toLowerCase();
    if (n == 'camera') return 0;
    if (n.startsWith('screenshot')) return 1;
    return 2;
  }

  void _open(String title, List<FItem> items) => Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => GalleryScreen(
          title: title,
          items: items,
          onDeleted: (ps) => setState(() {
            all?.removeWhere((e) => ps.contains(e.path));
            for (final v in albums.values) {
              v.removeWhere((e) => ps.contains(e.path));
            }
            albums.removeWhere((k, v) => v.isEmpty);
          }),
        ),
      ));

  @override
  Widget build(BuildContext context) {
    final list = all;
    final keys = albums.keys.where((k) => q.isEmpty || p.basename(k).toLowerCase().contains(q)).toList()
      ..sort((a, b) {
        final r = _rank(a).compareTo(_rank(b));
        return r != 0 ? r : albums[b]!.length.compareTo(albums[a]!.length);
      });
    return Scaffold(
      appBar: AppBar(title: Text(L.t('images') + (list == null ? '' : ' (${list.length})'))),
      body: list == null
          ? Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Center(child: CircularProgressIndicator()), const SizedBox(height: 12), Text(L.t('scanning'))])
          : list.isEmpty
              ? Center(child: Text(L.t('empty')))
              : Column(children: [
                  Padding(
                    padding: const EdgeInsets.all(8),
                    child: TextField(onChanged: (v) => setState(() => q = v.toLowerCase()), decoration: InputDecoration(hintText: L.t('search'), prefixIcon: const Icon(Icons.search_rounded))),
                  ),
                  Expanded(
                    child: GridView.builder(
                      padding: const EdgeInsets.all(10),
                      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 180, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.85),
                      itemCount: keys.length + (q.isEmpty ? 1 : 0),
                      itemBuilder: (_, i) {
                        final isAll = q.isEmpty && i == 0;
                        final items = isAll ? list : albums[keys[q.isEmpty ? i - 1 : i]]!;
                        final name = isAll ? L.t('allPhotos') : p.basename(keys[q.isEmpty ? i - 1 : i]);
                        return InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () => _open(name, items),
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Expanded(
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(14),
                                child: LayoutBuilder(
                                  builder: (_, c) => ImageThumb(
                                    key: ValueKey(items.first.path),
                                    item: items.first,
                                    size: c.maxWidth.isFinite ? c.maxWidth : 180,
                                    fallback: const Icon(Icons.photo_library_rounded, color: AppColors.blue),
                                  ),
                                ),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                            Text('${items.length}', style: const TextStyle(fontSize: 11, color: Colors.white54)),
                          ]),
                        );
                      },
                    ),
                  ),
                ]),
    );
  }
}
