import 'dart:io';

import 'package:flutter/material.dart' hide Icon;

import '../widgets/app_icon.dart';

import 'package:flutter/services.dart';

import '../services/saf.dart';
import '../services/file_ops.dart';
import 'saf_prompt.dart';

import 'package:path/path.dart' as p;

import '../core/l10n.dart';
import '../services/highlighter.dart';
import '../widgets/ui.dart';
import 'hash_screen.dart';
import 'hex_viewer_screen.dart';
import 'viewer_delete.dart';
import 'terminal_screen.dart';

/// Text / code file: opens in VIEW mode (read-only, selectable, syntax highlighted).
/// The edit button switches to edit mode; save returns to view mode.
class TextEditorScreen extends StatefulWidget {
  final String path;
  const TextEditorScreen({super.key, required this.path});
  @override
  State<TextEditorScreen> createState() => _TextEditorScreenState();
}

class _TextEditorScreenState extends State<TextEditorScreen> {
  static const int _historyLimit = 80;
  static const int _historyBudget = 2 * 1024 * 1024;

  late final CodeController ctl = CodeController(lang: Hl.langOf(widget.path));
  final FocusNode focus = FocusNode();
  bool loaded = false, dirty = false, editing = false;
  double font = 14;
  int indentWidth = 4;
  String _savedText = '';
  TextEditingValue _lastStableValue = TextEditingValue.empty;
  final List<TextEditingValue> _undo = [];
  final List<TextEditingValue> _redo = [];
  int _undoBytes = 0, _redoBytes = 0;
  bool _applyingHistory = false;

  @override
  void initState() {
    super.initState();
    ctl.addListener(_onControllerChanged);
    File(widget.path)
        .readAsString()
        .then((t) {
          if (!mounted) return;
          ctl.value = TextEditingValue(
            text: t,
            selection: TextSelection.collapsed(offset: t.length),
          );
          _savedText = t;
          _lastStableValue = ctl.value;
          setState(() => loaded = true);
        })
        .catchError((e) {
          if (mounted) {
            snack(context, '$e');
            Navigator.pop(context);
          }
        });
  }

  @override
  void dispose() {
    ctl.removeListener(_onControllerChanged);
    ctl.dispose();
    focus.dispose();
    super.dispose();
  }

  void _push(Widget w) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => w));

  Future<void> _openTerminal() async {
    if (dirty) {
      final proceed = await confirm(
        context,
        'تغییرات ذخیره‌نشده‌اند؛ فرمان‌های ترمینال فایل ذخیره‌شده روی دیسک را می‌بینند، نه متن ذخیره‌نشدهٔ ویرایشگر. ادامه می‌دهید؟',
      );
      if (!proceed || !mounted) return;
    }
    focus.unfocus();
    await Navigator.push<void>(
      context,
      MaterialPageRoute<void>(
        builder: (_) => TerminalScreen(cwd: p.dirname(widget.path)),
      ),
    );
  }

  void _onControllerChanged() {
    final value = ctl.value;
    if (_applyingHistory || !loaded) return;

    // Do not put intermediate IME composing text on the undo stack. The stable
    // pre-composition value remains the undo target until composition commits.
    if (value.composing.isValid && !value.composing.isCollapsed) {
      if (mounted) setState(() {});
      return;
    }

    if (value.text != _lastStableValue.text) {
      _pushHistory(_undo, value: _lastStableValue, isUndo: true);
      _clearHistory(_redo, isUndo: false);
    }
    _lastStableValue = value;
    dirty = value.text != _savedText;
    // Selection-only changes move the status-bar caret as well.
    if (mounted) setState(() {});
  }

  int _valueBytes(TextEditingValue v) => v.text.length * 2;

  String _spaces(int count) => List<String>.filled(count, ' ').join();

  void _pushHistory(
    List<TextEditingValue> stack, {
    required TextEditingValue value,
    required bool isUndo,
  }) {
    final bytes = _valueBytes(value);
    if (bytes > _historyBudget) {
      _clearHistory(stack, isUndo: isUndo);
      return;
    }
    final currentBytes = isUndo ? _undoBytes : _redoBytes;
    var total = currentBytes;
    while (stack.isNotEmpty &&
        (stack.length >= _historyLimit || total + bytes > _historyBudget)) {
      total -= _valueBytes(stack.removeAt(0));
    }
    stack.add(value);
    total += bytes;
    if (isUndo) {
      _undoBytes = total;
    } else {
      _redoBytes = total;
    }
  }

  void _clearHistory(List<TextEditingValue> stack, {required bool isUndo}) {
    stack.clear();
    if (isUndo) {
      _undoBytes = 0;
    } else {
      _redoBytes = 0;
    }
  }

  void _applyHistory(TextEditingValue value) {
    _applyingHistory = true;
    ctl.value = value.copyWith(composing: TextRange.empty);
    _applyingHistory = false;
    _lastStableValue = ctl.value;
    dirty = ctl.text != _savedText;
    setState(() {});
  }

  void _undoEdit() {
    if (!editing || _undo.isEmpty) return;
    final target = _undo.removeLast();
    _undoBytes -= _valueBytes(target);
    _pushHistory(_redo, value: ctl.value, isUndo: false);
    _applyHistory(target);
  }

  void _redoEdit() {
    if (!editing || _redo.isEmpty) return;
    final target = _redo.removeLast();
    _redoBytes -= _valueBytes(target);
    _pushHistory(_undo, value: ctl.value, isUndo: true);
    _applyHistory(target);
  }

  void _startEdit() {
    setState(() => editing = true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) focus.requestFocus();
    });
  }

  void _stopEdit() {
    focus.unfocus();
    setState(() => editing = false);
  }

  Future<void> _save() async {
    if (!await ensureSdAll(context, [widget.path])) return;
    try {
      await Saf.writeString(widget.path, ctl.text);
    } on OpError catch (e) {
      if (mounted) snack(context, L.t(e.key));
      return;
    }
    if (!mounted) return;
    _savedText = ctl.text;
    setState(() {
      dirty = false;
      editing = false;
    });
    focus.unfocus();
    snack(context, L.t('done'));
  }

  Future<void> _deleteThis() async {
    if (await deleteFromViewer(context, widget.path) && mounted) {
      dirty = false;
      Navigator.of(context).pop();
    }
  }

  TextEditingValue _formatInput(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    // Let active IME composition and multi-character input (including ordinary
    // paste) pass through untouched.
    if (newValue.composing.isValid && !newValue.composing.isCollapsed)
      return newValue;
    final diff = _textDiff(oldValue, newValue);
    if (diff == null || diff.inserted.isEmpty) return newValue;
    final cursor = newValue.selection.isValid
        ? newValue.selection.extentOffset
        : -1;

    if (diff.inserted == '\n' && cursor == diff.start + 1) {
      final lineStart = _lineStart(newValue.text, diff.start);
      final beforeEnter = newValue.text.substring(lineStart, diff.start);
      final leading =
          RegExp(r'^[\t ]*').firstMatch(beforeEnter)?.group(0) ?? '';
      final trimmed = beforeEnter.trimRight();
      final extra =
          trimmed.isNotEmpty &&
              const [
                '{',
                '[',
                '(',
              ].contains(trimmed.substring(trimmed.length - 1))
          ? _spaces(indentWidth)
          : '';
      final indentation =
          leading.replaceAll('\t', _spaces(indentWidth)) + extra;
      if (indentation.isNotEmpty) {
        final text = newValue.text.replaceRange(
          diff.start + 1,
          diff.start + 1,
          indentation,
        );
        final next = diff.start + 1 + indentation.length;
        return newValue.copyWith(
          text: text,
          selection: TextSelection.collapsed(offset: next),
          composing: TextRange.empty,
        );
      }
    }

    const pairs = {'(': ')', '[': ']', '{': '}', '"': '"', "'": "'", '`': '`'};
    final closeChars = const {')', ']', '}', '"', "'", '`'};
    if (diff.inserted.length == 1 &&
        cursor == diff.start + 1 &&
        newValue.selection.isCollapsed) {
      final typed = diff.inserted;
      if (closeChars.contains(typed) &&
          oldValue.selection.isCollapsed &&
          oldValue.selection.extentOffset == diff.start &&
          oldValue.text.startsWith(typed, diff.start)) {
        // Typing over the already-present paired closer advances rather than duplicates it.
        return oldValue.copyWith(
          selection: TextSelection.collapsed(offset: diff.start + 1),
          composing: TextRange.empty,
        );
      }
      final close = pairs[typed];
      if (close != null) {
        // Insert the matching character after the caret, not inside any active
        // composition. Selection offsets are UTF-16 offsets as required by Flutter.
        final text = newValue.text.replaceRange(cursor, cursor, close);
        return newValue.copyWith(
          text: text,
          selection: TextSelection.collapsed(offset: cursor),
          composing: TextRange.empty,
        );
      }
    }
    return newValue;
  }

  _EditDiff? _textDiff(TextEditingValue oldValue, TextEditingValue newValue) {
    final oldText = oldValue.text;
    final newText = newValue.text;
    // Prefer the old selection as the edit anchor. A plain common-prefix diff
    // cannot distinguish inserting a repeated character (for example ')' just
    // before an existing ')') from typing after it.
    if (oldValue.selection.isValid &&
        newValue.selection.isValid &&
        newValue.selection.isCollapsed) {
      final start = oldValue.selection.start;
      final end = oldValue.selection.end;
      final cursor = newValue.selection.extentOffset;
      if (start <= end &&
          end <= oldText.length &&
          cursor >= start &&
          cursor <= newText.length) {
        final inserted = newText.substring(start, cursor);
        if (oldText.replaceRange(start, end, inserted) == newText) {
          return _EditDiff(start, oldText.substring(start, end), inserted);
        }
      }
    }
    var prefix = 0;
    final minLength = oldText.length < newText.length
        ? oldText.length
        : newText.length;
    while (prefix < minLength &&
        oldText.codeUnitAt(prefix) == newText.codeUnitAt(prefix)) {
      prefix++;
    }
    var oldEnd = oldText.length;
    var newEnd = newText.length;
    while (oldEnd > prefix &&
        newEnd > prefix &&
        oldText.codeUnitAt(oldEnd - 1) == newText.codeUnitAt(newEnd - 1)) {
      oldEnd--;
      newEnd--;
    }
    return _EditDiff(
      prefix,
      oldText.substring(prefix, oldEnd),
      newText.substring(prefix, newEnd),
    );
  }

  KeyEventResult _onKeyEvent(FocusNode node, KeyEvent event) {
    if (event is! KeyDownEvent && event is! KeyRepeatEvent)
      return KeyEventResult.ignored;
    final key = event.logicalKey;
    final keyboard = HardwareKeyboard.instance;
    final primary = keyboard.isControlPressed || keyboard.isMetaPressed;
    if (primary && key == LogicalKeyboardKey.keyZ) {
      if (keyboard.isShiftPressed) {
        _redoEdit();
      } else {
        _undoEdit();
      }
      return KeyEventResult.handled;
    }
    if (primary && key == LogicalKeyboardKey.keyY) {
      _redoEdit();
      return KeyEventResult.handled;
    }
    if (primary && key == LogicalKeyboardKey.keyF) {
      _showFindReplace();
      return KeyEventResult.handled;
    }
    if (primary && key == LogicalKeyboardKey.keyG) {
      _goToLine();
      return KeyEventResult.handled;
    }
    if (!editing) return KeyEventResult.ignored;
    if (key == LogicalKeyboardKey.tab) {
      _indentSelection(outdent: keyboard.isShiftPressed);
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  int _lineStart(String text, int offset) =>
      offset <= 0 ? 0 : text.lastIndexOf('\n', offset - 1) + 1;

  void _indentSelection({required bool outdent}) {
    if (!editing) return;
    final value = ctl.value;
    final text = value.text;
    final selection = value.selection.isValid
        ? value.selection
        : TextSelection.collapsed(offset: 0);
    final start = selection.start.clamp(0, text.length).toInt();
    final end = selection.end.clamp(0, text.length).toInt();
    if (!outdent && selection.isCollapsed) {
      final spaces = _spaces(indentWidth);
      final nextText = text.replaceRange(start, start, spaces);
      ctl.value = value.copyWith(
        text: nextText,
        selection: TextSelection.collapsed(offset: start + spaces.length),
        composing: TextRange.empty,
      );
      return;
    }

    final lastOffset = end > start && text.codeUnitAt(end - 1) == 10
        ? end - 1
        : end;
    final starts = <int>[];
    var line = _lineStart(text, start);
    final lastLine = _lineStart(text, lastOffset);
    while (line <= lastLine) {
      starts.add(line);
      final next = text.indexOf('\n', line);
      if (next < 0 || next + 1 > lastLine) break;
      line = next + 1;
    }

    var nextText = text;
    var nextStart = start;
    var nextEnd = end;
    if (!outdent) {
      final spaces = _spaces(indentWidth);
      for (final at in starts.reversed) {
        nextText = nextText.replaceRange(at, at, spaces);
      }
      int shifted(int offset) =>
          offset + starts.where((at) => at <= offset).length * spaces.length;
      nextStart = shifted(start);
      nextEnd = shifted(end);
    } else {
      final removals = <(int, int)>[];
      for (final at in starts) {
        if (at >= text.length) continue;
        if (text.codeUnitAt(at) == 9) {
          removals.add((at, 1));
        } else {
          var count = 0;
          while (count < indentWidth &&
              at + count < text.length &&
              text.codeUnitAt(at + count) == 32) {
            count++;
          }
          if (count > 0) removals.add((at, count));
        }
      }
      for (final removal in removals.reversed) {
        nextText = nextText.replaceRange(
          removal.$1,
          removal.$1 + removal.$2,
          '',
        );
      }
      int shifted(int offset) {
        var result = offset;
        for (final removal in removals) {
          if (offset > removal.$1) {
            result -= offset < removal.$1 + removal.$2
                ? offset - removal.$1
                : removal.$2;
          }
        }
        return result;
      }

      nextStart = shifted(start);
      nextEnd = shifted(end);
    }
    ctl.value = value.copyWith(
      text: nextText,
      selection: TextSelection(baseOffset: nextStart, extentOffset: nextEnd),
      composing: TextRange.empty,
    );
  }

  (int, int) _lineColumn(int offset) {
    final safe = offset.clamp(0, ctl.text.length).toInt();
    var line = 1;
    var lastBreak = -1;
    for (var i = 0; i < safe; i++) {
      if (ctl.text.codeUnitAt(i) == 10) {
        line++;
        lastBreak = i;
      }
    }
    return (line, safe - lastBreak);
  }

  Future<void> _showFindReplace() async {
    final selected = ctl.selection;
    final initial = selected.isValid && !selected.isCollapsed
        ? ctl.text.substring(selected.start, selected.end)
        : '';
    final query = TextEditingController(text: initial);
    final replacement = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('جست‌وجو و جایگزینی'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: query,
              autofocus: true,
              decoration: const InputDecoration(
                labelText: 'عبارت مورد جست‌وجو',
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: replacement,
              decoration: const InputDecoration(labelText: 'جایگزینی با'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => _findNext(query.text),
            child: const Text('یافتن بعدی'),
          ),
          TextButton(
            onPressed: editing
                ? () => _replaceSelected(query.text, replacement.text)
                : null,
            child: const Text('جایگزینی'),
          ),
          TextButton(
            onPressed: editing
                ? () => _replaceAll(query.text, replacement.text)
                : null,
            child: const Text('جایگزینی همه'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(L.t('done')),
          ),
        ],
      ),
    );
    query.dispose();
    replacement.dispose();
  }

  void _findNext(String query) {
    if (query.isEmpty) return;
    final text = ctl.text;
    final selection = ctl.selection;
    final from = selection.isValid
        ? selection.end.clamp(0, text.length).toInt()
        : 0;
    var at = text.indexOf(query, from);
    if (at < 0 && from > 0) at = text.indexOf(query);
    if (at < 0) {
      snack(context, 'موردی پیدا نشد');
      return;
    }
    ctl.selection = TextSelection(
      baseOffset: at,
      extentOffset: at + query.length,
    );
    if (editing) focus.requestFocus();
  }

  void _replaceSelected(String query, String replacement) {
    if (!editing || query.isEmpty) return;
    final selection = ctl.selection;
    if (selection.isValid &&
        !selection.isCollapsed &&
        ctl.text.substring(selection.start, selection.end) == query) {
      final text = ctl.text.replaceRange(
        selection.start,
        selection.end,
        replacement,
      );
      final caret = selection.start + replacement.length;
      ctl.value = TextEditingValue(
        text: text,
        selection: TextSelection.collapsed(offset: caret),
      );
      _findNext(query);
    } else {
      _findNext(query);
    }
  }

  void _replaceAll(String query, String replacement) {
    if (!editing || query.isEmpty) return;
    final value = ctl.value;
    final beforeCaret = value.selection.isValid
        ? value.selection.extentOffset
        : 0;
    var matchesBefore = 0;
    var from = 0;
    while (true) {
      final at = value.text.indexOf(query, from);
      if (at < 0) break;
      if (at < beforeCaret) matchesBefore++;
      from = at + query.length;
    }
    final result = value.text.replaceAll(query, replacement);
    if (result == value.text) {
      snack(context, 'موردی پیدا نشد');
      return;
    }
    final caret =
        (beforeCaret + matchesBefore * (replacement.length - query.length))
            .clamp(0, result.length)
            .toInt();
    ctl.value = TextEditingValue(
      text: result,
      selection: TextSelection.collapsed(offset: caret),
    );
  }

  Future<void> _goToLine() async {
    final lines = ctl.text.split('\n').length;
    final selected = ctl.selection;
    final initialLine = selected.isValid
        ? _lineColumn(selected.extentOffset).$1
        : 1;
    final input = TextEditingController(text: '$initialLine');
    final result = await showDialog<int>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('رفتن به خط'),
        content: TextField(
          controller: input,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: 'شمارهٔ خط (۱ تا $lines)'),
          onSubmitted: (v) => Navigator.pop(dialogContext, int.tryParse(v)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(L.t('cancel')),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.pop(dialogContext, int.tryParse(input.text)),
            child: Text(L.t('ok')),
          ),
        ],
      ),
    );
    input.dispose();
    if (result == null || !mounted) return;
    final target = result.clamp(1, lines).toInt();
    var offset = 0;
    for (var line = 1; line < target; line++) {
      final next = ctl.text.indexOf('\n', offset);
      if (next < 0) break;
      offset = next + 1;
    }
    ctl.selection = TextSelection.collapsed(offset: offset);
    if (editing) focus.requestFocus();
  }

  @override
  Widget build(BuildContext context) {
    ctl.dark = Theme.of(context).brightness == Brightness.dark;
    final caret = ctl.selection.isValid ? ctl.selection.extentOffset : 0;
    final position = _lineColumn(caret);
    return PopScope(
      canPop: !dirty,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await confirm(context, L.t('discard')) && context.mounted)
          Navigator.pop(context);
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            p.basename(widget.path),
            style: const TextStyle(fontSize: 16),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.text_decrease_rounded),
              tooltip: 'کوچک‌کردن متن',
              onPressed: () =>
                  setState(() => font = (font - 1).clamp(9, 40).toDouble()),
            ),
            IconButton(
              icon: const Icon(Icons.text_increase_rounded),
              tooltip: 'بزرگ‌کردن متن',
              onPressed: () =>
                  setState(() => font = (font + 1).clamp(9, 40).toDouble()),
            ),
            if (editing) ...[
              IconButton(
                icon: const Icon(Icons.visibility_rounded),
                tooltip: L.t('view'),
                onPressed: _stopEdit,
              ),
              IconButton(
                icon: Icon(
                  Icons.save_rounded,
                  color: dirty ? Colors.amber : null,
                ),
                tooltip: L.t('save'),
                onPressed: _save,
              ),
            ] else if (loaded)
              IconButton(
                icon: const Icon(Icons.edit_rounded),
                tooltip: L.t('edit'),
                onPressed: _startEdit,
              ),
            if (loaded && ctl.lang.isNotEmpty)
              IconButton(
                icon: const Icon(Icons.terminal_rounded),
                tooltip: 'ترمینال در پوشهٔ فایل',
                onPressed: _openTerminal,
              ),
            PopupMenuButton<int>(
              onSelected: (v) {
                if (v == 0) setState(() => ctl.enabled = !ctl.enabled);
                if (v == 1) _push(HexViewerScreen(path: widget.path));
                if (v == 2) _push(HashScreen(path: widget.path));
                if (v == 3) {
                  Clipboard.setData(ClipboardData(text: ctl.text));
                  snack(context, L.t('done'));
                }
                if (v == 4) _deleteThis();
                if (v == 5) _showFindReplace();
                if (v == 6) _goToLine();
                if (v == 7) _undoEdit();
                if (v == 8) _redoEdit();
                if (v == 9) _indentSelection(outdent: false);
                if (v == 10) _indentSelection(outdent: true);
                if (v == 11) setState(() => indentWidth = 2);
                if (v == 12) setState(() => indentWidth = 4);
              },
              itemBuilder: (_) => [
                if (ctl.lang.isNotEmpty)
                  CheckedPopupMenuItem(
                    value: 0,
                    checked: ctl.enabled,
                    child: Text(L.t('syntax')),
                  ),
                PopupMenuItem(value: 3, child: Text(L.t('copyAll'))),
                PopupMenuItem(
                  value: 5,
                  enabled: loaded,
                  child: const Text('جست‌وجو و جایگزینی'),
                ),
                PopupMenuItem(
                  value: 6,
                  enabled: loaded,
                  child: const Text('رفتن به خط'),
                ),
                if (editing) ...[
                  PopupMenuItem(
                    value: 7,
                    enabled: _undo.isNotEmpty,
                    child: const Text('بازگشت (Undo)'),
                  ),
                  PopupMenuItem(
                    value: 8,
                    enabled: _redo.isNotEmpty,
                    child: const Text('انجام دوباره (Redo)'),
                  ),
                  PopupMenuItem(
                    value: 9,
                    child: const Text('افزایش تورفتگی خط/انتخاب'),
                  ),
                  PopupMenuItem(
                    value: 10,
                    child: const Text('کاهش تورفتگی خط/انتخاب'),
                  ),
                  CheckedPopupMenuItem(
                    value: 11,
                    checked: indentWidth == 2,
                    child: const Text('اندازهٔ تورفتگی: ۲ فاصله'),
                  ),
                  CheckedPopupMenuItem(
                    value: 12,
                    checked: indentWidth == 4,
                    child: const Text('اندازهٔ تورفتگی: ۴ فاصله'),
                  ),
                ],
                PopupMenuItem(value: 1, child: Text(L.t('hex'))),
                PopupMenuItem(value: 2, child: Text(L.t('hash'))),
                PopupMenuItem(value: 4, child: Text(L.t('delete'))),
              ],
            ),
          ],
        ),
        floatingActionButton: (loaded && !editing)
            ? FloatingActionButton.extended(
                onPressed: _startEdit,
                icon: const Icon(Icons.edit_rounded),
                label: Text(L.t('edit')),
              )
            : null,
        body: !loaded
            ? const Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  Expanded(
                    child: Focus(
                      onKeyEvent: _onKeyEvent,
                      child: TextField(
                        controller: ctl,
                        focusNode: focus,
                        readOnly: !editing,
                        showCursor: editing,
                        enableInteractiveSelection: true,
                        maxLines: null,
                        expands: true,
                        textAlignVertical: TextAlignVertical.top,
                        style: TextStyle(
                          fontFamily: 'monospace',
                          fontSize: font,
                        ),
                        inputFormatters: [
                          TextInputFormatter.withFunction(_formatInput),
                        ],
                        decoration: InputDecoration(
                          border: InputBorder.none,
                          filled: false,
                          contentPadding: const EdgeInsets.fromLTRB(
                            12,
                            12,
                            12,
                            12,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 30,
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: Theme.of(context)
                          .colorScheme
                          .surfaceContainerHighest
                          .withOpacity(.55),
                      border: Border(
                        top: BorderSide(
                          color: Theme.of(context).dividerColor
                              .withOpacity(.35),
                        ),
                      ),
                    ),
                    child: Row(
                      children: [
                        Text(
                          editing ? 'ویرایش' : 'فقط‌خواندنی',
                          style: Theme.of(context).textTheme.labelSmall,
                        ),
                        const Spacer(),
                        Directionality(
                          textDirection: TextDirection.ltr,
                          child: Text(
                            '${position.$1}:${position.$2}',
                            style: Theme.of(context).textTheme.labelSmall
                                ?.copyWith(fontFamily: 'monospace'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}

class _EditDiff {
  final int start;
  final String removed;
  final String inserted;
  const _EditDiff(this.start, this.removed, this.inserted);
}
