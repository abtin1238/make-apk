import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../widgets/ui.dart';
import 'apk_info_screen.dart';
import 'bundle_install_screen.dart';
import 'category_screen.dart';

const _defaultBackupDir = '/storage/emulated/0/AbtinBackup/Apps';

class AppsScreen extends StatefulWidget {
  const AppsScreen({super.key});
  @override
  State<AppsScreen> createState() => _AppsScreenState();
}

class _AppsScreenState extends State<AppsScreen> with WidgetsBindingObserver {
  List<Map<String, dynamic>> apps = [];
  List<FileSystemEntity> backups = [];
  final sel = <String>{};
  final icons = <String, Future<Uint8List?>>{};
  String q = '';
  bool showSystem = false;
  bool loading = true;
  String _backupDir = _defaultBackupDir;
  // APK / bundle files on the storage whose app is not installed yet
  List<Map<String, dynamic>> _pending = [];
  bool _scanning = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _load();
  }

  Future<void> _pickDir() async {
    final d = await FilePicker.platform.getDirectoryPath();
    if (d == null) return;
    (await SharedPreferences.getInstance()).setString('appBackupDir', d);
    setState(() => _backupDir = d);
    _load();
  }

  Future<void> _load() async {
    try {
      _backupDir = (await SharedPreferences.getInstance()).getString('appBackupDir') ?? _defaultBackupDir;
      final a = await Native.apps();
      a.sort((x, y) => '${x['label']}'.toLowerCase().compareTo('${y['label']}'.toLowerCase()));
      final d = Directory(_backupDir);
      final b = d.existsSync()
          ? (d.listSync().where((e) => e is Directory || e.path.toLowerCase().endsWith('.apk')).toList()
            ..sort((x, y) => y.statSync().modified.compareTo(x.statSync().modified)))
          : <FileSystemEntity>[];
      if (!mounted) return;
      setState(() {
        apps = a;
        backups = b;
        loading = false;
        sel.removeWhere((k) => !a.any((e) => e['pkg'] == k));
      });
      _scanApks();
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> _scanApks() async {
    if (_scanning) return;
    setState(() => _scanning = true);
    try {
      final files = await FileOps.scanCat(Cat.apps); // newest first
      final out = <Map<String, dynamic>>[];
      final seen = <String>{};
      for (var i = 0; i < files.length; i += 6) {
        final part = files.skip(i).take(6).toList();
        final r = await Future.wait(part.map<Future<Map<String, dynamic>?>>((f) async {
          final ext = p.extension(f.path).toLowerCase();
          if (ext == '.aab') return null;
          if (ext != '.apk') return {'path': f.path, 'label': f.name, 'bundle': true, 'size': f.size};
          try {
            final info = await Native.apkInfo(f.path);
            if (info == null || info['installedCode'] != null) return null; // unreadable or already installed
            return {'path': f.path, 'label': '${info['label']}', 'pkg': '${info['package']}', 'version': '${info['versionName']}', 'size': f.size};
          } catch (_) {
            return null;
          }
        }));
        for (final m in r) {
          if (m == null) continue;
          final pkg = m['pkg'] as String?;
          if (pkg != null && !seen.add(pkg)) continue; // keep only the newest file of each app
          out.add(m);
        }
      }
      if (mounted) setState(() => _pending = out);
    } catch (_) {
    } finally {
      if (mounted) setState(() => _scanning = false);
    }
  }

  Widget _uninstalled() {
    if (_pending.isEmpty) {
      return Center(
        child: _scanning
            ? Column(mainAxisSize: MainAxisSize.min, children: [const CircularProgressIndicator(), const SizedBox(height: 12), Text(L.t('scanningApks'))])
            : Text(L.t('noUninstalled')),
      );
    }
    return RefreshIndicator(
      onRefresh: _scanApks,
      child: ListView.builder(
        itemCount: _pending.length,
        itemBuilder: (_, i) {
          final m = _pending[i];
          final path = '${m['path']}';
          final bundle = m['bundle'] == true;
          return ListTile(
            leading: bundle
                ? const Icon(Icons.inventory_2_rounded, size: 40, color: Color(0xFF3DDC84))
                : FutureBuilder<Uint8List?>(
                    future: icons.putIfAbsent(path, () => Native.apkIcon(path)),
                    builder: (_, s) => s.data != null
                        ? ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.memory(s.data!, width: 44, height: 44, gaplessPlayback: true))
                        : const Icon(Icons.android_rounded, size: 40, color: Color(0xFF3DDC84)),
                  ),
            title: Text('${m['label']}', maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(
              bundle ? '${p.basename(path)} • ${FileOps.fmt((m['size'] as num).toInt())}' : '${m['pkg']}\n${m['version']} • ${FileOps.fmt((m['size'] as num).toInt())}',
              style: const TextStyle(fontSize: 11),
            ),
            isThreeLine: !bundle,
            trailing: const Icon(Icons.download_for_offline_rounded),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => bundle ? BundleInstallScreen(path: path) : ApkInfoScreen(path: path))).then((_) => _load()),
          );
        },
      ),
    );
  }

  List<Map<String, dynamic>> get _shown => [
        for (final a in apps)
          if ((showSystem || a['system'] != true) &&
              (q.isEmpty || '${a['label']} ${a['pkg']}'.toLowerCase().contains(q.toLowerCase())))
            a
      ];

  Future<void> _backup() async {
    final list = sel.toList();
    int ok = 0;
    await busy(context, () async {
      for (final pkg in list) {
        if (await Native.backupApp(pkg, _backupDir) != null) ok++;
      }
    });
    if (!mounted) return;
    snack(context, ok == 0 ? L.t('backupFail') : L.tr('backupDone', {'n': ok, 'dir': _backupDir}));
    setState(sel.clear);
    _load();
  }

  Future<void> _uninstall() async {
    if (!await confirm(context, '${L.t('uninstallSel')} (${sel.length})')) return;
    final list = sel.toList();
    setState(sel.clear);
    for (final pkg in list) {
      await Native.uninstall(pkg);
      await Future.delayed(const Duration(milliseconds: 700));
    }
  }

  Widget _icon(String pkg) => FutureBuilder<Uint8List?>(
        future: icons.putIfAbsent(pkg, () => Native.appIcon(pkg)),
        builder: (_, s) => ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: s.data != null
              ? Image.memory(s.data!, width: 44, height: 44, gaplessPlayback: true)
              : const SizedBox(width: 44, height: 44, child: Icon(Icons.android_rounded, color: Color(0xFF3DDC84))),
        ),
      );

  Widget _installed() {
    final l = _shown;
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
        child: Row(children: [
          Expanded(
            child: TextField(
              decoration: InputDecoration(prefixIcon: const Icon(Icons.search_rounded), hintText: L.t('searchApps'), isDense: true),
              onChanged: (v) => setState(() => q = v),
            ),
          ),
          const SizedBox(width: 8),
          FilterChip(label: Text(L.t('systemApps')), selected: showSystem, onSelected: (v) => setState(() => showSystem = v)),
        ]),
      ),
      Expanded(
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                itemCount: l.length,
                itemBuilder: (_, i) {
                  final a = l[i];
                  final pkg = '${a['pkg']}';
                  final on = sel.contains(pkg);
                  return ListTile(
                    leading: _icon(pkg),
                    title: Text('${a['label']}', maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text('$pkg\n${a['version']} • ${FileOps.fmt((a['size'] as num).toInt())}', style: const TextStyle(fontSize: 11)),
                    isThreeLine: true,
                    selected: on,
                    trailing: Checkbox(value: on, onChanged: (_) => setState(() => on ? sel.remove(pkg) : sel.add(pkg))),
                    onTap: () => setState(() => on ? sel.remove(pkg) : sel.add(pkg)),
                    onLongPress: () => Native.uninstall(pkg),
                  );
                },
              ),
      ),
    ]);
  }

  Widget _backups() {
    final header = ListTile(
      dense: true,
      leading: const Icon(Icons.folder_rounded),
      title: Text(L.t('backupFolder')),
      subtitle: Text(_backupDir, style: const TextStyle(fontSize: 11)),
      trailing: TextButton(onPressed: _pickDir, child: Text(L.t('chooseFolder'))),
    );
    if (backups.isEmpty) return Column(children: [header, Expanded(child: Center(child: Text(L.t('noBackups'))))]);
    return ListView.builder(
      itemCount: backups.length + 1,
      itemBuilder: (_, i) {
        if (i == 0) return header;
        final e = backups[i - 1];
        final isDir = e is Directory;
        final apk = isDir ? p.join(e.path, 'base.apk') : e.path;
        return ListTile(
          leading: isDir
              ? const Icon(Icons.folder_zip_rounded, size: 40)
              : FutureBuilder<Uint8List?>(
                  future: icons.putIfAbsent(e.path, () => Native.apkIcon(e.path)),
                  builder: (_, s) => s.data != null
                      ? ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.memory(s.data!, width: 44, height: 44))
                      : const Icon(Icons.android_rounded, size: 40, color: Color(0xFF3DDC84)),
                ),
          title: Text(p.basename(e.path), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
          subtitle: Text(isDir ? 'APK ×${(e).listSync().length}' : FileOps.fmt(File(e.path).lengthSync())),
          onTap: () {
            Navigator.push(context, MaterialPageRoute(builder: (_) => isDir ? BundleInstallScreen(path: e.path) : ApkInfoScreen(path: apk)));
          },
          trailing: IconButton(
            icon: const Icon(Icons.delete_outline_rounded),
            onPressed: () async {
              if (!await confirm(context, p.basename(e.path))) return;
              await e.delete(recursive: true);
              _load();
            },
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(sel.isEmpty ? L.t('apps') : '${sel.length}'),
          actions: [
            IconButton(tooltip: L.t('apkFiles'), icon: const Icon(Icons.folder_open_rounded), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CategoryScreen(cat: Cat.apps)))),
            IconButton(tooltip: L.t('backupFolder'), icon: const Icon(Icons.drive_folder_upload_rounded), onPressed: _pickDir),
            if (sel.isNotEmpty) ...[
              IconButton(tooltip: L.t('backupSel'), icon: const Icon(Icons.backup_rounded), onPressed: _backup),
              IconButton(tooltip: L.t('uninstall'), icon: const Icon(Icons.delete_outline_rounded), onPressed: _uninstall),
              IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(sel.clear)),
            ] else ...[
              IconButton(
                  tooltip: L.t('selectAll'),
                  icon: const Icon(Icons.select_all_rounded),
                  onPressed: () => setState(() => sel.addAll(_shown.map((e) => '${e['pkg']}')))),
            ],
          ],
          bottom: TabBar(tabs: [Tab(text: L.t('installedApps')), Tab(text: L.t('notInstalledApps')), Tab(text: L.t('appBackups'))]),
        ),
        body: TabBarView(children: [_installed(), _uninstalled(), _backups()]),
      ),
    );
  }
}
