import 'package:flutter/material.dart' hide Icon;
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/layouts.dart' show tr2;
import '../core/office_prefs.dart';
import '../core/settings.dart';
import '../widgets/app_icon.dart';
import '../widgets/ui.dart';
import 'color_editor.dart';

/// Settings -> Office appearance: every colour of the Word / Excel / PowerPoint screens, with a live preview.
class OfficeStyleScreen extends StatelessWidget {
  const OfficeStyleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    OfficePrefs.resolve(MediaQuery.platformBrightnessOf(context));
    return Scaffold(
      appBar: AppBar(title: Text(tr2('ظاهر آفیس', 'Office appearance')), actions: [
        IconButton(
          tooltip: tr2('بازگشت به رنگ‌های طرح', 'Reset to design colours'),
          icon: const Icon(Icons.restart_alt_rounded),
          onPressed: OfficePrefs.anyCustom ? s.resetOffice : null,
        ),
      ]),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 32), children: [
        Directionality(
          textDirection: TextDirection.ltr,
          child: SegmentedButton<String>(
            showSelectedIcon: false,
            segments: [
              ButtonSegment(value: 'light', icon: const Icon(Icons.light_mode_rounded, size: 18), label: Text(tr2('روشن', 'Light'))),
              ButtonSegment(value: 'dark', icon: const Icon(Icons.dark_mode_rounded, size: 18), label: Text(tr2('تیره', 'Dark'))),
              ButtonSegment(value: 'system', icon: const Icon(Icons.brightness_auto_rounded, size: 18), label: Text(tr2('خودکار', 'Auto'))),
            ],
            selected: {OfficePrefs.mode},
            onSelectionChanged: (v) => s.setOfficeMode(v.first),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          tr2(OfficePrefs.dark ? 'رنگ‌های زیر برای حالت تیره است؛ حالت روشن رنگ‌های جدا دارد.' : 'رنگ‌های زیر برای حالت روشن است؛ حالت تیره رنگ‌های جدا دارد.',
              OfficePrefs.dark ? 'The colours below are for dark mode; light mode keeps its own.' : 'The colours below are for light mode; dark mode keeps its own.'),
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 12),
        const _Preview(),
        const SizedBox(height: 18),
        Text(tr2('طرح‌های آماده', 'Presets'), style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final pr in OfficePrefs.presets)
            ActionChip(
              avatar: CircleAvatar(radius: 8, backgroundColor: Color(pr.$3['navy'] ?? OfficePrefs.spec['navy']!.$3)),
              label: Text(tr2(pr.$1, pr.$2)),
              onPressed: () => s.applyOfficePreset(pr.$3),
            ),
        ]),
        const SizedBox(height: 18),
        Text(tr2('رنگ‌ها', 'Colours'), style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 4),
        for (final k in OfficePrefs.keys)
          ListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(tr2(OfficePrefs.spec[k]!.$1, OfficePrefs.spec[k]!.$2)),
            subtitle: Text(hexOf(OfficePrefs.c(k)), textDirection: TextDirection.ltr),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              if (OfficePrefs.isCustom(k))
                IconButton(tooltip: L.t('reset'), icon: const Icon(Icons.undo_rounded, size: 20), onPressed: () => s.setOfficeColor(k, null)),
              Container(width: 34, height: 34, decoration: BoxDecoration(color: OfficePrefs.c(k), shape: BoxShape.circle, border: Border.all(color: Colors.grey.withOpacity(.6)))),
            ]),
            onTap: () => _pick(context, s, k),
          ),
      ]),
    );
  }

  Future<void> _pick(BuildContext context, AppSettings s, String k) async {
    var cur = OfficePrefs.c(k);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 16 + MediaQuery.of(ctx).viewInsets.bottom),
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(tr2(OfficePrefs.spec[k]!.$1, OfficePrefs.spec[k]!.$2), style: Theme.of(ctx).textTheme.titleMedium),
            const SizedBox(height: 10),
            ColorPickerPanel(color: cur, onChanged: (c) => cur = c, onCommit: (c) => s.setOfficeColor(k, c.value)),
            const SizedBox(height: 10),
            FilledButton(onPressed: () => Navigator.pop(ctx), child: Text(L.t('ok'))),
          ]),
        ),
      ),
    );
  }
}

/// Miniature of the three Office screens drawn with the current colours.
class _Preview extends StatelessWidget {
  const _Preview();

  @override
  Widget build(BuildContext context) {
    Widget bar(String t) => Container(
          height: 34,
          color: OfficePrefs.navy,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Row(children: [
            const Icon(Icons.arrow_back_rounded, color: Colors.white, size: 18),
            Expanded(child: Text(t, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600))),
            const Icon(Icons.more_vert_rounded, color: Colors.white, size: 18),
          ]),
        );
    Widget strip(List<IconData> ics) => Container(
          height: 30,
          color: OfficePrefs.strip,
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [for (final i in ics) Icon(i, size: 16, color: OfficePrefs.ink)]),
        );
    Widget card(Widget child) => Expanded(
          child: Container(
            height: 150,
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: OfficePrefs.line)),
            clipBehavior: Clip.antiAlias,
            child: child,
          ),
        );
    final word = Column(children: [
      bar('Word'),
      strip(const [Icons.format_bold_rounded, Icons.format_italic_rounded, Icons.format_underline_rounded, Icons.format_align_left_rounded]),
      Expanded(
        child: Container(
          color: OfficePrefs.bg,
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
          child: Container(color: OfficePrefs.paper, padding: const EdgeInsets.all(6), alignment: Alignment.topRight, child: Text('Abc', style: TextStyle(color: OfficePrefs.blue, fontWeight: FontWeight.bold))),
        ),
      ),
    ]);
    final sheet = Column(children: [
      bar('Excel'),
      Expanded(
        child: Container(
          color: OfficePrefs.cell,
          child: Column(children: [
            Container(height: 18, color: OfficePrefs.head),
            Container(height: 22, color: OfficePrefs.rowOne, alignment: Alignment.center, child: Container(width: 34, height: 18, decoration: BoxDecoration(border: Border.all(color: OfficePrefs.green, width: 2)))),
            Expanded(child: Container(decoration: BoxDecoration(border: Border(top: BorderSide(color: OfficePrefs.line))))),
          ]),
        ),
      ),
      Container(height: 24, color: OfficePrefs.navyDeep),
    ]);
    final slides = Column(children: [
      bar('PowerPoint'),
      strip(const [Icons.undo_rounded, Icons.title_rounded, Icons.add_box_outlined]),
      Expanded(
        child: Container(
          color: OfficePrefs.bg,
          alignment: Alignment.center,
          child: Container(width: 60, height: 36, decoration: BoxDecoration(color: Colors.white, border: Border.all(color: OfficePrefs.sel, width: 2))),
        ),
      ),
    ]);
    return Row(children: [card(word), const SizedBox(width: 8), card(sheet), const SizedBox(width: 8), card(slides)]);
  }
}
