import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../widgets/ui.dart';

const List<int> _swatches = [
  0xFF2F6BFF, 0xFF8B5CF6, 0xFFE040FB, 0xFFE91E63, 0xFFFF4D5E, 0xFFF4511E,
  0xFFF5A623, 0xFFFFD54F, 0xFF9CCC65, 0xFF2E9E5B, 0xFF00BFA5, 0xFF26C6DA,
  0xFF607D8B, 0xFFFFFFFF, 0xFF000000,
];

/// Settings -> button style: colour of the buttons and colour of their text, with a live preview.
class ButtonStyleScreen extends StatelessWidget {
  const ButtonStyleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(L.t('buttonStyle')), actions: [
        IconButton(
          tooltip: L.t('resetButtons'),
          icon: const Icon(Icons.restart_alt_rounded),
          onPressed: () {
            s.setBtnColor(0);
            s.setBtnText(0);
          },
        ),
      ]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        // live preview: uses the real theme, so it shows exactly what the app will look like
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(22), border: Border.all(color: cs.primary.withOpacity(.25))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Text(L.t('preview'), style: Theme.of(context).textTheme.labelMedium),
            const SizedBox(height: 12),
            FilledButton.icon(onPressed: () {}, icon: const Icon(Icons.download_done_rounded, size: 20), label: Text(L.t('extract'))),
            const SizedBox(height: 8),
            OutlinedButton.icon(onPressed: () {}, icon: const Icon(Icons.unarchive_rounded, size: 20), label: Text(L.t('extractHere'))),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: CancelButton(icon: true, onPressed: () {})),
              const SizedBox(width: 8),
              Expanded(child: TextButton.icon(onPressed: () {}, icon: const Icon(Icons.visibility_rounded, size: 20), label: Text(L.t('viewContents')))),
            ]),
          ]),
        ),
        const SizedBox(height: 22),
        Text(L.t('buttonColor'), style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 10),
        _Swatches(current: s.btnColor, onPick: s.setBtnColor),
        const SizedBox(height: 22),
        Text(L.t('buttonTextColor'), style: Theme.of(context).textTheme.titleSmall),
        const SizedBox(height: 10),
        _Swatches(current: s.btnText, onPick: s.setBtnText),
        const SizedBox(height: 14),
        Text(L.t('buttonCancelNote'), style: Theme.of(context).textTheme.bodySmall),
      ]),
    );
  }
}

class _Swatches extends StatelessWidget {
  final int current;
  final ValueChanged<int> onPick;
  const _Swatches({required this.current, required this.onPick});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    Widget dot({required bool on, required Widget child, required VoidCallback tap, Color? fill}) => GestureDetector(
          onTap: tap,
          child: Container(
            width: 44,
            height: 44,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: fill,
              border: Border.all(color: on ? cs.onSurface : cs.outlineVariant, width: on ? 3 : 1),
            ),
            child: child,
          ),
        );
    return Wrap(spacing: 10, runSpacing: 10, children: [
      // 0 = automatic (follows the palette)
      dot(
        on: current == 0,
        tap: () => onPick(0),
        child: Icon(Icons.auto_awesome_rounded, size: 22, color: current == 0 ? cs.onSurface : cs.onSurfaceVariant),
      ),
      for (final c in _swatches)
        dot(
          on: current == c,
          tap: () => onPick(c),
          fill: Color(c),
          child: current == c ? Icon(Icons.check_rounded, color: Color(c).computeLuminance() > .6 ? Colors.black : Colors.white) : const SizedBox.shrink(),
        ),
    ]);
  }
}
