import 'dart:io';
import 'package:flutter/material.dart' hide Icon;
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../core/layouts.dart' show tr2;
import '../core/office_prefs.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../services/saf.dart';
import '../widgets/app_icon.dart';
import '../widgets/office_chrome.dart';
import '../widgets/ui.dart';
import 'opener.dart';
import 'saf_prompt.dart';

/// The three document types that can be created from scratch.
enum OfficeKind { docx, xlsx, pptx }

extension OfficeKindInfo on OfficeKind {
  String get ext => name;
  String get title => switch (this) {
        OfficeKind.docx => tr2('سند ورد جدید', 'New Word document'),
        OfficeKind.xlsx => tr2('صفحه‌گسترده اکسل جدید', 'New Excel spreadsheet'),
        OfficeKind.pptx => tr2('ارائهٔ پاورپوینت جدید', 'New PowerPoint presentation'),
      };
  String get defaultName => switch (this) {
        OfficeKind.docx => tr2('سند جدید', 'New document'),
        OfficeKind.xlsx => tr2('جدول جدید', 'New spreadsheet'),
        OfficeKind.pptx => tr2('ارائه جدید', 'New presentation'),
      };
  IconData get icon => switch (this) {
        OfficeKind.docx => Icons.description_rounded,
        OfficeKind.xlsx => Icons.grid_on_rounded,
        OfficeKind.pptx => Icons.slideshow_rounded,
      };
  Color get color => switch (this) {
        OfficeKind.docx => const Color(0xFF2B579A),
        OfficeKind.xlsx => const Color(0xFF217346),
        OfficeKind.pptx => const Color(0xFFD24726),
      };
}

class OfficeNew {
  /// Writes a blank document of [kind] named [rawName] (extension added when missing) into [dir]; returns its path.
  /// An existing file is never overwritten ("name (1).ext").
  static Future<String> create(String dir, OfficeKind kind, String rawName) async {
    var name = FileOps.checkName(rawName);
    if (!name.toLowerCase().endsWith('.${kind.ext}')) name = '$name.${kind.ext}';
    final target = FileOps.unique(dir, name);
    final data = await rootBundle.load('assets/templates/blank_${L.rtl ? 'fa' : 'en'}.${kind.ext}');
    await Saf.writeBytes(target, data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes));
    await Native.scan(target);
    return target;
  }
}

/// Asks for a name, creates a blank document of [kind] in [dir] and opens it in its editor.
Future<void> officeNewFile(BuildContext c, String dir, OfficeKind kind) async {
  if (!await ensureSdAll(c, [dir])) return;
  if (!c.mounted) return;
  final n = await promptText(c, kind.title, initial: kind.defaultName);
  if (n == null || n.trim().isEmpty) return;
  try {
    final t = await OfficeNew.create(dir, kind, n);
    if (!c.mounted) return;
    snack(c, '${L.t('saved')}: ${p.basename(t)}');
    await Opener.open(c, t);
  } catch (e) {
    if (c.mounted) snack(c, '$e');
  }
}

/// Bottom sheet with the three document types; the chosen one is created in [dir] and opened.
Future<void> officeNewPicker(BuildContext c, String dir) async {
  final k = await showModalBottomSheet<OfficeKind>(
    context: c,
    showDragHandle: true,
    builder: (ctx) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        for (final k in OfficeKind.values)
          ListTile(
            leading: Icon(k.icon, color: k.color, size: 30),
            title: Text(k.title),
            subtitle: Text('.${k.ext}'),
            onTap: () => Navigator.pop(ctx, k),
          ),
        const SizedBox(height: 8),
      ]),
    ),
  );
  if (k == null || !c.mounted) return;
  await officeNewFile(c, dir, k);
}

/// Bottom sheet with the Word / Excel / PowerPoint app icons. Tapping one lists the documents of that type in [dir]
/// (open with a tap) and offers to create a new one.
Future<void> officeAppsSheet(BuildContext c, String dir) async {
  final k = await showModalBottomSheet<OfficeKind>(
    context: c,
    showDragHandle: true,
    builder: (ctx) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(tr2('برنامه‌های آفیس', 'Office apps'), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
          const SizedBox(height: 14),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              for (final k in OfficeKind.values)
                InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => Navigator.pop(ctx, k),
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Container(
                        width: 64,
                        height: 64,
                        decoration: BoxDecoration(color: k.color, borderRadius: BorderRadius.circular(16)),
                        alignment: Alignment.center,
                        child: Text(switch (k) { OfficeKind.docx => 'W', OfficeKind.xlsx => 'X', OfficeKind.pptx => 'P' }, style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w800)),
                      ),
                      const SizedBox(height: 6),
                      Text(switch (k) { OfficeKind.docx => 'Word', OfficeKind.xlsx => 'Excel', OfficeKind.pptx => 'PowerPoint' }, style: const TextStyle(fontSize: 13)),
                    ]),
                  ),
                ),
            ]),
          ),
        ]),
      ),
    ),
  );
  if (k == null || !c.mounted) return;
  final exts = switch (k) { OfficeKind.docx => ['docx', 'doc', 'dotx'], OfficeKind.xlsx => ['xlsx', 'xlsm', 'xls'], OfficeKind.pptx => ['pptx', 'ppsx', 'pptm', 'ppt'] };
  final files = <String>[];
  try {
    for (final e in Directory(dir).listSync(followLinks: false)) {
      if (e is File && exts.contains(p.extension(e.path).replaceFirst('.', '').toLowerCase())) files.add(e.path);
    }
  } catch (_) {}
  files.sort((a, b) => p.basename(a).toLowerCase().compareTo(p.basename(b).toLowerCase()));
  final pick = await showModalBottomSheet<String>(
    context: c,
    showDragHandle: true,
    isScrollControlled: true,
    builder: (ctx) => SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * .7),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: Icon(Icons.add_circle_rounded, color: k.color, size: 30),
            title: Text(k.title),
            onTap: () => Navigator.pop(ctx, ''),
          ),
          const Divider(height: 1),
          Flexible(
            child: files.isEmpty
                ? Padding(padding: const EdgeInsets.all(24), child: Text(tr2('در این پوشه فایلی از این نوع نیست.', 'No files of this type in this folder.')))
                : ListView(shrinkWrap: true, children: [
                    for (final f in files)
                      ListTile(
                        leading: Icon(k.icon, color: k.color),
                        title: Text(p.basename(f), maxLines: 1, overflow: TextOverflow.ellipsis),
                        onTap: () => Navigator.pop(ctx, f),
                      ),
                  ]),
          ),
        ]),
      ),
    ),
  );
  if (pick == null || !c.mounted) return;
  if (pick.isEmpty) {
    await officeNewFile(c, dir, k);
  } else {
    await Opener.open(c, pick);
  }
}
