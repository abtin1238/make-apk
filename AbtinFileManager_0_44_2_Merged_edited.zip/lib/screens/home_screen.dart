import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../core/theme.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../widgets/adaptive_nav.dart';
import '../widgets/ui.dart';
import 'analyzer_screen.dart';
import 'browser_screen.dart';
import 'home_cats.dart';
import 'abtin_home.dart';
import 'home_looks.dart';
import 'home_variants.dart';
import 'search_screen.dart';

/// Home tab. The look depends on the chosen layout theme (Settings → App layout).
class HomeScreen extends StatelessWidget {
  final VoidCallback onOpenFiles;
  const HomeScreen({super.key, required this.onOpenFiles});

  void _go(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    final layout = context.select<AppSettings, String>((s) => s.layoutId);
    final look = context.select<AppSettings, String>((s) => s.look);
    if (look == 'abtin') return const AbtinHome();
    // look themes bring their own home (neon / gradient: quick tools; glass: quick access + folders)
    if ((look == 'neon' || look == 'gradient') && (layout == 'rail' || layout == 'classic')) return const ToolsHome();
    if (look == 'glass' && layout == 'classic') return const GlassHome();
    switch (layout) {
      case 'dashboard':
        return const DashboardHome();
      case 'drawer':
        return const ListHome();
      case 'rail':
        return const SectionsHome();
      case 'tabs':
        return const LauncherHome();
    }
    return _classic(context);
  }

  Widget _classic(BuildContext context) {
    final s = context.watch<AppSettings>();
    final cats = homeCats();
    return SafeArea(
      child: MaxWidth(width: 960, child: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(gradient: AppColors.grad, borderRadius: BorderRadius.circular(12)),
            child: Icon(iconFor('', true), color: Colors.white),
          ),
          const SizedBox(width: 12),
          const Expanded(child: Text('Abtin File Manager', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
          IconButton(icon: const Icon(Icons.search_rounded), onPressed: () => _go(context, const SearchScreen())),
        ]),
        const SizedBox(height: 16),
        for (final r in FileOps.roots()) _StorageCard(root: r, onTap: () => _go(context, BrowserScreen(initialPath: r.path, root: true))),
        const SizedBox(height: 8),
        GridView.count(
          crossAxisCount: (MediaQuery.of(context).size.width ~/ 130).clamp(3, 7), shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.05,
          children: [
            for (final c in cats)
              GradCard(
                onTap: () => _go(context, c.page),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(c.icon, size: 32, color: c.color),
                  const SizedBox(height: 8),
                  Text(L.t(c.key), style: const TextStyle(fontSize: 12), textAlign: TextAlign.center),
                ]),
              ),
          ],
        ),
        const SizedBox(height: 10),
        GradCard(
          onTap: () => _go(context, const AnalyzerScreen()),
          child: Row(children: [
            const Icon(Icons.pie_chart_rounded, color: AppColors.blue),
            const SizedBox(width: 12),
            Text(L.t('analyzer')),
          ]),
        ),
        if (s.recents.isNotEmpty) const SizedBox(height: 4),
      ])),
    );
  }
}

class _StorageCard extends StatelessWidget {
  final StorageRoot root;
  final VoidCallback onTap;
  const _StorageCard({required this.root, required this.onTap});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: FutureBuilder<List<int>>(
          future: Native.storage(root.path),
          builder: (c, snap) {
            final t = snap.data?[0] ?? 0, f = snap.data?[1] ?? 0;
            final used = t - f;
            return GradCard(
              onTap: onTap,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(root.sd ? Icons.sd_card_rounded : Icons.smartphone_rounded, color: AppColors.blue),
                  const SizedBox(width: 10),
                  Expanded(child: Text(root.sd ? '${L.t('sdcard')} (${root.name})' : L.t('internal'), style: const TextStyle(fontWeight: FontWeight.w600))),
                  Text(t == 0 ? '' : '${FileOps.fmt(used)} / ${FileOps.fmt(t)}', style: const TextStyle(fontSize: 12)),
                ]),
                const SizedBox(height: 10),
                ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: t == 0 ? 0 : used / t, minHeight: 8)),
              ]),
            );
          },
        ),
      );
}
