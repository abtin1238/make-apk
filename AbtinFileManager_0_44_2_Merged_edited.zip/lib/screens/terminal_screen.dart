import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../services/terminal_native.dart';

/// A lightweight, pipe-based Android shell screen. Caller supplies the working
/// directory; this screen intentionally does not offer a file picker.
class TerminalScreen extends StatefulWidget {
  final String cwd;
  const TerminalScreen({super.key, required this.cwd});

  @override
  State<TerminalScreen> createState() => _TerminalScreenState();
}

class _TerminalScreenState extends State<TerminalScreen> {
  static const _maxLogChars = 120000;
  final _native = TerminalNative();
  final _input = TextEditingController();
  final _inputFocus = FocusNode();
  final _scroll = ScrollController();
  final _history = <String>[];
  StreamSubscription<Map<String, dynamic>>? _events;

  String? _sessionId;
  String _cwd = '';
  String _log = '';
  String _status = 'در حال راه‌اندازی…';
  bool _starting = false;
  bool _rawMode = false;

  bool get _running => _sessionId != null;
  String get _prompt => 'android:${_cwd.isEmpty ? widget.cwd : _cwd}\$';

  @override
  void initState() {
    super.initState();
    // Subscribe before starting so even immediate shell output is observed.
    _events = _native.events.listen(
      _onEvent,
      onError: (Object error) {
        if (mounted) _append('\n[خطای stream: $error]\n');
      },
    );
    _start();
  }

  @override
  void dispose() {
    _events?.cancel();
    _input.dispose();
    _inputFocus.dispose();
    _scroll.dispose();
    final id = _sessionId;
    _sessionId = null;
    if (id != null) unawaited(_native.close(id).catchError((_) {}));
    super.dispose();
  }

  Future<void> _start() async {
    if (_starting || _running) return;
    setState(() {
      _starting = true;
      _status = 'در حال اتصال…';
    });
    try {
      final session = await _native.start(widget.cwd);
      if (!mounted) {
        unawaited(_native.close(session.id).catchError((_) {}));
        return;
      }
      setState(() {
        _sessionId = session.id;
        _cwd = session.cwd;
        _starting = false;
        _status = 'متصل';
      });
      _append('نشست shell در مسیر زیر آغاز شد:\n${session.cwd}\n');
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _starting = false;
        _status = 'اتصال ناموفق';
      });
      _append('[خطا] $error\n');
    }
  }

  void _onEvent(Map<String, dynamic> event) {
    if (!mounted || event['sessionId'] != _sessionId) return;
    switch (event['type']) {
      case 'output':
        final text = event['text'];
        if (text is String) _append(text);
        break;
      case 'exit':
        final code = event['exitCode'];
        setState(() {
          _sessionId = null;
          _status = 'پایان نشست${code == null ? '' : ' (کد $code)'}';
        });
        _append(
          '\n[نشست shell پایان یافت${code == null ? '' : '؛ کد خروج: $code'}]\n',
        );
        break;
    }
  }

  void _append(String text) {
    if (!mounted) return;
    setState(() {
      _log += text;
      if (_log.length > _maxLogChars) {
        _log =
            '[ابتدای خروجی برای محدودکردن حافظه حذف شد]\n'
            '${_log.substring(_log.length - _maxLogChars)}';
      }
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.jumpTo(_scroll.position.maxScrollExtent);
      }
    });
  }

  Future<void> _send() async {
    final text = _input.text;
    final id = _sessionId;
    if (id == null || text.isEmpty) return;
    _input.clear();
    _inputFocus.requestFocus();
    if (_history.isEmpty || _history.last != text) {
      _history.add(text);
      if (_history.length > 100) _history.removeAt(0);
    }
    _append('$_prompt $text${_rawMode ? '' : '\n'}');
    try {
      if (_rawMode) {
        await _native.writeRaw(id, text);
      } else {
        await _native.writeLine(id, text);
      }
    } catch (error) {
      _append('[خطای ورودی] $error\n');
    }
  }

  Future<void> _stop() async {
    final id = _sessionId;
    if (id == null) return;
    setState(() {
      _sessionId = null;
      _status = 'در حال توقف…';
    });
    try {
      await _native.close(id);
    } catch (error) {
      _append('[خطای توقف] $error\n');
    }
    if (mounted) setState(() => _status = 'متوقف');
  }

  Future<void> _showHistory() async {
    if (_history.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('تاریخچه خالی است')));
      return;
    }
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: ListView(
            shrinkWrap: true,
            children: [
              const ListTile(title: Text('تاریخچهٔ فرمان‌ها')),
              for (final command in _history.reversed)
                ListTile(
                  dense: true,
                  title: Text(
                    command,
                    textDirection: TextDirection.ltr,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  onTap: () => Navigator.pop(context, command),
                ),
            ],
          ),
        ),
      ),
    );
    if (selected != null && mounted) {
      _input
        ..text = selected
        ..selection = TextSelection.collapsed(offset: selected.length);
      _inputFocus.requestFocus();
    }
  }

  Future<void> _showHelp() async {
    await showDialog<void>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('راهنما و محدودیت‌ها'),
          content: const SingleChildScrollView(
            child: Text(
              'این ابزار یک /system/bin/sh واقعی را با دسترسی‌های خودِ اپ اجرا می‌کند. '
              'فرمان‌هایی که اجرا می‌کنید ممکن است فایل‌های قابل‌دسترسی اپ را حذف یا تغییر دهند؛ '
              'پیش از ارسال هر فرمان، اثر آن را بررسی کنید.\n\n'
              'این نشست PTY/TTY ندارد؛ بنابراین برنامه‌های تعاملی ترمینالی مانند vim و top '
              'و نیز Ctrl-C واقعی پشتیبانی نمی‌شوند. برای خاتمه‌دادن نشست از دکمهٔ توقف استفاده کنید.\n\n'
              'فقط /system/bin/sh مبنای این ابزار است. ابزارها و فرمان‌های دیگر به نسخهٔ Android '
              'و محیط دستگاه بستگی دارند و نصب‌بودن Python یا Git تضمین نمی‌شود. مسیر کاری باید '
              'پوشهٔ موجودی باشد که خود اپ به آن دسترسی دارد.',
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('متوجه شدم'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _closeScreen() async {
    await _stop();
    if (mounted) Navigator.of(context).maybePop();
  }

  @override
  Widget build(BuildContext context) {
    final dark = ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xFF080808),
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFF39D353),
        secondary: Color(0xFF8B949E),
        surface: Color(0xFF111111),
      ),
      cardColor: const Color(0xFF111111),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF101010),
        foregroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 52,
      ),
    );
    return Theme(
      data: dark,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: const Color(0xFF080808),
          appBar: AppBar(
            title: const Text('ترمینال', style: TextStyle(fontSize: 17)),
            actions: [
              if (_running)
                IconButton(
                  tooltip: 'توقف نشست',
                  onPressed: _stop,
                  icon: const Icon(Icons.stop_rounded, color: Colors.redAccent),
                )
              else
                IconButton(
                  tooltip: 'شروع نشست',
                  onPressed: _starting ? null : _start,
                  icon: const Icon(Icons.play_arrow_rounded),
                ),
              IconButton(
                tooltip: 'راهنما و هشدارها',
                onPressed: _showHelp,
                icon: const Icon(Icons.info_outline_rounded),
              ),
              IconButton(
                tooltip: 'بستن صفحه و نشست',
                onPressed: _closeScreen,
                icon: const Icon(Icons.close_rounded),
              ),
            ],
          ),
          body: SafeArea(
            child: Column(
              children: [
                _sessionBar(),
                Expanded(child: _terminalLog()),
                _extraKeys(),
                _inputBar(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sessionBar() => Padding(
    padding: const EdgeInsetsDirectional.fromSTEB(12, 3, 8, 3),
    child: Row(
      children: [
        Icon(
          _running ? Icons.circle : Icons.circle_outlined,
          size: 11,
          color: _running ? const Color(0xFF39D353) : Colors.orangeAccent,
        ),
        const SizedBox(width: 7),
        Expanded(
          child: Text(
            '${_status.toLowerCase()}  •  ${_cwd.isEmpty ? widget.cwd : _cwd}',
            textDirection: TextDirection.ltr,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
                fontSize: 10.5, color: Color(0xFF8B949E), fontFamily: 'monospace'),
          ),
        ),
        IconButton(
          tooltip: 'پاک‌کردن خروجی',
          onPressed: () => setState(() => _log = ''),
          icon: const Icon(Icons.delete_sweep_outlined),
        ),
        IconButton(
          tooltip: 'کپی کل خروجی',
          onPressed: _log.isEmpty
              ? null
              : () async {
                  await Clipboard.setData(ClipboardData(text: _log));
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('خروجی کپی شد')),
                    );
                  }
                },
          icon: const Icon(Icons.copy_rounded),
        ),
      ],
    ),
  );

  Widget _terminalLog() => Container(
    width: double.infinity,
    color: const Color(0xFF080808),
    padding: const EdgeInsets.fromLTRB(14, 6, 14, 10),
    child: Scrollbar(
      controller: _scroll,
      child: SingleChildScrollView(
        controller: _scroll,
        child: SelectableText(
          _log.isEmpty
              ? 'Android shell\nType a command below and press Enter.\n'
              : _log,
          textDirection: TextDirection.ltr,
          style: const TextStyle(
            fontFamily: 'monospace',
            fontSize: 13.5,
            height: 1.45,
            color: Color(0xFFE6EDF3),
          ),
        ),
      ),
    ),
  );

  void _insertInput(String value) {
    if (!_running) return;
    final old = _input.value;
    final selection = old.selection;
    final start = selection.isValid ? selection.start : old.text.length;
    final end = selection.isValid ? selection.end : old.text.length;
    final text = old.text.replaceRange(start, end, value);
    _input.value = TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: start + value.length),
    );
    _inputFocus.requestFocus();
  }

  Widget _extraKeys() => SizedBox(
        height: 38,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
          children: [
            for (final key in const ['ESC', 'TAB', '/', '-', '|', '~', '..', '*', '&&'])
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: OutlinedButton(
                  onPressed: !_running
                      ? null
                      : () => _insertInput(key == 'TAB' ? '  ' : key == 'ESC' ? '\u001b' : key),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFFB1BAC4),
                    side: const BorderSide(color: Color(0xFF30363D)),
                    padding: const EdgeInsets.symmetric(horizontal: 11),
                    minimumSize: const Size(38, 29),
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                    visualDensity: VisualDensity.compact,
                  ),
                  child: Text(key,
                      style: const TextStyle(fontFamily: 'monospace', fontSize: 11)),
                ),
              ),
          ],
        ),
      );

  Widget _inputBar() => Padding(
    padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        IconButton(
          tooltip: 'تاریخچهٔ فرمان‌ها',
          onPressed: _showHistory,
          icon: const Icon(Icons.history_rounded),
        ),
        IconButton(
          tooltip: _rawMode ? 'حالت خام روشن است' : 'ارسال خام (بدون Enter)',
          onPressed: () => setState(() => _rawMode = !_rawMode),
          color: _rawMode ? const Color(0xFF39D353) : null,
          icon: const Icon(Icons.keyboard_alt_outlined),
        ),
        Expanded(
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: TextField(
              controller: _input,
              focusNode: _inputFocus,
              enabled: _running,
              textInputAction: TextInputAction.send,
              onSubmitted: (_) => _send(),
              maxLines: 1,
              autocorrect: false,
              enableSuggestions: false,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 14),
              decoration: InputDecoration(
                isDense: true,
                hintText: _rawMode ? 'raw input' : 'command',
                hintStyle: const TextStyle(color: Color(0xFF6E7681)),
                prefixText: '$_prompt ',
                prefixStyle: const TextStyle(
                  fontFamily: 'monospace',
                  color: Color(0xFF39D353),
                  fontSize: 12,
                ),
                filled: true,
                fillColor: const Color(0xFF141414),
                contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 11),
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: Color(0xFF30363D))),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: Color(0xFF30363D))),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: const BorderSide(color: Color(0xFF39D353))),
              ),
            ),
          ),
        ),
        const SizedBox(width: 5),
        IconButton.filled(
          tooltip: _rawMode ? 'ارسال خام' : 'ارسال فرمان / Enter',
          onPressed: _running ? _send : null,
          style: IconButton.styleFrom(
            backgroundColor: const Color(0xFF238636),
            foregroundColor: Colors.white,
          ),
          icon: const Icon(Icons.keyboard_return_rounded),
        ),
      ],
    ),
  );
}
