import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Icon;
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../core/layouts.dart';
import '../core/office_prefs.dart';
import '../services/native.dart';
import '../services/pptx_service.dart';
import '../widgets/pptx_paint.dart';
import '../widgets/app_icon.dart';
import '../widgets/ui.dart';
import '../widgets/office_chrome.dart';
import 'color_editor.dart';
import 'saf_prompt.dart';
import 'office_new.dart';

/// .pptx / .ppsx viewer + editor. Every slide is drawn as it is laid out (text boxes, placeholders, pictures);
/// tap a shape to select it, double-tap (or the pencil) edits its text, the bar below moves / resizes / formats /
/// deletes it. Slides can be added, duplicated, reordered, deleted. Save overwrites the file, "save copy" writes
/// "<name> (edited).pptx".
class PptxScreen extends StatefulWidget {
  final String path;
  const PptxScreen({super.key, required this.path});
  @override
  State<PptxScreen> createState() => _PptxScreenState();
}

class _PptxScreenState extends State<PptxScreen> {
  PptxFile? x;
  int selSlide = -1, selShape = -1;
  int cur = 0; // slide shown in the editor
  final _undo = <(List<int>, Set<String>)>[];
  final _redo = <(List<int>, Set<String>)>[];
  final _thumbs = ScrollController();

  static const _historyLimit = 8;
  void _pushHistory(List<(List<int>, Set<String>)> stack, (List<int>, Set<String>) snap) {
    stack.add(snap);
    if (stack.length > _historyLimit) stack.removeAt(0);
  }

  /// Remembers the current state before a new edit and invalidates the old redo branch.
  void _snap() {
    final f = x;
    if (f == null) return;
    try {
      _pushHistory(_undo, f.snapshot());
      _redo.clear();
    } catch (_) {
      _undo.clear();
      _redo.clear();
    }
  }

  void _doUndo() {
    final f = x;
    if (f == null || _undo.isEmpty) return;
    (List<int>, Set<String>)? current;
    try {
      current = f.snapshot();
      f.restore(_undo.last);
    } catch (e) {
      final rollback = current;
      if (rollback != null) {
        try { f.restore(rollback); } catch (_) {}
      }
      if (mounted) snack(context, '$e');
      return;
    }
    final savedCurrent = current!;
    setState(() {
      _undo.removeLast();
      _pushHistory(_redo, savedCurrent);
      cur = f.slides.isEmpty ? 0 : cur.clamp(0, f.slides.length - 1).toInt();
      _clear();
    });
  }

  void _doRedo() {
    final f = x;
    if (f == null || _redo.isEmpty) return;
    (List<int>, Set<String>)? current;
    try {
      current = f.snapshot();
      f.restore(_redo.last);
    } catch (e) {
      final rollback = current;
      if (rollback != null) {
        try { f.restore(rollback); } catch (_) {}
      }
      if (mounted) snack(context, '$e');
      return;
    }
    final savedCurrent = current!;
    setState(() {
      _redo.removeLast();
      _pushHistory(_undo, savedCurrent);
      cur = f.slides.isEmpty ? 0 : cur.clamp(0, f.slides.length - 1).toInt();
      _clear();
    });
  }

  @override
  void dispose() {
    _thumbs.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    PptxFile.open(widget.path).then((v) {
      if (mounted) setState(() => x = v);
    }).catchError((e) {
      if (mounted) {
        snack(context, '$e');
        Navigator.pop(context);
      }
    });
  }

  PShape? get _sel {
    final f = x;
    if (f == null || selSlide < 0 || selSlide >= f.slides.length) return null;
    final sl = f.slides[selSlide];
    return selShape >= 0 && selShape < sl.shapes.length ? sl.shapes[selShape] : null;
  }

  void _clear() {
    selSlide = -1;
    selShape = -1;
  }

  Future<void> _save({required bool copy}) async {
    final f = x;
    if (f == null) return;
    if (!await ensureSdAll(context, [f.z.path])) return;
    try {
      if (copy) {
        final t = await f.z.saveCopy();
        Native.scan(t);
        if (mounted) snack(context, '${L.t('saved')}: ${p.basename(t)}');
      } else {
        await f.z.saveInPlace();
        Native.scan(f.z.path);
        if (mounted) {
          setState(() {});
          snack(context, '${L.t('saved')}: ${p.basename(f.z.path)}');
        }
      }
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _editText(PSlide s, PShape sh) async {
    final f = x!;
    if (sh.paras.isEmpty) return;
    final res = await showDialog<List<({int src, String text})>>(
      context: context,
      builder: (_) => _ParasDialog(initial: [for (final para in sh.paras) f.text(para)], fixed: sh.kind == PKind.table),
    );
    if (res == null) return;
    _snap();
    setState(() => f.applyParas(s, sh, res));
  }

  Future<void> _format(PSlide s, PShape sh) async {
    final f = x!;
    final info = sh.paras.isEmpty ? null : f.paraInfo(s, sh, sh.paras.first);
    final r = await showDialog<_Fmt>(
      context: context,
      builder: (_) => _FormatDialog(size: info?.sizePt ?? 18, bold: info?.bold ?? false, rgb: info?.rgb),
    );
    if (r == null) return;
    _snap();
    setState(() => f.setFormat(s, sh, sizePt: r.size, bold: r.bold, rgb: r.rgb));
  }

  Future<void> _addTextBox(PSlide s, int si) async {
    final f = x!;
    final ctl = TextEditingController();
    final t = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(tr2('افزودن کادر متن', 'Add text box')),
        content: TextField(controller: ctl, autofocus: true, minLines: 1, maxLines: 6),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(c)),
          FilledButton(onPressed: () => Navigator.pop(c, ctl.text), child: Text(L.t('ok'))),
        ],
      ),
    );
    if (t == null || t.trim().isEmpty) return;
    _snap();
    setState(() {
      final i = f.addTextBox(s, t);
      selSlide = si;
      selShape = i;
    });
  }

  Future<void> _addPicture(PSlide s, int si) async {
    final f = x!;
    final r = await FilePicker.platform.pickFiles(type: FileType.image);
    final path = r?.files.single.path;
    if (path == null) return;
    try {
      final bytes = await File(path).readAsBytes();
      final img = await decodeImageFromList(bytes);
      _snap();
      final i = f.addPicture(s, bytes, p.extension(path), img.width, img.height);
      if (i >= 0 && mounted) {
        setState(() {
          selSlide = si;
          selShape = i;
        });
      }
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Widget _bar(PSlide s, PShape sh) {
    final f = x!;
    final cs = Theme.of(context).colorScheme;
    void nudge(double dx, double dy) => f.moveShape(s, sh, dx, dy);
    return Material(
      color: cs.surface,
      elevation: 4,
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 54,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              if (sh.hasText) TextButton.icon(onPressed: sh.paras.isEmpty ? null : () => _editText(s, sh), icon: const Icon(Icons.edit_rounded, size: 18), label: Text(tr2('ویرایش متن', 'Edit text'))),
              if (sh.hasText) TextButton.icon(onPressed: sh.paras.isEmpty ? null : () => _format(s, sh), icon: const Icon(Icons.format_size_rounded, size: 18), label: Text(tr2('قالب‌بندی', 'Format'))),
              PopupMenuButton<String>(
                tooltip: tr2('چیدمان و اندازه', 'Arrange and size'),
                onSelected: (a) {
                  _snap();
                  setState(() {
                    if (a == 'left') nudge(-.01, 0);
                    if (a == 'right') nudge(.01, 0);
                    if (a == 'up') nudge(0, -.01);
                    if (a == 'down') nudge(0, .01);
                    if (a == 'rotate') f.rotateBy(s, sh, 15);
                    if (a == 'larger') f.scaleShape(s, sh, 1.1);
                    if (a == 'smaller') f.scaleShape(s, sh, .9);
                  });
                },
                itemBuilder: (_) => [
                  PopupMenuItem(value: 'left', child: Text(tr2('انتقال به چپ', 'Move left'))),
                  PopupMenuItem(value: 'right', child: Text(tr2('انتقال به راست', 'Move right'))),
                  PopupMenuItem(value: 'up', child: Text(tr2('انتقال به بالا', 'Move up'))),
                  PopupMenuItem(value: 'down', child: Text(tr2('انتقال به پایین', 'Move down'))),
                  PopupMenuItem(value: 'rotate', child: Text(tr2('چرخش ۱۵ درجه', 'Rotate 15°'))),
                  PopupMenuItem(value: 'larger', child: Text(tr2('بزرگ‌تر', 'Larger'))),
                  PopupMenuItem(value: 'smaller', child: Text(tr2('کوچک‌تر', 'Smaller'))),
                ],
                child: Padding(padding: const EdgeInsets.symmetric(horizontal: 12), child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.tune_rounded, color: cs.primary, size: 19), const SizedBox(width: 6), Text(tr2('چیدمان', 'Arrange'))])),
              ),
              IconButton(tooltip: L.t('delete'), icon: const Icon(Icons.delete_outline_rounded), onPressed: () async {
                if (await confirm(context, '${L.t('delete')}?')) {
                  _snap();
                  setState(() { f.deleteShape(s, sh); _clear(); });
                }
              }),
              IconButton(tooltip: tr2('لغو انتخاب', 'Deselect'), icon: const Icon(Icons.close_rounded), onPressed: () => setState(_clear)),
            ]),
          ),
        ),
      ),
    );
  }

  void _addSlide(PptxFile f, int from, {bool blank = true}) {
    _snap();
    setState(() {
      f.duplicate(from, blank: blank);
      cur = from + 1;
      _clear();
    });
  }

  Future<void> _slideActions(PptxFile f, int i) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (c) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.note_add_outlined), title: Text(L.t('newSlide')), onTap: () => Navigator.pop(c, 'blank')),
          ListTile(leading: const Icon(Icons.copy_outlined), title: Text(L.t('dupSlide')), onTap: () => Navigator.pop(c, 'dup')),
          ListTile(leading: const Icon(Icons.arrow_upward_rounded), title: Text(L.t('moveUp')), onTap: i > 0 ? () => Navigator.pop(c, 'up') : null),
          ListTile(leading: const Icon(Icons.arrow_downward_rounded), title: Text(L.t('moveDown')), onTap: i < f.slides.length - 1 ? () => Navigator.pop(c, 'down') : null),
          ListTile(leading: const Icon(Icons.delete_outline_rounded), title: Text(L.t('delete')), onTap: f.slides.length > 1 ? () => Navigator.pop(c, 'del') : null),
          const SizedBox(height: 8),
        ]),
      ),
    );
    if (action == null || !mounted) return;
    if (action == 'del' && (f.slides.length <= 1 || !await confirm(context, '${L.t('delete')}?'))) return;
    _snap();
    setState(() {
      final oldCur = cur;
      switch (action) {
        case 'blank':
          f.duplicate(i, blank: true);
          cur = oldCur > i ? oldCur + 1 : i + 1;
          break;
        case 'dup':
          f.duplicate(i);
          cur = oldCur > i ? oldCur + 1 : (oldCur == i ? i + 1 : oldCur);
          break;
        case 'up':
          if (i > 0) {
            f.move(i, -1);
            cur = oldCur == i ? i - 1 : (oldCur == i - 1 ? i : oldCur);
          }
          break;
        case 'down':
          if (i < f.slides.length - 1) {
            f.move(i, 1);
            cur = oldCur == i ? i + 1 : (oldCur == i + 1 ? i : oldCur);
          }
          break;
        case 'del':
          f.delete(i);
          cur = oldCur > i ? oldCur - 1 : (oldCur == i ? math.min(i, f.slides.length - 1) : oldCur);
          break;
      }
      _clear();
    });
  }

  Color get _accent => OfficePrefs.sel;

  void _goSlide(PptxFile f, int i) {
    final n = i.clamp(0, f.slides.length - 1).toInt();
    setState(() {
      cur = n;
      _clear();
    });
    if (_thumbs.hasClients) {
      final target = (n * 108.0 - 90).clamp(0.0, _thumbs.position.maxScrollExtent).toDouble();
      _thumbs.animateTo(target, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    }
  }

  Widget _filmstrip(PptxFile f, int c) {
    final aspect = (f.slideW / f.slideH).clamp(.5, 3.0).toDouble();
    Widget arrow(IconData ic, VoidCallback? onTap) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: Material(
            color: Color.lerp(OfficePrefs.strip, OfficePrefs.ink, .12),
            shape: const CircleBorder(),
            child: InkWell(customBorder: const CircleBorder(), onTap: onTap, child: SizedBox(width: 30, height: 30, child: Icon(ic, size: 22, color: onTap == null ? Colors.black26 : kOfficeInk))),
          ),
        );
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
        color: Color.lerp(OfficePrefs.strip, OfficePrefs.dark ? Colors.black : Colors.white, .5),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 128,
            child: Row(children: [
              arrow(Icons.chevron_left_rounded, c > 0 ? () => _goSlide(f, c - 1) : null),
              Expanded(
                child: ListView.builder(
                  controller: _thumbs,
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  itemCount: f.slides.length,
                  itemBuilder: (_, i) {
                    final selected = i == c;
                    return GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () => _goSlide(f, i),
                      onLongPress: () => _slideActions(f, i),
                      child: SizedBox(
                        width: 108,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 4),
                          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                                border: Border.all(color: selected ? _accent : OfficePrefs.line, width: selected ? 3 : 1),
                                boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 4, offset: Offset(0, 1))],
                              ),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(7),
                                child: AspectRatio(aspectRatio: aspect, child: IgnorePointer(child: RepaintBoundary(child: _canvas(f, f.slides[i], i)))),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text('${i + 1}', style: TextStyle(fontSize: 16, color: kOfficeInk, fontWeight: selected ? FontWeight.w800 : FontWeight.w500)),
                          ]),
                        ),
                      ),
                    );
                  },
                ),
              ),
              arrow(Icons.chevron_right_rounded, c < f.slides.length - 1 ? () => _goSlide(f, c + 1) : null),
            ]),
          ),
        ),
      ),
    );
  }

  /// Tool strip of the design: undo / text box / add slide / edit slide (icon above label).

  // ---------------------------------------------------------------- ribbon tabs / tools
  int _tab = 0; // 0 home, 1 insert, 2 design, 3 effects

  /// Flutter font family used to draw a typeface name of the file (null = default font).
  static String? fontFamilyFor(String? tf) {
    if (tf == null) return null;
    const m = {'Vazir': 'Vazir', 'Vazirmatn': 'Vazir', 'IRANSans': 'Vazir', 'B Titr': 'BTitr', 'Times New Roman': 'serif', 'Georgia': 'serif', 'Courier New': 'monospace', 'B Nazanin': 'serif'};
    return m[tf];
  }

  /// Shapes the text tools act on: the selected text shape, else every text shape of the slide.
  List<PShape> _targets(PSlide s) {
    final sel = _sel;
    if (sel != null && sel.hasText && sel.paras.isNotEmpty && identical(s, x!.slides[selSlide])) return [sel];
    return [for (final sh in s.shapes) if (sh.hasText && sh.paras.isNotEmpty) sh];
  }

  Future<void> _sheet(String title, Widget Function(BuildContext, StateSetter) body) {
    return showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Theme(
        data: officeTheme(context),
        child: SafeArea(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * .8),
            child: StatefulBuilder(
              builder: (ctx, set) => Column(mainAxisSize: MainAxisSize.min, children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                const SizedBox(height: 8),
                Flexible(child: SingleChildScrollView(padding: const EdgeInsets.fromLTRB(16, 0, 16, 16), child: body(ctx, set))),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  void _fontSheet(PptxFile f, PSlide s) {
    final t = _targets(s);
    if (t.isEmpty) return;
    final cur0 = f.fontOf(t.first);
    _sheet(tr2('نوع قلم', 'Font'), (ctx, set) => Column(children: [
          for (final name in kPptxFonts)
            ListTile(
              dense: true,
              title: Text(name, style: TextStyle(fontSize: 18, fontFamily: fontFamilyFor(name))),
              trailing: (f.fontOf(t.first) ?? cur0) == name ? Icon(Icons.check_rounded, color: kOfficeBlue) : null,
              onTap: () {
                _snap();
                setState(() {
                  for (final sh in t) {
                    f.setFont(s, sh, name);
                  }
                });
                set(() {});
              },
            ),
        ]));
  }

  void _paraSheet(PptxFile f, PSlide s) {
    final t = _targets(s);
    if (t.isEmpty) return;
    void apply(void Function(PShape) fn) {
      _snap();
      setState(() {
        for (final sh in t) {
          fn(sh);
        }
      });
    }

    Widget seg<T>(String label, List<(T, Widget)> items, T? value, void Function(T) on) => Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 6),
            Directionality(
              textDirection: TextDirection.ltr,
              child: SegmentedButton<T>(
                showSelectedIcon: false,
                emptySelectionAllowed: true,
                segments: [for (final it in items) ButtonSegment<T>(value: it.$1, label: it.$2)],
                selected: value == null ? <T>{} : {value},
                onSelectionChanged: (v) {
                  if (v.isNotEmpty) on(v.first);
                },
              ),
            ),
          ]),
        );
    final info = f.paraInfo(s, t.first, t.first.paras.first);
    final pl = f.paraList(s, t.first);
    final p0 = pl.isEmpty ? null : pl.first;
    String al = info.align;
    String? bu = p0?.bullet == null ? 'none' : (RegExp(r'^\d').hasMatch(p0!.bullet!) ? 'num' : 'dot');
    double? ls = p0?.lineSpacing, sb = p0?.spcBef, sa = p0?.spcAft;
    bool rtl = info.rtl;
    _sheet(tr2('پاراگراف', 'Paragraph'), (ctx, set) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          seg<String>(tr2('تراز', 'Alignment'), const [
            ('l', Icon(Icons.format_align_left_rounded)),
            ('ctr', Icon(Icons.format_align_center_rounded)),
            ('r', Icon(Icons.format_align_right_rounded)),
            ('just', Icon(Icons.format_align_justify_rounded)),
          ], al, (v) {
            apply((sh) => f.setFormat(s, sh, align: v));
            set(() => al = v);
          }),
          seg<String>(tr2('فهرست', 'List'), [
            ('none', Text(tr2('بدون', 'None'))),
            ('dot', const Icon(Icons.format_list_bulleted_rounded)),
            ('num', const Icon(Icons.format_list_numbered_rounded)),
          ], bu, (v) {
            apply((sh) => f.setParagraph(s, sh, bullet: v));
            set(() => bu = v);
          }),
          seg<double>(tr2('فاصلهٔ خطوط', 'Line spacing'), [for (final v in const [1.0, 1.15, 1.5, 2.0]) (v, Text(faDigits(v)))], ls == null ? null : ([1.0, 1.15, 1.5, 2.0].contains(ls) ? ls : null), (v) {
            apply((sh) => f.setParagraph(s, sh, lineSpacing: v));
            set(() => ls = v);
          }),
          seg<double>(tr2('فاصله قبل از پاراگراف', 'Space before'), [for (final v in const [0.0, 6.0, 12.0, 24.0]) (v, Text(faDigits(v.round())))], sb == null ? null : ([0.0, 6.0, 12.0, 24.0].contains(sb) ? sb : null), (v) {
            apply((sh) => f.setParagraph(s, sh, spcBef: v));
            set(() => sb = v);
          }),
          seg<double>(tr2('فاصله بعد از پاراگراف', 'Space after'), [for (final v in const [0.0, 6.0, 12.0, 24.0]) (v, Text(faDigits(v.round())))], sa == null ? null : ([0.0, 6.0, 12.0, 24.0].contains(sa) ? sa : null), (v) {
            apply((sh) => f.setParagraph(s, sh, spcAft: v));
            set(() => sa = v);
          }),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(tr2('جهت راست‌به‌چپ', 'Right-to-left')),
            value: rtl,
            onChanged: (v) {
              apply((sh) => f.setParagraph(s, sh, rtl: v));
              set(() => rtl = v);
            },
          ),
        ]));
  }

  void _designSheet(PptxFile f) {
    _sheet(tr2('طراحی', 'Design'), (ctx, set) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(tr2('یک طرح انتخاب کنید؛ رنگ‌های تم، پس‌زمینه و قلم‌های پیش‌فرض همهٔ اسلایدها عوض می‌شود. رنگ‌هایی که خودتان روی متن گذاشته‌اید دست نمی‌خورد.', 'Pick a design: theme colours, background and default fonts change on every slide. Colours you set on text yourself are kept.'), style: Theme.of(ctx).textTheme.bodySmall),
          const SizedBox(height: 10),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 1.55,
            children: [
              for (final d in kPptxDesigns)
                InkWell(
                  borderRadius: BorderRadius.circular(10),
                  onTap: () {
                    Navigator.pop(ctx);
                    _snap();
                    setState(() {
                      f.applyDesign(d);
                      _clear();
                    });
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: OfficePrefs.line),
                      gradient: d.grad != null ? LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [for (final g in d.grad!) _c(g)]) : null,
                      color: d.grad == null ? _c(d.bg) : null,
                    ),
                    padding: const EdgeInsets.all(10),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(tr2(d.fa, d.en), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14, color: _c(d.dark ? d.lt1 : d.dk1))),
                      const Spacer(),
                      Row(children: [for (final a in d.accents) Container(width: 16, height: 16, margin: const EdgeInsetsDirectional.only(end: 4), decoration: BoxDecoration(color: _c(a), shape: BoxShape.circle))]),
                    ]),
                  ),
                ),
            ],
          ),
        ]));
  }

  void _effectSheet(PptxFile f, int i) {
    final s = f.slides[i];
    var kind = f.transitionOf(s);
    var speed = f.transitionSpeedOf(s);
    _sheet(tr2('افکت اسلاید', 'Slide effect'), (ctx, set) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final e in kPptxTransitions.entries)
              ChoiceChip(
                label: Text(tr2(e.value.$1, e.value.$2)),
                selected: kind == e.key,
                onSelected: (_) {
                  _snap();
                  setState(() => f.setTransition(s, e.key, speed: speed));
                  set(() => kind = e.key);
                },
              ),
          ]),
          const SizedBox(height: 14),
          Text(tr2('سرعت', 'Speed'), style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Directionality(
            textDirection: TextDirection.ltr,
            child: SegmentedButton<String>(
              showSelectedIcon: false,
              segments: [
                ButtonSegment(value: 'slow', label: Text(tr2('آهسته', 'Slow'))),
                ButtonSegment(value: 'med', label: Text(tr2('متوسط', 'Medium'))),
                ButtonSegment(value: 'fast', label: Text(tr2('سریع', 'Fast'))),
              ],
              selected: {speed},
              onSelectionChanged: (v) {
                speed = v.first;
                _snap();
                setState(() => f.setTransition(s, kind, speed: speed));
                set(() {});
              },
            ),
          ),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(
              child: OutlinedButton.icon(
                icon: const Icon(Icons.done_all_rounded, size: 20),
                label: Text(tr2('اعمال روی همهٔ اسلایدها', 'Apply to all slides')),
                onPressed: () {
                  _snap();
                  setState(() => f.setTransitionAll(kind, speed: speed));
                  snack(context, L.t('done'));
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: FilledButton.icon(
                icon: const Icon(Icons.play_arrow_rounded, size: 20),
                label: Text(tr2('پیش‌نمایش', 'Preview')),
                onPressed: () {
                  Navigator.pop(ctx);
                  _present(f);
                },
              ),
            ),
          ]),
        ]));
  }

  Future<void> _addPictureFromRibbon(PptxFile f, int i) => _addPicture(f.slides[i], i);

  Widget _ribbon(PptxFile f, int i) {
    final slide = f.slides[i];
    final selected = _sel;
    final canEditShape = selected != null && selected.hasText && selected.paras.isNotEmpty;
    final hasText = _targets(slide).isNotEmpty;
    Widget cmd(IconData icon, String label, VoidCallback? onTap, {Widget Function(Color)? glyph}) => SizedBox(
          width: 82,
          child: InkWell(
            onTap: onTap,
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              SizedBox(height: 32, child: Center(child: glyph != null ? glyph(onTap == null ? kOfficeInk.withOpacity(.3) : kOfficeInk) : Icon(icon, size: 30, color: onTap == null ? kOfficeInk.withOpacity(.3) : kOfficeInk))),
              const SizedBox(height: 3),
              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13.5, color: onTap == null ? kOfficeInk.withOpacity(.35) : kOfficeInk)),
            ]),
          ),
        );
    final tabs = [tr2('خانه', 'Home'), tr2('درج', 'Insert'), tr2('طراحی', 'Design'), tr2('افکت‌ها', 'Effects')];
    final List<Widget> items = switch (_tab) {
      1 => [
          cmd(Icons.image_outlined, tr2('تصویر', 'Picture'), () => _addPictureFromRibbon(f, i)),
          cmd(Icons.title_rounded, tr2('کادر متن', 'Text box'), () => _addTextBox(slide, i), glyph: (c) => Text('T', style: TextStyle(fontSize: 34, fontFamily: 'serif', color: c, height: 1, fontWeight: FontWeight.w500))),
          cmd(Icons.add_box_outlined, tr2('اسلاید جدید', 'New slide'), () => _addSlide(f, i)),
          cmd(Icons.copy_rounded, tr2('کپی اسلاید', 'Duplicate'), () => _slideActions(f, i)),
        ],
      2 => [
          cmd(Icons.palette_outlined, tr2('طرح‌ها', 'Designs'), () => _designSheet(f)),
        ],
      3 => [
          cmd(Icons.auto_awesome_motion_rounded, tr2('افکت اسلاید', 'Transition'), () => _effectSheet(f, i)),
          cmd(Icons.slideshow_rounded, tr2('پیش‌نمایش', 'Preview'), () => _present(f)),
      ],
      _ => [
          cmd(Icons.undo_rounded, tr2('بازگشت', 'Undo'), _undo.isEmpty ? null : _doUndo),
          cmd(Icons.redo_rounded, tr2('انجام دوباره', 'Redo'), _redo.isEmpty ? null : _doRedo),
          cmd(Icons.title_rounded, tr2('متن', 'Text'), () => _addTextBox(slide, i), glyph: (c) => Text('T', style: TextStyle(fontSize: 34, fontFamily: 'serif', color: c, height: 1, fontWeight: FontWeight.w500))),
          cmd(Icons.add_box_outlined, tr2('افزودن اسلاید', 'Add slide'), () => _addSlide(f, i)),
          cmd(Icons.edit_square, tr2('ویرایش اسلاید', 'Edit slide'), canEditShape ? () => _editText(f.slides[selSlide], selected!) : () => _slideActions(f, i)),
          cmd(Icons.font_download_outlined, tr2('نوع قلم', 'Font'), hasText ? () => _fontSheet(f, slide) : null),
          cmd(Icons.format_align_right_rounded, tr2('پاراگراف', 'Paragraph'), hasText ? () => _paraSheet(f, slide) : null),
          cmd(Icons.format_size_rounded, tr2('قالب‌بندی', 'Format'), canEditShape ? () => _format(f.slides[selSlide], selected!) : null),
        ],
    };
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Container(
        decoration: BoxDecoration(color: kOfficeStrip, border: Border(bottom: BorderSide(color: OfficePrefs.line))),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          SizedBox(
            height: 38,
            child: Row(children: [
              for (var k = 0; k < tabs.length; k++)
                Expanded(
                  child: InkWell(
                    onTap: () => setState(() => _tab = k),
                    child: Container(
                      alignment: Alignment.center,
                      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: _tab == k ? OfficePrefs.sel : Colors.transparent, width: 3))),
                      child: Text(tabs[k], style: TextStyle(fontSize: 15, fontWeight: _tab == k ? FontWeight.w800 : FontWeight.w500, color: _tab == k ? OfficePrefs.sel : kOfficeInk)),
                    ),
                  ),
                ),
            ]),
          ),
          SizedBox(
            height: 76,
            child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Row(children: items)),
          ),
        ]),
      ),
    );
  }

  Widget _editor(PptxFile f) {
    final c = cur.clamp(0, f.slides.length - 1).toInt();
    return Column(children: [
      _ribbon(f, c),
      Expanded(
        child: LayoutBuilder(builder: (context, cons) {
          final aspect = (f.slideW / f.slideH).clamp(.5, 3.0).toDouble();
          final maxW = math.max(1.0, cons.maxWidth - 22);
          final maxH = math.max(1.0, cons.maxHeight - 22);
          final slideW = math.min(maxW, maxH * aspect);
          return Container(
            color: Color.lerp(OfficePrefs.bg, Colors.black, .02),
            width: double.infinity,
            child: Center(
              child: Material(
                color: Colors.white,
                elevation: 3,
                borderRadius: BorderRadius.circular(4),
                clipBehavior: Clip.antiAlias,
                child: SizedBox(width: slideW, child: RepaintBoundary(child: _canvas(f, f.slides[c], c))),
              ),
            ),
          );
        }),
      ),
      _filmstrip(f, c),
    ]);
  }

  void _present(PptxFile f) {
    setState(_clear);
    Navigator.push(
      context,
      PageRouteBuilder<void>(
        opaque: true,
        pageBuilder: (_, __, ___) => _SlideShow(
          kinds: [for (final sl in f.slides) f.transitionOf(sl)],
          speeds: [for (final sl in f.slides) f.transitionSpeedOf(sl)],
          count: f.slides.length,
          start: cur.clamp(0, f.slides.length - 1).toInt(),
          aspect: (f.slideW / f.slideH).toDouble(),
          build: (i, w) => SizedBox(width: w, child: IgnorePointer(child: _canvas(f, f.slides[i], i))),
        ),
      ),
    );
  }

  Color _c(int rgb, [double a = 1]) => Color(0xFF000000 | (rgb & 0xFFFFFF)).withOpacity(a);

  double _gx = 0, _gy = 0;

  Widget _canvas(PptxFile f, PSlide s, int si) {
    return LayoutBuilder(builder: (context, cons) {
      final w = cons.maxWidth;
      final k = w / f.slideW; // px per EMU
      final h = f.slideH * k;
      final pt = k * 12700; // px per point
      final bg = s.bg;
      final bgBase = bg.rgb ?? (bg.grad != null ? bg.grad!.first : 0xFFFFFF);
      final bgc = _c(bgBase);
      final defText = bgc.computeLuminance() < .4 ? Colors.white : Colors.black;
      BoxDecoration deco;
      if (bg.image != null) {
        deco = BoxDecoration(color: bgc, image: DecorationImage(image: MemoryImage(bg.image!), fit: BoxFit.cover));
      } else if (bg.grad != null) {
        final a = bg.gradAngle * math.pi / 180;
        deco = BoxDecoration(gradient: LinearGradient(colors: [for (final g in bg.grad!) _c(g)], begin: Alignment(-math.cos(a), -math.sin(a)), end: Alignment(math.cos(a), math.sin(a))));
      } else {
        deco = BoxDecoration(color: bgc);
      }
      return SizedBox(
        width: w,
        height: h,
        child: ClipRect(
          child: Stack(children: [
            Positioned.fill(child: GestureDetector(onTap: () => setState(_clear), child: DecoratedBox(decoration: deco))),
            for (final sh in s.backShapes) _place(f, s, si, -1, sh, k, pt, defText),
            for (var j = 0; j < s.shapes.length; j++) _place(f, s, si, j, s.shapes[j], k, pt, defText),
          ]),
        ),
      );
    });
  }

  Widget _place(PptxFile f, PSlide s, int si, int j, PShape sh, double k, double pt, Color defText) {
    final selected = j >= 0 && selSlide == si && selShape == j;
    final primary = Theme.of(context).colorScheme.primary;
    final bw = math.max(1.0, sh.w * k), bh = math.max(1.0, sh.h * k);
    Widget body = _body(f, s, sh, k, pt, defText);
    if (j < 0) {
      return Positioned(left: sh.x * k, top: sh.y * k, width: bw, height: bh, child: IgnorePointer(child: Transform.rotate(angle: sh.rot * math.pi / 180, child: body)));
    }
    final canDrag = selected && sh.movable;
    Widget content = Stack(clipBehavior: Clip.none, children: [
      Positioned.fill(child: body),
      Positioned.fill(
        child: IgnorePointer(
          child: DecoratedBox(decoration: BoxDecoration(border: selected ? Border.all(color: primary, width: 2) : null)),
        ),
      ),
      if (canDrag)
        Positioned(
          right: 2,
          bottom: 2,
          width: 24,
          height: 24,
          child: GestureDetector(
            onPanStart: (d) {
              _snap();
              _gx = d.globalPosition.dx;
              _gy = d.globalPosition.dy;
            },
            onPanUpdate: (d) {
              final dx = d.globalPosition.dx - _gx, dy = d.globalPosition.dy - _gy;
              _gx = d.globalPosition.dx;
              _gy = d.globalPosition.dy;
              final r = sh.rot * math.pi / 180;
              final lw = dx * math.cos(r) + dy * math.sin(r), lh = -dx * math.sin(r) + dy * math.cos(r);
              setState(() => f.resizeBy(s, sh, lw / k, lh / k, keepAspect: sh.isPic));
            },
            child: Container(decoration: BoxDecoration(color: primary, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2))),
          ),
        ),
    ]);
    return Positioned(
      left: sh.x * k,
      top: sh.y * k,
      width: bw,
      height: bh,
      child: Transform.rotate(
        angle: sh.rot * math.pi / 180,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => setState(() {
            selSlide = si;
            selShape = j;
          }),
          onDoubleTap: sh.hasText ? () => _editText(s, sh) : null,
          onPanStart: canDrag
              ? (d) {
                  _snap();
                  _gx = d.globalPosition.dx;
                  _gy = d.globalPosition.dy;
                }
              : null,
          onPanUpdate: canDrag
              ? (d) {
                  final dx = d.globalPosition.dx - _gx, dy = d.globalPosition.dy - _gy;
                  _gx = d.globalPosition.dx;
                  _gy = d.globalPosition.dy;
                  setState(() => f.moveBy(s, sh, dx / k, dy / k));
                }
              : null,
          child: content,
        ),
      ),
    );
  }

  Widget _body(PptxFile f, PSlide s, PShape sh, double k, double pt, Color defText) {
    switch (sh.kind) {
      case PKind.pic:
        return sh.image == null ? const SizedBox() : Image.memory(sh.image!, fit: BoxFit.fill, errorBuilder: (_, __, ___) => const SizedBox());
      case PKind.chart:
        return sh.chart == null ? const SizedBox() : CustomPaint(painter: ChartPainter(sh.chart!, defText));
      case PKind.smart:
        return Stack(children: [
          for (final n in sh.smart ?? const <PSmartNode>[])
            Positioned(
              left: n.x * k,
              top: n.y * k,
              width: math.max(1.0, n.w * k),
              height: math.max(1.0, n.h * k),
              child: Transform.rotate(
                angle: n.rot * math.pi / 180,
                child: Stack(children: [
                  Positioned.fill(child: CustomPaint(painter: ShapePainter(geom: n.geom, adj: 16667, cust: const [], fill: n.fill, line: n.line, fillAlpha: 1, grad: null, gradAngle: 90, linePx: n.line == null ? 0 : 1, flipH: false, flipV: false))),
                  Positioned.fill(
                    child: Padding(
                      padding: EdgeInsets.all(math.max(1.0, 45720 * k)),
                      child: Center(
                        child: n.paras.isNotEmpty
                            ? _paras(f.cellParas(s, n.paras, defaultPt: 14), k, pt, n.fill != null && _c(n.fill!).computeLuminance() < .5 ? Colors.white : defText, center: true)
                            : Text(n.plain, textAlign: TextAlign.center, style: TextStyle(fontSize: 14 * pt, color: Colors.white)),
                      ),
                    ),
                  ),
                ]),
              ),
            ),
        ]);
      case PKind.table:
        return _table(f, s, sh, k, pt, defText);
      case PKind.text:
        break;
    }
    final hasGeom = sh.fill != null || sh.grad != null || (sh.line != null && sh.lineW > 0);
    final paras = f.paraList(s, sh);
    Color txt = defText;
    if (sh.fill != null && sh.fillAlpha > .5 && sh.fontClr == null) txt = _c(sh.fill!).computeLuminance() < .45 ? Colors.white : Colors.black;
    final anchor = sh.anchor == 'ctr' ? Alignment.center : (sh.anchor == 'b' ? Alignment.bottomCenter : Alignment.topCenter);
    return Stack(children: [
      if (hasGeom)
        Positioned.fill(
          child: CustomPaint(painter: ShapePainter(geom: sh.geom, adj: sh.adj, cust: sh.cust, fill: sh.fill, line: sh.line, fillAlpha: sh.fillAlpha, grad: sh.grad, gradAngle: sh.gradAngle, linePx: sh.lineW * k, flipH: sh.flipH, flipV: sh.flipV)),
        ),
      if (paras.isNotEmpty)
        Positioned.fill(
          child: ClipRect(
            child: Padding(
              padding: EdgeInsets.fromLTRB(sh.insL * k, sh.insT * k, sh.insR * k, sh.insB * k),
              child: OverflowBox(alignment: anchor, minHeight: 0, maxHeight: double.infinity, child: _paras(paras, k, pt, txt)),
            ),
          ),
        ),
    ]);
  }

  Widget _paras(List<PPara> list, double k, double pt, Color defText, {bool center = false, bool bold = false}) {
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [for (final pp in list) _para(pp, k, pt, defText, center, bold)]);
  }

  Widget _para(PPara pp, double k, double pt, Color defText, bool center, bool bold) {
    final align = center ? TextAlign.center : (pp.align == 'ctr' ? TextAlign.center : (pp.align == 'r' ? TextAlign.right : (pp.align == 'just' ? TextAlign.justify : TextAlign.left)));
    final spans = <InlineSpan>[
      for (final r in pp.runs)
        TextSpan(
          text: r.text,
          style: TextStyle(
            fontSize: r.sizePt * pt * (r.baseline != 0 ? .7 : 1),
            height: 1.15 * pp.lineSpacing,
            fontWeight: (r.bold || bold) ? FontWeight.bold : FontWeight.normal,
            fontStyle: r.italic ? FontStyle.italic : FontStyle.normal,
            decoration: TextDecoration.combine([if (r.underline) TextDecoration.underline, if (r.strike) TextDecoration.lineThrough]),
            color: r.rgb == null ? defText : _c(r.rgb!),
            fontFamily: _PptxScreenState.fontFamilyFor(r.font),
          ),
        ),
    ];
    final hasText = pp.runs.any((r) => r.text.trim().isNotEmpty);
    final txt = Text.rich(
      TextSpan(children: spans.isEmpty ? [TextSpan(text: ' ', style: TextStyle(fontSize: pp.sizePt * pt, height: 1.15))] : spans),
      textAlign: align,
    );
    Widget child = txt;
    if (pp.bullet != null && hasText) {
      final hang = pp.indent < 0 ? -pp.indent * k : pp.sizePt * pt * 1.1;
      child = Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: hang, child: Text(pp.bullet!, style: TextStyle(fontSize: pp.sizePt * pt, height: 1.15 * pp.lineSpacing, color: pp.bulletRgb == null ? defText : _c(pp.bulletRgb!)))),
        Expanded(child: txt),
      ]);
    }
    final startPad = pp.bullet != null && pp.indent < 0 ? math.max(0.0, (pp.marL + pp.indent) * k) : math.max(0.0, pp.marL * k);
    return Directionality(
      textDirection: pp.rtl ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: EdgeInsetsDirectional.only(start: startPad, top: pp.spcBef * pt, bottom: pp.spcAft * pt),
        child: child,
      ),
    );
  }

  Widget _table(PptxFile f, PSlide s, PShape sh, double k, double pt, Color defText) {
    final t = sh.table!;
    final rows = <Widget>[];
    for (var r = 0; r < t.rows.length; r++) {
      final cells = <Widget>[];
      var col = 0;
      for (final cell in t.rows[r]) {
        final span = cell.gridSpan < 1 ? 1 : cell.gridSpan;
        var cw = 0.0;
        for (var c = col; c < col + span && c < t.colW.length; c++) {
          cw += t.colW[c];
        }
        col += span;
        if (cell.hMerge) continue;
        int? fill = cell.fill;
        var header = false;
        if (fill == null && t.firstRow && r == 0) {
          fill = t.accent;
          header = true;
        } else if (fill == null && t.bandRow && r.isOdd) {
          fill = 0xE9EBF5;
        }
        final dark = fill != null && _c(fill).computeLuminance() < .5;
        cells.add(SizedBox(
          width: math.max(1.0, cw * k),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 91440 * k, vertical: 45720 * k),
            decoration: BoxDecoration(color: fill == null ? null : _c(fill), border: Border.all(color: Colors.grey.withOpacity(.55), width: .5)),
            child: _paras(f.cellParas(s, cell.paras), k, pt, dark ? Colors.white : (fill == null ? defText : Colors.black), bold: header),
          ),
        ));
      }
      rows.add(ConstrainedBox(constraints: BoxConstraints(minHeight: t.rowH[r] * k), child: IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: cells))));
    }
    return ClipRect(child: OverflowBox(alignment: Alignment.topLeft, minHeight: 0, maxHeight: double.infinity, child: Column(mainAxisSize: MainAxisSize.min, children: rows)));
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    final sel = _sel;
    return PopScope(
      canPop: f == null || !f.z.changed,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await confirm(context, tr2('تغییرات ذخیره‌نشده از بین می‌رود. خارج می‌شوید؟', 'Unsaved changes will be lost. Leave?')) && context.mounted) {
          Navigator.pop(context);
        }
      },
      child: Theme(
        data: officeTheme(context),
        child: Scaffold(
          backgroundColor: kOfficeBg,
          bottomNavigationBar: f == null || sel == null ? null : _bar(f.slides[selSlide], sel),
          body: Column(children: [
            OfficeTopBar(
              title: p.basename(widget.path),
              actions: [
                officeAction(Icons.apps_rounded, () => officeAppsSheet(context, p.dirname(widget.path)), tip: tr2('برنامه‌های آفیس', 'Office apps')),
                officeAction(Icons.slideshow_rounded, f == null ? null : () => _present(f), tip: tr2('نمایش اسلاید', 'Present')),
                PopupMenuButton<String>(
                  icon: const Icon(Icons.more_vert_rounded, color: Colors.white, size: 26),
                  onSelected: (action) {
                    if (action == 'save') _save(copy: false);
                    if (action == 'copy') _save(copy: true);
                    if (action == 'open') Native.openWith(widget.path, title: L.t('openWith'));
                    if (action == 'new') officeNewFile(context, p.dirname(widget.path), OfficeKind.pptx);
                    if (action == 'text' && f != null) _addTextBox(f.slides[cur.clamp(0, f.slides.length - 1).toInt()], cur.clamp(0, f.slides.length - 1).toInt());
                    if (action == 'pic' && f != null) _addPicture(f.slides[cur.clamp(0, f.slides.length - 1).toInt()], cur.clamp(0, f.slides.length - 1).toInt());
                  },
                  itemBuilder: (_) => [
                    PopupMenuItem(value: 'new', child: Text(tr2('ارائهٔ جدید', 'New presentation'))),
                    PopupMenuItem(value: 'text', enabled: f != null, child: Text(tr2('افزودن کادر متن', 'Add text box'))),
                    PopupMenuItem(value: 'pic', enabled: f != null, child: Text(tr2('افزودن تصویر', 'Add picture'))),
                    PopupMenuItem(value: 'save', enabled: f != null && f.z.changed, child: Text(L.t('save'))),
                    PopupMenuItem(value: 'copy', child: Text(L.t('saveCopy'))),
                    PopupMenuItem(value: 'open', child: Text(L.t('openWith'))),
                  ],
                ),
              ],
            ),
            Expanded(child: f == null ? const Center(child: CircularProgressIndicator()) : _editor(f)),
          ]),
        ),
      ),
    );
  }
}

class _ParasDialog extends StatefulWidget {
  final List<String> initial;
  final bool fixed; // table cells: paragraphs can not be added / removed
  const _ParasDialog({required this.initial, this.fixed = false});
  @override
  State<_ParasDialog> createState() => _ParasDialogState();
}

class _Row {
  final int src;
  final TextEditingController c;
  _Row(this.src, String t) : c = TextEditingController(text: t);
}

class _ParasDialogState extends State<_ParasDialog> {
  late final List<_Row> rows = [for (var i = 0; i < widget.initial.length; i++) _Row(i, widget.initial[i])];

  @override
  void dispose() {
    for (final r in rows) {
      r.c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(tr2('ویرایش متن', 'Edit text')),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              for (var i = 0; i < rows.length; i++)
                Row(children: [
                  Expanded(child: TextField(controller: rows[i].c, minLines: 1, maxLines: 6, autofocus: i == 0)),
                  IconButton(
                    icon: const Icon(Icons.remove_circle_outline_rounded, size: 20),
                    tooltip: L.t('delete'),
                    onPressed: widget.fixed || rows.length <= 1 ? null : () => setState(() => rows.removeAt(i).c.dispose()),
                  ),
                ]),
              if (!widget.fixed)
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: TextButton.icon(
                  icon: const Icon(Icons.add_rounded, size: 20),
                  label: Text(tr2('پاراگراف جدید', 'New paragraph')),
                  onPressed: () => setState(() => rows.add(_Row(-1, ''))),
                ),
              ),
            ]),
          ),
        ),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(context)),
          FilledButton(
            onPressed: () => Navigator.pop(context, [for (final r in rows) (src: r.src, text: r.c.text)]),
            child: Text(L.t('ok')),
          ),
        ],
      );
}

class _Fmt {
  final double? size;
  final bool? bold;
  final int? rgb;
  const _Fmt(this.size, this.bold, this.rgb);
}

class _FormatDialog extends StatefulWidget {
  final double size;
  final bool bold;
  final int? rgb;
  const _FormatDialog({required this.size, required this.bold, required this.rgb});
  @override
  State<_FormatDialog> createState() => _FormatDialogState();
}

class _FormatDialogState extends State<_FormatDialog> {
  late double size = widget.size.clamp(6, 120).toDouble();
  late bool bold = widget.bold;
  int? rgb;
  bool colorChanged = false;

  @override
  void initState() {
    super.initState();
    rgb = widget.rgb;
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(tr2('قالب‌بندی متن', 'Text format')),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text('${tr2('اندازه', 'Size')}: ${size.round()} pt'),
              LSlider(value: size, min: 6, max: 120, onChanged: (v) => setState(() => size = v)),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(tr2('ضخیم', 'Bold')), value: bold, onChanged: (v) => setState(() => bold = v)),
              const SizedBox(height: 6),
              Text(tr2('رنگ متن', 'Text colour')),
              const SizedBox(height: 6),
              ColorPickerPanel(
                color: Color(0xFF000000 | (rgb ?? 0x000000)),
                onChanged: (_) {},
                onCommit: (c) => setState(() {
                  rgb = c.value & 0xFFFFFF;
                  colorChanged = true;
                }),
              ),
            ]),
          ),
        ),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(context)),
          FilledButton(onPressed: () => Navigator.pop(context, _Fmt(size, bold, colorChanged ? rgb : null)), child: Text(L.t('ok'))),
        ],
      );
}

/// Full-screen slide show: tap right / left edge or swipe to move, centre tap shows the controls, optional auto-play.
class _SlideShow extends StatefulWidget {
  final int count, start;
  final double aspect;
  final Widget Function(int index, double width) build;
  final List<String> kinds, speeds; // transition INTO each slide
  const _SlideShow({required this.count, required this.start, required this.aspect, required this.build, this.kinds = const [], this.speeds = const []});
  @override
  State<_SlideShow> createState() => _SlideShowState();
}

class _SlideShowState extends State<_SlideShow> {
  late int i = widget.start;
  bool ui = true, auto = false;
  Timer? _hideT, _autoT;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    _hideLater();
  }

  @override
  void dispose() {
    _hideT?.cancel();
    _autoT?.cancel();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    super.dispose();
  }

  void _hideLater() {
    _hideT?.cancel();
    _hideT = Timer(const Duration(seconds: 3), () { if (mounted) setState(() => ui = false); });
  }

  void _go(int d) {
    final n = i + d;
    if (n < 0 || n > widget.count) return;
    setState(() => i = n);
    if (n >= widget.count) _setAuto(false);
  }

  void _setAuto(bool v) {
    _autoT?.cancel();
    setState(() => auto = v);
    if (v) _autoT = Timer.periodic(const Duration(seconds: 5), (_) { if (mounted) _go(1); });
  }

  String _kind() => i >= 0 && i < widget.kinds.length ? widget.kinds[i] : 'none';

  Duration _dur() {
    final k = _kind();
    if (k == 'none') return Duration.zero;
    final sp = i >= 0 && i < widget.speeds.length ? widget.speeds[i] : 'med';
    return Duration(milliseconds: sp == 'slow' ? 1000 : (sp == 'fast' ? 250 : 550));
  }

  /// Plays the slide effect: the incoming slide (key == current index) animates in, the outgoing one out.
  Widget _trans(Widget child, Animation<double> a) {
    final incoming = child.key == ValueKey(i);
    final k = _kind();
    final curved = CurvedAnimation(parent: a, curve: Curves.easeInOut);
    switch (k) {
      case 'push':
        return SlideTransition(position: Tween(begin: incoming ? const Offset(1, 0) : const Offset(-1, 0), end: Offset.zero).animate(curved), child: child);
      case 'cover':
        return incoming ? SlideTransition(position: Tween(begin: const Offset(1, 0), end: Offset.zero).animate(curved), child: child) : child;
      case 'uncover':
        return incoming ? child : SlideTransition(position: Tween(begin: const Offset(-1, 0), end: Offset.zero).animate(curved), child: child);
      case 'wipe':
      case 'split':
      case 'randomBar':
        return AnimatedBuilder(animation: curved, child: child, builder: (_, c) => ClipRect(child: Align(alignment: Alignment.centerLeft, widthFactor: incoming ? curved.value.clamp(0.01, 1.0).toDouble() : 1, child: c)));
      case 'zoom':
      case 'circle':
      case 'diamond':
      case 'plus':
      case 'wheel':
        return FadeTransition(opacity: curved, child: ScaleTransition(scale: Tween(begin: incoming ? .6 : 1.4, end: 1.0).animate(curved), child: child));
      default:
        return FadeTransition(opacity: curved, child: child);
    }
  }

  @override
  Widget build(BuildContext context) {
    final ended = i >= widget.count;
    return Scaffold(
      backgroundColor: Colors.black,
      body: LayoutBuilder(builder: (context, cons) {
        final w = math.min(cons.maxWidth, cons.maxHeight * widget.aspect);
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapUp: (d) {
            if (ended) { Navigator.pop(context); return; }
            final x = d.localPosition.dx / cons.maxWidth;
            if (x > .7) {
              _go(1);
            } else if (x < .3) {
              _go(-1);
            } else {
              setState(() => ui = !ui);
              if (ui) _hideLater();
            }
          },
          onHorizontalDragEnd: (d) {
            final v = d.primaryVelocity ?? 0;
            if (v < -200) _go(1);
            if (v > 200) _go(-1);
          },
          child: Stack(children: [
            Positioned.fill(
              child: AnimatedSwitcher(
                duration: _dur(),
                transitionBuilder: (child, anim) => _trans(child, anim),
                child: KeyedSubtree(
                  key: ValueKey(i),
                  child: Center(
                    child: ended
                        ? Text(tr2('پایان نمایش اسلاید — برای خروج لمس کنید', 'End of slide show — tap to exit'), style: const TextStyle(color: Colors.white70, fontSize: 18))
                        : widget.build(i, w),
                  ),
                ),
              ),
            ),
            if (ui && !ended)
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(12, 18, 12, 8),
                    decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Color(0xCC000000), Colors.transparent])),
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      IconButton(color: Colors.white, icon: const Icon(Icons.close_rounded), onPressed: () => Navigator.pop(context)),
                      const SizedBox(width: 16),
                      IconButton(color: Colors.white, icon: const Icon(Icons.skip_previous_rounded, size: 30), onPressed: i > 0 ? () => _go(-1) : null),
                      IconButton(color: Colors.white, icon: Icon(auto ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded, size: 42), onPressed: () => _setAuto(!auto)),
                      IconButton(color: Colors.white, icon: const Icon(Icons.skip_next_rounded, size: 30), onPressed: () => _go(1)),
                      const SizedBox(width: 16),
                      Text('${i + 1} / ${widget.count}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                    ]),
                  ),
                ),
              ),
          ]),
        );
      }),
    );
  }
}
