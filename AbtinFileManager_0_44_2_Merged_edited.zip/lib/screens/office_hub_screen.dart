import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import '../core/layouts.dart' show tr2;
import '../core/office_prefs.dart';
import '../core/settings.dart';
import '../widgets/office_chrome.dart';
import 'office_new.dart';
import 'opener.dart';
import 'pdf_viewer_screen.dart';

/// WPS-inspired, local-first Office center. It exposes the document editors and PDF
/// tools that are actually implemented in this app without implying cloud parity.
class OfficeHubScreen extends StatefulWidget {
  final String directory;
  const OfficeHubScreen({super.key, required this.directory});

  @override
  State<OfficeHubScreen> createState() => _OfficeHubScreenState();
}

class _OfficeHubScreenState extends State<OfficeHubScreen> {
  final _search = TextEditingController();
  List<FileSystemEntity> _folderFiles = [];
  bool _loading = true;
  String _filter = 'all';
  String _source = 'recent';

  static const _officeExts = <String>{
    'docx', 'docm', 'dotx', 'dotm', 'doc',
    'xlsx', 'xlsm', 'xls',
    'pptx', 'ppsx', 'pptm', 'ppt',
    'pdf', 'odt', 'ods', 'odp', 'rtf',
  };

  @override
  void initState() {
    super.initState();
    _refresh();
    _search.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    final found = <FileSystemEntity>[];
    try {
      final dir = Directory(widget.directory);
      if (await dir.exists()) {
        for (final entity in dir.listSync(followLinks: false)) {
          if (entity is! File) continue;
          final ext = p.extension(entity.path).replaceFirst('.', '').toLowerCase();
          if (_officeExts.contains(ext)) found.add(entity);
        }
      }
      found.sort((a, b) {
        try {
          return b.statSync().modified.compareTo(a.statSync().modified);
        } catch (_) {
          return 0;
        }
      });
    } catch (_) {}
    if (mounted) setState(() {
      _folderFiles = found;
      _loading = false;
    });
  }

  List<FileSystemEntity> _openedRecently(List<String> paths) {
    final result = <FileSystemEntity>[];
    final seen = <String>{};
    for (final path in paths) {
      final ext = p.extension(path).replaceFirst('.', '').toLowerCase();
      if (!_officeExts.contains(ext) || !seen.add(path)) continue;
      final file = File(path);
      try {
        if (file.existsSync()) result.add(file);
      } catch (_) {}
      if (result.length == 60) break;
    }
    return result;
  }

  String _kind(String path) {
    final ext = p.extension(path).replaceFirst('.', '').toLowerCase();
    if (const {'docx', 'docm', 'dotx', 'dotm', 'doc'}.contains(ext)) return 'word';
    if (const {'xlsx', 'xlsm', 'xls'}.contains(ext)) return 'excel';
    if (const {'pptx', 'ppsx', 'pptm', 'ppt'}.contains(ext)) return 'ppt';
    if (ext == 'pdf') return 'pdf';
    return 'other';
  }

  List<FileSystemEntity> _filtered(List<FileSystemEntity> source) {
    final q = _search.text.trim().toLowerCase();
    return source.where((entity) {
      final matchesName = q.isEmpty || p.basename(entity.path).toLowerCase().contains(q);
      final matchesKind = _filter == 'all' || _kind(entity.path) == _filter;
      return matchesName && matchesKind;
    }).take(60).toList();
  }

  Future<void> _create(OfficeKind kind) async {
    await officeNewFile(context, widget.directory, kind);
    await _refresh();
  }

  Future<void> _openPicker() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: _officeExts.toList(),
    );
    final path = result?.files.single.path;
    if (path == null || !mounted) return;
    await Opener.open(context, path);
    await _refresh();
  }

  Future<void> _openType(String type) async {
    final extensions = switch (type) {
      'word' => const ['docx', 'docm', 'dotx', 'dotm', 'doc'],
      'excel' => const ['xlsx', 'xlsm', 'xls'],
      'ppt' => const ['pptx', 'ppsx', 'pptm', 'ppt'],
      _ => const ['pdf'],
    };
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: extensions,
    );
    final path = result?.files.single.path;
    if (path == null || !mounted) return;
    await Opener.open(context, path);
    await _refresh();
  }

  Future<void> _openPdfTool(String tool) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['pdf'],
    );
    final path = result?.files.single.path;
    if (path == null || !mounted) return;
    Provider.of<AppSettings>(context, listen: false).addRecent(path);
    await Navigator.push(context, MaterialPageRoute(builder: (_) => PdfViewerScreen(path: path, initialTool: tool)));
    await _refresh();
  }

  Future<void> _open(String path) async {
    await Opener.open(context, path);
    await _refresh();
  }

  Widget _sectionTitle(String title, {String? action, VoidCallback? onAction}) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 23, 18, 11),
        child: Row(children: [
          Expanded(child: Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: OfficePrefs.ink))),
          if (action != null)
            TextButton(onPressed: onAction, child: Text(action, style: TextStyle(color: OfficePrefs.blue, fontWeight: FontWeight.w700))),
        ]),
      );

  Widget _documentTile(OfficeKind kind, String subtitle, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: OfficePrefs.paper,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: OfficePrefs.line.withOpacity(.8)),
            boxShadow: const [BoxShadow(color: Color(0x10000000), blurRadius: 12, offset: Offset(0, 4))],
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              width: 45,
              height: 45,
              decoration: BoxDecoration(color: kind.color, borderRadius: BorderRadius.circular(13)),
              alignment: Alignment.center,
              child: Text(
                kind == OfficeKind.docx ? 'W' : kind == OfficeKind.xlsx ? 'X' : 'P',
                style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.w800),
              ),
            ),
            const Spacer(),
            Text(kind == OfficeKind.docx ? 'Word' : kind == OfficeKind.xlsx ? 'Excel' : 'PowerPoint',
                style: TextStyle(color: OfficePrefs.ink, fontSize: 14, fontWeight: FontWeight.w800)),
            const SizedBox(height: 3),
            Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: TextStyle(color: OfficePrefs.ink.withOpacity(.62), fontSize: 10.5)),
          ]),
        ),
      );

  Widget _typeCard({
    required String title,
    required String subtitle,
    required IconData icon,
    required Color color,
    required String type,
  }) => InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _openType(type),
        child: Container(
          width: 144,
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: OfficePrefs.paper,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: OfficePrefs.line.withOpacity(.8)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: color.withOpacity(.13), borderRadius: BorderRadius.circular(12)),
              child: Icon(icon, color: color),
            ),
            const SizedBox(height: 11),
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: TextStyle(color: OfficePrefs.ink, fontWeight: FontWeight.w800, fontSize: 14)),
            const SizedBox(height: 3),
            Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis,
                style: TextStyle(color: OfficePrefs.ink.withOpacity(.62), fontSize: 10.5, height: 1.25)),
          ]),
        ),
      );

  Widget _quickAction(IconData icon, String title, String subtitle, VoidCallback onTap, {Color? color}) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 13),
          decoration: BoxDecoration(
            color: OfficePrefs.strip,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: OfficePrefs.line.withOpacity(.8)),
          ),
          child: Row(children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(color: (color ?? OfficePrefs.blue).withOpacity(.12), borderRadius: BorderRadius.circular(12)),
              child: Icon(icon, color: color ?? OfficePrefs.blue, size: 22),
            ),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: TextStyle(fontWeight: FontWeight.w800, color: OfficePrefs.ink, fontSize: 13)),
              const SizedBox(height: 3),
              Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 10.5, height: 1.25, color: OfficePrefs.ink.withOpacity(.62))),
            ])),
            Icon(Icons.chevron_right_rounded, color: OfficePrefs.ink.withOpacity(.4)),
          ]),
        ),
      );

  Widget _filterChip(String key, String label) {
    final selected = _filter == key;
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => setState(() => _filter = key),
        labelStyle: TextStyle(color: selected ? Colors.white : OfficePrefs.ink, fontSize: 12, fontWeight: FontWeight.w700),
        selectedColor: OfficePrefs.blue,
        backgroundColor: OfficePrefs.paper,
        side: BorderSide(color: selected ? OfficePrefs.blue : OfficePrefs.line),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        showCheckmark: false,
        visualDensity: VisualDensity.compact,
      ),
    );
  }

  IconData _fileIcon(String path) {
    switch (_kind(path)) {
      case 'word': return Icons.description_rounded;
      case 'excel': return Icons.grid_on_rounded;
      case 'ppt': return Icons.slideshow_rounded;
      case 'pdf': return Icons.picture_as_pdf_rounded;
      default: return Icons.article_outlined;
    }
  }

  Color _fileColor(String path) {
    switch (_kind(path)) {
      case 'word': return const Color(0xFF2B579A);
      case 'excel': return const Color(0xFF217346);
      case 'ppt': return const Color(0xFFD24726);
      case 'pdf': return const Color(0xFFD32F2F);
      default: return OfficePrefs.blue;
    }
  }

  String _fileMeta(File file) {
    final ext = p.extension(file.path).replaceFirst('.', '').toUpperCase();
    try {
      final modified = file.statSync().modified;
      final date = '${modified.year}/${modified.month.toString().padLeft(2, '0')}/${modified.day.toString().padLeft(2, '0')}';
      return '$ext  •  ${tr2('ویرایش', 'Edited')} $date';
    } catch (_) {
      return ext;
    }
  }

  Widget _recentTile(File file) {
    final color = _fileColor(file.path);
    return Card(
      color: OfficePrefs.paper,
      elevation: 0,
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15), side: BorderSide(color: OfficePrefs.line)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
        leading: Container(
          width: 43,
          height: 43,
          decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(12)),
          child: Icon(_fileIcon(file.path), color: color),
        ),
        title: Text(p.basename(file.path), maxLines: 1, overflow: TextOverflow.ellipsis,
            style: TextStyle(fontWeight: FontWeight.w700, color: OfficePrefs.ink, fontSize: 13)),
        subtitle: Text(_fileMeta(file), style: TextStyle(fontSize: 10.5, color: OfficePrefs.ink.withOpacity(.58))),
        trailing: Icon(Icons.chevron_right_rounded, color: OfficePrefs.ink.withOpacity(.4)),
        onTap: () => _open(file.path),
      ),
    );
  }

  Widget _pdfToolCard(IconData icon, String title, String subtitle, String tool) => InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => _openPdfTool(tool),
        child: Container(
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: OfficePrefs.paper,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: OfficePrefs.line.withOpacity(.85)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Container(
              width: 37,
              height: 37,
              decoration: BoxDecoration(color: const Color(0xFFD32F2F).withOpacity(.12), borderRadius: BorderRadius.circular(11)),
              child: Icon(icon, color: const Color(0xFFD32F2F), size: 21),
            ),
            const SizedBox(height: 9),
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: TextStyle(color: OfficePrefs.ink, fontSize: 12, fontWeight: FontWeight.w800)),
            const SizedBox(height: 3),
            Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis,
                style: TextStyle(color: OfficePrefs.ink.withOpacity(.62), fontSize: 10, height: 1.2)),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<AppSettings>();
    final opened = _openedRecently(settings.recents);
    final usingRecent = _source == 'recent' && opened.isNotEmpty;
    final sourceFiles = usingRecent ? opened : _folderFiles;
    final documents = _filtered(sourceFiles);

    return Theme(
      data: officeTheme(context),
      child: Scaffold(
        backgroundColor: kOfficeBg,
        body: SafeArea(
          child: RefreshIndicator(
            onRefresh: _refresh,
            child: CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(18, 15, 18, 20),
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [Color(0xFF17365C), Color(0xFF245B91), Color(0xFF337CC2)],
                      ),
                      borderRadius: BorderRadius.vertical(bottom: Radius.circular(27)),
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: Row(children: [
                          IconButton(
                            onPressed: () => Navigator.maybePop(context),
                            tooltip: tr2('بازگشت', 'Back'),
                            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                          ),
                          Container(
                            width: 39,
                            height: 39,
                            decoration: BoxDecoration(color: Colors.white.withOpacity(.16), borderRadius: BorderRadius.circular(12)),
                            child: const Icon(Icons.description_rounded, color: Colors.white, size: 23),
                          ),
                          const SizedBox(width: 10),
                          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            const Text('Abtin Office', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 17)),
                            Text(tr2('سندها و ابزارهای PDF', 'Documents & PDF tools'), style: const TextStyle(color: Colors.white70, fontSize: 10.5)),
                          ]),
                          const Spacer(),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                            decoration: BoxDecoration(color: Colors.white.withOpacity(.13), borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.white24)),
                            child: Row(mainAxisSize: MainAxisSize.min, children: [
                              const Icon(Icons.phone_android_rounded, color: Colors.white, size: 15),
                              const SizedBox(width: 5),
                              Text(tr2('روی دستگاه', 'On device'), style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)),
                            ]),
                          ),
                        ]),
                      ),
                      const SizedBox(height: 14),
                      Text(tr2('همهٔ کارهای آفیس، یک‌جا', 'Your Office workspace'),
                          style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w800)),
                      const SizedBox(height: 5),
                      Text(tr2('سند بسازید، فایل‌ها را باز کنید و ویرایش را ادامه دهید', 'Create, open and continue editing your documents'),
                          style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
                      const SizedBox(height: 16),
                      Material(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(15),
                        child: TextField(
                          controller: _search,
                          textDirection: TextDirection.ltr,
                          decoration: InputDecoration(
                            hintText: tr2('جست‌وجوی نام فایل', 'Search document names'),
                            prefixIcon: const Icon(Icons.search_rounded, color: Color(0xFF56708F)),
                            suffixIcon: _search.text.isEmpty ? null : IconButton(
                              onPressed: _search.clear,
                              icon: const Icon(Icons.close_rounded),
                            ),
                            border: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(vertical: 14),
                          ),
                        ),
                      ),
                    ]),
                  ),
                ),

                SliverToBoxAdapter(child: _sectionTitle(tr2('ساخت سند جدید', 'Create new document'))),
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverGrid(
                    delegate: SliverChildListDelegate([
                      _documentTile(OfficeKind.docx, tr2('سند متنی', 'Text document'), () => _create(OfficeKind.docx)),
                      _documentTile(OfficeKind.xlsx, tr2('صفحه‌گسترده', 'Spreadsheet'), () => _create(OfficeKind.xlsx)),
                      _documentTile(OfficeKind.pptx, tr2('ارائهٔ اسلایدی', 'Presentation'), () => _create(OfficeKind.pptx)),
                    ]),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                      childAspectRatio: .88,
                    ),
                  ),
                ),

                SliverToBoxAdapter(child: _sectionTitle(tr2('برنامه‌های آفیس', 'Office apps'))),
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: 128,
                    child: ListView(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      scrollDirection: Axis.horizontal,
                      children: [
                        _typeCard(title: 'Word', subtitle: tr2('سند و قالب‌بندی متن', 'Documents & formatting'), icon: Icons.description_rounded, color: const Color(0xFF2B579A), type: 'word'),
                        const SizedBox(width: 9),
                        _typeCard(title: 'Excel', subtitle: tr2('صفحه‌گسترده و فرمول‌ها', 'Sheets & formulas'), icon: Icons.grid_on_rounded, color: const Color(0xFF217346), type: 'excel'),
                        const SizedBox(width: 9),
                        _typeCard(title: 'PowerPoint', subtitle: tr2('اسلاید و ارائه', 'Slides & presentations'), icon: Icons.slideshow_rounded, color: const Color(0xFFD24726), type: 'ppt'),
                        const SizedBox(width: 9),
                        _typeCard(title: 'PDF', subtitle: tr2('مشاهده و ابزارهای PDF', 'Reader & PDF tools'), icon: Icons.picture_as_pdf_rounded, color: const Color(0xFFD32F2F), type: 'pdf'),
                      ],
                    ),
                  ),
                ),

                SliverToBoxAdapter(child: _sectionTitle(tr2('بازکردن فایل', 'Open a file'))),
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverToBoxAdapter(
                    child: _quickAction(
                      Icons.folder_open_rounded,
                      tr2('انتخاب از دستگاه', 'Browse this device'),
                      tr2('DOC، DOCX، XLSX، PPTX، PDF، ODF و RTF', 'DOC, DOCX, XLSX, PPTX, PDF, ODF and RTF'),
                      _openPicker,
                    ),
                  ),
                ),

                SliverToBoxAdapter(child: _sectionTitle(tr2('ابزارهای PDF', 'PDF productivity tools'))),
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverGrid(
                    delegate: SliverChildListDelegate([
                      _pdfToolCard(Icons.edit_rounded, tr2('ویرایش PDF', 'Edit PDF'), tr2('قلم، متن و هایلایت', 'Pen, text & highlights'), 'edit'),
                      _pdfToolCard(Icons.list_alt_rounded, tr2('پرکردن فرم', 'Fill forms'), tr2('فیلدهای فرم PDF', 'PDF form fields'), 'form'),
                      _pdfToolCard(Icons.draw_rounded, tr2('امضا و مهر', 'Sign & stamp'), tr2('مهر تصویری روی صفحه', 'Place a signature stamp'), 'stamp'),
                      _pdfToolCard(Icons.rotate_right_rounded, tr2('چرخاندن صفحه', 'Rotate pages'), tr2('صفحهٔ جاری یا همه', 'Current page or all'), 'rotate'),
                      _pdfToolCard(Icons.content_copy_rounded, tr2('استخراج صفحات', 'Extract pages'), tr2('انتخاب بازهٔ صفحه', 'Choose a page range'), 'extract'),
                      _pdfToolCard(Icons.call_split_rounded, tr2('تقسیم PDF', 'Split PDF'), tr2('هر صفحه در فایل جدا', 'One file per page'), 'split'),
                      _pdfToolCard(Icons.call_merge_rounded, tr2('ادغام PDF', 'Merge PDFs'), tr2('پیوستن فایل‌های دیگر', 'Append other PDF files'), 'merge'),
                      _pdfToolCard(Icons.lock_rounded, tr2('گذرواژه‌گذاری', 'Password protect'), tr2('ساخت نسخهٔ محافظت‌شده', 'Create a protected copy'), 'protect'),
                      _pdfToolCard(Icons.search_rounded, tr2('جست‌وجوی متن', 'Search text'), tr2('پیداکردن متن در PDF', 'Find text in a PDF'), 'search'),
                      _pdfToolCard(Icons.select_all_rounded, tr2('انتخاب متن', 'Select text'), tr2('انتخاب و کپی از صفحه', 'Select and copy page text'), 'select'),
                      _pdfToolCard(Icons.text_snippet_rounded, tr2('متن صفحه', 'Page text'), tr2('مشاهده و کپی متن', 'View and copy text'), 'text'),
                      _pdfToolCard(Icons.share_rounded, tr2('اشتراک‌گذاری', 'Share PDF'), tr2('ارسال با برنامه‌های دستگاه', 'Share with device apps'), 'share'),
                    ]),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 9,
                      crossAxisSpacing: 9,
                      childAspectRatio: 1.18,
                    ),
                  ),
                ),

                SliverToBoxAdapter(
                  child: _sectionTitle(
                    usingRecent ? tr2('اخیراً بازشده', 'Recently opened') : tr2('فایل‌های این پوشه', 'Files in this folder'),
                    action: usingRecent ? tr2('این پوشه', 'This folder') : tr2('اخیراً بازشده', 'Recent'),
                    onAction: () => setState(() => _source = usingRecent ? 'folder' : 'recent'),
                  ),
                ),
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: 42,
                    child: ListView(
                      padding: const EdgeInsetsDirectional.fromSTEB(16, 0, 16, 3),
                      scrollDirection: Axis.horizontal,
                      children: [
                        _filterChip('all', tr2('همه', 'All')),
                        _filterChip('word', 'Word'),
                        _filterChip('excel', 'Excel'),
                        _filterChip('ppt', 'PowerPoint'),
                        _filterChip('pdf', 'PDF'),
                        _filterChip('other', tr2('سایر', 'Other')),
                      ],
                    ),
                  ),
                ),
                if (_loading && !usingRecent)
                  const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(28), child: Center(child: CircularProgressIndicator())))
                else if (documents.isEmpty)
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(24, 20, 24, 30),
                      child: Center(child: Column(children: [
                        Icon(Icons.description_outlined, size: 42, color: OfficePrefs.ink.withOpacity(.28)),
                        const SizedBox(height: 8),
                        Text(
                          _search.text.isNotEmpty
                              ? tr2('فایلی با این نام پیدا نشد.', 'No matching file found.')
                              : (usingRecent
                                  ? tr2('هنوز فایل آفیس یا PDF اخیراً بازشده‌ای نیست.', 'No recently opened Office or PDF files yet.')
                                  : tr2('در این پوشه فایلی از نوع انتخاب‌شده نیست.', 'No files of this type in this folder.')),
                          textAlign: TextAlign.center,
                          style: TextStyle(color: OfficePrefs.ink.withOpacity(.62)),
                        ),
                      ])),
                    ),
                  )
                else
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(12, 3, 12, 22),
                    sliver: SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (context, index) => _recentTile(documents[index] as File),
                        childCount: documents.length,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
