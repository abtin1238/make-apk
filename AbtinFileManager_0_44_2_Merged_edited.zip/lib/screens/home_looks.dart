import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart' hide Icon;
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/layouts.dart';
import '../core/looks.dart';
import 'more_screen.dart';
import '../core/settings.dart';
import '../services/file_ops.dart';
import '../widgets/adaptive_nav.dart';
import '../widgets/app_icon.dart';
import '../widgets/glass_kit.dart';
import '../widgets/mock_icons.dart';
import '../widgets/mock_svg.dart';
import '../widgets/neon_kit.dart';
import '../widgets/ui.dart';
import 'analyzer_screen.dart';
import 'apps_screen.dart';
import 'path_list_screen.dart';
import 'security_screen.dart';
import 'browser_screen.dart';
import 'category_screen.dart';
import 'duplicates_screen.dart';
import 'home_cats.dart';
import 'home_variants.dart' show StorageBuilder;
import 'search_screen.dart';
import 'trash_screen.dart';
import 'transfer_screen.dart';

// Home screens of the look themes (Settings -> theme look):
//   ToolsHome  – neon + gradient looks: storage card with ring, quick chips, recent files, quick-tools grid
//   GlassHome  – glass look: storage card, quick access tiles, folder list

void _go(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));

String _rootName(StorageRoot r) => r.sd ? '${L.t('sdcard')} (${r.name})' : L.t('internal');

/// The newest [max] recent files that still exist.
List<String> recentFiles(AppSettings s, int max) {
  final out = <String>[];
  for (final p in s.recents) {
    if (out.length >= max) break;
    try {
      if (File(p).existsSync()) out.add(p);
    } catch (_) {}
  }
  return out;
}

// ------------------------------------------------------------------ ring

class RingPainter extends CustomPainter {
  final double value;
  final List<Color> colors;
  final Color track;
  final double stroke;
  RingPainter({required this.value, required this.colors, required this.track, this.stroke = 10});

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = (math.min(size.width, size.height) - stroke) / 2;
    final rect = Rect.fromCircle(center: c, radius: r);
    canvas.drawCircle(c, r, Paint()..style = PaintingStyle.stroke..strokeWidth = stroke..color = track);
    final v = value < 0 ? 0.0 : (value > 1 ? 1.0 : value);
    if (v <= 0) return;
    final sweep = 2 * math.pi * v;
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        startAngle: 0,
        endAngle: sweep < 0.1 ? 0.1 : sweep,
        colors: colors,
        transform: const GradientRotation(-math.pi / 2),
      ).createShader(rect);
    canvas.drawArc(rect, -math.pi / 2, sweep, false, p);
  }

  @override
  bool shouldRepaint(RingPainter o) => o.value != value || o.track != track || o.stroke != stroke || o.colors.length != colors.length || o.colors.first != colors.first || o.colors.last != colors.last;
}

/// Circular usage meter with the percentage in the middle.
class StorageRing extends StatelessWidget {
  final double value, size, stroke;
  final List<Color> colors;
  final Color track, textColor;
  const StorageRing({super.key, required this.value, required this.colors, required this.track, required this.textColor, this.size = 96, this.stroke = 10});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: RingPainter(value: value, colors: colors, track: track, stroke: stroke),
          child: Center(child: Text('${(value * 100).round()}%', style: TextStyle(color: textColor, fontSize: size * .23, fontWeight: FontWeight.bold))),
        ),
      );
}

double _ratio(int t, int used) => t == 0 ? 0.0 : (used / t).clamp(0.0, 1.0).toDouble();

// ------------------------------------------------------------------ neon + gradient home

class _Tool {
  final IconData icon;
  final String fa, en;
  final Color color;
  final void Function(BuildContext) run;
  final String? svg; // icon of the reference HTML mockup (drawn verbatim by MockSvg)
  const _Tool(this.icon, this.fa, this.en, this.color, this.run, [this.svg]);
}

Future<void> _newFolder(BuildContext c) async {
  final name = await promptText(c, tr2('ایجاد پوشه', 'Create folder'));
  if (name == null || name.isEmpty || !c.mounted) return;
  final ok = await busy(c, () => FileOps.mkdir(FileOps.root, name));
  if (ok && c.mounted) snack(c, '${tr2('پوشه ساخته شد', 'Folder created')}: $name');
}

void _storageDetails(BuildContext c) {
  showModalBottomSheet<void>(
    context: c,
    builder: (ctx) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(tr2('جزئیات حافظه', 'Storage details'), style: Theme.of(ctx).textTheme.titleMedium),
          const SizedBox(height: 12),
          for (final r in FileOps.roots())
            StorageBuilder(
              root: r,
              builder: (t, used) => Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(_rootName(r), style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: _ratio(t, used), minHeight: 8)),
                  const SizedBox(height: 6),
                  Text(t == 0 ? '…' : '${tr2('استفاده‌شده', 'Used')}: ${FileOps.fmt(used)}   •   ${tr2('آزاد', 'Free')}: ${FileOps.fmt(t - used)}   •   ${tr2('کل', 'Total')}: ${FileOps.fmt(t)}', style: const TextStyle(fontSize: 12)),
                ]),
              ),
            ),
          FilledButton.icon(
            icon: const Icon(Icons.pie_chart_rounded, size: 20),
            label: Text(L.t('analyzer')),
            onPressed: () {
              Navigator.pop(ctx);
              _go(c, const AnalyzerScreen());
            },
          ),
        ]),
      ),
    ),
  );
}

final List<_Tool> _tools = [
  _Tool(Icons.delete_rounded, 'زباله‌دان', 'Trash', const Color(0xFFFF9A1F), (c) => _go(c, const TrashScreen()), mockToolTrash),
  _Tool(Icons.download_rounded, 'دانلودها', 'Downloads', const Color(0xFF17D878), (c) => _go(c, const BrowserScreen(initialPath: FileOps.downloads)), mockToolDownloads),
  _Tool(Icons.content_copy_rounded, 'فایل‌های تکراری', 'Duplicate files', const Color(0xFF1F6DFF), (c) => _go(c, const DuplicatesScreen()), mockToolDuplicates),
  _Tool(Icons.cleaning_services_rounded, 'پاکسازی فایل‌های اضافی', 'Clean junk files', const Color(0xFF6A3DFF), (c) => _go(c, const AnalyzerScreen()), mockToolCleanup),
  _Tool(Icons.info_rounded, 'جزئیات حافظه', 'Storage details', const Color(0xFF6A3DFF), _storageDetails, mockToolInfo),
  _Tool(Icons.create_new_folder_rounded, 'ایجاد پوشه', 'New folder', const Color(0xFF1F6DFF), (c) => _newFolder(c), mockToolNewFolder),
  _Tool(Icons.share_rounded, 'اشتراک‌گذاری', 'Share', const Color(0xFF16C9FF), (c) => _go(c, const TransferScreen()), mockToolShare),
  _Tool(Icons.inventory_2_rounded, 'فشرده‌سازی', 'Archives', const Color(0xFF6A3DFF), (c) => _go(c, const CategoryScreen(cat: Cat.archives)), mockToolArchive),
  _Tool(Icons.android_rounded, 'برنامه‌ها', 'Apps', const Color(0xFF3DDC84), (c) => _go(c, const AppsScreen())),
  _Tool(Icons.description_rounded, 'اسناد', 'Documents', const Color(0xFFFF5C7A), (c) => _go(c, const CategoryScreen(cat: Cat.docs))),
  _Tool(Icons.star_rounded, 'علاقه‌مندی‌ها', 'Favorites', Colors.amber, (c) => _go(c, PathListScreen(title: L.t('favorites'), fav: true))),
  _Tool(Icons.shield_rounded, 'امنیت', 'Security', const Color(0xFF16C9FF), (c) => _go(c, const SecurityScreen())),
];

class _SectionTitle extends StatelessWidget {
  final String svg;
  final double w, h;
  final String text;
  final double k;
  const _SectionTitle(this.svg, this.w, this.h, this.text, this.k);
  @override
  Widget build(BuildContext context) => SizedBox(
        height: 50 * k,
        child: Row(children: [
          MockSvg(svg, width: w * k, height: h * k),
          SizedBox(width: 18 * k),
          Text(text, style: TextStyle(fontSize: 31 * k, fontWeight: FontWeight.w700)),
        ]),
      );
}

/// Tile / chip of the neon home: dark gradient, glowing blue outline (sizes in mockup pixels * [k]).
class _NeonTile extends StatelessWidget {
  final double k, h, radius;
  final Widget child;
  final VoidCallback? onTap;
  final Color? border;
  const _NeonTile({required this.k, required this.h, required this.child, this.onTap, this.border, this.radius = 28});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final r = BorderRadius.circular(radius * k);
    final deco = dark
        ? BoxDecoration(
            borderRadius: r,
            gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF0A1022), Color(0xFF060A16)]),
            border: Border.all(color: (border ?? const Color(0xFF3C6EFF)).withOpacity(.6), width: 1.5),
            boxShadow: [BoxShadow(color: const Color(0xFF325AFF).withOpacity(.28), blurRadius: 12 * k)],
          )
        : Looks.card(context, radius: radius * k);
    return DecoratedBox(
      decoration: deco,
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(borderRadius: r, onTap: onTap, child: SizedBox(height: h * k, child: child)),
      ),
    );
  }
}

/// Storage card: gradient fill in the gradient look, glowing chamfered outline in the neon look.
class _Hero extends StatelessWidget {
  final StorageRoot root;
  final double k;
  const _Hero({required this.root, required this.k});

  @override
  Widget build(BuildContext context) {
    AppStyleScope.watch(context);
    final cs = Theme.of(context).colorScheme;
    final filled = Looks.current == 'gradient';
    final fg = filled ? Colors.white : (Theme.of(context).brightness == Brightness.dark ? const Color(0xFFE4E7F2) : cs.onSurface);
    final r = BorderRadius.circular(28);
    return StorageBuilder(
      root: root,
      builder: (t, used) {
        final ratio = _ratio(t, used);
        // laid out left -> right exactly like the mockup: drive icon | text | ring
        final content = Directionality(
          textDirection: TextDirection.ltr,
          child: Row(children: [
            SizedBox(
              width: 142 * k,
              height: 154 * k,
              child: filled
                  ? Icon(Icons.storage_rounded, size: 134 * k, color: Colors.white)
                  : Transform.translate(offset: Offset(0, 2.5 * k), child: MockSvg(mockDrive3d, width: 142 * k, height: 154 * k, glow: const Color(0xFF288CFF).withOpacity(.6), glowBlur: 16 * k)),
            ),
            Expanded(
              child: Directionality(
                textDirection: L.rtl ? TextDirection.rtl : TextDirection.ltr,
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Text(_rootName(root), style: TextStyle(color: fg.withOpacity(.72), fontSize: 27 * k)),
                  FittedBox(fit: BoxFit.scaleDown, child: Text(t == 0 ? '…' : FileOps.fmt(used), style: TextStyle(color: fg, fontSize: 56 * k, fontWeight: FontWeight.w700, height: 1.25))),
                  FittedBox(fit: BoxFit.scaleDown, child: Text(t == 0 ? '' : '${tr2('از', 'of')} ${FileOps.fmt(t)} • ${FileOps.fmt(t - used)} ${tr2('آزاد', 'free')}', style: TextStyle(color: fg.withOpacity(.8), fontSize: 22 * k))),
                ]),
              ),
            ),
            SizedBox(
              width: 210 * k,
              height: 210 * k,
              child: CustomPaint(
                painter: RingPainter(
                  value: ratio,
                  colors: filled ? const [Colors.white, Colors.white] : const [Color(0xFF00E5FF), Color(0xFF4A7BFF), Color(0xFFA23DFF)],
                  track: filled ? Colors.white24 : const Color(0xFF18214A),
                  stroke: 18 * k,
                ),
                child: Center(child: Text('${(ratio * 100).round()}%', style: TextStyle(color: fg, fontSize: 50 * k, fontWeight: FontWeight.w600))),
              ),
            ),
          ]),
        );
        void open() => _go(context, BrowserScreen(initialPath: root.path, root: true));
        if (Looks.current == 'neon') {
          return NeonCutCard(
            onTap: open,
            uniform: true,
            cut: 36 * k,
            line: 2.5,
            padding: EdgeInsets.fromLTRB(55 * k, 0, 20 * k, 0),
            child: SizedBox(height: 275 * k, child: content),
          );
        }
        return DecoratedBox(
          decoration: Looks.accent(cs, radius: r),
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(borderRadius: r, onTap: open, child: Padding(padding: EdgeInsets.fromLTRB(18, 14, 14, 14), child: SizedBox(height: 275 * k, child: content))),
          ),
        );
      },
    );
  }
}

class _MiniStorage extends StatelessWidget {
  final StorageRoot root;
  const _MiniStorage({required this.root});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 10),
        child: StorageBuilder(
          root: root,
          builder: (t, used) => GradCard(
            onTap: () => _go(context, BrowserScreen(initialPath: root.path, root: true)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(Icons.sd_card_rounded, size: 20),
                const SizedBox(width: 8),
                Expanded(child: Text(_rootName(root), style: const TextStyle(fontWeight: FontWeight.w600))),
                Text(t == 0 ? '' : '${FileOps.fmt(used)} / ${FileOps.fmt(t)}', style: const TextStyle(fontSize: 12)),
              ]),
              const SizedBox(height: 8),
              ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: _ratio(t, used), minHeight: 6)),
            ]),
          ),
        ),
      );
}

Widget _chipIcon(HomeCat c, double k) {
  switch (c.key) {
    case 'images':
      return Container(width: 42 * k, height: 38 * k, alignment: Alignment.center, decoration: BoxDecoration(color: const Color(0xFF17D878), borderRadius: BorderRadius.circular(9 * k)), child: MockSvg(mockChipImages, width: 30 * k, height: 26 * k));
    case 'videos':
      return Container(width: 42 * k, height: 42 * k, alignment: Alignment.center, decoration: const BoxDecoration(color: Color(0xFF6A3DFF), shape: BoxShape.circle), child: MockSvg(mockChipVideos, width: 30 * k, height: 30 * k));
    case 'music':
      return SizedBox(width: 44 * k, height: 44 * k, child: Center(child: MockSvg(mockChipMusic, width: 34 * k, height: 40 * k)));
  }
  return Icon(c.icon, color: c.color, size: 42 * k);
}

/// Home of the neon and gradient looks (laid out in the 842 px wide mockup grid, scaled by [k]).
class ToolsHome extends StatelessWidget {
  const ToolsHome({super.key});

  static List<int> _flex(BuildContext c, List<int> ltr) => Directionality.of(c) == TextDirection.rtl ? ltr.reversed.toList() : ltr;

  static Widget _row(BuildContext c, double k, List<int> flex, List<Widget> kids) {
    final fx = _flex(c, flex);
    return Row(children: [
      for (var i = 0; i < kids.length; i++) ...[
        if (i > 0) SizedBox(width: 21 * k),
        Expanded(flex: fx[i], child: kids[i]),
      ],
    ]);
  }

  @override
  Widget build(BuildContext context) {
    context.watch<AppSettings>();
    AppStyleScope.watch(context);
    final cats = homeCats();
    final roots = FileOps.roots();
    final k = math.min(MediaQuery.of(context).size.width, 600.0) / 842;
    final chips = [for (final key in const ['images', 'videos', 'music']) homeCat(cats, key)].whereType<HomeCat>().toList();
    final neon = Looks.current == 'neon';
    final dark = Theme.of(context).brightness == Brightness.dark;
    final txt = dark ? const Color(0xFFEEF0F8) : null;
    final side = EdgeInsets.only(left: 28 * k, right: 25 * k);

    final page = SafeArea(
      child: MaxWidth(
        width: 960,
        child: ListView(padding: EdgeInsets.only(bottom: 24 * k), children: [
          SizedBox(
            height: 82 * k,
            child: Stack(children: [
              Center(child: Padding(padding: EdgeInsets.only(right: 52 * k), child: Text('Abtin File Manager', style: TextStyle(fontSize: 38 * k, fontWeight: FontWeight.w500)))),
              Positioned(left: 40 * k, top: 18 * k, child: InkWell(onTap: () => _go(context, const SearchScreen()), child: MockSvg(mockSearch, width: 44 * k, height: 44 * k))),
            ]),
          ),
          SizedBox(height: 37 * k),
          if (roots.isNotEmpty) Padding(padding: EdgeInsets.only(left: 20 * k, right: 24 * k), child: _Hero(root: roots.first, k: k)),
          for (final r in roots.skip(1)) Padding(padding: EdgeInsets.fromLTRB(20 * k, 0, 24 * k, 0), child: _MiniStorage(root: r)),
          SizedBox(height: 41 * k),
          Padding(
            padding: side,
            child: _row(context, k, const [206, 215, 234], [
              for (final c in chips)
                _NeonTile(
                  k: k,
                  h: 79,
                  radius: 40,
                  onTap: () => _go(context, c.page),
                  child: Row(mainAxisAlignment: MainAxisAlignment.start, children: [
                    SizedBox(width: 24 * k),
                    _chipIcon(c, k),
                    SizedBox(width: 16 * k),
                    Flexible(child: Text(L.t(c.key), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 29 * k, fontWeight: FontWeight.w700, color: txt))),
                  ]),
                ),
            ]),
          ),
          SizedBox(height: 66 * k),
          Padding(padding: side, child: _SectionTitle(mockSecBolt, 40, 50, tr2('ابزارهای سریع', 'Quick tools'), k)),
          SizedBox(height: 29 * k),
          for (var r = 0; r * 4 < _tools.length; r++) ...[
            if (r > 0) SizedBox(height: 25 * k),
            Padding(
              padding: side,
              child: _row(context, k, const [173, 154, 148, 146], [
                for (var i = r * 4; i < r * 4 + 4; i++)
                  if (i < _tools.length)
                    _NeonTile(
                      k: k,
                      h: r == 0 ? 150 : 144,
                      onTap: () => _tools[i].run(context),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        (_tools[i].svg != null ? MockSvg(_tools[i].svg!, width: 50 * k, height: 50 * k) : Icon(_tools[i].icon, color: _tools[i].color, size: 50 * k)),
                        SizedBox(height: 6 * k),
                        Text(tr2(_tools[i].fa, _tools[i].en), maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: TextStyle(fontSize: 22 * k, height: 1.3, color: txt)),
                      ]),
                    )
                  else
                    SizedBox(height: 144 * k),
              ]),
            ),
          ],
        ]),
      ),
    );
    return neon ? NeonBackdrop(child: page) : page;
  }
}

// ------------------------------------------------------------------ glass home

/// One practical utility of the glass home (replaces the former folder rows).
class _UtilRow extends StatelessWidget {
  final _Tool tool;
  final double k;
  const _UtilRow({required this.tool, required this.k});

  String get _sub {
    switch (tool.en) {
      case 'Trash':
        return tr2('فایل‌های حذف‌شده', 'Deleted files');
      case 'Downloads':
        return tr2('پوشهٔ دانلودها', 'Downloaded files');
      case 'Duplicate files':
        return tr2('پیدا کردن فایل‌های تکراری', 'Find identical files');
      case 'Clean junk files':
        return tr2('آزاد کردن فضا', 'Free up space');
      case 'Storage details':
        return tr2('بررسی مصرف حافظه', 'See what uses space');
      case 'New folder':
        return tr2('ساخت پوشهٔ جدید', 'Create a folder');
      case 'Share':
        return tr2('ارسال و دریافت فایل', 'Send and receive files');
      case 'Apps':
        return tr2('نصب‌شده، نصب‌نشده و پشتیبان', 'Installed, not installed, backups');
      case 'Documents':
        return tr2('Word، PDF و متن', 'Word, PDF and text');
      case 'Favorites':
        return tr2('فایل‌های ستاره‌دار', 'Starred files');
      case 'Security':
        return tr2('قفل و گاوصندوق', 'Lock and vault');
      default:
        return tr2('ZIP، RAR و ...', 'ZIP, RAR and more');
    }
  }

  @override
  Widget build(BuildContext context) {
    final dim = Theme.of(context).colorScheme.onSurface.withOpacity(.6);
    final c = tool.color;
    return SizedBox(
      height: 69 * k,
      child: InkWell(
        onTap: () => tool.run(context),
        child: Padding(
          padding: EdgeInsets.only(left: 38 * k, right: 30 * k),
          child: Row(children: [
            Container(
              width: 48 * k,
              height: 48 * k,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14 * k),
                gradient: LinearGradient(colors: [c, c.withOpacity(.7)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                boxShadow: [BoxShadow(color: c.withOpacity(.4), blurRadius: 12 * k, spreadRadius: -2)],
              ),
              child: Icon(tool.icon, color: Colors.white, size: 27 * k),
            ),
            SizedBox(width: 17 * k),
            Expanded(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(tr2(tool.fa, tool.en), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 18 * k, fontWeight: FontWeight.w600, height: 1.3)),
                Text(_sub, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 15 * k, color: dim, height: 1.3)),
              ]),
            ),
            Icon(Icons.chevron_right_rounded, size: 24 * k, color: dim),
          ]),
        ),
      ),
    );
  }
}

/// Storage card of the glass look: ring with drive icon + percentage, "used / total" and the usage wave.
class _GlassStorageCard extends StatefulWidget {
  final StorageRoot root;
  final double k;
  const _GlassStorageCard({required this.root, required this.k});
  @override
  State<_GlassStorageCard> createState() => _GlassStorageCardState();
}

class _GlassStorageCardState extends State<_GlassStorageCard> {
  List<double> _hist = const [];
  double _lastRecorded = -1;

  @override
  void initState() {
    super.initState();
    UsageHistory.load(widget.root.path).then((v) {
      if (mounted) setState(() => _hist = v);
    });
  }

  void _record(double ratio) {
    if (ratio <= 0 || (ratio - _lastRecorded).abs() < 1e-6) return;
    _lastRecorded = ratio;
    UsageHistory.record(widget.root.path, ratio).then((v) {
      if (mounted) setState(() => _hist = v);
    });
  }

  @override
  Widget build(BuildContext context) {
    AppStyleScope.watch(context);
    final cs = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final r = widget.root;
    final k = widget.k;
    const glow = Color(0xFF22E4C8);
    final radius = BorderRadius.circular(24 * k);
    return StorageBuilder(
      root: r,
      builder: (t, used) {
        final ratio = _ratio(t, used);
        if (t > 0) WidgetsBinding.instance.addPostFrameCallback((_) => _record(ratio));
        return DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: radius,
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: dark ? [glow.withOpacity(.14), const Color(0xFF1E2846).withOpacity(.35), const Color(0xFF3C5AE6).withOpacity(.16)] : [Colors.white.withOpacity(.9), glow.withOpacity(.06), glow.withOpacity(.10)],
            ),
            border: Border.all(color: const Color(0xFF28C8D2).withOpacity(dark ? .6 : .4), width: 1.5),
            boxShadow: [BoxShadow(color: const Color(0xFF1EBEDC).withOpacity(dark ? .26 : .12), blurRadius: 22 * k, spreadRadius: -4)],
          ),
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(
              borderRadius: radius,
              onTap: () => _go(context, BrowserScreen(initialPath: r.path, root: true)),
              child: SizedBox(
                height: 144 * k,
                child: Padding(
                  padding: EdgeInsets.fromLTRB(15 * k, 0, 20 * k, 0),
                  // laid out left -> right like the mockup (ring | numbers + wave), also in RTL
                  child: Directionality(
                    textDirection: TextDirection.ltr,
                    child: Row(children: [
                      SizedBox(
                        width: 107 * k,
                        height: 107 * k,
                        child: CustomPaint(
                          painter: RingPainter(value: ratio, colors: const [Color(0xFF19E0D0), Color(0xFF2AA8F0), Color(0xFF3A8BFF)], track: cs.onSurface.withOpacity(.12), stroke: 9 * k),
                          child: Center(
                            child: Column(mainAxisSize: MainAxisSize.min, children: [
                              Icon(Icons.storage_rounded, size: 34 * k, color: const Color(0xFF3B82F6)),
                              SizedBox(height: 4 * k),
                              Text('${(ratio * 100).round()}%', style: TextStyle(fontSize: 19 * k, fontWeight: FontWeight.w500)),
                            ]),
                          ),
                        ),
                      ),
                      SizedBox(width: 29 * k),
                      Expanded(
                        child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                          FittedBox(
                            fit: BoxFit.scaleDown,
                            alignment: Alignment.centerLeft,
                            child: Text.rich(TextSpan(children: [
                              TextSpan(text: t == 0 ? '…' : FileOps.fmt(used), style: TextStyle(fontSize: 19 * k, fontWeight: FontWeight.w600)),
                              if (t != 0) TextSpan(text: ' / ${FileOps.fmt(t)}', style: TextStyle(fontSize: 15 * k, fontWeight: FontWeight.w500, color: cs.onSurface.withOpacity(.55))),
                            ])),
                          ),
                          SizedBox(height: 14 * k),
                          Sparkline(samples: _hist, a: const Color(0xFF19D3E6), b: const Color(0xFF19D3C5), height: 50 * k),
                        ]),
                      ),
                    ]),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Quick-access tile of the glass look: tinted glass tile + gradient icon square.
class _QuickTile extends StatelessWidget {
  final HomeCat cat;
  final VoidCallback onTap;
  final double k;
  const _QuickTile({required this.cat, required this.onTap, required this.k});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final c = cat.color;
    final r = BorderRadius.circular(20 * k);
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: r,
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [c.withOpacity(dark ? .34 : .16), c.withOpacity(dark ? .08 : .05)]),
        border: Border.all(color: (dark ? Colors.white : c).withOpacity(dark ? .06 : .22)),
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          borderRadius: r,
          onTap: onTap,
          child: SizedBox(
            height: 97 * k,
            child: Column(children: [
              SizedBox(height: 14 * k),
              Container(
                width: 46 * k,
                height: 46 * k,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(13 * k),
                  gradient: LinearGradient(colors: [c, c.withOpacity(.7)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                  boxShadow: [BoxShadow(color: c.withOpacity(.45), blurRadius: 14 * k, spreadRadius: -2)],
                ),
                child: Icon(cat.icon, color: Colors.white, size: 28 * k),
              ),
              SizedBox(height: 11 * k),
              Text(L.t(cat.key), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 14.5 * k, fontWeight: FontWeight.w500)),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Home of the glass look: storage card, quick-access tiles, folder list (385 px wide mockup grid, scaled by k).
class GlassHome extends StatelessWidget {
  const GlassHome({super.key});

  @override
  Widget build(BuildContext context) {
    AppStyleScope.watch(context);
    final dark = Theme.of(context).brightness == Brightness.dark;
    final k = math.min(MediaQuery.of(context).size.width, 520.0) / 385;
    final cats = homeCats();
    final roots = FileOps.roots();
    final quick = [for (final key in const ['images', 'videos', 'music', 'apps']) homeCat(cats, key)].whereType<HomeCat>().toList();
    TextStyle h2() => TextStyle(fontSize: 19 * k, fontWeight: FontWeight.w600, letterSpacing: -.1);
    final body = SafeArea(
      child: MaxWidth(
        width: 960,
        child: ListView(padding: EdgeInsets.only(bottom: 110 * k), children: [
          SizedBox(height: 16 * k),
          SizedBox(
            height: 34 * k,
            child: Padding(
              padding: EdgeInsets.only(left: 34 * k, right: 34 * k),
              child: Row(children: [
                Expanded(child: Text(tr2('فایل‌ها', 'Files'), style: TextStyle(fontSize: 26 * k, fontWeight: FontWeight.w700, letterSpacing: -.2))),
                InkWell(onTap: () => _go(context, const SearchScreen()), child: Icon(Icons.search_rounded, size: 26 * k)),
                SizedBox(width: 22 * k),
                InkWell(onTap: () => _go(context, const MoreScreen()), child: Icon(Icons.more_vert_rounded, size: 26 * k)),
              ]),
            ),
          ),
          SizedBox(height: 21 * k),
          for (final r in roots) Padding(padding: EdgeInsets.fromLTRB(30 * k, 0, 25 * k, roots.length > 1 ? 10.0 : 0.0), child: _GlassStorageCard(root: r, k: k)),
          SizedBox(height: 22 * k),
          Padding(padding: EdgeInsets.symmetric(horizontal: 31 * k), child: Text(tr2('دسترسی سریع', 'Quick access'), style: h2())),
          SizedBox(height: 10 * k),
          Padding(
            padding: EdgeInsets.only(left: 31 * k, right: 25 * k),
            child: Row(children: [
              for (var i = 0; i < quick.length; i++) ...[
                if (i > 0) SizedBox(width: 15 * k),
                Expanded(child: _QuickTile(cat: quick[i], k: k, onTap: () => _go(context, quick[i].page))),
              ],
            ]),
          ),
          SizedBox(height: 24 * k),
          Padding(
            padding: EdgeInsets.only(left: 31 * k, right: 26 * k),
            child: Row(children: [
              Expanded(child: Text(tr2('ابزارهای کاربردی', 'Utilities'), style: h2())),
              InkWell(
                onTap: () => _go(context, const MoreScreen()),
                child: Row(children: [
                  Text(tr2('همه', 'See all'), style: TextStyle(fontSize: 15 * k, fontWeight: FontWeight.w500)),
                  SizedBox(width: 8 * k),
                  Icon(Icons.chevron_right_rounded, size: 20 * k),
                ]),
              ),
            ]),
          ),
          SizedBox(height: 12 * k),
          for (final t in _tools) _UtilRow(tool: t, k: k),
        ]),
      ),
    );
    if (!dark) return body;
    return DecoratedBox(
      decoration: const BoxDecoration(gradient: RadialGradient(center: Alignment(0, -.55), radius: 1.1, colors: [Color(0xFF12141F), Color(0xFF0B0C14), Color(0xFF090A11)], stops: [0, .7, 1])),
      child: body,
    );
  }
}
