import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart' hide Icon;
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../core/layouts.dart';
import '../core/office_prefs.dart';
import '../services/native.dart';
import '../services/saf.dart';
import '../services/office_service.dart';
import '../widgets/app_icon.dart';
import '../widgets/office_chrome.dart';
import '../widgets/office_sheet.dart';
import '../widgets/ui.dart';
import '../widgets/xlsx_canvas.dart';
import 'office_new.dart';
import 'saf_prompt.dart';
import 'xlsx_dialogs.dart';

/// .xlsx / .xlsm editor: ribbon (Home / Insert / Formulas / Data / View), rich cell formatting, number formats,
/// merge, freeze panes, sort / filter, conditional formats, data validation, charts, find & replace, undo / redo.
class XlsxScreen extends StatefulWidget {
  final String path;
  const XlsxScreen({super.key, required this.path});
  @override
  State<XlsxScreen> createState() => _XlsxScreenState();
}

class _XlsxScreenState extends State<XlsxScreen> {
  XlsxFile? x;
  int cur = 0, version = 0, curC = 0, curR = 1, extraRows = 0, extraCols = 0;
  XRange sel = XRange.cell(0, 1);
  double zoom = 1;
  bool showFormulas = false;
  String tab = 'home';
  XClip? clip;
  String clipText = '';
  XChart? chart;
  final _undo = <XSnap>[], _redo = <XSnap>[];
  final _canvas = GlobalKey<XlsxCanvasState>();

  XSheet get s => x!.sheets[cur];
  String get ref => refOf(curC, curR);
  XStyle get curStyle => s.styles[ref] ?? XStyle.plain;

  @override
  void initState() {
    super.initState();
    XlsxFile.open(widget.path).then((v) {
      if (!mounted) return;
      setState(() {
        x = v;
        cur = v.sheets.indexWhere((e) => !e.hidden).clamp(0, v.sheets.length - 1).toInt();
      });
    }).catchError((e) {
      if (mounted) {
        snack(context, '$e');
        Navigator.pop(context);
      }
    });
  }

  // ------------------------------------------------------------------ core
  void _do(void Function(XlsxFile f, XSheet s) action) {
    final f = x;
    if (f == null) return;
    final snap = f.z.liteSnapshot();
    try {
      action(f, f.sheets[cur]);
    } catch (e) {
      f.z.restoreLite(snap);
      _reload();
      snack(context, '$e');
      return;
    }
    _undo.add(snap);
    if (_undo.length > 30) _undo.removeAt(0);
    _redo.clear();
    xCondCache.clear();
    setState(() => version++);
  }

  void _reload() {
    final nf = XlsxFile.load(x!.z);
    xCondCache.clear();
    setState(() {
      x = nf;
      cur = cur.clamp(0, nf.sheets.length - 1).toInt();
      chart = null;
      version++;
    });
  }

  void _undoOp() {
    if (_undo.isEmpty) return;
    _redo.add(x!.z.liteSnapshot());
    x!.z.restoreLite(_undo.removeLast());
    _reload();
  }

  void _redoOp() {
    if (_redo.isEmpty) return;
    _undo.add(x!.z.liteSnapshot());
    x!.z.restoreLite(_redo.removeLast());
    _reload();
  }

  void _select(XRange r, {int? c, int? rr}) => setState(() {
        sel = r;
        curC = c ?? r.c1;
        curR = rr ?? r.r1;
        chart = null;
      });

  void _goCell(int c, int r, {int? sheet}) {
    setState(() {
      if (sheet != null) cur = sheet;
      curC = c;
      curR = r;
      sel = XRange.cell(c, r);
      chart = null;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _canvas.currentState?.ensureVisible(c, r));
  }

  /// Limits whole-row / whole-column selections to the used area.
  XRange _used(XRange r) {
    final maxR = r.r2 > s.rows + 100 ? (s.rows < 100 ? 100 : s.rows) : r.r2;
    final maxC = r.c2 > s.cols + 20 ? (s.cols < 26 ? 26 : s.cols) - 1 : r.c2;
    return XRange(r.c1, r.r1, maxC < r.c1 ? r.c1 : maxC, maxR < r.r1 ? r.r1 : maxR);
  }

  void _style(XStyle Function(XStyle) f) => _do((fl, sh) => fl.applyStyle(sh, _used(sel), f));

  /// Contiguous block of data around a cell.
  XRange _region(int c, int r) {
    if (s.cells.isEmpty) return XRange.cell(c, r);
    var c1 = c, c2 = c, r1 = r, r2 = r;
    bool has(int cc, int rr) => s.cells.containsKey(refOf(cc, rr));
    var grown = true;
    var guard = 0;
    while (grown && guard++ < 400) {
      grown = false;
      bool col(int cc, int a, int b) {
        for (var rr = a; rr <= b; rr++) {
          if (has(cc, rr)) return true;
        }
        return false;
      }

      bool row(int rr, int a, int b) {
        for (var cc = a; cc <= b; cc++) {
          if (has(cc, rr)) return true;
        }
        return false;
      }

      if (c1 > 0 && col(c1 - 1, r1 - 1 < 1 ? 1 : r1 - 1, r2 + 1)) {
        c1--;
        grown = true;
      }
      if (col(c2 + 1, r1 - 1 < 1 ? 1 : r1 - 1, r2 + 1)) {
        c2++;
        grown = true;
      }
      if (r1 > 1 && row(r1 - 1, c1 > 0 ? c1 - 1 : 0, c2 + 1)) {
        r1--;
        grown = true;
      }
      if (row(r2 + 1, c1 > 0 ? c1 - 1 : 0, c2 + 1)) {
        r2++;
        grown = true;
      }
    }
    return XRange(c1, r1, c2, r2);
  }

  XRange _dataRange() => sel.isCell ? _region(curC, curR) : _used(sel);

  bool _guessHeader(XRange rg) {
    if (rg.rows < 2) return false;
    var texts = 0;
    for (var c = rg.c1; c <= rg.c2; c++) {
      final v = x!.cellValue(s, refOf(c, rg.r1));
      if (v is String && v.isNotEmpty) texts++;
    }
    return texts >= (rg.cols / 2).ceil();
  }

  // ------------------------------------------------------------------ entry
  (String, String?) _smart(String t, String curFmt) {
    var text = t.trim();
    if (text.isEmpty || text.startsWith('=') || text.startsWith("'")) return (t, null);
    const fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
    if (RegExp('^[0-9$fa$ar.,٫٬\\-+%/:]+\$').hasMatch(text)) {
      final b = StringBuffer();
      for (final ch in text.split('')) {
        final i = fa.indexOf(ch) >= 0 ? fa.indexOf(ch) : ar.indexOf(ch);
        b.write(i >= 0 ? '$i' : (ch == '٫' ? '.' : (ch == '٬' ? ',' : ch)));
      }
      text = b.toString();
    }
    final d = RegExp(r'^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$').firstMatch(text);
    if (d != null) {
      final dt = DateTime.utc(int.parse(d[1]!), int.parse(d[2]!), int.parse(d[3]!));
      return (XNumFmt.general(XNumFmt.toSerial(dt)), curFmt.isEmpty ? 'yyyy-mm-dd' : null);
    }
    final pc = RegExp(r'^(-?\d+(?:\.(\d+))?)%$').firstMatch(text);
    if (pc != null) {
      final v = double.parse(pc[1]!) / 100;
      return (XNumFmt.general(double.parse(v.toStringAsFixed(10))), curFmt.isEmpty ? (pc[2] == null ? '0%' : '0.${'0' * pc[2]!.length}%') : null);
    }
    final tm = RegExp(r'^(\d{1,2}):(\d{2})(?::(\d{2}))?$').firstMatch(text);
    if (tm != null) {
      final v = (int.parse(tm[1]!) * 3600 + int.parse(tm[2]!) * 60 + int.parse(tm[3] ?? '0')) / 86400;
      return (v.toString(), curFmt.isEmpty ? (tm[3] == null ? 'h:mm' : 'h:mm:ss') : null);
    }
    final th = RegExp(r'^-?\d{1,3}(,\d{3})+(\.\d+)?$').firstMatch(text);
    if (th != null) return (text.replaceAll(',', ''), curFmt.isEmpty ? '#,##0${th[2] == null ? '' : '.${'0' * (th[2]!.length - 1)}'}' : null);
    if (text != t.trim() && double.tryParse(text) != null) return (text, null);
    return (t, null);
  }

  void _commit(int c, int r, String text) {
    final f = x!;
    final err = f.validate(s, c, r, text);
    if (err != null) {
      final v = f.validationAt(s, c, r);
      snack(context, err == 'list' ? tr2('مقدار باید از فهرست انتخاب شود', 'Value must come from the list') : (err == 'range' ? tr2('مقدار خارج از محدودهٔ مجاز است', 'Value is outside the allowed range') : (err == 'number' ? tr2('نوع داده معتبر نیست', 'Invalid data type') : tr2('این سلول نمی‌تواند خالی باشد', 'Cell cannot be blank'))) + (v == null ? '' : ''));
      return;
    }
    final rf = refOf(c, r);
    final (content, fmt) = _smart(text, s.styles[rf]?.numFmt ?? '');
    _do((fl, sh) {
      fl.setCell(sh, rf, content);
      if (fmt != null) fl.applyStyle(sh, XRange.cell(c, r), (st) => st.copyWith(numFmt: fmt));
    });
  }

  Future<void> _editCell(int c, int r) async {
    final f = x!;
    final rf = refOf(c, r);
    final v = f.validationAt(s, c, r);
    if (v != null && v.type == 'list' && v.dropdown) {
      final items = f.validationItems(s, v);
      final pick = await showModalBottomSheet<String>(
        context: context,
        showDragHandle: true,
        builder: (ctx) => Theme(data: officeTheme(context), child: SafeArea(child: ListView(shrinkWrap: true, children: [for (final i in items) ListTile(title: Text(i), onTap: () => Navigator.pop(ctx, i))]))),
      );
      if (pick != null) _commit(c, r, pick);
      return;
    }
    final ctl = TextEditingController(text: s.formulas.containsKey(rf) ? '=${s.formulas[rf]}' : (s.cells[rf] ?? ''));
    final r2 = await showDialog<String>(
      context: context,
      builder: (ctx) => Theme(
        data: officeTheme(context),
        child: AlertDialog(
          title: Text(rf),
          content: TextField(controller: ctl, autofocus: true, minLines: 1, maxLines: 10, decoration: InputDecoration(helperText: v?.message.isEmpty == false ? v!.message : null)),
          actions: [
            TextButton(onPressed: () async {
              final fn = await pickFunction(ctx);
              if (fn != null) ctl.text = '${ctl.text.startsWith('=') ? ctl.text : '='}$fn(';
              ctl.selection = TextSelection.collapsed(offset: ctl.text.length);
            }, child: officeFx(kOfficeGreen, size: 20)),
            CancelButton(onPressed: () => Navigator.pop(ctx)),
            FilledButton(onPressed: () => Navigator.pop(ctx, ctl.text), child: Text(L.t('ok'))),
          ],
        ),
      ),
    );
    if (r2 != null) _commit(c, r, r2);
  }

  // ------------------------------------------------------------------ clipboard
  Future<void> _copy({bool cut = false}) async {
    final f = x!;
    final rg = _used(sel);
    clip = f.copyRange(s, rg, cut: cut);
    clipText = f.rangeText(s, rg);
    await Clipboard.setData(ClipboardData(text: clipText));
    if (mounted) snack(context, cut ? tr2('بریده شد', 'Cut') : tr2('کپی شد', 'Copied'));
  }

  Future<void> _paste({String mode = 'all', bool transpose = false}) async {
    final sys = (await Clipboard.getData('text/plain'))?.text ?? '';
    XClip? c = clip;
    if (c == null || (sys.isNotEmpty && sys.trimRight() != clipText.trimRight())) {
      if (sys.isEmpty) return;
      final lines = sys.replaceAll('\r', '').split('\n');
      while (lines.isNotEmpty && lines.last.isEmpty) {
        lines.removeLast();
      }
      final cells = [for (final l in lines) [for (final t in l.split('\t')) XClipCell(_smart(t, '').$1, XStyle.plain)]];
      final w = cells.fold<int>(1, (a, b) => b.length > a ? b.length : a);
      for (final r in cells) {
        while (r.length < w) {
          r.add(const XClipCell('', XStyle.plain));
        }
      }
      c = XClip(cells.length, w, cells, false, XRange(sel.c1, sel.r1, sel.c1 + w - 1, sel.r1 + cells.length - 1));
    }
    final cc = c;
    _do((f, sh) {
      final r = f.pasteClip(sh, sel.c1, sel.r1, cc, mode: mode, transpose: transpose);
      sel = r;
    });
    if (cc.cut) clip = null;
  }

  // ------------------------------------------------------------------ formatting helpers
  void _toggleBool(bool Function(XStyle) get, XStyle Function(XStyle, bool) set) {
    final on = !get(curStyle);
    _style((st) => set(st, on));
  }

  void _size(double d) {
    final v = ((curStyle.size ?? 11) + d).clamp(6, 72).toDouble();
    _style((st) => st.copyWith(size: v));
  }

  void _align({String? h, String? v}) {
    final cs = curStyle;
    _style((st) => st.copyWith(h: h == null ? st.h : (cs.h == h ? '' : h), v: v == null ? st.v : (cs.v == v ? '' : v)));
  }

  void _decimals(int delta) {
    var code = curStyle.numFmt;
    if (code.isEmpty || code == 'General') {
      final t = x!.displayText(s, ref);
      final d = t.contains('.') ? t.split('.').last.replaceAll(RegExp(r'\D'), '').length : 0;
      final n = (d + delta).clamp(0, 15).toInt();
      code = n == 0 ? '0' : '0.${'0' * n}';
    } else {
      final m = RegExp(r'\.(0+)').firstMatch(code);
      if (m != null) {
        final n = (m[1]!.length + delta).clamp(0, 15).toInt();
        code = code.replaceFirst(RegExp(r'\.0+'), n == 0 ? '' : '.${'0' * n}');
      } else if (delta > 0) {
        final i = code.lastIndexOf('0');
        if (i >= 0) code = '${code.substring(0, i + 1)}.0${code.substring(i + 1)}';
      }
    }
    _style((st) => st.copyWith(numFmt: code));
  }

  Future<void> _fontColor() async {
    final c = await pickColor(context, title: tr2('رنگ متن', 'Text colour'), current: curStyle.color);
    if (c == null) return;
    _style((st) => c < 0 ? st.copyWith(clearColor: true) : st.copyWith(color: c));
  }

  Future<void> _fillColor() async {
    final c = await pickColor(context, title: tr2('رنگ پس‌زمینه', 'Fill colour'), current: curStyle.fill);
    if (c == null) return;
    _style((st) => c < 0 ? st.copyWith(clearFill: true) : st.copyWith(fill: c));
  }

  Future<void> _fontMenu() async {
    const fonts = ['', 'Calibri', 'Arial', 'Times New Roman', 'Courier New', 'Tahoma', 'Verdana', 'Georgia', 'Segoe UI', 'Vazirmatn', 'B Nazanin', 'Sahel'];
    final f = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (ctx) => Theme(data: officeTheme(context), child: SafeArea(child: ListView(shrinkWrap: true, children: [for (final n in fonts) ListTile(dense: true, selected: curStyle.font == n, title: Text(n.isEmpty ? tr2('پیش‌فرض', 'Default') : n, style: TextStyle(fontFamily: n.isEmpty ? null : n)), onTap: () => Navigator.pop(ctx, n))]))),
    );
    if (f != null) _style((st) => st.copyWith(font: f));
  }

  Future<void> _sizeDialog() async {
    final v = await promptText(context, tr2('اندازهٔ قلم', 'Font size'), initial: '${(curStyle.size ?? 11).toStringAsFixed(curStyle.size == null || curStyle.size == curStyle.size!.roundToDouble() ? 0 : 1)}');
    final d = double.tryParse(v ?? '');
    if (d != null && d >= 6 && d <= 200) _style((st) => st.copyWith(size: d));
  }

  Future<void> _bordersMenu() async {
    final rg = _used(sel);
    void apply(String kind) => _do((f, sh) {
          var n = 0;
          for (var r = rg.r1; r <= rg.r2 && n < 4000; r++) {
            for (var c = rg.c1; c <= rg.c2 && n < 4000; c++, n++) {
              var bits = 0;
              switch (kind) {
                case 'all':
                  bits = XBorder.all;
                case 'outer':
                  bits = (c == rg.c1 ? XBorder.left : 0) | (c == rg.c2 ? XBorder.right : 0) | (r == rg.r1 ? XBorder.top : 0) | (r == rg.r2 ? XBorder.bottom : 0);
                case 'top':
                  bits = r == rg.r1 ? XBorder.top : 0;
                case 'bottom':
                  bits = r == rg.r2 ? XBorder.bottom : 0;
                case 'left':
                  bits = c == rg.c1 ? XBorder.left : 0;
                case 'right':
                  bits = c == rg.c2 ? XBorder.right : 0;
              }
              f.applyStyle(sh, XRange.cell(c, r), (st) => st.copyWith(border: kind == 'none' ? 0 : (kind == 'all' ? bits : st.border | bits)));
            }
          }
        });
    final items = <(String, IconData, String)>[
      ('all', Icons.border_all_rounded, tr2('همهٔ کادرها', 'All borders')),
      ('outer', Icons.border_outer_rounded, tr2('کادر بیرونی', 'Outside borders')),
      ('top', Icons.border_top_rounded, tr2('بالا', 'Top')),
      ('bottom', Icons.border_bottom_rounded, tr2('پایین', 'Bottom')),
      ('left', Icons.border_left_rounded, tr2('چپ', 'Left')),
      ('right', Icons.border_right_rounded, tr2('راست', 'Right')),
      ('none', Icons.border_clear_rounded, tr2('بدون کادر', 'No border')),
    ];
    final k = await _menu(tr2('کادر', 'Borders'), [for (final i in items) (i.$1, i.$2, i.$3)]);
    if (k != null) apply(k);
  }

  /// Generic bottom-sheet menu; returns the chosen key.
  Future<String?> _menu(String title, List<(String, IconData, String)> items) => showModalBottomSheet<String>(
        context: context,
        showDragHandle: true,
        isScrollControlled: true,
        builder: (ctx) => Theme(
          data: officeTheme(context),
          child: SafeArea(
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Padding(padding: const EdgeInsets.only(bottom: 6), child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
                for (final i in items) ListTile(dense: true, leading: Icon(i.$2, color: kOfficeGreen), title: Text(i.$3), onTap: () => Navigator.pop(ctx, i.$1)),
                const SizedBox(height: 8),
              ]),
            ),
          ),
        ),
      );

  Future<void> _alignMenu() async {
    final k = await _menu(tr2('تراز', 'Alignment'), [
      ('l', Icons.format_align_left_rounded, tr2('چپ‌چین', 'Left')),
      ('c', Icons.format_align_center_rounded, tr2('وسط‌چین', 'Center')),
      ('r', Icons.format_align_right_rounded, tr2('راست‌چین', 'Right')),
      ('j', Icons.format_align_justify_rounded, tr2('تراز دو طرف', 'Justify')),
      ('t', Icons.vertical_align_top_rounded, tr2('بالا', 'Top')),
      ('m', Icons.vertical_align_center_rounded, tr2('وسط عمودی', 'Middle')),
      ('b', Icons.vertical_align_bottom_rounded, tr2('پایین', 'Bottom')),
      ('i+', Icons.format_indent_increase_rounded, tr2('افزایش تورفتگی', 'Increase indent')),
      ('i-', Icons.format_indent_decrease_rounded, tr2('کاهش تورفتگی', 'Decrease indent')),
    ]);
    switch (k) {
      case 'l':
        _align(h: 'left');
      case 'c':
        _align(h: 'center');
      case 'r':
        _align(h: 'right');
      case 'j':
        _align(h: 'justify');
      case 't':
        _align(v: 'top');
      case 'm':
        _align(v: 'center');
      case 'b':
        _align(v: 'bottom');
      case 'i+':
        _style((st) => st.copyWith(indent: (st.indent + 1).clamp(0, 15).toInt()));
      case 'i-':
        _style((st) => st.copyWith(indent: (st.indent - 1).clamp(0, 15).toInt()));
    }
  }

  void _wrap() {
    final on = !curStyle.wrap;
    _style((st) => st.copyWith(wrap: on));
    if (on) _autoFitRows(rows: [for (var r = sel.r1; r <= (sel.r2 > s.rows ? s.rows : sel.r2); r++) r]);
  }

  void _merge() {
    final merged = s.mergeAt(sel.c1, sel.r1) == sel;
    if (merged) {
      _do((f, sh) => f.unmergeCells(sh, sel));
    } else if (!sel.isCell) {
      _do((f, sh) => f.mergeCells(sh, sel));
      _style((st) => st.copyWith(h: st.h.isEmpty ? 'center' : st.h));
    }
  }

  Future<void> _numFmt() async {
    final c = await pickNumFmt(context, curStyle.numFmt);
    if (c != null) _style((st) => st.copyWith(numFmt: c));
  }

  Future<void> _cellStyles() async {
    final presets = <(String, String, XStyle)>[
      ('عنوان', 'Title', const XStyle(bold: true, size: 18)),
      ('سرتیتر', 'Heading', const XStyle(bold: true, size: 13, border: XBorder.bottom)),
      ('خوب', 'Good', const XStyle(fill: 0xC6EFCE, color: 0x006100)),
      ('بد', 'Bad', const XStyle(fill: 0xFFC7CE, color: 0x9C0006)),
      ('خنثی', 'Neutral', const XStyle(fill: 0xFFEB9C, color: 0x9C5700)),
      ('یادداشت', 'Note', const XStyle(fill: 0xFFFFCC, border: XBorder.all)),
      ('جمع کل', 'Total', const XStyle(bold: true, border: XBorder.top | XBorder.bottom)),
      ('ورودی', 'Input', const XStyle(fill: 0xFFCC99, color: 0x3F3F76, border: XBorder.all)),
      ('سرستون', 'Header', const XStyle(bold: true, fill: 0x107C41, color: 0xFFFFFF, h: 'center')),
    ];
    final k = await _menu(tr2('سبک‌های سلول', 'Cell styles'), [for (var i = 0; i < presets.length; i++) ('$i', Icons.style_rounded, tr2(presets[i].$1, presets[i].$2))]);
    if (k == null) return;
    final pr = presets[int.parse(k)].$3;
    _style((st) => pr.copyWith(numFmt: st.numFmt));
  }

  Future<void> _clearMenu() async {
    final k = await _menu(tr2('پاک کردن', 'Clear'), [
      ('all', Icons.cleaning_services_rounded, tr2('همه چیز', 'Everything')),
      ('contents', Icons.backspace_outlined, tr2('فقط محتوا', 'Contents only')),
      ('formats', Icons.format_clear_rounded, tr2('فقط قالب', 'Formats only')),
    ]);
    if (k != null) _do((f, sh) => f.clearRange(sh, _used(sel), what: k));
  }

  Future<void> _pasteMenu() async {
    final k = await _menu(tr2('چسباندن', 'Paste'), [
      ('all', Icons.content_paste_rounded, tr2('همه', 'All')),
      ('values', Icons.pin_outlined, tr2('فقط مقادیر', 'Values only')),
      ('formulas', Icons.functions_rounded, tr2('فقط فرمول‌ها', 'Formulas only')),
      ('formats', Icons.format_paint_rounded, tr2('فقط قالب', 'Formats only')),
      ('transpose', Icons.swap_calls_rounded, tr2('جابه‌جایی سطر و ستون', 'Transpose')),
    ]);
    if (k == null) return;
    if (k == 'transpose') {
      await _paste(transpose: true);
    } else {
      await _paste(mode: k);
    }
  }

  // ------------------------------------------------------------------ conditional formats
  Future<void> _condMenu() async {
    final k = await _menu(tr2('قالب‌بندی شرطی', 'Conditional formatting'), [
      ('gt', Icons.chevron_right_rounded, tr2('بزرگ‌تر از…', 'Greater than…')),
      ('lt', Icons.chevron_left_rounded, tr2('کوچک‌تر از…', 'Less than…')),
      ('eq', Icons.drag_handle_rounded, tr2('برابر با…', 'Equal to…')),
      ('between', Icons.swap_horiz_rounded, tr2('بین…', 'Between…')),
      ('text', Icons.text_fields_rounded, tr2('شامل متن…', 'Text contains…')),
      ('dup', Icons.content_copy_rounded, tr2('مقادیر تکراری', 'Duplicate values')),
      ('unique', Icons.filter_1_rounded, tr2('مقادیر یکتا', 'Unique values')),
      ('s1', Icons.gradient_rounded, tr2('مقیاس رنگ: سبز-زرد-قرمز', 'Colour scale: green-yellow-red')),
      ('s2', Icons.gradient_rounded, tr2('مقیاس رنگ: قرمز-زرد-سبز', 'Colour scale: red-yellow-green')),
      ('s3', Icons.gradient_rounded, tr2('مقیاس رنگ: سفید-سبز', 'Colour scale: white-green')),
      ('s4', Icons.gradient_rounded, tr2('مقیاس رنگ: سفید-آبی', 'Colour scale: white-blue')),
      ('manage', Icons.list_alt_rounded, tr2('مدیریت قوانین', 'Manage rules')),
      ('clear', Icons.layers_clear_rounded, tr2('پاک کردن قوانین', 'Clear rules')),
    ]);
    if (k == null || !mounted) return;
    final rg = _used(sel);
    if (k == 'clear') {
      _do((f, sh) {
        sh.conds.removeWhere((c) => c.range.intersects(rg));
        f.writeConditionalFormats(sh);
      });
    } else if (k == 'manage') {
      await _manageRules();
    } else if (k.startsWith('s')) {
      const scales = {
        's1': [0x63BE7B, 0xFFEB84, 0xF8696B],
        's2': [0xF8696B, 0xFFEB84, 0x63BE7B],
        's3': [0xFFFFFF, 0x63BE7B],
        's4': [0xFFFFFF, 0x5A8AC6],
      };
      _do((f, sh) {
        sh.conds.add(XCond(type: 'colorScale', range: rg, scale: scales[k]!));
        f.writeConditionalFormats(sh);
      });
    } else {
      final cd = await condDialog(context, rg, k);
      if (cd != null) {
        _do((f, sh) {
          sh.conds.add(cd);
          f.writeConditionalFormats(sh);
        });
      }
    }
  }

  Future<void> _manageRules() async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (ctx) => Theme(
        data: officeTheme(context),
        child: StatefulBuilder(
          builder: (ctx, set) => SafeArea(
            child: ListView(shrinkWrap: true, children: [
              if (s.conds.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Center(child: Text(tr2('قانونی وجود ندارد', 'No rules')))),
              for (final c in List.of(s.conds))
                ListTile(
                  dense: true,
                  leading: Container(width: 22, height: 22, color: c.fill != null ? Color(0xFF000000 | c.fill!) : Colors.grey.shade300),
                  title: Text('${c.type} ${c.op} ${c.v1}${c.v2.isEmpty ? '' : ' / ${c.v2}'}'),
                  subtitle: Text(c.range.ref),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline_rounded),
                    onPressed: () {
                      _do((f, sh) {
                        sh.conds.remove(c);
                        f.writeConditionalFormats(sh);
                      });
                      set(() {});
                    },
                  ),
                ),
            ]),
          ),
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ data tools
  void _sortQuick(bool asc) {
    final rg = _dataRange();
    final key = curC < rg.c1 ? rg.c1 : (curC > rg.c2 ? rg.c2 : curC);
    _do((f, sh) => f.sortRange(sh, rg, [(key, asc)], header: _guessHeader(rg)));
  }

  Future<void> _sortCustom() async {
    final rg = _dataRange();
    final r = await sortDialog(context, x!, s, rg, header: _guessHeader(rg), firstKey: curC < rg.c1 || curC > rg.c2 ? rg.c1 : curC);
    if (r != null) _do((f, sh) => f.sortRange(sh, rg, r.keys, header: r.header));
  }

  void _toggleFilter() {
    if (s.filter == null) {
      _do((f, sh) => f.setAutoFilter(sh, _dataRange()));
    } else {
      _do((f, sh) => f.setAutoFilter(sh, null));
    }
  }

  Future<void> _filterMenu(int col) async {
    final f = x!;
    final rg = s.filter;
    if (rg == null) return;
    final vals = f.distinctValues(s, rg, col);
    final r = await filterDialog(context, vals, s.filterValues[col], '${tr2('فیلتر ستون', 'Filter column')} ${colName(col)}');
    if (r == null) return;
    if (r.sort != null) {
      _do((fl, sh) => fl.sortRange(sh, rg, [(col, r.sort == 'asc')], header: true));
    } else if (r.clear) {
      _do((fl, sh) => fl.setColumnFilter(sh, col, null));
    } else {
      _do((fl, sh) => fl.setColumnFilter(sh, col, r.allowed));
    }
  }

  void _removeDuplicates() {
    final rg = _dataRange();
    if (rg.rows < 2) return;
    var removed = 0;
    _do((f, sh) => removed = f.removeDuplicates(sh, rg, [for (var c = rg.c1; c <= rg.c2; c++) c], header: _guessHeader(rg)));
    snack(context, tr2('$removed ردیف تکراری حذف شد', '$removed duplicate rows removed'));
  }

  Future<void> _textToColumns() async {
    final rg = XRange(sel.c1, sel.r1, sel.c1, _used(sel).r2);
    final custom = TextEditingController();
    var pick = ',';
    final d = await showDialog<String>(
      context: context,
      builder: (ctx) => Theme(
        data: officeTheme(context),
        child: StatefulBuilder(
          builder: (ctx, set) => AlertDialog(
            title: Text(tr2('متن به ستون', 'Text to columns')),
            content: Column(mainAxisSize: MainAxisSize.min, children: [
              Wrap(spacing: 8, children: [
                for (final o in [(',', tr2('ویرگول', 'Comma')), (';', tr2('نقطه‌ویرگول', 'Semicolon')), ('\t', 'Tab'), (' ', tr2('فاصله', 'Space')), ('|', '|'), ('', tr2('دلخواه', 'Custom'))])
                  ChoiceChip(label: Text(o.$2), selected: pick == o.$1, onSelected: (_) => set(() => pick = o.$1)),
              ]),
              if (pick.isEmpty) TextField(controller: custom, decoration: InputDecoration(labelText: tr2('جداکننده', 'Delimiter'))),
            ]),
            actions: [CancelButton(onPressed: () => Navigator.pop(ctx)), FilledButton(onPressed: () => Navigator.pop(ctx, pick.isEmpty ? custom.text : pick), child: Text(L.t('ok')))],
          ),
        ),
      ),
    );
    if (d != null && d.isNotEmpty) _do((f, sh) => f.splitColumn(sh, rg, d));
  }

  Future<void> _validation() async {
    final rg = _used(sel);
    final res = await validationDialog(context, rg, x!.validationAt(s, curC, curR));
    if (res == null) return;
    _do((f, sh) {
      sh.validations.removeWhere((v) => v.range.intersects(rg));
      if (res.validation != null) sh.validations.add(res.validation!);
      f.writeValidations(sh);
    });
  }

  // ------------------------------------------------------------------ formulas
  void _autoSum(String fn) {
    final f = x!;
    if (sel.isCell) {
      // look up, then left, for a block of numbers
      var r = curR - 1;
      while (r >= 1 && f.cellValue(s, refOf(curC, r)) is num) {
        r--;
      }
      if (r < curR - 1) {
        _commit(curC, curR, '=$fn(${refOf(curC, r + 1)}:${refOf(curC, curR - 1)})');
        return;
      }
      var c = curC - 1;
      while (c >= 0 && f.cellValue(s, refOf(c, curR)) is num) {
        c--;
      }
      if (c < curC - 1) {
        _commit(curC, curR, '=$fn(${refOf(c + 1, curR)}:${refOf(curC - 1, curR)})');
        return;
      }
      _commit(curC, curR, '=$fn(');
      return;
    }
    final rg = _used(sel);
    _do((fl, sh) {
      for (var c = rg.c1; c <= rg.c2; c++) {
        fl.setCellRaw(sh, refOf(c, rg.r2 + 1), '=$fn(${refOf(c, rg.r1)}:${refOf(c, rg.r2)})');
      }
      fl.recalculateAll();
    });
  }

  Future<void> _autoSumMenu() async {
    final k = await _menu(tr2('جمع خودکار', 'AutoSum'), [
      ('SUM', Icons.functions_rounded, tr2('جمع', 'Sum')),
      ('AVERAGE', Icons.functions_rounded, tr2('میانگین', 'Average')),
      ('COUNT', Icons.functions_rounded, tr2('شمارش', 'Count')),
      ('MAX', Icons.functions_rounded, tr2('بیشترین', 'Max')),
      ('MIN', Icons.functions_rounded, tr2('کمترین', 'Min')),
    ]);
    if (k != null) _autoSum(k);
  }

  Future<void> _insertFunction() async {
    final fn = await pickFunction(context);
    if (fn == null) return;
    final cur0 = s.formulas.containsKey(ref) ? '=${s.formulas[ref]}' : (s.cells[ref] ?? '');
    final text = cur0.startsWith('=') && cur0.length > 1 ? '$cur0$fn(' : '=$fn(';
    final ctl = TextEditingController(text: text);
    final r = await showDialog<String>(
      context: context,
      builder: (ctx) => Theme(data: officeTheme(context), child: AlertDialog(title: Text(ref), content: TextField(controller: ctl, autofocus: true, textDirection: TextDirection.ltr), actions: [CancelButton(onPressed: () => Navigator.pop(ctx)), FilledButton(onPressed: () => Navigator.pop(ctx, ctl.text), child: Text(L.t('ok')))])),
    );
    if (r != null) _commit(curC, curR, r);
  }

  Future<void> _namesDialog() async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (ctx) => Theme(
        data: officeTheme(context),
        child: StatefulBuilder(
          builder: (ctx, set) => SafeArea(
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text(tr2('نام‌های تعریف‌شده', 'Named ranges'), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                for (final e in x!.definedNames.entries.toList())
                  ListTile(
                    dense: true,
                    title: Text(e.key, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text(e.value),
                    trailing: IconButton(icon: const Icon(Icons.delete_outline_rounded), onPressed: () { _do((f, sh) => f.setDefinedName(e.key, null)); set(() {}); }),
                  ),
                ListTile(
                  leading: const Icon(Icons.add_rounded),
                  title: Text(tr2('نام‌گذاری انتخاب فعلی', 'Name the current selection')),
                  onTap: () async {
                    final n = await promptText(context, tr2('نام (بدون فاصله)', 'Name (no spaces)'));
                    if (n == null || !RegExp(r'^[A-Za-z_\u0600-\u06FF][A-Za-z0-9_.\u0600-\u06FF]*$').hasMatch(n.trim()) || XRange.parse(n.trim()) != null) {
                      if (n != null && mounted) snack(context, tr2('نام نامعتبر است', 'Invalid name'));
                      return;
                    }
                    final rg = _used(sel);
                    final q = RegExp(r'^[A-Za-z_][A-Za-z0-9_.]*$').hasMatch(s.name) ? s.name : "'${s.name.replaceAll("'", "''")}'";
                    final abs = rg.isCell ? '\$${colName(rg.c1)}\$${rg.r1}' : '\$${colName(rg.c1)}\$${rg.r1}:\$${colName(rg.c2)}\$${rg.r2}';
                    _do((f, sh) => f.setDefinedName(n.trim(), '$q!$abs'));
                    set(() {});
                  },
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ rows / columns / sheet structure
  Future<void> _numberPrompt(String title, double initial, void Function(double) apply) async {
    final v = await promptText(context, title, initial: initial.toStringAsFixed(0));
    final d = double.tryParse(v ?? '');
    if (d != null && d > 0) apply(d);
  }

  List<int> get _selCols => [for (var c = sel.c1; c <= (sel.c2 > s.cols + 20 ? sel.c1 : sel.c2); c++) c];
  List<int> get _selRows => [for (var r = sel.r1; r <= (sel.r2 > s.rows + 100 ? sel.r1 : sel.r2); r++) r];

  void _autoFitCols() {
    final f = x!;
    _do((fl, sh) {
      for (final c in _selCols) {
        var w = 40.0;
        final to = sh.rows > 2000 ? 2000 : sh.rows;
        for (var r = 1; r <= to; r++) {
          final rf = refOf(c, r);
          if (!sh.cells.containsKey(rf)) continue;
          final st = sh.styles[rf];
          final tp = TextPainter(text: TextSpan(text: f.displayText(sh, rf), style: TextStyle(fontSize: (st?.size ?? 11) * 1.3, fontWeight: st?.bold == true ? FontWeight.w700 : FontWeight.w400)), textDirection: TextDirection.ltr, maxLines: 1)..layout();
          if (tp.width + 22 > w && !sh.merges.any((m) => m.contains(c, r))) w = tp.width + 22;
        }
        fl.setColWidth(sh, [c], w.clamp(40, 600).toDouble());
      }
    });
  }

  void _autoFitRows({List<int>? rows}) {
    final f = x!;
    final list = rows ?? _selRows;
    _do((fl, sh) {
      for (final r in list) {
        var h = 30.0;
        for (var c = 0; c < sh.cols; c++) {
          final rf = refOf(c, r);
          final st = sh.styles[rf];
          if (!sh.cells.containsKey(rf) || st?.wrap != true) continue;
          final tp = TextPainter(text: TextSpan(text: f.displayText(sh, rf), style: TextStyle(fontSize: (st?.size ?? 11) * 1.3, height: 1.15)), textDirection: TextDirection.ltr)..layout(maxWidth: (sh.colW(c) - 10).clamp(10, 2000).toDouble());
          if (tp.height + 10 > h) h = tp.height + 10;
        }
        if (h > 30) {
          fl.setRowHeight(sh, [r], h);
        } else {
          fl.resetRowHeight(sh, [r]);
        }
      }
    });
  }

  void _unhide({required bool cols}) {
    _do((f, sh) {
      if (cols) {
        f.setColsHidden(sh, [for (var c = (sel.c1 > 0 ? sel.c1 - 1 : 0); c <= sel.c2 + 1; c++) if (sh.hiddenCols.contains(c)) c], false);
      } else {
        f.setRowsHidden(sh, [for (var r = (sel.r1 > 1 ? sel.r1 - 1 : 1); r <= sel.r2 + 1; r++) if (sh.hiddenRows.contains(r)) r], false);
      }
    });
  }

  Future<void> _insertMenu() async {
    final k = await _menu(tr2('درج و حذف', 'Insert & delete'), [
      ('ra', Icons.table_rows_rounded, L.t('rowAbove')),
      ('rb', Icons.table_rows_rounded, L.t('rowBelow')),
      ('rd', Icons.delete_outline_rounded, L.t('delRow')),
      ('cl', Icons.view_column_rounded, L.t('colLeft')),
      ('cr', Icons.view_column_rounded, L.t('colRight')),
      ('cd', Icons.delete_outline_rounded, L.t('delCol')),
    ]);
    if (k == null) return;
    final n = k.startsWith('r') ? sel.rows : sel.cols;
    _do((f, sh) {
      for (var i = 0; i < (n > 50 ? 1 : n); i++) {
        switch (k) {
          case 'ra':
            f.shiftRows(sh, sel.r1, insert: true);
          case 'rb':
            f.shiftRows(sh, sel.r2 + 1, insert: true);
          case 'rd':
            f.shiftRows(sh, sel.r1, insert: false);
          case 'cl':
            f.shiftCols(sh, sel.c1, insert: true);
          case 'cr':
            f.shiftCols(sh, sel.c2 + 1, insert: true);
          case 'cd':
            f.shiftCols(sh, sel.c1, insert: false);
        }
      }
    });
  }

  Future<void> _freezeMenu() async {
    final k = await _menu(tr2('ثابت کردن پنجره', 'Freeze panes'), [
      ('sel', Icons.grid_on_rounded, tr2('ثابت کردن بالا و کنار سلول فعلی', 'Freeze above & left of cell')),
      ('row', Icons.table_rows_rounded, tr2('ثابت کردن ردیف اول', 'Freeze top row')),
      ('col', Icons.view_column_rounded, tr2('ثابت کردن ستون اول', 'Freeze first column')),
      ('off', Icons.grid_off_rounded, tr2('آزاد کردن', 'Unfreeze')),
    ]);
    if (k == null) return;
    _do((f, sh) {
      switch (k) {
        case 'sel':
          f.setFreeze(sh, curC, curR - 1);
        case 'row':
          f.setFreeze(sh, 0, 1);
        case 'col':
          f.setFreeze(sh, 1, 0);
        default:
          f.setFreeze(sh, 0, 0);
      }
    });
  }

  Future<void> _zoomMenu() async {
    final k = await _menu(tr2('بزرگ‌نمایی', 'Zoom'), [for (final z in [50, 75, 100, 125, 150, 200, 300]) ('$z', Icons.zoom_in_rounded, '$z%')]);
    if (k != null) setState(() => zoom = int.parse(k) / 100);
  }

  Future<void> _headerMenu(bool isCol, int idx) async {
    final inSel = isCol ? (idx >= sel.c1 && idx <= sel.c2 && sel.r1 == 1) : (idx >= sel.r1 && idx <= sel.r2 && sel.c1 == 0);
    if (!inSel) _select(isCol ? XRange(idx, 1, idx, s.rows + 100) : XRange(0, idx, s.cols + 20, idx), c: isCol ? idx : 0, rr: isCol ? 1 : idx);
    final k = await _menu(isCol ? '${tr2('ستون', 'Column')} ${colName(idx)}' : '${tr2('ردیف', 'Row')} $idx', [
      ('ins', Icons.add_box_outlined, tr2('درج قبل', 'Insert before')),
      ('ins2', Icons.add_box_outlined, tr2('درج بعد', 'Insert after')),
      ('del', Icons.delete_outline_rounded, tr2('حذف', 'Delete')),
      ('size', Icons.straighten_rounded, isCol ? tr2('عرض ستون…', 'Column width…') : tr2('ارتفاع ردیف…', 'Row height…')),
      ('fit', Icons.fit_screen_rounded, tr2('اندازهٔ خودکار', 'AutoFit')),
      ('hide', Icons.visibility_off_outlined, tr2('پنهان کردن', 'Hide')),
      ('show', Icons.visibility_outlined, tr2('نمایش پنهان‌ها', 'Unhide')),
      ('freeze', Icons.ac_unit_rounded, tr2('ثابت کردن تا اینجا', 'Freeze up to here')),
    ]);
    if (k == null) return;
    switch (k) {
      case 'ins':
        _do((f, sh) => isCol ? f.shiftCols(sh, idx, insert: true) : f.shiftRows(sh, idx, insert: true));
      case 'ins2':
        _do((f, sh) => isCol ? f.shiftCols(sh, idx + 1, insert: true) : f.shiftRows(sh, idx + 1, insert: true));
      case 'del':
        _do((f, sh) => isCol ? f.shiftCols(sh, idx, insert: false) : f.shiftRows(sh, idx, insert: false));
      case 'size':
        if (isCol) {
          await _numberPrompt(tr2('عرض ستون', 'Column width'), s.colW(idx), (v) => _do((f, sh) => f.setColWidth(sh, _selCols, v)));
        } else {
          await _numberPrompt(tr2('ارتفاع ردیف', 'Row height'), s.rowH(idx), (v) => _do((f, sh) => f.setRowHeight(sh, _selRows, v)));
        }
      case 'fit':
        isCol ? _autoFitCols() : _autoFitRows();
      case 'hide':
        _do((f, sh) => isCol ? f.setColsHidden(sh, _selCols, true) : f.setRowsHidden(sh, _selRows, true));
      case 'show':
        _unhide(cols: isCol);
      case 'freeze':
        _do((f, sh) => isCol ? f.setFreeze(sh, idx + 1, sh.frozenRows) : f.setFreeze(sh, sh.frozenCols, idx));
    }
  }

  Future<void> _cellMenu(int c, int r) async {
    _goCell(c, r);
    final k = await _menu(refOf(c, r), [
      ('edit', Icons.edit_outlined, tr2('ویرایش', 'Edit')),
      ('copy', Icons.copy_rounded, tr2('کپی', 'Copy')),
      ('cut', Icons.content_cut_rounded, tr2('برش', 'Cut')),
      ('paste', Icons.content_paste_rounded, tr2('چسباندن', 'Paste')),
      ('special', Icons.content_paste_go_rounded, tr2('چسباندن ویژه…', 'Paste special…')),
      ('clear', Icons.backspace_outlined, tr2('پاک کردن…', 'Clear…')),
      ('insert', Icons.add_box_outlined, tr2('درج / حذف…', 'Insert / delete…')),
      ('fmt', Icons.format_color_text_rounded, tr2('قالب عدد…', 'Number format…')),
    ]);
    switch (k) {
      case 'edit':
        await _editCell(c, r);
      case 'copy':
        await _copy();
      case 'cut':
        await _copy(cut: true);
      case 'paste':
        await _paste();
      case 'special':
        await _pasteMenu();
      case 'clear':
        await _clearMenu();
      case 'insert':
        await _insertMenu();
      case 'fmt':
        await _numFmt();
    }
  }

  // ------------------------------------------------------------------ sheets
  Future<void> _sheetMenu(int idx) async {
    final f = x!;
    final sh = f.sheets[idx];
    final k = await _menu(sh.name, [
      ('rename', Icons.drive_file_rename_outline_rounded, tr2('تغییر نام', 'Rename')),
      ('dup', Icons.copy_all_rounded, tr2('کپی برگه', 'Duplicate')),
      ('left', Icons.arrow_back_rounded, tr2('انتقال به قبل', 'Move left')),
      ('right', Icons.arrow_forward_rounded, tr2('انتقال به بعد', 'Move right')),
      ('color', Icons.palette_outlined, tr2('رنگ برگه', 'Tab colour')),
      ('rtl', Icons.swap_horiz_rounded, sh.rtl ? tr2('جهت چپ به راست', 'Left-to-right sheet') : tr2('جهت راست به چپ', 'Right-to-left sheet')),
      ('hide', Icons.visibility_off_outlined, tr2('پنهان کردن', 'Hide')),
      if (f.sheets.any((e) => e.hidden)) ('unhide', Icons.visibility_outlined, tr2('نمایش برگه‌های پنهان', 'Unhide sheets')),
      ('del', Icons.delete_outline_rounded, tr2('حذف برگه', 'Delete')),
    ]);
    if (k == null || !mounted) return;
    switch (k) {
      case 'rename':
        final n = await promptText(context, tr2('نام برگه', 'Sheet name'), initial: sh.name);
        if (n == null) return;
        String? err;
        _do((fl, _) => err = fl.renameSheet(sh, n));
        if (err != null && mounted) snack(context, err == 'exists' ? tr2('این نام قبلاً استفاده شده', 'Name already used') : tr2('نام نامعتبر است', 'Invalid name'));
      case 'dup':
        _do((fl, _) => cur = fl.sheets.indexOf(fl.duplicateSheet(sh)));
      case 'left':
        _do((fl, _) {
          fl.moveSheet(sh, -1);
          cur = fl.sheets.indexOf(sh);
        });
      case 'right':
        _do((fl, _) {
          fl.moveSheet(sh, 1);
          cur = fl.sheets.indexOf(sh);
        });
      case 'color':
        final c = await pickColor(context, title: tr2('رنگ برگه', 'Tab colour'), current: sh.tabColor);
        if (c != null) _do((fl, _) => fl.setTabColor(sh, c < 0 ? null : c));
      case 'rtl':
        _do((fl, _) => fl.setSheetView(sh, rtl: !sh.rtl));
      case 'hide':
        bool ok = true;
        _do((fl, _) => ok = fl.setSheetHidden(sh, true));
        if (!ok && mounted) snack(context, tr2('حداقل یک برگه باید نمایان بماند', 'At least one sheet must stay visible'));
        if (sh.hidden) setState(() => cur = f.sheets.indexWhere((e) => !e.hidden).clamp(0, f.sheets.length - 1).toInt());
      case 'unhide':
        _do((fl, _) {
          for (final e in fl.sheets) {
            if (e.hidden) fl.setSheetHidden(e, false);
          }
        });
      case 'del':
        if (await confirm(context, tr2('برگه «${sh.name}» حذف شود؟', 'Delete sheet "${sh.name}"?')) && mounted) {
          bool ok = false;
          _do((fl, _) {
            ok = fl.deleteSheet(sh);
            cur = cur.clamp(0, fl.sheets.length - 1).toInt();
            if (cur == idx && cur > 0) cur--;
          });
          if (!ok && mounted) snack(context, tr2('آخرین برگه قابل حذف نیست', 'The last sheet cannot be deleted'));
        }
    }
    setState(() {
      curC = 0;
      curR = 1;
      sel = XRange.cell(0, 1);
    });
  }

  void _addSheet() {
    final f = x!;
    _do((fl, _) {
      final sh = fl.addSheet(fl.freeSheetName(tr2('برگه', 'Sheet')), rtl: L.rtl);
      cur = fl.sheets.indexOf(sh);
    });
    setState(() {
      curC = 0;
      curR = 1;
      sel = XRange.cell(0, 1);
    });
    if (f.sheets.isEmpty) return;
  }

  // ------------------------------------------------------------------ charts
  Future<void> _insertChart() async {
    final rg = _dataRange();
    if (rg.cols < 2 && rg.rows < 2) {
      snack(context, tr2('ابتدا محدودهٔ داده را انتخاب کنید', 'Select the data range first'));
      return;
    }
    var type = 'col';
    var header = _guessHeader(rg), labels = true;
    final title = TextEditingController();
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => Theme(
        data: officeTheme(context),
        child: StatefulBuilder(
          builder: (ctx, set) => AlertDialog(
            title: Text(tr2('درج نمودار', 'Insert chart')),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(rg.ref, style: const TextStyle(color: Colors.grey)),
                Wrap(spacing: 8, children: [
                  for (final t in xChartTypes)
                    ChoiceChip(
                      avatar: Icon(switch (t) { 'col' => Icons.bar_chart_rounded, 'bar' => Icons.align_horizontal_left_rounded, 'line' => Icons.show_chart_rounded, 'area' => Icons.area_chart_rounded, 'pie' => Icons.pie_chart_rounded, _ => Icons.donut_large_rounded }, size: 18),
                      label: Text(switch (t) { 'col' => tr2('ستونی', 'Column'), 'bar' => tr2('میله‌ای', 'Bar'), 'line' => tr2('خطی', 'Line'), 'area' => tr2('ناحیه‌ای', 'Area'), 'pie' => tr2('دایره‌ای', 'Pie'), _ => tr2('حلقوی', 'Doughnut') }),
                      selected: type == t,
                      onSelected: (_) => set(() => type = t),
                    ),
                ]),
                TextField(controller: title, decoration: InputDecoration(labelText: tr2('عنوان نمودار', 'Chart title'))),
                CheckboxListTile(dense: true, contentPadding: EdgeInsets.zero, value: header, onChanged: (v) => set(() => header = v ?? true), title: Text(tr2('ردیف اول نام سری‌هاست', 'First row holds series names'))),
                CheckboxListTile(dense: true, contentPadding: EdgeInsets.zero, value: labels, onChanged: (v) => set(() => labels = v ?? true), title: Text(tr2('ستون اول برچسب دسته‌هاست', 'First column holds category labels'))),
              ]),
            ),
            actions: [CancelButton(onPressed: () => Navigator.pop(ctx, false)), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(L.t('ok')))],
          ),
        ),
      ),
    );
    if (go != true) return;
    XChart? made;
    _do((f, sh) => made = f.addChart(sh, type: type, data: rg, header: header, labels: labels, title: title.text.trim(), atCol: rg.c2 + 2, atRow: rg.r1 - 1));
    if (made != null) {
      setState(() => chart = made);
      WidgetsBinding.instance.addPostFrameCallback((_) => _canvas.currentState?.ensureVisible(made!.c1, made!.r1 + 1));
    }
  }

  Future<void> _chartMenu(XChart ch) async {
    final k = await _menu(tr2('نمودار', 'Chart'), [
      ('type', Icons.bar_chart_rounded, tr2('تغییر نوع', 'Change type')),
      ('title', Icons.title_rounded, tr2('ویرایش عنوان', 'Edit title')),
      ('left', Icons.arrow_back_rounded, tr2('جابه‌جایی به چپ', 'Move left')),
      ('right', Icons.arrow_forward_rounded, tr2('جابه‌جایی به راست', 'Move right')),
      ('up', Icons.arrow_upward_rounded, tr2('جابه‌جایی به بالا', 'Move up')),
      ('down', Icons.arrow_downward_rounded, tr2('جابه‌جایی به پایین', 'Move down')),
      ('big', Icons.zoom_out_map_rounded, tr2('بزرگ‌تر', 'Larger')),
      ('small', Icons.zoom_in_map_rounded, tr2('کوچک‌تر', 'Smaller')),
      ('del', Icons.delete_outline_rounded, tr2('حذف نمودار', 'Delete chart')),
    ]);
    if (k == null) return;
    switch (k) {
      case 'type':
        final t = await _menu(tr2('نوع نمودار', 'Chart type'), [for (final t in xChartTypes) (t, Icons.bar_chart_rounded, t)]);
        if (t != null) _do((f, sh) => f.updateChart(sh, ch, type: t));
      case 'title':
        final t = await promptText(context, tr2('عنوان', 'Title'), initial: ch.title);
        if (t != null) _do((f, sh) => f.updateChart(sh, ch, title: t));
      case 'left':
        _do((f, sh) => f.setChartAnchor(ch, ch.c1 > 0 ? ch.c1 - 1 : 0, ch.r1, ch.c2 - (ch.c1 > 0 ? 1 : 0), ch.r2));
      case 'right':
        _do((f, sh) => f.setChartAnchor(ch, ch.c1 + 1, ch.r1, ch.c2 + 1, ch.r2));
      case 'up':
        _do((f, sh) => f.setChartAnchor(ch, ch.c1, ch.r1 > 0 ? ch.r1 - 1 : 0, ch.c2, ch.r2 - (ch.r1 > 0 ? 1 : 0)));
      case 'down':
        _do((f, sh) => f.setChartAnchor(ch, ch.c1, ch.r1 + 1, ch.c2, ch.r2 + 1));
      case 'big':
        _do((f, sh) => f.setChartAnchor(ch, ch.c1, ch.r1, ch.c2 + 1, ch.r2 + 2));
      case 'small':
        _do((f, sh) => f.setChartAnchor(ch, ch.c1, ch.r1, ch.c2 > ch.c1 + 3 ? ch.c2 - 1 : ch.c2, ch.r2 > ch.r1 + 5 ? ch.r2 - 2 : ch.r2));
      case 'del':
        _do((f, sh) => f.deleteChart(sh, ch));
        setState(() => chart = null);
    }
  }

  // ------------------------------------------------------------------ find / goto / stats / export
  Future<void> _goto() async {
    final v = await promptText(context, tr2('رفتن به سلول یا نام', 'Go to cell or name'), initial: ref);
    if (v == null || !mounted) return;
    var t = v.trim();
    final named = x!.definedNames[t];
    if (named != null) t = named.split('!').last;
    final rg = XRange.parse(t.toUpperCase());
    if (rg == null) {
      snack(context, tr2('آدرس نامعتبر است', 'Invalid address'));
      return;
    }
    _goCell(rg.c1, rg.r1);
    if (!rg.isCell) setState(() => sel = rg);
  }

  Future<void> _findSheet({bool replace = false}) async {
    final f = x!;
    final q = TextEditingController(), rp = TextEditingController();
    var matchCase = false, whole = false, inF = false, all = false;
    var idx = -1;
    List<(int, String)> hits() => f.findAll(q.text, matchCase: matchCase, wholeCell: whole, inFormulas: inF, onlySheet: all ? null : cur);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Theme(
        data: officeTheme(context),
        child: StatefulBuilder(
          builder: (ctx, set) {
            final h = q.text.isEmpty ? <(int, String)>[] : hits();
            void step(int d) {
              if (h.isEmpty) return;
              idx = (idx + d) % h.length;
              if (idx < 0) idx += h.length;
              final pr = parseRef(h[idx].$2)!;
              _goCell(pr.$1, pr.$2, sheet: h[idx].$1);
              set(() {});
            }

            return SafeArea(
              child: Padding(
                padding: EdgeInsets.fromLTRB(16, 0, 16, MediaQuery.of(ctx).viewInsets.bottom + 12),
                child: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    TextField(controller: q, autofocus: true, onChanged: (_) => set(() => idx = -1), decoration: InputDecoration(labelText: tr2('جستجو', 'Find'), prefixIcon: const Icon(Icons.search_rounded), suffixText: q.text.isEmpty ? '' : '${h.isEmpty ? 0 : idx + 1}/${h.length}')),
                    TextField(controller: rp, decoration: InputDecoration(labelText: tr2('جایگزینی با', 'Replace with'), prefixIcon: const Icon(Icons.find_replace_rounded))),
                    Wrap(spacing: 6, children: [
                      FilterChip(label: Text(tr2('حساس به حروف', 'Match case')), selected: matchCase, onSelected: (v) => set(() => matchCase = v)),
                      FilterChip(label: Text(tr2('کل سلول', 'Whole cell')), selected: whole, onSelected: (v) => set(() => whole = v)),
                      FilterChip(label: Text(tr2('در فرمول‌ها', 'In formulas')), selected: inF, onSelected: (v) => set(() => inF = v)),
                      FilterChip(label: Text(tr2('همهٔ برگه‌ها', 'All sheets')), selected: all, onSelected: (v) => set(() => all = v)),
                    ]),
                    const SizedBox(height: 8),
                    Row(children: [
                      IconButton(onPressed: () => step(-1), icon: const Icon(Icons.keyboard_arrow_up_rounded)),
                      IconButton(onPressed: () => step(1), icon: const Icon(Icons.keyboard_arrow_down_rounded)),
                      const Spacer(),
                      TextButton(
                        onPressed: h.isEmpty || idx < 0
                            ? null
                            : () {
                                final hit = h[idx];
                                _do((fl, _) {
                                  fl.replaceIn(fl.sheets[hit.$1], hit.$2, q.text, rp.text, matchCase: matchCase, wholeCell: whole, inFormulas: inF);
                                  fl.recalculateAll();
                                });
                                set(() {});
                              },
                        child: Text(tr2('جایگزین', 'Replace')),
                      ),
                      FilledButton(
                        onPressed: h.isEmpty
                            ? null
                            : () {
                                var n = 0;
                                _do((fl, _) {
                                  for (final hit in h) {
                                    if (fl.replaceIn(fl.sheets[hit.$1], hit.$2, q.text, rp.text, matchCase: matchCase, wholeCell: whole, inFormulas: inF)) n++;
                                  }
                                  fl.recalculateAll();
                                });
                                snack(context, tr2('$n مورد جایگزین شد', '$n replaced'));
                                set(() => idx = -1);
                              },
                        child: Text(tr2('جایگزینی همه', 'Replace all')),
                      ),
                    ]),
                  ]),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  String _stats() {
    final f = x!;
    final rg = _used(sel);
    if (rg.isCell && !s.cells.containsKey(ref)) return '';
    if (rg.isCell) return '';
    var cnt = 0, nums = 0;
    double sum = 0, mn = double.infinity, mx = -double.infinity;
    var n = 0;
    for (final r in rg.refs) {
      if (++n > 50000) break;
      final v = f.cellValue(s, r);
      if (v == null || v == '') continue;
      cnt++;
      if (v is num) {
        nums++;
        sum += v;
        if (v < mn) mn = v.toDouble();
        if (v > mx) mx = v.toDouble();
      }
    }
    if (cnt == 0) return '';
    String g(double d) => XNumFmt.general(double.parse(d.toStringAsPrecision(10)));
    return nums == 0 ? '${tr2('تعداد', 'Count')}: $cnt' : '${tr2('جمع', 'Sum')}: ${g(sum)}   ${tr2('میانگین', 'Avg')}: ${g(sum / nums)}   ${tr2('تعداد', 'Count')}: $cnt   ${tr2('کمترین', 'Min')}: ${g(mn)}   ${tr2('بیشترین', 'Max')}: ${g(mx)}';
  }

  Future<void> _exportCsv() async {
    final f = x!;
    if (!await ensureSdAll(context, [widget.path])) return;
    final rg = XRange(0, 1, s.cols < 1 ? 0 : s.cols - 1, s.rows < 1 ? 1 : s.rows);
    String q(String v) => v.contains(',') || v.contains('"') || v.contains('\n') ? '"${v.replaceAll('"', '""')}"' : v;
    final b = StringBuffer('\uFEFF');
    for (var r = rg.r1; r <= rg.r2; r++) {
      b.writeln([for (var c = rg.c1; c <= rg.c2; c++) q(f.displayText(s, refOf(c, r)))].join(','));
    }
    final base = p.join(p.dirname(widget.path), '${p.basenameWithoutExtension(widget.path)}${f.sheets.length > 1 ? '_${s.name}' : ''}');
    var target = '$base.csv';
    var i = 2;
    while (File(target).existsSync()) {
      target = '$base ($i).csv';
      i++;
    }
    try {
      await Saf.writeBytes(target, utf8.encode(b.toString()));
      Native.scan(target);
      if (mounted) snack(context, '${tr2('ذخیره شد', 'Saved')}: ${p.basename(target)}');
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _save({required bool copy}) async {
    final f = x;
    if (f == null) return;
    if (!await ensureSdAll(context, [widget.path])) return;
    try {
      if (copy) {
        final t = await f.saveCopy();
        Native.scan(t);
        if (mounted) snack(context, '${tr2('ذخیره شد', 'Saved')}: ${p.basename(t)}');
      } else {
        await f.saveInPlace();
        Native.scan(widget.path);
        if (mounted) {
          setState(() {});
          snack(context, '${tr2('ذخیره شد', 'Saved')}: ${p.basename(widget.path)}');
        }
      }
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _info() async {
    final f = x!;
    final formulas = f.sheets.fold<int>(0, (a, b) => a + b.formulas.length);
    final cells = f.sheets.fold<int>(0, (a, b) => a + b.cells.length);
    final charts = f.sheets.fold<int>(0, (a, b) => a + b.charts.length);
    await showDialog<void>(
      context: context,
      builder: (ctx) => Theme(
        data: officeTheme(context),
        child: AlertDialog(
          title: Text(p.basename(widget.path)),
          content: Text('${tr2('برگه‌ها', 'Sheets')}: ${f.sheets.length}\n${tr2('سلول‌های دارای مقدار', 'Non-empty cells')}: $cells\n${tr2('فرمول‌ها', 'Formulas')}: $formulas\n${tr2('نمودارها', 'Charts')}: $charts\n${tr2('نام‌ها', 'Named ranges')}: ${f.definedNames.length}'),
          actions: [FilledButton(onPressed: () => Navigator.pop(ctx), child: Text(L.t('ok')))],
        ),
      ),
    );
  }

  // ------------------------------------------------------------------ ribbon
  Widget _tool(IconData ic, String label, VoidCallback? onTap, {bool on = false, Widget? glyph, Color? bar}) {
    final ink = OfficePrefs.c('ink');
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        width: 62,
        margin: const EdgeInsets.symmetric(horizontal: 1, vertical: 4),
        decoration: BoxDecoration(color: on ? OfficePrefs.c('green').withAlpha(46) : null, borderRadius: BorderRadius.circular(10)),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Stack(alignment: Alignment.bottomCenter, children: [
            Padding(padding: const EdgeInsets.only(bottom: 3), child: glyph ?? Icon(ic, size: 23, color: onTap == null ? ink.withAlpha(90) : (on ? OfficePrefs.c('green') : ink))),
            if (bar != null) Container(width: 20, height: 3.5, color: bar),
          ]),
          const SizedBox(height: 2),
          Text(label, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, height: 1.1, color: onTap == null ? ink.withAlpha(90) : ink)),
        ]),
      ),
    );
  }

  List<Widget> _tools() {
    final st = curStyle;
    final f = x!;
    switch (tab) {
      case 'insert':
        return [
          _tool(Icons.bar_chart_rounded, tr2('نمودار', 'Chart'), _insertChart),
          _tool(Icons.table_rows_rounded, tr2('درج/حذف', 'Insert/Del'), _insertMenu),
          _tool(Icons.functions_rounded, tr2('تابع', 'Function'), _insertFunction, glyph: officeFx(OfficePrefs.c('ink'), size: 22)),
          _tool(Icons.today_rounded, tr2('تاریخ امروز', 'Today'), () => _commit(curC, curR, '=TODAY()')),
          _tool(Icons.access_time_rounded, tr2('اکنون', 'Now'), () => _commit(curC, curR, '=NOW()')),
          _tool(Icons.table_chart_rounded, tr2('جدول', 'Table'), () {
            final rg = _dataRange();
            _do((fl, sh) {
              fl.setAutoFilter(sh, rg);
              for (var c = rg.c1; c <= rg.c2; c++) {
                fl.applyStyle(sh, XRange.cell(c, rg.r1), (x0) => x0.copyWith(bold: true, fill: 0x107C41, color: 0xFFFFFF));
              }
              for (var r = rg.r1 + 1; r <= rg.r2; r++) {
                if ((r - rg.r1).isEven) fl.applyStyle(sh, XRange(rg.c1, r, rg.c2, r), (x0) => x0.copyWith(fill: 0xE4F1E8));
              }
            });
          }),
          _tool(Icons.rule_rounded, tr2('اعتبارسنجی', 'Validation'), _validation),
          _tool(Icons.drive_file_rename_outline_rounded, tr2('نام محدوده', 'Names'), _namesDialog),
        ];
      case 'formulas':
        return [
          _tool(Icons.functions_rounded, tr2('جمع خودکار', 'AutoSum'), _autoSumMenu),
          _tool(Icons.functions_rounded, tr2('کتابخانه توابع', 'Functions'), _insertFunction, glyph: officeFx(OfficePrefs.c('ink'), size: 22)),
          _tool(Icons.drive_file_rename_outline_rounded, tr2('نام‌ها', 'Names'), _namesDialog),
          _tool(Icons.visibility_rounded, tr2('نمایش فرمول‌ها', 'Show formulas'), () => setState(() => showFormulas = !showFormulas), on: showFormulas),
          _tool(Icons.refresh_rounded, tr2('محاسبهٔ مجدد', 'Recalculate'), () {
            f.recalculateAll();
            xCondCache.clear();
            setState(() => version++);
          }),
          _tool(Icons.calculate_rounded, tr2('جمع', 'Sum'), () => _autoSum('SUM')),
          _tool(Icons.percent_rounded, tr2('میانگین', 'Average'), () => _autoSum('AVERAGE')),
        ];
      case 'data':
        return [
          _tool(Icons.arrow_downward_rounded, tr2('صعودی', 'Sort A→Z'), () => _sortQuick(true)),
          _tool(Icons.arrow_upward_rounded, tr2('نزولی', 'Sort Z→A'), () => _sortQuick(false)),
          _tool(Icons.sort_rounded, tr2('مرتب‌سازی', 'Custom sort'), _sortCustom),
          _tool(Icons.filter_alt_rounded, tr2('فیلتر', 'Filter'), _toggleFilter, on: s.filter != null),
          _tool(Icons.layers_clear_rounded, tr2('حذف تکراری‌ها', 'Remove dups'), _removeDuplicates),
          _tool(Icons.splitscreen_rounded, tr2('متن به ستون', 'Text→cols'), _textToColumns),
          _tool(Icons.rule_rounded, tr2('اعتبارسنجی', 'Validation'), _validation),
          _tool(Icons.rule_folder_outlined, tr2('قالب شرطی', 'Cond. format'), _condMenu),
          _tool(Icons.find_replace_rounded, tr2('جایگزینی', 'Replace'), () => _findSheet(replace: true)),
        ];
      case 'view':
        return [
          _tool(Icons.ac_unit_rounded, tr2('ثابت‌سازی', 'Freeze'), _freezeMenu, on: s.frozenRows > 0 || s.frozenCols > 0),
          _tool(Icons.grid_on_rounded, tr2('خطوط شبکه', 'Gridlines'), () => _do((fl, sh) => fl.setSheetView(sh, showGrid: !sh.showGrid)), on: s.showGrid),
          _tool(Icons.visibility_rounded, tr2('نمایش فرمول', 'Formulas'), () => setState(() => showFormulas = !showFormulas), on: showFormulas),
          _tool(Icons.zoom_in_rounded, '${(zoom * 100).round()}%', _zoomMenu),
          _tool(Icons.swap_horiz_rounded, tr2('جهت برگه', 'Direction'), () => _do((fl, sh) => fl.setSheetView(sh, rtl: !sh.rtl)), on: s.rtl),
          _tool(Icons.straighten_rounded, tr2('عرض ستون', 'Col width'), () => _numberPrompt(tr2('عرض ستون', 'Column width'), s.colW(sel.c1), (v) => _do((fl, sh) => fl.setColWidth(sh, _selCols, v)))),
          _tool(Icons.height_rounded, tr2('ارتفاع ردیف', 'Row height'), () => _numberPrompt(tr2('ارتفاع ردیف', 'Row height'), s.rowH(sel.r1), (v) => _do((fl, sh) => fl.setRowHeight(sh, _selRows, v)))),
          _tool(Icons.fit_screen_rounded, tr2('اندازهٔ خودکار', 'AutoFit'), () {
            _autoFitCols();
            _autoFitRows();
          }),
          _tool(Icons.visibility_off_outlined, tr2('پنهان ستون', 'Hide col'), () => _do((fl, sh) => fl.setColsHidden(sh, _selCols, true))),
          _tool(Icons.visibility_off_outlined, tr2('پنهان ردیف', 'Hide row'), () => _do((fl, sh) => fl.setRowsHidden(sh, _selRows, true))),
          _tool(Icons.visibility_outlined, tr2('نمایش ستون', 'Show cols'), () => _unhide(cols: true)),
          _tool(Icons.visibility_outlined, tr2('نمایش ردیف', 'Show rows'), () => _unhide(cols: false)),
          _tool(Icons.moving_rounded, tr2('رفتن به', 'Go to'), _goto),
          _tool(Icons.tab_rounded, tr2('برگه', 'Sheet'), () => _sheetMenu(cur)),
        ];
      default:
        return [
          _tool(Icons.content_paste_rounded, tr2('چسباندن', 'Paste'), _pasteMenu),
          _tool(Icons.copy_rounded, tr2('کپی', 'Copy'), () => _copy()),
          _tool(Icons.content_cut_rounded, tr2('برش', 'Cut'), () => _copy(cut: true)),
          _tool(Icons.font_download_outlined, st.font.isEmpty ? tr2('قلم', 'Font') : st.font, _fontMenu),
          _tool(Icons.format_size_rounded, '${(st.size ?? 11).toStringAsFixed(0)} pt', _sizeDialog),
          _tool(Icons.text_increase_rounded, tr2('بزرگ‌تر', 'Larger'), () => _size(1)),
          _tool(Icons.text_decrease_rounded, tr2('کوچک‌تر', 'Smaller'), () => _size(-1)),
          _tool(Icons.format_bold_rounded, tr2('پررنگ', 'Bold'), () => _toggleBool((x0) => x0.bold, (x0, v) => x0.copyWith(bold: v)), on: st.bold),
          _tool(Icons.format_italic_rounded, tr2('کج', 'Italic'), () => _toggleBool((x0) => x0.italic, (x0, v) => x0.copyWith(italic: v)), on: st.italic),
          _tool(Icons.format_underlined_rounded, tr2('زیرخط', 'Underline'), () => _toggleBool((x0) => x0.underline, (x0, v) => x0.copyWith(underline: v)), on: st.underline),
          _tool(Icons.strikethrough_s_rounded, tr2('خط‌خورده', 'Strike'), () => _toggleBool((x0) => x0.strike, (x0, v) => x0.copyWith(strike: v)), on: st.strike),
          _tool(Icons.format_color_text_rounded, tr2('رنگ متن', 'Text colour'), _fontColor, bar: st.color == null ? Colors.black : Color(0xFF000000 | st.color!)),
          _tool(Icons.format_color_fill_rounded, tr2('رنگ پس‌زمینه', 'Fill'), _fillColor, bar: st.fill == null ? Colors.transparent : Color(0xFF000000 | st.fill!)),
          _tool(Icons.border_all_rounded, tr2('کادر', 'Borders'), _bordersMenu),
          _tool(Icons.format_align_center_rounded, tr2('تراز', 'Align'), _alignMenu),
          _tool(Icons.wrap_text_rounded, tr2('شکستن متن', 'Wrap'), _wrap, on: st.wrap),
          _tool(Icons.merge_type_rounded, tr2('ادغام', 'Merge'), _merge, on: s.mergeAt(sel.c1, sel.r1) == sel && !sel.isCell),
          _tool(Icons.pin_outlined, tr2('قالب عدد', 'Number'), _numFmt, on: st.numFmt.isNotEmpty),
          _tool(Icons.percent_rounded, tr2('درصد', 'Percent'), () => _style((x0) => x0.copyWith(numFmt: x0.numFmt == '0%' ? '' : '0%')), on: st.numFmt == '0%'),
          _tool(Icons.more_vert_rounded, '000', () => _style((x0) => x0.copyWith(numFmt: x0.numFmt == '#,##0' ? '' : '#,##0')), on: st.numFmt == '#,##0'),
          _tool(Icons.exposure_plus_1_rounded, tr2('اعشار +', 'Decimals +'), () => _decimals(1)),
          _tool(Icons.exposure_neg_1_rounded, tr2('اعشار −', 'Decimals −'), () => _decimals(-1)),
          _tool(Icons.rule_folder_outlined, tr2('قالب شرطی', 'Cond. format'), _condMenu),
          _tool(Icons.style_rounded, tr2('سبک سلول', 'Styles'), _cellStyles),
          _tool(Icons.functions_rounded, tr2('جمع خودکار', 'AutoSum'), _autoSumMenu),
          _tool(Icons.arrow_downward_rounded, tr2('پر کردن ↓', 'Fill ↓'), () => _do((fl, sh) => fl.fillRange(sh, _used(sel), down: true))),
          _tool(Icons.arrow_forward_rounded, tr2('پر کردن →', 'Fill →'), () => _do((fl, sh) => fl.fillRange(sh, _used(sel), down: false))),
          _tool(Icons.linear_scale_rounded, tr2('سری', 'Series'), () => _do((fl, sh) => fl.fillSeries(sh, _used(sel), down: sel.rows >= sel.cols))),
          _tool(Icons.cleaning_services_rounded, tr2('پاک کردن', 'Clear'), _clearMenu),
          _tool(Icons.sort_rounded, tr2('مرتب‌سازی', 'Sort'), _sortCustom),
          _tool(Icons.filter_alt_rounded, tr2('فیلتر', 'Filter'), _toggleFilter, on: s.filter != null),
          _tool(Icons.search_rounded, tr2('یافتن', 'Find'), () => _findSheet()),
        ];
    }
  }

  // ------------------------------------------------------------------ build
  @override
  Widget build(BuildContext context) {
    final f = x;
    final changed = f != null && f.z.changed;
    final vis = f == null ? <int>[] : [for (var i = 0; i < f.sheets.length; i++) if (!f.sheets[i].hidden || i == cur) i];
    return PopScope(
      canPop: !changed,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await confirm(context, tr2('تغییرات ذخیره‌نشده از بین می‌رود. خارج می‌شوید؟', 'Unsaved changes will be lost. Leave?')) && context.mounted) Navigator.pop(context);
      },
      child: Theme(
        data: officeTheme(context),
        child: Scaffold(
          backgroundColor: OfficePrefs.cell,
          bottomNavigationBar: f == null || f.sheets.isEmpty
              ? null
              : Column(mainAxisSize: MainAxisSize.min, children: [
                  _statusBar(),
                  _ribbon(),
                  OfficeSheetTabs(
                    names: [for (final i in vis) f.sheets[i].name],
                    current: vis.indexOf(cur).clamp(0, vis.length - 1).toInt(),
                    onSelect: (i) => setState(() {
                      cur = vis[i];
                      _goCell(0, 1);
                    }),
                    onList: () => officeSheetList(context, [for (final i in vis) f.sheets[i].name], vis.indexOf(cur), (i) => setState(() {
                          cur = vis[i];
                          _goCell(0, 1);
                        })),
                    onAdd: _addSheet,
                    onLong: (i) => _sheetMenu(vis[i]),
                  ),
                ]),
          body: Column(children: [
            OfficeTopBar(
              title: '${changed ? '• ' : ''}${p.basename(widget.path)}',
              actions: [
                officeAction(Icons.undo_rounded, _undo.isEmpty ? null : _undoOp, tip: tr2('واگرد', 'Undo')),
                officeAction(Icons.redo_rounded, _redo.isEmpty ? null : _redoOp, tip: tr2('ازنو', 'Redo')),
                officeAction(Icons.save_rounded, f == null || !changed ? null : () => _save(copy: false), tip: L.t('save')),
                PopupMenuButton<String>(
                  icon: const Icon(Icons.more_vert_rounded, color: Colors.white, size: 26),
                  onSelected: (v) async {
                    if (f == null) return;
                    switch (v) {
                      case 'open':
                        Native.openWith(widget.path, title: L.t('openWith'));
                      case 'copy':
                        _save(copy: true);
                      case 'new':
                        officeNewFile(context, p.dirname(widget.path), OfficeKind.xlsx);
                      case 'sheet':
                        _addSheet();
                      case 'csv':
                        _exportCsv();
                      case 'info':
                        _info();
                      case 'find':
                        _findSheet();
                    }
                  },
                  itemBuilder: (_) => [
                    PopupMenuItem(value: 'find', child: Text(tr2('یافتن و جایگزینی', 'Find & replace'))),
                    PopupMenuItem(value: 'new', child: Text(tr2('فایل اکسل جدید', 'New Excel file'))),
                    PopupMenuItem(value: 'sheet', child: Text(tr2('برگهٔ جدید', 'New sheet'))),
                    PopupMenuItem(value: 'copy', child: Text(L.t('saveCopy'))),
                    PopupMenuItem(value: 'csv', child: Text(tr2('خروجی CSV', 'Export CSV'))),
                    PopupMenuItem(value: 'info', child: Text(tr2('اطلاعات فایل', 'File info'))),
                    PopupMenuItem(value: 'open', child: Text(L.t('openWith'))),
                  ],
                ),
              ],
            ),
            if (f == null)
              const Expanded(child: Center(child: CircularProgressIndicator()))
            else if (f.sheets.isEmpty)
              Expanded(child: Center(child: Text(L.t('empty'))))
            else ...[
              OfficeFormulaBar(
                refName: sel.isCell ? ref : sel.ref,
                value: s.formulas.containsKey(ref) ? '=${s.formulas[ref]}' : (s.cells[ref] ?? ''),
                onGoto: _goto,
                onSubmit: (v) => _commit(curC, curR, v),
              ),
              Expanded(
                child: XlsxCanvas(
                  key: _canvas,
                  file: f,
                  sheet: s,
                  version: version,
                  sel: sel,
                  curC: curC,
                  curR: curR,
                  zoom: zoom,
                  showFormulas: showFormulas,
                  selectedChart: chart,
                  extraRows: extraRows,
                  extraCols: extraCols,
                  onTapCell: (c, r) => _select(XRange.cell(c, r)),
                  onSelectRange: (rg, c, r) => _select(rg, c: c, rr: r),
                  onDoubleTapCell: (c, r) {
                    _select(XRange.cell(c, r));
                    _editCell(c, r);
                  },
                  onLongPressCell: _cellMenu,
                  onLongPressHeader: _headerMenu,
                  onSelectChart: (ch) => setState(() => chart = ch),
                  onChartTapAgain: _chartMenu,
                  onFilterTap: _filterMenu,
                  onResizeCols: (cols, px) => _do((fl, sh) => fl.setColWidth(sh, cols, px)),
                  onResizeRows: (rows, px) => _do((fl, sh) => fl.setRowHeight(sh, rows, px)),
                  onHandleDrag: (rg) => setState(() => sel = rg),
                  onZoom: (z) => setState(() => zoom = z),
                  onNeedMore: (rows, cols) => setState(() {
                    if (rows) extraRows += 100;
                    if (cols) extraCols += 10;
                  }),
                ),
              ),
            ],
          ]),
        ),
      ),
    );
  }

  Widget _statusBar() {
    final t = _stats();
    if (t.isEmpty) return const SizedBox.shrink();
    return Container(
      width: double.infinity,
      color: OfficePrefs.c('head'),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: Text(t, style: TextStyle(fontSize: 12, color: OfficePrefs.c('ink')))),
    );
  }

  Widget _ribbon() {
    const tabs = [('home', 'خانه', 'Home'), ('insert', 'درج', 'Insert'), ('formulas', 'فرمول‌ها', 'Formulas'), ('data', 'داده', 'Data'), ('view', 'نما', 'View')];
    return Material(
      color: OfficePrefs.c('strip'),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        SizedBox(
          height: 38,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            for (final t in tabs)
              InkWell(
                onTap: () => setState(() => tab = t.$1),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 18),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(border: Border(bottom: BorderSide(color: tab == t.$1 ? OfficePrefs.c('green') : Colors.transparent, width: 3))),
                  child: Text(tr2(t.$2, t.$3), style: TextStyle(fontWeight: tab == t.$1 ? FontWeight.w700 : FontWeight.w500, color: tab == t.$1 ? OfficePrefs.c('green') : OfficePrefs.c('ink'))),
                ),
              ),
          ]),
        ),
        SizedBox(height: 70, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 6), children: _tools())),
      ]),
    );
  }
}
