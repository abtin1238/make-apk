import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../core/layouts.dart';
import '../services/file_ops.dart';
import '../widgets/ui.dart';

/// One planned rename. [error] is an l10n key when the new name is unusable.
class RenamePlan {
  final FItem item;
  final String newName;
  final String? error;
  const RenamePlan(this.item, this.newName, this.error);
  bool get changed => newName != item.name;
}

/// Assigns the supplied base name to every selected item, adding a stable
/// numeric suffix while preserving each file extension.
List<RenamePlan> planBatchRename(List<FItem> items, String baseName) {
  final out = <RenamePlan>[];
  for (var index = 0; index < items.length; index++) {
    final item = items[index];
    final ext = item.isDir ? '' : p.extension(item.name);
    final suffix = (index + 1).toString().padLeft(items.length.toString().length, '0');
    var name = '$baseName-$suffix$ext';
    String? error;
    try {
      name = FileOps.checkName(name);
    } on OpError catch (e) {
      error = e.key;
    }
    out.add(RenamePlan(item, name, error));
  }

  final selectedPaths = items.map((e) => e.path).toSet();
  final seen = <String>{};
  for (var i = 0; i < out.length; i++) {
    final r = out[i];
    final key = r.newName.toLowerCase();
    final target = p.join(p.dirname(r.item.path), r.newName);
    final collision = !seen.add(key) ||
        (FileOps.exists(target) && !selectedPaths.contains(target));
    if (r.error == null && collision) {
      out[i] = RenamePlan(r.item, r.newName, 'exists');
    }
  }
  return out;
}

Future<List<RenamePlan>?> askBatchRename(BuildContext c, List<FItem> items) {
  final name = TextEditingController();
  return showDialog<List<RenamePlan>>(
    context: c,
    builder: (_) => StatefulBuilder(builder: (ctx, set) {
      final plan = planBatchRename(items, name.text.trim());
      final ok = name.text.trim().isNotEmpty &&
          plan.every((r) => r.error == null) &&
          plan.any((r) => r.changed);
      return AlertDialog(
        title: Text('${L.t('batchRename')} (${items.length})'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: name,
              autofocus: true,
              onChanged: (_) => set(() {}),
              decoration: InputDecoration(
                labelText: L.t('rename'),
                hintText: tr2('نام جدید', 'New name'),
                helperText: tr2('پسوند فایل‌ها حفظ می‌شود؛ برای هر مورد شماره اضافه می‌شود', 'Extensions are preserved; each item gets a number'),
              ),
            ),
            const SizedBox(height: 8),
            Flexible(
              child: ListView(
                shrinkWrap: true,
                children: [
                  for (final r in plan)
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      title: Text(r.item.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 11, color: Colors.grey)),
                      subtitle: Text(r.newName, maxLines: 1, overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 13, color: r.error != null ? Colors.redAccent : null)),
                      trailing: r.error != null
                          ? const Icon(Icons.error_outline_rounded, color: Colors.redAccent, size: 18)
                          : null,
                    ),
                ],
              ),
            ),
          ]),
        ),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(ctx)),
          TextButton(
            onPressed: ok ? () => Navigator.pop(ctx, plan.where((r) => r.changed).toList()) : null,
            child: Text(L.t('ok')),
          ),
        ],
      );
    }),
  );
}
