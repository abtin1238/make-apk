import 'package:flutter/material.dart';

/// Colour of every known file extension, so each format gets its own recognisable icon
/// (Word blue, Excel green, PowerPoint orange, PDF red, ...).
const Map<String, int> _extColors = {
  // Word / text documents
  'doc': 0xFF2B579A, 'docx': 0xFF2B579A, 'docm': 0xFF2B579A, 'dotx': 0xFF2B579A, 'dotm': 0xFF2B579A,
  'odt': 0xFF3F7FD8, 'rtf': 0xFF4A6FA5,
  // Excel / tables
  'xls': 0xFF1E8E4E, 'xlsx': 0xFF1E8E4E, 'xlsm': 0xFF1E8E4E, 'ods': 0xFF43A047, 'csv': 0xFF2E7D32,
  // PowerPoint / slides
  'ppt': 0xFFD24726, 'pptx': 0xFFD24726, 'pptm': 0xFFD24726, 'ppsx': 0xFFD24726, 'odp': 0xFFE65100,
  // PDF, books, plain text
  'pdf': 0xFFE53935, 'epub': 0xFF8D6E63, 'cbz': 0xFF8D6E63, 'cbr': 0xFF8D6E63,
  'txt': 0xFF78909C, 'md': 0xFF546E7A, 'log': 0xFF90A4AE,
  // Web / data / code
  'json': 0xFFF9A825, 'xml': 0xFFEF6C00, 'html': 0xFFE65100, 'htm': 0xFFE65100, 'css': 0xFF1E88E5,
  'js': 0xFFF0B400, 'ts': 0xFF3178C6, 'tsx': 0xFF3178C6, 'jsx': 0xFF00B8D4, 'dart': 0xFF00B4AB,
  'py': 0xFF3776AB, 'java': 0xFFE76F00, 'kt': 0xFF7F52FF, 'kts': 0xFF7F52FF, 'c': 0xFF546E9E,
  'h': 0xFF546E9E, 'cpp': 0xFF00599C, 'hpp': 0xFF00599C, 'cs': 0xFF68217A, 'php': 0xFF777BB4,
  'go': 0xFF00ADD8, 'rs': 0xFFB7410E, 'swift': 0xFFF05138, 'rb': 0xFFCC342D, 'sql': 0xFF0097A7,
  'yaml': 0xFF607D8B, 'yml': 0xFF607D8B, 'ini': 0xFF607D8B, 'conf': 0xFF607D8B, 'sh': 0xFF37474F,
  'bat': 0xFF455A64,
  // Images
  'jpg': 0xFF43A047, 'jpeg': 0xFF43A047, 'png': 0xFF26A69A, 'gif': 0xFFEC407A, 'webp': 0xFF00ACC1,
  'svg': 0xFFFF9800, 'heic': 0xFF5C6BC0, 'heif': 0xFF5C6BC0, 'bmp': 0xFF7CB342, 'tiff': 0xFF6D8B3A,
  'ico': 0xFF8D6E63,
  // Video
  'mp4': 0xFF7E57C2, 'mkv': 0xFF5E35B1, 'avi': 0xFF3949AB, 'mov': 0xFF8E24AA, 'wmv': 0xFF1E88E5,
  'flv': 0xFFE53935, 'webm': 0xFF00897B, 'm4v': 0xFF7E57C2, '3gp': 0xFF6A1B9A, 'mpg': 0xFF5C6BC0,
  'mpeg': 0xFF5C6BC0, 'vob': 0xFF455A64, 'ogv': 0xFF00897B,
  // Audio
  'mp3': 0xFFEC407A, 'wav': 0xFF29B6F6, 'flac': 0xFF00ACC1, 'aac': 0xFFAB47BC, 'm4a': 0xFFFF7043,
  'ogg': 0xFF5C6BC0, 'opus': 0xFF7E57C2, 'wma': 0xFF3949AB, 'amr': 0xFF26A69A, 'mid': 0xFFFFB300,
  'midi': 0xFFFFB300, 'ape': 0xFF8E24AA, 'aiff': 0xFF29B6F6,
  // Android packages
  'apk': 0xFF3DDC84, 'aab': 0xFF00C853, 'xapk': 0xFF00BFA5, 'apks': 0xFF00BFA5, 'apkm': 0xFF00BFA5,
  // Archives
  'zip': 0xFFFFA000, 'rar': 0xFF8E24AA, '7z': 0xFF546E7A, 'tar': 0xFFF57C00, 'gz': 0xFFF57C00,
  'tgz': 0xFFF57C00, 'bz2': 0xFFF57C00, 'tbz': 0xFFF57C00, 'tbz2': 0xFFF57C00, 'xz': 0xFFF57C00,
  'txz': 0xFFF57C00, 'lzma': 0xFFF57C00, 'z': 0xFFF57C00, 'jar': 0xFFD84315,
};

/// Fallback colour for an extension that has no entry of its own.
Color extColor(String ext) => Color(_extColors[ext.toLowerCase()] ?? 0xFF78909C);

/// A file-type icon of its own for every extension: a sheet of paper with a folded corner, tinted with the
/// colour of the format, a glyph in the middle and the extension (PDF, DOCX, MP3, ...) on a ribbon.
class FileTypeIcon extends StatelessWidget {
  final String ext;
  final IconData glyph;
  final double size;
  final Color? tint; // user-chosen category colour, overrides the format colour
  const FileTypeIcon({super.key, required this.ext, required this.glyph, this.size = 40, this.tint});

  @override
  Widget build(BuildContext context) {
    final c = tint ?? extColor(ext);
    return SizedBox(
      width: size * .82,
      height: size,
      child: CustomPaint(painter: _FilePainter(c, glyph, ext.toUpperCase())),
    );
  }
}

class _FilePainter extends CustomPainter {
  final Color color;
  final IconData glyph;
  final String label;
  _FilePainter(this.color, this.glyph, this.label);

  @override
  void paint(Canvas canvas, Size s) {
    final w = s.width, h = s.height;
    final r = w * .14, fold = w * .30;
    final hsl = HSLColor.fromColor(color);
    final light = hsl.withLightness((hsl.lightness + .14).clamp(0.0, 1.0)).toColor();
    final dark = hsl.withLightness((hsl.lightness - .16).clamp(0.0, 1.0)).toColor();

    // soft shadow
    final sheet = Path()
      ..moveTo(r, 0)
      ..lineTo(w - fold, 0)
      ..lineTo(w, fold)
      ..lineTo(w, h - r)
      ..arcToPoint(Offset(w - r, h), radius: Radius.circular(r))
      ..lineTo(r, h)
      ..arcToPoint(Offset(0, h - r), radius: Radius.circular(r))
      ..lineTo(0, r)
      ..arcToPoint(Offset(r, 0), radius: Radius.circular(r))
      ..close();
    canvas.drawShadow(sheet.shift(Offset(0, h * .02)), Colors.black.withOpacity(.55), h * .04, false);
    canvas.drawPath(
      sheet,
      Paint()
        ..shader = LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [light, color])
            .createShader(Offset.zero & s),
    );

    // folded corner
    final foldP = Path()
      ..moveTo(w - fold, 0)
      ..lineTo(w - fold, fold - r * .3)
      ..quadraticBezierTo(w - fold, fold, w - fold + r * .3, fold)
      ..lineTo(w, fold)
      ..close();
    canvas.drawPath(foldP, Paint()..color = Colors.white.withOpacity(.38));
    canvas.drawPath(foldP, Paint()..color = dark.withOpacity(.25));

    // ribbon with the extension
    final showLabel = h >= 30 && label.isNotEmpty;
    if (showLabel) {
      final text = label.length > 5 ? label.substring(0, 5) : label;
      final bandH = h * .27, bandTop = h - bandH - h * .09;
      final band = RRect.fromLTRBR(w * .09, bandTop, w - w * .09, bandTop + bandH, Radius.circular(bandH * .35));
      canvas.drawRRect(band, Paint()..color = dark);
      var fs = bandH * .62;
      TextPainter tp;
      while (true) {
        tp = TextPainter(
          text: TextSpan(text: text, style: TextStyle(color: Colors.white, fontSize: fs, fontWeight: FontWeight.w900, letterSpacing: .2, height: 1)),
          textDirection: TextDirection.ltr,
        )..layout();
        if (tp.width <= band.width - 4 || fs < 5) break;
        fs -= .5;
      }
      tp.paint(canvas, Offset(band.left + (band.width - tp.width) / 2, band.top + (band.height - tp.height) / 2));
    }

    // glyph
    final gs = (showLabel ? h * .36 : h * .5);
    final gp = TextPainter(
      text: TextSpan(
        text: String.fromCharCode(glyph.codePoint),
        style: TextStyle(fontSize: gs, fontFamily: glyph.fontFamily, package: glyph.fontPackage, color: Colors.white.withOpacity(.95)),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    final cy = showLabel ? h * .34 : h * .55;
    gp.paint(canvas, Offset((w - gp.width) / 2 - (w * .02), cy - gp.height / 2 + h * .06));
  }

  @override
  bool shouldRepaint(_FilePainter o) => o.color != color || o.glyph != glyph || o.label != label;
}
