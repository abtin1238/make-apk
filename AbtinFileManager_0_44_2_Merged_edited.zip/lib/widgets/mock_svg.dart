import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:xml/xml.dart';

/// Minimal SVG renderer (path / rect / circle / ellipse / g / linearGradient) used to draw the icons of the
/// reference HTML mockup exactly as designed. Parsed once per string and cached.
class MockSvg extends StatelessWidget {
  final String svg;
  final double width, height;
  final Color? glow;
  final double glowBlur;
  const MockSvg(this.svg, {super.key, required this.width, required this.height, this.glow, this.glowBlur = 8});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: width,
        height: height,
        child: CustomPaint(painter: _SvgPainter(_SvgDoc.of(svg), glow, glowBlur)),
      );
}

class _Grad {
  double x1 = 0, y1 = 0, x2 = 1, y2 = 0;
  final colors = <Color>[];
  final stops = <double>[];
}

class _Shape {
  final Path path;
  final String? fill, stroke;
  final double sw, fo, so, op;
  final StrokeCap cap;
  final StrokeJoin join;
  _Shape(this.path, this.fill, this.stroke, this.sw, this.fo, this.so, this.op, this.cap, this.join);
}

Color? _color(String? v, double opacity) {
  if (v == null || v == 'none') return null;
  var h = v.trim();
  if (!h.startsWith('#')) return null;
  h = h.substring(1);
  if (h.length == 3) h = h.split('').map((c) => '$c$c').join();
  final n = int.tryParse(h, radix: 16);
  if (n == null) return null;
  return Color(0xFF000000 | n).withOpacity(opacity.clamp(0.0, 1.0).toDouble());
}

class _SvgDoc {
  static final _cache = <String, _SvgDoc>{};
  static _SvgDoc of(String s) => _cache.putIfAbsent(s, () => _SvgDoc._(s));

  late final List<double> vb;
  final grads = <String, _Grad>{};
  final shapes = <_Shape>[];
  static const _inh = ['fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'fill-opacity', 'stroke-opacity'];

  _SvgDoc._(String src) {
    final root = XmlDocument.parse(src).rootElement;
    vb = (root.getAttribute('viewBox') ?? '0 0 100 100').trim().split(RegExp(r'[ ,]+')).map(double.parse).toList();
    for (final g in root.findAllElements('linearGradient')) {
      final gr = _Grad();
      double n(String k, double d) => double.tryParse(g.getAttribute(k) ?? '') ?? d;
      gr.x1 = n('x1', 0);
      gr.y1 = n('y1', 0);
      gr.x2 = n('x2', 1);
      gr.y2 = n('y2', 0);
      for (final st in g.findElements('stop')) {
        final o = double.tryParse(st.getAttribute('offset') ?? '0') ?? 0;
        final op = double.tryParse(st.getAttribute('stop-opacity') ?? '1') ?? 1;
        gr.colors.add(_color(st.getAttribute('stop-color'), op) ?? Colors.black);
        gr.stops.add(o);
      }
      grads[g.getAttribute('id') ?? ''] = gr;
    }
    _walk(root, {});
  }

  void _walk(XmlElement e, Map<String, String> parent) {
    final a = Map<String, String>.from(parent);
    for (final k in _inh) {
      final v = e.getAttribute(k);
      if (v != null) a[k] = v;
    }
    double d(String k, double def) => double.tryParse(e.getAttribute(k) ?? '') ?? def;
    Path? p;
    switch (e.name.local) {
      case 'defs':
        return;
      case 'svg':
      case 'g':
        for (final c in e.childElements) {
          _walk(c, a);
        }
        return;
      case 'path':
        p = _parsePath(e.getAttribute('d') ?? '');
        break;
      case 'rect':
        final r = Rect.fromLTWH(d('x', 0), d('y', 0), d('width', 0), d('height', 0));
        p = Path()..addRRect(RRect.fromRectAndRadius(r, Radius.circular(d('rx', 0))));
        break;
      case 'circle':
        p = Path()..addOval(Rect.fromCircle(center: Offset(d('cx', 0), d('cy', 0)), radius: d('r', 0)));
        break;
      case 'ellipse':
        p = Path()..addOval(Rect.fromCenter(center: Offset(d('cx', 0), d('cy', 0)), width: d('rx', 0) * 2, height: d('ry', 0) * 2));
        break;
      default:
        return; // <text> etc. are not needed for the icons
    }
    shapes.add(_Shape(
      p,
      a['fill'] ?? '#000000',
      a['stroke'],
      double.tryParse(a['stroke-width'] ?? '1') ?? 1,
      double.tryParse(a['fill-opacity'] ?? '1') ?? 1,
      double.tryParse(a['stroke-opacity'] ?? '1') ?? 1,
      d('opacity', 1),
      a['stroke-linecap'] == 'round' ? StrokeCap.round : StrokeCap.butt,
      a['stroke-linejoin'] == 'round' ? StrokeJoin.round : StrokeJoin.miter,
    ));
  }
}

// ---------------------------------------------------------------- path data

class _Sc {
  final String s;
  int pos = 0;
  _Sc(this.s);
  static final _numRe = RegExp(r'[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?');
  void ws() {
    while (pos < s.length && (s[pos] == ' ' || s[pos] == ',' || s[pos] == '\n' || s[pos] == '\t' || s[pos] == '\r')) {
      pos++;
    }
  }

  bool get eof => pos >= s.length;
  double num() {
    ws();
    final m = _numRe.matchAsPrefix(s, pos);
    if (m == null) throw const FormatException('bad svg path');
    pos = m.end;
    return double.parse(m.group(0)!);
  }

  // arc flags may be packed ("011-5"): read exactly one character
  bool flag() {
    ws();
    final c = s[pos++];
    return c == '1';
  }
}

Path _parsePath(String d) {
  final p = Path();
  final s = _Sc(d);
  double cx = 0, cy = 0, sx = 0, sy = 0, lx = 0, ly = 0;
  String? cmd;
  String prev = '';
  final letter = RegExp(r'[A-Za-z]');
  while (true) {
    s.ws();
    if (s.eof) break;
    if (letter.hasMatch(s.s[s.pos])) {
      cmd = s.s[s.pos++];
      if (cmd == 'Z' || cmd == 'z') {
        p.close();
        cx = sx;
        cy = sy;
        prev = 'Z';
        continue;
      }
    } else if (cmd == null) {
      break;
    }
    final cm = cmd!;
    final rel = cm == cm.toLowerCase();
    final ox = rel ? cx : 0.0, oy = rel ? cy : 0.0;
    switch (cm.toUpperCase()) {
      case 'M':
        cx = ox + s.num();
        cy = oy + s.num();
        sx = cx;
        sy = cy;
        p.moveTo(cx, cy);
        cmd = rel ? 'l' : 'L';
        prev = 'M';
        break;
      case 'L':
        cx = ox + s.num();
        cy = oy + s.num();
        p.lineTo(cx, cy);
        prev = 'L';
        break;
      case 'H':
        cx = ox + s.num();
        p.lineTo(cx, cy);
        prev = 'L';
        break;
      case 'V':
        cy = oy + s.num();
        p.lineTo(cx, cy);
        prev = 'L';
        break;
      case 'C': {
        final x1 = ox + s.num(), y1 = oy + s.num(), x2 = ox + s.num(), y2 = oy + s.num(), x = ox + s.num(), y = oy + s.num();
        p.cubicTo(x1, y1, x2, y2, x, y);
        lx = x2;
        ly = y2;
        cx = x;
        cy = y;
        prev = 'C';
        break;
      }
      case 'S': {
        final x1 = (prev == 'C' || prev == 'S') ? 2 * cx - lx : cx;
        final y1 = (prev == 'C' || prev == 'S') ? 2 * cy - ly : cy;
        final x2 = ox + s.num(), y2 = oy + s.num(), x = ox + s.num(), y = oy + s.num();
        p.cubicTo(x1, y1, x2, y2, x, y);
        lx = x2;
        ly = y2;
        cx = x;
        cy = y;
        prev = 'S';
        break;
      }
      case 'Q': {
        final x1 = ox + s.num(), y1 = oy + s.num(), x = ox + s.num(), y = oy + s.num();
        p.quadraticBezierTo(x1, y1, x, y);
        cx = x;
        cy = y;
        prev = 'Q';
        break;
      }
      case 'A': {
        final rx = s.num().abs(), ry = s.num().abs(), rot = s.num();
        final large = s.flag(), sweep = s.flag();
        final x = ox + s.num(), y = oy + s.num();
        if (rx == 0 || ry == 0) {
          p.lineTo(x, y);
        } else {
          p.arcToPoint(Offset(x, y), radius: Radius.elliptical(rx, ry), rotation: rot, largeArc: large, clockwise: sweep);
        }
        cx = x;
        cy = y;
        prev = 'A';
        break;
      }
      default:
        return p;
    }
  }
  return p;
}

// ---------------------------------------------------------------- painter

class _SvgPainter extends CustomPainter {
  final _SvgDoc doc;
  final Color? glow;
  final double glowBlur;
  _SvgPainter(this.doc, this.glow, this.glowBlur);

  Paint? _fill(_Shape sh) {
    final f = sh.fill;
    if (f == null || f == 'none') return null;
    if (f.startsWith('url(#')) {
      final g = doc.grads[f.substring(5, f.length - 1)];
      if (g == null || g.colors.length < 2) return null;
      final b = sh.path.getBounds();
      return Paint()
        ..shader = LinearGradient(
          begin: Alignment(g.x1 * 2 - 1, g.y1 * 2 - 1),
          end: Alignment(g.x2 * 2 - 1, g.y2 * 2 - 1),
          colors: [for (final c in g.colors) c.withOpacity(c.opacity * sh.fo * sh.op)],
          stops: g.stops,
        ).createShader(b);
    }
    final c = _color(f, sh.fo * sh.op);
    return c == null ? null : (Paint()..color = c);
  }

  @override
  void paint(Canvas c, Size s) {
    final vb = doc.vb;
    final sc = math.min(s.width / vb[2], s.height / vb[3]);
    c.save();
    c.translate((s.width - vb[2] * sc) / 2, (s.height - vb[3] * sc) / 2);
    c.scale(sc);
    c.translate(-vb[0], -vb[1]);
    if (glow != null) {
      final gp = Paint()
        ..color = glow!
        ..maskFilter = MaskFilter.blur(BlurStyle.normal, glowBlur / sc);
      for (final sh in doc.shapes) {
        if (sh.fill != null && sh.fill != 'none') c.drawPath(sh.path, gp);
      }
    }
    for (final sh in doc.shapes) {
      final f = _fill(sh);
      if (f != null) c.drawPath(sh.path, f);
      final sc2 = _color(sh.stroke, sh.so * sh.op);
      if (sc2 != null) {
        c.drawPath(
            sh.path,
            Paint()
              ..style = PaintingStyle.stroke
              ..color = sc2
              ..strokeWidth = sh.sw
              ..strokeCap = sh.cap
              ..strokeJoin = sh.join);
      }
    }
    c.restore();
  }

  @override
  bool shouldRepaint(covariant _SvgPainter o) => o.doc != doc || o.glow != glow || o.glowBlur != glowBlur;
}
