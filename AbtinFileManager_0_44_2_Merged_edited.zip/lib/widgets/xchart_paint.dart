import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../services/xlsx_model.dart';
import '../services/xlsx_format.dart';
import '../services/office_service.dart' show xChartColors;

/// Draws [ch] (column / bar / line / area / pie / doughnut) into [rect].
void paintXChart(Canvas canvas, Rect rect, XChart ch, {required Color bg, required Color ink, required Color line, bool selected = false}) {
  final rr = RRect.fromRectAndRadius(rect, const Radius.circular(6));
  canvas.drawRRect(rr, Paint()..color = bg);
  canvas.drawRRect(rr, Paint()
    ..color = selected ? const Color(0xFF2D7DF0) : line
    ..style = PaintingStyle.stroke
    ..strokeWidth = selected ? 2.5 : 1);
  canvas.save();
  canvas.clipRRect(rr);
  final pad = math.min(rect.width, rect.height) * 0.04 + 6;
  var area = rect.deflate(pad);
  final fs = (math.min(rect.width, rect.height) / 24).clamp(8.0, 14.0).toDouble();

  void text(String s, Offset at, {double? size, Color? color, TextAlign align = TextAlign.left, double? maxW, FontWeight? weight}) {
    final tp = TextPainter(
      text: TextSpan(text: s, style: TextStyle(fontSize: size ?? fs, color: color ?? ink, fontWeight: weight)),
      textDirection: TextDirection.ltr,
      textAlign: align,
      maxLines: 1,
      ellipsis: '…',
    )..layout(maxWidth: maxW ?? 400);
    var dx = at.dx;
    if (align == TextAlign.center) dx -= tp.width / 2;
    if (align == TextAlign.right) dx -= tp.width;
    tp.paint(canvas, Offset(dx, at.dy));
  }

  if (ch.title.isNotEmpty) {
    text(ch.title, Offset(area.center.dx, area.top), size: fs * 1.25, align: TextAlign.center, weight: FontWeight.w700, maxW: area.width);
    area = Rect.fromLTRB(area.left, area.top + fs * 1.25 + 8, area.right, area.bottom);
  }
  final series = ch.series.where((s) => s.vals.isNotEmpty).toList();
  if (series.isEmpty || area.width < 30 || area.height < 30) {
    canvas.restore();
    return;
  }
  final pie = ch.type == 'pie' || ch.type == 'doughnut';
  Color col(int i) => Color(0xFF000000 | xChartColors[i % xChartColors.length]);

  // ---- legend (bottom)
  final legendItems = pie ? (series.first.cats.isNotEmpty ? series.first.cats : [for (var i = 0; i < series.first.vals.length; i++) '${i + 1}']) : [for (final s in series) s.name];
  if (legendItems.length > 1 || !pie) {
    var x = area.left;
    var y = area.bottom - fs - 2;
    for (var i = 0; i < legendItems.length && i < 24; i++) {
      final label = legendItems[i];
      final w = label.length * fs * 0.55 + fs * 2;
      if (x + w > area.right) {
        x = area.left;
        y -= fs + 6;
        if (y < area.top + area.height * 0.5) break;
      }
      canvas.drawRect(Rect.fromLTWH(x, y + 2, fs * 0.8, fs * 0.8), Paint()..color = col(i));
      text(label, Offset(x + fs, y), maxW: w, size: fs * 0.9);
      x += w;
    }
    area = Rect.fromLTRB(area.left, area.top, area.right, y - 6);
  }
  if (area.height < 20) {
    canvas.restore();
    return;
  }

  if (pie) {
    final vals = series.first.vals.map((v) => v < 0 ? 0.0 : v).toList();
    final total = vals.fold<double>(0, (a, b) => a + b);
    final r = math.min(area.width, area.height) / 2 - 4;
    final c = area.center;
    var start = -math.pi / 2;
    for (var i = 0; i < vals.length; i++) {
      final sweep = total == 0 ? 0.0 : vals[i] / total * math.pi * 2;
      canvas.drawArc(Rect.fromCircle(center: c, radius: r), start, sweep, true, Paint()..color = col(i));
      if (sweep > 0.25) {
        final mid = start + sweep / 2;
        text('${(vals[i] / total * 100).round()}%', Offset(c.dx + math.cos(mid) * r * 0.65, c.dy + math.sin(mid) * r * 0.65 - fs / 2), align: TextAlign.center, color: Colors.white, size: fs * 0.9);
      }
      start += sweep;
    }
    if (ch.type == 'doughnut') canvas.drawCircle(c, r * 0.5, Paint()..color = bg);
    canvas.restore();
    return;
  }

  // ---- axes
  final horizontal = ch.type == 'bar';
  var lo = 0.0, hi = 0.0;
  for (final s in series) {
    for (final v in s.vals) {
      lo = math.min(lo, v);
      hi = math.max(hi, v);
    }
  }
  if (hi == lo) hi = lo + 1;
  final span = hi - lo;
  final rough = span / 4;
  final mag = math.pow(10, (math.log(rough) / math.ln10).floor()).toDouble();
  final norm = rough / mag;
  final step = (norm <= 1 ? 1 : norm <= 2 ? 2 : norm <= 5 ? 5 : 10) * mag;
  final top = (hi / step).ceil() * step, bottom = (lo / step).floor() * step;
  final nCat = series.map((s) => s.vals.length).reduce(math.max);
  final cats = series.first.cats.length >= nCat ? series.first.cats : [for (var i = 0; i < nCat; i++) i < series.first.cats.length ? series.first.cats[i] : '${i + 1}'];
  final labelW = math.max(XNumFmt.general(top).length, XNumFmt.general(bottom).length) * fs * 0.6 + 6;
  final plot = horizontal
      ? Rect.fromLTRB(area.left + 60.clamp(20, area.width * 0.3).toDouble(), area.top + 4, area.right - 8, area.bottom - fs - 6)
      : Rect.fromLTRB(area.left + labelW, area.top + 4, area.right - 8, area.bottom - fs - 6);
  if (plot.width < 20 || plot.height < 20) {
    canvas.restore();
    return;
  }
  final grid = Paint()
    ..color = line
    ..strokeWidth = 1;
  for (var v = bottom; v <= top + step / 2; v += step) {
    final t = (v - bottom) / (top - bottom);
    if (horizontal) {
      final x = plot.left + t * plot.width;
      canvas.drawLine(Offset(x, plot.top), Offset(x, plot.bottom), grid);
      text(XNumFmt.general(double.parse(v.toStringAsPrecision(6))), Offset(x, plot.bottom + 2), align: TextAlign.center, size: fs * 0.85);
    } else {
      final y = plot.bottom - t * plot.height;
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), grid);
      text(XNumFmt.general(double.parse(v.toStringAsPrecision(6))), Offset(plot.left - 4, y - fs / 2), align: TextAlign.right, size: fs * 0.85, maxW: labelW);
    }
  }
  double pos(double v) => (v - bottom) / (top - bottom);
  final slot = (horizontal ? plot.height : plot.width) / nCat;
  final skip = math.max(1, (fs * 5 / math.max(slot, 1)).ceil());
  for (var i = 0; i < nCat; i += skip) {
    final label = i < cats.length ? cats[i] : '';
    if (horizontal) {
      text(label, Offset(plot.left - 4, plot.top + slot * (nCat - 1 - i) + slot / 2 - fs / 2), align: TextAlign.right, size: fs * 0.85, maxW: plot.left - area.left);
    } else {
      text(label, Offset(plot.left + slot * i + slot / 2, plot.bottom + 3), align: TextAlign.center, size: fs * 0.85, maxW: slot * skip);
    }
  }
  final base = Paint()
    ..color = ink.withAlpha(120)
    ..strokeWidth = 1.2;
  if (horizontal) {
    canvas.drawLine(Offset(plot.left + pos(0) * plot.width, plot.top), Offset(plot.left + pos(0) * plot.width, plot.bottom), base);
  } else {
    canvas.drawLine(Offset(plot.left, plot.bottom - pos(0) * plot.height), Offset(plot.right, plot.bottom - pos(0) * plot.height), base);
  }

  if (ch.type == 'col' || ch.type == 'bar') {
    final group = slot * 0.7 / series.length;
    for (var s = 0; s < series.length; s++) {
      for (var i = 0; i < series[s].vals.length; i++) {
        final v = series[s].vals[i];
        final a = pos(math.min(v, 0)), b = pos(math.max(v, 0));
        final off = slot * 0.15 + group * s;
        final r = horizontal
            ? Rect.fromLTRB(plot.left + a * plot.width, plot.top + slot * (nCat - 1 - i) + off, plot.left + b * plot.width, plot.top + slot * (nCat - 1 - i) + off + group)
            : Rect.fromLTRB(plot.left + slot * i + off, plot.bottom - b * plot.height, plot.left + slot * i + off + group, plot.bottom - a * plot.height);
        canvas.drawRect(r, Paint()..color = col(s));
      }
    }
  } else {
    for (var s = 0; s < series.length; s++) {
      final pts = [for (var i = 0; i < series[s].vals.length; i++) Offset(plot.left + slot * i + slot / 2, plot.bottom - pos(series[s].vals[i]) * plot.height)];
      if (pts.isEmpty) continue;
      if (ch.type == 'area') {
        final path = Path()..moveTo(pts.first.dx, plot.bottom - pos(0) * plot.height);
        for (final p in pts) {
          path.lineTo(p.dx, p.dy);
        }
        path.lineTo(pts.last.dx, plot.bottom - pos(0) * plot.height);
        path.close();
        canvas.drawPath(path, Paint()..color = col(s).withAlpha(140));
      }
      final path = Path()..moveTo(pts.first.dx, pts.first.dy);
      for (final p in pts.skip(1)) {
        path.lineTo(p.dx, p.dy);
      }
      canvas.drawPath(
          path,
          Paint()
            ..color = col(s)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2.2);
      if (ch.type == 'line') {
        for (final p in pts) {
          canvas.drawCircle(p, 3.2, Paint()..color = col(s));
        }
      }
    }
  }
  canvas.restore();
}
