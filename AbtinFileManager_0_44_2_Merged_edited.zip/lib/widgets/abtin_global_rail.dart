import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/settings.dart';

/// Bridge from the app-wide visual rail to the root Shell's tab and page routes.
class AbtinGlobalNavigation {
  static ValueChanged<String>? onNavigate;
  static final ValueNotifier<String> active = ValueNotifier<String>('home');
  static final ValueNotifier<bool> shellVisible = ValueNotifier<bool>(false);

  static void navigate(String destination) {
    active.value = destination;
    onNavigate?.call(destination);
  }
}

/// Hides the persistent rail while a dialog or bottom sheet is on top.
class AbtinRailRouteObserver extends NavigatorObserver {
  static final ValueNotifier<bool> hasPopup = ValueNotifier<bool>(false);
  final Set<Route<dynamic>> _popups = <Route<dynamic>>{};

  void _refresh() => hasPopup.value = _popups.isNotEmpty;

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPush(route, previousRoute);
    if (route is PopupRoute<dynamic>) {
      _popups.add(route);
      _refresh();
    }
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPop(route, previousRoute);
    _popups.remove(route);
    _refresh();
  }

  @override
  void didRemove(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didRemove(route, previousRoute);
    _popups.remove(route);
    _refresh();
  }

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) {
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
    if (oldRoute != null) _popups.remove(oldRoute);
    if (newRoute is PopupRoute<dynamic>) _popups.add(newRoute);
    _refresh();
  }
}

final AbtinRailRouteObserver abtinRailRouteObserver = AbtinRailRouteObserver();

/// A floating, always-available shortcut rail for the Abtin reference look.
class AbtinGlobalRail extends StatelessWidget {
  const AbtinGlobalRail({super.key});

  static const _items = <(String, IconData, String, String)>[
    ('home', Icons.home_rounded, 'خانه', 'Home'),
    ('favorites', Icons.star_rounded, 'علاقه‌مندی‌ها', 'Favorites'),
    ('recents', Icons.schedule_rounded, 'اخیر', 'Recent files'),
    ('trash', Icons.delete_outline_rounded, 'سطل زباله', 'Trash'),
    ('settings', Icons.settings_rounded, 'تنظیمات', 'Settings'),
  ];

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
        valueListenable: AbtinGlobalNavigation.active,
        builder: (context, active, _) => Container(
          width: 52,
          padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 3),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(27),
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF1A1D82), Color(0xFF10125E)],
            ),
            border: Border.all(color: const Color(0x665B78FF), width: 1.1),
            boxShadow: const [
              BoxShadow(color: Color(0x553C4BFF), blurRadius: 16),
              BoxShadow(
                color: Color(0x332E3AFF),
                blurRadius: 14,
                spreadRadius: -4,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (final item in _items) ...[
                if (item != _items.first) const SizedBox(height: 5),
                _RailButton(
                  icon: item.$2,
                  label: item.$3,
                  tooltip: item.$4,
                  selected: active == item.$1,
                  onTap: () => AbtinGlobalNavigation.navigate(item.$1),
                ),
              ],
            ],
          ),
        ),
      );
}

class _RailButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final String tooltip;
  final bool selected;
  final VoidCallback onTap;

  const _RailButton({
    required this.icon,
    required this.label,
    required this.tooltip,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Tooltip(
        message: tooltip,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Material(
            color: selected ? const Color(0xFF1C3FD8) : const Color(0xFF1C1F8E),
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: onTap,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: selected
                      ? Border.all(color: const Color(0xFF3DA3FF), width: 1.5)
                      : null,
                  boxShadow: selected
                      ? const [BoxShadow(color: Color(0xAA2D7BFF), blurRadius: 12)]
                      : null,
                ),
                child: Icon(icon,
                    size: 25,
                    color: selected
                        ? const Color(0xFF33D6FF)
                        : const Color(0xFFE5E8FF)),
              ),
            ),
          ),
        ),
      );
}

/// Places the reference rail above the root Navigator so it remains reachable
/// on pushed screens, while allowing dialogs to cover it normally.
class AbtinAppChrome extends StatelessWidget {
  final Widget child;
  const AbtinAppChrome({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final look = context.select<AppSettings, String>((s) => s.look);
    return ValueListenableBuilder<bool>(
      valueListenable: AbtinGlobalNavigation.shellVisible,
      builder: (context, shellVisible, _) {
        if (!shellVisible || look != 'abtin') return child;
        return ValueListenableBuilder<bool>(
          valueListenable: AbtinRailRouteObserver.hasPopup,
          builder: (context, hasPopup, _) {
            if (hasPopup) return child;
            return Stack(
              fit: StackFit.expand,
              children: [
                child,
                Positioned(
                  top: 104 + MediaQuery.paddingOf(context).top,
                  right: 8,
                  child: const AbtinGlobalRail(),
                ),
              ],
            );
          },
        );
      },
    );
  }
}
