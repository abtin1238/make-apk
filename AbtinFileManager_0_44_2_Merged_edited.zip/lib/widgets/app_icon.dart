import 'package:flutter/material.dart' hide Icon;
import 'package:flutter/material.dart' as m show Icon;
import '../core/color_spec.dart';
import '../core/icon_prefs.dart';

/// Rebuilds everything that depends on the user's visual style (icon colours, look, ...) when it changes.
/// Const widgets are not rebuilt by a normal parent rebuild, so style-aware widgets depend on this scope.
class AppStyleScope extends InheritedWidget {
  final int ver;
  const AppStyleScope({super.key, required this.ver, required super.child});

  /// Registers a dependency (does nothing outside of a scope, e.g. in widget tests).
  static void watch(BuildContext c) => c.dependOnInheritedWidgetOfExactType<AppStyleScope>();

  @override
  bool updateShouldNotify(AppStyleScope old) => ver != old.ver;
}

bool _sameRgb(Color a, Color b) => (a.value & 0xFFFFFF) == (b.value & 0xFFFFFF);

/// True when [amb] is one of the "neutral" icon colours of the theme (plain icons on a surface).
/// Icons on filled buttons (pure white / black), on photos or on the players keep their colour.
bool _neutral(BuildContext c, Color? amb) {
  if (amb == null) return true;
  final cs = Theme.of(c).colorScheme;
  return _sameRgb(amb, cs.onSurface) ||
      _sameRgb(amb, cs.onSurfaceVariant) ||
      _sameRgb(amb, cs.onSecondaryContainer) ||
      _sameRgb(amb, cs.primary) ||
      _sameRgb(amb, cs.secondary) ||
      _sameRgb(amb, cs.outline);
}

/// Drop-in replacement for Flutter's [Icon] (screens import material with `hide Icon` and this file instead).
///
/// Colour rules, in order:
///  1. the user's colour for this exact icon (Settings -> icon style -> all icons), solid or gradient;
///  2. an explicit `color:` given in code is kept as it is;
///  3. otherwise the app-wide icon style when it is switched on and the icon sits on a normal surface
///     (not on a filled button, photo or player). Theme-gradient icons use a dark foreground in light mode.
class Icon extends StatelessWidget {
  final IconData? icon;
  final double? size;
  final Color? color;
  final String? semanticLabel;
  final TextDirection? textDirection;
  final List<Shadow>? shadows;
  const Icon(this.icon, {super.key, this.size, this.color, this.semanticLabel, this.textDirection, this.shadows});

  Widget _plain(Color? c) => m.Icon(icon, size: size, color: c, semanticLabel: semanticLabel, textDirection: textDirection, shadows: shadows);

  @override
  Widget build(BuildContext context) {
    AppStyleScope.watch(context);
    final d = icon;
    if (d == null) return _plain(color);
    ColorSpec? spec = IconPrefs.overrides[IconPrefs.idOf(d)];
    var alpha = 1.0;
    if (spec == null && color == null && IconPrefs.mode != 0) {
      final amb = IconTheme.of(context).color;
      if (_neutral(context, amb)) {
        final cs = Theme.of(context).colorScheme;
        spec = IconPrefs.mode == 1
            ? (Theme.of(context).brightness == Brightness.light
                ? ColorSpec.solid(cs.onSurface.value)
                : ColorSpec(cs.primary.value, cs.secondary.value))
            : IconPrefs.custom;
        if (amb != null && amb.alpha < 255) alpha = amb.alpha / 255; // disabled buttons stay dimmed
      }
    }
    if (spec == null) return _plain(color);
    final Widget w = paintWithSpec(spec, _plain(spec.isGradient ? Colors.white : spec.color1));
    return alpha < 1 ? Opacity(opacity: alpha, child: w) : w;
  }
}

/// A file-type / folder icon (key: folder, images, videos, ...) drawn with the user's shape and colour (solid or gradient).
class KeyIcon extends StatelessWidget {
  final String keyName;
  final double? size;
  const KeyIcon(this.keyName, {super.key, this.size});

  @override
  Widget build(BuildContext context) {
    AppStyleScope.watch(context);
    final d = IconPrefs.icon(keyName);
    final s = IconPrefs.overrides[IconPrefs.idOf(d)] ?? IconPrefs.spec(keyName);
    return paintWithSpec(s, m.Icon(d, size: size, color: s.isGradient ? Colors.white : s.color1));
  }
}

/// Icon of the icon sheet drawn with [spec] (used by the settings previews).
class SpecIcon extends StatelessWidget {
  final IconData icon;
  final ColorSpec spec;
  final double size;
  const SpecIcon(this.icon, this.spec, {super.key, this.size = 28});

  @override
  Widget build(BuildContext context) => paintWithSpec(spec, m.Icon(icon, size: size, color: spec.isGradient ? Colors.white : spec.color1));
}
