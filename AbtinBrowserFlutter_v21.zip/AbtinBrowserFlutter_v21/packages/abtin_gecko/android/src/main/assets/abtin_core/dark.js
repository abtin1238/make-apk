'use strict';
// Abtin Core - smart dark mode. Runs in EVERY frame at document_start (content.js is top-frame only).
//  - applies before the first paint (no white flash), then darkens light surfaces only;
//  - time-sliced scanning (no long main-thread stalls), open + closed shadow roots, iframes;
//  - coloured dark text (links) is lightened, not replaced by grey; gradients and url() backgrounds are kept apart;
//  - small logos with a white background / black-on-transparent get inverted (background page measures the pixels);
//  - per-site override (on/off) comes from the app (cfg.sites), see AppState.toggleDarkSite.
//  v20 fixes (sites that already have a dark theme, e.g. web.bale.ai, ended up with dark text on dark / pale text on white):
//  - colour parser understands color(srgb ..), oklch/oklab/lab/lch/hwb/hsl and space syntax (computed color-mix() values are
//    serialised as color(srgb ..) by Gecko; the old rgb()-only parser saw them as "no colour" and left them untouched);
//  - text colour is decided against the surface that is really behind it (after our own changes), so dark text is never
//    forced light on a light yellow badge and light text on a surface we could not darken becomes dark;
//  - "site is already dark" is re-measured (sampled pixels' surfaces + color-scheme), after load, and on every theme
//    attribute change; the page switches between skipped <-> darkened without a reload;
//  - changes that arrive within 400 ms are re-scanned afterwards instead of being dropped; transitionend re-tags the element.
(function () {
  if (window.__abtinDark) return;
  window.__abtinDark = true;
  var isTop = window.top === window;
  var host = (location.hostname || '').toLowerCase().replace(/^www\./, '');
  var cfg = { forceDark: false, sites: {} };
  var on = false, skip = false;
  var mo = null, moRoot = null, trHooked = false, shadowMo = [], hooked = new WeakSet(), selfEdit = new WeakSet(), ownStyles = [];
  var work = [], wi = 0, pumping = false, pendingRoots = new Set(), pendingEls = new Set(), lateRoots = new Set();
  var flushTimer = 0, lateTimer = 0, judgeTimer = 0, judgeCount = 0, lastJudge = 0;
  var surfCache = new WeakMap();
  var T_SKIP = /^(script|style|link|meta|head|title|noscript|br|template|base|source|track|param|area|defs)$/;
  var T_MEDIA = /^(video|audio|canvas|iframe|object|embed|picture|svg|math|frame|frameset)$/;
  var SVGNS = 'http://www.w3.org/2000/svg';
  var TAGS = ['bg', 'grad', 'fg', 'border', 'img'];

  var BG = '#24262b', FG = '#e6e8ed', BD = '#50545d', FGD = '#16181d';
  function rules(p) {
    return [
      p + '[data-abtin-dark-bg="1"]{background-color:' + BG + '!important}',
      p + '[data-abtin-dark-grad="1"]{background-image:none!important;background-color:' + BG + '!important}',
      p + '[data-abtin-dark-fg="1"]{color:' + FG + '!important}',
      p + '[data-abtin-dark-fg="2"]{color:var(--abtin-c)!important}',
      p + '[data-abtin-dark-fg="3"]{color:' + FGD + '!important}',
      p + '[data-abtin-dark-border="1"]{border-color:' + BD + '!important;outline-color:' + BD + '!important}',
      p + '[data-abtin-dark-img="1"]{filter:invert(.9) hue-rotate(180deg)!important}',
      p + 'input,' + p + 'textarea,' + p + 'select{color-scheme:dark}'
    ].join('');
  }
  var DOC_CSS = [
    'html.__abtin_dark:not(.__abtin_dark_sub){background:#202226!important}',
    'html.__abtin_dark{color-scheme:dark!important}',
    // before the first scan the body is already dark: no white flash while the page loads
    'html.__abtin_dark.__abtin_dark_pending:not(.__abtin_dark_sub) body{background-color:' + BG + '!important;color:' + FG + '!important}',
    rules('html.__abtin_dark ')
  ].join('');
  var SHADOW_CSS = rules('');

  // ---------------------------------------------------------------- colour helpers
  function c01(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
  function toS(v) { v = c01(v); return v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055; }
  function mk(r, g, b, a) { // r,g,b: sRGB 0..1
    r = c01(r); g = c01(g); b = c01(b);
    return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255), a: a, l: 0.2126 * r + 0.7152 * g + 0.0722 * b, sat: Math.max(r, g, b) - Math.min(r, g, b) };
  }
  function hsl2rgb(h, s, l) {
    h = ((h % 360) + 360) % 360 / 360;
    function f(n) { var k = (n + h * 12) % 12, a = s * Math.min(l, 1 - l); return l - a * Math.max(-1, Math.min(k - 3, Math.min(9 - k, 1))); }
    return [f(0), f(8), f(4)];
  }
  function linRgb(r, g, b, a) { return mk(toS(r), toS(g), toS(b), a); }
  function xyzD65(X, Y, Z, a) { return linRgb(3.2404542 * X - 1.5371385 * Y - 0.4985314 * Z, -0.969266 * X + 1.8760108 * Y + 0.041556 * Z, 0.0556434 * X - 0.2040259 * Y + 1.0572252 * Z, a); }
  function xyzD50(X, Y, Z, a) { return linRgb(3.1338561 * X - 1.6168667 * Y - 0.4906146 * Z, -0.9787684 * X + 1.9161415 * Y + 0.033454 * Z, 0.0719453 * X - 0.2289914 * Y + 1.4052427 * Z, a); }
  function oklab(L, A, B, a) {
    var l_ = L + 0.3963377774 * A + 0.2158037573 * B, m_ = L - 0.1055613458 * A - 0.0638541728 * B, s_ = L - 0.0894841775 * A - 1.291485548 * B;
    var l = l_ * l_ * l_, m = m_ * m_ * m_, s = s_ * s_ * s_;
    return linRgb(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s, -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s, -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s, a);
  }
  function lab(L, A, B, a) { // CIE Lab, D50
    var fy = (L + 16) / 116, fx = fy + A / 500, fz = fy - B / 200, e = 216 / 24389, k = 24389 / 27;
    var xr = fx * fx * fx > e ? fx * fx * fx : (116 * fx - 16) / k;
    var yr = L > 8 ? fy * fy * fy : L / k;
    var zr = fz * fz * fz > e ? fz * fz * fz : (116 * fz - 16) / k;
    return xyzD50(xr * 0.96422, yr, zr * 0.82521, a);
  }
  // Any CSS colour string from getComputedStyle -> {r,g,b (0..255), l, sat, a}; null when transparent (alpha < minA).
  function parseColor(str, minA) {
    if (!str || str === 'transparent') return null;
    var m = /^\s*([a-z-]+)\(([^)]*)\)/i.exec(str);
    if (!m) return null;
    var fn = m[1].toLowerCase(), t = m[2].replace('/', ' ').trim().split(/[\s,]+/), space = '';
    if (fn === 'color') space = (t.shift() || '').toLowerCase();
    function num(s, pct) {
      if (s === undefined || s === 'none') return 0;
      var v = parseFloat(s); if (isNaN(v)) return 0;
      if (/%$/.test(s)) return v / 100 * pct;
      if (/turn$/.test(s)) return v * 360;
      if (/rad$/.test(s)) return v * 180 / Math.PI;
      if (/grad$/.test(s)) return v * 0.9;
      return v;
    }
    var a = t.length > 3 ? num(t[3], 1) : 1;
    if (a < (minA === undefined ? 0.08 : minA)) return null;
    var p, h;
    switch (fn) {
      case 'rgb': case 'rgba': return mk(num(t[0], 255) / 255, num(t[1], 255) / 255, num(t[2], 255) / 255, a);
      case 'hsl': case 'hsla':
        p = hsl2rgb(num(t[0], 360), /%$/.test(t[1]) ? num(t[1], 1) : num(t[1], 1) / 100, /%$/.test(t[2]) ? num(t[2], 1) : num(t[2], 1) / 100);
        return mk(p[0], p[1], p[2], a);
      case 'hwb': {
        var w = /%$/.test(t[1]) ? num(t[1], 1) : num(t[1], 1) / 100, bl = /%$/.test(t[2]) ? num(t[2], 1) : num(t[2], 1) / 100;
        if (w + bl >= 1) { var g = w / (w + bl); return mk(g, g, g, a); }
        p = hsl2rgb(num(t[0], 360), 1, 0.5);
        return mk(p[0] * (1 - w - bl) + w, p[1] * (1 - w - bl) + w, p[2] * (1 - w - bl) + w, a);
      }
      case 'oklab': return oklab(num(t[0], 1), num(t[1], 0.4), num(t[2], 0.4), a);
      case 'oklch': h = num(t[2], 360) * Math.PI / 180; return oklab(num(t[0], 1), num(t[1], 0.4) * Math.cos(h), num(t[1], 0.4) * Math.sin(h), a);
      case 'lab': return lab(num(t[0], 100), num(t[1], 125), num(t[2], 125), a);
      case 'lch': h = num(t[2], 360) * Math.PI / 180; return lab(num(t[0], 100), num(t[1], 150) * Math.cos(h), num(t[1], 150) * Math.sin(h), a);
      case 'color': {
        var x = num(t[0], 1), y = num(t[1], 1), z = num(t[2], 1);
        if (space === 'srgb-linear') return linRgb(x, y, z, a);
        if (space === 'xyz' || space === 'xyz-d65') return xyzD65(x, y, z, a);
        if (space === 'xyz-d50') return xyzD50(x, y, z, a);
        return mk(x, y, z, a); // srgb; display-p3 / rec2020 / a98 / prophoto approximated as sRGB (only used to judge light vs dark)
      }
    }
    return null;
  }
  function rgb(c) { return parseColor(c, 0.08); }
  function lighten(c) { // keep the hue (links stay blue, errors stay red), raise the lightness
    var r = c.r / 255, g = c.g / 255, b = c.b / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), h = 0, s = 0, l = (mx + mn) / 2, d = mx - mn;
    if (d > 0) {
      s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      if (mx === r) h = ((g - b) / d + (g < b ? 6 : 0)); else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
      h *= 60;
    }
    l = Math.max(l, 0.7); s = Math.min(s, 0.9);
    return 'hsl(' + Math.round(h) + ',' + Math.round(s * 100) + '%,' + Math.round(l * 100) + '%)';
  }
  var COLOR_RE = /(?:rgba?|hsla?|hwb|lab|lch|oklab|oklch|color)\([^)]*\)/g;
  function gradLight(bi) {
    var re = new RegExp(COLOR_RE.source, 'g'), m, n = 0, l = 0, sat = 0;
    while ((m = re.exec(bi))) { var c = rgb(m[0]); if (!c) continue; n++; l += c.l; sat = Math.max(sat, c.sat); }
    return n > 0 && l / n > 0.72 && sat < 0.22;
  }

  // ---------------------------------------------------------------- the surface behind an element (after our own changes)
  function up(n) { return n.parentElement || (n.parentNode && n.parentNode.host) || null; }
  // returns luminance 0..1 of the nearest opaque background, -1 when a picture is behind the text, 0.13 for the (dark) page canvas
  function surfL(el) {
    var path = [], n = el, res;
    for (var i = 0; n && i < 30; i++) {
      if (surfCache.has(n)) { res = surfCache.get(n); break; }
      path.push(n);
      if (n.getAttribute('data-abtin-dark-bg') === '1' || n.getAttribute('data-abtin-dark-grad') === '1') { res = 0.15; break; }
      var cs = null;
      try { cs = getComputedStyle(n); } catch (e) {}
      if (cs) {
        var c = parseColor(cs.backgroundColor, 0.6);
        if (c) { res = c.l; break; }
        var bi = cs.backgroundImage;
        if (bi && bi !== 'none' && bi.indexOf('gradient') < 0) { res = -1; break; }
      }
      n = up(n);
    }
    if (res === undefined) res = 0.13;
    for (var k = 0; k < path.length; k++) surfCache.set(path[k], res);
    return res;
  }

  // ---------------------------------------------------------------- style injection (adopted sheet + <style>: either may be blocked)
  function inject(root, css) {
    try {
      var sh = new window.CSSStyleSheet(); sh.replaceSync(css);
      root.adoptedStyleSheets = Array.prototype.slice.call(root.adoptedStyleSheets || []).concat([sh]);
      ownStyles.push({ root: root, sheet: sh });
    } catch (e) {}
    try {
      var st = document.createElement('style'); st.setAttribute('data-abtin-dark-style', '1'); st.textContent = css;
      (root === document ? (document.head || document.documentElement) : root).appendChild(st);
      ownStyles.push({ el: st });
    } catch (e) {}
  }
  function removeInjected() {
    ownStyles.forEach(function (o) {
      try {
        if (o.el && o.el.parentNode) o.el.parentNode.removeChild(o.el);
        if (o.sheet) o.root.adoptedStyleSheets = Array.prototype.slice.call(o.root.adoptedStyleSheets || []).filter(function (s) { return s !== o.sheet; });
      } catch (e) {}
    });
    ownStyles = [];
  }

  // ---------------------------------------------------------------- tagging one element
  function rm(el, k) { if (el.hasAttribute('data-abtin-dark-' + k)) el.removeAttribute('data-abtin-dark-' + k); }
  function tag(el) {
    if (!el || el.nodeType !== 1) return;
    var t = el.tagName.toLowerCase();
    if (T_SKIP.test(t)) return;
    if (t === 'img') { maybeImg(el); return; }
    if (T_MEDIA.test(t) || el.namespaceURI === SVGNS) return;
    var cs;
    try { cs = getComputedStyle(el); } catch (e) { return; }
    if (cs.display === 'none') return;
    var bg = rgb(cs.backgroundColor), fg = rgb(cs.color), bd = null;
    if (bg && bg.l > 0.72 && bg.sat < 0.22) el.setAttribute('data-abtin-dark-bg', '1'); else rm(el, 'bg');
    var bi = cs.backgroundImage;
    if (bi && bi.indexOf('gradient') >= 0 && gradLight(bi)) el.setAttribute('data-abtin-dark-grad', '1'); else rm(el, 'grad');
    // text colour: judged against the surface that is really behind it (our own bg/grad tags above are already counted)
    var want = 0;
    if (fg) {
      if (fg.l < 0.42) {
        var sl = surfL(el);
        if (sl <= 0.5) want = fg.sat >= 0.3 ? 2 : 1; // dark text on a dark surface: lighten (coloured text keeps its hue)
        // dark text on a surface that stays light (yellow badge, mid-grey chip): it is already readable, leave it
      } else if (fg.l > 0.62 && fg.sat < 0.3) {
        var sl2 = surfL(el);
        if (sl2 > 0.6) want = 3; // light text on a light surface we could not darken: make the text dark
      }
    }
    if (want === 2) {
      var v = lighten(fg);
      if (el.style.getPropertyValue('--abtin-c') !== v) { selfEdit.add(el); el.style.setProperty('--abtin-c', v); }
    }
    if (want) el.setAttribute('data-abtin-dark-fg', String(want)); else rm(el, 'fg');
    bd = rgb(cs.borderTopColor);
    if (bd && bd.l > 0.68 && bd.sat < 0.2 && cs.borderTopStyle !== 'none') el.setAttribute('data-abtin-dark-border', '1'); else rm(el, 'border');
  }
  function retag(el) { surfCache = new WeakMap(); tag(el); }

  // ---------------------------------------------------------------- images: logos on white / black glyphs on transparent
  var imgBusy = 0, imgQueue = [], imgCount = 0;
  function maybeImg(img) {
    if (img.__abtinImg) return;
    if (!img.complete || !img.naturalWidth) {
      if (!img.__abtinWait) { img.__abtinWait = true; img.addEventListener('load', function () { img.__abtinWait = false; maybeImg(img); }, { once: true }); }
      return;
    }
    var w = img.clientWidth, h = img.clientHeight;
    if (w < 8 || h < 8 || w > 480 || h > 480 || imgCount > 80) return; // big pictures are photos: leave them alone
    var src = img.currentSrc || img.src;
    if (!/^(https?:|data:image\/)/i.test(src || '') || src.length > 300000) return;
    img.__abtinImg = true; imgCount++;
    imgQueue.push({ img: img, src: src });
    nextImg();
  }
  function nextImg() {
    while (imgBusy < 3 && imgQueue.length) {
      var j = imgQueue.shift(); imgBusy++;
      (function (j) {
        browser.runtime.sendMessage({ t: 'imgKind', url: j.src }).then(function (k) {
          if (on && !skip && k === 'i') j.img.setAttribute('data-abtin-dark-img', '1');
        }).catch(function () {}).then(function () { imgBusy--; nextImg(); });
      })(j);
    }
  }

  // ---------------------------------------------------------------- collecting (incl. shadow roots) and time-sliced work
  function shadowOf(el) { try { return el.openOrClosedShadowRoot || el.shadowRoot || null; } catch (e) { return null; } }
  function collect(root, out) {
    if (root.nodeType === 1) { out.push(root); var s0 = shadowOf(root); if (s0) { hook(s0); collect(s0, out); } }
    var all = root.querySelectorAll ? root.querySelectorAll('*') : [];
    for (var i = 0; i < all.length; i++) {
      var el = all[i]; out.push(el);
      var sr = shadowOf(el);
      if (sr) { hook(sr); collect(sr, out); }
    }
  }
  function hook(sr) {
    if (hooked.has(sr)) return;
    hooked.add(sr);
    inject(sr, SHADOW_CSS);
    try {
      var m = new MutationObserver(onMutations);
      m.observe(sr, { subtree: true, childList: true, attributes: true, attributeFilter: ['style', 'class', 'src', 'srcset'] });
      shadowMo.push(m);
    } catch (e) {}
  }
  function enqueue(root) {
    if (!on || skip) return;
    var list = [];
    try { collect(root, list); } catch (e) {}
    if (work.length - wi > 30000) return;
    for (var i = 0; i < list.length; i++) work.push(list[i]);
    if (!pumping) { pumping = true; surfCache = new WeakMap(); pump(); }
  }
  function later(fn) {
    if (window.requestIdleCallback) window.requestIdleCallback(fn, { timeout: 250 }); else setTimeout(fn, 16);
  }
  function pump() {
    var t0 = performance.now();
    while (wi < work.length) {
      if (!on || skip) { work = []; wi = 0; pumping = false; return; }
      tag(work[wi++]);
      if ((wi & 15) === 0 && performance.now() - t0 > 8) { later(pump); return; } // stay under one frame
    }
    work = []; wi = 0; pumping = false; surfCache = new WeakMap();
  }

  function onMutations(records) {
    if (!on || skip) return;
    var now = Date.now();
    for (var i = 0; i < records.length; i++) {
      var r = records[i];
      if (r.type === 'childList') {
        for (var j = 0; j < r.addedNodes.length; j++) { var n = r.addedNodes[j]; if (n.nodeType === 1 && !(n.getAttribute && n.getAttribute('data-abtin-dark-style'))) pendingRoots.add(n); }
      } else if (r.type === 'attributes') {
        var el = r.target;
        if (r.attributeName === 'style' && selfEdit.has(el)) { selfEdit.delete(el); continue; }
        if (r.attributeName === 'src' || r.attributeName === 'srcset') {
          if (el.tagName === 'IMG') { el.__abtinImg = false; el.removeAttribute('data-abtin-dark-img'); pendingRoots.add(el); }
          continue;
        }
        if (el.__abtinT && now - el.__abtinT < 400) { // animated styles: not every frame, but the LAST change must still be scanned
          lateRoots.add(el);
          if (!lateTimer) lateTimer = setTimeout(flushLate, 500);
          continue;
        }
        el.__abtinT = now;
        // a class change on <html>/<body> (site theme switch) can recolour everything below it
        pendingRoots.add(el);
      }
    }
    if (!flushTimer && (pendingRoots.size || pendingEls.size)) flushTimer = setTimeout(flush, 120);
  }
  function flush() {
    flushTimer = 0;
    var roots = Array.from(pendingRoots); pendingRoots.clear();
    var els = Array.from(pendingEls).slice(0, 1500); pendingEls.clear();
    if (!on || skip) return;
    roots.forEach(function (n) { if (n.isConnected) enqueue(n); });
    if (els.length) { surfCache = new WeakMap(); els.forEach(function (n) { if (n.isConnected) tag(n); }); }
  }
  function flushLate() {
    lateTimer = 0;
    var list = Array.from(lateRoots); lateRoots.clear();
    if (!on || skip) return;
    list.forEach(function (n) {
      if (!n.isConnected) return;
      n.__abtinT = Date.now();
      var small = false;
      try { small = n.getElementsByTagName('*').length < 400; } catch (e) {}
      if (small) enqueue(n); else retag(n);
    });
  }
  function onTrans(e) { // a colour transition finished: the computed value measured earlier may have been mid-way
    if (!on || skip) return;
    var t = e.target;
    if (!t || t.nodeType !== 1 || T_SKIP.test(t.tagName.toLowerCase())) return;
    pendingEls.add(t);
    if (!flushTimer) flushTimer = setTimeout(flush, 120);
  }

  // ---------------------------------------------------------------- is the SITE dark already? (our rules must be off while measuring)
  function measureDark() {
    var h = document.documentElement, b = document.body;
    if (!h) return false;
    var cs = getComputedStyle(h), sch = cs.colorScheme || '';
    if (/\bdark\b/.test(sch) && !/\blight\b/.test(sch)) return true; // site declares itself dark
    var W = window.innerWidth || 360, H = window.innerHeight || 640;
    var pts = [[.5, .3], [.5, .55], [.2, .4], [.8, .4], [.5, .8], [.5, .15]], dark = 0, light = 0;
    for (var i = 0; i < pts.length; i++) {
      var e = null;
      try { e = document.elementFromPoint(W * pts[i][0], H * pts[i][1]); } catch (x) {}
      var l = 1; // nothing opaque behind it -> the white canvas
      for (var n = e, k = 0; n && k < 40; n = up(n), k++) {
        var c = parseColor(getComputedStyle(n).backgroundColor, 0.6);
        if (c) { l = c.l; break; }
      }
      if (l < 0.4) dark++; else if (l > 0.6) light++;
    }
    if (dark + light === 0 || !b) {
      var c0 = rgb(getComputedStyle(b || h).backgroundColor);
      return !!(c0 && c0.l < 0.38);
    }
    return dark >= 2 && dark > light;
  }
  function judge() { // classes of ours off -> measure -> restore. Same task, so no frame is painted in between.
    var h = document.documentElement, res = false;
    var wasOn = h.classList.contains('__abtin_dark'), wasP = h.classList.contains('__abtin_dark_pending');
    h.classList.remove('__abtin_dark', '__abtin_dark_pending');
    try { res = measureDark(); } catch (e) {}
    if (wasOn) h.classList.add('__abtin_dark');
    if (wasP) h.classList.add('__abtin_dark_pending');
    if (mo) mo.takeRecords();
    if (moRoot) moRoot.takeRecords();
    return res;
  }
  function forcedOn() { return !!(cfg.sites && cfg.sites[host] === 'on'); }
  function scheduleJudge(ms) {
    if (!isTop || !on || judgeTimer || judgeCount > 25) return;
    judgeTimer = setTimeout(recheck, ms);
  }
  function recheck() {
    judgeTimer = 0;
    if (!on || !isTop || forcedOn()) return;
    var since = Date.now() - lastJudge;
    if (since < 800) { scheduleJudge(800 - since); return; }
    lastJudge = Date.now(); judgeCount++;
    var h = document.documentElement;
    var dark = judge();
    if (dark && !skip) { // the site turned dark (own theme finished loading / user switched it): back off completely
      skip = true; work = []; wi = 0; pumping = false;
      h.classList.remove('__abtin_dark', '__abtin_dark_pending');
      clearTags();
    } else if (!dark && skip) { // the site went light again: darken it
      skip = false;
      h.classList.add('__abtin_dark');
      startObservers();
      enqueue(h);
    }
    if (mo) mo.takeRecords();
    if (moRoot) moRoot.takeRecords();
  }

  // ---------------------------------------------------------------- start / stop
  function wanted() {
    var m = cfg.sites && cfg.sites[host];
    return m === 'on' ? true : m === 'off' ? false : !!cfg.forceDark;
  }
  function startObservers() {
    var h = document.documentElement;
    if (!h) return;
    if (!mo) {
      mo = new MutationObserver(onMutations);
      mo.observe(h, { subtree: true, childList: true, attributes: true, attributeFilter: ['style', 'class', 'src', 'srcset'] });
    }
    if (!trHooked) { trHooked = true; document.addEventListener('transitionend', onTrans, true); }
    if (isTop && !moRoot) { // theme switches of the site itself: any attribute on <html>/<body> (class, data-theme, style ...)
      moRoot = new MutationObserver(function () { scheduleJudge(400); });
      moRoot.observe(h, { attributes: true });
      if (document.body) moRoot.observe(document.body, { attributes: true });
    }
  }
  function firstScan() {
    var h = document.documentElement;
    if (!h || !on) return;
    // judge the page WITHOUT our own rules (they paint html/body dark and would always look "already dark")
    h.classList.remove('__abtin_dark_pending', '__abtin_dark');
    skip = isTop && !forcedOn() ? (function () { try { return measureDark(); } catch (e) { return false; } })() : false;
    lastJudge = Date.now();
    startObservers();
    if (!skip) { h.classList.add('__abtin_dark'); enqueue(h); }
    if (mo) mo.takeRecords();
    if (moRoot) moRoot.takeRecords();
    // late theme / lazy content: measure again a bit later (single-page apps render after DOMContentLoaded)
    setTimeout(function () { scheduleJudge(0); }, 900);
    setTimeout(function () { scheduleJudge(0); }, 2500);
  }
  function start() {
    var h = document.documentElement;
    if (!h) { document.addEventListener('readystatechange', function () { if (wanted() && !on) start(); }, { once: true }); return; }
    on = true; skip = false; judgeCount = 0;
    h.classList.add('__abtin_dark');
    if (isTop) h.classList.add('__abtin_dark_pending'); else h.classList.add('__abtin_dark_sub');
    inject(document, DOC_CSS);
    var go = function () { if (on) firstScan(); };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go, { once: true }); else go();
    // late stylesheets / lazy themes: one more pass (cheap pages only)
    window.addEventListener('load', function () {
      if (!on) return;
      if (!skip && document.getElementsByTagName('*').length < 4000) enqueue(document.documentElement);
      scheduleJudge(300);
    }, { once: true });
  }
  function clearTags() {
    try {
      Array.prototype.forEach.call(document.querySelectorAll('[data-abtin-dark-bg],[data-abtin-dark-grad],[data-abtin-dark-fg],[data-abtin-dark-border],[data-abtin-dark-img]'), function (e) {
        TAGS.forEach(function (k) { e.removeAttribute('data-abtin-dark-' + k); });
        if (e.style && e.style.getPropertyValue('--abtin-c')) e.style.removeProperty('--abtin-c');
        e.__abtinImg = false;
      });
    } catch (e) {}
    imgCount = 0; imgQueue = [];
  }
  function stop() {
    on = false; skip = false; work = []; wi = 0; pumping = false; imgQueue = [];
    if (mo) { mo.disconnect(); mo = null; }
    if (moRoot) { moRoot.disconnect(); moRoot = null; }
    if (trHooked) { document.removeEventListener('transitionend', onTrans, true); trHooked = false; }
    clearTimeout(flushTimer); clearTimeout(lateTimer); clearTimeout(judgeTimer); flushTimer = lateTimer = judgeTimer = 0;
    pendingRoots.clear(); pendingEls.clear(); lateRoots.clear();
    shadowMo.forEach(function (m) { try { m.disconnect(); } catch (e) {} }); shadowMo = []; hooked = new WeakSet();
    removeInjected();
    var h = document.documentElement;
    if (h) h.classList.remove('__abtin_dark', '__abtin_dark_pending', '__abtin_dark_sub');
    clearTags();
  }
  function apply() {
    var w = wanted();
    if (w && !on) start(); else if (!w && on) stop();
    else if (w && on && forcedOn() && skip) { skip = false; document.documentElement.classList.add('__abtin_dark'); startObservers(); enqueue(document.documentElement); }
  }

  browser.runtime.onMessage.addListener(function (m) {
    if (m && m.cmd === 'forceDark') {
      cfg.forceDark = !!m.on;
      if (m.sites) cfg.sites = m.sites;
      apply();
    }
  });
  browser.runtime.sendMessage({ t: 'getConfig' }).then(function (c) {
    if (!c) return;
    cfg.forceDark = !!c.forceDark;
    cfg.sites = c.darkSites || {};
    apply();
  }).catch(function () {});
})();
