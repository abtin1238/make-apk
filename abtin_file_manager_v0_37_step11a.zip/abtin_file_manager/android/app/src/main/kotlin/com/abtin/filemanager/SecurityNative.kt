package com.abtin.filemanager

import android.annotation.TargetApi
import android.app.Activity
import android.content.pm.PackageManager
import android.hardware.biometrics.BiometricManager
import android.hardware.biometrics.BiometricPrompt
import android.os.Build
import android.os.CancellationSignal
import android.os.Handler
import android.util.Base64
import android.view.WindowManager
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.GeneralSecurityException
import java.security.SecureRandom
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/** App lock (fingerprint via the framework BiometricPrompt, no extra dependency) + encrypted vault. Channel: abtin/sec */
object SecurityNative {
    private var cancel: CancellationSignal? = null
    private val vaultMethods = setOf(
        "pbkdf2", "vaultCreate", "vaultUnlock", "vaultLock", "vaultChangePw",
        "vaultEncrypt", "vaultDecrypt", "vaultReadIndex", "vaultWriteIndex",
    )

    fun register(act: Activity, messenger: BinaryMessenger, ui: Handler) {
        MethodChannel(messenger, "abtin/sec").setMethodCallHandler { call, result ->
            when {
                call.method == "bioStatus" -> result.success(bioStatus(act))
                call.method == "bioAuth" -> bioAuth(act, call.argument<String>("title") ?: "", call.argument<String>("cancel") ?: "", result)
                call.method == "bioCancel" -> { cancel?.cancel(); cancel = null; result.success(true) }
                call.method == "setSecure" -> {
                    val on = call.argument<Boolean>("on") ?: false
                    act.runOnUiThread {
                        if (on) act.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
                        else act.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                    }
                    result.success(true)
                }
                call.method in vaultMethods -> Thread {
                    try {
                        val r = VaultCrypto.handle(call)
                        ui.post { result.success(r) }
                    } catch (e: Throwable) {
                        ui.post { result.error("ERR", e.message ?: e.toString(), null) }
                    }
                }.start()
                else -> result.notImplemented()
            }
        }
    }

    /** 0 = unavailable, 1 = ready, 2 = hardware present but nothing enrolled */
    @Suppress("DEPRECATION")
    private fun bioStatus(act: Activity): Int {
        if (Build.VERSION.SDK_INT < 28) return 0
        if (!act.packageManager.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)) return 0
        if (Build.VERSION.SDK_INT < 29) return 1
        return try {
            val bm = act.getSystemService(BiometricManager::class.java) ?: return 0
            val r = if (Build.VERSION.SDK_INT >= 30) bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) else bm.canAuthenticate()
            when (r) {
                BiometricManager.BIOMETRIC_SUCCESS -> 1
                BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> 2
                else -> 0
            }
        } catch (e: Throwable) { 0 }
    }

    @TargetApi(28)
    private fun bioAuth(act: Activity, title: String, negative: String, result: MethodChannel.Result) {
        if (Build.VERSION.SDK_INT < 28) { result.success(false); return }
        cancel?.cancel()
        val done = AtomicBoolean(false)
        fun reply(v: Boolean) { if (done.compareAndSet(false, true)) result.success(v) }
        try {
            val exec = act.mainExecutor
            val b = BiometricPrompt.Builder(act)
                .setTitle(title)
                .setNegativeButton(negative, exec) { _, _ -> reply(false) }
            if (Build.VERSION.SDK_INT >= 29) b.setConfirmationRequired(false)
            val cs = CancellationSignal()
            cancel = cs
            b.build().authenticate(cs, exec, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult?) { reply(true) }
                override fun onAuthenticationError(code: Int, msg: CharSequence?) { reply(false) }
            })
        } catch (e: Throwable) {
            reply(false)
        }
    }
}

/** PBKDF2 + AES-256-GCM chunked file encryption. The master key never leaves this process. */
object VaultCrypto {
    @Volatile private var master: ByteArray? = null
    private val rnd = SecureRandom()
    private val MAGIC = byteArrayOf('A'.code.toByte(), 'B'.code.toByte(), 'V'.code.toByte(), 1)
    private const val CHUNK = 64 * 1024
    private const val TAG = 16
    private const val ITER = 120_000

    fun handle(c: MethodCall): Any? {
        val dir = c.argument<String>("dir") ?: ""
        return when (c.method) {
            "pbkdf2" -> b64(pbkdf2(c.argument<String>("pw")!!, Base64.decode(c.argument<String>("salt")!!, Base64.NO_WRAP), c.argument<Int>("iter") ?: ITER))
            "vaultCreate" -> create(File(dir), c.argument<String>("pw")!!)
            "vaultUnlock" -> unlock(File(dir), c.argument<String>("pw")!!)
            "vaultLock" -> { master?.fill(0); master = null; true }
            "vaultChangePw" -> changePw(File(dir), c.argument<String>("old")!!, c.argument<String>("new")!!)
            "vaultEncrypt" -> { encryptFile(File(c.argument<String>("src")!!), File(c.argument<String>("dst")!!)); true }
            "vaultDecrypt" -> { decryptFile(File(c.argument<String>("src")!!), File(c.argument<String>("dst")!!)); true }
            "vaultReadIndex" -> readIndex(File(c.argument<String>("path")!!))
            "vaultWriteIndex" -> { writeIndex(File(c.argument<String>("path")!!), c.argument<String>("json")!!); true }
            else -> throw UnsupportedOperationException(c.method)
        }
    }

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun rand(n: Int) = ByteArray(n).also { rnd.nextBytes(it) }
    private fun key() = master ?: throw IllegalStateException("Vault is locked")

    /** PBKDF2-HMAC-SHA256, one 32-byte block (works on every API level). */
    private fun pbkdf2(pw: String, salt: ByteArray, iter: Int): ByteArray {
        val pwb = pw.toByteArray(Charsets.UTF_8)
        if (pwb.isEmpty()) throw IllegalArgumentException("Empty password")
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(pwb, "HmacSHA256"))
        mac.update(salt)
        mac.update(byteArrayOf(0, 0, 0, 1))
        var u = mac.doFinal()
        val t = u.copyOf()
        for (i in 2..iter) {
            u = mac.doFinal(u)
            for (j in t.indices) t[j] = (t[j].toInt() xor u[j].toInt()).toByte()
        }
        return t
    }

    private fun gcm(mode: Int, key: ByteArray, nonce: ByteArray, aad: ByteArray, data: ByteArray, off: Int = 0, len: Int = data.size): ByteArray {
        val ci = Cipher.getInstance("AES/GCM/NoPadding")
        ci.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
        ci.updateAAD(aad)
        return ci.doFinal(data, off, len)
    }

    private fun writeMeta(meta: File, mk: ByteArray, pw: String) {
        val salt = rand(16)
        val nonce = rand(12)
        val kek = pbkdf2(pw, salt, ITER)
        val ct = gcm(Cipher.ENCRYPT_MODE, kek, nonce, "ABV-KEY".toByteArray(), mk)
        kek.fill(0)
        val j = JSONObject().put("v", 1).put("iter", ITER).put("salt", b64(salt)).put("nonce", b64(nonce)).put("wrapped", b64(ct))
        val tmp = File(meta.path + ".tmp")
        tmp.writeText(j.toString())
        if (!tmp.renameTo(meta)) { meta.delete(); if (!tmp.renameTo(meta)) throw IOException("Cannot write vault.json") }
    }

    private fun readMaster(meta: File, pw: String): ByteArray? {
        val j = JSONObject(meta.readText())
        val kek = pbkdf2(pw, Base64.decode(j.getString("salt"), Base64.NO_WRAP), j.getInt("iter"))
        return try {
            gcm(Cipher.DECRYPT_MODE, kek, Base64.decode(j.getString("nonce"), Base64.NO_WRAP), "ABV-KEY".toByteArray(), Base64.decode(j.getString("wrapped"), Base64.NO_WRAP))
        } catch (e: GeneralSecurityException) {
            null
        } finally {
            kek.fill(0)
        }
    }

    private fun create(dir: File, pw: String): Boolean {
        dir.mkdirs()
        val meta = File(dir, "vault.json")
        if (meta.exists()) throw IllegalStateException("Vault already exists")
        val mk = rand(32)
        writeMeta(meta, mk, pw)
        File(dir, ".nomedia").createNewFile()
        master = mk
        return true
    }

    private fun unlock(dir: File, pw: String): Boolean {
        val mk = readMaster(File(dir, "vault.json"), pw) ?: return false
        master = mk
        return true
    }

    private fun changePw(dir: File, old: String, new: String): Boolean {
        val meta = File(dir, "vault.json")
        val mk = readMaster(meta, old) ?: return false
        writeMeta(meta, mk, new)
        master = mk
        return true
    }

    // ---------- chunked AES-GCM stream: MAGIC(4) prefix(8) then [len(4) ciphertext+tag]* ----------
    private fun nonce(prefix: ByteArray, idx: Int): ByteArray {
        val n = ByteArray(12)
        System.arraycopy(prefix, 0, n, 0, 8)
        n[8] = (idx ushr 24).toByte(); n[9] = (idx ushr 16).toByte(); n[10] = (idx ushr 8).toByte(); n[11] = idx.toByte()
        return n
    }

    private fun aad(last: Boolean, idx: Int) =
        byteArrayOf(if (last) 1 else 0, (idx ushr 24).toByte(), (idx ushr 16).toByte(), (idx ushr 8).toByte(), idx.toByte())

    private fun readFull(ins: InputStream, b: ByteArray): Int {
        var n = 0
        while (n < b.size) {
            val r = ins.read(b, n, b.size - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    private fun readInt(ins: InputStream): Int {
        val b = ByteArray(4)
        val n = readFull(ins, b)
        if (n == 0) return -1
        if (n < 4) throw IOException("Truncated file")
        return ((b[0].toInt() and 255) shl 24) or ((b[1].toInt() and 255) shl 16) or ((b[2].toInt() and 255) shl 8) or (b[3].toInt() and 255)
    }

    private fun writeInt(os: OutputStream, v: Int) {
        os.write(byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte()))
    }

    private fun encryptStream(ins: InputStream, os: OutputStream) {
        val k = key()
        val prefix = rand(8)
        os.write(MAGIC)
        os.write(prefix)
        var cur = ByteArray(CHUNK)
        var nxt = ByteArray(CHUNK)
        var curLen = readFull(ins, cur)
        var idx = 0
        while (true) {
            val nxtLen = if (curLen == CHUNK) readFull(ins, nxt) else 0
            val last = nxtLen <= 0
            val ct = gcm(Cipher.ENCRYPT_MODE, k, nonce(prefix, idx), aad(last, idx), cur, 0, curLen)
            writeInt(os, ct.size)
            os.write(ct)
            if (last) break
            val t = cur; cur = nxt; nxt = t
            curLen = nxtLen
            idx++
        }
    }

    private fun decryptStream(ins: InputStream, os: OutputStream) {
        val k = key()
        val hdr = ByteArray(12)
        if (readFull(ins, hdr) != 12 || !hdr.copyOfRange(0, 4).contentEquals(MAGIC)) throw IOException("Not a vault file")
        val prefix = hdr.copyOfRange(4, 12)
        var len = readInt(ins)
        if (len < 0) throw IOException("Truncated file")
        var idx = 0
        while (true) {
            if (len < TAG || len > CHUNK + TAG) throw IOException("Corrupt file")
            val ct = ByteArray(len)
            if (readFull(ins, ct) != len) throw IOException("Truncated file")
            val nextLen = readInt(ins)
            val last = nextLen < 0
            val pt = try {
                gcm(Cipher.DECRYPT_MODE, k, nonce(prefix, idx), aad(last, idx), ct)
            } catch (e: GeneralSecurityException) {
                throw IOException("Corrupt file or wrong key")
            }
            os.write(pt)
            if (last) break
            len = nextLen
            idx++
        }
    }

    private fun viaTemp(dst: File, body: (OutputStream) -> Unit) {
        dst.parentFile?.mkdirs()
        val tmp = File(dst.path + ".tmp")
        try {
            FileOutputStream(tmp).use { body(it.buffered(1 shl 16)) }
        } catch (e: Throwable) {
            tmp.delete()
            throw e
        }
        if (dst.exists()) dst.delete()
        if (!tmp.renameTo(dst)) { tmp.delete(); throw IOException("Cannot write ${dst.name}") }
    }

    private fun encryptFile(src: File, dst: File) {
        FileInputStream(src).use { ins ->
            viaTemp(dst) { os -> encryptStream(ins, os); os.flush() }
        }
    }

    private fun decryptFile(src: File, dst: File) {
        FileInputStream(src).buffered(1 shl 16).use { ins ->
            viaTemp(dst) { os -> decryptStream(ins, os); os.flush() }
        }
    }

    private fun readIndex(f: File): String? {
        if (!f.exists()) return null
        val out = ByteArrayOutputStream()
        FileInputStream(f).use { decryptStream(it, out) }
        return out.toString("UTF-8")
    }

    private fun writeIndex(f: File, json: String) {
        if (f.exists()) try { f.copyTo(File(f.path + ".bak"), overwrite = true) } catch (_: Throwable) {}
        viaTemp(f) { os -> encryptStream(ByteArrayInputStream(json.toByteArray(Charsets.UTF_8)), os); os.flush() }
    }
}
