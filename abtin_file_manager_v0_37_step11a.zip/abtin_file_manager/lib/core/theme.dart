import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xFF070B1A);
  static const card = Color(0xFF111A33);
  static const blue = Color(0xFF2F6BFF);
  static const purple = Color(0xFF8B5CF6);
  static const gold = Color(0xFFF5A623);
  static const grad = LinearGradient(colors: [blue, purple], begin: Alignment.topLeft, end: Alignment.bottomRight);
}

ThemeData buildTheme(bool dark) {
  final scheme = ColorScheme.fromSeed(seedColor: AppColors.blue, brightness: dark ? Brightness.dark : Brightness.light, primary: AppColors.blue, secondary: AppColors.purple);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: dark ? AppColors.bg : const Color(0xFFF3F5FB),
    cardColor: dark ? AppColors.card : Colors.white,
    appBarTheme: AppBarTheme(backgroundColor: dark ? AppColors.bg : const Color(0xFFF3F5FB), elevation: 0, scrolledUnderElevation: 0),
    navigationBarTheme: NavigationBarThemeData(backgroundColor: dark ? const Color(0xFF0B1226) : Colors.white, indicatorColor: AppColors.blue.withOpacity(.25)),
    dialogTheme: DialogTheme(backgroundColor: dark ? AppColors.card : Colors.white),
    bottomSheetTheme: BottomSheetThemeData(backgroundColor: dark ? AppColors.card : Colors.white),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: dark ? const Color(0xFF0B1226) : const Color(0xFFEAEEF8), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
  );
}
