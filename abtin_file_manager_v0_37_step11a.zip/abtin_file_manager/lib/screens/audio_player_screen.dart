import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:media_kit/media_kit.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../core/theme.dart';
import '../services/player_service.dart';
import 'audio_options_screen.dart';
import 'equalizer_screen.dart';
import 'tag_editor_screen.dart';

class AudioPlayerScreen extends StatefulWidget {
  const AudioPlayerScreen({super.key});
  @override
  State<AudioPlayerScreen> createState() => _AudioPlayerScreenState();
}

class _AudioPlayerScreenState extends State<AudioPlayerScreen> with SingleTickerProviderStateMixin {
  late final AnimationController spin = AnimationController(vsync: this, duration: const Duration(seconds: 12));
  final lyrCtl = ScrollController();
  List<(Duration, String)>? lrc;
  String? lrcFor;
  bool showLyrics = false;
  int _lastIdx = -1;
  double? _drag;

  @override
  void dispose() {
    spin.dispose();
    lyrCtl.dispose();
    super.dispose();
  }

  File? _lrcFile(String song) {
    if (song.startsWith('http')) return null;
    final base = p.withoutExtension(song);
    for (final e in ['lrc', 'LRC', 'txt']) {
      final f = File('$base.$e');
      if (f.existsSync()) return f;
    }
    return null;
  }

  Future<void> _loadLrc(String song) async {
    lrcFor = song;
    _lastIdx = -1;
    final f = _lrcFile(song);
    if (f == null) {
      lrc = null;
      return;
    }
    final out = <(Duration, String)>[];
    final re = RegExp(r'\[(\d+):(\d+(?:\.\d+)?)\]');
    try {
      for (final line in await f.readAsLines()) {
        final ms = re.allMatches(line).toList();
        final text = line.replaceAll(re, '').trim();
        for (final m in ms) {
          out.add((Duration(milliseconds: (int.parse(m[1]!) * 60000 + double.parse(m[2]!) * 1000).round()), text));
        }
      }
    } catch (_) {}
    out.sort((a, b) => a.$1.compareTo(b.$1));
    lrc = out.isEmpty ? null : out;
    if (mounted) setState(() {});
  }

  String _t(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  Widget _disc(PlayerService pl) {
    final art = pl.meta?.art;
    return Center(
      child: RotationTransition(
        turns: spin,
        child: Container(
          width: 300,
          height: 300,
          decoration: const BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [Color(0xFF222222), Color(0xFF050505)]), boxShadow: [BoxShadow(color: Color(0x55F5A623), blurRadius: 40)]),
          child: Center(
            child: Container(
              width: art != null ? 190 : 120,
              height: art != null ? 190 : 120,
              clipBehavior: Clip.antiAlias,
              decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [Color(0xFFF7B544), Color(0xFFD98A12)])),
              child: art != null
                  ? Image.memory(art, fit: BoxFit.cover, gaplessPlayback: true, errorBuilder: (_, __, ___) => const Icon(Icons.music_note_rounded, size: 56, color: Color(0xFF3A2A08)))
                  : const Icon(Icons.music_note_rounded, size: 56, color: Color(0xFF3A2A08)),
            ),
          ),
        ),
      ),
    );
  }

  Widget _lyrics(PlayerService pl) => StreamBuilder<Duration>(
        stream: pl.player.stream.position,
        builder: (c, snap) {
          final pos = snap.data ?? Duration.zero;
          var idx = lrc!.lastIndexWhere((e) => e.$1 <= pos);
          if (idx < 0) idx = 0;
          if (idx != _lastIdx) {
            _lastIdx = idx;
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (lyrCtl.hasClients) {
                final target = (idx * 52.0 - lyrCtl.position.viewportDimension / 2 + 26).clamp(0.0, lyrCtl.position.maxScrollExtent).toDouble();
                lyrCtl.animateTo(target, duration: const Duration(milliseconds: 350), curve: Curves.easeOut);
              }
            });
          }
          return ListView.builder(
            controller: lyrCtl,
            itemExtent: 52,
            itemCount: lrc!.length,
            itemBuilder: (_, i) => InkWell(
              onTap: () => pl.player.seek(lrc![i].$1),
              child: Center(
                child: Text(lrc![i].$2, textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: i == idx ? 22 : 16, color: i == idx ? AppColors.gold : Colors.white54, fontWeight: i == idx ? FontWeight.bold : FontWeight.normal)),
              ),
            ),
          );
        },
      );

  Future<void> _sleepMenu(PlayerService pl) async {
    final r = await showModalBottomSheet<int>(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          ListTile(title: Text(L.t('sleepTimer'), style: const TextStyle(fontWeight: FontWeight.bold))),
          if (pl.sleepActive) ListTile(leading: const Icon(Icons.timer_off_rounded), title: Text(L.t('off')), onTap: () => Navigator.pop(context, -1)),
          for (final m in [5, 10, 15, 30, 45, 60, 90]) ListTile(leading: const Icon(Icons.timer_rounded), title: Text('$m ${L.t('minutes')}'), onTap: () => Navigator.pop(context, m)),
          ListTile(leading: const Icon(Icons.music_off_rounded), title: Text(L.t('endOfTrack')), onTap: () => Navigator.pop(context, 0)),
        ]),
      ),
    );
    if (r == null) return;
    if (r < 0) {
      pl.setSleep(null);
    } else if (r == 0) {
      pl.setSleep(null, endOfTrack: true);
    } else {
      pl.setSleep(Duration(minutes: r));
    }
  }

  void _queue() => showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        builder: (_) => Consumer<PlayerService>(
          builder: (c, pl, _) => SizedBox(
            height: MediaQuery.of(c).size.height * .7,
            child: Column(children: [
              ListTile(
                title: Text('${L.t('nextQueue')} (${pl.queue.length})', style: const TextStyle(fontWeight: FontWeight.bold)),
                trailing: TextButton(onPressed: () { pl.stopAll(); Navigator.pop(c); Navigator.pop(context); }, child: Text(L.t('clear'))),
              ),
              Expanded(
                child: ReorderableListView.builder(
                  itemCount: pl.queue.length,
                  onReorder: (a, b) => pl.moveItem(a, b > a ? b - 1 : b),
                  itemBuilder: (c, i) => ListTile(
                    key: ValueKey('$i-${pl.queue[i]}'),
                    selected: i == pl.index,
                    leading: Text('${i + 1}'),
                    title: Text(p.basenameWithoutExtension(Uri.decodeFull(pl.queue[i])), maxLines: 1, overflow: TextOverflow.ellipsis),
                    trailing: IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => pl.removeAt(i)),
                    onTap: () { pl.player.jump(i); Navigator.pop(c); },
                  ),
                ),
              ),
            ]),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final pl = context.watch<PlayerService>();
    final s = context.watch<AppSettings>();
    if (pl.playing) {
      if (!spin.isAnimating) spin.repeat();
    } else {
      spin.stop();
    }
    if (pl.hasQueue && lrcFor != pl.current) _loadLrc(pl.current);
    final hasLrc = lrc != null;
    final rate = pl.player.state.rate;
    return Scaffold(
      backgroundColor: const Color(0xFF0A0D14),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: IconButton(icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32), onPressed: () => Navigator.pop(context)),
        centerTitle: true,
        title: const Text.rich(TextSpan(children: [TextSpan(text: 'Abtin '), TextSpan(text: 'Media', style: TextStyle(color: AppColors.gold))]), style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(icon: Icon(Icons.bedtime_rounded, color: pl.sleepActive ? AppColors.gold : null), tooltip: L.t('sleepTimer'), onPressed: () => _sleepMenu(pl)),
          IconButton(icon: const Icon(Icons.equalizer_rounded), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const EqualizerScreen()))),
          PopupMenuButton<String>(
            onSelected: (v) async {
              if (v == 'share' && pl.hasQueue && !pl.current.startsWith('http')) Share.shareXFiles([XFile(pl.current)]);
              if (v == 'ab') pl.toggleAB();
              if (v == 'opts') Navigator.push(context, MaterialPageRoute(builder: (_) => const AudioOptionsScreen()));
              if (v == 'tags' && pl.hasQueue && !pl.current.startsWith('http')) Navigator.push(context, MaterialPageRoute(builder: (_) => TagEditorScreen(path: pl.current)));
              if (v.startsWith('r')) pl.setRate(double.parse(v.substring(1)));
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'ab', child: Text('A-B ${L.t('loop')}${pl.abStage == 0 ? '' : pl.abStage == 1 ? '  (A)' : '  (A-B ✓)'}')),
              PopupMenuItem(value: 'tags', child: Text(L.t('tagEdit'))),
              PopupMenuItem(value: 'opts', child: Text(L.t('playOpts'))),
              PopupMenuItem(value: 'share', child: Text(L.t('share'))),
              const PopupMenuDivider(),
              for (final v in [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]) PopupMenuItem(value: 'r$v', child: Text('${L.t('speed')} ${v}x${rate == v ? '  ✓' : ''}')),
            ],
          ),
        ],
      ),
      body: !pl.hasQueue
          ? const SizedBox()
          : Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(children: [
                Expanded(child: showLyrics && hasLrc ? _lyrics(pl) : _disc(pl)),
                Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(pl.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                      Text([pl.artist, pl.album].where((e) => e.isNotEmpty).join(' • '), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54)),
                    ]),
                  ),
                  IconButton(
                    icon: Icon(s.isFav(pl.current) ? Icons.star_rounded : Icons.star_border_rounded, color: AppColors.gold, size: 30),
                    onPressed: () => s.toggleFav(pl.current),
                  ),
                ]),
                const SizedBox(height: 6),
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Wrap(spacing: 8, children: [
                    ActionChip(
                      avatar: const Icon(Icons.article_outlined, size: 18),
                      label: Text(hasLrc ? (showLyrics ? L.t('disc') : L.t('lyrics')) : L.t('addLyrics')),
                      onPressed: hasLrc
                          ? () => setState(() => showLyrics = !showLyrics)
                          : () async {
                              if (pl.current.startsWith('http')) return;
                              final r = await FilePicker.platform.pickFiles();
                              final f = r?.files.single.path;
                              if (f == null) return;
                              if (!await ensureSdAll(context, [pl.current])) return;
                              await Saf.copyTo(f, '${p.withoutExtension(pl.current)}.lrc');
                              lrcFor = null;
                              setState(() {});
                            },
                    ),
                    if (pl.abStage != 0) ActionChip(avatar: const Icon(Icons.repeat_rounded, size: 18), label: Text(pl.abStage == 1 ? 'A…' : 'A-B'), onPressed: pl.toggleAB),
                    if (pl.sleepActive)
                      ActionChip(
                        avatar: const Icon(Icons.bedtime_rounded, size: 18),
                        label: Text(pl.sleepEndOfTrack ? L.t('endOfTrack') : '${pl.sleepAt!.difference(DateTime.now()).inMinutes + 1} ${L.t('minutes')}'),
                        onPressed: () => pl.setSleep(null),
                      ),
                  ]),
                ),
                StreamBuilder<Duration>(
                  stream: pl.player.stream.position,
                  builder: (c, snap) {
                    final pos = snap.data ?? Duration.zero;
                    final dur = pl.player.state.duration;
                    final max = dur.inMilliseconds.toDouble().clamp(1, double.infinity).toDouble();
                    final v = (_drag ?? pos.inMilliseconds.toDouble()).clamp(0, max).toDouble();
                    return Column(children: [
                      Slider(
                        activeColor: AppColors.gold,
                        value: v,
                        max: max,
                        onChanged: (x) => setState(() => _drag = x),
                        onChangeEnd: (x) {
                          pl.player.seek(Duration(milliseconds: x.round()));
                          setState(() => _drag = null);
                        },
                      ),
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(_t(Duration(milliseconds: v.round()))), Text(_t(dur))]),
                    ]);
                  },
                ),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  IconButton(
                    icon: Icon(pl.mode == PlaylistMode.single ? Icons.repeat_one_rounded : Icons.repeat_rounded, color: pl.mode == PlaylistMode.none ? Colors.white : AppColors.gold),
                    onPressed: pl.cycleMode,
                  ),
                  IconButton(iconSize: 38, icon: const Icon(Icons.skip_previous_rounded), onPressed: pl.player.previous),
                  Container(
                    decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: AppColors.gold, width: 3)),
                    child: IconButton(iconSize: 48, icon: Icon(pl.playing ? Icons.pause_rounded : Icons.play_arrow_rounded), onPressed: pl.player.playOrPause),
                  ),
                  IconButton(iconSize: 38, icon: const Icon(Icons.skip_next_rounded), onPressed: pl.player.next),
                  IconButton(icon: Icon(Icons.shuffle_rounded, color: pl.shuffle ? AppColors.gold : Colors.white), onPressed: pl.toggleShuffle),
                ]),
                Row(children: [
                  IconButton(icon: const Icon(Icons.replay_10_rounded), onPressed: () => pl.seekBy(const Duration(seconds: -10))),
                  Icon(pl.volume == 0 ? Icons.volume_off_rounded : Icons.volume_up_rounded, size: 20),
                  Expanded(child: Slider(value: pl.volume, max: 100, onChanged: pl.setVolume)),
                  IconButton(icon: const Icon(Icons.forward_10_rounded), onPressed: () => pl.seekBy(const Duration(seconds: 10))),
                ]),
                ListTile(
                  tileColor: Colors.white10,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                  leading: const Icon(Icons.queue_music_rounded),
                  title: Text('${L.t('nextQueue')} (${pl.queue.length})'),
                  trailing: const Icon(Icons.chevron_right_rounded, matchTextDirection: true),
                  onTap: _queue,
                ),
                const SizedBox(height: 12),
              ]),
            ),
    );
  }
}
