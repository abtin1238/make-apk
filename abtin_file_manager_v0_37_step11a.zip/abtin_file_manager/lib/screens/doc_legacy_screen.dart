import 'dart:io';
import 'package:flutter/material.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:path/path.dart' as p;
import 'package:open_filex/open_filex.dart';
import '../core/l10n.dart';
import '../services/doc_legacy.dart';
import '../services/file_ops.dart';
import '../widgets/ui.dart';
import 'docx_editor_screen.dart';

/// Opens a legacy binary .doc inside the app: text is extracted, can be edited,
/// and "Save" writes a new .docx next to the original (the .doc itself is never altered).
class DocLegacyScreen extends StatefulWidget {
  final String path;
  const DocLegacyScreen({super.key, required this.path});
  @override
  State<DocLegacyScreen> createState() => _DocLegacyScreenState();
}

class _DocLegacyScreenState extends State<DocLegacyScreen> {
  final ctl = TextEditingController();
  bool loading = true, dirty = false, edit = false;
  List<DocPara>? paras;
  double font = 16;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final bytes = await File(widget.path).readAsBytes();
      try {
        paras = DocLegacy.extractFormatted(bytes);
        if (paras!.isEmpty) paras = null;
      } catch (_) {
        paras = null;
      }
      ctl.text = paras != null ? paras!.map((e) => e.text).join('\n') : DocLegacy.extractText(bytes);
      edit = paras == null;
      if (mounted) setState(() => loading = false);
    } catch (e) {
      if (!mounted) return;
      snack(context, '${L.t('error')}: $e');
      await OpenFilex.open(widget.path); // fall back to another app
      if (mounted) Navigator.pop(context);
    }
  }

  TextDirection get _dir => RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(ctl.text) ? TextDirection.rtl : TextDirection.ltr;

  Future<void> _saveDocx() async {
    if (!await ensureSdAll(context, [widget.path])) return;
    if (!mounted) return;
    String? target;
    final ok = await busy(context, () async {
      target = FileOps.unique(p.dirname(widget.path), '${p.basenameWithoutExtension(widget.path)}.docx');
      await Saf.writeBytes(target!, edit || paras == null ? DocLegacy.buildDocx(ctl.text) : DocLegacy.buildDocxFormatted(paras!));
    });
    if (ok && mounted && target != null) {
      setState(() => dirty = false);
      snack(context, '${L.t('done')}: ${p.basename(target!)}');
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => DocxEditorScreen(path: target!)));
    }
  }

  Widget _paraView(DocPara p) {
    final align = switch (p.jc) { 1 => TextAlign.center, 2 => TextAlign.end, 3 => TextAlign.justify, _ => TextAlign.start };
    return Directionality(
      textDirection: p.rtl ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: SelectableText.rich(
          TextSpan(children: [
            for (final r in p.runs)
              TextSpan(
                text: r.text,
                style: TextStyle(
                  fontWeight: r.b ? FontWeight.bold : null,
                  fontStyle: r.i ? FontStyle.italic : null,
                  decoration: r.u ? TextDecoration.underline : null,
                  fontSize: r.sz > 0 ? r.sz / 2 * (font / 12) : font,
                  color: r.color != null ? Color(0xFF000000 | r.color!) : null,
                ),
              ),
            if (p.runs.isEmpty) const TextSpan(text: ' '),
          ], style: TextStyle(fontSize: font)),
          textAlign: align,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: !dirty,
        onPopInvokedWithResult: (did, _) async {
          if (did) return;
          if (await confirm(context, '${L.t('saveAsDocx')}?') && mounted) {
            await _saveDocx();
          } else if (mounted) {
            Navigator.pop(context);
          }
        },
        child: Scaffold(
          appBar: AppBar(
            title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)),
            actions: [
              IconButton(icon: const Icon(Icons.text_decrease_rounded), onPressed: () => setState(() => font = (font - 1).clamp(10, 36))),
              IconButton(icon: const Icon(Icons.text_increase_rounded), onPressed: () => setState(() => font = (font + 1).clamp(10, 36))),
              if (paras != null)
                IconButton(
                  icon: Icon(edit ? Icons.visibility_rounded : Icons.edit_rounded),
                  tooltip: edit ? L.t('formatted') : L.t('editPlain'),
                  onPressed: () async {
                    if (!edit && !await confirm(context, L.t('editPlainWarn'))) return;
                    setState(() => edit = !edit);
                  },
                ),
              IconButton(icon: const Icon(Icons.open_in_new_rounded), tooltip: L.t('openWith'), onPressed: () => OpenFilex.open(widget.path)),
              IconButton(icon: Icon(Icons.save_rounded, color: dirty ? Colors.amber : null), tooltip: L.t('saveAsDocx'), onPressed: loading ? null : _saveDocx),
            ],
          ),
          body: loading
              ? const Center(child: CircularProgressIndicator())
              : Column(children: [
                  Container(
                    width: double.infinity,
                    color: Colors.amber.withOpacity(.15),
                    padding: const EdgeInsets.all(8),
                    child: Text(L.t('legacyDocNote'), style: const TextStyle(fontSize: 12)),
                  ),
                  Expanded(
                    child: !edit && paras != null
                        ? ListView.builder(
                            padding: const EdgeInsets.all(14),
                            itemCount: paras!.length,
                            itemBuilder: (_, i) => _paraView(paras![i]),
                          )
                        : TextField(
                      controller: ctl,
                      maxLines: null,
                      expands: true,
                      textDirection: _dir,
                      textAlignVertical: TextAlignVertical.top,
                      style: TextStyle(fontSize: font),
                      onChanged: (_) { if (!dirty) setState(() => dirty = true); },
                      decoration: const InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.all(12)),
                    ),
                  ),
                ]),
        ),
      );
}
