import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../widgets/adaptive_nav.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';
import '../core/l10n.dart';
import '../services/transfer_service.dart';
import '../widgets/ui.dart';
import 'nearby_screen.dart';
import 'remote_screen.dart';

class TransferScreen extends StatelessWidget {
  const TransferScreen({super.key});

  Future<List<String>> _pick() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true);
    return r?.paths.whereType<String>().toList() ?? [];
  }

  /// Lets the user choose between files and a whole folder.
  Future<List<String>> _pickAny(BuildContext context) async {
    final a = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.insert_drive_file_rounded), title: Text(L.t('sendFilesOpt')), onTap: () => Navigator.pop(context, 'f')),
          ListTile(leading: const Icon(Icons.folder_rounded), title: Text(L.t('sendFolderOpt')), onTap: () => Navigator.pop(context, 'd')),
        ]),
      ),
    );
    if (a == 'f') return _pick();
    if (a == 'd') {
      final d = await FilePicker.platform.getDirectoryPath();
      return d == null ? [] : [d];
    }
    return [];
  }

  /// Sends [files]; asks for the receiver's PIN when needed.
  Future<void> _send(BuildContext context, TransferService t, String ip, int port, List<String> files) async {
    String? pin;
    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        await t.sendTo(ip, port, files, pin: pin);
        if (context.mounted) snack(context, L.t('done'));
        return;
      } on NeedPin {
        if (!context.mounted) return;
        pin = await promptText(context, L.t('enterPin'));
        if (pin == null || pin.isEmpty) return;
      } catch (e) {
        if (context.mounted) snack(context, '$e');
        return;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final t = context.watch<TransferService>();
    return Scaffold(
      appBar: AppBar(title: Text(L.t('network'))),
      body: MaxWidth(child: ListView(padding: const EdgeInsets.all(16), children: [
        GradCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              const Icon(Icons.wifi_tethering_rounded),
              const SizedBox(width: 10),
              Expanded(child: Text(L.t('lanServer'), style: const TextStyle(fontWeight: FontWeight.bold))),
              Switch(value: t.running, onChanged: (v) => v ? t.start() : t.stop()),
            ]),
            if (t.url != null) ...[
              const SizedBox(height: 6),
              SelectableText(t.url!, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const Text('Open this address in any browser on the same Wi-Fi to upload/download files.', style: TextStyle(fontSize: 12)),
              const SizedBox(height: 10),
              Center(child: Container(color: Colors.white, padding: const EdgeInsets.all(8), child: QrImageView(data: t.qrData ?? t.url!, size: 170, backgroundColor: Colors.white))),
              const SizedBox(height: 4),
              Text(L.t('qrHint'), style: const TextStyle(fontSize: 11)),
              if (t.requirePin) Row(children: [
                Text('${L.t('yourPin')}: ', style: const TextStyle(fontSize: 14)),
                SelectableText(t.pin, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 4)),
                const Spacer(),
                TextButton(onPressed: t.newPin, child: Text(L.t('newPin'))),
              ]),
            ],
          ]),
        ),
        for (final a in List.of(t.pending))
          Card(
            color: Colors.amber.withOpacity(.18),
            child: ListTile(
              leading: const Icon(Icons.download_rounded),
              title: Text(a.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text('${a.ip} • ${L.t('incoming')}'),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                IconButton(icon: const Icon(Icons.close_rounded, color: Colors.redAccent), tooltip: L.t('reject'), onPressed: () => t.decide(a, false)),
                IconButton(icon: const Icon(Icons.check_rounded, color: Colors.greenAccent), tooltip: L.t('accept'), onPressed: () => t.decide(a, true)),
              ]),
            ),
          ),
        SwitchListTile(dense: true, title: Text(L.t('useHttps')), subtitle: Text(t.running ? (t.secure ? 'HTTPS ✓' : 'HTTP') : L.t('httpsHint'), style: const TextStyle(fontSize: 11)), value: t.useHttps, onChanged: t.setUseHttps),
        SwitchListTile(dense: true, title: Text(L.t('pinRequired')), value: t.requirePin, onChanged: t.setRequirePin),
        SwitchListTile(dense: true, title: Text(L.t('askIncoming')), value: t.requireApproval, onChanged: t.setRequireApproval),
        ListTile(
          dense: true,
          leading: const Icon(Icons.folder_rounded),
          title: Text(L.t('receiveFolder')),
          subtitle: Text(t.receiveDir, style: const TextStyle(fontSize: 11)),
          onTap: () async {
            final d = await FilePicker.platform.getDirectoryPath();
            if (d != null) t.setReceiveDir(d);
          },
        ),
        const SizedBox(height: 12),
        if (t.progress != null) ...[
          Text(t.status ?? ''),
          LinearProgressIndicator(value: t.progress),
          const SizedBox(height: 12),
        ],
        Row(children: [
          Expanded(
            child: FilledButton.icon(
              icon: const Icon(Icons.share_rounded),
              label: const Text('Share for download'),
              onPressed: () async {
                if (!t.running) { snack(context, L.t('startServerFirst')); return; }
                t.share(await _pick());
              },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: OutlinedButton.icon(
              icon: const Icon(Icons.folder_shared_rounded),
              label: Text(L.t('shareFolder')),
              onPressed: () async {
                if (!t.running) { snack(context, L.t('startServerFirst')); return; }
                final d = await FilePicker.platform.getDirectoryPath();
                if (d != null) t.share([d]);
              },
            ),
          ),
        ]),
        for (final e in t.shared.entries)
          ListTile(dense: true, leading: Icon(Directory(e.value).existsSync() ? Icons.folder_rounded : Icons.insert_drive_file_rounded), title: Text(e.key), trailing: IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => t.unshare(e.key))),
        const SizedBox(height: 12),
        Text(L.t('nearby'), style: const TextStyle(fontWeight: FontWeight.bold)),
        if (t.peers.isEmpty) const Padding(padding: EdgeInsets.all(12), child: Text('—')),
        for (final p in t.peers.values)
          ListTile(
            leading: const Icon(Icons.phone_android_rounded),
            title: Text(p.name),
            subtitle: Text(p.ip),
            trailing: const Icon(Icons.send_rounded),
            onTap: () async {
              final files = await _pickAny(context);
              if (files.isEmpty || !context.mounted) return;
              await _send(context, t, p.ip, p.port, files);
            },
          ),
        ListTile(
          leading: const Icon(Icons.dns_rounded),
          title: Text(L.t('manualIp')),
          onTap: () async {
            final ip = await promptText(context, L.t('manualIp'));
            if (ip == null || ip.isEmpty) return;
            if (!context.mounted) return;
            final files = await _pickAny(context);
            if (files.isEmpty || !context.mounted) return;
            await _send(context, t, ip, TransferService.port, files);
          },
        ),
        const Divider(),
        ListTile(leading: const Icon(Icons.cloud_rounded), title: Text(L.t('remote')), subtitle: const Text('FTP • SFTP • SMB • WebDAV • Dropbox • Google Drive', style: TextStyle(fontSize: 11)), trailing: const Icon(Icons.chevron_right_rounded, matchTextDirection: true), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RemoteScreen()))),
        ListTile(leading: const Icon(Icons.bluetooth_searching_rounded), title: Text(L.t('nearbyTitle')), subtitle: Text('${L.t('bluetooth')} • ${L.t('wifiDirect')}', style: const TextStyle(fontSize: 11)), trailing: const Icon(Icons.chevron_right_rounded, matchTextDirection: true), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NearbyScreen()))),
        const Divider(),
        Text(L.t('received'), style: const TextStyle(fontWeight: FontWeight.bold)),
        for (final l in t.log.take(30)) Text(l, style: const TextStyle(fontSize: 12)),
      ])),
    );
  }
}
