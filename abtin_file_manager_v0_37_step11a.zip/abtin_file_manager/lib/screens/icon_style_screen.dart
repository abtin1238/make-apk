import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/icon_prefs.dart';
import '../core/l10n.dart';
import '../core/settings.dart';

/// Settings -> icon style: colour and shape of the folder icon and of every file-type icon.
class IconStyleScreen extends StatelessWidget {
  const IconStyleScreen({super.key});

  String _label(String k) => L.t('icon_$k');

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return Scaffold(
      appBar: AppBar(title: Text(L.t('iconStyle')), actions: [
        IconButton(icon: const Icon(Icons.restart_alt_rounded), tooltip: L.t('resetIcons'), onPressed: s.resetIcons),
      ]),
      body: ListView(children: [
        for (final k in IconPrefs.keys)
          ListTile(
            leading: Icon(IconPrefs.icon(k), color: IconPrefs.color(k), size: 38),
            title: Text(_label(k)),
            trailing: const Icon(Icons.chevron_right_rounded, matchTextDirection: true),
            onTap: () => showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              builder: (_) => _Sheet(k: k, title: _label(k)),
            ),
          ),
      ]),
    );
  }
}

class _Sheet extends StatelessWidget {
  final String k, title;
  const _Sheet({required this.k, required this.title});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final cur = IconPrefs.color(k);
    final shapes = IconPrefs.options[k]!;
    final sel = IconPrefs.shapes[k] ?? 0;
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            Icon(IconPrefs.icon(k), color: cur, size: 44),
            const SizedBox(width: 12),
            Expanded(child: Text(title, style: Theme.of(context).textTheme.titleMedium)),
            TextButton(onPressed: () { s.setIconColor(k, null); s.setIconShape(k, null); }, child: Text(L.t('resetIcons'))),
          ]),
          const SizedBox(height: 14),
          Text(L.t('iconColor')),
          const SizedBox(height: 8),
          Wrap(spacing: 10, runSpacing: 10, children: [
            for (final c in IconPrefs.palette)
              GestureDetector(
                onTap: () => s.setIconColor(k, c),
                child: Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: Color(c),
                    shape: BoxShape.circle,
                    border: Border.all(color: cur.value == c ? Theme.of(context).colorScheme.primary : Colors.black26, width: cur.value == c ? 3 : 1),
                  ),
                ),
              ),
          ]),
          const SizedBox(height: 18),
          Text(L.t('iconShape')),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (var i = 0; i < shapes.length; i++)
              InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => s.setIconShape(k, i),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: sel == i ? Theme.of(context).colorScheme.primary : Colors.black26, width: sel == i ? 2.5 : 1),
                  ),
                  child: Icon(shapes[i], color: cur, size: 34),
                ),
              ),
          ]),
        ]),
      ),
    );
  }
}
