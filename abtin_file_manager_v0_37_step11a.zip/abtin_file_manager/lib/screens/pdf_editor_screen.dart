import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:path/path.dart' as p;
import 'package:pdfx/pdfx.dart';
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../services/pdf_native.dart';
import '../widgets/ui.dart';
import 'pdf_viewer_screen.dart';

enum _Tool { scroll, pen, highlight, text, edit }

class _Stroke {
  final List<Offset> pts; // normalised 0..1 (x by width, y by height)
  final Color color;
  final double w; // fraction of page width
  final double alpha;
  _Stroke(this.pts, this.color, this.w, this.alpha);
}

class _Txt {
  final Offset pos; // normalised
  final String t;
  final Color color;
  final double size; // fraction of page width
  _Txt(this.pos, this.t, this.color, this.size);
}

/// Replacement of an existing text line: the old line is covered with white and the new text is placed on top.
class _Rep {
  final Rect box; // normalised l, t, w, h
  final String t;
  final double size; // fraction of page width
  final Color color; // colour of the original text
  final _Fnt font; // family / weight of the original text
  _Rep(this.box, this.t, this.size, this.color, this.font);
}

/// Approximation of the original font: PDF standard family (h = Helvetica, t = Times, c = Courier) + weight / slant.
class _Fnt {
  final String fam;
  final bool bold, italic;
  final String? name; // BaseFont of the original (embedded) font, reused on save when it can encode the new text
  const _Fnt([this.fam = 'h', this.bold = false, this.italic = false, this.name]);
  String? get flutterFamily => fam == 't' ? 'serif' : fam == 'c' ? 'monospace' : null;
}

class _Pg {
  final int orig; // 1-based page number in the source PDF
  final Uint8List png;
  final int w, h;
  final double ptW, ptH;
  final items = <Object>[]; // _Stroke | _Txt | _Rep, in draw order
  List<Map<String, dynamic>>? boxes; // text lines (loaded for the "edit text" tool)
  _Pg(this.orig, this.png, this.w, this.h, this.ptW, this.ptH);
}

bool _isRtl(String t) => RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(t);

/// true when the text can be written as real PDF text (Helvetica / WinAnsi).
bool _latin(String t) => t.runes.every((r) => r == 10 || (r >= 0x20 && r <= 0x7E) || (r >= 0xA0 && r <= 0xFF));

TextPainter _tp(String t, Color c, double fs, double maxW, [_Fnt f = const _Fnt()]) => TextPainter(
      text: TextSpan(
          text: t,
          style: TextStyle(
              color: c,
              fontSize: fs,
              fontFamily: f.flutterFamily,
              fontWeight: f.bold ? FontWeight.bold : FontWeight.normal,
              fontStyle: f.italic ? FontStyle.italic : FontStyle.normal)),
      textDirection: _isRtl(t) ? TextDirection.rtl : TextDirection.ltr,
      textWidthBasis: TextWidthBasis.longestLine,
    )..layout(maxWidth: maxW.clamp(20, 100000).toDouble());

void _paintItems(Canvas c, Size s, List<Object> items) {
  for (final it in items) {
    if (it is _Stroke) {
      final paint = Paint()
        ..color = it.color.withOpacity(it.alpha)
        ..strokeWidth = it.w * s.width
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round;
      if (it.pts.length == 1) {
        c.drawCircle(Offset(it.pts[0].dx * s.width, it.pts[0].dy * s.height), it.w * s.width / 2, paint..style = PaintingStyle.fill);
      } else {
        final path = Path()..moveTo(it.pts[0].dx * s.width, it.pts[0].dy * s.height);
        for (final q in it.pts.skip(1)) {
          path.lineTo(q.dx * s.width, q.dy * s.height);
        }
        c.drawPath(path, paint);
      }
    } else if (it is _Txt) {
      final x = it.pos.dx * s.width;
      _tp(it.t, it.color, it.size * s.width, s.width - x).paint(c, Offset(x, it.pos.dy * s.height));
    } else if (it is _Rep) {
      final r = Rect.fromLTWH(it.box.left * s.width, it.box.top * s.height, it.box.width * s.width, it.box.height * s.height).inflate(1);
      c.drawRect(r, Paint()..color = Colors.white);
      _tp(it.t, it.color, it.size * s.width, s.width - r.left, it.font).paint(c, Offset(it.box.left * s.width, it.box.top * s.height));
    }
  }
}

class _Painter extends CustomPainter {
  final List<Object> items;
  final int rev;
  _Painter(this.items, this.rev);
  @override
  void paint(Canvas canvas, Size size) => _paintItems(canvas, size, items);
  @override
  bool shouldRepaint(covariant _Painter o) => o.rev != rev || o.items != items;
}

/// PDF editor: draw, highlight, add text, replace existing text lines, delete / reorder pages.
/// Pages are only rasterised for the on-screen preview. Saving writes the edits as vector content into the
/// real PDF (PdfBox), so the original text stays selectable and searchable.
class PdfEditorScreen extends StatefulWidget {
  final String path;
  /// set when [path] is a decrypted temp copy: results are named after / saved next to this file
  final String? origPath;
  const PdfEditorScreen({super.key, required this.path, this.origPath});
  @override
  State<PdfEditorScreen> createState() => _PdfEditorScreenState();
}

class _PdfEditorScreenState extends State<PdfEditorScreen> {
  final pages = <_Pg>[];
  bool loading = true, dirty = false;
  int total = 0;
  _Tool tool = _Tool.scroll;
  Color color = const Color(0xFFE53935);
  int sizeIdx = 1;
  bool asAnnot = true; // pen / highlighter / added text are saved as real Ink / FreeText annotations
  int rev = 0;
  _Stroke? live;
  _Pg? livePg;
  // pinch-zoom (two fingers anywhere on the pages)
  double zoom = 1;
  bool pinching = false;
  final _ptrs = <int, Offset>{};
  double _z0 = 1, _d0 = 0;

  double _dist() {
    final v = _ptrs.values.toList();
    return (v[0] - v[1]).distance;
  }

  void _ptrDown(PointerDownEvent e) {
    _ptrs[e.pointer] = e.position;
    if (_ptrs.length == 2) {
      _z0 = zoom;
      _d0 = _dist();
      setState(() => pinching = true);
    }
  }

  void _ptrMove(PointerMoveEvent e) {
    if (!_ptrs.containsKey(e.pointer)) return;
    _ptrs[e.pointer] = e.position;
    if (_ptrs.length == 2 && _d0 > 0) {
      final z = (_z0 * _dist() / _d0).clamp(1.0, 4.0).toDouble();
      if ((z - zoom).abs() > 0.01) setState(() => zoom = z);
    }
  }

  void _ptrUp(PointerEvent e) {
    _ptrs.remove(e.pointer);
    if (_ptrs.length < 2 && pinching) setState(() => pinching = false);
  }

  static const _colors = [Color(0xFFE53935), Color(0xFF1E88E5), Color(0xFF43A047), Color(0xFF000000), Color(0xFFFDD835), Color(0xFF8E24AA)];
  static const _pen = [0.003, 0.006, 0.012];
  static const _hl = [0.015, 0.025, 0.04];
  static const _txt = [0.02, 0.03, 0.045];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await PdfDocument.openFile(widget.path);
      total = d.pagesCount;
      for (var i = 1; i <= d.pagesCount; i++) {
        final pg = await d.getPage(i);
        final scale = (1400 / pg.width).clamp(1.0, 2.0).toDouble();
        final r = await pg.render(width: pg.width * scale, height: pg.height * scale, format: PdfPageImageFormat.png, backgroundColor: '#FFFFFF');
        final w = pg.width, h = pg.height;
        await pg.close();
        if (r == null) continue;
        pages.add(_Pg(i, r.bytes, r.width ?? (w * scale).round(), r.height ?? (h * scale).round(), w, h));
        if (mounted && i % 2 == 0) setState(() {});
        if (!mounted) return;
      }
      await d.close();
      if (mounted) setState(() => loading = false);
    } catch (e) {
      if (mounted) {
        snack(context, '${L.t('error')}: $e');
        Navigator.pop(context);
      }
    }
  }

  // ---------- drawing ----------
  void _down(_Pg pg, Offset n) {
    if (tool == _Tool.pen || tool == _Tool.highlight) {
      final hl = tool == _Tool.highlight;
      live = _Stroke([n], color, (hl ? _hl : _pen)[sizeIdx], hl ? 0.35 : 1);
      livePg = pg;
      pg.items.add(live!);
      setState(() { rev++; dirty = true; });
    }
  }

  void _move(_Pg pg, Offset n) {
    if (live != null && identical(livePg, pg)) {
      live!.pts.add(n);
      setState(() => rev++);
    }
  }

  void _up() {
    live = null;
    livePg = null;
  }

  Future<void> _tapText(_Pg pg, Offset n) async {
    if (tool != _Tool.text) return;
    final t = await promptText(context, L.t('addText'));
    if (t == null || t.isEmpty) return;
    setState(() {
      pg.items.add(_Txt(n, t, color, _txt[sizeIdx]));
      rev++;
      dirty = true;
    });
  }

  Future<void> _ensureBoxes(_Pg pg) async {
    if (pg.boxes != null) return;
    try {
      pg.boxes = await PdfNative.boxes(widget.path, pg.orig);
    } catch (_) {
      pg.boxes = [];
    }
    if (mounted) setState(() {});
  }

  Future<void> _tapEdit(_Pg pg, Offset n) async {
    await _ensureBoxes(pg);
    Map<String, dynamic>? hit;
    var best = double.infinity;
    for (final b in pg.boxes ?? const <Map<String, dynamic>>[]) {
      final r = Rect.fromLTWH((b['x'] as num).toDouble(), (b['y'] as num).toDouble(), (b['w'] as num).toDouble(), (b['h'] as num).toDouble()).inflate(0.004);
      if (r.contains(n) && r.width * r.height < best) {
        best = r.width * r.height;
        hit = b;
      }
    }
    if (hit == null) {
      snack(context, L.t('noTextHere'));
      return;
    }
    final old = '${hit['text']}';
    final t = await promptText(context, L.t('editText'), initial: old);
    if (t == null || t == old || !mounted) return;
    final box = Rect.fromLTWH((hit['x'] as num).toDouble(), (hit['y'] as num).toDouble(), (hit['w'] as num).toDouble(), (hit['h'] as num).toDouble());
    final size = (hit['pt'] as num).toDouble() * 0.92 / pg.ptW;
    final col = Color(0xFF000000 | ((hit['col'] as num?)?.toInt() ?? 0));
    final fn = '${hit['fn'] ?? ''}';
    final fnt = _Fnt('${hit['fam'] ?? 'h'}', hit['bold'] == true, hit['it'] == true, fn.isEmpty ? null : fn);
    setState(() {
      pg.items.add(_Rep(box, t, size, col, fnt));
      rev++;
      dirty = true;
    });
  }

  void _setTool(_Tool t) {
    setState(() => tool = t);
    if (t == _Tool.edit) {
      () async {
        for (final pg in List.of(pages)) {
          if (!mounted || tool != _Tool.edit) return;
          await _ensureBoxes(pg);
        }
      }();
    }
  }

  void _undo() {
    for (final pg in pages.reversed) {
      if (pg.items.isNotEmpty) {
        setState(() { pg.items.removeLast(); rev++; });
        return;
      }
    }
  }

  // ---------- save ----------
  Map<String, dynamic> _rgb(Color c) => {'r': (c.value >> 16) & 255, 'g': (c.value >> 8) & 255, 'b': c.value & 255};

  /// Text as a transparent PNG (used for Persian / non-Latin text, which PdfBox can not shape itself).
  Future<Map<String, dynamic>> _imgOp(_Pg pg, Offset pos, String t, Color c, double size, [_Fnt f = const _Fnt()]) async {
    final tp = _tp(t, c, size * pg.w, pg.w - pos.dx * pg.w, f);
    const sc = 3.0;
    final rec = ui.PictureRecorder();
    final cv = Canvas(rec)..scale(sc);
    tp.paint(cv, Offset.zero);
    final im = await rec.endRecording().toImage((tp.width * sc).ceil().clamp(1, 8000), (tp.height * sc).ceil().clamp(1, 8000));
    final bd = await im.toByteData(format: ui.ImageByteFormat.png);
    return {'k': 'i', 'x': pos.dx, 'y': pos.dy, 'w': tp.width / pg.w, 'h': tp.height / pg.h, 'png': bd!.buffer.asUint8List()};
  }

  Future<Map<String, dynamic>> _textOp(_Pg pg, Offset pos, String t, Color c, double size, [_Fnt f = const _Fnt()]) async {
    if (_latin(t)) {
      final tp = _tp(t, c, size * pg.w, pg.w - pos.dx * pg.w, f);
      // real text only when nothing wrapped (PdfBox does not wrap)
      if (tp.computeLineMetrics().length == t.split('\n').length) {
        return {'k': 't', 'x': pos.dx, 'y': pos.dy, 'text': t, 'size': size, 'fam': f.fam, 'b': f.bold, 'i': f.italic, if (f.name != null) 'fn': f.name, ..._rgb(c)};
      }
    }
    return _imgOp(pg, pos, t, c, size, f);
  }

  Future<List<Map<String, dynamic>>> _itemOps(_Pg pg) async {
    final out = <Map<String, dynamic>>[];
    for (final it in pg.items) {
      if (it is _Stroke) {
        out.add({'k': 's', 'p': [for (final q in it.pts) ...[q.dx, q.dy]], 'w': it.w, 'a': it.alpha, if (asAnnot) 'ink': true, ..._rgb(it.color)});
      } else if (it is _Txt) {
        final o = await _textOp(pg, it.pos, it.t, it.color, it.size);
        if (asAnnot) {
          o['k'] = o['k'] == 't' ? 'ft' : 'fti'; // real FreeText annotation (Contents = the text)
          o['text'] = it.t;
        }
        out.add(o);
      } else if (it is _Rep) {
        // rm: also delete the old glyphs from the content stream (not only cover them)
        out.add({'k': 'r', 'rm': true, 'x': it.box.left, 'y': it.box.top, 'w': it.box.width, 'h': it.box.height});
        if (it.t.trim().isNotEmpty) out.add(await _textOp(pg, it.box.topLeft, it.t, it.color, it.size, it.font));
      }
    }
    return out;
  }

  /// Returns the path of the saved file (null when cancelled / failed).
  Future<String?> _save({required bool overwrite}) async {
    if (pages.isEmpty) return null;
    if (overwrite && !await confirm(context, L.t('overwriteWarn'))) return null;
    if (!await ensureSdAll(context, [widget.path, widget.origPath ?? widget.path])) return null;
    if (!mounted) return null;
    String? target;
    var removed = 0;
    final hasRep = pages.any((pg) => pg.items.any((e) => e is _Rep));
    final named = widget.origPath ?? widget.path;
    final ok = await busy(context, () async {
      final ops = <Map<String, dynamic>>[];
      for (final pg in pages) {
        if (pg.items.isNotEmpty) ops.add({'page': pg.orig, 'items': await _itemOps(pg)});
      }
      final dir = p.dirname(named);
      target = overwrite ? widget.path : FileOps.unique(dir, '${p.basenameWithoutExtension(named)} (edited).pdf');
      final viaSaf = await Saf.use(target!); // PdfNative handles the temp copy itself on SAF cards
      final tmp = overwrite && !viaSaf ? p.join(dir, '.${p.basename(widget.path)}.abtin.tmp') : target!;
      removed = await PdfNative.edit(widget.path, tmp, [for (final pg in pages) pg.orig], ops);
      if (overwrite && !viaSaf) await File(tmp).rename(widget.path);
    });
    if (!ok || target == null) return null;
    if (hasRep && removed == 0 && mounted) snack(context, L.t('oldTextKept'));
    Native.scan(target!);
    return target;
  }

  Future<void> _saveAndOpen({required bool overwrite}) async {
    final out = await _save(overwrite: overwrite);
    if (out == null || !mounted) return;
    setState(() => dirty = false);
    snack(context, '${L.t('done')}: ${p.basename(out)}');
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => PdfViewerScreen(path: out)));
  }

  // ---------- UI ----------
  Widget _pageW(int i) {
    final pg = pages[i];
    return Column(children: [
      Row(children: [
        const SizedBox(width: 12),
        Text('${i + 1} / ${pages.length}', style: const TextStyle(fontSize: 12)),
        const Spacer(),
        IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.arrow_upward_rounded, size: 18), onPressed: i == 0 ? null : () => setState(() { pages.insert(i - 1, pages.removeAt(i)); dirty = true; })),
        IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.arrow_downward_rounded, size: 18), onPressed: i == pages.length - 1 ? null : () => setState(() { pages.insert(i + 1, pages.removeAt(i)); dirty = true; })),
        IconButton(
          visualDensity: VisualDensity.compact,
          icon: const Icon(Icons.delete_outline_rounded, size: 18),
          tooltip: L.t('deletePage'),
          onPressed: pages.length <= 1 ? null : () async {
            if (await confirm(context, '${L.t('deletePage')} ${i + 1}?')) setState(() { pages.removeAt(i); dirty = true; });
          },
        ),
      ]),
      LayoutBuilder(builder: (c, cons) {
        final w = cons.maxWidth, h = w * pg.h / pg.w;
        Offset norm(Offset o) => Offset((o.dx / w).clamp(0, 1).toDouble(), (o.dy / h).clamp(0, 1).toDouble());
        final drawing = tool == _Tool.pen || tool == _Tool.highlight;
        return Container(
          margin: const EdgeInsets.only(bottom: 14),
          decoration: BoxDecoration(boxShadow: [BoxShadow(color: Colors.black.withOpacity(.25), blurRadius: 6)]),
          child: SizedBox(
            width: w,
            height: h,
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onPanStart: drawing ? (d) => _down(pg, norm(d.localPosition)) : null,
              onPanUpdate: drawing ? (d) => _move(pg, norm(d.localPosition)) : null,
              onPanEnd: drawing ? (_) => _up() : null,
              onPanCancel: drawing ? _up : null,
              onTapUp: tool == _Tool.text ? (d) => _tapText(pg, norm(d.localPosition)) : tool == _Tool.edit ? (d) => _tapEdit(pg, norm(d.localPosition)) : null,
              child: Stack(fit: StackFit.expand, children: [
                Image.memory(pg.png, fit: BoxFit.fill, gaplessPlayback: true),
                CustomPaint(painter: _Painter(pg.items, rev)),
                if (tool == _Tool.edit && pg.boxes != null) CustomPaint(painter: _BoxPainter(pg.boxes!)),
              ]),
            ),
          ),
        );
      }),
    ]);
  }

  Widget _toolbar() {
    final cs = Theme.of(context).colorScheme;
    Widget tb(IconData ic, _Tool t, String tip) => IconButton(tooltip: tip, icon: Icon(ic, color: tool == t ? cs.primary : null), onPressed: () => _setTool(t));
    return Material(
      elevation: 1,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: [
          tb(Icons.pan_tool_alt_rounded, _Tool.scroll, L.t('scroll')),
          tb(Icons.edit_rounded, _Tool.pen, L.t('pen')),
          tb(Icons.border_color_rounded, _Tool.highlight, L.t('highlight')),
          tb(Icons.text_fields_rounded, _Tool.text, L.t('addText')),
          tb(Icons.edit_note_rounded, _Tool.edit, L.t('editText')),
          const SizedBox(height: 28, child: VerticalDivider()),
          PopupMenuButton<Color>(
            icon: Icon(Icons.circle, color: color),
            onSelected: (c) => setState(() => color = c),
            itemBuilder: (_) => [for (final c in _colors) PopupMenuItem(value: c, child: Icon(Icons.circle, color: c))],
          ),
          PopupMenuButton<int>(
            icon: const Icon(Icons.line_weight_rounded),
            onSelected: (i) => setState(() => sizeIdx = i),
            itemBuilder: (_) => [for (var i = 0; i < 3; i++) PopupMenuItem(value: i, child: Text(['S', 'M', 'L'][i] + (sizeIdx == i ? '  ✓' : '')))],
          ),
          IconButton(
            tooltip: L.t('asAnnot'),
            icon: Icon(Icons.layers_rounded, color: asAnnot ? cs.primary : null),
            onPressed: () {
              setState(() => asAnnot = !asAnnot);
              snack(context, L.t(asAnnot ? 'annOn' : 'annOff'));
            },
          ),
          IconButton(tooltip: L.t('undo'), icon: const Icon(Icons.undo_rounded), onPressed: _undo),
          if (zoom > 1.01) IconButton(tooltip: L.t('resetZoom'), icon: const Icon(Icons.zoom_out_map_rounded), onPressed: () => setState(() => zoom = 1)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: !dirty,
        onPopInvokedWithResult: (did, _) async {
          if (did) return;
          if (await confirm(context, '${L.t('save')}?') && mounted) await _save(overwrite: false);
          if (mounted) Navigator.pop(context);
        },
        child: Scaffold(
          appBar: AppBar(
            title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)),
            actions: [
              PopupMenuButton<int>(
                onSelected: (v) => _saveAndOpen(overwrite: v == 1),
                itemBuilder: (_) => [
                  PopupMenuItem(value: 0, child: Text(L.t('saveCopy'))),
                  if (widget.origPath == null) PopupMenuItem(value: 1, child: Text(L.t('overwrite'))),
                ],
                icon: Icon(Icons.save_rounded, color: dirty ? Colors.amber : null),
              ),
            ],
          ),
          body: Column(children: [
            _toolbar(),
            if (loading) LinearProgressIndicator(value: total == 0 ? null : pages.length / total),
            Expanded(
              child: Listener(
                onPointerDown: _ptrDown,
                onPointerMove: _ptrMove,
                onPointerUp: _ptrUp,
                onPointerCancel: _ptrUp,
                child: LayoutBuilder(builder: (c, cons) {
                  final list = ListView.builder(
                    physics: tool == _Tool.scroll && !pinching ? null : const NeverScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(8),
                    itemCount: pages.length,
                    itemBuilder: (c, i) => _pageW(i),
                  );
                  if (zoom <= 1.01) return list;
                  return SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    physics: pinching ? const NeverScrollableScrollPhysics() : null,
                    child: SizedBox(width: cons.maxWidth * zoom, height: cons.maxHeight, child: list),
                  );
                }),
              ),
            ),
          ]),
        ),
      );
}

class _BoxPainter extends CustomPainter {
  final List<Map<String, dynamic>> boxes;
  _BoxPainter(this.boxes);
  @override
  void paint(Canvas c, Size s) {
    final paint = Paint()
      ..color = const Color(0xAA2F6BFF)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    for (final b in boxes) {
      c.drawRect(
        Rect.fromLTWH((b['x'] as num) * s.width, (b['y'] as num) * s.height, (b['w'] as num) * s.width, (b['h'] as num) * s.height).inflate(1),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _BoxPainter o) => o.boxes != boxes;
}
