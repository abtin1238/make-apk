import 'package:flutter/services.dart';

/// Bridge to SecurityNative.kt (fingerprint prompt, FLAG_SECURE, vault crypto).
class Sec {
  static const _c = MethodChannel('abtin/sec');

  /// 0 = unavailable, 1 = ready, 2 = hardware present but no fingerprint enrolled.
  static Future<int> bioStatus() async {
    try {
      return (await _c.invokeMethod<int>('bioStatus')) ?? 0;
    } catch (_) {
      return 0;
    }
  }

  static Future<bool> bioAuth(String title, String cancel) async {
    try {
      return (await _c.invokeMethod<bool>('bioAuth', {'title': title, 'cancel': cancel})) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> bioCancel() async {
    try { await _c.invokeMethod('bioCancel'); } catch (_) {}
  }

  static Future<void> setSecure(bool on) async {
    try { await _c.invokeMethod('setSecure', {'on': on}); } catch (_) {}
  }

  static Future<String> pbkdf2(String pw, String saltB64, int iter) async =>
      (await _c.invokeMethod<String>('pbkdf2', {'pw': pw, 'salt': saltB64, 'iter': iter}))!;

  static Future<void> vaultCreate(String dir, String pw) => _c.invokeMethod('vaultCreate', {'dir': dir, 'pw': pw});
  static Future<bool> vaultUnlock(String dir, String pw) async => (await _c.invokeMethod<bool>('vaultUnlock', {'dir': dir, 'pw': pw})) ?? false;
  static Future<void> vaultLock() async {
    try { await _c.invokeMethod('vaultLock'); } catch (_) {}
  }
  static Future<bool> vaultChangePw(String dir, String oldPw, String newPw) async =>
      (await _c.invokeMethod<bool>('vaultChangePw', {'dir': dir, 'old': oldPw, 'new': newPw})) ?? false;
  static Future<void> vaultEncrypt(String src, String dst) => _c.invokeMethod('vaultEncrypt', {'src': src, 'dst': dst});
  static Future<void> vaultDecrypt(String src, String dst) => _c.invokeMethod('vaultDecrypt', {'src': src, 'dst': dst});
  static Future<String?> vaultReadIndex(String path) => _c.invokeMethod<String>('vaultReadIndex', {'path': path});
  static Future<void> vaultWriteIndex(String path, String json) => _c.invokeMethod('vaultWriteIndex', {'path': path, 'json': json});
}
