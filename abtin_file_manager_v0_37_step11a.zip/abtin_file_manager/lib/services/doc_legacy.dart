import 'dart:convert';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'ole.dart';

/// Minimal reader for legacy Word 97-2003 (.doc, OLE2/CFB) files: extracts the
/// main-document text via the FIB + piece table (CLX). Formatting is not kept.
class DocLegacy {
  static const _free = 0xFFFFFFFF, _endOfChain = 0xFFFFFFFE;

  /// Returns plain text (paragraphs separated by \n). Throws on unsupported files.
  static String extractText(Uint8List b) {
    final ole = Ole.parse(b);
    Uint8List stream(String n) => ole.stream(n);

    final wd = stream('WordDocument');
    final w = ByteData.sublistView(wd);
    if (w.getUint16(0, Endian.little) != 0xA5EC) throw Exception('Not a Word binary document');
    final flags = w.getUint16(0x0A, Endian.little);
    if (flags & 0x0100 != 0) throw Exception('Encrypted .doc is not supported');
    final tbl = stream((flags & 0x0200) != 0 ? '1Table' : '0Table');
    final ccpText = w.getUint32(0x4C, Endian.little);
    final fcClx = w.getUint32(0x1A2, Endian.little);
    final lcbClx = w.getUint32(0x1A6, Endian.little);
    final t = ByteData.sublistView(tbl);
    var pos = fcClx;
    final end = fcClx + lcbClx;
    while (pos < end && tbl[pos] == 1) {
      pos += 3 + t.getUint16(pos + 1, Endian.little); // skip Prc
    }
    if (pos >= end || tbl[pos] != 2) throw Exception('Piece table not found');
    final lcb = t.getUint32(pos + 1, Endian.little);
    pos += 5;
    final n = (lcb - 4) ~/ 12;
    final cps = [for (var i = 0; i <= n; i++) t.getUint32(pos + i * 4, Endian.little)];
    final pcd = pos + (n + 1) * 4;
    final sb = StringBuffer();
    for (var i = 0; i < n; i++) {
      var cnt = cps[i + 1] - cps[i];
      if (cps[i] >= ccpText) break;
      if (cps[i] + cnt > ccpText) cnt = ccpText - cps[i];
      final fc = t.getUint32(pcd + i * 8 + 2, Endian.little);
      if (fc & 0x40000000 != 0) {
        final o = (fc & 0x3FFFFFFF) ~/ 2;
        if (o + cnt <= wd.length) sb.write(latin1.decode(Uint8List.sublistView(wd, o, o + cnt)));
      } else {
        if (fc + cnt * 2 <= wd.length) {
          sb.write(String.fromCharCodes(Uint16List.fromList([for (var k = 0; k < cnt; k++) w.getUint16(fc + k * 2, Endian.little)])));
        }
      }
    }
    var s = sb.toString();
    s = s.replaceAll(RegExp(r'\x13[^\x14\x15]*\x14'), '').replaceAll(RegExp(r'[\x13\x14\x15]'), ''); // fields: keep result
    s = s.replaceAll('\r\x07', '\t').replaceAll('\x07', '\t').replaceAll('\r', '\n').replaceAll('\x0B', '\n').replaceAll('\x0C', '\n');
    s = s.replaceAll(RegExp(r'[\x00-\x08\x0E-\x1F]'), '');
    return s;
  }

  /// Builds a minimal valid .docx from plain-text paragraphs.
  static List<int> buildDocx(String text) {
    final paras = text.split('\n').map((l) {
      final rtl = RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(l);
      return _paraXml(DocPara(rtl: rtl)..runs.add(DocRun(l)));
    }).join();
    return _pack(paras);
  }

  /// Builds a .docx that keeps bold / italic / underline / size / colour / alignment / direction.
  static List<int> buildDocxFormatted(List<DocPara> ps) => _pack(ps.map(_paraXml).join());

  static String _esc(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');

  static String _paraXml(DocPara p) {
    final ppr = StringBuffer();
    if (p.rtl) ppr.write('<w:bidi/>');
    if (p.jc != 0) ppr.write('<w:jc w:val="${const ['left', 'center', 'right', 'both'][p.jc.clamp(0, 3)]}"/>');
    final b = StringBuffer('<w:p>');
    if (ppr.isNotEmpty) b.write('<w:pPr>$ppr</w:pPr>');
    for (final r in p.runs) {
      final rpr = StringBuffer();
      if (r.b) rpr.write('<w:b/><w:bCs/>');
      if (r.i) rpr.write('<w:i/><w:iCs/>');
      if (r.color != null) rpr.write('<w:color w:val="${r.color!.toRadixString(16).padLeft(6, '0').toUpperCase()}"/>');
      if (r.sz > 0) rpr.write('<w:sz w:val="${r.sz}"/><w:szCs w:val="${r.sz}"/>');
      if (r.u) rpr.write('<w:u w:val="single"/>');
      if (p.rtl || RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(r.text)) rpr.write('<w:rtl/>');
      final head = rpr.isEmpty ? '' : '<w:rPr>$rpr</w:rPr>';
      final buf = StringBuffer();
      void flush() {
        if (buf.isEmpty) return;
        b.write('<w:r>$head<w:t xml:space="preserve">${_esc(buf.toString())}</w:t></w:r>');
        buf.clear();
      }
      for (final ch in r.text.split('')) {
        if (ch == '\t') {
          flush();
          b.write('<w:r>$head<w:tab/></w:r>');
        } else if (ch == '\n') {
          flush();
          b.write('<w:r>$head<w:br/></w:r>');
        } else {
          buf.write(ch);
        }
      }
      flush();
    }
    b.write('</w:p>');
    return b.toString();
  }

  static List<int> _pack(String paras) {
    const ns = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';
    final files = <String, String>{
      '[Content_Types].xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>',
      '_rels/.rels': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
      'word/document.xml': '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document $ns><w:body>$paras<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>',
    };
    final arc = Archive();
    files.forEach((k, v) {
      final bytes = utf8.encode(v);
      arc.addFile(ArchiveFile(k, bytes.length, bytes));
    });
    return ZipEncoder().encode(arc)!;
  }

  // ------------------------------------------------------------ formatted extraction (CHPX / PAPX)
  static const _ico = [0, 0x000000, 0x0000FF, 0x00FFFF, 0x00FF00, 0xFF00FF, 0xFF0000, 0xFFFF00, 0xFFFFFF, 0x000080, 0x008080, 0x008000, 0x800080, 0x800000, 0x808000, 0x808080, 0xC0C0C0];

  static void _sprms(Uint8List d, int s, int e, void Function(int op, int pos) f) {
    var pos = s;
    final bd = ByteData.sublistView(d);
    while (pos + 2 <= e) {
      final op = bd.getUint16(pos, Endian.little);
      pos += 2;
      int len;
      switch (op >> 13) {
        case 0:
        case 1:
          len = 1;
          break;
        case 2:
        case 4:
        case 5:
          len = 2;
          break;
        case 3:
          len = 4;
          break;
        case 7:
          len = 3;
          break;
        default:
          if (pos >= e) return;
          len = op == 0xD608 ? bd.getUint16(pos, Endian.little) + 1 : d[pos] + 1;
      }
      if (pos + len > e) return;
      f(op, pos);
      pos += len;
    }
  }

  /// Paragraphs with run formatting. Style-sheet based formatting (e.g. heading styles) is not resolved.
  static List<DocPara> extractFormatted(Uint8List bytes) {
    final ole = Ole.parse(bytes);
    final wd = ole.stream('WordDocument');
    final w = ByteData.sublistView(wd);
    if (w.getUint16(0, Endian.little) != 0xA5EC) throw Exception('Not a Word binary document');
    final flags = w.getUint16(0x0A, Endian.little);
    if (flags & 0x0100 != 0) throw Exception('Encrypted .doc is not supported');
    final tbl = ole.stream((flags & 0x0200) != 0 ? '1Table' : '0Table');
    final t = ByteData.sublistView(tbl);
    final ccpText = w.getUint32(0x4C, Endian.little);
    final fcClx = w.getUint32(0x1A2, Endian.little);
    final lcbClx = w.getUint32(0x1A6, Endian.little);
    var pos = fcClx;
    final end = fcClx + lcbClx;
    while (pos < end && tbl[pos] == 1) {
      pos += 3 + t.getUint16(pos + 1, Endian.little);
    }
    if (pos >= end || tbl[pos] != 2) throw Exception('Piece table not found');
    final lcb = t.getUint32(pos + 1, Endian.little);
    pos += 5;
    final n = (lcb - 4) ~/ 12;
    final cps = [for (var i = 0; i <= n; i++) t.getUint32(pos + i * 4, Endian.little)];
    final pcd = pos + (n + 1) * 4;
    // pieces: cpStart, cpEnd, byte offset of first char, bytes per char
    final pcs = <List<int>>[];
    final raw = List<int>.filled(ccpText, 0x20);
    for (var i = 0; i < n; i++) {
      var cs = cps[i], ce = cps[i + 1];
      if (cs >= ccpText) break;
      if (ce > ccpText) ce = ccpText;
      final fc = t.getUint32(pcd + i * 8 + 2, Endian.little);
      final comp = fc & 0x40000000 != 0;
      final off = comp ? (fc & 0x3FFFFFFF) ~/ 2 : fc;
      final bpc = comp ? 1 : 2;
      pcs.add([cs, ce, off, bpc]);
      for (var k = 0; k < ce - cs; k++) {
        final o = off + k * bpc;
        if (o + bpc > wd.length) break;
        raw[cs + k] = comp ? wd[o] : w.getUint16(o, Endian.little);
      }
    }
    int? cpOfFc(int fc) {
      for (final p in pcs) {
        final len = (p[1] - p[0]) * p[3];
        if (fc >= p[2] && fc < p[2] + len) return p[0] + (fc - p[2]) ~/ p[3];
      }
      return null;
    }

    int? fcOfCp(int cp) {
      for (final p in pcs) {
        if (cp >= p[0] && cp < p[1]) return p[2] + (cp - p[0]) * p[3];
      }
      return null;
    }

    // character formatting
    final props = <DocRun>[DocRun('')];
    final fmtId = Uint32List(ccpText);
    final fcChpx = w.getUint32(0xFA, Endian.little), lcbChpx = w.getUint32(0xFE, Endian.little);
    try {
      final nb = (lcbChpx - 4) ~/ 8;
      for (var b = 0; b < nb; b++) {
        final pn = t.getUint32(fcChpx + (nb + 1) * 4 + b * 4, Endian.little);
        final po = pn * 512;
        if (po + 512 > wd.length) continue;
        final page = Uint8List.sublistView(wd, po, po + 512);
        final pg = ByteData.sublistView(page);
        final crun = page[511];
        for (var i = 0; i < crun; i++) {
          final off = page[(crun + 1) * 4 + i] * 2;
          if (off == 0) continue;
          final cb = page[off];
          final r = DocRun('');
          _sprms(page, off + 1, off + 1 + cb, (op, p) {
            switch (op) {
              case 0x0835:
              case 0x085C:
                r.b = page[p] == 1 || page[p] == 0x81;
                break;
              case 0x0836:
              case 0x085D:
                r.i = page[p] == 1 || page[p] == 0x81;
                break;
              case 0x2A3E:
                r.u = page[p] != 0;
                break;
              case 0x4A43:
              case 0x4A61:
                r.sz = pg.getUint16(p, Endian.little);
                break;
              case 0x2A42:
                if (page[p] > 0 && page[p] < _ico.length) r.color = _ico[page[p]];
                break;
              case 0x6870:
                if (page[p + 3] == 0) r.color = (page[p] << 16) | (page[p + 1] << 8) | page[p + 2];
                break;
            }
          });
          if (!r.b && !r.i && !r.u && r.sz == 0 && r.color == null) continue;
          props.add(r);
          final id = props.length - 1;
          final fa = pg.getUint32(i * 4, Endian.little), fb = pg.getUint32((i + 1) * 4, Endian.little);
          for (final p in pcs) {
            final lo = fa > p[2] ? fa : p[2];
            final hi = fb < p[2] + (p[1] - p[0]) * p[3] ? fb : p[2] + (p[1] - p[0]) * p[3];
            if (lo >= hi) continue;
            final c0 = p[0] + (lo - p[2]) ~/ p[3], c1 = p[0] + (hi - p[2] + p[3] - 1) ~/ p[3];
            for (var c = c0; c < c1 && c < ccpText; c++) {
              fmtId[c] = id;
            }
          }
        }
      }
    } catch (_) {}

    // paragraph formatting: fc range -> (jc, bidi)
    final pRuns = <List<int>>[]; // fa, fb, jc, bidi
    final fcPapx = w.getUint32(0x102, Endian.little), lcbPapx = w.getUint32(0x106, Endian.little);
    try {
      final nb = (lcbPapx - 4) ~/ 8;
      for (var b = 0; b < nb; b++) {
        final pn = t.getUint32(fcPapx + (nb + 1) * 4 + b * 4, Endian.little);
        final po = pn * 512;
        if (po + 512 > wd.length) continue;
        final page = Uint8List.sublistView(wd, po, po + 512);
        final pg = ByteData.sublistView(page);
        final crun = page[511];
        for (var i = 0; i < crun; i++) {
          final off = page[(crun + 1) * 4 + i * 13] * 2;
          var jc = 0, bidi = 0;
          if (off != 0) {
            var cb = page[off], st = off + 1;
            if (cb == 0) {
              cb = page[off + 1] * 2;
              st = off + 2;
            } else {
              cb = cb * 2 - 1;
            }
            _sprms(page, st + 2, st + cb, (op, p) {
              if (op == 0x2461 || op == 0x2403) jc = page[p];
              if (op == 0x2441) bidi = page[p];
            });
          }
          pRuns.add([pg.getUint32(i * 4, Endian.little), pg.getUint32((i + 1) * 4, Endian.little), jc, bidi]);
        }
      }
    } catch (_) {}

    // build paragraphs
    final out = <DocPara>[];
    var cur = DocPara();
    var curStart = 0;
    final codeStack = <bool>[];
    void finish(int endCp) {
      final fc = fcOfCp(curStart);
      if (fc != null) {
        for (final r in pRuns) {
          if (fc >= r[0] && fc < r[1]) {
            cur.jc = r[2];
            cur.rtl = r[3] == 1;
            break;
          }
        }
      }
      if (!cur.rtl) {
        final txt = cur.runs.map((r) => r.text).join();
        if (RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(txt) && !RegExp(r'[A-Za-z]').hasMatch(txt)) cur.rtl = true;
      }
      out.add(cur);
      cur = DocPara();
      curStart = endCp + 1;
    }

    void put(String ch, int id) {
      final base = props[id];
      if (cur.runs.isNotEmpty) {
        final l = cur.runs.last;
        if (l.b == base.b && l.i == base.i && l.u == base.u && l.sz == base.sz && l.color == base.color) {
          l.text += ch;
          return;
        }
      }
      cur.runs.add(DocRun(ch, b: base.b, i: base.i, u: base.u, sz: base.sz, color: base.color));
    }

    for (var cp = 0; cp < ccpText; cp++) {
      final c = raw[cp];
      if (c == 0x13) {
        codeStack.add(true);
        continue;
      }
      if (c == 0x14) {
        if (codeStack.isNotEmpty) codeStack[codeStack.length - 1] = false;
        continue;
      }
      if (c == 0x15) {
        if (codeStack.isNotEmpty) codeStack.removeLast();
        continue;
      }
      if (codeStack.contains(true)) continue;
      if (c == 0x0D) {
        finish(cp);
      } else if (c == 0x07) {
        put('\t', fmtId[cp]);
      } else if (c == 0x0B || c == 0x0C) {
        put('\n', fmtId[cp]);
      } else if (c == 0x1E) {
        put('-', fmtId[cp]);
      } else if (c < 0x20 && c != 0x09) {
        continue;
      } else {
        put(String.fromCharCode(c), fmtId[cp]);
      }
    }
    if (cur.runs.isNotEmpty) finish(ccpText);
    return out;
  }
}

class DocRun {
  String text;
  bool b, i, u;
  int sz; // half-points, 0 = default
  int? color;
  DocRun(this.text, {this.b = false, this.i = false, this.u = false, this.sz = 0, this.color});
}

class DocPara {
  final runs = <DocRun>[];
  int jc = 0; // 0 start, 1 center, 2 end, 3 justify
  bool rtl;
  DocPara({this.rtl = false});
  String get text => runs.map((r) => r.text).join();
}
