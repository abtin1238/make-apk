import 'dart:io';
import 'package:ftpconnect/ftpconnect.dart';
import 'remote_fs.dart';

class FtpFs extends RemoteFs {
  final RemoteProfile pr;
  FTPConnect? _c;
  FtpFs(this.pr);

  @override
  Future<void> connect() async {
    _c = FTPConnect(pr.host,
        port: pr.port, user: pr.user.isEmpty ? 'anonymous' : pr.user, pass: pr.pass, timeout: 20,
        securityType: pr.flag ? SecurityType.FTPES : SecurityType.FTP);
    if (!await _c!.connect()) throw const RemoteError('FTP login failed');
    home = pr.path.isEmpty ? '/' : pr.path;
  }

  Future<void> _cd(String dir) async {
    if (!await _c!.changeDirectory(dir)) throw RemoteError('cd failed: $dir');
  }

  @override
  Future<List<RemoteEntry>> list(String path) async {
    await _cd(path);
    final l = await _c!.listDirectoryContent();
    return [
      for (final e in l)
        if (e.name != '.' && e.name != '..' && e.name.isNotEmpty)
          RemoteEntry(e.name, e.type == FTPEntryType.DIR, size: e.size, modified: e.modifyTime),
    ];
  }

  @override
  Future<void> download(String path, String local, {Prog? onProgress}) async {
    await _cd(RPath.parent(path));
    final ok = await _c!.downloadFile(RPath.name(path), File(local),
        onProgress: (pct, got, total) => onProgress?.call(got, total));
    if (!ok) throw RemoteError('Download failed: ${RPath.name(path)}');
  }

  @override
  Future<void> upload(String local, String path, {Prog? onProgress}) async {
    await _cd(RPath.parent(path));
    final ok = await _c!.uploadFile(File(local),
        sRemoteName: RPath.name(path), onProgress: (pct, sent, total) => onProgress?.call(sent, total));
    if (!ok) throw RemoteError('Upload failed: ${RPath.name(path)}');
  }

  @override
  Future<void> mkdir(String path) async {
    await _cd(RPath.parent(path));
    if (!await _c!.makeDirectory(RPath.name(path))) throw RemoteError('mkdir failed');
  }

  @override
  Future<void> delete(String path, bool dir) async {
    await _cd(RPath.parent(path));
    final ok = dir ? await _c!.deleteDirectory(RPath.name(path)) : await _c!.deleteFile(RPath.name(path));
    if (!ok) throw const RemoteError('Delete failed');
  }

  @override
  Future<void> rename(String from, String to) async {
    await _cd(RPath.parent(from));
    if (!await _c!.rename(RPath.name(from), to)) throw const RemoteError('Rename failed');
  }

  @override
  Future<void> close() async {
    try {
      await _c?.disconnect();
    } catch (_) {}
    _c = null;
  }
}
