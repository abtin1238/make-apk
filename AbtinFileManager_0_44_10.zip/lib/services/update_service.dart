import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'archive_service.dart';
import 'file_ops.dart' show OpError;
import 'native.dart';

/// A GitHub release that carries an installable build.
class UpdateInfo {
  final String tag;
  final String name;
  final String notes;
  final String assetName;
  final String assetUrl;
  final int assetSize;
  final DateTime assetTime;
  const UpdateInfo(this.tag, this.name, this.notes, this.assetName, this.assetUrl, this.assetSize, this.assetTime);
}

/// Checks https://github.com/abtin1238/make-apk/releases (tags build-N; each release holds the APK
/// as .apk or as a .zip that contains the APK) and downloads / installs the newest build.
///
/// "Newer" means: the release's APK asset was uploaded after this app was installed / last updated
/// (PackageInfo.lastUpdateTime). Once the new build is installed, lastUpdateTime moves past the
/// asset time, so the same release is never offered twice.
class UpdateService {
  static const repo = 'abtin1238/make-apk';
  static const releasesPage = 'https://github.com/$repo/releases';
  static const _kAuto = 'upd_auto';
  static const _kLast = 'upd_last_check';
  static const _kSkip = 'upd_skip_tag';

  static Future<bool> autoEnabled() async => (await SharedPreferences.getInstance()).getBool(_kAuto) ?? true;
  static Future<void> setAuto(bool v) async => (await SharedPreferences.getInstance()).setBool(_kAuto, v);

  /// true at most once per [every] on app start, when the user has not switched it off.
  static Future<bool> dueForAutoCheck({Duration every = const Duration(hours: 6)}) async {
    final sp = await SharedPreferences.getInstance();
    if (!(sp.getBool(_kAuto) ?? true)) return false;
    final last = sp.getInt(_kLast) ?? 0;
    return DateTime.now().millisecondsSinceEpoch - last >= every.inMilliseconds;
  }

  static Future<void> skip(String tag) async => (await SharedPreferences.getInstance()).setString(_kSkip, tag);

  static Future<String> currentVersion() async {
    final i = await Native.selfInfo();
    return i == null ? '' : '${i['versionName']} (${i['versionCode']})';
  }

  static bool _isApk(String n) => n.toLowerCase().endsWith('.apk');
  static bool _isZip(String n) => n.toLowerCase().endsWith('.zip');

  /// Best APK among [names]: arm64 first (modern phones), then universal / release, then anything.
  static String? pickApk(List<String> names) {
    final apks = names.where(_isApk).toList();
    if (apks.isEmpty) return null;
    int score(String n) {
      final l = n.toLowerCase();
      var s = 0;
      if (l.contains('arm64') || l.contains('v8a')) s += 8;
      if (l.contains('universal') || l.contains('fat')) s += 4;
      if (l.contains('release')) s += 2;
      if (l.contains('debug')) s -= 3;
      if (l.contains('x86') || l.contains('armeabi') || l.contains('v7a')) s -= 6;
      return s;
    }
    apks.sort((a, b) => score(b).compareTo(score(a)));
    return apks.first;
  }

  /// Same idea for the release assets (an .apk, or a .zip that wraps the APKs).
  static Map<String, dynamic>? _pickAsset(List assets) {
    final ok = [
      for (final a in assets)
        if (a is Map && a['state'] != 'starter' && (_isApk('${a['name']}') || _isZip('${a['name']}'))) Map<String, dynamic>.from(a)
    ];
    if (ok.isEmpty) return null;
    int score(Map a) {
      final n = '${a['name']}'.toLowerCase();
      var s = _isApk(n) ? 1 : 0;
      if (n.contains('arm64') || n.contains('v8a')) s += 8;
      if (n.contains('universal') || n.contains('fat')) s += 4;
      if (n.contains('release')) s += 2;
      if (n.contains('x86') || n.contains('armeabi') || n.contains('v7a')) s -= 6;
      if (n.contains('debug')) s -= 3;
      return s;
    }
    ok.sort((a, b) => score(b).compareTo(score(a)));
    return ok.first;
  }

  static Future<dynamic> _getJson(String url) async {
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      final rq = await c.getUrl(Uri.parse(url));
      rq.headers.set('Accept', 'application/vnd.github+json');
      rq.headers.set('User-Agent', 'AbtinFileManager');
      final rs = await rq.close().timeout(const Duration(seconds: 25));
      final body = await rs.transform(utf8.decoder).join();
      if (rs.statusCode != 200) throw OpError('updFailed', 'HTTP ${rs.statusCode}');
      return jsonDecode(body);
    } finally {
      c.close(force: true);
    }
  }

  /// Newest release that already has an APK asset (a release is created first, its files are added
  /// as each build finishes). Returns null when this app is up to date.
  /// [force] ignores a version the user chose to skip.
  static Future<UpdateInfo?> check({bool force = false}) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setInt(_kLast, DateTime.now().millisecondsSinceEpoch);
    final data = await _getJson('https://api.github.com/repos/$repo/releases?per_page=10');
    if (data is! List) throw const OpError('updFailed');
    final me = await Native.selfInfo();
    final installed = DateTime.fromMillisecondsSinceEpoch(((me?['lastUpdate'] as num?) ?? 0).toInt(), isUtc: true);
    for (final r in data) {
      if (r is! Map || r['draft'] == true) continue;
      final a = _pickAsset((r['assets'] as List?) ?? const []);
      if (a == null) continue; // release exists but its build is not finished yet
      final t = DateTime.tryParse('${a['updated_at'] ?? a['created_at']}')?.toUtc() ?? DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
      final tag = '${r['tag_name']}';
      if (!t.isAfter(installed)) return null; // newest build is already installed
      if (!force && sp.getString(_kSkip) == tag) return null;
      return UpdateInfo(tag, '${r['name'] ?? tag}', '${r['body'] ?? ''}', '${a['name']}', '${a['browser_download_url']}', (a['size'] as num?)?.toInt() ?? 0, t);
    }
    return null;
  }

  /// Downloads the asset (following GitHub's redirect) and returns the path of the APK to install.
  static Future<String> download(UpdateInfo u, void Function(double?) onProgress) async {
    final tmp = await getTemporaryDirectory();
    final dir = Directory(p.join(tmp.path, 'abtin_update'));
    if (dir.existsSync()) dir.deleteSync(recursive: true);
    dir.createSync(recursive: true);
    final file = File(p.join(dir.path, u.assetName));
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 20);
    try {
      var uri = Uri.parse(u.assetUrl);
      HttpClientResponse? rs;
      for (var hop = 0; hop < 6; hop++) {
        final rq = await c.getUrl(uri);
        rq.followRedirects = false;
        rq.headers.set('User-Agent', 'AbtinFileManager');
        rs = await rq.close();
        if (rs.isRedirect) {
          final loc = rs.headers.value(HttpHeaders.locationHeader);
          await rs.drain<void>();
          if (loc == null) throw const OpError('updFailed');
          uri = uri.resolve(loc);
          continue;
        }
        break;
      }
      if (rs == null || rs.statusCode != 200) throw OpError('updFailed', 'HTTP ${rs?.statusCode}');
      final total = rs.contentLength > 0 ? rs.contentLength : u.assetSize;
      final sink = file.openWrite();
      var got = 0;
      try {
        await for (final chunk in rs) {
          sink.add(chunk);
          got += chunk.length;
          onProgress(total > 0 ? (got / total).clamp(0.0, 1.0) : null);
        }
      } finally {
        await sink.close();
      }
    } finally {
      c.close(force: true);
    }
    if (_isApk(file.path)) return file.path;
    // a zip that wraps the APK(s): unpack only the best one
    final list = await ArchiveService.list(file.path);
    final pick = pickApk([for (final e in list) if (!e.dir) e.name]);
    if (pick == null) throw const OpError('updNoApk');
    final out = Directory(p.join(dir.path, 'apk'));
    await ArchiveService.extract(file.path, out.path, only: [pick]);
    final apk = File(p.join(out.path, ArchiveService.normName(pick)));
    if (!apk.existsSync()) throw const OpError('updNoApk');
    return apk.path;
  }
}
