'use strict';
// Abtin Core - background. Receives config from the app over native messaging and blocks requests.
var cfg = { adblock: true, level: 'standard', ads: [], trackers: [], strict: [], cosmetic: '', extra: [] };
var sets = { ads: new Set(), trackers: new Set(), strict: new Set(), extra: new Set() };
var verdict = new Map();   // "host|from" -> true (block) / false; cleared whenever the config changes

function rebuild() {
  sets.ads = new Set(cfg.ads || []);
  sets.trackers = new Set(cfg.trackers || []);
  sets.strict = new Set(cfg.strict || []);
  sets.extra = new Set(cfg.extra || []);
  verdict.clear();
  if (typeof registerBlocker === 'function') registerBlocker();
}

var port = browser.runtime.connectNative('abtin');
port.onMessage.addListener(function (m) {
  if (!m) return;
  if (m.cmd === 'config' && m.config) {
    var prevUi = [cfg.mediaBtn, cfg.pullRefresh, cfg.scrollBtn].join();
    var wasOff = cfg.mediaBtn === false;
    cfg = Object.assign(cfg, m.config);
    // switching the video buttons back on brings them back on every site closed with the X
    var reset = wasOff && cfg.mediaBtn !== false;
    if (reset) { try { browser.storage.local.remove('mbOff').catch(function () {}); } catch (e) {} }
    rebuild();
    applyLite();
    if (prevUi !== [cfg.mediaBtn, cfg.pullRefresh, cfg.scrollBtn].join()) {
      browser.tabs.query({}).then(function (tabs) {
        tabs.forEach(function (t) { browser.tabs.sendMessage(t.id, { cmd: 'uiCfg', mediaBtn: cfg.mediaBtn !== false, pullRefresh: cfg.pullRefresh !== false, scrollBtn: cfg.scrollBtn !== false, resetOff: reset }).catch(function () {}); });
      }).catch(function () {});
    }
  } else if (m.cmd === 'relay' && m.msg) {
    // The page's own native port was not available: deliver the command through the tabs API instead.
    browser.tabs.query({ active: true }).then(function (tabs) {
      tabs.forEach(function (t) { browser.tabs.sendMessage(t.id, m.msg).catch(function () {}); });
    }).catch(function () {});
  }
});
port.onDisconnect.addListener(function () {});

// Favicon -> 64px PNG data URL. Done here (not in the page) so the page's CSP cannot block it and .ico/.svg/.webp all work.
var iconCache = new Map();
function iconData(url) {
  if (!/^https?:/i.test(url || '')) return Promise.resolve('');
  if (iconCache.has(url)) return Promise.resolve(iconCache.get(url));
  return fetch(url, { credentials: 'omit' }).then(function (r) {
    if (!r.ok) throw new Error('http');
    return r.blob();
  }).then(function (b) {
    return new Promise(function (res, rej) {
      var u = URL.createObjectURL(b), im = new Image();
      im.onload = function () {
        try {
          var c = document.createElement('canvas'); c.width = c.height = 64;
          var w = im.naturalWidth || 64, h = im.naturalHeight || 64, s = Math.min(64 / w, 64 / h);
          c.getContext('2d').drawImage(im, (64 - w * s) / 2, (64 - h * s) / 2, w * s, h * s);
          var d = c.toDataURL('image/png');
          URL.revokeObjectURL(u);
          if (iconCache.size > 300) iconCache.clear();
          iconCache.set(url, d);
          res(d);
        } catch (e) { URL.revokeObjectURL(u); rej(e); }
      };
      im.onerror = function () { URL.revokeObjectURL(u); rej(new Error('decode')); };
      im.src = u;
    });
  }).catch(function () { return ''; });
}

var HOST = /^[a-z][a-z0-9+.-]*:\/\/(?:[^\/?#@]*@)?([^\/:?#]+)/i;
function hostOf(u) {
  var m = HOST.exec(u || '');
  return m ? m[1].toLowerCase() : '';
}

// registrable-domain approximation (good enough for third-party checks)
var SLD = { co: 1, com: 1, org: 1, net: 1, gov: 1, edu: 1, ac: 1 };
function base(h) {
  var p = h.split('.');
  if (p.length <= 2) return h;
  var n = (p[p.length - 2].length <= 3 && SLD[p[p.length - 2]]) ? 3 : 2;
  return p.slice(-n).join('.');
}

function inSet(set, host) {
  if (!set.size) return false;
  var p = host.split('.');
  for (var i = 0; i < p.length - 1; i++) {
    if (set.has(p.slice(i).join('.'))) return true;
  }
  return false;
}

function decide(host, from) {
  if (from && base(from) === base(host)) return false;   // first party is never blocked
  if (inSet(sets.extra, host)) return true;
  if (cfg.adblock && inSet(sets.ads, host)) return true;
  if (cfg.level !== 'off' && inSet(sets.trackers, host)) return true;
  if (cfg.level === 'strict' && inSet(sets.strict, host)) return true;
  return false;
}

// Only requests to listed domains ever reach this blocking handler (match patterns), so ordinary pages
// (GitHub, Google...) pay no per-request round trip to the background page.
var blockTypes = ['sub_frame', 'stylesheet', 'script', 'image', 'imageset', 'object', 'xmlhttprequest', 'ping', 'beacon', 'csp_report', 'media', 'websocket', 'other'];
function onBlockReq(d) {
  var host = hostOf(d.url);
  if (!host) return {};
  var from = hostOf(d.originUrl || d.documentUrl);
  var key = host + '|' + from;
  var v = verdict.get(key);
  if (v === undefined) {
    v = decide(host, from);
    if (verdict.size > 4000) verdict.clear();
    verdict.set(key, v);
  }
  return v ? { cancel: true } : {};
}
var blockOn = false;
function registerBlocker() {
  if (blockOn) { try { browser.webRequest.onBeforeRequest.removeListener(onBlockReq); } catch (e) {} blockOn = false; }
  var doms = [];
  if (cfg.adblock) doms = doms.concat(cfg.ads || []);
  if (cfg.level !== 'off') doms = doms.concat(cfg.trackers || []);
  if (cfg.level === 'strict') doms = doms.concat(cfg.strict || []);
  doms = doms.concat(cfg.extra || []);
  var pats = [];
  doms.forEach(function (h) { if (h && /^[a-z0-9.-]+$/i.test(h)) pats.push('*://*.' + h + '/*'); });
  if (!pats.length) return;
  try {
    browser.webRequest.onBeforeRequest.addListener(onBlockReq, { urls: pats, types: blockTypes }, ['blocking']);
    blockOn = true;
  } catch (e) {}
}
registerBlocker();

// ---- media sniffer: remembers playable streams per tab and tells the page's content script ----
var recent = {};   // tabId -> [{url,mime,size,kind,part}]

function normalizeMedia(url) {
  try {
    var o = new URL(url), h = o.hostname, part = '';
    if (/(^|\.)(fbcdn\.net|cdninstagram\.com)$/.test(h)) {
      o.searchParams.delete('bytestart'); o.searchParams.delete('byteend');
      var efg = o.searchParams.get('efg');
      if (efg) {
        try {
          var tag = atob(efg.replace(/-/g, '+').replace(/_/g, '/'));
          if (/audio/i.test(tag)) part = 'audio'; else if (/dash/i.test(tag)) part = 'video';
        } catch (e) {}
      }
    } else if (/googlevideo\.com$/.test(h) && o.pathname === '/videoplayback') {
      ['range', 'rn', 'rbuf'].forEach(function (k) { o.searchParams.delete(k); });
      var mt = o.searchParams.get('mime') || '', it = o.searchParams.get('itag') || '';
      if (!/^(18|22|37|43|59|78)$/.test(it)) { if (/^audio/.test(mt)) part = 'audio'; else if (/^video/.test(mt)) part = 'video'; }
      var cl = parseInt(o.searchParams.get('clen') || '', 10);
      return { url: o.toString(), part: part, clen: isNaN(cl) ? -1 : cl };
    }
    return { url: o.toString(), part: part, clen: -1 };
  } catch (e) { return { url: url, part: '', clen: -1 }; }
}

function classifyMedia(url, mime) {
  var path = (url.split('#')[0].split('?')[0] || '').toLowerCase();
  var m = (mime || '').toLowerCase();
  if (/\.(ts|m4s|cmfv|cmfa|vtt|srt|aac|mpd|key)$/.test(path) || /dash\+xml|video\/mp2t|text\//.test(m)) return '';
  if (/\.m3u8$/.test(path) || /mpegurl/.test(m)) return 'hls';
  if (/^audio\//.test(m)) return 'audio';
  if (/^video\//.test(m)) return 'video';
  if (/\.(mp4|m4v|webm|mkv|mov)$/.test(path)) return 'video';
  if (/\.(mp3|m4a|ogg|oga|opus|flac|wav)$/.test(path)) return 'audio';
  return '';
}

browser.webRequest.onBeforeRequest.addListener(function (d) {
  if (d.tabId >= 0) recent[d.tabId] = [];
  return {};
}, { urls: ['http://*/*', 'https://*/*'], types: ['main_frame'] });

browser.webRequest.onHeadersReceived.addListener(function (d) {
  if (d.tabId < 0 || (d.statusCode !== 200 && d.statusCode !== 206)) return;
  var mime = '', len = -1, range = '';
  (d.responseHeaders || []).forEach(function (h) {
    var n = (h.name || '').toLowerCase();
    if (n === 'content-type') mime = h.value || '';
    else if (n === 'content-length') len = parseInt(h.value, 10);
    else if (n === 'content-range') range = h.value || '';
  });
  var rm = /\/(\d+)\s*$/.exec(range);
  if (rm) len = parseInt(rm[1], 10);
  if (isNaN(len)) len = -1;
  var kind = classifyMedia(d.url, mime);
  if (!kind) return;
  var n = normalizeMedia(d.url);
  if (n.clen > 0) len = n.clen;
  // tiny files are noise, but the audio track of a short reel can be well under 150 KB
  if (kind !== 'hls' && len >= 0 && len < (n.part === 'audio' || kind === 'audio' ? 8000 : 150000)) return;
  var item = { url: n.url, mime: mime, size: len, kind: kind, part: n.part, ts: Date.now() };
  var list = recent[d.tabId] || (recent[d.tabId] = []);
  for (var i = 0; i < list.length; i++) if (list[i].url === item.url) return;
  list.push(item);
  if (list.length > 40) list.shift();
  browser.tabs.sendMessage(d.tabId, Object.assign({ cmd: 'media' }, item)).catch(function () {});
}, { urls: ['http://*/*', 'https://*/*'], types: ['media', 'xmlhttprequest', 'other', 'object'] }, ['responseHeaders']);

browser.tabs.onRemoved.addListener(function (id) { delete recent[id]; });


// content scripts ask for cosmetic filter CSS
browser.runtime.onMessage.addListener(function (m, sender) {
  if (m && m.t === 'getConfig') {
    return Promise.resolve({ adblock: !!cfg.adblock, cosmetic: cfg.cosmetic || '', mediaBtn: cfg.mediaBtn !== false, pullRefresh: cfg.pullRefresh !== false, scrollBtn: cfg.scrollBtn !== false, lang: cfg.lang || 'fa' });
  }
  if (m && m.t === 'icon') return iconData(m.url);
  if (m && m.t === 'netOn') { netOn(); return Promise.resolve(true); }
  if (m && m.t === 'netOff') { netOff(); return Promise.resolve(true); }
  if (m && m.t === 'net') {
    netOn();
    var nid = sender && sender.tab ? sender.tab.id : -1;
    var nl = netLog[nid];
    return Promise.resolve(nl ? nl.list : []);
  }
  if (m && m.t === 'fetchText') return fetchSource(m.url);
  if (m && m.t === 'recentMedia') {
    var id = sender && sender.tab ? sender.tab.id : -1;
    return Promise.resolve(recent[id] || []);
  }
});

// ---- Data saver ("lite" mode, Settings > slow connection): ask sites for lighter content with the Save-Data header ----
// (Save-Data is a CORS-safelisted request header; CDNs / sites such as Instagram, Facebook, YouTube serve smaller media for it.)
var liteOn = false;
function onLiteHeaders(d) {
  var h = d.requestHeaders || [];
  for (var i = 0; i < h.length; i++) if ((h[i].name || '').toLowerCase() === 'save-data') return {};
  h.push({ name: 'Save-Data', value: 'on' });
  return { requestHeaders: h };
}
function applyLite() {
  var want = cfg.lite === true;
  if (want === liteOn) return;
  try {
    if (want) browser.webRequest.onBeforeSendHeaders.addListener(onLiteHeaders, { urls: ['http://*/*', 'https://*/*'] }, ['blocking', 'requestHeaders']);
    else browser.webRequest.onBeforeSendHeaders.removeListener(onLiteHeaders);
    liteOn = want;
  } catch (e) {}
}


// ---- Inspector: network log per tab (Network tab) and source fetching (Sources tab, cross-origin CSS) ----
var netLog = {};   // tabId -> { list: [entry], map: { requestId: entry }, main: requestId }
function netOf(id) { return netLog[id] || (netLog[id] = { list: [], map: {}, main: '' }); }
function netPair(h) { var o = []; (h || []).forEach(function (x) { if (o.length < 80) o.push([x.name, x.value == null ? '' : String(x.value).slice(0, 600)]); }); return o; }
var NET_FILTER = { urls: ['http://*/*', 'https://*/*'] };
// The network log is only needed while the inspector's Network tab is open. Six listeners that copy every request / response
// header of every tab slow page loads on weak phones, so they are attached on demand (content.js sends netOn / netOff).
var netOnFlag = false;
function nlReq(d) {
  if (d.tabId < 0) return;
  var n = netOf(d.tabId);
  if (d.type === 'main_frame' && n.main !== d.requestId) { n.list = []; n.map = {}; n.main = d.requestId; }
  var e = { id: d.requestId, url: d.url, method: d.method, type: d.type, ts: Math.round(d.timeStamp), status: 0, done: false };
  n.map[d.requestId] = e;
  n.list.push(e);
  if (n.list.length > 500) { var old = n.list.shift(); if (n.map[old.id] === old) delete n.map[old.id]; }
}
function nlSend(d) {
  var e = d.tabId >= 0 && netLog[d.tabId] && netLog[d.tabId].map[d.requestId];
  if (e) e.reqH = netPair(d.requestHeaders);
}
function nlHead(d) {
  var e = d.tabId >= 0 && netLog[d.tabId] && netLog[d.tabId].map[d.requestId];
  if (!e) return;
  e.status = d.statusCode; e.line = d.statusLine || '';
  e.resH = netPair(d.responseHeaders);
  (d.responseHeaders || []).forEach(function (x) {
    var k = (x.name || '').toLowerCase();
    if (k === 'content-length') e.len = parseInt(x.value, 10);
    else if (k === 'content-type') e.ctype = String(x.value || '').split(';')[0];
  });
}
function nlRedir(d) {
  var n = d.tabId >= 0 && netLog[d.tabId], e = n && n.map[d.requestId];
  if (!e) return;
  e.status = d.statusCode; e.done = true; e.end = Math.round(d.timeStamp); e.redir = d.redirectUrl;
  delete n.map[d.requestId];   // the redirected request continues under the same id as a new entry
}
function nlDone(d) {
  var e = d.tabId >= 0 && netLog[d.tabId] && netLog[d.tabId].map[d.requestId];
  if (!e) return;
  e.status = d.statusCode || e.status; e.done = true; e.end = Math.round(d.timeStamp); e.cache = !!d.fromCache; e.ip = d.ip || '';
}
function nlErr(d) {
  var e = d.tabId >= 0 && netLog[d.tabId] && netLog[d.tabId].map[d.requestId];
  if (!e) return;
  e.err = d.error || 'error'; e.done = true; e.end = Math.round(d.timeStamp);
}
function netOn() {
  if (netOnFlag) return;
  netOnFlag = true;
  try {
    browser.webRequest.onBeforeRequest.addListener(nlReq, NET_FILTER);
    browser.webRequest.onSendHeaders.addListener(nlSend, NET_FILTER, ['requestHeaders']);
    browser.webRequest.onHeadersReceived.addListener(nlHead, NET_FILTER, ['responseHeaders']);
    browser.webRequest.onBeforeRedirect.addListener(nlRedir, NET_FILTER);
    browser.webRequest.onCompleted.addListener(nlDone, NET_FILTER);
    browser.webRequest.onErrorOccurred.addListener(nlErr, NET_FILTER);
  } catch (e) {}
}
function netOff() {
  if (!netOnFlag) return;
  netOnFlag = false;
  try {
    browser.webRequest.onBeforeRequest.removeListener(nlReq);
    browser.webRequest.onSendHeaders.removeListener(nlSend);
    browser.webRequest.onHeadersReceived.removeListener(nlHead);
    browser.webRequest.onBeforeRedirect.removeListener(nlRedir);
    browser.webRequest.onCompleted.removeListener(nlDone);
    browser.webRequest.onErrorOccurred.removeListener(nlErr);
  } catch (e) {}
  netLog = {};
}
browser.tabs.onRemoved.addListener(function (id) { delete netLog[id]; });

function fetchSource(url) {
  if (!/^https?:\/\//i.test(url || '')) return Promise.resolve({ ok: false, error: 'url' });
  return fetch(url, { credentials: 'include', cache: 'force-cache' }).then(function (r) {
    return r.text().then(function (t) {
      return { ok: r.ok, status: r.status, text: t.length > 2000000 ? t.slice(0, 2000000) : t, size: t.length, ctype: r.headers.get('content-type') || '' };
    });
  }).catch(function (e) { return { ok: false, error: String(e && e.message || e) }; });
}
