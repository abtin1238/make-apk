import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:path/path.dart' as p;
import 'package:xterm/xterm.dart';

import 'code_runner.dart';
import 'terminal_native.dart';

/// Breakpoints of the editor: file path -> line (1-based) -> optional condition.
class BreakpointStore extends ChangeNotifier {
  final Map<String, Map<int, String?>> _m = <String, Map<int, String?>>{};

  /// Lines the debugger said hold no code (shown as hollow circles).
  final Map<String, Set<int>> unverified = <String, Set<int>>{};

  Map<int, String?> of(String path) => _m[path] ?? const <int, String?>{};
  bool has(String path, int line) => (_m[path] ?? const <int, String?>{}).containsKey(line);
  Iterable<String> get files => _m.keys.where((k) => _m[k]!.isNotEmpty);
  bool get isEmpty => _m.values.every((e) => e.isEmpty);
  int get count => _m.values.fold<int>(0, (a, e) => a + e.length);

  void toggle(String path, int line) {
    final m = _m.putIfAbsent(path, () => <int, String?>{});
    if (m.containsKey(line)) {
      m.remove(line);
      unverified[path]?.remove(line);
    } else {
      m[line] = null;
    }
    notifyListeners();
  }

  void setCondition(String path, int line, String? cond) {
    final m = _m.putIfAbsent(path, () => <int, String?>{});
    final c = (cond ?? '').trim();
    m[line] = c.isEmpty ? null : c;
    notifyListeners();
  }

  void remove(String path, int line) {
    _m[path]?.remove(line);
    unverified[path]?.remove(line);
    notifyListeners();
  }

  void clear() {
    _m.clear();
    unverified.clear();
    notifyListeners();
  }

  /// A file / folder was renamed: keep its breakpoints.
  void renamePath(String from, String to) {
    final keys = _m.keys.toList();
    for (final k in keys) {
      if (k == from || p.isWithin(from, k)) {
        final nk = k == from ? to : p.join(to, p.relative(k, from: from));
        _m[nk] = _m.remove(k)!;
        final u = unverified.remove(k);
        if (u != null) unverified[nk] = u;
      }
    }
    notifyListeners();
  }

  void removePath(String path) {
    final keys = _m.keys.toList();
    for (final k in keys) {
      if (k == path || p.isWithin(path, k)) {
        _m.remove(k);
        unverified.remove(k);
      }
    }
    notifyListeners();
  }

  void setUnverified(String path, Iterable<int> lines) {
    unverified[path] = lines.toSet();
    notifyListeners();
  }
}

class DebugVar {
  final String name, value, type;
  final int ref;
  final int? len;
  bool expanded = false;
  bool loading = false;
  List<DebugVar>? children;
  DebugVar({required this.name, required this.value, required this.type, required this.ref, this.len});

  factory DebugVar.fromJson(Map<String, dynamic> j) => DebugVar(
        name: '${j['n']}',
        value: '${j['v']}',
        type: '${j['t'] ?? ''}',
        ref: (j['r'] as num?)?.toInt() ?? 0,
        len: (j['len'] as num?)?.toInt(),
      );

  static List<DebugVar> list(Object? o) {
    if (o is! List) return <DebugVar>[];
    return [
      for (final e in o)
        if (e is Map) DebugVar.fromJson(Map<String, dynamic>.from(e)),
    ];
  }
}

class DebugFrame {
  final int index;
  final String name;

  /// Path on this phone (mapped back from the Alpine /workspace path).
  final String file;
  final int line;

  /// false = library code (not part of the project)
  final bool mine;
  const DebugFrame(this.index, this.name, this.file, this.line, this.mine);
}

class DebugWatch {
  final String expr;
  DebugVar? value;
  String? error;
  DebugWatch(this.expr);
}

enum DebugState { idle, starting, running, paused, ended, needAlpine, needInstall, error }

/// Splits the raw terminal stream into the adapter's JSON messages
/// (`\x1fABTIN_DBG:{json}\x1f`) and the program's own output.
class DebugStream {
  static const _start = '\u001fABTIN_DBG:';
  String _buf = '';

  String feed(String chunk, void Function(String json) onMsg) {
    _buf += chunk;
    final plain = StringBuffer();
    while (true) {
      final i = _buf.indexOf(_start);
      if (i < 0) {
        final keep = _partialTail(_buf);
        plain.write(_buf.substring(0, _buf.length - keep));
        _buf = _buf.substring(_buf.length - keep);
        break;
      }
      plain.write(_buf.substring(0, i));
      final j = _buf.indexOf('\u001f', i + _start.length);
      if (j < 0) {
        _buf = _buf.substring(i);
        if (_buf.length > 4000000) _buf = '';
        break;
      }
      onMsg(_buf.substring(i + _start.length, j));
      _buf = _buf.substring(j + 1);
    }
    return plain.toString();
  }

  /// What is still held back (a lone \x1f at the end of a chunk): hand it on.
  String flush() {
    final r = _buf.startsWith(_start) ? '' : _buf;
    _buf = '';
    return r;
  }

  static int _partialTail(String s) {
    final max = s.length < _start.length - 1 ? s.length : _start.length - 1;
    for (var k = max; k >= 1; k--) {
      if (s.endsWith(_start.substring(0, k))) return k;
    }
    return 0;
  }
}

/// One debugging run of a Python file: the adapter (assets/debug/abtin_pydbg.py)
/// runs inside Alpine in a PTY; breakpoints, stepping, variables and watch
/// expressions go over that PTY as small JSON lines.
class DebugSession extends ChangeNotifier {
  static const guestRoot = '/workspace';

  /// Languages the debugger can run.
  static bool supports(String lang) => lang == 'python';

  final Terminal terminal = Terminal(maxLines: 5000);
  final TerminalNative _native = TerminalNative();
  StreamSubscription<Map<String, dynamic>>? _sub;
  String? _id;
  RunOutputFilter _filter = RunOutputFilter();
  DebugStream _stream = DebugStream();
  int _cols = 80, _rows = 24;
  bool _disposed = false;
  int _seq = 0;
  final Map<int, void Function(Map<String, dynamic>)> _waiters = <int, void Function(Map<String, dynamic>)>{};
  final Set<String> _sentFiles = <String>{};
  bool _bpsDirty = false;
  final Stopwatch _sw = Stopwatch();

  BreakpointStore? bps;
  String hostDir = '';

  DebugState state = DebugState.idle;
  String needPkgs = '';
  int runId = 0;
  int? exitCode;
  Duration? elapsed;

  /// 'breakpoint' | 'step' | 'entry' | 'pause' | 'exception'
  String stopReason = '';
  String exceptionText = '';
  List<DebugFrame> frames = <DebugFrame>[];
  int selFrame = 0;
  List<DebugVar> locals = <DebugVar>[];
  List<DebugVar> globals = <DebugVar>[];
  final List<DebugWatch> watches = <DebugWatch>[];

  /// Called on every stop (and when a frame is picked): the editor opens the file and shows the line.
  void Function(String file, int line, String reason)? onStopped;

  bool get active => state == DebugState.starting || state == DebugState.running || state == DebugState.paused;
  bool get paused => state == DebugState.paused;
  DebugFrame? get topFrame => frames.isEmpty ? null : frames[selFrame.clamp(0, frames.length - 1).toInt()];

  DebugSession() {
    terminal.onOutput = (data) {
      final id = _id;
      if (id != null && state == DebugState.running) unawaited(_native.writeRaw(id, data).catchError((_) {}));
    };
    terminal.onResize = (columns, rows, _, __) {
      _cols = columns.clamp(20, 500).toInt();
      _rows = rows.clamp(5, 300).toInt();
      final id = _id;
      if (id != null) unawaited(_native.resize(id, _cols, _rows).catchError((_) {}));
    };
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  // ---------- path mapping (phone <-> Alpine) ----------
  String? toGuest(String host) {
    if (hostDir.isEmpty) return null;
    if (host == hostDir) return guestRoot;
    if (!p.isWithin(hostDir, host)) return null;
    return p.posix.join(guestRoot, p.split(p.relative(host, from: hostDir)).join('/'));
  }

  String toHost(String guest) {
    if (guest == guestRoot) return hostDir;
    if (guest.startsWith('$guestRoot/')) {
      return p.joinAll([hostDir, ...guest.substring(guestRoot.length + 1).split('/')]);
    }
    return guest;
  }

  // ---------- start / stop ----------
  Future<void> start({
    required String filePath,
    required BreakpointStore store,
    String args = '',
    bool stopOnEntry = false,
    RunPre pre = RunPre.none,
  }) async {
    await _closeSession();
    runId++;
    bps = store;
    hostDir = p.dirname(filePath);
    _filter = RunOutputFilter();
    _stream = DebugStream();
    _waiters.clear();
    _sentFiles.clear();
    _bpsDirty = false;
    exitCode = null;
    elapsed = null;
    needPkgs = '';
    stopReason = '';
    exceptionText = '';
    frames = <DebugFrame>[];
    locals = <DebugVar>[];
    globals = <DebugVar>[];
    selFrame = 0;
    for (final w in watches) {
      w.value = null;
      w.error = null;
    }
    terminal.write('\x1b[2J\x1b[3J\x1b[H');
    state = DebugState.starting;
    _notify();
    try {
      final py = await rootBundle.loadString('assets/debug/abtin_pydbg.py');
      final dir = Directory(p.join(Directory.systemTemp.path, 'abtin_run'));
      await dir.create(recursive: true);
      final adapter = File(p.join(dir.path, 'abtin_pydbg.py'));
      await adapter.writeAsString(py, flush: true);
      final runner = LangRunner(
        'python',
        'Python',
        'python3',
        'python3',
        'python3 -u /tmp/abtin_pydbg.py --root $guestRoot${stopOnEntry ? ' --entry' : ''} {f}',
        mb: 40,
      );
      // Alpine's /tmp is $PREFIX/alpine/tmp on the phone: copy the adapter there.
      final copy = r'mkdir -p "$PREFIX/alpine/tmp" && cp -f ' +
          CodeRunner.shq(adapter.path) +
          r' "$PREFIX/alpine/tmp/abtin_pydbg.py" || { echo "cannot install the debug adapter"; exit 5; }';
      final script = CodeRunner.buildScript(
        runner: runner,
        fileName: p.basename(filePath),
        args: args,
        pre: pre,
        beforeRun: copy,
      );
      final f = File(p.join(dir.path, 'debug_$runId.sh'));
      await f.writeAsString(script, flush: true);
      _sub ??= _native.events.listen(_onEvent);
      final s = await _native.start(hostDir, columns: _cols, rows: _rows);
      _id = s.id;
      await _native.writeLine(s.id, '. ${CodeRunner.shq(f.path)}');
      _sw
        ..reset()
        ..start();
    } catch (e) {
      _id = null;
      state = DebugState.error;
      terminal.write('\r\n[$e]\r\n');
      _notify();
    }
  }

  Future<void> stop() async {
    if (!active) return;
    final id = _id;
    // ask the adapter to exit by itself first (restores the terminal), then close the PTY
    if (id != null && state == DebugState.paused) {
      await _send(<String, dynamic>{'cmd': 'stop'});
    }
    await _closeSession();
    _sw.stop();
    elapsed = _sw.elapsed;
    terminal.write('\r\n\x1b[33m[debug stopped]\x1b[0m\r\n');
    state = DebugState.ended;
    exitCode = null;
    _notify();
  }

  Future<void> _closeSession() async {
    final id = _id;
    _id = null;
    if (id != null) await _native.close(id).catchError((_) {});
  }

  // ---------- terminal events ----------
  void _onEvent(Map<String, dynamic> e) {
    final id = _id;
    if (id == null || e['sessionId'] != id) return;
    switch (e['type']) {
      case 'output':
        final t = e['text'];
        if (t is String) {
          final plain = _stream.feed(t, _onMsg);
          final visible = _filter.feed(plain);
          if (visible.isNotEmpty) terminal.write(visible);
        }
        break;
      case 'exit':
        final rest = _stream.flush();
        if (rest.isNotEmpty) {
          final v = _filter.feed(rest);
          if (v.isNotEmpty) terminal.write(v);
        }
        _finish(e['exitCode']);
        break;
    }
  }

  void _finish(Object? code) {
    _sw.stop();
    elapsed = _sw.elapsed;
    _id = null;
    if (_filter.needAlpine) {
      state = DebugState.needAlpine;
    } else if (_filter.need != null) {
      needPkgs = _filter.need!;
      state = DebugState.needInstall;
    } else {
      if (!_filter.started) terminal.write(_filter.unstarted);
      if (state != DebugState.ended) {
        exitCode ??= _filter.exitCode ?? (code is int ? code : null);
        state = DebugState.ended;
      }
    }
    _notify();
  }

  // ---------- adapter messages ----------
  void _onMsg(String json) {
    Map<String, dynamic> m;
    try {
      final d = jsonDecode(json);
      if (d is! Map) return;
      m = Map<String, dynamic>.from(d);
    } catch (_) {
      return;
    }
    switch (m['e']) {
      case 'ready':
        _sendAllBps();
        unawaited(_send(<String, dynamic>{'cmd': 'run'}));
        state = DebugState.running;
        _notify();
        break;
      case 'stopped':
        _applyStop(m);
        break;
      case 'vars':
        locals = DebugVar.list(m['locals']);
        globals = DebugVar.list(m['globals']);
        _notify();
        break;
      case 'children':
        final w = _waiters.remove((m['id'] as num?)?.toInt());
        if (w != null) w(m);
        break;
      case 'result':
        final w = _waiters.remove((m['id'] as num?)?.toInt());
        if (w != null) w(m);
        break;
      case 'bps':
        final file = toHost('${m['file']}');
        final bad = m['bad'];
        if (bad is List) bps?.setUnverified(file, bad.whereType<num>().map((x) => x.toInt()));
        break;
      case 'exited':
        exitCode = (m['code'] as num?)?.toInt();
        state = DebugState.ended;
        frames = <DebugFrame>[];
        locals = <DebugVar>[];
        globals = <DebugVar>[];
        _notify();
        break;
      case 'error':
        terminal.write('\r\n\x1b[31m[debugger] ${m['msg']}\x1b[0m\r\n');
        break;
    }
  }

  void _applyStop(Map<String, dynamic> m) {
    stopReason = '${m['reason']}';
    exceptionText = '${m['exc'] ?? ''}';
    final fl = m['frames'];
    frames = <DebugFrame>[];
    if (fl is List) {
      for (final f in fl) {
        if (f is! Map) continue;
        frames.add(DebugFrame(
          (f['i'] as num?)?.toInt() ?? frames.length,
          '${f['name']}',
          toHost('${f['file']}'),
          (f['line'] as num?)?.toInt() ?? 0,
          f['mine'] == true,
        ));
      }
    }
    selFrame = 0;
    locals = DebugVar.list(m['locals']);
    globals = DebugVar.list(m['globals']);
    state = DebugState.paused;
    if (stopReason == 'exception') {
      terminal.write('\r\n\x1b[31m[exception] $exceptionText\x1b[0m\r\n');
    }
    _notify();
    _refreshWatches();
    final top = frames.isEmpty ? null : frames.first;
    if (top != null) onStopped?.call(top.file, top.line, stopReason);
  }

  // ---------- commands ----------
  Future<void> _send(Map<String, dynamic> cmd) async {
    final id = _id;
    if (id == null) return;
    try {
      await _native.writeLine(id, jsonEncode(cmd));
    } catch (e) {
      terminal.write('\r\n[debug send error] $e\r\n');
    }
  }

  /// The editor changed a breakpoint: tell the adapter right away when paused,
  /// otherwise at the next resume.
  void breakpointsChanged() {
    _bpsDirty = true;
    if (state == DebugState.paused) _sendAllBps();
  }

  void _sendAllBps() {
    final store = bps;
    if (store == null) return;
    _bpsDirty = false;
    final files = <String>{...store.files, ..._sentFiles};
    _sentFiles.clear();
    for (final host in files) {
      final guest = toGuest(host);
      if (guest == null) continue;
      final m = store.of(host);
      final lines = m.keys.take(300).toList()..sort();
      final conds = <String, String>{};
      for (final l in lines) {
        final c = m[l];
        if (c != null && c.isNotEmpty && conds.length < 20) conds['$l'] = c.length > 120 ? c.substring(0, 120) : c;
      }
      var msg = jsonEncode(<String, dynamic>{'cmd': 'bps', 'file': guest, 'lines': lines, 'conds': conds});
      if (msg.length > 3500) {
        msg = jsonEncode(<String, dynamic>{'cmd': 'bps', 'file': guest, 'lines': lines});
      }
      if (lines.isNotEmpty) _sentFiles.add(host);
      final id = _id;
      if (id != null) unawaited(_native.writeLine(id, msg).catchError((_) {}));
    }
  }

  /// cmd: continue | next | step | out
  Future<void> resume(String cmd) async {
    if (state != DebugState.paused) return;
    if (_bpsDirty) _sendAllBps();
    state = DebugState.running;
    _notify();
    await _send(<String, dynamic>{'cmd': cmd});
  }

  /// Ctrl+C: the adapter stops at the next Python line.
  Future<void> pause() async {
    final id = _id;
    if (id != null && state == DebugState.running) await _native.interrupt(id).catchError((_) {});
  }

  Future<void> sendStdin(String text) async {
    final id = _id;
    if (id != null && state == DebugState.running) await _native.writeLine(id, text).catchError((_) {});
  }

  Future<void> selectFrame(int i) async {
    if (state != DebugState.paused || i < 0 || i >= frames.length) return;
    selFrame = i;
    _notify();
    await _send(<String, dynamic>{'cmd': 'frame', 'i': i});
    final f = frames[i];
    onStopped?.call(f.file, f.line, 'frame');
    _refreshWatches();
  }

  Future<void> toggleExpand(DebugVar v) async {
    if (v.ref == 0) return;
    if (v.expanded) {
      v.expanded = false;
      _notify();
      return;
    }
    if (v.children != null) {
      v.expanded = true;
      _notify();
      return;
    }
    if (state != DebugState.paused || v.loading) return;
    v.loading = true;
    _notify();
    final id = ++_seq;
    _waiters[id] = (m) {
      v.children = DebugVar.list(m['items']);
      v.loading = false;
      v.expanded = true;
      _notify();
    };
    await _send(<String, dynamic>{'cmd': 'expand', 'id': id, 'ref': v.ref});
  }

  // ---------- watch / console ----------
  void addWatch(String expr) {
    final e = expr.trim();
    if (e.isEmpty) return;
    final w = DebugWatch(e);
    watches.add(w);
    _notify();
    if (state == DebugState.paused) _evalWatch(w);
  }

  void removeWatch(int i) {
    if (i < 0 || i >= watches.length) return;
    watches.removeAt(i);
    _notify();
  }

  void _refreshWatches() {
    if (state != DebugState.paused) return;
    for (final w in watches) {
      _evalWatch(w);
    }
  }

  void _evalWatch(DebugWatch w) {
    final id = ++_seq;
    _waiters[id] = (m) {
      if (m['ok'] == true && m['item'] is Map) {
        w.value = DebugVar.fromJson(Map<String, dynamic>.from(m['item'] as Map));
        w.error = null;
      } else {
        w.value = null;
        w.error = '${m['v']}';
      }
      _notify();
    };
    unawaited(_send(<String, dynamic>{'cmd': 'eval', 'id': id, 'expr': w.expr, 'frame': selFrame}));
  }

  /// Debug console: evaluates [expr] in the selected frame and prints the result.
  Future<void> evaluate(String expr) async {
    final e = expr.trim();
    if (e.isEmpty) return;
    terminal.write('\x1b[90m> $e\x1b[0m\r\n');
    if (state != DebugState.paused) {
      terminal.write('\x1b[33m(pause the program to evaluate)\x1b[0m\r\n');
      return;
    }
    final id = ++_seq;
    _waiters[id] = (m) {
      if (m['ok'] == true && m['item'] is Map) {
        final v = DebugVar.fromJson(Map<String, dynamic>.from(m['item'] as Map));
        terminal.write('\x1b[36m${v.value}\x1b[0m\r\n');
      } else {
        terminal.write('\x1b[31m${m['v']}\x1b[0m\r\n');
      }
      // statements may have changed variables
      unawaited(_send(<String, dynamic>{'cmd': 'frame', 'i': selFrame}));
      _refreshWatches();
    };
    await _send(<String, dynamic>{'cmd': 'eval', 'id': id, 'expr': e, 'frame': selFrame});
  }

  @override
  void dispose() {
    _disposed = true;
    _sub?.cancel();
    final id = _id;
    _id = null;
    if (id != null) unawaited(_native.close(id).catchError((_) {}));
    super.dispose();
  }
}
