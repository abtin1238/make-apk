package ir.abtin.sms

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Shared visual language: glass cards, glowing orbs, cylindrical keys (from the Abtin mockups / HTML prototype). */
val OrbBrush = Brush.linearGradient(listOf(Color(0xFF6F9BFF), Color(0xFF5B3CFF), Color(0xFFC21CFF)))
val CallGreen = Color(0xFF18D39A)
val CallBlue = Color(0xFF0D3A9E)
val MsgViolet = Color(0xFF4A28B8)
val Cyan = Color(0xFF6FD3FF)

private val GlassFill = Brush.verticalGradient(listOf(Color(0x6B2A40B4), Color(0x8C0B1550)))
private val GlassEdge = Brush.verticalGradient(listOf(Color(0x665082FF), Color(0x264E64D8)))

fun Modifier.glass(shape: Shape = RoundedCornerShape(24.dp), fill: Brush = GlassFill): Modifier =
    this.clip(shape).background(fill, shape).border(1.dp, GlassEdge, shape)

/** Alignment used for Persian copy inside the (forced LTR) layout: text is bidi-aware and sits on the left like the mockups. */
val FaStyle = TextStyle(textDirection = TextDirection.Content, textAlign = TextAlign.Left)

@Composable
fun BrandHeader(first: String, accent: String, subtitle: String, icon: ImageVector, onIcon: () -> Unit = {}) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp).padding(top = 12.dp, bottom = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(50.dp)) {
            Box(Modifier.fillMaxSize().clip(CircleShape).background(Brush.radialGradient(listOf(Color(0xFF2D5BFF), Color(0xFF0A1A6E))))
                .border(1.dp, p.line, CircleShape).clickable(onClick = onIcon), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(25.dp))
            }
            Box(Modifier.align(Alignment.BottomEnd).size(13.dp).clip(CircleShape).background(Color(0xFF18E06A)).border(2.dp, p.bg2, CircleShape))
        }
        Box(Modifier.padding(horizontal = 14.dp).width(1.dp).height(40.dp).background(p.line))
        Column {
            Row { Text(first + " ", color = p.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold); Text(accent, color = p.primary, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold) }
            Text(subtitle, color = p.sub, fontSize = 13.sp, style = FaStyle)
        }
    }
}

/** Sub-page header: glass back button + title (+ optional trailing content). */
@Composable
fun PageHeader(title: String, onBack: () -> Unit, trailing: @Composable RowScope.() -> Unit = {}) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, onBack)
        Text(title, color = p.text, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, style = FaStyle, modifier = Modifier.weight(1f).padding(horizontal = 14.dp))
        trailing()
    }
}

@Composable
fun GlowButton(label: String, icon: ImageVector?, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    val shape = RoundedCornerShape(50)
    Row(modifier.height(46.dp).shadow(10.dp, shape, ambientColor = Color(0xFF2F6BFF), spotColor = Color(0xFF2F6BFF)).clip(shape)
        .background(Brush.horizontalGradient(if (enabled) listOf(Color(0xFF2145D6), Color(0xFF4A6DFF)) else listOf(Color(0xFF28306A), Color(0xFF28306A))))
        .border(1.dp, Color(0x66A0B4FF), shape).clickable(enabled = enabled, onClick = onClick).padding(horizontal = 18.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(19.dp)); Spacer(Modifier.width(8.dp)) }
        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, style = FaStyle, maxLines = 1)
    }
}

/** Big hero card: title, subtitle, pill button on the left and artwork floating on the right. */
@Composable
fun HeroCard(title: String, sub: String, btn: String, btnIcon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier, art: @Composable BoxScope.() -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Box(modifier.fillMaxWidth().height(150.dp)) {
        Box(Modifier.fillMaxSize().glass(shape, Brush.linearGradient(listOf(Color(0x73893DFF), Color(0x5A2846DC)))))
        Column(Modifier.align(Alignment.CenterStart).padding(start = 16.dp).fillMaxWidth(.62f)) {
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, style = FaStyle, maxLines = 1)
            Text(sub, color = Color(0xFFB9C4FF), fontSize = 12.sp, style = FaStyle, modifier = Modifier.padding(top = 2.dp, bottom = 12.dp), maxLines = 1)
            GlowButton(btn, btnIcon, onClick)
        }
        Box(Modifier.align(Alignment.CenterEnd).fillMaxHeight().width(150.dp), content = art)
    }
}

@Composable
fun TileCard(title: String, sub: String, icon: ImageVector, iconTint: Color, from: Color, to: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(24.dp)
    Box(modifier.height(128.dp).glass(shape, Brush.linearGradient(listOf(from, to))).clickable(onClick = onClick)) {
        Box(Modifier.align(Alignment.TopEnd).padding(10.dp).size(32.dp).clip(CircleShape).background(Color(0xB31E2896)).border(1.dp, Color(0x4D96A5FF), CircleShape),
            contentAlignment = Alignment.Center) { Icon(Icons.Default.KeyboardArrowRight, null, tint = Color.White, modifier = Modifier.size(18.dp)) }
        Column(Modifier.align(Alignment.Center).padding(top = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = iconTint, modifier = Modifier.size(44.dp))
            Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, style = FaStyle.copy(textAlign = TextAlign.Center), modifier = Modifier.padding(top = 4.dp), maxLines = 1)
            Text(sub, color = Color(0xFFB3BDF0), fontSize = 11.sp, style = FaStyle.copy(textAlign = TextAlign.Center), maxLines = 1)
        }
    }
}

class RailItem(val icon: ImageVector, val selected: Boolean, val onClick: () -> Unit)

/** Vertical glass shortcut bar shown at the right of the hero. */
@Composable
fun RailBar(items: List<RailItem>, modifier: Modifier = Modifier) {
    val p = LocalPal.current
    Column(modifier.width(62.dp).glass(RoundedCornerShape(32.dp)).padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.forEach { it ->
            Box(Modifier.size(46.dp).clip(CircleShape)
                .background(if (it.selected) OrbBrush else Brush.linearGradient(listOf(Color(0x8C1E2882), Color(0x8C1E2882))), CircleShape)
                .border(1.dp, if (it.selected) Color(0x99C8B4FF) else Color(0x2E788CFF), CircleShape).clickable(onClick = it.onClick), contentAlignment = Alignment.Center) {
                Icon(it.icon, null, tint = if (it.selected) Color.White else Color(0xFFB9C4FF), modifier = Modifier.size(22.dp))
            }
        }
    }
}

/** Neon phone illustration: tilted phone + glowing orbits. kind 0 = contact+call, 1 = chat bubble. */
@Composable
fun PhoneArt(kind: Int, modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize()) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width; val h = size.height
            rotate(-24f, Offset(w / 2, h / 2)) {
                drawOval(Color(0xB36EBEFF), Offset(w * .02f, h * .30f), Size(w * 1.0f, h * .42f), style = Stroke(2.dp.toPx()))
                drawOval(Color(0x336EBEFF), Offset(w * .02f, h * .30f), Size(w * 1.0f, h * .42f), style = Stroke(7.dp.toPx()))
            }
            rotate(-14f, Offset(w / 2, h / 2)) {
                drawOval(Color(0xB3DC5AFF), Offset(-w * .04f, h * .46f), Size(w * 1.0f, h * .36f), style = Stroke(2.dp.toPx()))
                drawOval(Color(0x33DC5AFF), Offset(-w * .04f, h * .46f), Size(w * 1.0f, h * .36f), style = Stroke(7.dp.toPx()))
            }
        }
        val ph = RoundedCornerShape(20.dp)
        Box(Modifier.align(Alignment.Center).padding(end = 6.dp).width(78.dp).fillMaxHeight(.86f).graphicsLayer { rotationZ = 12f }
            .shadow(16.dp, ph, ambientColor = Color(0xFF4A8CFF), spotColor = Color(0xFF4A8CFF)).clip(ph)
            .background(Brush.linearGradient(listOf(Color(0xFF4D8DFF), Color(0xFF1534B8)))).border(3.dp, Color(0xFF7FB0FF), ph)) {
            Box(Modifier.align(Alignment.TopCenter).width(26.dp).height(6.dp).clip(RoundedCornerShape(bottomStart = 6.dp, bottomEnd = 6.dp)).background(Color(0xFF0A1450)))
            if (kind == 0) {
                Icon(Icons.Default.Person, null, tint = Color(0xFFEEF3FF), modifier = Modifier.align(Alignment.TopCenter).padding(top = 18.dp).size(40.dp))
                Box(Modifier.align(Alignment.BottomCenter).padding(bottom = 20.dp).size(38.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Color(0xFF4DFFB0), Color(0xFF0CA36A)))), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Call, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
        if (kind == 1) {
            val bs = RoundedCornerShape(18.dp)
            Box(Modifier.align(Alignment.Center).padding(end = 8.dp, bottom = 6.dp).graphicsLayer { rotationZ = -6f }.width(84.dp).height(58.dp)
                .shadow(14.dp, bs, ambientColor = Color(0xFF6EC8FF), spotColor = Color(0xFF6EC8FF)).clip(bs)
                .background(Brush.linearGradient(listOf(Color(0xFF8ED2FF), Color(0xFF3F7BFF)))).border(1.dp, Color(0x99FFFFFF), bs), contentAlignment = Alignment.Center) {
                Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { repeat(3) { Box(Modifier.size(9.dp).clip(CircleShape).background(Color.White)) } }
            }
        }
    }
}

/** Glass search field + filter button row used on the contacts home. */
@Composable
fun SearchRow(value: String, onChange: (String) -> Unit, placeholder: String, onFilter: () -> Unit, filterOn: Boolean = false) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.weight(1f).height(56.dp).glass(RoundedCornerShape(20.dp))) {
            androidx.compose.foundation.text.BasicTextField(value, onChange, singleLine = true,
                textStyle = TextStyle(color = p.text, fontSize = 15.sp, textDirection = TextDirection.Content, textAlign = TextAlign.Right),
                cursorBrush = androidx.compose.ui.graphics.SolidColor(p.primary), modifier = Modifier.fillMaxSize().padding(start = 52.dp, end = 16.dp),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.CenterEnd) {
                        if (value.isEmpty()) Text(placeholder, color = Color(0xFFA9B3EF), fontSize = 15.sp, style = FaStyle.copy(textAlign = TextAlign.Right))
                        inner()
                    }
                })
            Icon(Icons.Default.Search, null, tint = Cyan, modifier = Modifier.align(Alignment.CenterStart).padding(start = 14.dp).size(26.dp))
        }
        Box(Modifier.size(width = 60.dp, height = 56.dp).glass(RoundedCornerShape(18.dp), if (filterOn) OrbBrush else GlassFill).clickable(onClick = onFilter), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.FilterList, null, tint = if (filterOn) Color.White else Cyan, modifier = Modifier.size(26.dp))
        }
    }
}

/** Section title: coloured part + count, icon at the end. */
@Composable
fun ListHead(title: String, count: String, icon: ImageVector) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Color(0xFF7F8DFF), modifier = Modifier.size(26.dp))
        Spacer(Modifier.weight(1f))
        Text(count, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, style = FaStyle)
        Spacer(Modifier.width(6.dp))
        Text(title, color = Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold, style = FaStyle)
    }
}

// ------------------------------------------------------------------
// Cylindrical (capsule) keys: used by the dial pad instead of round buttons.
// ------------------------------------------------------------------
val CylinderShape = RoundedCornerShape(percent = 50)

/** Gives a composable the look of a glossy horizontal cylinder: vertical shading, rim light and a top highlight stripe. */
fun Modifier.cylinder(top: Color = Color(0xFF4F6BF0), mid: Color = Color(0xFF2B40B8), bottom: Color = Color(0xFF141E6A)): Modifier =
    this.shadow(7.dp, CylinderShape, ambientColor = Color(0xFF000020), spotColor = Color(0xFF000020))
        .clip(CylinderShape)
        .background(Brush.verticalGradient(0f to top, .5f to mid, 1f to bottom), CylinderShape)
        .border(1.dp, Brush.verticalGradient(listOf(Color(0x80FFFFFF), Color(0x14FFFFFF))), CylinderShape)
        .drawWithContent {
            drawContent()
            val inset = size.height * .42f
            drawRoundRect(Brush.verticalGradient(listOf(Color(0x59FFFFFF), Color.Transparent), startY = size.height * .06f, endY = size.height * .5f),
                topLeft = Offset(inset, size.height * .06f), size = Size(size.width - inset * 2, size.height * .42f), cornerRadius = CornerRadius(size.height * .21f))
        }

/** Small cylinder button with an icon (add-contact, hide-pad, backspace…). */
@Composable
fun CylinderIconBtn(icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier, tint: Color = Color.White) {
    Box(modifier.size(width = 64.dp, height = 44.dp).cylinder().clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Icon(icon, null, tint = tint, modifier = Modifier.size(22.dp)) }
    }
}
