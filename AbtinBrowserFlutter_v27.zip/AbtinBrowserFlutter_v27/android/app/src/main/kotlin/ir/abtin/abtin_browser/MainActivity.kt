package ir.abtin.abtin_browser

import android.os.CancellationSignal
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import ir.abtin.abtin_browser.v2ray.V2rayConst
import ir.abtin.abtin_browser.v2ray.V2rayDiag
import ir.abtin.abtin_browser.v2ray.V2rayTestService
import ir.abtin.abtin_browser.v2ray.V2rayVpnService
import ir.abtin.abtin_browser.dns.DnsVpnService
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import android.net.Uri
import android.provider.DocumentsContract
import android.database.Cursor
import android.os.Build
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.nio.charset.Charset
import androidx.core.content.ContextCompat
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CredentialManagerCallback
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.ClearCredentialException
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

/**
 * One-tap Google sign-in: Android's Credential Manager lists the Google accounts on the phone,
 * the user taps one and Google itself shows (and controls) the consent / confirmation UI.
 * The app never sees a password, and the ID token stays in memory on the Dart side.
 */
class MainActivity : FlutterActivity() {
    private var pendingFolderResult: MethodChannel.Result? = null
    private val folderPickerRequest = 4817
    private val projectRoots = java.util.concurrent.ConcurrentHashMap<String, File>()
    private val projectOrder = ArrayList<String>()
    private val serverPool = java.util.concurrent.Executors.newCachedThreadPool()
    @Volatile private var localProjectServer: ServerSocket? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        // Project copies from a previous run are unreachable (new server port): clean them up.
        serverPool.execute { File(cacheDir, "local_web_projects").deleteRecursively() }
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "abtin/local_project").setMethodCallHandler { call, result ->
            when (call.method) {
                "pickProjectFolder" -> {
                    if (pendingFolderResult != null) {
                        result.error("picker_busy", "A folder selection is already in progress", null)
                    } else {
                        pendingFolderResult = result
                        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                        }
                        startActivityForResult(intent, folderPickerRequest)
                    }
                }
                else -> result.notImplemented()
            }
        }
        setupV2ray(flutterEngine)
        setupDns(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "abtin/google").setMethodCallHandler { call, result ->
            when (call.method) {
                "signIn" -> signIn(call.argument<String>("clientId") ?: "", result)
                "signOut" -> signOut(result)
                else -> result.notImplemented()
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == dnsRequest) {
            val pending = pendingDnsStart
            pendingDnsStart = null
            if (resultCode == RESULT_OK && pending != null) ContextCompat.startForegroundService(this, pending)
            else dnsChannel?.invokeMethod("state", mapOf("on" to false, "error" to "vpn_denied"))
            return
        }
        if (requestCode == v2rayRequest) {
            val pending = pendingV2rayStart
            pendingV2rayStart = null
            if (resultCode == RESULT_OK && pending != null) {
                launchV2ray(pending)
            } else {
                v2raySink?.success(mapOf("type" to "state", "state" to "error", "error" to "vpn_denied"))
            }
            return
        }
        if (requestCode != folderPickerRequest) return
        val callback = pendingFolderResult ?: return
        pendingFolderResult = null
        val treeUri = data?.data
        if (resultCode != RESULT_OK || treeUri == null) {
            callback.success(null)
            return
        }
        try {
            val flags = (data?.flags ?: 0) and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            contentResolver.takePersistableUriPermission(treeUri, flags)
        } catch (_: Exception) { }
        // Copy on a background thread so a big project does not freeze the UI.
        serverPool.execute {
            try {
                val id = UUID.randomUUID().toString().replace("-", "").take(12)
                val rootDir = File(File(cacheDir, "local_web_projects"), id)
                if (!rootDir.mkdirs() && !rootDir.isDirectory) throw IllegalStateException("Cannot create project cache")
                copyDocumentTree(treeUri, rootDir, intArrayOf(0))
                val canonical = rootDir.canonicalFile
                val port = ensureLocalServer()
                registerProject(id, canonical)
                val index = findProjectEntry(canonical)
                // No index.html: open the folder itself and the server shows a file listing.
                val rel = if (index == null) "" else
                    index.relativeTo(canonical).invariantSeparatorsPath.split("/").joinToString("/") { Uri.encode(it) }
                val url = "http://127.0.0.1:$port/$id/$rel"
                runOnUiThread { callback.success(url) }
            } catch (e: Exception) {
                runOnUiThread { callback.error("project_open_failed", e.message ?: "Could not open project folder", null) }
            }
        }
    }

    @Synchronized private fun registerProject(id: String, root: File) {
        projectRoots[id] = root
        projectOrder.add(id)
        // Several projects can be open in different tabs; keep the 5 newest, delete older copies.
        while (projectOrder.size > 5) {
            val old = projectOrder.removeAt(0)
            projectRoots.remove(old)?.let { serverPool.execute { it.deleteRecursively() } }
        }
    }

    private fun copyDocumentTree(treeUri: Uri, targetDir: File, counter: IntArray) {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(
            treeUri, DocumentsContract.getDocumentId(treeUri)
        )
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                val id = cursor.getString(0)
                val rawName = cursor.getString(1) ?: "file"
                val name = rawName.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(180).ifBlank { "file" }
                val mime = cursor.getString(2)
                val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    // Dependency / VCS folders would blow the file limit and are never part of a page.
                    if (name == ".git" || name == "node_modules") continue
                    if (++counter[0] > 5000) throw IllegalArgumentException("Project contains too many files (limit 5000)")
                    val childDir = File(targetDir, name)
                    if (!childDir.mkdirs() && !childDir.isDirectory) throw IllegalStateException("Cannot create $name")
                    copyDocumentTree(childUri, childDir, counter)
                } else {
                    if (++counter[0] > 5000) throw IllegalArgumentException("Project contains too many files (limit 5000)")
                    val out = File(targetDir, name)
                    contentResolver.openInputStream(childUri)?.use { input ->
                        FileOutputStream(out).use { output -> input.copyTo(output, 256 * 1024) }
                    } ?: throw IllegalStateException("Cannot read $name")
                }
            }
        } ?: throw IllegalStateException("Cannot read selected folder")
    }

    @Synchronized private fun ensureLocalServer(): Int {
        localProjectServer?.let { if (!it.isClosed) return it.localPort }
        val server = ServerSocket(0, 50, java.net.InetAddress.getByName("127.0.0.1"))
        localProjectServer = server
        Thread({
            while (!server.isClosed) {
                try {
                    val client = server.accept()
                    serverPool.execute { serveLocalProjectRequest(client) }
                } catch (_: Exception) { }
            }
        }, "abtin-local-project-server").apply { isDaemon = true; start() }
        return server.localPort
    }

    // URL layout: http://127.0.0.1:<port>/<projectId>/<path inside the project>
    private fun serveLocalProjectRequest(socket: Socket) {
        socket.use { client ->
            try {
                client.soTimeout = 10000
                val reader = client.getInputStream().bufferedReader(Charset.forName("UTF-8"))
                val request = reader.readLine() ?: return
                val parts = request.split(" ")
                var range: String? = null
                while (true) {
                    val line = reader.readLine() ?: break
                    if (line.isEmpty()) break
                    if (line.startsWith("range:", ignoreCase = true)) range = line.substring(6).trim()
                }
                if (parts.size < 2 || (parts[0] != "GET" && parts[0] != "HEAD")) {
                    sendBytes(client, 405, "text/plain; charset=utf-8", "Method Not Allowed".toByteArray(), false)
                    return
                }
                val headOnly = parts[0] == "HEAD"
                val rawPath = parts[1].substringBefore('?').substringBefore('#')
                val decoded = Uri.decode(rawPath).removePrefix("/")
                val projectId = decoded.substringBefore('/')
                val rel = decoded.substringAfter('/', "")
                val root = projectRoots[projectId]
                if (root == null) {
                    sendBytes(client, 404, "text/plain; charset=utf-8", "Not Found".toByteArray(), headOnly)
                    return
                }
                val file = File(root, rel).canonicalFile
                if (!file.toPath().startsWith(root.toPath()) || !file.exists()) {
                    sendBytes(client, 404, "text/plain; charset=utf-8", "Not Found".toByteArray(), headOnly)
                    return
                }
                if (file.isDirectory) {
                    if (!rawPath.endsWith("/")) { // keep relative URLs inside the folder working
                        sendBytes(client, 301, "text/plain", ByteArray(0), true, "Location: $rawPath/\r\n")
                        return
                    }
                    val idx = listOf("index.html", "index.htm").map { File(file, it) }.firstOrNull { it.isFile }
                    if (idx != null) serveFile(client, idx, headOnly, range)
                    else sendBytes(client, 200, "text/html; charset=utf-8", directoryListing(file, root, rel).toByteArray(Charsets.UTF_8), headOnly)
                    return
                }
                serveFile(client, file, headOnly, range)
            } catch (_: Exception) {
                try { sendBytes(client, 500, "text/plain", "Internal Server Error".toByteArray(), false) } catch (_: Exception) { }
            }
        }
    }

    private fun serveFile(client: Socket, file: File, headOnly: Boolean, range: String?) {
        val out = client.getOutputStream()
        val len = file.length()
        var start = 0L
        var end = len - 1
        var status = 200
        if (range != null && len > 0 && range.startsWith("bytes=", ignoreCase = true)) {
            val spec = range.substring(6).split(",")[0].trim()
            val a = spec.substringBefore('-').trim()
            val b = spec.substringAfter('-', "").trim()
            try {
                if (a.isEmpty()) start = maxOf(0L, len - b.toLong())
                else { start = a.toLong(); if (b.isNotEmpty()) end = minOf(b.toLong(), len - 1) }
                if (start > end || start >= len) {
                    writeHead(out, 416, "text/plain", 0, "Content-Range: bytes */$len\r\n")
                    out.flush()
                    return
                }
                status = 206
            } catch (_: NumberFormatException) { start = 0L; end = len - 1 }
        }
        val count = end - start + 1
        writeHead(out, status, mimeFor(file.extension.lowercase()), maxOf(0L, count),
            if (status == 206) "Content-Range: bytes $start-$end/$len\r\n" else "")
        if (!headOnly && count > 0) {
            java.io.RandomAccessFile(file, "r").use { raf ->
                raf.seek(start)
                var remaining = count
                val buf = ByteArray(64 * 1024)
                while (remaining > 0) {
                    val n = raf.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                    if (n < 0) break
                    out.write(buf, 0, n)
                    remaining -= n
                }
            }
        }
        out.flush()
    }

    private fun sendBytes(socket: Socket, status: Int, mime: String, body: ByteArray, headOnly: Boolean, extra: String = "") {
        val out = socket.getOutputStream()
        writeHead(out, status, mime, body.size.toLong(), extra)
        if (!headOnly && body.isNotEmpty()) out.write(body)
        out.flush()
    }

    private fun writeHead(out: java.io.OutputStream, status: Int, mime: String, length: Long, extra: String = "") {
        val reason = when (status) {
            200 -> "OK"; 206 -> "Partial Content"; 301 -> "Moved Permanently"; 404 -> "Not Found"
            405 -> "Method Not Allowed"; 416 -> "Range Not Satisfiable"; else -> "Internal Server Error"
        }
        // No CORS header on purpose: only the project's own pages (same origin) may read its files.
        val head = "HTTP/1.1 $status $reason\r\nContent-Type: $mime\r\nContent-Length: $length\r\n" +
            "Accept-Ranges: bytes\r\nCache-Control: no-cache\r\nConnection: close\r\n" +
            "X-Content-Type-Options: nosniff\r\n$extra\r\n"
        out.write(head.toByteArray(Charsets.UTF_8))
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun directoryListing(dir: File, root: File, rel: String): String {
        val items = (dir.listFiles() ?: emptyArray()).sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
        val sb = StringBuilder()
        sb.append("<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'>")
        sb.append("<title>").append(esc("/" + rel.trimEnd('/'))).append("</title>")
        sb.append("<style>:root{color-scheme:dark light}body{margin:0;padding:16px;font:15px system-ui,sans-serif;background:#111827;color:#e5e7eb}")
        sb.append("h1{font-size:15px;color:#93c5fd;overflow-wrap:anywhere}a{display:block;padding:10px 4px;color:#e5e7eb;text-decoration:none;border-bottom:1px solid #1f2937;overflow-wrap:anywhere}small{color:#9ca3af;float:right}</style>")
        sb.append("<h1>").append(esc("/" + rel.trimEnd('/'))).append("</h1>")
        if (dir.canonicalFile != root.canonicalFile) sb.append("<a href='../'>⬆ ..</a>")
        for (f in items) {
            val n = esc(f.name)
            val href = Uri.encode(f.name) + if (f.isDirectory) "/" else ""
            sb.append("<a href='").append(href).append("'>").append(if (f.isDirectory) "📁 " else "📄 ").append(n)
            if (f.isFile) sb.append("<small>").append(f.length() / 1024).append(" KB</small>")
            sb.append("</a>")
        }
        if (items.isEmpty()) sb.append("<p>(empty)</p>")
        return sb.toString()
    }

    private fun mimeFor(ext: String): String = when (ext) {
        "html", "htm", "xhtml" -> "text/html; charset=utf-8"
        "css" -> "text/css; charset=utf-8"
        "js", "mjs", "cjs" -> "text/javascript; charset=utf-8"
        "json", "map" -> "application/json; charset=utf-8"
        "webmanifest" -> "application/manifest+json; charset=utf-8"
        "svg" -> "image/svg+xml"
        "xml" -> "text/xml; charset=utf-8"
        "txt", "log", "ini", "yml", "yaml" -> "text/plain; charset=utf-8"
        "md", "markdown" -> "text/markdown; charset=utf-8"
        "csv" -> "text/csv; charset=utf-8"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "avif" -> "image/avif"
        "bmp" -> "image/bmp"
        "ico" -> "image/x-icon"
        "woff" -> "font/woff"
        "woff2" -> "font/woff2"
        "ttf" -> "font/ttf"
        "otf" -> "font/otf"
        "mp4", "m4v" -> "video/mp4"
        "webm" -> "video/webm"
        "ogv" -> "video/ogg"
        "mov" -> "video/quicktime"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "ogg", "oga" -> "audio/ogg"
        "wav" -> "audio/wav"
        "flac" -> "audio/flac"
        "pdf" -> "application/pdf"
        "wasm" -> "application/wasm"
        "zip" -> "application/zip"
        else -> "application/octet-stream"
    }

    private fun findProjectEntry(root: File): File? {
        val direct = listOf(File(root, "index.html"), File(root, "index.htm")).firstOrNull { it.isFile }
        if (direct != null) return direct
        // Common archive layout: the selected folder contains one project directory.
        val dirs = root.listFiles()?.filter { it.isDirectory } ?: emptyList()
        if (dirs.size == 1) return findProjectEntry(dirs[0])
        return null
    }

    // ---- v2ray: system-wide VPN. The service and the core live in the :v2ray process (see v2ray/*.kt) ----
    private var v2raySink: EventChannel.EventSink? = null
    private var pendingV2rayStart: Intent? = null
    private val v2rayRequest = 4818
    private var v2rayReceiverOn = false
    @Volatile private var v2rayLastStopMs = 0L

    /** The :v2ray process kills itself after a stop (fresh Go runtime). A start must wait until it is gone. */
    private fun launchV2ray(intent: Intent) {
        fun go() {
            try {
                ContextCompat.startForegroundService(this, intent)
            } catch (e: Exception) {
                // e.g. "process is bad": Android blocked the :v2ray process after repeated crashes. Report a short key, not a stack trace.
                val bad = (e.message ?: "").contains("process is bad")
                v2raySink?.success(mapOf("type" to "state", "state" to "error", "error" to (if (bad) "process_bad" else (e.message ?: "start_failed").take(300))))
            }
        }
        val wait = 2500L - (android.os.SystemClock.elapsedRealtime() - v2rayLastStopMs)
        if (wait <= 0L) {
            go()
        } else {
            v2raySink?.success(mapOf("type" to "state", "state" to "connecting", "error" to ""))
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ go() }, wait)
        }
    }

    private val v2rayReceiver = object : BroadcastReceiver() {
        @Suppress("DEPRECATION")
        override fun onReceive(context: Context?, intent: Intent?) {
            val extras = intent?.extras ?: return
            val m = HashMap<String, Any?>()
            for (k in extras.keySet()) m[k] = extras.get(k)
            if (m["type"] == "state") {
                applyJvmProxy(m["state"] == "connected")
                if (m["state"] == "disconnected" || m["state"] == "error") v2rayLastStopMs = android.os.SystemClock.elapsedRealtime()
            }
            v2raySink?.success(m)
        }
    }

    /** Java sockets of this process (downloads of the engine plugin) follow the tunnel's local SOCKS inbound while connected. */
    private fun applyJvmProxy(on: Boolean) {
        if (on) {
            System.setProperty("socksProxyHost", "127.0.0.1")
            System.setProperty("socksProxyPort", V2rayConst.SOCKS_PORT.toString())
        } else {
            System.clearProperty("socksProxyHost")
            System.clearProperty("socksProxyPort")
        }
    }

    private var dnsChannel: MethodChannel? = null
    private var pendingDnsStart: Intent? = null
    private val dnsRequest = 4819

    private fun setupDns(engine: FlutterEngine) {
        val ch = MethodChannel(engine.dartExecutor.binaryMessenger, "abtin/dns")
        dnsChannel = ch
        DnsVpnService.listener = { on, err -> ch.invokeMethod("state", mapOf("on" to on, "error" to err)) }
        ch.setMethodCallHandler { call, result ->
            when (call.method) {
                "start" -> {
                    val intent = Intent(this, DnsVpnService::class.java)
                        .setAction(DnsVpnService.ACTION_START)
                        .putExtra("servers", call.argument<String>("servers") ?: "")
                    val prepare = VpnService.prepare(this)
                    if (prepare != null) { pendingDnsStart = intent; startActivityForResult(prepare, dnsRequest) }
                    else ContextCompat.startForegroundService(this, intent)
                    result.success(true)
                }
                "stop" -> {
                    if (DnsVpnService.running) startService(Intent(this, DnsVpnService::class.java).setAction(DnsVpnService.ACTION_STOP))
                    result.success(true)
                }
                "query" -> result.success(mapOf("on" to DnsVpnService.running, "error" to DnsVpnService.lastError))
                else -> result.notImplemented()
            }
        }
    }

    private fun setupV2ray(engine: FlutterEngine) {
        if (!v2rayReceiverOn) {
            ContextCompat.registerReceiver(this, v2rayReceiver, IntentFilter(V2rayConst.ACTION_EVENT), ContextCompat.RECEIVER_NOT_EXPORTED)
            v2rayReceiverOn = true
        }
        EventChannel(engine.dartExecutor.binaryMessenger, "abtin/v2ray/events").setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) { v2raySink = events }
            override fun onCancel(arguments: Any?) { v2raySink = null }
        })
        MethodChannel(engine.dartExecutor.binaryMessenger, "abtin/v2ray").setMethodCallHandler { call, result ->
            when (call.method) {
                "start" -> if (v2rayCoreMissing(result)) Unit else startV2ray(call, result)
                "stop" -> {
                    v2rayLastStopMs = android.os.SystemClock.elapsedRealtime()
                    sendBroadcast(Intent(V2rayConst.ACTION_STOP).setPackage(packageName))
                    result.success(true)
                }
                "query" -> {
                    sendBroadcast(Intent(V2rayConst.ACTION_QUERY).setPackage(packageName))
                    result.success(true)
                }
                "diag" -> serverPool.execute {
                    val text = try { V2rayDiag.report(this) } catch (t: Throwable) { "diag failed: " + t.javaClass.simpleName }
                    runOnUiThread { result.success(text) }
                }
                "ping" -> if (v2rayCoreMissing(result)) Unit else {
                    try {
                        val id = call.argument<String>("id") ?: ""
                        val config = call.argument<String>("config") ?: ""
                        val f = File(filesDir, "v2ray_test_" + id.replace(Regex("[^A-Za-z0-9_-]"), "") + ".json")
                        f.writeText(config)
                        startService(
                            Intent(this, V2rayTestService::class.java)
                                .putExtra("id", id)
                                .putExtra("path", f.absolutePath)
                                .putExtra("url", call.argument<String>("url") ?: "https://www.gstatic.com/generate_204")
                        )
                        result.success(true)
                    } catch (e: Exception) {
                        result.error("ping_failed", e.message, null)
                    }
                }
                else -> result.notImplemented()
            }
        }
    }

    /** libgojni.so (Xray core) is only bundled for the ABIs it was copied for (see android/app/src/main/jniLibs). Other ABIs run without v2ray. */
    private fun v2rayCoreMissing(result: MethodChannel.Result): Boolean {
        if (File(applicationInfo.nativeLibraryDir, "libgojni.so").exists()) return false
        result.error("unsupported_abi", "v2ray core is not included in this build (CPU: " + (Build.SUPPORTED_ABIS.firstOrNull() ?: "?") + ")", null)
        return true
    }

    private fun startV2ray(call: MethodCall, result: MethodChannel.Result) {
        val config = call.argument<String>("config")
        if (config.isNullOrBlank()) {
            result.error("no_config", "empty config", null)
            return
        }
        try {
            File(filesDir, V2rayConst.CONFIG_FILE).writeText(config)
        } catch (e: Exception) {
            result.error("write_failed", e.message, null)
            return
        }
        val intent = Intent(this, V2rayVpnService::class.java)
            .setAction(V2rayConst.ACTION_START)
            .putExtra("name", call.argument<String>("name") ?: "VPN")
            .putExtra("mtu", call.argument<Int>("mtu") ?: 1500)
            .putExtra("ipv6", call.argument<Boolean>("ipv6") ?: true)
            .putExtra("bypassLan", call.argument<Boolean>("bypassLan") ?: true)
            .putExtra("dns", call.argument<String>("dns") ?: "8.8.8.8")
            .putExtra("skip", call.argument<String>("skip") ?: "")
        val prepare = VpnService.prepare(this)
        if (prepare != null) {
            pendingV2rayStart = intent
            startActivityForResult(prepare, v2rayRequest)
        } else {
            launchV2ray(intent)
        }
        result.success(true)
    }

    override fun onDestroy() {
        DnsVpnService.listener = null
        if (v2rayReceiverOn) {
            try { unregisterReceiver(v2rayReceiver) } catch (_: Exception) {}
            v2rayReceiverOn = false
        }
        super.onDestroy()
    }

    private fun signIn(clientId: String, result: MethodChannel.Result) {
        if (clientId.isBlank()) {
            result.error("no_client_id", "Web client ID is not set", null)
            return
        }
        val cm = CredentialManager.create(this)
        // 1) One Tap: account list sheet with every Google account on the phone (user taps one).
        val oneTap = GetGoogleIdOption.Builder()
            .setServerClientId(clientId)
            .setFilterByAuthorizedAccounts(false)
            .setAutoSelectEnabled(false)
            .build()
        request(cm, GetCredentialRequest.Builder().addCredentialOption(oneTap).build(), result) { e ->
            // 2) No account offered (never used here / sheet unavailable) -> the full "Sign in with Google" chooser.
            if (e is NoCredentialException) {
                val full = GetSignInWithGoogleOption.Builder(clientId).build()
                request(cm, GetCredentialRequest.Builder().addCredentialOption(full).build(), result, null)
            } else {
                fail(result, e)
            }
        }
    }

    private fun request(
        cm: CredentialManager, req: GetCredentialRequest, result: MethodChannel.Result,
        onError: ((GetCredentialException) -> Unit)?,
    ) {
        cm.getCredentialAsync(this, req, CancellationSignal(), ContextCompat.getMainExecutor(this),
            object : CredentialManagerCallback<GetCredentialResponse, GetCredentialException> {
                override fun onResult(r: GetCredentialResponse) {
                    val c = r.credential
                    if (c is CustomCredential && c.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                        try {
                            val g = GoogleIdTokenCredential.createFrom(c.data)
                            result.success(mapOf(
                                "idToken" to g.idToken, "email" to g.id,
                                "name" to (g.displayName ?: ""), "photo" to (g.profilePictureUri?.toString() ?: ""),
                            ))
                        } catch (e: GoogleIdTokenParsingException) {
                            result.error("parse", e.message, null)
                        }
                    } else {
                        result.error("unsupported", "Unexpected credential type", null)
                    }
                }

                override fun onError(e: GetCredentialException) {
                    if (onError != null) onError(e) else fail(result, e)
                }
            })
    }

    private fun fail(result: MethodChannel.Result, e: GetCredentialException) {
        when (e) {
            is GetCredentialCancellationException -> result.error("cancelled", "Cancelled", null)
            is NoCredentialException -> result.error("no_account", "No Google account on this phone", null)
            else -> result.error("failed", e.message ?: e.javaClass.simpleName, null)
        }
    }

    private fun signOut(result: MethodChannel.Result) {
        CredentialManager.create(this).clearCredentialStateAsync(
            ClearCredentialStateRequest(), CancellationSignal(), ContextCompat.getMainExecutor(this),
            object : CredentialManagerCallback<Void?, ClearCredentialException> {
                override fun onResult(r: Void?) = result.success(true)
                override fun onError(e: ClearCredentialException) = result.success(false)
            })
    }
}
