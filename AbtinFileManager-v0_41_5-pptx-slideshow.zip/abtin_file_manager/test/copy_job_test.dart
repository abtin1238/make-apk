import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;
import 'package:abtin_file_manager/services/copy_job.dart';
import 'package:abtin_file_manager/services/fgs.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory tmp;
  setUp(() => tmp = Directory.systemTemp.createTempSync('abtin_cj_'));
  tearDown(() {
    CopyJob.bigBytes = 32 * 1024 * 1024;
    try { tmp.deleteSync(recursive: true); } catch (_) {}
  });

  test('a big job registers with the foreground service and releases it at the end', () async {
    CopyJob.bigBytes = 0; // every job counts as big
    final src = File(p.join(tmp.path, 'a.bin'))..writeAsBytesSync(List.filled(4096, 7));
    final dst = Directory(p.join(tmp.path, 'dst'))..createSync();
    final job = CopyJob(move: false);
    await job.run([src], dst.path, (_) async => null);
    expect(File(p.join(dst.path, 'a.bin')).lengthSync(), 4096);
    expect(job.finished, isTrue);
    expect(Fgs.active, isFalse);
  });

  test('holders are reference counted', () async {
    await Fgs.hold('x', 'one');
    await Fgs.hold('y', 'two');
    await Fgs.release('x');
    expect(Fgs.active, isTrue);
    await Fgs.release('y');
    expect(Fgs.active, isFalse);
  });
}
