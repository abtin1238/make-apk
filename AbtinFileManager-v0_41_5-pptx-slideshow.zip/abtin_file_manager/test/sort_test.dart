import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:abtin_file_manager/core/settings.dart';

void main() {
  late AppSettings s;
  setUp(() async {
    SharedPreferences.setMockInitialValues({});
    s = AppSettings();
    await s.load();
  });

  test('folders without an override use the global sort', () {
    s.setSort(2, false);
    expect(s.sortFor('/a'), (2, false));
  });

  test('per-folder sort overrides the global one and can be reset', () {
    s.setFolderSort('/a', 1, true);
    expect(s.sortFor('/a'), (1, true));
    expect(s.sortFor('/b'), (0, true));
    expect(s.hasFolderSort('/a'), isTrue);
    s.clearFolderSort('/a');
    expect(s.sortFor('/a'), (0, true));
  });

  test('per-folder sort survives a restart and follows renames / removal', () async {
    s.setFolderSort('/a', 3, false);
    s.setFolderSort('/a/sub', 1, true);
    s.renamePath('/a', '/z');
    expect(s.sortFor('/z'), (3, false));
    expect(s.sortFor('/z/sub'), (1, true));
    expect(s.hasFolderSort('/a'), isFalse);
    final s2 = AppSettings();
    await s2.load();
    expect(s2.sortFor('/z'), (3, false));
    s2.removePath('/z');
    expect(s2.folderSort, isEmpty);
  });
}
