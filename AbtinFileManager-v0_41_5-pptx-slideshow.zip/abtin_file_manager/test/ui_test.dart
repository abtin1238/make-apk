import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:abtin_file_manager/core/l10n.dart';
import 'package:abtin_file_manager/screens/remote_screen.dart';
import 'package:abtin_file_manager/widgets/adaptive_nav.dart';

Widget _app(Widget child, {bool rtl = false}) => MaterialApp(
      builder: (c, w) => Directionality(textDirection: rtl ? TextDirection.rtl : TextDirection.ltr, child: w!),
      home: child,
    );

const _items = [NavItem(Icons.home_rounded, 'Home'), NavItem(Icons.folder_rounded, 'Files'), NavItem(Icons.more_horiz_rounded, 'More')];

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues({});
    L.add('en', jsonEncode({
      'addServer': 'Add server', 'editServer': 'Edit server', 'protocol': 'Protocol', 'profName': 'Name', 'host': 'Server address',
      'port': 'Port', 'user': 'Username', 'password': 'Password', 'clientId': 'OAuth client ID', 'signIn': 'Sign in',
      'savePass': 'Save password', 'savePassSub': 'x', 'path': 'Path', 'privateKey': 'Private key', 'passOrPhrase': 'Password or passphrase',
      'domain': 'Domain', 'allowInsecure': 'Accept any certificate', 'allowInsecureSub': 'x', 'dropboxHint': 'd', 'gdriveHint': 'g', 'signOut': 'Sign out', 'signedIn': 'Signed in',
    }));
    L.use('en');
  });

  testWidgets('phone width shows a bottom NavigationBar', (t) async {
    t.view.physicalSize = const Size(400, 800);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.reset);
    int sel = 0;
    await t.pumpWidget(_app(StatefulBuilder(builder: (c, set) => AdaptiveNav(selected: sel, onSelect: (i) => set(() => sel = i), items: _items, body: Text('page $sel')))));
    expect(find.byType(NavigationBar), findsOneWidget);
    expect(find.byType(NavigationRail), findsNothing);
    await t.tap(find.text('Files'));
    await t.pump();
    expect(find.text('page 1'), findsOneWidget);
  });

  testWidgets('tablet width shows a NavigationRail on the start side', (t) async {
    t.view.physicalSize = const Size(1000, 700);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.reset);
    await t.pumpWidget(_app(AdaptiveNav(selected: 0, onSelect: (_) {}, items: _items, body: const Text('body')), rtl: false));
    expect(find.byType(NavigationRail), findsOneWidget);
    expect(find.byType(NavigationBar), findsNothing);
    expect(t.getTopLeft(find.byType(NavigationRail)).dx, lessThan(100));
    await t.pumpWidget(_app(AdaptiveNav(selected: 0, onSelect: (_) {}, items: _items, body: const Text('body')), rtl: true));
    await t.pump();
    expect(t.getTopRight(find.byType(NavigationRail)).dx, greaterThan(900)); // RTL: rail on the right
  });

  testWidgets('MaxWidth caps content on wide screens', (t) async {
    t.view.physicalSize = const Size(1400, 800);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.reset);
    await t.pumpWidget(_app(const MaxWidth(child: SizedBox.expand(key: Key('c')))));
    expect(t.getSize(find.byKey(const Key('c'))).width, 720);
  });

  testWidgets('server form changes with the protocol', (t) async {
    t.view.physicalSize = const Size(500, 1400);
    t.view.devicePixelRatio = 1;
    addTearDown(t.view.reset);
    await t.pumpWidget(_app(const ProfileEditScreen()));
    await t.pump();
    expect(find.text('Server address'), findsOneWidget);
    expect(find.text('OAuth client ID'), findsNothing);
    await t.tap(find.byType(DropdownButtonFormField<String>));
    await t.pumpAndSettle();
    await t.tap(find.text('Dropbox').last);
    await t.pumpAndSettle();
    expect(find.text('OAuth client ID'), findsOneWidget);
    expect(find.text('Server address'), findsNothing);
    expect(find.text('Sign in'), findsOneWidget);
  });
}
