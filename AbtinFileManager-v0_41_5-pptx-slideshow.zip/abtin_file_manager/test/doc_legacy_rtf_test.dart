import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/doc_legacy.dart';

void main() {
  test('RTF round-trips CP1252, Unicode and heading style', () {
    const text = 'Café € “quote” —\nمتن فارسی';
    final bytes = DocLegacy.buildRtf(text, headingLevels: const {0: 1});
    expect(latin1.decode(bytes).startsWith(r'{\rtf1\ansi\ansicpg1252'), isTrue);
    expect(DocLegacy.extractText(bytes), text);
    final paras = DocLegacy.extractFormatted(bytes);
    expect(paras.first.heading, 1);
    expect(paras.map((e) => e.text).join('\n'), text);
  });

  test('tab-separated rows round-trip as table cells', () {
    const text = 'Name\tValue\nA\t1';
    final bytes = DocLegacy.buildRtf(text);
    expect(DocLegacy.extractText(bytes), text);
  });

  test('DOCX export includes Heading style references', () {
    final zip =
        DocLegacy.buildDocx('Chapter\nBody', headingLevels: const {0: 1});
    expect(zip, isA<Uint8List>());
    expect(zip, isNotEmpty);
  });
}
