import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/dup_service.dart';

void main() {
  test('finds identical content under different names, ignores same-size different content', () async {
    final d = await Directory.systemTemp.createTemp('dup');
    File('${d.path}/a.bin').writeAsBytesSync(List.filled(200000, 7));
    Directory('${d.path}/sub').createSync();
    File('${d.path}/sub/b.dat').writeAsBytesSync(List.filled(200000, 7));
    final diff = List.filled(200000, 7)..[100000] = 8; // same size/head/tail, different middle
    File('${d.path}/c.bin').writeAsBytesSync(diff);
    final g = await DupService.scan(d.path);
    expect(g.length, 1);
    expect(g.first.files.length, 2);
    await d.delete(recursive: true);
  });
}
