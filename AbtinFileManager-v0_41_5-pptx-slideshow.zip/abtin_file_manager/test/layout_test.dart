import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/core/layouts.dart';
import 'package:abtin_file_manager/services/media_events.dart';

void main() {
  test('layout ids are unique and unknown ids fall back to classic', () {
    final ids = appLayouts.map((l) => l.id).toList();
    expect(ids.toSet().length, ids.length);
    expect(ids, containsAll(['classic', 'drawer', 'dashboard', 'rail', 'tabs']));
    expect(layoutById('nope').id, 'classic');
    expect(layoutById('rail').id, 'rail');
  });

  test('MediaEvents delivers deleted paths to every listener', () async {
    final a = MediaEvents.onDeleted.first;
    final b = MediaEvents.onDeleted.first;
    MediaEvents.deleted(['/x/1.jpg', '/x/2.jpg']);
    expect(await a, {'/x/1.jpg', '/x/2.jpg'});
    expect(await b, {'/x/1.jpg', '/x/2.jpg'});
  });
}
