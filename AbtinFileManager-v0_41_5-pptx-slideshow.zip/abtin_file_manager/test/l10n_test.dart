import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/core/l10n.dart';

Map<String, dynamic> _arb(String lang) => jsonDecode(File('assets/l10n/app_$lang.arb').readAsStringSync()) as Map<String, dynamic>;
Set<String> _keys(Map<String, dynamic> m) => m.keys.where((k) => !k.startsWith('@')).toSet();

void main() {
  final files = Directory('assets/l10n').listSync().whereType<File>().where((f) => f.path.endsWith('.arb')).toList();

  test('every ARB file has the same keys as English', () {
    final en = _keys(_arb('en'));
    for (final f in files) {
      final lang = RegExp(r'app_([A-Za-z_]+)\.arb').firstMatch(f.path)![1]!;
      final k = _keys(_arb(lang));
      expect(en.difference(k), isEmpty, reason: '$lang is missing keys');
      expect(k.difference(en), isEmpty, reason: '$lang has unknown keys');
    }
  });

  test('no empty values, placeholders match English', () {
    final en = _arb('en');
    final ph = RegExp(r'\{(\w+)\}');
    for (final f in files) {
      final lang = RegExp(r'app_([A-Za-z_]+)\.arb').firstMatch(f.path)![1]!;
      final m = _arb(lang);
      for (final k in _keys(en)) {
        final v = '${m[k]}';
        expect(v.trim(), isNotEmpty, reason: '$lang:$k');
        expect(ph.allMatches(v).map((x) => x[1]).toSet(), ph.allMatches('${en[k]}').map((x) => x[1]).toSet(), reason: '$lang:$k placeholders');
      }
      expect(m['@@locale'], lang);
      expect('${m['@@language_name']}', isNotEmpty);
    }
  });

  test('L.t falls back to English and to the key', () {
    L.add('en', jsonEncode({'a': 'A', 'b': 'B'}));
    L.add('xx', jsonEncode({'a': 'AA', '@@language_name': 'Test'}));
    L.use('xx');
    expect(L.t('a'), 'AA');
    expect(L.t('b'), 'B');
    expect(L.t('zzz'), 'zzz');
    expect(L.nameOf('xx'), 'Test');
    L.use('nope');
    expect(L.lang, 'en');
  });

  test('RTL languages and placeholder helper', () {
    L.add('en', jsonEncode({'hi': 'Hello {name}'}));
    L.lang = 'fa';
    expect(L.rtl, isTrue);
    L.lang = 'en';
    expect(L.rtl, isFalse);
    expect(L.tr('hi', {'name': 'Ali'}), 'Hello Ali');
  });
}
