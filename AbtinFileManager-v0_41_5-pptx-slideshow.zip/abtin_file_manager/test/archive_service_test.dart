import 'dart:io';
import 'package:archive/archive.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;
import 'package:abtin_file_manager/services/archive_service.dart';

void main() {
  late Directory tmp;
  setUp(() => tmp = Directory.systemTemp.createTempSync('abtin_test_'));
  tearDown(() {
    try { tmp.deleteSync(recursive: true); } catch (_) {}
  });

  test('isArchive recognises common extensions', () {
    for (final n in ['a.zip', 'a.RAR', 'a.7z', 'a.tar.gz', 'a.tgz', 'a.bz2', 'a.xz', 'a.apk', 'a.epub']) {
      expect(ArchiveService.isArchive(n), isTrue, reason: n);
    }
    expect(ArchiveService.isArchive('a.txt'), isFalse);
  });

  test('defaultFolderName strips double extensions', () {
    expect(ArchiveService.defaultFolderName('/x/photos.tar.gz'), 'photos');
    expect(ArchiveService.defaultFolderName('/x/photos.zip'), 'photos');
    expect(ArchiveService.defaultFolderName('/x/data.TAR.BZ2'), 'data');
  });

  test('extFor maps formats to extensions', () {
    expect(ArchiveService.extFor('zip'), '.zip');
    expect(ArchiveService.extFor('targz'), '.tar.gz');
    expect(ArchiveService.extFor('7z'), '.7z');
  });

  test('zip round trip reports progress up to 100%', () async {
    final src = Directory(p.join(tmp.path, 'src'))..createSync();
    File(p.join(src.path, 'a.txt')).writeAsStringSync('hello');
    Directory(p.join(src.path, 'sub')).createSync();
    File(p.join(src.path, 'sub', 'b.txt')).writeAsStringSync('world');
    final zip = p.join(tmp.path, 'out.zip');
    await ArchiveService.compressZip([src.path], zip);

    final dst = p.join(tmp.path, 'dst');
    final seen = <double>[];
    await ArchiveService.extract(zip, dst, onProgress: seen.add);
    expect(File(p.join(dst, 'src', 'a.txt')).readAsStringSync(), 'hello');
    expect(File(p.join(dst, 'src', 'sub', 'b.txt')).readAsStringSync(), 'world');
    expect(seen, isNotEmpty);
    expect(seen.last, 1.0);
  });

  test('zip-slip entries are ignored', () async {
    final a = Archive()
      ..addFile(ArchiveFile('../evil.txt', 3, [1, 2, 3]))
      ..addFile(ArchiveFile('ok/a.txt', 2, [65, 66]));
    final zip = File(p.join(tmp.path, 'bad.zip'))..writeAsBytesSync(ZipEncoder().encode(a)!);
    final dst = p.join(tmp.path, 'dst');
    await ArchiveService.extract(zip.path, dst);
    expect(File(p.join(tmp.path, 'evil.txt')).existsSync(), isFalse);
    expect(File(p.join(dst, 'ok', 'a.txt')).existsSync(), isTrue);
  });

  test('tar.gz extraction', () async {
    final a = Archive()..addFile(ArchiveFile('d/x.txt', 4, [1, 2, 3, 4]));
    final gz = GZipEncoder().encode(TarEncoder().encode(a))!;
    final f = File(p.join(tmp.path, 'x.tar.gz'))..writeAsBytesSync(gz);
    final dst = p.join(tmp.path, 'dst');
    await ArchiveService.extract(f.path, dst);
    expect(File(p.join(dst, 'd', 'x.txt')).readAsBytesSync(), [1, 2, 3, 4]);
  });

  test('corrupt file is rejected', () async {
    final f = File(p.join(tmp.path, 'junk.zip'))..writeAsBytesSync([0, 1, 2, 3, 4, 5, 6, 7]);
    expect(() => ArchiveService.extract(f.path, p.join(tmp.path, 'dst')), throwsA(isA<Exception>()));
  });

  test('volume names: first volume, isArchive, partTarget', () {
    expect(ArchiveService.firstVolume('/x/a.7z.003'), '/x/a.7z.001');
    expect(ArchiveService.firstVolume('/x/a.part02.rar'), '/x/a.part01.rar');
    expect(ArchiveService.firstVolume('/x/a.part7.rar'), '/x/a.part1.rar');
    expect(ArchiveService.firstVolume('/x/plain.zip'), '/x/plain.zip');
    for (final n in ['a.7z.001', 'a.zip.002', 'a.z01', 'a.r00', 'a.part1.rar']) {
      expect(ArchiveService.isArchive(n), isTrue, reason: n);
    }
    expect(ArchiveService.isArchive('movie.001'), isFalse);
    expect(ArchiveService.partTarget('/t/tmp.7z.002', '/t/tmp.7z', '/o/new.7z'), '/o/new.7z.002');
    expect(ArchiveService.partTarget('/t/tmp.z03', '/t/tmp.zip', '/o/new.zip'), '/o/new.z03');
  });

  test('selection matching: files and whole folders', () {
    expect(ArchiveService.matches('a/b.txt', null), isTrue);
    expect(ArchiveService.matches('a/b.txt', ['a/']), isTrue);
    expect(ArchiveService.matches('a/b.txt', ['a/b.txt']), isTrue);
    expect(ArchiveService.matches('ab/b.txt', ['a/']), isFalse);
    expect(ArchiveService.matches('a', ['a/']), isTrue);
    expect(ArchiveService.matches('a/c.txt', ['a/b.txt']), isFalse);
  });

  Archive sample() => Archive()
    ..addFile(ArchiveFile('d/x.txt', 4, [1, 2, 3, 4]))
    ..addFile(ArchiveFile('d/sub/y.txt', 2, [5, 6]))
    ..addFile(ArchiveFile('z.txt', 1, [9]));

  test('list + extract only the selected entries (tar.gz)', () async {
    final f = File(p.join(tmp.path, 's.tar.gz'))..writeAsBytesSync(GZipEncoder().encode(TarEncoder().encode(sample()))!);
    final l = await ArchiveService.list(f.path);
    expect(l.map((e) => e.name), containsAll(['d/x.txt', 'd/sub/y.txt', 'z.txt']));
    final dst = p.join(tmp.path, 'dst');
    final seen = <double>[];
    await ArchiveService.extract(f.path, dst, only: ['d/sub/', 'z.txt'], onProgress: seen.add);
    expect(File(p.join(dst, 'd', 'sub', 'y.txt')).existsSync(), isTrue);
    expect(File(p.join(dst, 'z.txt')).existsSync(), isTrue);
    expect(File(p.join(dst, 'd', 'x.txt')).existsSync(), isFalse);
    expect(seen.last, 1.0);
  });

  test('raw split volumes (.001 .002 …) are joined and extracted', () async {
    final bytes = GZipEncoder().encode(TarEncoder().encode(sample()))!;
    final base = p.join(tmp.path, 'v.tar.gz');
    final cut = bytes.length ~/ 3;
    File('$base.001').writeAsBytesSync(bytes.sublist(0, cut));
    File('$base.002').writeAsBytesSync(bytes.sublist(cut, cut * 2));
    File('$base.003').writeAsBytesSync(bytes.sublist(cut * 2));
    expect(ArchiveService.rawParts('$base.001').length, 3);
    final dst = p.join(tmp.path, 'dst');
    await ArchiveService.extract('$base.002', dst); // any part opens the set
    expect(File(p.join(dst, 'd', 'x.txt')).readAsBytesSync(), [1, 2, 3, 4]);
    expect(Directory(tmp.path).listSync().whereType<File>().any((f) => p.basename(f.path).startsWith('abtin_join_')), isFalse);
  });
}
