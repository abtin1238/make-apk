import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/remote/remote_fs.dart';
import 'package:abtin_file_manager/services/remote/webdav_fs.dart';

void main() {
  test('RPath join / parent / name', () {
    expect(RPath.join('/', 'a'), '/a');
    expect(RPath.join('/a', 'b'), '/a/b');
    expect(RPath.parent('/a/b'), '/a');
    expect(RPath.parent('/a'), '/');
    expect(RPath.name('/a/b/'), 'b');
    expect(RPath.segs('/a//b/'), ['a', 'b']);
  });

  test('profile json round trip keeps password only when asked', () {
    final p = RemoteProfile(id: '1', name: 'n', type: 'sftp', host: 'h', pass: 'secret', port: 22);
    expect(RemoteProfile.fromJson(p.toJson()).pass, '');
    p.savePass = true;
    expect(RemoteProfile.fromJson(p.toJson()).pass, 'secret');
  });

  test('WebDAV multistatus parsing skips the folder itself', () {
    const xml = '''<?xml version="1.0"?>
<d:multistatus xmlns:d="DAV:">
 <d:response><d:href>/dav/files/me/</d:href><d:propstat><d:prop><d:resourcetype><d:collection/></d:resourcetype></d:prop></d:propstat></d:response>
 <d:response><d:href>/dav/files/me/Photos/</d:href><d:propstat><d:prop><d:resourcetype><d:collection/></d:resourcetype></d:prop></d:propstat></d:response>
 <d:response><d:href>/dav/files/me/a%20b.txt</d:href><d:propstat><d:prop><d:resourcetype/><d:getcontentlength>12</d:getcontentlength><d:getlastmodified>Wed, 01 Jan 2025 10:00:00 GMT</d:getlastmodified></d:prop></d:propstat></d:response>
</d:multistatus>''';
    final l = WebDavFs.parseMultistatus(xml, '/dav/files/me/');
    expect(l.length, 2);
    expect(l[0].name, 'Photos');
    expect(l[0].dir, isTrue);
    expect(l[1].name, 'a b.txt');
    expect(l[1].size, 12);
    expect(l[1].modified?.year, 2025);
  });
}
