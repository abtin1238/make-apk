package ir.abtin.filemanager

import android.content.Context
import android.graphics.BitmapFactory
import android.os.Handler
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import com.tom_roush.pdfbox.text.TextPosition
import com.tom_roush.pdfbox.util.Matrix
import java.io.IOException
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDCheckBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDChoice
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDComboBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDListBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDNonTerminalField
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDRadioButton
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTextField
import com.tom_roush.pdfbox.text.PDFTextStripper
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import com.tom_roush.pdfbox.contentstream.operator.Operator
import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.cos.COSFloat
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSNumber
import com.tom_roush.pdfbox.cos.COSString
import com.tom_roush.pdfbox.pdfparser.PDFStreamParser
import com.tom_roush.pdfbox.pdfwriter.ContentStreamWriter
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.common.PDStream
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDColor
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB
import com.tom_roush.pdfbox.pdmodel.graphics.form.PDFormXObject
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.pdmodel.PDResources
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotation
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationMarkup
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationTextMarkup
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAppearanceDictionary
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAppearanceStream
import java.text.Normalizer
import java.util.Locale

/** PDF operations that keep the original vector content (PdfBox-Android). Channel: abtin/pdf */
object PdfNative {
    private var inited = false

    fun register(ctx: Context, messenger: BinaryMessenger, ui: Handler) {
        MethodChannel(messenger, "abtin/pdf").setMethodCallHandler { call, result ->
            Thread {
                try {
                    synchronized(this) {
                        if (!inited) {
                            PDFBoxResourceLoader.init(ctx.applicationContext)
                            inited = true
                        }
                    }
                    val r = handle(call)
                    ui.post { result.success(r) }
                } catch (e: Throwable) {
                    ui.post { result.error("ERR", e.message ?: e.toString(), null) }
                }
            }.start()
        }
    }

    private fun ints(c: MethodCall, k: String): List<Int> =
        (c.argument<List<Any>>(k) ?: emptyList()).map { (it as Number).toInt() }

    private fun handle(c: MethodCall): Any? {
        val src = c.argument<String>("src") ?: ""
        val dst = c.argument<String>("dst") ?: ""
        return when (c.method) {
            "merge" -> merge(c.argument<List<String>>("srcs")!!, dst)
            "extract" -> extract(src, dst, ints(c, "pages"))
            "rotate" -> rotate(src, dst, ints(c, "pages"), c.argument<Int>("deg") ?: 90)
            "text" -> text(src, c.argument<Int>("page") ?: 1)
            "search" -> search(src, c.argument<String>("q") ?: "")
            "fields" -> fields(src)
            "fill" -> fill(src, dst, c.argument<Map<String, Any?>>("values") ?: emptyMap())
            "stamp" -> stamp(src, dst, c.argument<Int>("page") ?: 1, c.argument<Int>("anchor") ?: 0,
                c.argument<Double>("w") ?: 0.25, c.argument<ByteArray>("png")!!)
            "isEncrypted" -> isEncrypted(src)
            "decrypt" -> decrypt(src, dst, c.argument<String>("password") ?: "")
            "encrypt" -> encrypt(src, dst, c.argument<String>("password") ?: "")
            "boxes" -> boxes(src, c.argument<Int>("page") ?: 1)
            "edit" -> edit(src, dst, ints(c, "order"), c.argument<List<Map<String, Any?>>>("ops") ?: emptyList())
            "markup" -> markup(src, dst, c.argument<Int>("page") ?: 1, c.argument<String>("kind") ?: "highlight",
                (c.argument<List<List<Double>>>("rects") ?: emptyList()), c.argument<Int>("r") ?: 255, c.argument<Int>("g") ?: 235, c.argument<Int>("b") ?: 59)
            "stampAt" -> stampAt(src, dst, c.argument<Int>("page") ?: 1, num(c, "x"), num(c, "y"), num(c, "w"), c.argument<ByteArray>("png")!!)
            else -> throw UnsupportedOperationException(c.method)
        }
    }

    private fun num(c: MethodCall, k: String): Float = (c.argument<Number>(k) ?: 0).toFloat()
    private fun isBadPassword(e: Throwable) = e is IOException && e.javaClass.simpleName == "InvalidPasswordException"

    private fun isEncrypted(src: String): Boolean = try {
        PDDocument.load(File(src)).close()
        false
    } catch (e: IOException) {
        if (isBadPassword(e)) true else throw e
    }

    /** false = wrong password */
    private fun decrypt(src: String, dst: String, pw: String): Boolean {
        val doc = try { PDDocument.load(File(src), pw) } catch (e: IOException) {
            if (isBadPassword(e)) return false else throw e
        }
        try {
            doc.isAllSecurityToBeRemoved = true
            doc.save(File(dst))
        } finally {
            doc.close()
        }
        return true
    }

    /** AES-256, same password for opening and owner rights */
    private fun encrypt(src: String, dst: String, pw: String): Boolean {
        val doc = PDDocument.load(File(src))
        try {
            val policy = StandardProtectionPolicy(pw, pw, AccessPermission())
            policy.encryptionKeyLength = 256
            policy.setPreferAES(true)
            doc.protect(policy)
            doc.save(File(dst))
        } finally {
            doc.close()
        }
        return true
    }

    /** Maps "displayed page" coordinates (points, origin top-left, page rotation applied) to PDF user space. */
    private class Pm(page: PDPage) {
        val cb = page.cropBox
        val rot = ((page.rotation % 360) + 360) % 360
        val w = cb.width
        val h = cb.height
        val dw = if (rot % 180 == 0) w else h
        val dh = if (rot % 180 == 0) h else w
        fun pt(u: Float, v: Float): FloatArray = when (rot) {
            90 -> floatArrayOf(cb.lowerLeftX + v, cb.lowerLeftY + u)
            180 -> floatArrayOf(cb.lowerLeftX + w - u, cb.lowerLeftY + v)
            270 -> floatArrayOf(cb.lowerLeftX + w - v, cb.lowerLeftY + h - u)
            else -> floatArrayOf(cb.lowerLeftX + u, cb.lowerLeftY + h - v)
        }
    }

    private fun fontInfo(name: String?): Triple<String, Boolean, Boolean> {
        val n = (name ?: "").substringAfter('+').lowercase()
        val bold = Regex("bold|black|heavy|semibold|demi").containsMatchIn(n)
        val it = Regex("italic|oblique|slanted").containsMatchIn(n)
        val fam = when {
            Regex("courier|mono|consolas|typewriter").containsMatchIn(n) -> "c"
            !n.contains("sans") && Regex("times|serif|georgia|garamond|palatino|minion|cambria|roman|book|century|nazanin|lotus").containsMatchIn(n) -> "t"
            else -> "h"
        }
        return Triple(fam, bold, it)
    }

    private fun nfkc(s: String): String =
        if (s.any { it.code in 0xFB50..0xFDFF || it.code in 0xFE70..0xFEFF }) Normalizer.normalize(s, Normalizer.Form.NFKC) else s

    /** Words of a page with boxes, per-character extents, font family / weight and fill colour. */
    private class BoxStripper(val dw: Float, val dh: Float) : PDFTextStripper() {
        val out = ArrayList<Map<String, Any>>()
        private val col = java.util.IdentityHashMap<TextPosition, Int>()
        override fun processTextPosition(text: TextPosition) {
            col[text] = try { graphicsState.nonStrokingColor.toRGB() and 0xFFFFFF } catch (_: Throwable) { 0 }
            super.processTextPosition(text)
        }
        override fun writeString(text: String, textPositions: MutableList<TextPosition>) {
            if (text.isBlank() || textPositions.isEmpty()) return
            var x0 = Float.MAX_VALUE; var x1 = -Float.MAX_VALUE
            var bottom = -Float.MAX_VALUE; var hh = 0f
            val cs = ArrayList<String>(); val ca = ArrayList<Double>(); val cb = ArrayList<Double>()
            fun n(v: Float, d: Float) = (v / d).coerceIn(0f, 1f).toDouble()
            for (t in textPositions) {
                x0 = minOf(x0, t.xDirAdj)
                x1 = maxOf(x1, t.xDirAdj + t.widthDirAdj)
                bottom = maxOf(bottom, t.yDirAdj)
                hh = maxOf(hh, t.heightDir)
            }
            // characters in visual left-to-right order (RTL text is stored in logical order); Arabic presentation forms -> base letters
            for (t in textPositions.sortedBy { it.xDirAdj }) {
                cs.add(nfkc(t.unicode ?: ""))
                ca.add(n(t.xDirAdj, dw))
                cb.add(n(t.xDirAdj + t.widthDirAdj, dw))
            }
            val top = bottom - hh
            val ref = textPositions.firstOrNull { !it.unicode.isNullOrBlank() } ?: textPositions[0]
            val fi = fontInfo(try { ref.font.name } catch (_: Throwable) { null })
            out.add(mapOf("text" to text.trim(), "x" to n(x0, dw), "y" to n(top, dh), "w" to n(x1 - x0, dw), "h" to n(hh, dh), "pt" to hh.toDouble(),
                "c" to cs, "a" to ca, "b" to cb, "fn" to (try { ref.font.name } catch (_: Throwable) { null } ?: ""), "fam" to fi.first, "bold" to fi.second, "it" to fi.third, "col" to (col[ref] ?: 0)))
        }
    }

    /** Text lines of a page with their boxes (fractions of the displayed page). */
    private fun boxes(src: String, page: Int): List<Map<String, Any>> {
        val doc = PDDocument.load(File(src))
        try {
            val pm = Pm(doc.getPage(page - 1))
            val s = BoxStripper(pm.dw, pm.dh)
            s.startPage = page
            s.endPage = page
            s.getText(doc)
            return s.out
        } finally {
            doc.close()
        }
    }

    private fun rgb(m: Map<String, Any?>) = Triple(
        (m["r"] as Number).toInt().coerceIn(0, 255), (m["g"] as Number).toInt().coerceIn(0, 255), (m["b"] as Number).toInt().coerceIn(0, 255))

    private fun f(m: Map<String, Any?>, k: String): Float = (m[k] as Number).toFloat()

    private fun drawImg(doc: PDDocument, cs: PDPageContentStream, pm: Pm, png: ByteArray, u0: Float, v0: Float, wp: Float, hp: Float) {
        val bmp = BitmapFactory.decodeByteArray(png, 0, png.size) ?: throw IllegalArgumentException("Bad image")
        val img = LosslessFactory.createFromImage(doc, bmp)
        val bl = pm.pt(u0, v0 + hp)
        val br = pm.pt(u0 + wp, v0 + hp)
        val tl = pm.pt(u0, v0)
        cs.drawImage(img, Matrix(br[0] - bl[0], br[1] - bl[1], tl[0] - bl[0], tl[1] - bl[1], bl[0], bl[1]))
    }

    private fun isAnnot(m: Map<String, Any?>) = m["k"] == "ft" || m["k"] == "fti" || (m["k"] == "s" && m["ink"] == true)

    private fun drawItems(doc: PDDocument, page: PDPage, items: List<Map<String, Any?>>) {
        val pm = Pm(page)
        val content = items.filter { !isAnnot(it) }
        if (content.isNotEmpty()) {
            PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
            for (it in content) {
                when (it["k"]) {
                    "s" -> { // pen / highlighter stroke
                        val pts = (it["p"] as List<*>).map { v -> (v as Number).toFloat() }
                        if (pts.size < 2) continue
                        val (r, g, b) = rgb(it)
                        val gs = PDExtendedGraphicsState()
                        gs.setStrokingAlphaConstant(f(it, "a"))
                        gs.setNonStrokingAlphaConstant(f(it, "a"))
                        cs.saveGraphicsState()
                        cs.setGraphicsStateParameters(gs)
                        cs.setStrokingColor(r, g, b)
                        cs.setLineWidth(maxOf(0.2f, f(it, "w") * pm.dw))
                        cs.setLineCapStyle(1)
                        cs.setLineJoinStyle(1)
                        var first = true
                        var i = 0
                        while (i + 1 < pts.size) {
                            val q = pm.pt(pts[i] * pm.dw, pts[i + 1] * pm.dh)
                            if (first) cs.moveTo(q[0], q[1]) else cs.lineTo(q[0], q[1])
                            first = false
                            i += 2
                        }
                        if (pts.size == 2) { val q = pm.pt(pts[0] * pm.dw + 0.01f, pts[1] * pm.dh); cs.lineTo(q[0], q[1]) }
                        cs.stroke()
                        cs.restoreGraphicsState()
                    }
                    "r" -> { // white-out rectangle
                        val pad = 1f
                        val u0 = f(it, "x") * pm.dw - pad; val v0 = f(it, "y") * pm.dh - pad
                        val a = pm.pt(u0, v0)
                        val b = pm.pt(u0 + f(it, "w") * pm.dw + 2 * pad, v0 + f(it, "h") * pm.dh + 2 * pad)
                        cs.setNonStrokingColor(255, 255, 255)
                        cs.addRect(minOf(a[0], b[0]), minOf(a[1], b[1]), Math.abs(a[0] - b[0]), Math.abs(a[1] - b[1]))
                        cs.fill()
                    }
                    "t" -> { // real (selectable) Latin text; the original embedded font is reused when it can encode the text
                        val (r, g, b) = rgb(it)
                        cs.setNonStrokingColor(r, g, b)
                        val (font, lines) = pickFont(page, it)
                        drawLines(cs, pm, font, f(it, "size") * pm.dw, f(it, "x") * pm.dw, f(it, "y") * pm.dh, lines)
                    }
                    "i" -> drawImg(doc, cs, pm, it["png"] as ByteArray, f(it, "x") * pm.dw, f(it, "y") * pm.dh, f(it, "w") * pm.dw, f(it, "h") * pm.dh)
                }
            }
            }
        }
        if (items.none { isAnnot(it) }) return
        val annots = page.annotations
        var group = ArrayList<Map<String, Any?>>()
        fun flush() { if (group.isNotEmpty()) { addInk(doc, pm, annots, group); group = ArrayList() } }
        for (it in items) {
            if (it["k"] == "s" && it["ink"] == true) {
                if (group.isNotEmpty() && !sameInk(group[0], it)) flush()
                group.add(it)
            } else if (it["k"] == "ft" || it["k"] == "fti") {
                flush()
                addFreeText(doc, page, pm, annots, it)
            }
        }
        flush()
    }

    private fun sameInk(a: Map<String, Any?>, b: Map<String, Any?>) =
        listOf("r", "g", "b", "w", "a").all { k -> (a[k] as Number).toDouble() == (b[k] as Number).toDouble() }

    private fun findFont(page: PDPage, name: String?): PDFont? {
        if (name.isNullOrEmpty()) return null
        val res = page.resources ?: return null
        for (key in res.fontNames) {
            val fo = try { res.getFont(key) } catch (_: Throwable) { null } ?: continue
            if (fo.name == name) return fo
        }
        return null
    }

    private fun canEncode(font: PDFont, s: String): Boolean = try { font.encode(s); true } catch (_: Throwable) { false }

    /** Embedded original font when it contains every glyph of the text, else the standard-14 approximation. */
    private fun pickFont(page: PDPage, m: Map<String, Any?>): Pair<PDFont, List<String>> {
        val lines = (m["text"] as String).split("\n")
        val emb = findFont(page, m["fn"] as? String)
        if (emb != null && lines.all { l -> canEncode(emb, l) }) return Pair(emb, lines)
        val std = stdFont(m["fam"] as? String, m["b"] == true, m["i"] == true)
        return Pair(std, lines.map { l -> if (canEncode(std, l)) l else l.map { ch -> if (canEncode(std, ch.toString())) ch else '?' }.joinToString("") })
    }

    private fun drawLines(cs: PDPageContentStream, pm: Pm, font: PDFont, fs: Float, u: Float, v: Float, lines: List<String>) {
        for ((k, line) in lines.withIndex()) {
            if (line.isEmpty()) continue
            val bv = v + fs * 0.93f + k * fs * 1.17f
            val o = pm.pt(u, bv)
            val ex = pm.pt(u + 1, bv)
            val ey = pm.pt(u, bv - 1)
            cs.beginText()
            cs.setFont(font, fs)
            cs.setTextMatrix(Matrix(ex[0] - o[0], ex[1] - o[1], ey[0] - o[0], ey[1] - o[1], o[0], o[1]))
            cs.showText(line)
            cs.endText()
        }
    }

    private fun cosRect(pts: List<FloatArray>, pad: Float): PDRectangle {
        val x0 = pts.minOf { it[0] } - pad; val x1 = pts.maxOf { it[0] } + pad
        val y0 = pts.minOf { it[1] } - pad; val y1 = pts.maxOf { it[1] } + pad
        return PDRectangle(x0, y0, x1 - x0, y1 - y0)
    }

    /** Real Ink annotation (editable in any PDF viewer) with a drawn appearance; strokes of equal style share one annotation. */
    private fun addInk(doc: PDDocument, pm: Pm, annots: MutableList<PDAnnotation>, group: List<Map<String, Any?>>) {
        val first = group[0]
        val (r, g, b) = rgb(first)
        val alpha = f(first, "a")
        val width = maxOf(0.2f, f(first, "w") * pm.dw)
        val paths = ArrayList<List<FloatArray>>()
        for (st in group) {
            val pts = (st["p"] as List<*>).map { v -> (v as Number).toFloat() }
            val path = ArrayList<FloatArray>()
            var i = 0
            while (i + 1 < pts.size) {
                val q = pm.pt(pts[i] * pm.dw, pts[i + 1] * pm.dh)
                val last = path.lastOrNull()
                if (last == null || last[0] != q[0] || last[1] != q[1]) path.add(q)
                i += 2
            }
            if (path.isEmpty()) continue
            if (path.size == 1) path.add(floatArrayOf(path[0][0] + 0.01f, path[0][1]))
            paths.add(path)
        }
        if (paths.isEmpty()) return
        val dict = COSDictionary()
        dict.setItem(COSName.TYPE, COSName.ANNOT)
        dict.setName(COSName.SUBTYPE, "Ink")
        val an = PDAnnotationMarkup(dict)
        val inkList = COSArray()
        for (path in paths) {
            val arr = COSArray()
            for (q in path) { arr.add(COSFloat(q[0])); arr.add(COSFloat(q[1])) }
            inkList.add(arr)
        }
        dict.setItem(COSName.getPDFName("InkList"), inkList)
        val rect = cosRect(paths.flatten(), width / 2f + 1f)
        an.rectangle = rect
        an.color = PDColor(floatArrayOf(r / 255f, g / 255f, b / 255f), PDDeviceRGB.INSTANCE)
        an.constantOpacity = alpha
        val bs = COSDictionary()
        bs.setItem(COSName.W, COSFloat(width))
        bs.setName(COSName.S, "S")
        dict.setItem(COSName.BS, bs)
        an.isPrinted = true
        val ap = PDAppearanceStream(doc)
        ap.bBox = rect
        ap.resources = PDResources()
        PDPageContentStream(doc, ap).use { cs ->
            val gs = PDExtendedGraphicsState()
            gs.setStrokingAlphaConstant(alpha)
            cs.setGraphicsStateParameters(gs)
            cs.setStrokingColor(r, g, b)
            cs.setLineWidth(width)
            cs.setLineCapStyle(1)
            cs.setLineJoinStyle(1)
            for (path in paths) {
                cs.moveTo(path[0][0], path[0][1])
                for (k in 1 until path.size) cs.lineTo(path[k][0], path[k][1])
                cs.stroke()
            }
        }
        val apd = PDAppearanceDictionary()
        apd.setNormalAppearance(ap)
        an.appearance = apd
        annots.add(an)
    }

    /** Real FreeText annotation: [m] kind "ft" = Latin text drawn with a standard font, "fti" = text as image (Persian / wrapped). Contents keeps the real text. */
    private fun addFreeText(doc: PDDocument, page: PDPage, pm: Pm, annots: MutableList<PDAnnotation>, m: Map<String, Any?>) {
        val img = m["k"] == "fti"
        val (r, g, b) = rgb(m)
        val text = m["text"] as String
        val u = f(m, "x") * pm.dw
        val v = f(m, "y") * pm.dh
        var wU: Float
        var hV: Float
        var fs = 12f
        var font: PDFont? = null
        var lines = emptyList<String>()
        if (img) {
            wU = f(m, "w") * pm.dw
            hV = f(m, "h") * pm.dh
        } else {
            fs = f(m, "size") * pm.dw
            val pf = pickFont(page, m)
            font = pf.first
            lines = pf.second
            wU = lines.maxOf { l -> try { pf.first.getStringWidth(l) / 1000f * fs } catch (_: Throwable) { l.length * fs * 0.5f } }
            hV = lines.size * fs * 1.17f + fs * 0.1f
        }
        val corners = listOf(pm.pt(u, v), pm.pt(u + wU, v), pm.pt(u, v + hV), pm.pt(u + wU, v + hV))
        val rect = cosRect(corners, 0f)
        val dict = COSDictionary()
        dict.setItem(COSName.TYPE, COSName.ANNOT)
        dict.setName(COSName.SUBTYPE, "FreeText")
        val an = PDAnnotationMarkup(dict)
        an.rectangle = rect
        an.contents = text
        an.isPrinted = true
        dict.setString(COSName.DA, String.format(Locale.US, "%.3f %.3f %.3f rg /Helv %.1f Tf", r / 255f, g / 255f, b / 255f, fs))
        val bs = COSDictionary()
        bs.setItem(COSName.W, COSFloat(0f))
        dict.setItem(COSName.BS, bs)
        val ap = PDAppearanceStream(doc)
        ap.bBox = rect
        ap.resources = PDResources()
        PDPageContentStream(doc, ap).use { cs ->
            if (img) {
                drawImg(doc, cs, pm, m["png"] as ByteArray, u, v, wU, hV)
            } else {
                cs.setNonStrokingColor(r, g, b)
                drawLines(cs, pm, font!!, fs, u, v, lines)
            }
        }
        val apd = PDAppearanceDictionary()
        apd.setNormalAppearance(ap)
        an.appearance = apd
        annots.add(an)
    }

    /** Adds vector edits (ops per original page) and reorders / deletes pages. Original content is kept. */
    private fun edit(src: String, dst: String, order: List<Int>, ops: List<Map<String, Any?>>): Int {
        val doc = PDDocument.load(File(src))
        var removed = 0
        try {
            val n = doc.numberOfPages
            for (o in ops) {
                val pg = (o["page"] as Number).toInt()
                if (pg < 1 || pg > n) continue
                @Suppress("UNCHECKED_CAST")
                val items = o["items"] as List<Map<String, Any?>>
                val page = doc.getPage(pg - 1)
                val rm = items.filter { it["k"] == "r" && it["rm"] == true }
                if (rm.isNotEmpty()) removed += try { redact(doc, page, pg, rm) } catch (_: Throwable) { 0 }
                drawItems(doc, page, items)
            }
            val ident = order.size == n && order.withIndex().all { (i, v) -> v == i + 1 }
            if (!ident && order.isNotEmpty()) {
                val pages = (0 until n).map { doc.getPage(it) }
                for (i in n - 1 downTo 0) doc.removePage(i)
                for (o in order) if (o in 1..n) doc.addPage(pages[o - 1])
            }
            doc.save(File(dst))
        } finally {
            doc.close()
        }
        return removed
    }

    private fun stdFont(fam: String?, b: Boolean, i: Boolean): PDType1Font = when (fam) {
        "t" -> if (b && i) PDType1Font.TIMES_BOLD_ITALIC else if (b) PDType1Font.TIMES_BOLD else if (i) PDType1Font.TIMES_ITALIC else PDType1Font.TIMES_ROMAN
        "c" -> if (b && i) PDType1Font.COURIER_BOLD_OBLIQUE else if (b) PDType1Font.COURIER_BOLD else if (i) PDType1Font.COURIER_OBLIQUE else PDType1Font.COURIER
        else -> if (b && i) PDType1Font.HELVETICA_BOLD_OBLIQUE else if (b) PDType1Font.HELVETICA_BOLD else if (i) PDType1Font.HELVETICA_OBLIQUE else PDType1Font.HELVETICA
    }

    /**
     * Scans the page-level content stream and records, for every Tj / TJ operator, which glyphs lie inside the
     * given user-space rectangles. [repl] maps operator index -> replacement TJ array (removed glyphs become
     * kerning gaps so the text after them stays where it was).
     */
    private class OpScan(val rects: List<FloatArray>) : PDFTextStripper() {
        var depth = 0
        var idx = 0
        val repl = HashMap<Int, COSArray>()
        var removedGlyphs = 0
        private var capturing = false
        private val glyphs = ArrayList<TextPosition>()

        override fun showForm(form: PDFormXObject) {
            depth++
            try { super.showForm(form) } finally { depth-- }
        }

        override fun processTextPosition(text: TextPosition) {
            if (capturing) glyphs.add(text)
            super.processTextPosition(text)
        }

        private fun inRect(x: Float, y: Float) = rects.any { x >= it[0] && x <= it[2] && y >= it[1] && y <= it[3] }

        override fun processOperator(operator: Operator, operands: MutableList<COSBase>) {
            val my = if (depth == 0) idx++ else -1
            val name = operator.name
            if (my < 0 || (name != "Tj" && name != "TJ") || operands.isEmpty()) {
                super.processOperator(operator, operands)
                return
            }
            glyphs.clear()
            capturing = true
            try { super.processOperator(operator, operands) } finally { capturing = false }
            val gs = graphicsState
            val font: PDFont = gs.textState.font ?: return
            val fs = gs.textState.fontSize
            if (fs == 0f) return
            val tc = gs.textState.characterSpacing
            val tw = gs.textState.wordSpacing

            // flatten into items: either a code (bytes) or a TJ number
            class Item(val bytes: ByteArray?, val code: Int, val num: Float)
            val items = ArrayList<Item>()
            fun addString(s: COSString) {
                val bis = ByteArrayInputStream(s.bytes)
                while (bis.available() > 0) {
                    val before = bis.available()
                    val code = font.readCode(bis)
                    val used = before - bis.available()
                    if (used <= 0) break
                    val bs = ByteArray(used)
                    System.arraycopy(s.bytes, s.bytes.size - before, bs, 0, used)
                    items.add(Item(bs, code, 0f))
                }
            }
            val op0 = operands[0]
            if (op0 is COSString) {
                addString(op0)
            } else if (op0 is COSArray) {
                for (e in op0) {
                    if (e is COSString) addString(e) else if (e is COSNumber) items.add(Item(null, 0, e.floatValue()))
                }
            } else {
                return
            }
            val nCodes = items.count { it.bytes != null }
            if (nCodes != glyphs.size || nCodes == 0) return

            var gi = 0
            val hit = BooleanArray(items.size)
            var any = false
            for ((k, it) in items.withIndex()) {
                if (it.bytes == null) continue
                val g = glyphs[gi++]
                val m = g.textMatrix
                val w0 = try { font.getWidth(it.code) } catch (_: Throwable) { 0f }
                val cx = m.translateX + 0.5f * w0 / 1000f * m.scaleX
                val cy = m.translateY + 0.5f * w0 / 1000f * m.shearY
                if (inRect(cx, cy)) { hit[k] = true; any = true }
            }
            if (!any) return
            val arr = COSArray()
            val buf = ByteArrayOutputStream()
            var gap = 0f
            fun flushStr() { if (buf.size() > 0) { arr.add(COSString(buf.toByteArray())); buf.reset() } }
            fun flushGap() { if (gap != 0f) { arr.add(COSFloat(gap)); gap = 0f } }
            for ((k, it) in items.withIndex()) {
                if (it.bytes == null) { flushStr(); gap += it.num; continue }
                if (hit[k]) {
                    flushStr()
                    val w0 = try { font.getWidth(it.code) } catch (_: Throwable) { 0f }
                    var adv = w0 + tc * 1000f / fs
                    if (it.bytes.size == 1 && it.code == 32) adv += tw * 1000f / fs
                    gap -= adv
                    removedGlyphs++
                } else {
                    flushGap()
                    buf.write(it.bytes)
                }
            }
            flushStr(); flushGap()
            repl[my] = arr
        }
    }

    /** Really removes the glyphs under the white-out rectangles from the page content stream. Returns the number of glyphs removed. */
    private fun redact(doc: PDDocument, page: PDPage, pageNo: Int, rms: List<Map<String, Any?>>): Int {
        val pm = Pm(page)
        val rects = rms.map {
            val a = pm.pt(f(it, "x") * pm.dw, f(it, "y") * pm.dh)
            val b = pm.pt((f(it, "x") + f(it, "w")) * pm.dw, (f(it, "y") + f(it, "h")) * pm.dh)
            val w = Math.abs(a[0] - b[0]); val h = Math.abs(a[1] - b[1])
            val pad = maxOf(1.5f, 0.25f * minOf(w, h))
            floatArrayOf(minOf(a[0], b[0]) - pad, minOf(a[1], b[1]) - pad, maxOf(a[0], b[0]) + pad, maxOf(a[1], b[1]) + pad)
        }
        val scan = OpScan(rects)
        scan.startPage = pageNo
        scan.endPage = pageNo
        scan.getText(doc)
        if (scan.repl.isEmpty()) return 0
        val parser = PDFStreamParser(page)
        val toks = ArrayList<Any>()
        while (true) { val t = parser.parseNextToken() ?: break; toks.add(t) }
        val outT = ArrayList<Any>()
        val pending = ArrayList<Any>()
        var k = 0
        for (t in toks) {
            if (t is Operator) {
                val r = scan.repl[k++]
                if (r != null && (t.name == "Tj" || t.name == "TJ")) {
                    pending.clear()
                    outT.add(r)
                    outT.add(Operator.getOperator("TJ"))
                } else {
                    outT.addAll(pending); pending.clear()
                    outT.add(t)
                }
            } else pending.add(t)
        }
        outT.addAll(pending)
        val ns = PDStream(doc)
        ns.createOutputStream(COSName.FLATE_DECODE).use { ContentStreamWriter(it).writeTokens(outT) }
        page.setContents(ns)
        return scan.removedGlyphs
    }

    /** Real PDF text-markup annotation (highlight / underline / strike-out) over rects given as fractions (x, y, w, h) of the displayed page. */
    private fun markup(src: String, dst: String, page: Int, kind: String, rects: List<List<Double>>, r: Int, g: Int, b: Int): Boolean {
        val doc = PDDocument.load(File(src))
        try {
            val pg = doc.getPage(page - 1)
            val pm = Pm(pg)
            val sub = when (kind) {
                "underline" -> PDAnnotationTextMarkup.SUB_TYPE_UNDERLINE
                "strike" -> PDAnnotationTextMarkup.SUB_TYPE_STRIKEOUT
                else -> PDAnnotationTextMarkup.SUB_TYPE_HIGHLIGHT
            }
            val an = PDAnnotationTextMarkup(sub)
            val quads = ArrayList<Float>()
            var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
            for (q in rects) {
                if (q.size < 4) continue
                val u0 = q[0].toFloat() * pm.dw; val v0 = q[1].toFloat() * pm.dh
                val u1 = u0 + q[2].toFloat() * pm.dw; val v1 = v0 + q[3].toFloat() * pm.dh
                val tl = pm.pt(u0, v0); val tr = pm.pt(u1, v0); val bl = pm.pt(u0, v1); val br = pm.pt(u1, v1)
                for (p in listOf(tl, tr, bl, br)) {
                    quads.add(p[0]); quads.add(p[1])
                    minX = minOf(minX, p[0]); maxX = maxOf(maxX, p[0]); minY = minOf(minY, p[1]); maxY = maxOf(maxY, p[1])
                }
            }
            if (quads.isEmpty()) return false
            an.quadPoints = quads.toFloatArray()
            an.rectangle = PDRectangle(minX, minY, maxX - minX, maxY - minY)
            an.color = PDColor(floatArrayOf(r.coerceIn(0, 255) / 255f, g.coerceIn(0, 255) / 255f, b.coerceIn(0, 255) / 255f), PDDeviceRGB.INSTANCE)
            an.isPrinted = true
            pg.annotations.add(an)
            try { an.constructAppearances() } catch (_: Throwable) { /* viewer draws it from QuadPoints */ }
            doc.save(File(dst))
        } finally {
            doc.close()
        }
        return true
    }

    /** Place an image at a fraction position of the displayed page; works on rotated pages. */
    private fun stampAt(src: String, dst: String, page: Int, x: Float, y: Float, w: Float, png: ByteArray): Boolean {
        val doc = PDDocument.load(File(src))
        try {
            val pg = doc.getPage(page - 1)
            val pm = Pm(pg)
            val bmp = BitmapFactory.decodeByteArray(png, 0, png.size) ?: throw IllegalArgumentException("Bad image")
            val wp = w * pm.dw
            val hp = wp * bmp.height / bmp.width
            PDPageContentStream(doc, pg, PDPageContentStream.AppendMode.APPEND, true, true).use {
                drawImg(doc, it, pm, png, x * pm.dw, y * pm.dh, wp, hp)
            }
            doc.save(File(dst))
        } finally {
            doc.close()
        }
        return true
    }

    private fun merge(srcs: List<String>, dst: String): Boolean {
        val out = PDDocument()
        val opened = ArrayList<PDDocument>()
        try {
            val m = PDFMergerUtility()
            for (s in srcs) {
                val d = PDDocument.load(File(s))
                opened.add(d)
                m.appendDocument(out, d)
            }
            out.save(File(dst))
        } finally {
            opened.forEach { try { it.close() } catch (_: Throwable) {} }
            out.close()
        }
        return true
    }

    private fun extract(src: String, dst: String, pages: List<Int>): Boolean {
        val doc = PDDocument.load(File(src))
        try {
            val keep = pages.map { it - 1 }.toSet()
            for (i in doc.numberOfPages - 1 downTo 0) if (i !in keep) doc.removePage(i)
            doc.save(File(dst))
        } finally {
            doc.close()
        }
        return true
    }

    private fun rotate(src: String, dst: String, pages: List<Int>, deg: Int): Boolean {
        val doc = PDDocument.load(File(src))
        try {
            for (i in 0 until doc.numberOfPages) {
                if (pages.isEmpty() || (i + 1) in pages) {
                    val pg = doc.getPage(i)
                    pg.rotation = (((pg.rotation + deg) % 360) + 360) % 360
                }
            }
            doc.save(File(dst))
        } finally {
            doc.close()
        }
        return true
    }

    private fun text(src: String, page: Int): String {
        val doc = PDDocument.load(File(src))
        try {
            val s = PDFTextStripper()
            s.startPage = page
            s.endPage = page
            return s.getText(doc)
        } finally {
            doc.close()
        }
    }

    private fun search(src: String, q: String): List<Map<String, Any>> {
        val out = ArrayList<Map<String, Any>>()
        if (q.isEmpty()) return out
        val doc = PDDocument.load(File(src))
        try {
            val s = PDFTextStripper()
            for (p in 1..doc.numberOfPages) {
                s.startPage = p
                s.endPage = p
                val t = s.getText(doc).replace(Regex("\\s+"), " ")
                var count = 0
                var first = -1
                var from = 0
                while (true) {
                    val i = t.indexOf(q, from, ignoreCase = true)
                    if (i < 0) break
                    if (first < 0) first = i
                    count++
                    from = i + q.length
                }
                if (count > 0) {
                    val a = maxOf(0, first - 30)
                    val b = minOf(t.length, first + q.length + 40)
                    out.add(mapOf("page" to p, "count" to count, "snippet" to t.substring(a, b)))
                }
            }
        } finally {
            doc.close()
        }
        return out
    }

    private fun fields(src: String): List<Map<String, Any?>> {
        val out = ArrayList<Map<String, Any?>>()
        val doc = PDDocument.load(File(src))
        try {
            val form = doc.documentCatalog.acroForm ?: return out
            for (f in form.fieldTree) {
                if (f is PDNonTerminalField) continue
                val name = f.fullyQualifiedName ?: continue
                when (f) {
                    is PDTextField -> out.add(mapOf("name" to name, "type" to "text", "value" to (f.value ?: ""), "multi" to f.isMultiline, "ro" to f.isReadOnly))
                    is PDCheckBox -> out.add(mapOf("name" to name, "type" to "check", "value" to f.isChecked, "ro" to f.isReadOnly))
                    is PDRadioButton -> out.add(mapOf("name" to name, "type" to "choice", "value" to (f.value ?: ""), "options" to f.exportValues, "ro" to f.isReadOnly))
                    is PDChoice -> out.add(mapOf("name" to name, "type" to "choice", "value" to (f.value.firstOrNull() ?: ""), "options" to f.options, "ro" to f.isReadOnly))
                    else -> {}
                }
            }
        } finally {
            doc.close()
        }
        return out
    }

    /** returns names of fields that could not be set */
    private fun fill(src: String, dst: String, values: Map<String, Any?>): List<String> {
        val failed = ArrayList<String>()
        val doc = PDDocument.load(File(src))
        try {
            val form = doc.documentCatalog.acroForm ?: throw IllegalStateException("No form")
            form.needAppearances = true
            for ((k, v) in values) {
                val f = form.getField(k) ?: continue
                try {
                    when (f) {
                        is PDCheckBox -> if (v == true) f.check() else f.unCheck()
                        is PDTextField -> f.setValue(v?.toString() ?: "")
                        is PDRadioButton -> f.setValue(v?.toString() ?: "")
                        is PDChoice -> f.setValue(v?.toString() ?: "")
                        else -> {}
                    }
                } catch (e: Throwable) {
                    failed.add(k)
                }
            }
            doc.save(File(dst))
        } finally {
            doc.close()
        }
        return failed
    }

    /** anchor: 0 bottom-right, 1 bottom-left, 2 centre, 3 top-right, 4 top-left; w = fraction of page width */
    private fun stamp(src: String, dst: String, page: Int, anchor: Int, wFrac: Double, png: ByteArray): Boolean {
        val doc = PDDocument.load(File(src))
        try {
            val pg = doc.getPage(page - 1)
            val box = pg.cropBox
            val bmp = BitmapFactory.decodeByteArray(png, 0, png.size) ?: throw IllegalArgumentException("Bad image")
            val img = LosslessFactory.createFromImage(doc, bmp)
            val bw = box.width * wFrac.toFloat()
            val bh = bw * bmp.height / bmp.width
            val mx = box.width * 0.04f
            val my = box.height * 0.04f
            val left = box.lowerLeftX + mx
            val right = box.upperRightX - mx - bw
            val bottom = box.lowerLeftY + my
            val top = box.upperRightY - my - bh
            val x: Float
            val y: Float
            when (anchor) {
                1 -> { x = left; y = bottom }
                2 -> { x = box.lowerLeftX + (box.width - bw) / 2; y = box.lowerLeftY + (box.height - bh) / 2 }
                3 -> { x = right; y = top }
                4 -> { x = left; y = top }
                else -> { x = right; y = bottom }
            }
            PDPageContentStream(doc, pg, PDPageContentStream.AppendMode.APPEND, true, true).use {
                it.drawImage(img, x, y, bw, bh)
            }
            doc.save(File(dst))
        } finally {
            doc.close()
        }
        return true
    }
}
