package ir.abtin.filemanager

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Build
import android.view.KeyEvent
import android.widget.RemoteViews
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel

/** Home-screen media widget. Buttons dispatch media keys to the active session (audio_service). */
class MediaWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        for (id in ids) mgr.updateAppWidget(id, build(ctx))
    }

    override fun onReceive(ctx: Context, intent: Intent) {
        val key = when (intent.action) {
            ACT_PREV -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            ACT_NEXT -> KeyEvent.KEYCODE_MEDIA_NEXT
            ACT_PLAY -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            else -> -1
        }
        if (key != -1) {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
            am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
            return
        }
        super.onReceive(ctx, intent)
    }

    companion object {
        const val ACT_PREV = "ir.abtin.filemanager.W_PREV"
        const val ACT_NEXT = "ir.abtin.filemanager.W_NEXT"
        const val ACT_PLAY = "ir.abtin.filemanager.W_PLAY"

        private fun pi(ctx: Context, act: String): PendingIntent {
            val i = Intent(ctx, MediaWidget::class.java).setAction(act)
            val f = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
            return PendingIntent.getBroadcast(ctx, act.hashCode(), i, f)
        }

        fun build(ctx: Context): RemoteViews {
            val sp = ctx.getSharedPreferences("abtin_widget", Context.MODE_PRIVATE)
            val v = RemoteViews(ctx.packageName, R.layout.widget_media)
            v.setTextViewText(R.id.w_title, sp.getString("title", ctx.getString(R.string.app_name_widget)))
            v.setTextViewText(R.id.w_artist, sp.getString("artist", ""))
            v.setImageViewResource(R.id.w_play, if (sp.getBoolean("playing", false)) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
            v.setOnClickPendingIntent(R.id.w_prev, pi(ctx, ACT_PREV))
            v.setOnClickPendingIntent(R.id.w_play, pi(ctx, ACT_PLAY))
            v.setOnClickPendingIntent(R.id.w_next, pi(ctx, ACT_NEXT))
            val launch = ctx.packageManager.getLaunchIntentForPackage(ctx.packageName)
            if (launch != null) {
                val f = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
                v.setOnClickPendingIntent(R.id.w_root, PendingIntent.getActivity(ctx, 0, launch, f))
            }
            return v
        }

        fun refresh(ctx: Context) {
            val mgr = AppWidgetManager.getInstance(ctx)
            val ids = mgr.getAppWidgetIds(ComponentName(ctx, MediaWidget::class.java))
            for (id in ids) mgr.updateAppWidget(id, build(ctx))
        }
    }
}

/** Channel: abtin/widget  update(title, artist, playing) */
object WidgetNative {
    fun register(ctx: Context, messenger: BinaryMessenger) {
        MethodChannel(messenger, "abtin/widget").setMethodCallHandler { call, result ->
            if (call.method == "update") {
                ctx.getSharedPreferences("abtin_widget", Context.MODE_PRIVATE).edit()
                    .putString("title", call.argument<String>("title") ?: "")
                    .putString("artist", call.argument<String>("artist") ?: "")
                    .putBoolean("playing", call.argument<Boolean>("playing") ?: false)
                    .apply()
                MediaWidget.refresh(ctx)
                result.success(null)
            } else result.notImplemented()
        }
    }
}
