package ir.abtin.filemanager

import android.os.Handler
import com.github.junrar.Archive
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.io.outputstream.SplitOutputStream
import net.lingala.zip4j.io.outputstream.ZipOutputStream
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.CompressionMethod
import net.lingala.zip4j.model.enums.EncryptionMethod
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveEntry
import org.apache.commons.compress.archivers.tar.TarArchiveOutputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorOutputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

/**
 * Archives on the native side. Channel: abtin/archive
 *  list     {src, password}                          -> [{name, size, dir, enc}]
 *  extract  {src, dst, password, only?, id}          -> true   (7z / rar / zip; `only` = entry names, folders end with '/')
 *  compress {paths, dst, format, password, volume, id} -> true (zip (AES-256 with password, optional split .z01 …), targz, 7z)
 * Errors use the codes RAR5 (unsupported RAR 5 archive) and PASSWORD (missing / wrong password).
 */
object ArchiveNative {
    private class Fail(val code: String, msg: String) : Exception(msg)

    fun register(messenger: BinaryMessenger, ui: Handler) {
        val arc = MethodChannel(messenger, "abtin/archive")
        arc.setMethodCallHandler { call, result ->
            if (call.method != "list" && call.method != "extract" && call.method != "compress") {
                result.notImplemented(); return@setMethodCallHandler
            }
            val src = call.argument<String>("src")
            val dst = call.argument<String>("dst")
            val pw = call.argument<String>("password")?.takeIf { it.isNotEmpty() }
            val id = call.argument<Int>("id") ?: 0
            val prog = progress(arc, ui, id)
            Thread {
                try {
                    val out: Any? = when (call.method) {
                        "list" -> list(src!!, pw)
                        "extract" -> {
                            File(dst!!).mkdirs()
                            extract(src!!, dst, pw, call.argument<List<String>>("only")?.map { norm(it) }, prog)
                            true
                        }
                        else -> {
                            val paths = call.argument<List<String>>("paths")!!
                            val vol = (call.argument<Number>("volume") ?: 0).toLong()
                            try {
                                when (call.argument<String>("format")) {
                                    "7z" -> compress7z(paths, dst!!, pw, prog)
                                    "zip" -> compressZip(paths, dst!!, pw, vol, prog)
                                    else -> compressTarGz(paths, dst!!, prog)
                                }
                            } catch (e: Throwable) {
                                deleteOutputs(dst!!)
                                throw e
                            }
                            true
                        }
                    }
                    ui.post { result.success(out) }
                } catch (e: Fail) {
                    ui.post { result.error(e.code, e.message, null) }
                } catch (e: Throwable) {
                    val c = when {
                        e.javaClass.simpleName.contains("RarV5") -> "RAR5"
                        e.javaClass.simpleName.contains("Password", true) || (e.message ?: "").contains("password", true) -> "PASSWORD"
                        else -> "ERR"
                    }
                    ui.post { result.error(c, e.message ?: e.toString(), null) }
                }
            }.start()
        }
    }

    private fun progress(ch: MethodChannel, ui: Handler, id: Int): (Int, Int) -> Unit {
        var last = -1
        return { done, total ->
            val pct = if (total <= 0) 0 else (done * 100L / total).toInt()
            if (pct != last) {
                last = pct
                ui.post { ch.invokeMethod("progress", mapOf("id" to id, "done" to done, "total" to total)) }
            }
        }
    }

    private fun norm(n: String): String {
        var s = n.replace('\\', '/')
        while (s.startsWith("./")) s = s.substring(2)
        return s.trimStart('/')
    }

    /** `only` == null: everything. Entry "a/" selects the folder and all below it. */
    private fun wanted(name: String, only: List<String>?): Boolean =
        only == null || only.any { if (it.endsWith("/")) (name == it || name.startsWith(it) || "$name/" == it) else name == it }

    private fun safe(dst: File, name: String): File {
        val f = File(dst, name).canonicalFile
        if (f.path != dst.canonicalPath && !f.path.startsWith(dst.canonicalPath + File.separator)) throw SecurityException("Bad entry: $name")
        return f
    }

    private fun kind(f: File): String {
        val h = ByteArray(8)
        val n = f.inputStream().use { it.read(h) }
        fun m(vararg b: Int) = n >= b.size && b.indices.all { (h[it].toInt() and 0xFF) == b[it] }
        return when {
            m(0x50, 0x4B) -> "zip"
            m(0x37, 0x7A, 0xBC, 0xAF) -> "7z"
            m(0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x01, 0x00) -> throw Fail("RAR5", "RAR5")
            m(0x52, 0x61, 0x72, 0x21) -> "rar"
            else -> throw Fail("ERR", "Unsupported or corrupted archive")
        }
    }

    // ───────────────────────── list ─────────────────────────

    private fun list(src: String, pw: String?): List<Map<String, Any>> {
        val f = File(src)
        val out = ArrayList<Map<String, Any>>()
        when (kind(f)) {
            "7z" -> sevenZ(f, pw).use { z ->
                for (e in z.entries) out.add(mapOf("name" to norm(e.name) + (if (e.isDirectory && !e.name.endsWith("/")) "/" else ""), "size" to e.size, "dir" to e.isDirectory, "enc" to false))
            }
            "rar" -> rar(f, pw).use { a ->
                for (h in a.fileHeaders) {
                    val n = norm(h.fileName)
                    out.add(mapOf("name" to if (h.isDirectory && !n.endsWith("/")) "$n/" else n, "size" to h.fullUnpackSize, "dir" to h.isDirectory, "enc" to h.isEncrypted))
                }
            }
            else -> {
                val z = ZipFile(f)
                if (z.isEncrypted && pw != null) z.setPassword(pw.toCharArray())
                for (h in z.fileHeaders) {
                    val n = norm(h.fileName)
                    out.add(mapOf("name" to n, "size" to h.uncompressedSize, "dir" to h.isDirectory, "enc" to h.isEncrypted))
                }
            }
        }
        return out
    }

    @Suppress("DEPRECATION")
    private fun sevenZ(f: File, pw: String?): SevenZFile = if (pw == null) SevenZFile(f) else SevenZFile(f, pw.toCharArray())

    private fun rar(f: File, pw: String?): Archive = if (pw == null) Archive(f) else Archive(f, pw)

    // ───────────────────────── extract ─────────────────────────

    private fun extract(src: String, dst: String, pw: String?, only: List<String>?, prog: (Int, Int) -> Unit) {
        val f = File(src)
        val out = File(dst)
        when (kind(f)) {
            "7z" -> extract7z(f, out, pw, only, prog)
            "rar" -> extractRar(f, out, pw, only, prog)
            else -> extractZip(f, out, pw, only, prog)
        }
    }

    private fun extract7z(src: File, out: File, pw: String?, only: List<String>?, prog: (Int, Int) -> Unit) {
        sevenZ(src, pw).use { z ->
            val buf = ByteArray(64 * 1024)
            val total = z.entries.count { wanted(norm(it.name), only) || wanted(norm(it.name) + "/", only) }
            var done = 0
            while (true) {
                val e = z.nextEntry ?: break
                val name = norm(e.name)
                if (!wanted(if (e.isDirectory) "$name/" else name, only)) continue
                done++
                prog(done, total)
                val f = safe(out, name)
                if (e.isDirectory) { f.mkdirs(); continue }
                f.parentFile?.mkdirs()
                FileOutputStream(f).use { os ->
                    while (true) {
                        val n = z.read(buf)
                        if (n < 0) break
                        os.write(buf, 0, n)
                    }
                }
            }
        }
    }

    private fun extractRar(src: File, out: File, pw: String?, only: List<String>?, prog: (Int, Int) -> Unit) {
        rar(src, pw).use { a ->
            val hs = a.fileHeaders.filter { wanted(norm(it.fileName).let { n -> if (it.isDirectory) "$n/" else n }, only) }
            for ((i, h) in hs.withIndex()) {
                val f = safe(out, norm(h.fileName))
                if (h.isDirectory) f.mkdirs()
                else {
                    f.parentFile?.mkdirs()
                    FileOutputStream(f).use { os -> a.extractFile(h, os) }
                }
                prog(i + 1, hs.size)
            }
        }
    }

    private fun extractZip(src: File, out: File, pw: String?, only: List<String>?, prog: (Int, Int) -> Unit) {
        val z = ZipFile(src)
        if (z.isEncrypted) {
            if (pw == null) throw Fail("PASSWORD", "password required")
            z.setPassword(pw.toCharArray())
        }
        val hs = z.fileHeaders.filter { wanted(norm(it.fileName), only) }
        for ((i, h) in hs.withIndex()) {
            val name = norm(h.fileName)
            val f = safe(out, name)
            if (h.isDirectory) f.mkdirs()
            else {
                f.parentFile?.mkdirs()
                // extract under its own (already validated) name; zip4j recreates the same relative path
                z.extractFile(h, out.path)
            }
            prog(i + 1, hs.size)
        }
    }

    // ───────────────────────── compress ─────────────────────────

    /** All files and folders below [paths] as (file, entry name) pairs; symlinks are skipped. */
    private fun collect(paths: List<String>): List<Pair<File, String>> {
        val out = ArrayList<Pair<File, String>>()
        fun walk(f: File, rel: String) {
            if (java.nio.file.Files.isSymbolicLink(f.toPath())) return
            if (f.isDirectory) {
                out.add(f to "$rel/")
                f.listFiles()?.sortedBy { it.name }?.forEach { walk(it, "$rel/${it.name}") }
            } else if (f.isFile) {
                out.add(f to rel)
            }
        }
        for (p in paths) { val f = File(p); walk(f, f.name) }
        return out
    }

    /** Removes the archive and all of its volumes (.z01 …) after a failed / cancelled job. */
    private fun deleteOutputs(dst: String) {
        val f = File(dst)
        try { f.delete() } catch (_: Throwable) {}
        val stem = f.nameWithoutExtension
        f.parentFile?.listFiles()?.filter { Regex("^" + Regex.escape(stem) + "\\.z\\d{2,}$").matches(it.name) }?.forEach { try { it.delete() } catch (_: Throwable) {} }
    }

    // already-compressed formats: storing is much faster and does not make the zip bigger
    private val storedExts = setOf("mp4", "mkv", "avi", "mov", "webm", "mp3", "m4a", "aac", "ogg", "opus", "flac", "jpg", "jpeg", "png", "gif", "webp", "heic", "zip", "rar", "7z", "gz", "tgz", "bz2", "xz", "apk", "jar", "docx", "xlsx", "pptx", "pdf")

    private fun compressZip(paths: List<String>, dst: String, pw: String?, volume: Long, prog: (Int, Int) -> Unit) {
        val items = collect(paths)
        val raw: OutputStream = if (volume > 0) SplitOutputStream(File(dst), maxOf(volume, 65536L)) else BufferedOutputStream(FileOutputStream(dst))
        val zos = if (pw == null) ZipOutputStream(raw) else ZipOutputStream(raw, pw.toCharArray())
        zos.use {
            val buf = ByteArray(64 * 1024)
            for ((i, item) in items.withIndex()) {
                val f = item.first
                val zp = ZipParameters()
                zp.fileNameInZip = item.second
                zp.lastModifiedFileTime = f.lastModified()
                zp.compressionMethod = if (f.isFile && f.extension.lowercase() in storedExts) CompressionMethod.STORE else CompressionMethod.DEFLATE
                if (pw != null && f.isFile) {
                    zp.isEncryptFiles = true
                    zp.encryptionMethod = EncryptionMethod.AES
                    zp.aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256
                }
                it.putNextEntry(zp)
                if (f.isFile) {
                    f.inputStream().use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            it.write(buf, 0, n)
                        }
                    }
                }
                it.closeEntry()
                prog(i + 1, items.size)
            }
        }
    }

    private fun compressTarGz(paths: List<String>, dst: String, prog: (Int, Int) -> Unit) {
        val items = collect(paths)
        TarArchiveOutputStream(GzipCompressorOutputStream(BufferedOutputStream(FileOutputStream(dst)))).use { tar ->
            tar.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX)
            tar.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX)
            for ((i, item) in items.withIndex()) {
                val f = item.first
                tar.putArchiveEntry(TarArchiveEntry(f, item.second))
                if (f.isFile) f.inputStream().use { it.copyTo(tar) }
                tar.closeArchiveEntry()
                prog(i + 1, items.size)
            }
            tar.finish()
        }
    }

    private fun compress7z(paths: List<String>, dst: String, pw: String?, prog: (Int, Int) -> Unit) {
        val items = collect(paths)
        val z = if (pw.isNullOrEmpty()) SevenZOutputFile(File(dst)) else SevenZOutputFile(File(dst), pw.toCharArray())
        z.use {
            val buf = ByteArray(64 * 1024)
            for ((i, item) in items.withIndex()) {
                val f = item.first
                it.putArchiveEntry(it.createArchiveEntry(f, item.second))
                if (f.isFile) {
                    f.inputStream().use { ins ->
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            it.write(buf, 0, n)
                        }
                    }
                }
                it.closeArchiveEntry()
                prog(i + 1, items.size)
            }
            it.finish()
        }
    }
}
