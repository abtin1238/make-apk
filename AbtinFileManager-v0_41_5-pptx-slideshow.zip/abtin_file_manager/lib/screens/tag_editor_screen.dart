import 'dart:io';
import 'dart:typed_data';
import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../services/native.dart';
import '../services/player_service.dart';
import '../services/playlist_store.dart';
import '../widgets/ui.dart';

/// Edits title / artist / album / genre / year / track / lyrics / cover of an audio file (mp3, m4a, flac).
/// The change is written to a temporary copy first and only replaces the original when that copy can be read back.
class TagEditorScreen extends StatefulWidget {
  final String path;
  const TagEditorScreen({super.key, required this.path});
  static const writable = {'mp3', 'm4a', 'mp4', 'flac'};
  @override
  State<TagEditorScreen> createState() => _TagEditorScreenState();
}

class _TagEditorScreenState extends State<TagEditorScreen> {
  final title = TextEditingController(), artist = TextEditingController(), album = TextEditingController();
  final genre = TextEditingController(), year = TextEditingController(), track = TextEditingController(), lyrics = TextEditingController();
  Uint8List? cover;
  bool coverChanged = false, loading = true, saving = false;

  bool get _ok => TagEditorScreen.writable.contains(p.extension(widget.path).toLowerCase().replaceFirst('.', ''));

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    for (final c in [title, artist, album, genre, year, track, lyrics]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final m = readMetadata(File(widget.path), getImage: true);
      title.text = m.title ?? '';
      artist.text = m.artist ?? '';
      album.text = m.album ?? '';
      final d = m as dynamic; // optional fields differ between formats
      try { genre.text = (d.genres as List).join(', '); } catch (_) {}
      try { final y = d.year; if (y != null) year.text = '${(y as DateTime).year}'; } catch (_) {}
      try { final t = d.trackNumber; if (t != null) track.text = '$t'; } catch (_) {}
      try { lyrics.text = (d.lyrics as String?) ?? ''; } catch (_) {}
      if (m.pictures.isNotEmpty) cover = m.pictures.first.bytes;
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  Future<void> _pickCover() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.image);
    final f = r?.files.single.path;
    if (f == null) return;
    final b = await File(f).readAsBytes();
    setState(() { cover = b; coverChanged = true; });
  }

  static String _mime(Uint8List b) => b.length > 4 && b[0] == 0x89 && b[1] == 0x50 ? 'image/png' : 'image/jpeg';

  Future<void> _save() async {
    if (!_ok) {
      snack(context, L.t('tagUnsupported'));
      return;
    }
    if (!await ensureSdAll(context, [widget.path])) return;
    if (!mounted) return;
    setState(() => saving = true);
    final viaSaf = await Saf.use(widget.path);
    final dir = viaSaf ? Directory.systemTemp.path : p.dirname(widget.path);
    final tmp = p.join(dir, '.abtin_tag_${p.basename(widget.path)}'); // keeps the extension so the right writer is chosen
    try {
      await File(widget.path).copy(tmp);
      await Future.sync(() => updateMetadata(File(tmp), (dynamic m) {
            void tryDo(void Function() fn) { try { fn(); } catch (_) {} }
            tryDo(() => m.setTitle(title.text.trim()));
            tryDo(() => m.setArtist(artist.text.trim()));
            tryDo(() => m.setAlbum(album.text.trim()));
            tryDo(() => m.setGenres([for (final g in genre.text.split(',')) if (g.trim().isNotEmpty) g.trim()]));
            final y = int.tryParse(year.text.trim());
            if (y != null) tryDo(() => m.setYear(DateTime(y)));
            final t = int.tryParse(track.text.trim());
            if (t != null) tryDo(() => m.setTrackNumber(t));
            tryDo(() => m.setLyrics(lyrics.text));
            if (coverChanged) {
              tryDo(() => m.setPictures(cover == null ? <Picture>[] : [Picture(cover!, _mime(cover!), PictureType.coverFront)]));
            }
          }));
      readMetadata(File(tmp), getImage: false); // must still be readable
      if (viaSaf) {
        await Saf.copyFileIn(tmp, widget.path);
        await File(tmp).delete();
      } else {
        await File(tmp).rename(widget.path);
      }
    } catch (e) {
      try { if (File(tmp).existsSync()) File(tmp).deleteSync(); } catch (_) {}
      if (mounted) {
        setState(() => saving = false);
        snack(context, '${L.t('error')}: $e');
      }
      return;
    }
    ArtCache.forget(widget.path);
    Native.scan(widget.path);
    if (mounted) {
      await context.read<PlayerService>().reloadMeta(widget.path);
    }
    if (!mounted) return;
    snack(context, L.t('tagSaved'));
    Navigator.pop(context, true);
  }

  Widget _f(TextEditingController c, String label, {int lines = 1, TextInputType? kb}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(controller: c, minLines: lines, maxLines: lines == 1 ? 1 : 8, keyboardType: kb, decoration: InputDecoration(labelText: label)),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(L.t('tagEdit'), style: const TextStyle(fontSize: 16)),
          actions: [IconButton(icon: const Icon(Icons.save_rounded), tooltip: L.t('save'), onPressed: loading || saving ? null : _save)],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : ListView(padding: const EdgeInsets.all(16), children: [
                Text(p.basename(widget.path), style: const TextStyle(fontSize: 12), maxLines: 2, overflow: TextOverflow.ellipsis),
                if (!_ok) Padding(padding: const EdgeInsets.only(top: 6), child: Text(L.t('tagUnsupported'), style: const TextStyle(color: Colors.orange))),
                const SizedBox(height: 12),
                Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: SizedBox(
                      width: 110,
                      height: 110,
                      child: cover != null ? Image.memory(cover!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.album_rounded, size: 48)) : Container(color: Colors.black26, child: const Icon(Icons.album_rounded, size: 48)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      OutlinedButton.icon(icon: const Icon(Icons.image_rounded), label: Text(L.t('tagPickCover')), onPressed: _pickCover),
                      if (cover != null) TextButton.icon(icon: const Icon(Icons.delete_outline_rounded), label: Text(L.t('tagRemoveCover')), onPressed: () => setState(() { cover = null; coverChanged = true; })),
                    ]),
                  ),
                ]),
                const SizedBox(height: 16),
                _f(title, L.t('tagTitle')),
                _f(artist, L.t('tagArtist')),
                _f(album, L.t('tagAlbum')),
                _f(genre, L.t('tagGenre')),
                Row(children: [
                  Expanded(child: _f(year, L.t('tagYear'), kb: TextInputType.number)),
                  const SizedBox(width: 12),
                  Expanded(child: _f(track, L.t('tagTrack'), kb: TextInputType.number)),
                ]),
                _f(lyrics, L.t('tagLyrics'), lines: 4),
              ]),
      );
}
