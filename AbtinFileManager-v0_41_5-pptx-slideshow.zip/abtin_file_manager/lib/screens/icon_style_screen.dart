import 'package:flutter/material.dart' hide Icon;
import 'package:provider/provider.dart';
import '../core/color_spec.dart';
import '../core/icon_prefs.dart';
import '../core/l10n.dart';
import '../core/layouts.dart';
import '../core/settings.dart';
import '../widgets/app_icon.dart';
import 'color_editor.dart';

/// Settings -> icon style:
///  1. the app-wide icon style (theme's own colours / theme gradient / custom gradient),
///  2. shape + colour (solid or gradient) of the folder and file-type icons,
///  3. every icon of the Abtin icon sheet, each with its own colour (solid or gradient).
class IconStyleScreen extends StatelessWidget {
  const IconStyleScreen({super.key});

  String _label(String k) => L.t('icon_$k');

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final cs = Theme.of(context).colorScheme;
    final mode = IconPrefs.mode;
    Widget head(String t) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 6),
          child: Text(t, style: Theme.of(context).textTheme.titleSmall?.copyWith(color: cs.primary, fontWeight: FontWeight.bold)),
        );
    Widget modeTile(int m, String title, String sub, Widget lead) => ListTile(
          leading: lead,
          title: Text(title),
          subtitle: Text(sub, maxLines: 2, overflow: TextOverflow.ellipsis),
          trailing: Icon(mode == m ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded, color: mode == m ? cs.primary : cs.outline),
          onTap: () => s.setIconMode(m),
        );
    return Scaffold(
      appBar: AppBar(title: Text(L.t('iconStyle')), actions: [
        IconButton(icon: const Icon(Icons.restart_alt_rounded), tooltip: L.t('resetIcons'), onPressed: s.resetIcons),
      ]),
      body: ListView(padding: const EdgeInsets.only(bottom: 24), children: [
        head(tr2('سبک کلی آیکون‌ها', 'Overall icon style')),
        modeTile(0, tr2('پیش‌فرض تم', 'Theme default'), tr2('آیکون‌ها با رنگ ساده‌ٔ تم', 'Icons use the plain colour of the theme'), const Icon(Icons.format_color_reset_rounded)),
        modeTile(
          1,
          tr2('گرادیانت تم', 'Theme gradient'),
          tr2('آیکون‌ها با گرادیانت رنگ اصلی و دوم تم (مثل ست آیکون)', 'Icons use the primary → secondary gradient of the theme (like the icon sheet)'),
          Container(width: 24, height: 24, decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [cs.primary, cs.secondary]))),
        ),
        modeTile(
          2,
          tr2('گرادیانت یا رنگ دلخواه', 'Custom colour / gradient'),
          tr2('خودتان رنگ یا گرادیانت همهٔ آیکون‌ها را انتخاب کنید', 'Pick the colour or gradient of all icons yourself'),
          Container(width: 24, height: 24, decoration: IconPrefs.custom.decoration(shape: BoxShape.circle)),
        ),
        if (mode == 2)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: FilledButton.tonalIcon(
                icon: const Icon(Icons.palette_rounded, size: 20),
                label: Text(tr2('ویرایش رنگ همهٔ آیکون‌ها', 'Edit colour of all icons')),
                onPressed: () => showColorSpecSheet(
                  context,
                  title: tr2('رنگ همهٔ آیکون‌ها', 'Colour of all icons'),
                  initial: IconPrefs.custom,
                  onCommit: s.setIconCustom,
                ),
              ),
            ),
          ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
          child: Text(
            tr2('آیکون‌هایی که در برنامه رنگ ثابت دارند (مثل دکمه‌ها یا پخش‌کننده) دست نمی‌خورند، مگر اینکه همان آیکون را پایین‌تر جداگانه رنگ کنید.', 'Icons that have a fixed colour in the app (buttons, players) are left alone unless you recolour that icon below.'),
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
        head(tr2('پوشه و نوع فایل‌ها', 'Folder and file types')),
        for (final k in IconPrefs.keys)
          ListTile(
            leading: KeyIcon(k, size: 38),
            title: Text(_label(k)),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              builder: (_) => _TypeSheet(k: k, title: _label(k)),
            ),
          ),
        head(tr2('همهٔ آیکون‌های ست (رنگ تک‌تک آیکون‌ها)', 'All icons of the set (colour each one)')),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Wrap(spacing: 4, runSpacing: 4, children: [
            for (final p in iconPack) _PackTile(item: p),
          ]),
        ),
        if (IconPrefs.overrides.isNotEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: TextButton.icon(
                icon: const Icon(Icons.restart_alt_rounded, size: 20),
                label: Text(tr2('بازنشانی رنگ تک‌تک آیکون‌ها', 'Reset the per-icon colours')),
                onPressed: s.resetIconOverrides,
              ),
            ),
          ),
      ]),
    );
  }
}

class _PackTile extends StatelessWidget {
  final PackIcon item;
  const _PackTile({required this.item});

  @override
  Widget build(BuildContext context) {
    final s = context.read<AppSettings>();
    final cs = Theme.of(context).colorScheme;
    final id = IconPrefs.idOf(item.icon);
    final over = IconPrefs.overrides[id];
    final w = (MediaQuery.of(context).size.width - 24 - 4 * 4) / 5;
    return SizedBox(
      width: w.floorToDouble(),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => showColorSpecSheet(
          context,
          title: item.name,
          leading: Icon(item.icon, size: 36),
          initial: over ?? ColorSpec(cs.primary.value, cs.secondary.value),
          onCommit: (c) => s.setIconOverride(id, c),
          onReset: over == null ? null : () => s.setIconOverride(id, null),
        ),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: over != null ? cs.primary.withOpacity(.7) : cs.outlineVariant.withOpacity(.5)),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(item.icon, size: 28),
            const SizedBox(height: 4),
            Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10)),
          ]),
        ),
      ),
    );
  }
}

class _TypeSheet extends StatelessWidget {
  final String k, title;
  const _TypeSheet({required this.k, required this.title});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final cs = Theme.of(context).colorScheme;
    final shapes = IconPrefs.options[k]!;
    final sel = IconPrefs.shapes[k] ?? 0;
    return SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(context).viewInsets.bottom),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            KeyIcon(k, size: 44),
            const SizedBox(width: 12),
            Expanded(child: Text(title, style: Theme.of(context).textTheme.titleMedium)),
            TextButton(
              onPressed: () {
                s.setIconSpec(k, null);
                s.setIconShape(k, null);
              },
              child: Text(L.t('resetIcons')),
            ),
          ]),
          const SizedBox(height: 14),
          Text(L.t('iconShape')),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (var i = 0; i < shapes.length; i++)
              InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () => s.setIconShape(k, i),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: sel == i ? cs.primary : Colors.black26, width: sel == i ? 2.5 : 1),
                  ),
                  child: SpecIcon(shapes[i], IconPrefs.spec(k), size: 34),
                ),
              ),
          ]),
          const SizedBox(height: 18),
          Text(L.t('iconColor')),
          const SizedBox(height: 8),
          ColorSpecEditor(initial: IconPrefs.spec(k), onCommit: (c) => s.setIconSpec(k, c)),
        ]),
      ),
    );
  }
}
