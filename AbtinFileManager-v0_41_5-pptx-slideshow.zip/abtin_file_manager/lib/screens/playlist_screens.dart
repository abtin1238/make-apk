import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../services/player_service.dart';
import '../services/playlist_store.dart';
import '../widgets/ui.dart';
import 'audio_player_screen.dart';

Future<void> _play(BuildContext context, List<String> paths, int start, {bool shuffle = false}) async {
  if (paths.isEmpty) return;
  final list = shuffle ? (List.of(paths)..shuffle()) : paths;
  await context.read<PlayerService>().playList(list, shuffle ? 0 : start);
  if (context.mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const AudioPlayerScreen()));
}

/// Bottom sheet: choose a playlist (or create one) and add [paths] to it.
Future<void> addToPlaylist(BuildContext context, List<String> paths) async {
  final r = await showModalBottomSheet<Object>(
    context: context,
    builder: (_) => SafeArea(
      child: ListView(shrinkWrap: true, children: [
        ListTile(leading: const Icon(Icons.add_rounded), title: Text(L.t('newPlaylist')), onTap: () => Navigator.pop(context, 'new')),
        for (final l in PlaylistStore.lists)
          ListTile(leading: const Icon(Icons.queue_music_rounded), title: Text(l.name), subtitle: Text('${l.tracks.length}'), onTap: () => Navigator.pop(context, l)),
      ]),
    ),
  );
  if (r == null || !context.mounted) return;
  Playlist? l;
  if (r == 'new') {
    final n = await promptText(context, L.t('newPlaylist'));
    if (n == null || n.trim().isEmpty) return;
    l = PlaylistStore.create(n);
  } else {
    l = r as Playlist;
  }
  PlaylistStore.add(l, paths);
  if (context.mounted) snack(context, '${L.t('done')}: ${l.name}');
}

/// Tab with the user's playlists + create / import .m3u.
class PlaylistsTab extends StatefulWidget {
  const PlaylistsTab({super.key});
  @override
  State<PlaylistsTab> createState() => _PlaylistsTabState();
}

class _PlaylistsTabState extends State<PlaylistsTab> {
  Future<void> _new() async {
    final n = await promptText(context, L.t('newPlaylist'));
    if (n == null || n.trim().isEmpty) return;
    setState(() => PlaylistStore.create(n));
  }

  Future<void> _import() async {
    final r = await FilePicker.platform.pickFiles();
    final path = r?.files.single.path;
    if (path == null || !mounted) return;
    try {
      final t = await PlaylistStore.parseM3u(path);
      if (t.isEmpty) {
        if (mounted) snack(context, L.t('empty'));
        return;
      }
      setState(() => PlaylistStore.create(p.basenameWithoutExtension(path), t));
      if (mounted) snack(context, '${L.t('done')}: ${t.length}');
    } catch (e) {
      if (mounted) snack(context, '${L.t('error')}: $e');
    }
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
          child: Row(children: [
            Expanded(child: FilledButton.icon(icon: const Icon(Icons.add_rounded), label: Text(L.t('newPlaylist')), onPressed: _new)),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.file_open_rounded), label: Text(L.t('importM3u')), onPressed: _import)),
          ]),
        ),
        Expanded(
          child: PlaylistStore.lists.isEmpty
              ? Center(child: Text(L.t('empty')))
              : ListView.builder(
                  itemCount: PlaylistStore.lists.length,
                  itemBuilder: (_, i) {
                    final l = PlaylistStore.lists[i];
                    return ListTile(
                      leading: const Icon(Icons.queue_music_rounded, color: AppColors.gold, size: 34),
                      title: Text(l.name),
                      subtitle: Text('${l.tracks.length}', style: const TextStyle(fontSize: 11)),
                      onTap: () async {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => TrackListScreen(title: l.name, paths: l.tracks, playlist: l)));
                        if (mounted) setState(() {});
                      },
                      onLongPress: () async {
                        if (await confirm(context, '${L.t('delete')} "${l.name}"?')) setState(() => PlaylistStore.remove(l));
                      },
                    );
                  },
                ),
        ),
      ]);
}

/// Album / artist tab: groups audio files by tag.
class GroupTab extends StatelessWidget {
  final Map<String, List<String>> groups;
  final bool done;
  final bool grid; // album cover grid
  const GroupTab({super.key, required this.groups, required this.done, this.grid = false});
  @override
  Widget build(BuildContext context) {
    final keys = groups.keys.toList()..sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    if (keys.isEmpty) return Center(child: done ? Text(L.t('empty')) : const CircularProgressIndicator());
    if (grid) {
      return GridView.builder(
        padding: const EdgeInsets.all(10),
        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 180, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.78),
        itemCount: keys.length,
        itemBuilder: (_, i) {
          final name = keys[i].isEmpty ? L.t('unknown') : keys[i];
          final tracks = groups[keys[i]]!;
          return InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TrackListScreen(title: name, paths: tracks))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: SizedBox.expand(
                    child: FutureBuilder<File?>(
                      future: ArtCache.get(tracks.first),
                      builder: (_, s) => s.data != null
                          ? Image.file(s.data!, fit: BoxFit.cover, cacheWidth: 360, gaplessPlayback: true, errorBuilder: (_, __, ___) => _noArt())
                          : _noArt(),
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 6),
              Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
              Text('${tracks.length}', style: const TextStyle(fontSize: 11, color: Colors.white54)),
            ]),
          );
        },
      );
    }
    return ListView.builder(
      itemCount: keys.length,
      itemBuilder: (_, i) => ListTile(
        leading: const CircleAvatar(backgroundColor: Colors.black26, child: Icon(Icons.album_rounded, color: AppColors.gold)),
        title: Text(keys[i].isEmpty ? L.t('unknown') : keys[i], maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('${groups[keys[i]]!.length}', style: const TextStyle(fontSize: 11)),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TrackListScreen(title: keys[i].isEmpty ? L.t('unknown') : keys[i], paths: groups[keys[i]]!))),
      ),
    );
  }
}

Widget _noArt() => Container(color: Colors.black26, child: const Center(child: Icon(Icons.album_rounded, size: 48, color: AppColors.gold)));

/// Tracks of a playlist / album / artist. With [playlist]: remove, reorder, rename, export .m3u8.
class TrackListScreen extends StatefulWidget {
  final String title;
  final List<String> paths;
  final Playlist? playlist;
  const TrackListScreen({super.key, required this.title, required this.paths, this.playlist});
  @override
  State<TrackListScreen> createState() => _TrackListScreenState();
}

class _TrackListScreenState extends State<TrackListScreen> {
  late String title = widget.title;
  List<String> get paths => widget.paths;

  @override
  Widget build(BuildContext context) {
    final pl = widget.playlist;
    return Scaffold(
      appBar: AppBar(title: Text(title), actions: [
        if (pl == null) IconButton(icon: const Icon(Icons.playlist_add_rounded), tooltip: L.t('addToPlaylist'), onPressed: () => addToPlaylist(context, paths))
        else PopupMenuButton<String>(
          onSelected: (v) async {
            if (v == 'rename') {
              final n = await promptText(context, L.t('rename'), initial: pl.name);
              if (n != null && n.trim().isNotEmpty) setState(() { pl.name = n.trim(); title = pl.name; PlaylistStore.save(); });
            } else {
              try {
                final out = await PlaylistStore.exportM3u(pl);
                Native.scan(out);
                if (context.mounted) snack(context, '${L.t('done')}: $out');
              } catch (e) {
                if (context.mounted) snack(context, '${L.t('error')}: $e');
              }
            }
          },
          itemBuilder: (_) => [
            PopupMenuItem(value: 'rename', child: Text(L.t('rename'))),
            PopupMenuItem(value: 'export', child: Text(L.t('exportM3u'))),
          ],
        ),
      ]),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: Row(children: [
            Expanded(child: FilledButton.icon(icon: const Icon(Icons.play_arrow_rounded), label: Text(L.t('playAll')), onPressed: paths.isEmpty ? null : () => _play(context, paths, 0))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.shuffle_rounded), label: Text(L.t('shuffle')), onPressed: paths.isEmpty ? null : () => _play(context, paths, 0, shuffle: true))),
          ]),
        ),
        Expanded(
          child: paths.isEmpty
              ? Center(child: Text(L.t('empty')))
              : ReorderableListView.builder(
                  buildDefaultDragHandles: pl != null,
                  itemCount: paths.length,
                  onReorder: (a, b) {
                    if (pl == null) return;
                    setState(() {
                      if (b > a) b--;
                      paths.insert(b, paths.removeAt(a));
                      PlaylistStore.save();
                    });
                  },
                  itemBuilder: (_, i) => ListTile(
                    key: ValueKey('$i${paths[i]}'),
                    leading: const Icon(Icons.music_note_rounded, color: AppColors.gold),
                    title: Text(p.basenameWithoutExtension(paths[i]), maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(p.basename(p.dirname(paths[i])), maxLines: 1, style: const TextStyle(fontSize: 11)),
                    trailing: pl == null
                        ? null
                        : Padding(
                            padding: const EdgeInsetsDirectional.only(end: 28),
                            child: IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(() { paths.removeAt(i); PlaylistStore.save(); })),
                          ),
                    onTap: () => _play(context, paths, i),
                  ),
                ),
        ),
      ]),
    );
  }
}
