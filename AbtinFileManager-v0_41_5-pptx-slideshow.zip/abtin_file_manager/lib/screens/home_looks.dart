import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart' hide Icon;
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/layouts.dart';
import '../core/looks.dart';
import 'more_screen.dart';
import '../core/settings.dart';
import '../services/file_ops.dart';
import '../widgets/adaptive_nav.dart';
import '../widgets/app_icon.dart';
import '../widgets/glass_kit.dart';
import '../widgets/neon_kit.dart';
import '../widgets/ui.dart';
import 'analyzer_screen.dart';
import 'browser_screen.dart';
import 'category_screen.dart';
import 'duplicates_screen.dart';
import 'home_cats.dart';
import 'home_variants.dart' show StorageBuilder;
import 'opener.dart';
import 'search_screen.dart';
import 'trash_screen.dart';
import 'transfer_screen.dart';

// Home screens of the look themes (Settings -> theme look):
//   ToolsHome  – neon + gradient looks: storage card with ring, quick chips, recent files, quick-tools grid
//   GlassHome  – glass look: storage card, quick access tiles, folder list

void _go(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));

String _rootName(StorageRoot r) => r.sd ? '${L.t('sdcard')} (${r.name})' : L.t('internal');

/// The newest [max] recent files that still exist.
List<String> recentFiles(AppSettings s, int max) {
  final out = <String>[];
  for (final p in s.recents) {
    if (out.length >= max) break;
    try {
      if (File(p).existsSync()) out.add(p);
    } catch (_) {}
  }
  return out;
}

String _baseName(String p) {
  final i = p.lastIndexOf('/');
  return i < 0 ? p : p.substring(i + 1);
}

// ------------------------------------------------------------------ ring

class RingPainter extends CustomPainter {
  final double value;
  final List<Color> colors;
  final Color track;
  final double stroke;
  RingPainter({required this.value, required this.colors, required this.track, this.stroke = 10});

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = (math.min(size.width, size.height) - stroke) / 2;
    final rect = Rect.fromCircle(center: c, radius: r);
    canvas.drawCircle(c, r, Paint()..style = PaintingStyle.stroke..strokeWidth = stroke..color = track);
    final v = value < 0 ? 0.0 : (value > 1 ? 1.0 : value);
    if (v <= 0) return;
    final sweep = 2 * math.pi * v;
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = stroke
      ..strokeCap = StrokeCap.round
      ..shader = SweepGradient(
        startAngle: 0,
        endAngle: sweep < 0.1 ? 0.1 : sweep,
        colors: colors,
        transform: const GradientRotation(-math.pi / 2),
      ).createShader(rect);
    canvas.drawArc(rect, -math.pi / 2, sweep, false, p);
  }

  @override
  bool shouldRepaint(RingPainter o) => o.value != value || o.track != track || o.stroke != stroke || o.colors.length != colors.length || o.colors.first != colors.first || o.colors.last != colors.last;
}

/// Circular usage meter with the percentage in the middle.
class StorageRing extends StatelessWidget {
  final double value, size, stroke;
  final List<Color> colors;
  final Color track, textColor;
  const StorageRing({super.key, required this.value, required this.colors, required this.track, required this.textColor, this.size = 96, this.stroke = 10});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: size,
        height: size,
        child: CustomPaint(
          painter: RingPainter(value: value, colors: colors, track: track, stroke: stroke),
          child: Center(child: Text('${(value * 100).round()}%', style: TextStyle(color: textColor, fontSize: size * .23, fontWeight: FontWeight.bold))),
        ),
      );
}

double _ratio(int t, int used) => t == 0 ? 0.0 : (used / t).clamp(0.0, 1.0).toDouble();

// ------------------------------------------------------------------ neon + gradient home

class _Tool {
  final IconData icon;
  final String fa, en;
  final Color color;
  final void Function(BuildContext) run;
  const _Tool(this.icon, this.fa, this.en, this.color, this.run);
}

Future<void> _newFolder(BuildContext c) async {
  final name = await promptText(c, tr2('ایجاد پوشه', 'Create folder'));
  if (name == null || name.isEmpty || !c.mounted) return;
  final ok = await busy(c, () => FileOps.mkdir(FileOps.root, name));
  if (ok && c.mounted) snack(c, '${tr2('پوشه ساخته شد', 'Folder created')}: $name');
}

void _storageDetails(BuildContext c) {
  showModalBottomSheet<void>(
    context: c,
    builder: (ctx) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(tr2('جزئیات حافظه', 'Storage details'), style: Theme.of(ctx).textTheme.titleMedium),
          const SizedBox(height: 12),
          for (final r in FileOps.roots())
            StorageBuilder(
              root: r,
              builder: (t, used) => Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(_rootName(r), style: const TextStyle(fontWeight: FontWeight.w600)),
                  const SizedBox(height: 6),
                  ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: _ratio(t, used), minHeight: 8)),
                  const SizedBox(height: 6),
                  Text(t == 0 ? '…' : '${tr2('استفاده‌شده', 'Used')}: ${FileOps.fmt(used)}   •   ${tr2('آزاد', 'Free')}: ${FileOps.fmt(t - used)}   •   ${tr2('کل', 'Total')}: ${FileOps.fmt(t)}', style: const TextStyle(fontSize: 12)),
                ]),
              ),
            ),
          FilledButton.icon(
            icon: const Icon(Icons.pie_chart_rounded, size: 20),
            label: Text(L.t('analyzer')),
            onPressed: () {
              Navigator.pop(ctx);
              _go(c, const AnalyzerScreen());
            },
          ),
        ]),
      ),
    ),
  );
}

final List<_Tool> _tools = [
  _Tool(Icons.delete_rounded, 'زباله‌دان', 'Trash', const Color(0xFFFF9F43), (c) => _go(c, const TrashScreen())),
  _Tool(Icons.download_rounded, 'دانلودها', 'Downloads', const Color(0xFF2ECC71), (c) => _go(c, const BrowserScreen(initialPath: FileOps.downloads))),
  _Tool(Icons.content_copy_rounded, 'فایل‌های تکراری', 'Duplicate files', const Color(0xFF2F6BFF), (c) => _go(c, const DuplicatesScreen())),
  _Tool(Icons.cleaning_services_rounded, 'پاکسازی فایل‌های اضافی', 'Clean junk files', const Color(0xFF8B5CF6), (c) => _go(c, const AnalyzerScreen())),
  _Tool(Icons.info_rounded, 'جزئیات حافظه', 'Storage details', const Color(0xFF8B5CF6), _storageDetails),
  _Tool(Icons.create_new_folder_rounded, 'ایجاد پوشه', 'New folder', const Color(0xFF2F6BFF), (c) => _newFolder(c)),
  _Tool(Icons.share_rounded, 'اشتراک‌گذاری', 'Share', const Color(0xFF29B6F6), (c) => _go(c, const TransferScreen())),
  _Tool(Icons.inventory_2_rounded, 'فشرده‌سازی', 'Archives', const Color(0xFF8B5CF6), (c) => _go(c, const CategoryScreen(cat: Cat.archives))),
];

class _SectionTitle extends StatelessWidget {
  final IconData icon;
  final String text;
  const _SectionTitle(this.icon, this.text);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 10),
        child: Row(children: [
          Icon(icon, size: 22),
          const SizedBox(width: 8),
          Text(text, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ]),
      );
}

/// Storage card: gradient fill in the gradient look, glowing outline in the neon look.
class _Hero extends StatelessWidget {
  final StorageRoot root;
  const _Hero({required this.root});

  @override
  Widget build(BuildContext context) {
    AppStyleScope.watch(context);
    final cs = Theme.of(context).colorScheme;
    final filled = Looks.current == 'gradient';
    final fg = filled ? Colors.white : cs.onSurface;
    final r = BorderRadius.circular(28);
    return StorageBuilder(
      root: root,
      builder: (t, used) {
        final content = Row(children: [
          StorageRing(
            value: _ratio(t, used),
            colors: filled ? const [Colors.white, Colors.white] : Looks.accentColors(cs),
            track: filled ? Colors.white24 : cs.onSurface.withOpacity(.12),
            textColor: fg,
            size: 104,
            stroke: 11,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(_rootName(root), style: TextStyle(color: fg.withOpacity(.75), fontSize: 14)),
              const SizedBox(height: 4),
              FittedBox(fit: BoxFit.scaleDown, alignment: AlignmentDirectional.centerStart, child: Text(t == 0 ? '…' : FileOps.fmt(used), style: TextStyle(color: fg, fontSize: 32, fontWeight: FontWeight.bold))),
              const SizedBox(height: 4),
              Text(t == 0 ? '' : '${tr2('از', 'of')} ${FileOps.fmt(t)} • ${FileOps.fmt(t - used)} ${tr2('آزاد', 'free')}', style: TextStyle(color: fg.withOpacity(.75), fontSize: 12)),
            ]),
          ),
          Icon(Icons.storage_rounded, size: 64, color: filled ? Colors.white : null),
        ]);
        void open() => _go(context, BrowserScreen(initialPath: root.path, root: true));
        if (Looks.current == 'neon') {
          // glowing card with bevelled corners (mockup)
          return NeonCutCard(onTap: open, child: content);
        }
        return DecoratedBox(
          decoration: Looks.accent(cs, radius: r),
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(borderRadius: r, onTap: open, child: Padding(padding: const EdgeInsets.all(18), child: content)),
          ),
        );
      },
    );
  }
}

class _MiniStorage extends StatelessWidget {
  final StorageRoot root;
  const _MiniStorage({required this.root});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(top: 10),
        child: StorageBuilder(
          root: root,
          builder: (t, used) => GradCard(
            onTap: () => _go(context, BrowserScreen(initialPath: root.path, root: true)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                const Icon(Icons.sd_card_rounded, size: 20),
                const SizedBox(width: 8),
                Expanded(child: Text(_rootName(root), style: const TextStyle(fontWeight: FontWeight.w600))),
                Text(t == 0 ? '' : '${FileOps.fmt(used)} / ${FileOps.fmt(t)}', style: const TextStyle(fontSize: 12)),
              ]),
              const SizedBox(height: 8),
              ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: _ratio(t, used), minHeight: 6)),
            ]),
          ),
        ),
      );
}

/// Home of the neon and gradient looks.
class ToolsHome extends StatelessWidget {
  const ToolsHome({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    AppStyleScope.watch(context);
    final cats = homeCats();
    final roots = FileOps.roots();
    final recents = recentFiles(s, 4);
    final width = MediaQuery.of(context).size.width;
    final cols = (width ~/ 150).clamp(4, 8).toInt();
    final chips = [for (final k in const ['images', 'videos', 'music']) homeCat(cats, k)].whereType<HomeCat>().toList();
    final neon = Looks.current == 'neon';
    final page = SafeArea(
      child: MaxWidth(
        width: 960,
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 6, 16, 24), children: [
          Row(children: [
            const SizedBox(width: 48),
            const Expanded(child: Text('Abtin File Manager', textAlign: TextAlign.center, style: TextStyle(fontSize: 21, fontWeight: FontWeight.w600))),
            IconButton(icon: const Icon(Icons.search_rounded), onPressed: () => _go(context, const SearchScreen())),
          ]),
          const SizedBox(height: 6),
          if (roots.isNotEmpty) _Hero(root: roots.first),
          for (final r in roots.skip(1)) _MiniStorage(root: r),
          const SizedBox(height: 14),
          Row(children: [
            for (var i = 0; i < chips.length; i++) ...[
              if (i > 0) const SizedBox(width: 10),
              Expanded(
                child: GradCard(
                  radius: 30,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 12),
                  onTap: () => _go(context, chips[i].page),
                  child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(chips[i].icon, color: chips[i].color, size: 24),
                    const SizedBox(width: 8),
                    Flexible(child: Text(L.t(chips[i].key), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600))),
                  ]),
                ),
              ),
            ],
          ]),
          _SectionTitle(Icons.history_rounded, tr2('فایل‌های اخیر', 'Recent files')),
          if (recents.isEmpty)
            Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(tr2('هنوز فایلی باز نشده است', 'No files opened yet'), style: Theme.of(context).textTheme.bodySmall))
          else
            Row(children: [
              for (var i = 0; i < 4; i++) ...[
                if (i > 0) const SizedBox(width: 10),
                Expanded(
                  child: i < recents.length
                      ? GradCard(
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 12),
                          onTap: () => Opener.open(context, recents[i]),
                          child: Column(children: [
                            TypeIcon(recents[i], false, size: 36),
                            const SizedBox(height: 6),
                            Text(_baseName(recents[i]), maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.5)),
                          ]),
                        )
                      : const SizedBox(),
                ),
              ],
            ]),
          _SectionTitle(Icons.bolt_rounded, tr2('ابزارهای سریع', 'Quick tools')),
          GridView.count(
            crossAxisCount: cols,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: .95,
            children: [
              for (final t in _tools)
                GradCard(
                  padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
                  onTap: () => t.run(context),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Icon(t.icon, color: t.color, size: 30),
                    const SizedBox(height: 8),
                    Text(tr2(t.fa, t.en), maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.5)),
                  ]),
                ),
            ],
          ),
        ]),
      ),
    );
    return neon ? NeonBackdrop(child: page) : page;
  }
}

// ------------------------------------------------------------------ glass home

class _FolderRow extends StatelessWidget {
  final String path, title;
  const _FolderRow({required this.path, required this.title});

  Future<int> _count() async {
    try {
      return await Directory(path).list().length;
    } catch (_) {
      return 0;
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 8),
        leading: const TypeIcon('', true, size: 44),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: FutureBuilder<int>(
          future: _count(),
          builder: (c, snap) => Text(snap.hasData ? '${snap.data} ${tr2('مورد', 'items')}' : '…', style: const TextStyle(fontSize: 12)),
        ),
        trailing: PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert_rounded),
          onSelected: (v) {
            if (v == 'open') _go(context, BrowserScreen(initialPath: path));
            if (v == 'fav') s.toggleFav(path);
          },
          itemBuilder: (_) => [
            PopupMenuItem(value: 'open', child: Text(tr2('باز کردن', 'Open'))),
            PopupMenuItem(value: 'fav', child: Text(s.isFav(path) ? tr2('حذف از علاقه‌مندی‌ها', 'Remove from favourites') : tr2('افزودن به علاقه‌مندی‌ها', 'Add to favourites'))),
          ],
        ),
        onTap: () => _go(context, BrowserScreen(initialPath: path)),
      ),
    );
  }
}

/// Storage card of the glass look: ring with drive icon + percentage, "used / total" and the usage wave.
class _GlassStorageCard extends StatefulWidget {
  final StorageRoot root;
  const _GlassStorageCard({required this.root});
  @override
  State<_GlassStorageCard> createState() => _GlassStorageCardState();
}

class _GlassStorageCardState extends State<_GlassStorageCard> {
  List<double> _hist = const [];
  double _lastRecorded = -1;

  @override
  void initState() {
    super.initState();
    UsageHistory.load(widget.root.path).then((v) {
      if (mounted) setState(() => _hist = v);
    });
  }

  void _record(double ratio) {
    if (ratio <= 0 || (ratio - _lastRecorded).abs() < 1e-6) return;
    _lastRecorded = ratio;
    UsageHistory.record(widget.root.path, ratio).then((v) {
      if (mounted) setState(() => _hist = v);
    });
  }

  @override
  Widget build(BuildContext context) {
    AppStyleScope.watch(context);
    final cs = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final r = widget.root;
    final glow = const Color(0xFF22E4C8);
    return StorageBuilder(
      root: r,
      builder: (t, used) {
        final ratio = _ratio(t, used);
        if (t > 0) WidgetsBinding.instance.addPostFrameCallback((_) => _record(ratio));
        return DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(26),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: dark ? [glow.withOpacity(.14), cs.primary.withOpacity(.06)] : [Colors.white.withOpacity(.9), glow.withOpacity(.10)],
            ),
            border: Border.all(color: glow.withOpacity(dark ? .55 : .35), width: 1.2),
            boxShadow: [BoxShadow(color: glow.withOpacity(dark ? .22 : .12), blurRadius: 18, spreadRadius: -4)],
          ),
          child: Material(
            type: MaterialType.transparency,
            child: InkWell(
              borderRadius: BorderRadius.circular(26),
              onTap: () => _go(context, BrowserScreen(initialPath: r.path, root: true)),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(children: [
                  SizedBox(
                    width: 96,
                    height: 96,
                    child: CustomPaint(
                      painter: RingPainter(value: ratio, colors: const [Color(0xFF2F8CFF), Color(0xFF22E4C8)], track: cs.onSurface.withOpacity(.10), stroke: 9),
                      child: Center(
                        child: Column(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.storage_rounded, size: 24, color: Color(0xFF3B82F6)),
                          const SizedBox(height: 2),
                          Text('${(ratio * 100).round()}%', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                        ]),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(_rootName(r), style: TextStyle(color: cs.onSurface.withOpacity(.65), fontSize: 12.5)),
                      const SizedBox(height: 2),
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        alignment: AlignmentDirectional.centerStart,
                        child: Text.rich(TextSpan(children: [
                          TextSpan(text: t == 0 ? '…' : FileOps.fmt(used), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                          if (t != 0) TextSpan(text: ' / ${FileOps.fmt(t)}', style: TextStyle(fontSize: 15, color: cs.onSurface.withOpacity(.55))),
                        ])),
                      ),
                      const SizedBox(height: 8),
                      // the wave always runs left -> right (time axis), also in RTL
                      Directionality(textDirection: TextDirection.ltr, child: Sparkline(samples: _hist, a: const Color(0xFF22B8F5), b: glow)),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
        );
      },
    );
  }
}

/// Quick-access tile of the glass look: tinted glass tile + gradient icon square.
class _QuickTile extends StatelessWidget {
  final HomeCat cat;
  final VoidCallback onTap;
  const _QuickTile({required this.cat, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final c = cat.color;
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: c.withOpacity(dark ? .13 : .10),
        border: Border.all(color: c.withOpacity(dark ? .28 : .22)),
        boxShadow: [BoxShadow(color: c.withOpacity(dark ? .18 : .08), blurRadius: 14, spreadRadius: -4)],
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
            child: Column(children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  gradient: LinearGradient(colors: [c, c.withOpacity(.6)], begin: Alignment.topLeft, end: Alignment.bottomRight),
                ),
                child: Icon(cat.icon, color: Colors.white, size: 26),
              ),
              const SizedBox(height: 8),
              Text(L.t(cat.key), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5)),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Home of the glass look: storage card, quick-access tiles, folder list.
class GlassHome extends StatelessWidget {
  const GlassHome({super.key});

  @override
  Widget build(BuildContext context) {
    AppStyleScope.watch(context);
    final cats = homeCats();
    final roots = FileOps.roots();
    final quick = [for (final k in const ['images', 'videos', 'music', 'apps']) homeCat(cats, k)].whereType<HomeCat>().toList();
    final folders = <List<String>>[
      [FileOps.downloads, tr2('دانلودها', 'Download')],
      ['${FileOps.root}/Pictures', tr2('تصاویر', 'Pictures')],
      ['${FileOps.root}/Music', tr2('موسیقی', 'Music')],
      ['${FileOps.root}/Documents', tr2('اسناد', 'Documents')],
    ].where((f) => Directory(f[0]).existsSync()).toList();
    return SafeArea(
      child: MaxWidth(
        width: 960,
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 6, 16, 24), children: [
          Row(children: [
            Expanded(child: Text(tr2('فایل‌ها', 'Files'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
            IconButton(icon: const Icon(Icons.search_rounded), onPressed: () => _go(context, const SearchScreen())),
            IconButton(icon: const Icon(Icons.more_vert_rounded), onPressed: () => _go(context, const MoreScreen())),
          ]),
          const SizedBox(height: 8),
          for (final r in roots) Padding(padding: const EdgeInsets.only(bottom: 10), child: _GlassStorageCard(root: r)),
          Padding(padding: const EdgeInsets.only(top: 12, bottom: 10), child: Text(tr2('دسترسی سریع', 'Quick access'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
          Row(children: [
            for (var i = 0; i < quick.length; i++) ...[
              if (i > 0) const SizedBox(width: 10),
              Expanded(child: _QuickTile(cat: quick[i], onTap: () => _go(context, quick[i].page))),
            ],
          ]),
          Padding(
            padding: const EdgeInsets.only(top: 22, bottom: 6),
            child: Row(children: [
              Expanded(child: Text(tr2('پوشه‌ها', 'Folders'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
              TextButton(
                onPressed: () => _go(context, const BrowserScreen(initialPath: FileOps.root, root: true)),
                child: Text(tr2('همه', 'See all')),
              ),
            ]),
          ),
          for (final f in folders) _FolderRow(path: f[0], title: f[1]),
        ]),
      ),
    );
  }
}
