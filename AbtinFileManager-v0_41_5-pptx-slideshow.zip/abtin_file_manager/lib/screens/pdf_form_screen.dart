import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'saf_prompt.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/pdf_native.dart';
import '../widgets/ui.dart';

/// Fill AcroForm fields of a PDF. Pops with the path of the new file (or null).
class PdfFormScreen extends StatefulWidget {
  final String path;
  /// set when [path] is a decrypted temp copy: the result is named after / saved next to this file
  final String? origPath;
  const PdfFormScreen({super.key, required this.path, this.origPath});
  @override
  State<PdfFormScreen> createState() => _PdfFormScreenState();
}

class _PdfFormScreenState extends State<PdfFormScreen> {
  List<Map<String, dynamic>>? fields;
  final vals = <String, dynamic>{};
  final ctrls = <String, TextEditingController>{};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final f = await PdfNative.fields(widget.path);
      for (final e in f) {
        final n = e['name'] as String;
        vals[n] = e['value'];
        if (e['type'] == 'text') ctrls[n] = TextEditingController(text: '${e['value'] ?? ''}');
      }
      if (mounted) setState(() => fields = f);
    } catch (e) {
      if (mounted) {
        snack(context, '${L.t('error')}: $e');
        Navigator.pop(context);
      }
    }
  }

  Future<void> _save() async {
    for (final e in ctrls.entries) {
      vals[e.key] = e.value.text;
    }
    if (!await ensureSdAll(context, [widget.origPath ?? widget.path])) return;
    final out = FileOps.unique(p.dirname(widget.origPath ?? widget.path), '${p.basenameWithoutExtension(widget.origPath ?? widget.path)} (filled).pdf');
    List<String> failed = [];
    final ok = await busy(context, () async {
      failed = await PdfNative.fill(widget.path, out, vals);
    });
    if (!ok || !mounted) return;
    if (failed.isNotEmpty) snack(context, '${L.t('error')}: ${failed.join(', ')}');
    Navigator.pop(context, out);
  }

  Widget _row(Map<String, dynamic> f) {
    final n = f['name'] as String;
    final ro = f['ro'] == true;
    switch (f['type']) {
      case 'text':
        return TextField(
          controller: ctrls[n],
          enabled: !ro,
          maxLines: f['multi'] == true ? null : 1,
          decoration: InputDecoration(labelText: n),
        );
      case 'check':
        return SwitchListTile(
          title: Text(n),
          value: vals[n] == true,
          onChanged: ro ? null : (v) => setState(() => vals[n] = v),
        );
      default:
        final opts = ((f['options'] as List?) ?? []).map((e) => '$e').toList();
        final cur = '${vals[n] ?? ''}';
        return DropdownButtonFormField<String>(
          value: opts.contains(cur) ? cur : null,
          decoration: InputDecoration(labelText: n),
          items: [for (final o in opts) DropdownMenuItem(value: o, child: Text(o))],
          onChanged: ro ? null : (v) => setState(() => vals[n] = v),
        );
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(L.t('fillForm')),
          actions: [IconButton(icon: const Icon(Icons.save_rounded), onPressed: fields == null || fields!.isEmpty ? null : _save)],
        ),
        body: fields == null
            ? const Center(child: CircularProgressIndicator())
            : fields!.isEmpty
                ? Center(child: Text(L.t('noFormFields')))
                : ListView(padding: const EdgeInsets.all(12), children: [
                    for (final f in fields!) Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: _row(f)),
                  ]),
      );
}
