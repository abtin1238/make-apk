import 'dart:async';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../widgets/ui.dart';
import 'browser_screen.dart';
import 'opener.dart';
import 'duplicates_screen.dart';

class SearchScreen extends StatefulWidget {
  final String start;
  const SearchScreen({super.key, this.start = FileOps.root});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final ctl = TextEditingController();
  final results = <FItem>[];
  Cat? filter;
  bool running = false;
  int _gen = 0;

  Future<void> _search() async {
    final q = ctl.text.trim().toLowerCase();
    final gen = ++_gen;
    setState(() { results.clear(); running = true; });
    if (q.isEmpty && filter == null) { setState(() => running = false); return; }
    await for (final f in FileOps.walk(widget.start, skipAndroid: true)) {
      if (gen != _gen || !mounted) return;
      final n = p.basename(f.path).toLowerCase();
      if ((q.isEmpty || n.contains(q)) && (filter == null || FileOps.catOf(f.path) == filter)) {
        try {
          final s = await f.stat();
          setState(() => results.add(FItem(f, false, s.size, s.modified)));
        } catch (_) {}
        if (results.length >= 500) break;
      }
    }
    if (gen == _gen && mounted) setState(() => running = false);
  }

  @override
  void dispose() {
    _gen++;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final chips = <(String, Cat?)>[('all', null), ('images', Cat.images), ('videos', Cat.videos), ('music', Cat.audio), ('docs', Cat.docs), ('apps', Cat.apps), ('archives', Cat.archives)];
    return Scaffold(
      appBar: AppBar(
        title: TextField(controller: ctl, autofocus: true, textInputAction: TextInputAction.search, onSubmitted: (_) => _search(), decoration: InputDecoration(hintText: L.t('search'), prefixIcon: const Icon(Icons.search_rounded))),
        actions: [
          IconButton(icon: const Icon(Icons.content_copy_rounded), tooltip: L.t('dupFinder'), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DuplicatesScreen(start: widget.start)))),
          IconButton(icon: const Icon(Icons.arrow_forward_rounded), onPressed: _search),
        ],
      ),
      body: Column(children: [
        SizedBox(
          height: 48,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
            for (final c in chips)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
                child: ChoiceChip(label: Text(L.t(c.$1 == 'all' ? 'files' : c.$1)), selected: filter == c.$2, onSelected: (_) { setState(() => filter = c.$2); _search(); }),
              ),
          ]),
        ),
        if (running) const LinearProgressIndicator(),
        Expanded(
          child: ListView.builder(
            itemCount: results.length,
            itemBuilder: (c, i) {
              final r = results[i];
              return ListTile(
                leading: TypeIcon(r.path, false),
                title: Text(r.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                isThreeLine: true,
                subtitle: Text('${FileOps.fmt(r.size)} • ${FileOps.dt(r.modified)}\n${p.dirname(r.path)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
                onLongPress: () => Navigator.push(context, MaterialPageRoute(builder: (_) => BrowserScreen(initialPath: p.dirname(r.path)))),
                onTap: () => Opener.open(context, r.path, siblings: results.map((e) => e.path).toList()),
              );
            },
          ),
        ),
      ]),
    );
  }
}
