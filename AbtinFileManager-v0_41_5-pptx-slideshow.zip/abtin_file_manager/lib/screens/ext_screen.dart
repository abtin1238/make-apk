import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../widgets/ui.dart';
import 'opener.dart';

/// Lists every file with one of [exts] on the device.
class ExtScreen extends StatefulWidget {
  final String title;
  final Set<String> exts;
  const ExtScreen({super.key, required this.title, required this.exts});
  @override
  State<ExtScreen> createState() => _ExtScreenState();
}

class _ExtScreenState extends State<ExtScreen> {
  final items = <FItem>[];
  bool done = false;
  String q = '';

  @override
  void initState() {
    super.initState();
    _scan();
  }

  Future<void> _scan() async {
    var n = 0;
    await for (final f in FileOps.walk(FileOps.root, skipAndroid: true)) {
      if (!mounted) return;
      if (!widget.exts.contains(FileOps.ext(f.path))) continue;
      try {
        final s = await f.stat();
        items.add(FItem(f, false, s.size, s.modified));
      } catch (_) {}
      if (++n % 20 == 0) setState(() {});
    }
    items.sort((a, b) => b.modified.compareTo(a.modified));
    if (mounted) setState(() => done = true);
  }

  @override
  Widget build(BuildContext context) {
    final list = items.where((e) => q.isEmpty || e.name.toLowerCase().contains(q)).toList();
    return Scaffold(
      appBar: AppBar(title: Text('${widget.title} (${items.length})')),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: TextField(onChanged: (v) => setState(() => q = v.toLowerCase()), decoration: InputDecoration(hintText: L.t('search'), prefixIcon: const Icon(Icons.search_rounded))),
        ),
        if (!done) const LinearProgressIndicator(),
        Expanded(
          child: ListView.builder(
            itemCount: list.length,
            itemBuilder: (c, i) => ListTile(
              leading: TypeIcon(list[i].path, false, size: 34),
              title: Text(list[i].name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text('${FileOps.fmt(list[i].size)} • ${list[i].modified.toString().split('.').first}', style: const TextStyle(fontSize: 11)),
              onTap: () => Opener.open(context, list[i].path, siblings: list.map((e) => e.path).toList()),
            ),
          ),
        ),
      ]),
    );
  }
}
