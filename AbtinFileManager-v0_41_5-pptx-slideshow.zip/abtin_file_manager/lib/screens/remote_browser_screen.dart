import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/remote/remote_factory.dart';
import '../services/remote/remote_fs.dart';
import '../widgets/ui.dart';

class RemoteBrowserScreen extends StatefulWidget {
  final RemoteProfile profile;
  const RemoteBrowserScreen({super.key, required this.profile});
  @override
  State<RemoteBrowserScreen> createState() => _RemoteBrowserScreenState();
}

class _RemoteBrowserScreenState extends State<RemoteBrowserScreen> {
  late final RemoteFs fs = createRemote(widget.profile);
  List<RemoteEntry>? entries;
  String cwd = '/';
  String? error;
  final sel = <String>{};
  final prog = ValueNotifier<(String, double?)?>(null);
  var _closed = false;

  @override
  void initState() {
    super.initState();
    _start();
  }

  @override
  void dispose() {
    _closed = true;
    fs.close();
    prog.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    try {
      await fs.connect();
      await _go(fs.home);
    } catch (e) {
      if (mounted) setState(() => error = '$e');
    }
  }

  Future<void> _go(String path) async {
    try {
      final l = await fs.list(path);
      l.sort((a, b) => a.dir != b.dir ? (a.dir ? -1 : 1) : a.name.toLowerCase().compareTo(b.name.toLowerCase()));
      if (!mounted) return;
      setState(() {
        entries = l;
        cwd = path;
        error = null;
        sel.clear();
      });
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _reload() => _go(cwd);

  void _progress(String name, int done, int total) {
    if (_closed) return;
    prog.value = (name, total > 0 ? (done / total).clamp(0.0, 1.0) : null);
  }

  Future<void> _run(Future<void> Function() job) async {
    try {
      await job();
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
    if (!_closed) prog.value = null;
  }

  Future<void> _downloadTree(String remote, bool dir, String localParent) async {
    final name = RPath.name(remote);
    final target = FileOps.unique(localParent, name);
    if (dir) {
      await Directory(target).create(recursive: true);
      for (final e in await fs.list(remote)) {
        await _downloadTree(RPath.join(remote, e.name), e.dir, target);
      }
    } else {
      await fs.download(remote, target, onProgress: (d, t) => _progress(name, d, t));
    }
  }

  Future<void> _uploadTree(String local, String remoteDir) async {
    final name = p.basename(local);
    final target = RPath.join(remoteDir, name);
    if (FileSystemEntity.isDirectorySync(local)) {
      try {
        await fs.mkdir(target);
      } catch (_) {}
      for (final e in Directory(local).listSync()) {
        await _uploadTree(e.path, target);
      }
    } else {
      await fs.upload(local, target, onProgress: (d, t) => _progress(name, d, t));
    }
  }

  Future<void> _download(List<RemoteEntry> items) async {
    await _run(() async {
      for (final e in items) {
        await _downloadTree(RPath.join(cwd, e.name), e.dir, FileOps.downloads);
      }
      if (mounted) snack(context, '${L.t('downloaded')}: ${FileOps.downloads}');
    });
    if (mounted) setState(sel.clear);
  }

  Future<void> _open(RemoteEntry e) async {
    final tmp = await getTemporaryDirectory();
    final dir = await Directory(p.join(tmp.path, 'remote_open')).create(recursive: true);
    final local = p.join(dir.path, e.name);
    await _run(() async {
      await fs.download(RPath.join(cwd, e.name), local, onProgress: (d, t) => _progress(e.name, d, t));
      await OpenFilex.open(local);
    });
  }

  Future<void> _upload() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true);
    final files = r?.paths.whereType<String>().toList() ?? [];
    if (files.isEmpty) return;
    await _run(() async {
      for (final f in files) {
        await _uploadTree(f, cwd);
      }
      await _reload();
      if (mounted) snack(context, L.t('uploaded'));
    });
  }

  Future<void> _uploadFolder() async {
    final d = await FilePicker.platform.getDirectoryPath();
    if (d == null) return;
    await _run(() async {
      await _uploadTree(d, cwd);
      await _reload();
      if (mounted) snack(context, L.t('uploaded'));
    });
  }

  Future<void> _mkdir() async {
    final n = await promptText(context, L.t('newFolder'));
    if (n == null || n.isEmpty || !mounted) return;
    await _run(() async {
      await fs.mkdir(RPath.join(cwd, n));
      await _reload();
    });
  }

  Future<void> _rename(RemoteEntry e) async {
    final n = await promptText(context, L.t('rename'), initial: e.name);
    if (n == null || n.isEmpty || n == e.name || !mounted) return;
    await _run(() async {
      await fs.rename(RPath.join(cwd, e.name), RPath.join(cwd, n));
      await _reload();
    });
  }

  Future<void> _delete(List<RemoteEntry> items) async {
    if (!await confirm(context, '${L.t('delete')}: ${items.length}')) return;
    await _run(() async {
      for (final e in items) {
        await fs.deleteTree(RPath.join(cwd, e.name), e.dir);
      }
      await _reload();
    });
  }

  String _fmt(int? b) {
    if (b == null) return '';
    const u = ['B', 'KB', 'MB', 'GB', 'TB'];
    var v = b.toDouble(), i = 0;
    while (v >= 1024 && i < u.length - 1) {
      v /= 1024;
      i++;
    }
    return '${v.toStringAsFixed(i == 0 ? 0 : 1)} ${u[i]}';
  }

  Widget _crumbs() {
    final segs = RPath.segs(cwd);
    return SizedBox(
      height: 38,
      child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
        TextButton(onPressed: () => _go('/'), child: const Text('/')),
        for (var i = 0; i < segs.length; i++)
          TextButton(onPressed: () => _go('/${segs.sublist(0, i + 1).join('/')}'), child: Text(segs[i])),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final items = entries;
    final chosen = [for (final e in items ?? <RemoteEntry>[]) if (sel.contains(e.name)) e];
    return PopScope(
      canPop: sel.isEmpty && (cwd == '/' || items == null),
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        if (sel.isNotEmpty) {
          setState(sel.clear);
        } else {
          _go(RPath.parent(cwd));
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(sel.isNotEmpty ? '${sel.length}' : (widget.profile.name.isEmpty ? widget.profile.host : widget.profile.name)),
          actions: sel.isNotEmpty
              ? [
                  IconButton(icon: const Icon(Icons.download_rounded), tooltip: L.t('dl'), onPressed: () => _download(chosen)),
                  IconButton(icon: const Icon(Icons.delete_rounded), tooltip: L.t('delete'), onPressed: () => _delete(chosen)),
                ]
              : [
                  if (items != null) ...[
                    IconButton(icon: const Icon(Icons.create_new_folder_rounded), tooltip: L.t('newFolder'), onPressed: _mkdir),
                    PopupMenuButton<String>(
                      icon: const Icon(Icons.upload_rounded),
                      onSelected: (v) => v == 'f' ? _upload() : _uploadFolder(),
                      itemBuilder: (_) => [
                        PopupMenuItem(value: 'f', child: Text(L.t('upload'))),
                        PopupMenuItem(value: 'd', child: Text(L.t('uploadFolder'))),
                      ],
                    ),
                    IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: _reload),
                  ],
                ],
        ),
        body: Column(children: [
          if (items != null) _crumbs(),
          ValueListenableBuilder<(String, double?)?>(
            valueListenable: prog,
            builder: (_, v, __) => v == null
                ? const SizedBox.shrink()
                : Padding(
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(v.$1, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                      LinearProgressIndicator(value: v.$2),
                    ]),
                  ),
          ),
          Expanded(
            child: error != null
                ? Center(child: Padding(padding: const EdgeInsets.all(20), child: SelectableText('${L.t('error')}: $error')))
                : items == null
                    ? const Center(child: CircularProgressIndicator())
                    : items.isEmpty
                        ? Center(child: Text(L.t('empty')))
                        : ListView.builder(
                            itemCount: items.length,
                            itemBuilder: (_, i) {
                              final e = items[i];
                              final on = sel.contains(e.name);
                              return ListTile(
                                selected: on,
                                leading: on
                                    ? const Icon(Icons.check_circle_rounded)
                                    : TypeIcon(e.name, e.dir),
                                title: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                                subtitle: Text([if (!e.dir) _fmt(e.size), if (e.modified != null) e.modified!.toString().split('.').first].where((s) => s.isNotEmpty).join(' • ')),
                                onLongPress: () => setState(() => on ? sel.remove(e.name) : sel.add(e.name)),
                                trailing: sel.isEmpty
                                    ? PopupMenuButton<String>(
                                        onSelected: (v) {
                                          if (v == 'dl') _download([e]);
                                          if (v == 'rn') _rename(e);
                                          if (v == 'rm') _delete([e]);
                                        },
                                        itemBuilder: (_) => [
                                          PopupMenuItem(value: 'dl', child: Text(L.t('dl'))),
                                          PopupMenuItem(value: 'rn', child: Text(L.t('rename'))),
                                          PopupMenuItem(value: 'rm', child: Text(L.t('delete'))),
                                        ],
                                      )
                                    : null,
                                onTap: () {
                                  if (sel.isNotEmpty) {
                                    setState(() => on ? sel.remove(e.name) : sel.add(e.name));
                                  } else if (e.dir) {
                                    _go(RPath.join(cwd, e.name));
                                  } else {
                                    _open(e);
                                  }
                                },
                              );
                            },
                          ),
          ),
        ]),
      ),
    );
  }
}
