import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:pdfx/pdfx.dart';
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../services/pdf_native.dart';
import '../widgets/ui.dart';

class _Ch {
  final int word;
  final String ch;
  final Rect r; // normalised
  int line = 0;
  _Ch(this.word, this.ch, this.r);
}

final _ltrChar = RegExp(r'[\p{L}\p{N}]', unicode: true);

/// 1 = right-to-left letter, 2 = left-to-right letter / digit (also Arabic-Indic digits), 0 = neutral.
int _cls(String u) {
  for (final r in u.runes) {
    if ((r >= 0x0590 && r <= 0x08FF) || (r >= 0xFB1D && r <= 0xFDFF) || (r >= 0xFE70 && r <= 0xFEFF)) {
      if ((r >= 0x0660 && r <= 0x0669) || (r >= 0x06F0 && r <= 0x06F9)) return 2;
      return 1;
    }
    if (_ltrChar.hasMatch(String.fromCharCode(r))) return 2;
  }
  return 0;
}

/// Reverses every maximal run of class [target] (neutrals between two such characters belong to the run).
List<String> _reverseRuns(List<String> v, int target) {
  final cls = [for (final u in v) _cls(u)];
  final out = <String>[];
  var i = 0;
  while (i < v.length) {
    if (cls[i] != target) {
      out.add(v[i]);
      i++;
      continue;
    }
    var j = i;
    while (true) {
      var k = j + 1;
      while (k < v.length && cls[k] == 0) {
        k++;
      }
      if (k < v.length && cls[k] == target) {
        j = k;
      } else {
        break;
      }
    }
    out.addAll(v.sublist(i, j + 1).reversed);
    i = j + 1;
  }
  return out;
}

/// Characters of one line in visual (left-to-right) order -> text in logical reading order.
String _logical(List<String> vis) {
  var rtl = 0, ltr = 0;
  for (final u in vis) {
    final c = _cls(u);
    if (c == 1) rtl++;
    if (c == 2) ltr++;
  }
  if (rtl == 0) return vis.join();
  if (rtl >= ltr) return _reverseRuns(vis.reversed.toList(), 2).join(); // RTL line: reverse, keep numbers / Latin runs readable
  return _reverseRuns(vis, 1).join(); // LTR line with embedded RTL words
}

/// One page with its real text. Long-press a character and drag to select (character level), tap a word to select
/// it, pinch to zoom. The selection can be copied or turned into a real PDF highlight / underline / strike-out annotation.
class PdfSelectScreen extends StatefulWidget {
  final String path;
  final int page;
  /// set when [path] is a decrypted temp copy: annotated copies are named after / saved next to this file
  final String? origPath;
  const PdfSelectScreen({super.key, required this.path, required this.page, this.origPath});
  @override
  State<PdfSelectScreen> createState() => _PdfSelectScreenState();
}

class _PdfSelectScreenState extends State<PdfSelectScreen> {
  Uint8List? png;
  double ratio = 1;
  List<Map<String, dynamic>> boxes = [];
  final chars = <_Ch>[];
  int anchor = -1, cur = -1;
  bool loading = true;
  String? outPath; // annotated copy (created on first annotation, then updated in place)

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _render(String path) async {
    final d = await PdfDocument.openFile(path);
    final pg = await d.getPage(widget.page);
    final scale = (1400 / pg.width).clamp(1.0, 2.5).toDouble();
    final r = await pg.render(width: pg.width * scale, height: pg.height * scale, format: PdfPageImageFormat.png, backgroundColor: '#FFFFFF');
    ratio = pg.height / pg.width;
    await pg.close();
    await d.close();
    png = r?.bytes;
  }

  Future<void> _load() async {
    try {
      await _render(widget.path);
      final b = await PdfNative.boxes(widget.path, widget.page);
      for (var wi = 0; wi < b.length; wi++) {
        final w = b[wi];
        final cs = (w['c'] as List?)?.map((e) => '$e').toList() ?? <String>[];
        final a = (w['a'] as List?)?.map((e) => (e as num).toDouble()).toList() ?? <double>[];
        final e = (w['b'] as List?)?.map((e) => (e as num).toDouble()).toList() ?? <double>[];
        final y = (w['y'] as num).toDouble(), h = (w['h'] as num).toDouble();
        if (cs.isEmpty || cs.length != a.length || a.length != e.length) {
          // no per-character data: treat the whole word as one unit
          chars.add(_Ch(wi, '${w['text']}', Rect.fromLTWH((w['x'] as num).toDouble(), y, (w['w'] as num).toDouble(), h)));
          continue;
        }
        for (var i = 0; i < cs.length; i++) {
          chars.add(_Ch(wi, cs[i], Rect.fromLTRB(a[i], y, e[i] < a[i] ? a[i] : e[i], y + h)));
        }
      }
      _layout();
      if (mounted) setState(() { boxes = b; loading = false; });
    } catch (e) {
      if (mounted) {
        snack(context, '${L.t('error')}: $e');
        Navigator.pop(context);
      }
    }
  }

  /// Reading layout: characters grouped into lines (top to bottom), each line ordered visually left to right.
  void _layout() {
    final idx = List<int>.generate(chars.length, (i) => i)..sort((a, b) => chars[a].r.center.dy.compareTo(chars[b].r.center.dy));
    final lines = <List<_Ch>>[];
    var cy = 0.0, hh = 0.0;
    for (final i in idx) {
      final c = chars[i];
      if (lines.isEmpty || (c.r.center.dy - cy).abs() > 0.5 * (hh < 0.004 ? 0.004 : hh)) {
        lines.add([c]);
        cy = c.r.center.dy;
        hh = c.r.height;
      } else {
        lines.last.add(c);
      }
    }
    final out = <_Ch>[];
    for (var li = 0; li < lines.length; li++) {
      lines[li].sort((a, b) => a.r.left.compareTo(b.r.left));
      for (final c in lines[li]) {
        c.line = li;
        out.add(c);
      }
    }
    chars
      ..clear()
      ..addAll(out);
  }

  int _hit(Offset n) {
    var best = -1;
    var bd = double.infinity;
    for (var i = 0; i < chars.length; i++) {
      final r = chars[i].r.inflate(0.002);
      if (r.contains(n)) return i;
      final d = (r.center - n).distanceSquared;
      if (d < bd) { bd = d; best = i; }
    }
    return bd < 0.0025 ? best : -1; // within ~5 % of the page
  }

  bool get _has => anchor >= 0 && cur >= 0;
  int get _lo => anchor < cur ? anchor : cur;
  int get _hi => anchor < cur ? cur : anchor;

  /// Selected characters as per-line rectangles (normalised).
  List<Rect> _selRects() {
    final out = <Rect>[];
    if (!_has) return out;
    Rect? run;
    int? runWord;
    for (var i = _lo; i <= _hi; i++) {
      final c = chars[i];
      if (run != null && runWord == c.word) {
        run = run.expandToInclude(c.r);
      } else if (run != null && (run.center.dy - c.r.center.dy).abs() < c.r.height * 0.4) {
        run = run.expandToInclude(c.r); // same line, next word
        runWord = c.word;
      } else {
        if (run != null) out.add(run);
        run = c.r;
        runWord = c.word;
      }
    }
    if (run != null) out.add(run);
    return out;
  }

  String _text(int lo, int hi) {
    final lines = <String>[];
    var i = lo;
    while (i <= hi) {
      final ln = chars[i].line;
      final vis = <String>[];
      int? prevWord;
      while (i <= hi && chars[i].line == ln) {
        if (prevWord != null && chars[i].word != prevWord) vis.add(' ');
        vis.add(chars[i].ch);
        prevWord = chars[i].word;
        i++;
      }
      lines.add(_logical(vis));
    }
    return lines.join('\n');
  }

  void _copy() {
    if (chars.isEmpty) return;
    Clipboard.setData(ClipboardData(text: _has ? _text(_lo, _hi) : _text(0, chars.length - 1)));
    snack(context, L.t('copied'));
  }

  void _selectWord(int i) {
    final w = chars[i].word;
    var a = i, b = i;
    while (a > 0 && chars[a - 1].word == w) a--;
    while (b < chars.length - 1 && chars[b + 1].word == w) b++;
    setState(() { anchor = a; cur = b; });
  }

  Future<void> _annotate(String kind) async {
    final rects = _selRects();
    if (rects.isEmpty) return;
    final col = kind == 'highlight' ? const [255, 235, 59] : const [229, 57, 53];
    if (!await ensureSdAll(context, [widget.origPath ?? widget.path])) return;
    if (!mounted) return;
    final ok = await busy(context, () async {
      final named = widget.origPath ?? widget.path;
      final src = outPath ?? widget.path;
      final first = outPath == null;
      final dir = p.dirname(named);
      final viaSaf = !first && await Saf.use(src);
      final dst = first ? FileOps.unique(dir, '${p.basenameWithoutExtension(named)} (annotated).pdf') : viaSaf ? src : p.join(dir, '.${p.basename(src)}.abtin.tmp');
      await PdfNative.markup(src, dst, widget.page, kind, [for (final r in rects) [r.left, r.top, r.width, r.height]], col[0], col[1], col[2]);
      if (first) {
        outPath = dst;
      } else if (!viaSaf) {
        await File(dst).rename(src);
      }
      await _render(outPath!);
    });
    if (!ok || !mounted) return;
    Native.scan(outPath!);
    setState(() { anchor = -1; cur = -1; });
    snack(context, '${L.t('done')}: ${p.basename(outPath!)}');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final sel = _has;
    return Scaffold(
      appBar: AppBar(
        title: Text('${L.t('selectText')} • ${L.t('page')} ${widget.page}', style: const TextStyle(fontSize: 15)),
        actions: [
          IconButton(
            icon: const Icon(Icons.select_all_rounded),
            tooltip: L.t('selectAll'),
            onPressed: chars.isEmpty ? null : () => setState(() { anchor = 0; cur = chars.length - 1; }),
          ),
          IconButton(icon: const Icon(Icons.copy_rounded), tooltip: L.t('copy'), onPressed: chars.isEmpty ? null : _copy),
          PopupMenuButton<String>(
            tooltip: L.t('annotate'),
            icon: const Icon(Icons.highlight_rounded),
            enabled: sel,
            onSelected: _annotate,
            itemBuilder: (_) => [
              PopupMenuItem(value: 'highlight', child: Text(L.t('annHighlight'))),
              PopupMenuItem(value: 'underline', child: Text(L.t('annUnderline'))),
              PopupMenuItem(value: 'strike', child: Text(L.t('annStrike'))),
            ],
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : chars.isEmpty
              ? Center(child: Text(L.t('noTextOnPage')))
              : LayoutBuilder(builder: (c, cons) {
                  final w = cons.maxWidth, h = w * ratio;
                  Offset norm(Offset o) => Offset(o.dx / w, o.dy / h);
                  final rects = _selRects();
                  return InteractiveViewer(
                    maxScale: 6,
                    child: Center(
                      child: SizedBox(
                        width: w,
                        height: h,
                        child: GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTapUp: (d) {
                            final i = _hit(norm(d.localPosition));
                            if (i < 0) { setState(() { anchor = -1; cur = -1; }); } else { _selectWord(i); }
                          },
                          onLongPressStart: (d) {
                            final i = _hit(norm(d.localPosition));
                            if (i >= 0) { HapticFeedback.selectionClick(); setState(() { anchor = i; cur = i; }); }
                          },
                          onLongPressMoveUpdate: (d) {
                            final i = _hit(norm(d.localPosition));
                            if (i >= 0 && anchor >= 0 && i != cur) setState(() => cur = i);
                          },
                          child: Stack(children: [
                            Image.memory(png!, width: w, height: h, fit: BoxFit.fill),
                            for (final r in rects)
                              Positioned(
                                left: r.left * w,
                                top: r.top * h,
                                width: r.width * w,
                                height: r.height * h,
                                child: IgnorePointer(child: Container(color: cs.primary.withOpacity(.35))),
                              ),
                          ]),
                        ),
                      ),
                    ),
                  );
                }),
      bottomNavigationBar: chars.isEmpty
          ? null
          : Padding(
              padding: const EdgeInsets.all(10),
              child: Text(sel ? '${_hi - _lo + 1} ${L.t('charsSelected')}' : L.t('selectHintChars'), textAlign: TextAlign.center)),
    );
  }
}
