import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../widgets/adaptive_nav.dart';
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/layout_scope.dart';
import '../core/layouts.dart';
import '../core/looks.dart';
import '../core/settings.dart';
import '../core/theme.dart';
import 'analyzer_screen.dart';
import 'duplicates_screen.dart';
import 'button_style_screen.dart';
import 'icon_style_screen.dart';
import 'layout_style_screen.dart';
import 'path_list_screen.dart';
import 'trash_screen.dart';
import 'saf_prompt.dart';
import 'security_screen.dart';
import '../core/font_prefs.dart';
import '../widgets/ui.dart';
import 'browser_screen.dart';
import 'transfer_screen.dart';
import '../services/file_ops.dart';
import '../services/saf.dart';

Future<void> _pickFont(BuildContext context, AppSettings s) {
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(tr2('فونت برنامه', 'App font')),
      content: SizedBox(
        width: double.maxFinite,
        child: ListView(shrinkWrap: true, children: [
          for (final f in appFonts)
            ListTile(
              selected: f.id == s.fontId,
              title: Text(f.name),
              subtitle: Text('آبتین فایل منیجر ۱۲۳  Abtin 123', style: TextStyle(fontFamily: f.id == 'auto' ? (L.lang == 'fa' ? 'Vazir' : null) : f.family, fontSize: 18)),
              trailing: f.id == s.fontId ? const Icon(Icons.check_circle_rounded) : null,
              onTap: () {
                s.setFont(f.id);
                Navigator.pop(ctx);
              },
            ),
        ]),
      ),
      actions: [CancelButton(onPressed: () => Navigator.pop(ctx))],
    ),
  );
}

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return Scaffold(
      appBar: AppBar(leading: menuLeading(context), title: Text(L.t('settings'))),
      body: MaxWidth(child: ListView(children: [
        if (s.look == 'glass' || s.look == 'neon') ...[
          // these looks have no Files / Network tab in their bar: reach them from here
          ListTile(leading: const Icon(Icons.folder_rounded), title: Text(L.t('files')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BrowserScreen(initialPath: FileOps.root, root: true)))),
          ListTile(leading: const Icon(Icons.swap_horiz_rounded), title: Text(L.t('network')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TransferScreen()))),
          const Divider(),
        ],
        SwitchListTile(secondary: const Icon(Icons.dark_mode_rounded), title: Text(L.t('dark')), value: s.dark, onChanged: s.setDark),
        ListTile(
          leading: const Icon(Icons.auto_awesome_rounded),
          title: Text(tr2('تم برنامه', 'App theme')),
          subtitle: Text(lookById(s.look).name),
          onTap: () => _pickLook(context, s),
        ),
        ListTile(
          leading: const Icon(Icons.font_download_rounded),
          title: Text(tr2('فونت برنامه', 'App font')),
          subtitle: Text(fontById(s.fontId).name),
          onTap: () => _pickFont(context, s),
        ),
        ListTile(
          leading: const Icon(Icons.dashboard_customize_rounded),
          title: Text(tr2('چیدمان و ساختار برنامه', 'App layout')),
          subtitle: Text('${layoutById(s.layoutId).name} — ${layoutById(s.layoutId).desc}', maxLines: 2, overflow: TextOverflow.ellipsis),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LayoutStyleScreen())),
        ),
        ListTile(
          leading: const Icon(Icons.smart_button_rounded),
          title: Text(L.t('buttonStyle')),
          subtitle: Text(L.t('buttonStyleSub')),
          trailing: Container(width: 22, height: 22, decoration: BoxDecoration(shape: BoxShape.circle, color: s.btnColor != 0 ? Color(s.btnColor) : Theme.of(context).colorScheme.primary)),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ButtonStyleScreen())),
        ),
        ListTile(
          leading: const Icon(Icons.language_rounded),
          title: Text(L.t('language')),
          trailing: DropdownButton<String>(
            value: L.lang,
            underline: const SizedBox(),
            items: [for (final c in L.langs) DropdownMenuItem(value: c, child: Text(L.nameOf(c)))],
            onChanged: (v) => s.setLang(v!),
          ),
        ),
        SwitchListTile(secondary: const Icon(Icons.splitscreen_rounded), title: Text(L.t('dual')), subtitle: Text(L.t('dualSub')), value: s.dual, onChanged: s.setDual),
        ListTile(leading: const Icon(Icons.palette_rounded), title: Text(L.t('iconStyle')), subtitle: Text(L.t('iconStyleSub')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const IconStyleScreen()))),
        SwitchListTile(secondary: const Icon(Icons.visibility_rounded), title: Text(L.t('hidden')), value: s.showHidden, onChanged: s.setHidden),
        SwitchListTile(secondary: const Icon(Icons.warning_amber_rounded), title: Text(L.t('confirmDelete')), value: s.confirmDelete, onChanged: s.setConfirm),
        SwitchListTile(secondary: const Icon(Icons.sync_rounded), title: Text(L.t('bgCopy')), subtitle: Text(L.t('bgCopySub')), value: s.bgCopy, onChanged: s.setBgCopy),
        SwitchListTile(secondary: const Icon(Icons.folder_special_rounded), title: Text(L.t('folderSizes')), subtitle: Text(L.t('folderSizesSub')), value: s.folderSizes, onChanged: s.setFolderSizes),
        SwitchListTile(secondary: const Icon(Icons.delete_outline_rounded), title: Text(L.t('trash')), subtitle: Text(L.t('trashSub')), value: s.trashEnabled, onChanged: s.setTrash),
        ListTile(leading: const Icon(Icons.restore_from_trash_rounded), title: Text(L.t('trash')), subtitle: Text(L.t('trashOpen')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TrashScreen()))),
        ListTile(leading: const Icon(Icons.shield_rounded), title: Text(L.t('security')), subtitle: Text(L.t('securitySub')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SecurityScreen()))),
        for (final r in FileOps.roots().where((r) => r.sd)) _SdTile(root: r),
        const Divider(),
        ListTile(leading: const Icon(Icons.pie_chart_rounded), title: Text(L.t('analyzer')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AnalyzerScreen()))),
        ListTile(leading: const Icon(Icons.content_copy_rounded), title: Text(L.t('dupFinder')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DuplicatesScreen()))),
        ListTile(leading: const Icon(Icons.star_rounded), title: Text(L.t('favorites')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PathListScreen(title: L.t('favorites'), fav: true)))),
        ListTile(leading: const Icon(Icons.history_rounded), title: Text(L.t('recents')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PathListScreen(title: L.t('recents'), fav: false)))),
        const Divider(),
        ListTile(leading: const Icon(Icons.info_outline_rounded), title: Text(L.t('about')), subtitle: const Text('Abtin File Manager 0.40.0')),
      ])),
    );
  }
}

void _pickLook(BuildContext context, AppSettings s) {
  showModalBottomSheet<void>(
    context: context,
    builder: (ctx) => SafeArea(
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        for (final l in appLooks)
          ListTile(
            leading: Icon(l.icon),
            title: Text(l.name),
            subtitle: Text(l.desc),
            trailing: l.id == s.look ? const Icon(Icons.check_rounded) : null,
            onTap: () { s.setLook(l.id); Navigator.pop(ctx); },
          ),
      ]),
    ),
  );
}

class _SdTile extends StatefulWidget {
  final StorageRoot root;
  const _SdTile({required this.root});
  @override
  State<_SdTile> createState() => _SdTileState();
}

class _SdTileState extends State<_SdTile> {
  Future<int> _state() async {
    // 0 = not needed, 1 = granted, 2 = needs access
    if (!await Saf.needsSaf(widget.root.path)) return 0;
    return await Saf.has(Saf.volumeOf(widget.root.path)!) ? 1 : 2;
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<int>(
        future: _state(),
        builder: (c, snap) => ListTile(
          leading: const Icon(Icons.sd_card_rounded),
          title: Text('${L.t('sdAccess')} (${widget.root.name})'),
          subtitle: Text(snap.data == 1 ? L.t('sdGranted') : snap.data == 2 ? L.t('sdNotGranted') : L.t('sdDirect')),
          onTap: snap.data == 0 || snap.data == null
              ? null
              : () async {
                  await manageSdAccess(context, widget.root.path);
                  if (mounted) setState(() {});
                },
        ),
      );
}
