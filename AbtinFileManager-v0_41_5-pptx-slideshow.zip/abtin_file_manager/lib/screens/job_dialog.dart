import 'dart:io';
import 'package:flutter/material.dart';
import '../core/l10n.dart';
import '../services/copy_job.dart';
import '../services/file_ops.dart';
import '../widgets/ui.dart';

/// Copies / moves [items] into [dest] showing progress, a cancel button and a
/// replace / skip / rename dialog on name clashes. Returns the finished job.
Future<CopyJob> runCopyJob(BuildContext context, List<FileSystemEntity> items, String dest, {required bool move}) async {
  final job = CopyJob(move: move);
  showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => PopScope(canPop: false, child: _ProgressDialog(job)),
  );
  await job.run(
    items,
    dest,
    (c) => showDialog<ConflictAnswer>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _ConflictDialog(c),
    ),
  );
  if (context.mounted) Navigator.of(context, rootNavigator: true).pop();
  return job;
}

String jobResultText(CopyJob j) {
  if (j.cancelled) return L.t('cancelled');
  if (j.errors.isNotEmpty) return '${L.t('doneErrors')} (${j.errors.length}): ${j.errors.first}';
  return L.t('done');
}

String _dur(int s) {
  final m = s ~/ 60, r = s % 60;
  return '${m.toString().padLeft(2, '0')}:${r.toString().padLeft(2, '0')}';
}

class _ProgressDialog extends StatelessWidget {
  final CopyJob job;
  const _ProgressDialog(this.job);

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: job,
      builder: (_, __) {
        final f = job.fraction;
        final sp = job.speed;
        final eta = sp > 0 ? ((job.totalBytes - job.doneBytes) / sp).round().clamp(0, 359999) : -1;
        return AlertDialog(
          title: Text(job.move ? L.t('moving') : L.t('copying')),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(job.counting ? L.t('preparing') : job.current, maxLines: 1, overflow: TextOverflow.ellipsis),
              const SizedBox(height: 12),
              LinearProgressIndicator(value: f, minHeight: 8, borderRadius: BorderRadius.circular(6)),
              const SizedBox(height: 10),
              Directionality(
                textDirection: TextDirection.ltr,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${f == null ? '' : '${(f * 100).floor()}%  •  '}${FileOps.fmt(job.doneBytes)} / ${FileOps.fmt(job.totalBytes)}', style: const TextStyle(fontSize: 13)),
                  Text('${job.doneFiles} / ${job.totalFiles} ${L.t('files')}', style: const TextStyle(fontSize: 12)),
                  if (sp > 0) Text('${FileOps.fmt(sp)}/s${eta >= 0 ? '  •  ${_dur(eta)} ${L.t('remaining')}' : ''}', style: const TextStyle(fontSize: 12)),
                ]),
              ),
            ],
          ),
          actions: [
            CancelButton(onPressed: job.cancelled ? null : job.cancel),
          ],
        );
      },
    );
  }
}

class _ConflictDialog extends StatefulWidget {
  final Conflict c;
  const _ConflictDialog(this.c);
  @override
  State<_ConflictDialog> createState() => _ConflictDialogState();
}

class _ConflictDialogState extends State<_ConflictDialog> {
  bool all = false;

  Widget _info(String label, bool dir, int size, DateTime t) => Padding(
        padding: const EdgeInsets.only(top: 4),
        child: Text('$label: ${dir ? '' : '${FileOps.fmt(size)} • '}${t.toString().split('.').first}', style: const TextStyle(fontSize: 12.5)),
      );

  @override
  Widget build(BuildContext context) {
    final c = widget.c;
    return AlertDialog(
      title: Text(L.t('conflictTitle')),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(c.name, style: const TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text(L.t('conflictMsg')),
          const SizedBox(height: 8),
          _info(L.t('existing'), c.dstIsDir, c.dstSize, c.dstTime),
          _info(L.t('newItem'), c.srcIsDir, c.srcSize, c.srcTime),
          const SizedBox(height: 4),
          CheckboxListTile(
            value: all,
            dense: true,
            contentPadding: EdgeInsets.zero,
            controlAffinity: ListTileControlAffinity.leading,
            title: Text(L.t('applyAll')),
            onChanged: (v) => setState(() => all = v ?? false),
          ),
        ],
      ),
      actionsOverflowDirection: VerticalDirection.down,
      actions: [
        CancelButton(onPressed: () => Navigator.pop(context)),
        TextButton(onPressed: () => Navigator.pop(context, ConflictAnswer(Resolution.skip, all)), child: Text(L.t('skip'))),
        TextButton(onPressed: () => Navigator.pop(context, ConflictAnswer(Resolution.rename, all)), child: Text(L.t('rename'))),
        FilledButton(onPressed: () => Navigator.pop(context, ConflictAnswer(Resolution.replace, all)), child: Text(L.t('replace'))),
      ],
    );
  }
}
