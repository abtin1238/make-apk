import '../widgets/ui.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../services/player_service.dart';

/// Gapless playback, crossfade and ReplayGain.
class AudioOptionsScreen extends StatelessWidget {
  const AudioOptionsScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final pl = context.watch<PlayerService>();
    return Scaffold(
      appBar: AppBar(title: Text(L.t('playOpts'))),
      body: ListView(padding: const EdgeInsets.all(8), children: [
        SwitchListTile(
          title: Text(L.t('gapless')),
          subtitle: Text(L.t('gaplessSub')),
          value: pl.gapless,
          onChanged: (v) { pl.gapless = v; pl.applyAudioOpts(); },
        ),
        const Divider(),
        ListTile(
          title: Text(L.t('crossfade')),
          subtitle: Text(pl.crossfade <= 0 ? L.t('off') : '${pl.crossfade.round()} ${L.t('secShort')} — ${L.t('crossfadeSub')}'),
        ),
        LSlider(
          min: 0,
          max: 12,
          divisions: 12,
          label: pl.crossfade <= 0 ? L.t('off') : '${pl.crossfade.round()}',
          value: pl.crossfade,
          onChanged: (v) { pl.crossfade = v; pl.touch(); },
          onChangeEnd: (_) => pl.applyAudioOpts(),
        ),
        const Divider(),
        ListTile(title: Text(L.t('replayGain')), subtitle: Text(L.t('rgHint'))),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: SegmentedButton<String>(
            segments: [
              ButtonSegment(value: 'no', label: Text(L.t('off'))),
              ButtonSegment(value: 'track', label: Text(L.t('rgTrack'))),
              ButtonSegment(value: 'album', label: Text(L.t('rgAlbum'))),
            ],
            selected: {pl.rgMode},
            onSelectionChanged: (s) { pl.rgMode = s.first; pl.applyAudioOpts(); },
          ),
        ),
        ListTile(title: Text('${L.t('rgPreamp')}: ${pl.rgPreamp.toStringAsFixed(1)} dB')),
        LSlider(
          min: -15,
          max: 15,
          divisions: 60,
          value: pl.rgPreamp,
          onChanged: pl.rgMode == 'no' ? null : (v) { pl.rgPreamp = v; pl.touch(); },
          onChangeEnd: (_) => pl.applyAudioOpts(),
        ),
        SwitchListTile(
          title: Text(L.t('rgClip')),
          value: pl.rgClip,
          onChanged: pl.rgMode == 'no' ? null : (v) { pl.rgClip = v; pl.applyAudioOpts(); },
        ),
      ]),
    );
  }
}
