import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:path/path.dart' as pth;
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../services/file_ops.dart';
import '../services/media_events.dart';
import '../services/thumbs.dart';
import '../services/trash_service.dart';
import '../widgets/file_thumb.dart';
import '../widgets/ui.dart';
import 'opener.dart';
import 'saf_prompt.dart';

/// Gallery for photos and videos: date sections, thumbnail / list modes, pinch to resize,
/// multi-select and permanent delete (previews are dropped from memory right away).
class GalleryScreen extends StatefulWidget {
  final String title;
  final List<FItem> items;
  final void Function(Set<String> deleted)? onDeleted;
  const GalleryScreen({super.key, required this.title, required this.items, this.onDeleted});
  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  late List<FItem> items = [...widget.items]..sort((a, b) => b.modified.compareTo(a.modified));
  final sel = <String>{};
  final _pts = <int, Offset>{};
  double? _baseDist, _baseExtent;
  double extent = 110;
  bool listMode = false;
  SharedPreferences? _sp;
  StreamSubscription<Set<String>>? _delSub;
  StreamSubscription<String>? _resSub;

  @override
  void initState() {
    super.initState();
    // A photo deleted in the viewer disappears from the grid at once (the viewer is still on top).
    _delSub = MediaEvents.onDeleted.listen((ps) {
      final gone = items.where((e) => ps.contains(e.path)).map((e) => e.path).toSet();
      if (gone.isNotEmpty && mounted) _dropped(gone);
    });
    // "Undo" in the trash snackbar brings it back.
    _resSub = MediaEvents.onRestored.listen(_restored);
    SharedPreferences.getInstance().then((p) {
      _sp = p;
      if (!mounted) return;
      setState(() {
        listMode = p.getBool('galList') ?? false;
        extent = (p.getDouble('galExtent') ?? 110).clamp(60.0, 320.0);
      });
    });
  }

  @override
  void dispose() {
    _delSub?.cancel();
    _resSub?.cancel();
    super.dispose();
  }

  void _restored(String path) {
    if (!mounted || items.any((e) => e.path == path)) return;
    try {
      final f = File(path);
      if (!f.existsSync()) return;
      // belongs here when this gallery shows several folders, or the folder of one of its items
      final dirs = items.map((e) => pth.dirname(e.path)).toSet();
      if (dirs.length > 1 || dirs.contains(pth.dirname(path)) || items.isEmpty) {
        final st = f.statSync();
        setState(() {
          items.add(FItem(f, false, st.size, st.modified));
          items.sort((a, b) => b.modified.compareTo(a.modified));
        });
      }
    } catch (_) {}
  }

  bool get selecting => sel.isNotEmpty;
  bool get _pinching => _pts.length >= 2;

  // ---- pinch to resize (Listener does not compete with scrolling)
  void _down(PointerDownEvent e) => setState(() => _pts[e.pointer] = e.position);
  void _move(PointerMoveEvent e) {
    if (!_pts.containsKey(e.pointer)) return;
    _pts[e.pointer] = e.position;
    if (_pts.length == 2) {
      final v = _pts.values.toList();
      final d = (v[0] - v[1]).distance;
      if (_baseDist == null) {
        _baseDist = d;
        _baseExtent = extent;
      } else if (_baseDist! > 8) {
        setState(() => extent = (_baseExtent! * d / _baseDist!).clamp(60.0, 320.0));
      }
    }
  }

  void _up(PointerEvent e) {
    final was = _pinching;
    setState(() => _pts.remove(e.pointer));
    if (_pts.length < 2) {
      _baseDist = null;
      if (was) _sp?.setDouble('galExtent', extent);
    }
  }

  void _toggleMode() {
    setState(() => listMode = !listMode);
    _sp?.setBool('galList', listMode);
  }

  void _toggle(String path) => setState(() => sel.contains(path) ? sel.remove(path) : sel.add(path));

  void _open(FItem it) async {
    if (selecting) {
      _toggle(it.path);
      return;
    }
    await Opener.open(context, it.path, siblings: items.map((e) => e.path).toList());
    if (!mounted) return;
    final gone = items.where((e) => !File(e.path).existsSync()).map((e) => e.path).toSet();
    if (gone.isNotEmpty) _dropped(gone);
  }

  void _dropped(Set<String> gone) {
    for (final g in gone) {
      Thumbs.evict(g);
    }
    setState(() {
      items.removeWhere((e) => gone.contains(e.path));
      sel.removeAll(gone);
    });
    widget.onDeleted?.call(gone);
  }

  Future<void> _delete() async {
    final paths = sel.toList();
    if (paths.isEmpty) return;
    if (!await ensureSdAll(context, paths)) return;
    if (!mounted) return;
    final st = context.read<AppSettings>();
    final useTrash = st.trashEnabled;
    if (st.confirmDelete) {
      final msg = useTrash ? '${L.t('moveToTrash')} (${paths.length})?' : '${L.t('deletePermanent')} (${paths.length})?';
      if (!await confirm(context, msg)) return;
    }
    if (!mounted) return;
    final done = <String>{};
    final failed = <String>[];
    await busy(context, () async {
      for (final pa in paths) {
        try {
          if (useTrash && !TrashService.isInTrash(pa)) {
            try {
              await TrashService.moveToTrash(File(pa));
            } on OpError catch (x) {
              if (x.key == 'trashFail') {
                failed.add(pa);
                continue;
              }
              rethrow;
            }
          } else {
            await FileOps.delete(File(pa));
          }
          st.removePath(pa);
          done.add(pa);
        } catch (_) {}
      }
    });
    if (failed.isNotEmpty && mounted && await confirm(context, L.t('trashFailAsk'))) {
      await busy(context, () async {
        for (final pa in failed) {
          try {
            await FileOps.delete(File(pa));
            st.removePath(pa);
            done.add(pa);
          } catch (_) {}
        }
      });
    }
    if (mounted) _dropped(done);
  }

  // ---- date sections
  String _day(DateTime d) => FileOps.dt(d).substring(0, 10);

  List<MapEntry<String, List<FItem>>> get _groups {
    final m = <String, List<FItem>>{};
    for (final i in items) {
      (m[_day(i.modified)] ??= []).add(i);
    }
    return m.entries.toList();
  }

  Widget _header(String day, List<FItem> g) {
    final all = g.every((e) => sel.contains(e.path));
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 8, 4),
      child: Row(children: [
        Expanded(child: Text('$day  (${g.length})', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))),
        if (selecting)
          IconButton(
            visualDensity: VisualDensity.compact,
            icon: Icon(all ? Icons.check_circle_rounded : Icons.circle_outlined, size: 22),
            onPressed: () => setState(() => all ? sel.removeAll(g.map((e) => e.path)) : sel.addAll(g.map((e) => e.path))),
          ),
      ]),
    );
  }

  Widget _thumb(FItem it, double side) {
    final isVideo = FileOps.isCat(it.path, Cat.videos);
    if (isVideo) return SizedBox(width: side, height: side, child: FittedBox(fit: BoxFit.cover, clipBehavior: Clip.hardEdge, child: FileThumb(item: it, size: math.max(side, 80))));
    return ImageThumb(key: ValueKey(it.path), item: it, size: side);
  }

  Widget _gridCell(FItem it) {
    final on = sel.contains(it.path);
    final cs = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: () => _open(it),
      onLongPress: () => _toggle(it.path),
      child: Stack(fit: StackFit.expand, children: [
        LayoutBuilder(builder: (_, c) => _thumb(it, c.maxWidth)),
        if (on) Container(color: cs.primary.withOpacity(.35)),
        if (selecting) PositionedDirectional(top: 4, start: 4, child: Icon(on ? Icons.check_circle_rounded : Icons.circle_outlined, color: on ? cs.primary : Colors.white, size: 22)),
        if (extent >= 100)
          Positioned(
            left: 0, right: 0, bottom: 0,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 1),
              color: Colors.black45,
              child: Text(FileOps.dt(it.modified), maxLines: 1, textAlign: TextAlign.center, style: const TextStyle(fontSize: 9.5, color: Colors.white)),
            ),
          ),
      ]),
    );
  }

  Widget _listRow(FItem it) {
    final on = sel.contains(it.path);
    final side = (extent * .75).clamp(48.0, 150.0);
    return ListTile(
      selected: on,
      selectedTileColor: Theme.of(context).colorScheme.primary.withOpacity(.18),
      leading: ClipRRect(borderRadius: BorderRadius.circular(8), child: SizedBox(width: side, height: side, child: _thumb(it, side))),
      title: Text(it.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14)),
      subtitle: Text('${FileOps.fmt(it.size)} • ${FileOps.dt(it.modified)}', style: const TextStyle(fontSize: 11)),
      trailing: selecting ? Icon(on ? Icons.check_circle_rounded : Icons.circle_outlined) : null,
      onTap: () => _open(it),
      onLongPress: () => _toggle(it.path),
    );
  }

  @override
  Widget build(BuildContext context) {
    final groups = _groups;
    return PopScope(
      canPop: !selecting,
      onPopInvokedWithResult: (did, _) {
        if (!did) setState(sel.clear);
      },
      child: Scaffold(
        appBar: AppBar(
          leading: selecting ? IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(sel.clear)) : null,
          title: Text(selecting ? '${sel.length}' : '${widget.title} (${items.length})'),
          actions: [
            if (selecting) ...[
              IconButton(icon: const Icon(Icons.select_all_rounded), tooltip: L.t('selectAll'), onPressed: () => setState(() => sel.addAll(items.map((e) => e.path)))),
              IconButton(icon: const Icon(Icons.share_rounded), tooltip: L.t('share'), onPressed: () => Share.shareXFiles([for (final p in sel) XFile(p)])),
              IconButton(icon: const Icon(Icons.delete_rounded), tooltip: L.t('delete'), onPressed: _delete),
            ] else
              IconButton(icon: Icon(listMode ? Icons.grid_view_rounded : Icons.view_list_rounded), onPressed: _toggleMode),
          ],
        ),
        body: items.isEmpty
            ? Center(child: Text(L.t('empty')))
            : Listener(
                onPointerDown: _down,
                onPointerMove: _move,
                onPointerUp: _up,
                onPointerCancel: _up,
                child: CustomScrollView(
                  physics: _pinching ? const NeverScrollableScrollPhysics() : null,
                  slivers: [
                    for (final g in groups) ...[
                      SliverToBoxAdapter(child: _header(g.key, g.value)),
                      if (listMode)
                        SliverList(delegate: SliverChildBuilderDelegate((_, i) => _listRow(g.value[i]), childCount: g.value.length))
                      else
                        SliverPadding(
                          padding: const EdgeInsets.symmetric(horizontal: 2),
                          sliver: SliverGrid(
                            gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: extent, mainAxisSpacing: 2, crossAxisSpacing: 2),
                            delegate: SliverChildBuilderDelegate((_, i) => _gridCell(g.value[i]), childCount: g.value.length),
                          ),
                        ),
                    ],
                    const SliverToBoxAdapter(child: SizedBox(height: 40)),
                  ],
                ),
              ),
      ),
    );
  }
}
