import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../widgets/ui.dart';
import 'opener.dart';

class AnalyzerScreen extends StatefulWidget {
  const AnalyzerScreen({super.key});
  @override
  State<AnalyzerScreen> createState() => _AnalyzerScreenState();
}

class _AnalyzerScreenState extends State<AnalyzerScreen> {
  final sizes = <String, int>{'images': 0, 'videos': 0, 'music': 0, 'docs': 0, 'apps': 0, 'archives': 0, 'other': 0};
  final big = <FItem>[];
  int total = 0, free = 0, scanned = 0;
  bool done = false;
  static const colors = {'images': Color(0xFF2ECC71), 'videos': Color(0xFFE056FD), 'music': Color(0xFF5B6CFF), 'docs': Color(0xFFFF5C7A), 'apps': Color(0xFFFFB84D), 'archives': Color(0xFFFF9F43), 'other': Color(0xFF3DDCB0)};
  static const keyOf = {Cat.images: 'images', Cat.videos: 'videos', Cat.audio: 'music', Cat.docs: 'docs', Cat.apps: 'apps', Cat.archives: 'archives'};

  @override
  void initState() {
    super.initState();
    _scan();
  }

  Future<void> _scan() async {
    final st = await Native.storage(FileOps.root);
    total = st[0];
    free = st[1];
    var tick = 0;
    await for (final f in FileOps.walk(FileOps.root, hidden: true, skipAndroid: true)) {
      if (!mounted) return;
      try {
        final s = await f.stat();
        final k = keyOf[FileOps.catOf(f.path)] ?? 'other';
        sizes[k] = sizes[k]! + s.size;
        scanned++;
        if (s.size > 20 * 1024 * 1024) {
          big.add(FItem(f, false, s.size, s.modified));
          big.sort((a, b) => b.size.compareTo(a.size));
          if (big.length > 20) big.removeLast();
        }
      } catch (_) {}
      if (++tick % 300 == 0) setState(() {});
    }
    if (mounted) setState(() => done = true);
  }

  @override
  Widget build(BuildContext context) {
    final used = total - free;
    return Scaffold(
      appBar: AppBar(title: Text(L.t('analyzer'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        SizedBox(
          height: 220,
          child: CustomPaint(
            painter: _Donut(sizes, colors, total),
            child: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(FileOps.fmt(free), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
              Text('${L.t('free')} / ${FileOps.fmt(total)}', style: const TextStyle(fontSize: 12)),
              Text('${FileOps.fmt(used)} ${L.t('used')}', style: const TextStyle(fontSize: 12)),
            ])),
          ),
        ),
        if (!done) const Padding(padding: EdgeInsets.all(8), child: LinearProgressIndicator()),
        for (final e in sizes.entries)
          ListTile(
            dense: true,
            leading: CircleAvatar(radius: 7, backgroundColor: colors[e.key]),
            title: Text(L.t(e.key == 'other' ? 'files' : e.key)),
            trailing: Text('${FileOps.fmt(e.value)}  ${total == 0 ? 0 : (e.value * 100 / total).round()}%'),
          ),
        const Divider(),
        Text(L.t('largest'), style: const TextStyle(fontWeight: FontWeight.bold)),
        for (final f in big)
          ListTile(
            dense: true,
            leading: TypeIcon(f.path, false),
            title: Text(f.name, maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: Text(FileOps.fmt(f.size)),
            onTap: () => Opener.open(context, f.path),
          ),
      ]),
    );
  }
}

class _Donut extends CustomPainter {
  final Map<String, int> sizes;
  final Map<String, Color> colors;
  final int total;
  _Donut(this.sizes, this.colors, this.total);
  @override
  void paint(Canvas c, Size s) {
    final r = math.min(s.width, s.height) / 2 - 14;
    final rect = Rect.fromCircle(center: s.center(Offset.zero), radius: r);
    final base = Paint()..style = PaintingStyle.stroke..strokeWidth = 22..color = Colors.white12;
    c.drawCircle(rect.center, r, base);
    if (total == 0) return;
    var start = -math.pi / 2;
    for (final e in sizes.entries) {
      final sweep = e.value / total * 2 * math.pi;
      if (sweep <= 0) continue;
      c.drawArc(rect, start, sweep, false, Paint()..style = PaintingStyle.stroke..strokeWidth = 22..color = colors[e.key]!);
      start += sweep;
    }
  }
  @override
  bool shouldRepaint(covariant _Donut o) => true;
}
