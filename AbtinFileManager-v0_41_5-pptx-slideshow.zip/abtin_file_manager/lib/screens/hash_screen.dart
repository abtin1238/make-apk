import 'dart:io';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/hash_service.dart';
import '../widgets/ui.dart';

class HashScreen extends StatefulWidget {
  final String path;
  const HashScreen({super.key, required this.path});
  @override
  State<HashScreen> createState() => _HashScreenState();
}

class _HashScreenState extends State<HashScreen> {
  Map<String, String>? res;
  double progress = 0;
  String? err;
  bool stop = false, upper = false;
  int size = 0;
  final cmp = TextEditingController();

  @override
  void initState() {
    super.initState();
    _run();
  }

  @override
  void dispose() {
    stop = true;
    cmp.dispose();
    super.dispose();
  }

  Future<void> _run() async {
    try {
      size = await File(widget.path).length();
      final r = await HashService.compute(
        widget.path,
        onProgress: (v) { if (mounted) setState(() => progress = v); },
        cancelled: () => stop,
      );
      if (mounted) setState(() => res = r);
    } catch (e) {
      if (mounted) setState(() => err = e is OpError ? L.t(e.key) : '$e');
    }
  }

  String _fmt(String v) => upper ? v.toUpperCase() : v;

  String? _matchName() {
    final x = cmp.text.trim().toLowerCase().replaceAll(RegExp(r'\s'), '');
    if (x.isEmpty || res == null) return null;
    for (final e in res!.entries) {
      if (e.value == x) return e.key;
    }
    return '';
  }

  @override
  Widget build(BuildContext context) {
    final m = _matchName();
    return Scaffold(
      appBar: AppBar(
        title: Text(L.t('hash'), style: const TextStyle(fontSize: 16)),
        actions: [
          IconButton(icon: const Icon(Icons.abc_rounded), tooltip: 'abc / ABC', onPressed: () => setState(() => upper = !upper)),
        ],
      ),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: TypeIcon(widget.path, false, size: 36),
          title: Text(p.basename(widget.path), maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text('${FileOps.fmt(size)} ($size B)'),
        ),
        if (res == null && err == null) ...[
          LinearProgressIndicator(value: progress == 0 ? null : progress),
          Padding(padding: const EdgeInsets.only(top: 6), child: Text('${L.t('hashing')} ${(progress * 100).toStringAsFixed(0)}%')),
        ],
        if (err != null) Text(err!, style: const TextStyle(color: Colors.redAccent)),
        if (res != null) ...[
          for (final e in res!.entries)
            Card(
              child: ListTile(
                title: Text(e.key, style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: SelectableText(_fmt(e.value), style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
                trailing: IconButton(
                  icon: const Icon(Icons.copy_rounded),
                  tooltip: L.t('copy'),
                  onPressed: () { Clipboard.setData(ClipboardData(text: _fmt(e.value))); snack(context, L.t('copied')); },
                ),
              ),
            ),
          const SizedBox(height: 8),
          TextField(
            controller: cmp,
            onChanged: (_) => setState(() {}),
            decoration: InputDecoration(
              labelText: L.t('compareHash'),
              suffixIcon: IconButton(
                icon: const Icon(Icons.paste_rounded),
                onPressed: () async {
                  final d = await Clipboard.getData('text/plain');
                  if (d?.text != null) { cmp.text = d!.text!; setState(() {}); }
                },
              ),
            ),
          ),
          if (m != null)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: Row(children: [
                Icon(m.isEmpty ? Icons.cancel_rounded : Icons.check_circle_rounded, color: m.isEmpty ? Colors.redAccent : Colors.green),
                const SizedBox(width: 8),
                Text(m.isEmpty ? L.t('noMatch') : '${L.t('match')} ($m)', style: TextStyle(color: m.isEmpty ? Colors.redAccent : Colors.green, fontWeight: FontWeight.bold)),
              ]),
            ),
        ],
      ]),
    );
  }
}
