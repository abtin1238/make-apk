import 'dart:async';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:provider/provider.dart';
import '../core/app_lock.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../services/sec_native.dart';
import '../widgets/pin_pad.dart';

/// Wraps the whole app: while [AppLock.locked] the app is kept alive but hidden behind the lock screen.
class AppLockGate extends StatelessWidget {
  final Widget child;
  const AppLockGate({super.key, required this.child});
  @override
  Widget build(BuildContext context) {
    final locked = context.select<AppLock, bool>((l) => l.locked);
    return PopScope(
      canPop: !locked,
      child: Stack(fit: StackFit.expand, children: [
        Offstage(offstage: locked, child: child),
        if (locked) const LockScreen(),
      ]),
    );
  }
}

class LockScreen extends StatefulWidget {
  const LockScreen({super.key});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> with WidgetsBindingObserver {
  String? _msg;
  bool _bioBusy = false;
  Timer? _tick;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) => _bio());
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _tick?.cancel();
    Sec.bioCancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _bio();
  }

  Future<void> _bio() async {
    final lock = context.read<AppLock>();
    if (!lock.bio || _bioBusy || lock.lockoutLeft > 0) return;
    _bioBusy = true;
    final ok = await Sec.bioAuth(L.t('bioTitle'), L.t('usePin'));
    _bioBusy = false;
    if (ok && mounted) lock.unlock();
  }

  void _startTick() {
    _tick?.cancel();
    _tick = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return t.cancel();
      if (context.read<AppLock>().lockoutLeft <= 0) {
        t.cancel();
        setState(() => _msg = null);
      } else {
        setState(() {});
      }
    });
  }

  Future<void> _submit(String pin) async {
    final lock = context.read<AppLock>();
    final r = await lock.verify(pin);
    if (!mounted) return;
    switch (r) {
      case PinResult.ok:
        lock.unlock();
      case PinResult.wrong:
        setState(() => _msg = L.t('wrongPin'));
      case PinResult.lockedOut:
        setState(() => _msg = 'lock');
        _startTick();
    }
  }

  @override
  Widget build(BuildContext context) {
    final lock = context.watch<AppLock>();
    final left = lock.lockoutLeft;
    final text = left > 0 ? '${L.t('tooMany')} $left ${L.t('sec')}' : (_msg == 'lock' ? null : _msg);
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(
                width: 84, height: 84,
                decoration: const BoxDecoration(shape: BoxShape.circle, gradient: AppColors.grad),
                child: const Icon(Icons.lock_rounded, size: 42, color: Colors.white),
              ),
              const SizedBox(height: 16),
              Text(L.t('enterPin'), style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 8),
              SizedBox(
                height: 22,
                child: text == null ? null : Text(text, style: TextStyle(color: Theme.of(context).colorScheme.error)),
              ),
              const SizedBox(height: 20),
              PinEntry(
                length: lock.pinLength,
                enabled: left <= 0,
                onComplete: _submit,
                extraIcon: lock.bio ? Icons.fingerprint_rounded : null,
                onExtra: _bio,
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
