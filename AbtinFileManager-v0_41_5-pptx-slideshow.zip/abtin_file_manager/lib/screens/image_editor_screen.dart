import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../widgets/ui.dart';

// ───────────────────────── isolate helpers ─────────────────────────

class _Prep {
  final Uint8List preview; // <= 2048 px, for the live canvas
  final Uint8List full; // orientation baked, <= 4096 px, for the final render
  final int w, h; // size of `full`
  _Prep(this.preview, this.full, this.w, this.h);
}

_Prep _prepare(Uint8List bytes) {
  var im = img.decodeImage(bytes);
  if (im == null) throw Exception('decode');
  im = img.bakeOrientation(im);
  if (im.width > 4096 || im.height > 4096) {
    im = img.copyResize(im, width: im.width >= im.height ? 4096 : null, height: im.height > im.width ? 4096 : null);
  }
  final w = im.width, h = im.height;
  final alpha = im.hasAlpha;
  final full = Uint8List.fromList(alpha ? img.encodePng(im) : img.encodeJpg(im, quality: 97));
  var pv = im;
  if (w > 2048 || h > 2048) {
    pv = img.copyResize(im, width: w >= h ? 2048 : null, height: h > w ? 2048 : null);
  }
  final preview = Uint8List.fromList(alpha ? img.encodePng(pv) : img.encodeJpg(pv, quality: 90));
  return _Prep(preview, full, w, h);
}

Uint8List _encodeOut(Map<String, dynamic> a) {
  final png = a['png'] as Uint8List;
  final ext = a['ext'] as String;
  if (ext == 'png') return png;
  final im = img.decodePng(png)!;
  switch (ext) {
    case 'bmp': return Uint8List.fromList(img.encodeBmp(im));
    case 'gif': return Uint8List.fromList(img.encodeGif(im));
    default: return Uint8List.fromList(img.encodeJpg(im, quality: 95));
  }
}

// ───────────────────────── colour matrices ─────────────────────────

const List<double> _id = [1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0];

/// result = a(b(x)): apply `b` first, then `a` (4x5 affine matrices, offsets in 0..255).
List<double> _mm(List<double> a, List<double> b) {
  final o = List<double>.filled(20, 0);
  for (var i = 0; i < 4; i++) {
    for (var j = 0; j < 5; j++) {
      var s = 0.0;
      for (var k = 0; k < 4; k++) {
        s += a[i * 5 + k] * b[k * 5 + j];
      }
      if (j == 4) s += a[i * 5 + 4];
      o[i * 5 + j] = s;
    }
  }
  return o;
}

List<double> _lerpM(List<double> a, List<double> b, double t) => [for (var i = 0; i < 20; i++) a[i] + (b[i] - a[i]) * t];

List<double> _satM(double s) {
  const lr = .2126, lg = .7152, lb = .0722;
  return [
    lr * (1 - s) + s, lg * (1 - s), lb * (1 - s), 0, 0,
    lr * (1 - s), lg * (1 - s) + s, lb * (1 - s), 0, 0,
    lr * (1 - s), lg * (1 - s), lb * (1 - s) + s, 0, 0,
    0, 0, 0, 1, 0,
  ];
}

List<double> _conM(double c) {
  final o = 127.5 * (1 - c);
  return [c, 0, 0, 0, o, 0, c, 0, 0, o, 0, 0, c, 0, o, 0, 0, 0, 1, 0];
}

List<double> _briM(double b) => [b, 0, 0, 0, 0, 0, b, 0, 0, 0, 0, 0, b, 0, 0, 0, 0, 0, 1, 0];

List<double> _warmM(double w) {
  final r = 1 + .22 * w, bl = 1 - .22 * w;
  return [r, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, bl, 0, 0, 0, 0, 0, 1, 0];
}

List<double> _offM(double o) => [1, 0, 0, 0, o, 0, 1, 0, 0, o, 0, 0, 1, 0, o, 0, 0, 0, 1, 0];

List<List<double>> _buildFilters() {
  final mono = _satM(0);
  const sepia = <double>[.393, .769, .189, 0, 0, .349, .686, .168, 0, 0, .272, .534, .131, 0, 0, 0, 0, 0, 1, 0];
  return [
    _id,
    _mm(_conM(1.12), _satM(1.45)),
    _mm(_warmM(.7), _satM(1.1)),
    _warmM(-.7),
    mono,
    _mm(_conM(1.4), _mm(_briM(.95), mono)),
    sepia,
    _mm(_offM(10), _mm(_conM(.9), _lerpM(_id, sepia, .6))),
    _mm(_offM(14), _mm(_conM(.82), _satM(.85))),
    _mm(_conM(1.3), _mm(_briM(.96), _satM(.8))),
  ];
}

final List<List<double>> _filters = _buildFilters();
const List<(String, String)> _filterNames = [
  ('اصلی', 'Original'), ('زنده', 'Vivid'), ('گرم', 'Warm'), ('سرد', 'Cool'), ('سیاه‌وسفید', 'Mono'),
  ('نوآر', 'Noir'), ('سپیا', 'Sepia'), ('قدیمی', 'Vintage'), ('محو', 'Fade'), ('دراماتیک', 'Drama'),
];

// ───────────────────────── overlay model (normalised to the image box) ─────────────────────────

class _Stroke {
  final List<Offset> pts;
  final Color color;
  final double w; // fraction of image width
  final bool marker;
  _Stroke(this.pts, this.color, this.w, this.marker);
}

class _Item {
  String text;
  Color color;
  double size; // font size, fraction of image width
  double rot;
  Offset pos; // centre, 0..1
  bool bg, bold;
  _Item(this.text, this.color, this.size, this.pos, {this.rot = 0, this.bg = false, this.bold = true});
  _Item copy() => _Item(text, color, size, pos, rot: rot, bg: bg, bold: bold);
}

class _Snap {
  final int turns, filter;
  final bool fh, fv;
  final Rect crop;
  final double br, ct, sat, warm, vig;
  final List<_Stroke> strokes;
  final List<_Item> items;
  _Snap(this.turns, this.fh, this.fv, this.crop, this.filter, this.br, this.ct, this.sat, this.warm, this.vig, this.strokes, this.items);
}

final RegExp _rtlRe = RegExp(r'[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]');

TextPainter _tp(_Item it, double w) => TextPainter(
      text: TextSpan(
        text: it.text,
        style: TextStyle(
          fontSize: it.size * w,
          color: it.color,
          fontWeight: it.bold ? FontWeight.w800 : FontWeight.w500,
          height: 1.15,
          shadows: it.bg ? null : const [Shadow(color: Colors.black54, blurRadius: 4, offset: Offset(1, 1))],
        ),
      ),
      textDirection: _rtlRe.hasMatch(it.text) ? TextDirection.rtl : TextDirection.ltr,
      textAlign: TextAlign.center,
    )..layout(maxWidth: w * .9);

void _paintVig(Canvas c, Size s, double amt) {
  if (amt <= 0) return;
  final center = Offset(s.width / 2, s.height / 2);
  final rad = math.sqrt(s.width * s.width + s.height * s.height) / 2;
  final a = (amt * .85).clamp(0.0, 1.0).toDouble();
  c.drawRect(
    Offset.zero & s,
    Paint()..shader = ui.Gradient.radial(center, rad, [const Color(0x00000000), Color.fromRGBO(0, 0, 0, a)], [.45, 1.0]),
  );
}

void _paintOverlay(Canvas c, Size sz, List<_Stroke> strokes, List<_Item> items, _Item? sel) {
  final w = sz.width, h = sz.height;
  for (final s in strokes) {
    if (s.pts.isEmpty) continue;
    final col = s.marker ? s.color.withOpacity(.4) : s.color;
    final sw = s.w * w;
    if (s.pts.length == 1) {
      c.drawCircle(Offset(s.pts[0].dx * w, s.pts[0].dy * h), sw / 2, Paint()..color = col);
      continue;
    }
    final path = Path()..moveTo(s.pts[0].dx * w, s.pts[0].dy * h);
    for (var i = 1; i < s.pts.length - 1; i++) {
      final a = s.pts[i], b = s.pts[i + 1];
      path.quadraticBezierTo(a.dx * w, a.dy * h, (a.dx + b.dx) / 2 * w, (a.dy + b.dy) / 2 * h);
    }
    path.lineTo(s.pts.last.dx * w, s.pts.last.dy * h);
    c.drawPath(
      path,
      Paint()
        ..color = col
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round
        ..strokeJoin = StrokeJoin.round
        ..strokeWidth = sw,
    );
  }
  for (final it in items) {
    final tp = _tp(it, w);
    final pad = it.size * w * .3;
    final rect = Rect.fromCenter(center: Offset.zero, width: tp.width + pad * 2, height: tp.height + pad);
    c.save();
    c.translate(it.pos.dx * w, it.pos.dy * h);
    c.rotate(it.rot);
    if (it.bg) {
      c.drawRRect(RRect.fromRectAndRadius(rect, Radius.circular(pad)), Paint()..color = it.color.computeLuminance() > .5 ? Colors.black54 : Colors.white70);
    }
    tp.paint(c, Offset(-tp.width / 2, -tp.height / 2));
    if (identical(it, sel)) {
      c.drawRRect(
        RRect.fromRectAndRadius(rect.inflate(4), Radius.circular(pad)),
        Paint()
          ..color = Colors.white
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6,
      );
    }
    c.restore();
  }
}

class _OverlayPainter extends CustomPainter {
  final List<_Stroke> strokes;
  final List<_Item> items;
  final _Stroke? live;
  final _Item? sel;
  _OverlayPainter(this.strokes, this.items, this.live, this.sel);
  @override
  void paint(Canvas c, Size s) => _paintOverlay(c, s, live == null ? strokes : [...strokes, live!], items, sel);
  @override
  bool shouldRepaint(covariant _OverlayPainter o) => true;
}

class _VigPainter extends CustomPainter {
  final double amt;
  _VigPainter(this.amt);
  @override
  void paint(Canvas c, Size s) => _paintVig(c, s, amt);
  @override
  bool shouldRepaint(covariant _VigPainter o) => o.amt != amt;
}

enum _Tool { none, crop, filters, adjust, draw, text, sticker }

class ImageEditorScreen extends StatefulWidget {
  final String path;
  const ImageEditorScreen({super.key, required this.path});
  @override
  State<ImageEditorScreen> createState() => _ImageEditorScreenState();
}

class _ImageEditorScreenState extends State<ImageEditorScreen> {
  static const _full = Rect.fromLTRB(0, 0, 1, 1);
  static const _palette = [Colors.white, Colors.black, Color(0xFFFF3B30), Color(0xFFFF9500), Color(0xFFFFD60A), Color(0xFF34C759), Color(0xFF0A84FF), Color(0xFFBF5AF2), Color(0xFFFF2D87)];
  static const _emoji = ['😀', '😂', '😍', '😎', '🥳', '😭', '😡', '👍', '👏', '🙏', '💪', '🔥', '❤️', '💯', '⭐', '✨', '🎉', '🎈', '🌹', '☀️', '🌙', '⚡', '🍕', '☕', '🎵', '📌', '✅', '❌', '➡️', '⬅️'];

  _Prep? prep;
  String? err;
  // transform
  int turns = 0;
  bool fh = false, fv = false;
  Rect crop = _full;
  double? ratio;
  // look
  int filter = 0;
  double br = 1, ct = 1, sat = 1, warm = 0, vig = 0;
  // overlay
  final List<_Stroke> strokes = [];
  final List<_Item> items = [];
  _Stroke? live;
  _Item? sel;
  Color penColor = const Color(0xFFFF3B30), textColor = Colors.white;
  double penW = .012;
  bool marker = false;
  // ui
  _Tool tool = _Tool.none;
  bool showOrig = false;
  Size _box = const Size(1, 1);
  // history
  final List<_Snap> hist = [];
  int hi = 0;
  // gesture temp
  Offset _gp0 = Offset.zero, _gf0 = Offset.zero;
  double _gs0 = .07, _gr0 = 0;
  bool _moved = false;

  bool get dirty => hi > 0;
  double get dw => (turns.isOdd ? prep!.h : prep!.w).toDouble();
  double get dh => (turns.isOdd ? prep!.w : prep!.h).toDouble();

  @override
  void initState() {
    super.initState();
    hist.add(_snap());
    _load();
  }

  Future<void> _load() async {
    try {
      final b = await File(widget.path).readAsBytes();
      final r = await compute(_prepare, b);
      if (mounted) setState(() => prep = r);
    } catch (e) {
      if (mounted) setState(() => err = '${L.t('error')}: $e');
    }
  }

  // ── history ──
  _Snap _snap() => _Snap(turns, fh, fv, crop, filter, br, ct, sat, warm, vig, List.of(strokes), [for (final i in items) i.copy()]);

  void _restore(_Snap s) {
    turns = s.turns; fh = s.fh; fv = s.fv; crop = s.crop; filter = s.filter;
    br = s.br; ct = s.ct; sat = s.sat; warm = s.warm; vig = s.vig;
    strokes..clear()..addAll(s.strokes);
    items..clear()..addAll([for (final i in s.items) i.copy()]);
    sel = null;
    live = null;
    ratio = null;
  }

  void _commit() {
    if (hi < hist.length - 1) hist.removeRange(hi + 1, hist.length);
    hist.add(_snap());
    hi = hist.length - 1;
    setState(() {});
  }

  void _undo() { if (hi > 0) setState(() { hi--; _restore(hist[hi]); }); }
  void _redo() { if (hi < hist.length - 1) setState(() { hi++; _restore(hist[hi]); }); }

  void _resetAll() => setState(() { hi = 0; _restore(hist[0]); hist.removeRange(1, hist.length); });

  // ── transform ──
  void _resetCrop() { crop = _full; ratio = null; }

  void _mapOverlay(Offset Function(Offset) f, double sizeF, double rotAdd, bool neg) {
    final ns = [for (final s in strokes) _Stroke([for (final o in s.pts) f(o)], s.color, s.w * sizeF, s.marker)];
    strokes..clear()..addAll(ns);
    for (final it in items) {
      it.pos = f(it.pos);
      it.size *= sizeF;
      it.rot = neg ? -it.rot : it.rot + rotAdd;
    }
  }

  void _rot(int d) {
    final f = dw / dh; // old width / new width keeps the absolute size of strokes and texts
    _mapOverlay((o) => d > 0 ? Offset(1 - o.dy, o.dx) : Offset(o.dy, 1 - o.dx), f, d * math.pi / 2, false);
    setState(() { turns = ((turns + d) % 4 + 4) % 4; _resetCrop(); });
    _commit();
  }

  void _flip(bool h) {
    _mapOverlay((o) => h ? Offset(1 - o.dx, o.dy) : Offset(o.dx, 1 - o.dy), 1, 0, true);
    setState(() { if (h) { fh = !fh; } else { fv = !fv; } _resetCrop(); });
    _commit();
  }

  void _preset(double? r) {
    setState(() {
      ratio = r;
      if (r == null) return;
      final a = dw / dh;
      final rw = r > a ? 1.0 : r * dh / dw;
      final rh = r > a ? (dw / r) / dh : 1.0;
      crop = Rect.fromCenter(center: const Offset(.5, .5), width: rw, height: rh);
    });
    _commit();
  }

  List<double> _total() => _mm(_warmM(warm), _mm(_satM(sat), _mm(_briM(br), _mm(_conM(ct), _filters[filter]))));

  // ── render + save ──
  Future<Uint8List> _renderPng() async {
    final codec = await ui.instantiateImageCodec(prep!.full);
    final fr = await codec.getNextFrame();
    final src = fr.image;
    final tw = (turns.isOdd ? src.height : src.width).toDouble();
    final th = (turns.isOdd ? src.width : src.height).toDouble();
    final cx = (crop.left * tw).roundToDouble().clamp(0.0, tw - 1).toDouble();
    final cy = (crop.top * th).roundToDouble().clamp(0.0, th - 1).toDouble();
    final cw = ((crop.right - crop.left) * tw).roundToDouble().clamp(1.0, tw - cx).toDouble();
    final ch = ((crop.bottom - crop.top) * th).roundToDouble().clamp(1.0, th - cy).toDouble();
    final rec = ui.PictureRecorder();
    final c = Canvas(rec);
    c.translate(-cx, -cy);
    c.save();
    c.translate(tw / 2, th / 2);
    c.scale(fh ? -1.0 : 1.0, fv ? -1.0 : 1.0);
    c.rotate(turns * math.pi / 2);
    c.translate(-src.width / 2, -src.height / 2);
    c.drawImage(src, Offset.zero, Paint()..colorFilter = ColorFilter.matrix(_total())..filterQuality = FilterQuality.high);
    c.restore();
    _paintVig(c, Size(tw, th), vig);
    _paintOverlay(c, Size(tw, th), strokes, items, null);
    final pic = rec.endRecording();
    final out = await pic.toImage(cw.toInt(), ch.toInt());
    final bd = await out.toByteData(format: ui.ImageByteFormat.png);
    src.dispose();
    out.dispose();
    if (bd == null) throw Exception('render');
    return bd.buffer.asUint8List(bd.offsetInBytes, bd.lengthInBytes);
  }

  Future<void> _save() async {
    final ext = FileOps.ext(widget.path);
    final canOverwrite = const {'jpg', 'jpeg', 'png', 'bmp', 'gif'}.contains(ext);
    final outExt = switch (ext) { 'png' => 'png', 'bmp' => 'bmp', 'gif' => 'gif', 'jpg' || 'jpeg' => 'jpg', _ => 'png' };
    final choice = await showModalBottomSheet<bool>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.save_alt_rounded), title: Text(L.t('saveCopy')), onTap: () => Navigator.pop(context, false)),
          if (canOverwrite) ListTile(leading: const Icon(Icons.save_rounded), title: Text(L.t('overwrite')), onTap: () => Navigator.pop(context, true)),
        ]),
      ),
    );
    if (choice == null || !mounted) return;
    if (!await ensureSdAll(context, [widget.path])) return;
    if (!mounted) return;
    String? target;
    final ok = await busy(context, () async {
      final png = await _renderPng();
      final out = await compute(_encodeOut, <String, dynamic>{'png': png, 'ext': outExt});
      final t = choice ? widget.path : FileOps.unique(p.dirname(widget.path), '${p.basenameWithoutExtension(widget.path)} (edited).$outExt');
      if (await Saf.use(t)) {
        await Saf.writeBytes(t, out);
      } else {
        final tmp = '$t.tmp';
        try {
          await File(tmp).writeAsBytes(out, flush: true);
          await File(tmp).rename(t);
        } catch (_) {
          try { await File(tmp).delete(); } catch (_) {}
          rethrow;
        }
      }
      target = t;
    });
    if (!ok || target == null || !mounted) return;
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
    await Native.scan(target!);
    if (mounted) Navigator.pop(context, target);
  }

  // ── text / sticker items ──
  Offset _norm(Offset q) => Offset((q.dx / _box.width).clamp(0.0, 1.0).toDouble(), (q.dy / _box.height).clamp(0.0, 1.0).toDouble());

  _Item? _hitItem(Offset local) {
    final w = _box.width, h = _box.height;
    for (final it in items.reversed) {
      final tp = _tp(it, w);
      final d = local - Offset(it.pos.dx * w, it.pos.dy * h);
      final cs = math.cos(-it.rot), sn = math.sin(-it.rot);
      final x = d.dx * cs - d.dy * sn, y = d.dx * sn + d.dy * cs;
      final pad = it.size * w * .3 + 14;
      if (x.abs() <= tp.width / 2 + pad && y.abs() <= tp.height / 2 + pad) return it;
    }
    return null;
  }

  Future<void> _addText([_Item? edit]) async {
    final t = await promptText(context, L.t('text'), initial: edit?.text ?? '');
    if (t == null || t.trim().isEmpty || !mounted) return;
    if (edit != null) {
      setState(() => edit.text = t.trim());
    } else {
      final it = _Item(t.trim(), textColor, .07, const Offset(.5, .5));
      setState(() { items.add(it); sel = it; });
    }
    _commit();
  }

  void _addEmoji(String e) {
    final it = _Item(e, Colors.white, .16, const Offset(.5, .5), bold: false);
    setState(() { items.add(it); sel = it; });
    _commit();
  }

  void _deleteSel() {
    final s = sel;
    if (s == null) return;
    setState(() { items.removeWhere((e) => identical(e, s)); sel = null; });
    _commit();
  }

  // ───────────────────────── UI ─────────────────────────

  @override
  Widget build(BuildContext context) {
    final pc = Theme.of(context).colorScheme.primary;
    final dark = ThemeData.dark(useMaterial3: true).copyWith(colorScheme: ColorScheme.fromSeed(seedColor: pc, brightness: Brightness.dark));
    return Theme(
      data: dark,
      child: PopScope(
        canPop: !dirty,
        onPopInvokedWithResult: (didPop, _) async {
          if (didPop) return;
          if (await confirm(context, L.t('discard')) && context.mounted) Navigator.pop(context);
        },
        child: Scaffold(
          backgroundColor: Colors.black,
          appBar: AppBar(
            backgroundColor: const Color(0xFF0B0B0B),
            title: Text(L.t('edit'), style: const TextStyle(fontSize: 16)),
            actions: [
              IconButton(icon: const Icon(Icons.undo_rounded), tooltip: L.t('undo'), onPressed: hi > 0 ? _undo : null),
              IconButton(icon: const Icon(Icons.redo_rounded), tooltip: L.t('redo'), onPressed: hi < hist.length - 1 ? _redo : null),
              if (dirty) IconButton(icon: const Icon(Icons.restart_alt_rounded), tooltip: L.t('reset'), onPressed: _resetAll),
              IconButton(icon: const Icon(Icons.check_rounded), tooltip: L.t('save'), onPressed: dirty && prep != null ? _save : null),
            ],
          ),
          body: err != null
              ? Center(child: Text(err!, style: const TextStyle(color: Colors.white70)))
              : prep == null
                  ? const Center(child: CircularProgressIndicator())
                  : Column(children: [
                      Expanded(
                        child: Stack(children: [
                          Positioned.fill(child: Padding(padding: const EdgeInsets.all(10), child: _canvas())),
                          Positioned(
                            right: 14,
                            bottom: 10,
                            child: Listener(
                              onPointerDown: (_) => setState(() => showOrig = true),
                              onPointerUp: (_) => setState(() => showOrig = false),
                              onPointerCancel: (_) => setState(() => showOrig = false),
                              child: Container(
                                padding: const EdgeInsets.all(10),
                                decoration: BoxDecoration(color: Colors.black54, shape: BoxShape.circle, border: Border.all(color: Colors.white24)),
                                child: Icon(Icons.compare_rounded, size: 22, color: showOrig ? pc : Colors.white),
                              ),
                            ),
                          ),
                        ]),
                      ),
                      _panel(),
                      _tabs(),
                    ]),
        ),
      ),
    );
  }

  Widget _canvas() => Center(
        child: AspectRatio(
          aspectRatio: dw / dh,
          child: LayoutBuilder(builder: (c, box) {
            _box = box.biggest;
            final cropOn = tool == _Tool.crop;
            return ClipRect(
              child: Stack(fit: StackFit.expand, children: [
                Transform.scale(
                  scaleX: fh ? -1 : 1,
                  scaleY: fv ? -1 : 1,
                  child: RotatedBox(
                    quarterTurns: turns,
                    child: ColorFiltered(
                      colorFilter: ColorFilter.matrix(showOrig ? _id : _total()),
                      child: Image.memory(prep!.preview, fit: BoxFit.fill, gaplessPlayback: true),
                    ),
                  ),
                ),
                if (!showOrig && vig > 0) IgnorePointer(child: CustomPaint(painter: _VigPainter(vig))),
                if (!showOrig) IgnorePointer(child: CustomPaint(painter: _OverlayPainter(strokes, items, live, sel))),
                if (tool == _Tool.draw) _drawLayer(),
                if (tool == _Tool.text || tool == _Tool.sticker) _itemLayer(),
                if (cropOn) _CropOverlay(rect: crop, ratio: ratio, onChanged: (r) => setState(() => crop = r), onEnd: _commit),
              ]),
            );
          }),
        ),
      );

  Widget _drawLayer() => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) {
          strokes.add(_Stroke([_norm(d.localPosition)], penColor, penW, marker));
          _commit();
        },
        onPanStart: (d) => setState(() => live = _Stroke([_norm(d.localPosition)], penColor, penW, marker)),
        onPanUpdate: (d) {
          final l = live;
          if (l == null) return;
          setState(() => l.pts.add(_norm(d.localPosition)));
        },
        onPanEnd: (_) {
          final l = live;
          if (l == null) return;
          strokes.add(l);
          live = null;
          _commit();
        },
      );

  Widget _itemLayer() => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (d) => setState(() => sel = _hitItem(d.localPosition)),
        onScaleStart: (d) {
          final h = _hitItem(d.localFocalPoint);
          setState(() => sel = h);
          if (h != null) {
            _gp0 = h.pos;
            _gs0 = h.size;
            _gr0 = h.rot;
            _gf0 = d.localFocalPoint;
            _moved = false;
          }
        },
        onScaleUpdate: (d) {
          final it = sel;
          if (it == null) return;
          setState(() {
            it.pos = Offset(
              (_gp0.dx + (d.localFocalPoint.dx - _gf0.dx) / _box.width).clamp(0.0, 1.0).toDouble(),
              (_gp0.dy + (d.localFocalPoint.dy - _gf0.dy) / _box.height).clamp(0.0, 1.0).toDouble(),
            );
            if (d.pointerCount > 1) {
              it.size = (_gs0 * d.scale).clamp(.02, .5).toDouble();
              it.rot = _gr0 + d.rotation;
            }
          });
          _moved = true;
        },
        onScaleEnd: (_) {
          if (_moved && sel != null) _commit();
          _moved = false;
        },
      );

  // ── bottom panels ──
  Widget _panel() {
    Widget body = const SizedBox.shrink();
    switch (tool) {
      case _Tool.crop: body = _cropPanel(); break;
      case _Tool.filters: body = _filterPanel(); break;
      case _Tool.adjust: body = _adjustPanel(); break;
      case _Tool.draw: body = _drawPanel(); break;
      case _Tool.text: body = _textPanel(); break;
      case _Tool.sticker: body = _stickerPanel(); break;
      case _Tool.none: return const SizedBox.shrink();
    }
    return Container(color: const Color(0xFF111111), padding: const EdgeInsets.symmetric(vertical: 8), child: body);
  }

  Widget _cropPanel() {
    Widget chip(String t, double? r) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: ChoiceChip(label: Text(t), selected: ratio == r && (r != null || crop != _full), onSelected: (_) => r == null ? setState(() { _resetCrop(); }) : _preset(r)),
        );
    Widget ib(IconData i, String tip, VoidCallback f) => IconButton(icon: Icon(i), tooltip: tip, onPressed: f);
    return Column(mainAxisSize: MainAxisSize.min, children: [
      SizedBox(
        height: 46,
        child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
          chip(L.t('freeCrop'), null), chip('1:1', 1), chip('4:3', 4 / 3), chip('3:4', 3 / 4), chip('16:9', 16 / 9), chip('9:16', 9 / 16),
        ]),
      ),
      Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        ib(Icons.rotate_left_rounded, L.t('rotate'), () => _rot(-1)),
        ib(Icons.rotate_right_rounded, L.t('rotate'), () => _rot(1)),
        ib(Icons.flip_rounded, L.t('flipH'), () => _flip(true)),
        Transform.rotate(angle: math.pi / 2, child: ib(Icons.flip_rounded, L.t('flipV'), () => _flip(false))),
      ]),
    ]);
  }

  Widget _filterPanel() => SizedBox(
        height: 108,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          itemCount: _filters.length,
          itemBuilder: (_, i) {
            final on = i == filter;
            final pc = Theme.of(context).colorScheme.primary;
            return GestureDetector(
              onTap: () { setState(() => filter = i); _commit(); },
              child: Container(
                width: 74,
                margin: const EdgeInsets.symmetric(horizontal: 4),
                child: Column(children: [
                  Container(
                    width: 66,
                    height: 66,
                    decoration: BoxDecoration(borderRadius: BorderRadius.circular(12), border: Border.all(color: on ? pc : Colors.white24, width: on ? 2.5 : 1)),
                    clipBehavior: Clip.antiAlias,
                    child: ColorFiltered(
                      colorFilter: ColorFilter.matrix(_filters[i]),
                      child: Image.memory(prep!.preview, fit: BoxFit.cover, cacheWidth: 140),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(L.lang == 'fa' ? _filterNames[i].$1 : _filterNames[i].$2, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.5, color: on ? pc : Colors.white70)),
                ]),
              ),
            );
          },
        ),
      );

  Widget _adjustPanel() {
    Widget row(String t, double v, double min, double max, double def, ValueChanged<double> f) => Row(children: [
          SizedBox(width: 92, child: Padding(padding: const EdgeInsets.only(left: 12), child: Text(t, style: const TextStyle(color: Colors.white70, fontSize: 13)))),
          Expanded(child: LSlider(value: v, min: min, max: max, onChanged: (x) => setState(() => f(x)), onChangeEnd: (_) => _commit())),
          SizedBox(width: 44, child: Text('${((v - def) * 100).round()}', textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12))),
          IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.restart_alt_rounded, size: 18), onPressed: v == def ? null : () { setState(() => f(def)); _commit(); }),
        ]);
    return Column(mainAxisSize: MainAxisSize.min, children: [
      row(L.t('brightness'), br, .5, 1.5, 1, (x) => br = x),
      row(L.t('contrast'), ct, .5, 1.5, 1, (x) => ct = x),
      row(L.t('saturation'), sat, 0, 2, 1, (x) => sat = x),
      row(L.t('warmth'), warm, -1, 1, 0, (x) => warm = x),
      row(L.t('vignette'), vig, 0, 1, 0, (x) => vig = x),
    ]);
  }

  Widget _dots(Color cur, ValueChanged<Color> f) => SizedBox(
        height: 40,
        child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 10), children: [
          for (final c in _palette)
            GestureDetector(
              onTap: () => f(c),
              child: Container(
                width: 30,
                height: 30,
                margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                decoration: BoxDecoration(color: c, shape: BoxShape.circle, border: Border.all(color: cur == c ? Colors.white : Colors.white24, width: cur == c ? 3 : 1)),
              ),
            ),
        ]),
      );

  Widget _drawPanel() => Column(mainAxisSize: MainAxisSize.min, children: [
        Row(children: [
          const SizedBox(width: 10),
          ChoiceChip(label: Text(L.t('pen')), selected: !marker, onSelected: (_) => setState(() => marker = false)),
          const SizedBox(width: 8),
          ChoiceChip(label: Text(L.t('marker')), selected: marker, onSelected: (_) => setState(() => marker = true)),
          const Spacer(),
          IconButton(icon: const Icon(Icons.backspace_outlined), tooltip: L.t('undo'), onPressed: strokes.isEmpty ? null : () { setState(() => strokes.removeLast()); _commit(); }),
          IconButton(icon: const Icon(Icons.delete_sweep_rounded), tooltip: L.t('clearAll'), onPressed: strokes.isEmpty ? null : () { setState(() => strokes.clear()); _commit(); }),
        ]),
        _dots(penColor, (c) => setState(() => penColor = c)),
        Row(children: [
          const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Icon(Icons.line_weight_rounded, size: 20)),
          Expanded(child: LSlider(value: penW, min: .004, max: .05, onChanged: (v) => setState(() => penW = v))),
          Container(width: 30, height: 30, alignment: Alignment.center, child: Container(width: 6 + penW * 400, height: 6 + penW * 400, decoration: BoxDecoration(color: penColor, shape: BoxShape.circle))),
          const SizedBox(width: 12),
        ]),
      ]);

  Widget _itemControls() {
    final s = sel;
    return Column(mainAxisSize: MainAxisSize.min, children: [
      if (s != null) ...[
        Row(children: [
          const Padding(padding: EdgeInsets.symmetric(horizontal: 12), child: Icon(Icons.format_size_rounded, size: 20)),
          Expanded(child: LSlider(value: s.size.clamp(.02, .5).toDouble(), min: .02, max: .5, onChanged: (v) => setState(() => s.size = v), onChangeEnd: (_) => _commit())),
          IconButton(icon: const Icon(Icons.delete_outline_rounded), tooltip: L.t('delete'), onPressed: _deleteSel),
        ]),
      ],
    ]);
  }

  Widget _textPanel() {
    final cur = sel;
    final it = (cur != null && !_emoji.contains(cur.text)) ? cur : null;
    final pc = Theme.of(context).colorScheme.primary;
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Row(children: [
        const SizedBox(width: 10),
        FilledButton.tonalIcon(onPressed: () => _addText(), icon: const Icon(Icons.add_rounded), label: Text(L.t('addText'))),
        const Spacer(),
        if (it != null) ...[
          IconButton(icon: const Icon(Icons.edit_rounded), onPressed: () => _addText(it)),
          IconButton(icon: Icon(Icons.format_bold_rounded, color: it.bold ? pc : null), onPressed: () { setState(() => it.bold = !it.bold); _commit(); }),
          IconButton(icon: Icon(Icons.format_color_fill_rounded, color: it.bg ? pc : null), tooltip: L.t('background'), onPressed: () { setState(() => it.bg = !it.bg); _commit(); }),
        ],
        const SizedBox(width: 6),
      ]),
      _dots(it?.color ?? textColor, (c) {
        setState(() {
          textColor = c;
          if (it != null) it.color = c;
        });
        if (it != null) _commit();
      }),
      _itemControls(),
    ]);
  }

  Widget _stickerPanel() => Column(mainAxisSize: MainAxisSize.min, children: [
        SizedBox(
          height: 58,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
            for (final e in _emoji) InkWell(borderRadius: BorderRadius.circular(12), onTap: () => _addEmoji(e), child: Padding(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6), child: Text(e, style: const TextStyle(fontSize: 30)))),
          ]),
        ),
        _itemControls(),
      ]);

  Widget _tabs() {
    final pc = Theme.of(context).colorScheme.primary;
    Widget t(_Tool v, IconData i, String label) {
      final on = tool == v;
      return Expanded(
        child: InkWell(
          onTap: () => setState(() { tool = on ? _Tool.none : v; sel = null; live = null; }),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(i, color: on ? pc : Colors.white70),
              const SizedBox(height: 2),
              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, color: on ? pc : Colors.white60)),
            ]),
          ),
        ),
      );
    }

    return Container(
      color: const Color(0xFF0B0B0B),
      child: SafeArea(
        top: false,
        child: Row(children: [
          t(_Tool.crop, Icons.crop_rounded, L.t('crop')),
          t(_Tool.filters, Icons.auto_awesome_rounded, L.t('filters')),
          t(_Tool.adjust, Icons.tune_rounded, L.t('adjust')),
          t(_Tool.draw, Icons.brush_rounded, L.t('draw')),
          t(_Tool.text, Icons.title_rounded, L.t('text')),
          t(_Tool.sticker, Icons.emoji_emotions_rounded, L.t('stickers')),
        ]),
      ),
    );
  }
}

class _CropOverlay extends StatefulWidget {
  final Rect rect; // normalised
  final double? ratio; // w/h
  final ValueChanged<Rect> onChanged;
  final VoidCallback? onEnd;
  const _CropOverlay({required this.rect, required this.ratio, required this.onChanged, this.onEnd});
  @override
  State<_CropOverlay> createState() => _CropOverlayState();
}

class _CropOverlayState extends State<_CropOverlay> {
  static const hit = 32.0, minSize = 48.0;
  int mode = -1; // 0..3 corners (tl,tr,br,bl), 4 move
  Offset anchor = Offset.zero;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (c, box) {
        final sz = box.biggest;
        Rect px() => Rect.fromLTRB(widget.rect.left * sz.width, widget.rect.top * sz.height, widget.rect.right * sz.width, widget.rect.bottom * sz.height);
        void emit(Rect r) => widget.onChanged(Rect.fromLTRB(r.left / sz.width, r.top / sz.height, r.right / sz.width, r.bottom / sz.height));
        final r = px();
        final corners = [r.topLeft, r.topRight, r.bottomRight, r.bottomLeft];
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onPanStart: (d) {
            mode = -1;
            for (var i = 0; i < 4; i++) {
              if ((corners[i] - d.localPosition).distance < hit) { mode = i; anchor = corners[(i + 2) % 4]; return; }
            }
            if (r.contains(d.localPosition)) mode = 4;
          },
          onPanUpdate: (d) {
            if (mode < 0) return;
            final cur = px();
            if (mode == 4) {
              var dx = d.delta.dx, dy = d.delta.dy;
              dx = dx.clamp(-cur.left, sz.width - cur.right);
              dy = dy.clamp(-cur.top, sz.height - cur.bottom);
              emit(cur.shift(Offset(dx, dy)));
              return;
            }
            final moving = corners[mode] + d.delta;
            final m = Offset(moving.dx.clamp(0.0, sz.width), moving.dy.clamp(0.0, sz.height));
            final sx = m.dx >= anchor.dx ? 1.0 : -1.0, sy = m.dy >= anchor.dy ? 1.0 : -1.0;
            var w = (m.dx - anchor.dx).abs(), h = (m.dy - anchor.dy).abs();
            final rt = widget.ratio;
            if (rt != null) {
              final maxW = sx > 0 ? sz.width - anchor.dx : anchor.dx;
              final maxH = sy > 0 ? sz.height - anchor.dy : anchor.dy;
              w = [w, maxW, maxH * rt].reduce((a, b) => a < b ? a : b);
              if (w < minSize) w = minSize;
              h = w / rt;
            } else {
              if (w < minSize) w = minSize;
              if (h < minSize) h = minSize;
            }
            emit(Rect.fromPoints(anchor, Offset(anchor.dx + sx * w, anchor.dy + sy * h)).intersect(Offset.zero & sz));
          },
          onPanEnd: (_) { if (mode >= 0) widget.onEnd?.call(); mode = -1; },
          child: CustomPaint(size: sz, painter: _CropPainter(r)),
        );
      });
}

class _CropPainter extends CustomPainter {
  final Rect r;
  _CropPainter(this.r);
  @override
  void paint(Canvas canvas, Size size) {
    final dim = Path()
      ..addRect(Offset.zero & size)
      ..addRect(r)
      ..fillType = PathFillType.evenOdd;
    canvas.drawPath(dim, Paint()..color = Colors.black54);
    final line = Paint()..color = Colors.white..style = PaintingStyle.stroke..strokeWidth = 1.5;
    canvas.drawRect(r, line);
    final thin = Paint()..color = Colors.white38..strokeWidth = 1;
    for (var i = 1; i < 3; i++) {
      canvas.drawLine(Offset(r.left + r.width * i / 3, r.top), Offset(r.left + r.width * i / 3, r.bottom), thin);
      canvas.drawLine(Offset(r.left, r.top + r.height * i / 3), Offset(r.right, r.top + r.height * i / 3), thin);
    }
    final hp = Paint()..color = Colors.white;
    for (final c in [r.topLeft, r.topRight, r.bottomRight, r.bottomLeft]) {
      canvas.drawCircle(c, 8, hp);
    }
  }

  @override
  bool shouldRepaint(_CropPainter o) => o.r != r;
}
