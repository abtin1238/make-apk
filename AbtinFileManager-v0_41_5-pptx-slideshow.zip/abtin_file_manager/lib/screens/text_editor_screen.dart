import 'dart:io';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:flutter/services.dart';
import '../services/saf.dart';
import '../services/file_ops.dart';
import 'saf_prompt.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/highlighter.dart';
import '../widgets/ui.dart';
import 'hash_screen.dart';
import 'hex_viewer_screen.dart';
import 'viewer_delete.dart';

/// Text / code file: opens in VIEW mode (read-only, selectable, syntax highlighted).
/// The edit button switches to edit mode; save returns to view mode.
class TextEditorScreen extends StatefulWidget {
  final String path;
  const TextEditorScreen({super.key, required this.path});
  @override
  State<TextEditorScreen> createState() => _TextEditorScreenState();
}

class _TextEditorScreenState extends State<TextEditorScreen> {
  late final CodeController ctl = CodeController(lang: Hl.langOf(widget.path));
  final FocusNode focus = FocusNode();
  bool loaded = false, dirty = false, editing = false;
  double font = 14;

  @override
  void initState() {
    super.initState();
    File(widget.path).readAsString().then((t) { if (mounted) setState(() { ctl.text = t; loaded = true; }); }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  @override
  void dispose() {
    ctl.dispose();
    focus.dispose();
    super.dispose();
  }

  void _push(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w));

  void _startEdit() {
    setState(() => editing = true);
    WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) focus.requestFocus(); });
  }

  void _stopEdit() {
    focus.unfocus();
    setState(() => editing = false);
  }

  Future<void> _save() async {
    if (!await ensureSdAll(context, [widget.path])) return;
    try {
      await Saf.writeString(widget.path, ctl.text);
    } on OpError catch (e) {
      if (mounted) snack(context, L.t(e.key));
      return;
    }
    if (!mounted) return;
    setState(() { dirty = false; editing = false; });
    focus.unfocus();
    snack(context, L.t('done'));
  }

  Future<void> _deleteThis() async {
    if (await deleteFromViewer(context, widget.path) && mounted) {
      dirty = false;
      Navigator.of(context).pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    ctl.dark = Theme.of(context).brightness == Brightness.dark;
    return PopScope(
      canPop: !dirty,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await confirm(context, L.t('discard')) && context.mounted) Navigator.pop(context);
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 16)),
          actions: [
            IconButton(icon: const Icon(Icons.text_decrease_rounded), onPressed: () => setState(() => font = (font - 1).clamp(9, 40))),
            IconButton(icon: const Icon(Icons.text_increase_rounded), onPressed: () => setState(() => font = (font + 1).clamp(9, 40))),
            if (editing) ...[
              IconButton(icon: const Icon(Icons.visibility_rounded), tooltip: L.t('view'), onPressed: _stopEdit),
              IconButton(
                icon: Icon(Icons.save_rounded, color: dirty ? Colors.amber : null),
                tooltip: L.t('save'),
                onPressed: _save,
              ),
            ] else if (loaded)
              IconButton(icon: const Icon(Icons.edit_rounded), tooltip: L.t('edit'), onPressed: _startEdit),
            PopupMenuButton<int>(
              onSelected: (v) {
                if (v == 0) setState(() => ctl.enabled = !ctl.enabled);
                if (v == 1) _push(HexViewerScreen(path: widget.path));
                if (v == 2) _push(HashScreen(path: widget.path));
                if (v == 4) _deleteThis();
                if (v == 3) {
                  Clipboard.setData(ClipboardData(text: ctl.text));
                  snack(context, L.t('done'));
                }
              },
              itemBuilder: (_) => [
                if (ctl.lang.isNotEmpty) CheckedPopupMenuItem(value: 0, checked: ctl.enabled, child: Text(L.t('syntax'))),
                PopupMenuItem(value: 3, child: Text(L.t('copyAll'))),
                PopupMenuItem(value: 1, child: Text(L.t('hex'))),
                PopupMenuItem(value: 2, child: Text(L.t('hash'))),
                PopupMenuItem(value: 4, child: Text(L.t('delete'))),
              ],
            ),
          ],
        ),
        floatingActionButton: (loaded && !editing)
            ? FloatingActionButton.extended(onPressed: _startEdit, icon: const Icon(Icons.edit_rounded), label: Text(L.t('edit')))
            : null,
        body: !loaded
            ? const Center(child: CircularProgressIndicator())
            : TextField(
                controller: ctl,
                focusNode: focus,
                readOnly: !editing,
                showCursor: editing,
                enableInteractiveSelection: true,
                maxLines: null,
                expands: true,
                textAlignVertical: TextAlignVertical.top,
                style: TextStyle(fontFamily: 'monospace', fontSize: font),
                onChanged: (_) { if (!dirty) setState(() => dirty = true); },
                decoration: InputDecoration(
                  border: InputBorder.none,
                  filled: false,
                  contentPadding: EdgeInsets.fromLTRB(12, 12, 12, editing ? 12 : 88),
                ),
              ),
      ),
    );
  }
}
