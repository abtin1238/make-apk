import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdfx/pdfx.dart';
import 'package:share_plus/share_plus.dart';
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../services/pdf_native.dart';
import '../widgets/ui.dart';
import 'pdf_editor_screen.dart';
import 'pdf_form_screen.dart';
import 'pdf_place_screen.dart';
import 'pdf_select_screen.dart';
import 'pdf_stamp_dialog.dart';
import 'viewer_delete.dart';

class PdfViewerScreen extends StatefulWidget {
  final String path;
  const PdfViewerScreen({super.key, required this.path});
  @override
  State<PdfViewerScreen> createState() => _PdfViewerScreenState();
}

class _PdfViewerScreenState extends State<PdfViewerScreen> {
  PdfControllerPinch? _ctl;
  String? _tmp; // decrypted temp copy of a password-protected file
  String? _err;

  PdfControllerPinch get ctl => _ctl!;
  /// the file that is shown and edited (a decrypted temp copy for protected files)
  String get _src => _tmp ?? widget.path;
  String? get _origArg => _tmp == null ? null : widget.path;
  String get _base => p.basenameWithoutExtension(widget.path);
  String get _dir => p.dirname(widget.path);
  int get _n => _ctl?.pagesCount ?? 0;
  int get _page => _ctl?.page ?? 1;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  @override
  void dispose() {
    _ctl?.dispose();
    if (_tmp != null) {
      try { File(_tmp!).deleteSync(); } catch (_) {}
    }
    super.dispose();
  }

  Future<void> _prepare() async {
    try {
      if (await PdfNative.isEncrypted(widget.path)) {
        final tmp = await _unlock();
        if (tmp == null) {
          if (mounted) Navigator.pop(context);
          return;
        }
        _tmp = tmp;
      }
      if (!mounted) return;
      setState(() => _ctl = PdfControllerPinch(document: PdfDocument.openFile(_src)));
    } catch (e) {
      if (mounted) setState(() => _err = '$e');
    }
  }

  /// asks for the password until it is right; returns the path of an unprotected temp copy
  Future<String?> _unlock() async {
    final dir = Directory(p.join((await getTemporaryDirectory()).path, 'pdf_unlock'));
    await dir.create(recursive: true);
    final out = p.join(dir.path, '${DateTime.now().microsecondsSinceEpoch}.pdf');
    while (mounted) {
      final pw = await promptText(context, L.t('pdfPassword'), obscure: true);
      if (pw == null || !mounted) return null;
      if (await PdfNative.decrypt(widget.path, out, pw)) return out;
      if (mounted) snack(context, L.t('pdfWrongPw'));
    }
    return null;
  }

  static String _digits(String s) {
    const fa = '۰۱۲۳۴۵۶۷۸۹', ar = '٠١٢٣٤٥٦٧٨٩';
    final b = StringBuffer();
    for (final r in s.split('')) {
      var i = fa.indexOf(r);
      if (i < 0) i = ar.indexOf(r);
      b.write(i < 0 ? r : '$i');
    }
    return b.toString();
  }

  List<int>? _ranges(String s, int n) {
    final out = <int>{};
    for (final part in _digits(s).split(RegExp(r'[,\s،]+'))) {
      if (part.isEmpty) continue;
      final m = RegExp(r'^(\d*)-(\d*)$').firstMatch(part);
      int a, b;
      if (m != null) {
        a = int.tryParse(m.group(1)!) ?? 1;
        b = int.tryParse(m.group(2)!) ?? n;
      } else {
        final v = int.tryParse(part);
        if (v == null) return null;
        a = b = v;
      }
      if (a < 1 || b > n || a > b) return null;
      for (var i = a; i <= b; i++) {
        out.add(i);
      }
    }
    return out.isEmpty ? null : (out.toList()..sort());
  }

  /// runs [job] (returns the new file) then opens the result
  Future<void> _run(Future<String?> Function() job) async {
    if (!await ensureSdAll(context, [_dir])) return;
    if (!mounted) return;
    String? out;
    final ok = await busy(context, () async {
      out = await job();
    });
    if (!mounted || !ok || out == null) return;
    Native.scan(out!);
    snack(context, L.t('done'));
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => PdfViewerScreen(path: out!)));
  }

  Future<T?> _choose<T>(String title, Map<String, T> opts) => showDialog<T>(
        context: context,
        builder: (dc) => SimpleDialog(title: Text(title), children: [
          for (final e in opts.entries) SimpleDialogOption(onPressed: () => Navigator.pop(dc, e.value), child: Text(e.key)),
        ]),
      );

  Future<void> _search() async {
    final q = await promptText(context, L.t('pdfSearch'));
    if (q == null || q.trim().isEmpty || !mounted) return;
    var res = <Map<String, dynamic>>[];
    final ok = await busy(context, () async {
      res = await PdfNative.search(_src, q.trim());
    });
    if (!ok || !mounted) return;
    if (res.isEmpty) {
      snack(context, L.t('noMatches'));
      return;
    }
    final pg = await showModalBottomSheet<int>(
      context: context,
      builder: (c) => ListView(children: [
        for (final r in res)
          ListTile(
            title: Text('${L.t('page')} ${r['page']}  (${r['count']})'),
            subtitle: Text('${r['snippet']}', maxLines: 2, overflow: TextOverflow.ellipsis),
            onTap: () => Navigator.pop(c, (r['page'] as num).toInt()),
          ),
      ]),
    );
    if (pg != null) ctl.jumpToPage(pg);
  }

  Future<void> _pageText() async {
    var t = '';
    final ok = await busy(context, () async {
      t = await PdfNative.text(_src, _page);
    });
    if (!ok || !mounted) return;
    final rtl = RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(t);
    await showDialog<void>(
      context: context,
      builder: (dc) => AlertDialog(
        title: Text('${L.t('page')} $_page'),
        content: SingleChildScrollView(
          child: SelectableText(t.trim().isEmpty ? L.t('empty') : t, textDirection: rtl ? TextDirection.rtl : TextDirection.ltr),
        ),
        actions: [
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: t));
              snack(dc, L.t('copied'));
            },
            child: Text(L.t('copy')),
          ),
          TextButton(onPressed: () => Navigator.pop(dc), child: Text(L.t('ok'))),
        ],
      ),
    );
  }

  Future<void> _deleteThis() async {
    if (await deleteFromViewer(context, widget.path) && mounted) Navigator.pop(context);
  }

  Future<void> _extract() async {
    final s = await promptText(context, '${L.t('pagesRange')} (1-3, 5, 7-)');
    if (s == null || !mounted) return;
    final pages = _ranges(s, _n);
    if (pages == null) {
      snack(context, L.t('invalidInput'));
      return;
    }
    await _run(() async {
      final out = FileOps.unique(_dir, '$_base (pages).pdf');
      await PdfNative.extract(_src, out, pages);
      return out;
    });
  }

  Future<void> _splitAll() async {
    final dir = FileOps.unique(_dir, '$_base (pages)');
    final n = _n;
    final ok = await busy(context, () async {
      await Directory(dir).create(recursive: true);
      for (var i = 1; i <= n; i++) {
        await PdfNative.extract(_src, p.join(dir, '${_base}_$i.pdf'), [i]);
      }
    });
    if (ok && mounted) snack(context, '${L.t('done')}: ${p.basename(dir)}');
  }

  Future<void> _merge() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true, type: FileType.custom, allowedExtensions: ['pdf']);
    final more = r?.files.map((f) => f.path).whereType<String>().toList() ?? [];
    if (more.isEmpty || !mounted) return;
    await _run(() async {
      final out = FileOps.unique(_dir, '$_base (merged).pdf');
      await PdfNative.merge([_src, ...more], out);
      return out;
    });
  }

  Future<void> _rotate() async {
    final c = await _choose<(bool, int)>(L.t('rotatePage'), {
      L.t('rotPageCW'): (false, 90),
      L.t('rotPageCCW'): (false, -90),
      L.t('rotAllCW'): (true, 90),
      L.t('rotAllCCW'): (true, -90),
      L.t('rot180'): (true, 180),
    });
    if (c == null || !mounted) return;
    final pg = _page;
    await _run(() async {
      final out = FileOps.unique(_dir, '$_base (rotated).pdf');
      await PdfNative.rotate(_src, out, c.$1 ? [] : [pg], c.$2);
      return out;
    });
  }

  Future<void> _form() async {
    final out = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => PdfFormScreen(path: _src, origPath: _origArg)));
    if (out == null || !mounted) return;
    Native.scan(out);
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => PdfViewerScreen(path: out)));
  }

  Future<void> _stamp() async {
    final spec = await showStampDialog(context);
    if (spec == null || !mounted) return;
    final pg = _page;
    final pos = await Navigator.push<PlaceResult>(
      context,
      MaterialPageRoute(builder: (_) => PdfPlaceScreen(path: _src, page: pg, stamp: spec.png, anchor: spec.anchor, width: spec.w)),
    );
    if (pos == null || !mounted) return;
    await _run(() async {
      final out = FileOps.unique(_dir, '$_base (signed).pdf');
      await PdfNative.stampAt(_src, out, pg, pos.x, pos.y, pos.w, spec.png);
      return out;
    });
  }

  Future<void> _selectText() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => PdfSelectScreen(path: _src, page: _page, origPath: _origArg)));
  }

  Future<void> _protect() async {
    final a = await promptText(context, L.t('pdfSetPassword'), obscure: true);
    if (a == null || a.isEmpty || !mounted) return;
    final b = await promptText(context, L.t('vaultPwConfirm'), obscure: true);
    if (b == null || !mounted) return;
    if (a != b) {
      snack(context, L.t('vaultPwMismatch'));
      return;
    }
    await _run(() async {
      final out = FileOps.unique(_dir, '$_base (protected).pdf');
      await PdfNative.encrypt(_src, out, a);
      return out;
    });
  }

  Future<void> _saveUnlocked() async {
    await _run(() async {
      final out = FileOps.unique(_dir, '$_base (unlocked).pdf');
      await Saf.copyTo(_src, out); // _src is already the decrypted copy
      return out;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_ctl == null) {
      return Scaffold(
        appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15))),
        body: Center(child: _err == null ? const CircularProgressIndicator() : Padding(padding: const EdgeInsets.all(24), child: Text(_err!))),
      );
    }
    return Scaffold(
        appBar: AppBar(
          title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)),
          actions: [
            PdfPageNumber(
              controller: ctl,
              builder: (_, state, page, count) => Center(child: Text('$page / ${count ?? '-'}')),
            ),
            IconButton(icon: const Icon(Icons.search_rounded), tooltip: L.t('pdfSearch'), onPressed: _search),
            IconButton(
              icon: const Icon(Icons.pin_rounded),
              tooltip: L.t('page'),
              onPressed: () async {
                final n = int.tryParse(_digits(await promptText(context, L.t('page')) ?? ''));
                if (n != null) ctl.jumpToPage(n);
              },
            ),
            IconButton(
              icon: const Icon(Icons.edit_rounded),
              tooltip: L.t('edit'),
              onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => PdfEditorScreen(path: _src, origPath: _origArg))),
            ),
            PopupMenuButton<String>(
              tooltip: L.t('pdfTools'),
              onSelected: (v) {
                switch (v) {
                  case 'select': _selectText(); break;
                  case 'text': _pageText(); break;
                  case 'protect': _protect(); break;
                  case 'unlock': _saveUnlocked(); break;
                  case 'extract': _extract(); break;
                  case 'split': _splitAll(); break;
                  case 'merge': _merge(); break;
                  case 'rotate': _rotate(); break;
                  case 'form': _form(); break;
                  case 'stamp': _stamp(); break;
                  case 'share': Share.shareXFiles([XFile(widget.path)]); break;
                  case 'delete': _deleteThis(); break;
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(value: 'select', child: Text(L.t('selectText'))),
                PopupMenuItem(value: 'text', child: Text(L.t('pageText'))),
                PopupMenuItem(value: 'form', child: Text(L.t('fillForm'))),
                PopupMenuItem(value: 'stamp', child: Text(L.t('signStamp'))),
                PopupMenuItem(value: 'rotate', child: Text(L.t('rotatePage'))),
                PopupMenuItem(value: 'extract', child: Text(L.t('extractPages'))),
                PopupMenuItem(value: 'split', child: Text(L.t('splitAll'))),
                PopupMenuItem(value: 'merge', child: Text(L.t('mergePdf'))),
                if (_tmp == null) PopupMenuItem(value: 'protect', child: Text(L.t('pdfSetPassword'))) else PopupMenuItem(value: 'unlock', child: Text(L.t('pdfRemovePassword'))),
                PopupMenuItem(value: 'share', child: Text(L.t('share'))),
                PopupMenuItem(value: 'delete', child: Text(L.t('delete'))),
              ],
            ),
          ],
        ),
        body: PdfViewPinch(
          controller: ctl,
          builders: PdfViewPinchBuilders<DefaultBuilderOptions>(
            options: const DefaultBuilderOptions(),
            documentLoaderBuilder: (_) => const Center(child: CircularProgressIndicator()),
            pageLoaderBuilder: (_) => const Center(child: CircularProgressIndicator()),
            errorBuilder: (_, e) => Center(child: Text('$e')),
          ),
        ),
      );
  }
}
