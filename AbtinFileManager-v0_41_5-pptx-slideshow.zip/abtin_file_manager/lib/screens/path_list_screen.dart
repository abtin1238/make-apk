import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import '../core/settings.dart';
import '../services/file_ops.dart';
import '../widgets/ui.dart';
import 'browser_screen.dart';
import 'opener.dart';

class PathListScreen extends StatelessWidget {
  final String title;
  final bool fav;
  const PathListScreen({super.key, required this.title, required this.fav});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final list = (fav ? s.favorites : s.recents).where((e) => FileSystemEntity.typeSync(e) != FileSystemEntityType.notFound).toList();
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView.builder(
        itemCount: list.length,
        itemBuilder: (c, i) {
          final dir = FileSystemEntity.isDirectorySync(list[i]);
          return ListTile(
            leading: TypeIcon(list[i], dir, size: 34),
            title: Text(p.basename(list[i]), maxLines: 1, overflow: TextOverflow.ellipsis),
            subtitle: Text(p.dirname(list[i]), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
            onTap: () => dir
                ? Navigator.push(context, MaterialPageRoute(builder: (_) => BrowserScreen(initialPath: list[i])))
                : Opener.open(context, list[i], siblings: list),
          );
        },
      ),
    );
  }
}
