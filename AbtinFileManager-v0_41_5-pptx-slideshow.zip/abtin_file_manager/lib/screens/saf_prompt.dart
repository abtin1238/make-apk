import 'package:flutter/material.dart';
import '../core/l10n.dart';
import '../services/saf.dart';
import '../widgets/ui.dart';

/// Makes sure every SD card touched by [paths] can be written to, asking the
/// user for access (system folder picker) when necessary. false = abort the operation.
Future<bool> ensureSdAll(BuildContext context, Iterable<String> paths) async {
  final done = <String>{};
  for (final path in paths) {
    final u = Saf.volumeOf(path);
    if (u == null || !done.add(u)) continue;
    if (!await Saf.needsSaf(path)) continue;
    if (await Saf.has(u)) continue;
    if (!context.mounted) return false;
    final go = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(L.t('safTitle')),
        content: Text(L.t('safMsg')),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(context, false)),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(L.t('safContinue'))),
        ],
      ),
    );
    if (go != true) return false;
    final ok = await Saf.request(u);
    if (!ok) {
      if (context.mounted) snack(context, L.t('safWrong'));
      return false;
    }
  }
  return true;
}

/// Settings entry: grant or revoke SD card access for [rootPath] (`/storage/XXXX-XXXX`).
Future<void> manageSdAccess(BuildContext context, String rootPath) async {
  final u = Saf.volumeOf(rootPath);
  if (u == null) return;
  if (await Saf.has(u)) {
    if (!context.mounted) return;
    if (await confirm(context, L.t('sdRevokeAsk'))) await Saf.revoke(u);
  } else {
    await ensureSdAll(context, [rootPath]);
  }
}
