import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:provider/provider.dart';
import '../core/layouts.dart';
import '../core/settings.dart';
import '../widgets/ui.dart';

/// Pick the app's STRUCTURE (navigation, home screen, list density) – each card shows a tiny wireframe.
class LayoutStyleScreen extends StatelessWidget {
  const LayoutStyleScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(tr2('چیدمان و ساختار برنامه', 'App layout'))),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: Text(
            tr2('هر چیدمان کل ساختار برنامه را عوض می‌کند: نوع ناوبری، شکل صفحهٔ خانه و حالت نمایش فایل‌ها. رنگ‌ها جدا از «رنگ‌بندی (تم)» انتخاب می‌شوند و با همهٔ چیدمان‌ها کار می‌کنند.',
                'Each layout changes the whole structure of the app: navigation, home screen and the way files are listed. Colours are chosen separately (Color theme) and work with every layout.'),
            style: TextStyle(fontSize: 12.5, color: Theme.of(context).hintColor, height: 1.5),
          ),
        ),
        for (final l in appLayouts)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: l.id == s.layoutId ? cs.primary : Colors.transparent, width: 2),
              ),
              child: GradCard(
                onTap: () {
                  s.setLayout(l.id);
                  snack(context, '${l.name} ✓');
                },
                child: Row(children: [
                  SizedBox(
                    width: 84,
                    height: 140,
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: Theme.of(context).scaffoldBackgroundColor,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: Theme.of(context).hintColor.withOpacity(.5), width: 1.5),
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: CustomPaint(painter: _WirePainter(l.id, Theme.of(context).colorScheme.onSurface, cs.primary)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Icon(l.icon, size: 20, color: cs.primary),
                        const SizedBox(width: 8),
                        Expanded(child: Text(l.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold))),
                        if (l.id == s.layoutId) Icon(Icons.check_circle_rounded, color: cs.primary),
                      ]),
                      const SizedBox(height: 8),
                      Text(l.desc, style: const TextStyle(fontSize: 12.5, height: 1.5)),
                    ]),
                  ),
                ]),
              ),
            ),
          ),
      ]),
    );
  }
}

/// Tiny wireframe of each layout (84 × 140).
class _WirePainter extends CustomPainter {
  final String id;
  final Color fg, accent;
  _WirePainter(this.id, this.fg, this.accent);

  @override
  void paint(Canvas c, Size s) {
    final w = s.width, h = s.height;
    final soft = Paint()..color = fg.withOpacity(.14);
    final line = Paint()..color = fg.withOpacity(.32);
    final acc = Paint()..color = accent;
    final accSoft = Paint()..color = accent.withOpacity(.30);
    final white = Paint()..color = Colors.white.withOpacity(.75);

    void box(Paint p, double l, double t, double r, double b, [double rad = 4]) =>
        c.drawRRect(RRect.fromLTRBR(w * l, h * t, w * r, h * b, Radius.circular(rad)), p);
    void dot(Paint p, double x, double y, double r) => c.drawCircle(Offset(w * x, h * y), r, p);

    switch (id) {
      case 'drawer':
        // hamburger + title
        for (var i = 0; i < 3; i++) {
          box(line, .08, .05 + i * .02, .22, .062 + i * .02, 1);
        }
        box(line, .30, .06, .60, .085, 2);
        // dimmed content behind
        for (var i = 0; i < 6; i++) {
          box(soft, .10, .20 + i * .11, .90, .26 + i * .11);
        }
        // the open side menu
        c.drawRect(Rect.fromLTWH(0, 0, w * .66, h), Paint()..color = accent.withOpacity(.16));
        box(acc, .06, .05, .60, .20, 8);
        box(accSoft, .06, .26, .60, .34, 5);
        for (var i = 0; i < 6; i++) {
          box(line, .10, .40 + i * .09, .52, .44 + i * .09, 2);
        }
        break;
      case 'dashboard':
        box(acc, .08, .05, .92, .30, 10);
        dot(white, .27, .175, w * .10);
        box(white, .46, .11, .84, .14, 2);
        box(white, .46, .17, .70, .20, 2);
        for (var i = 0; i < 3; i++) {
          box(soft, .08 + i * .29, .34, .32 + i * .29, .40, 8);
        }
        for (var i = 0; i < 4; i++) {
          box(soft, .08 + i * .22, .45, .26 + i * .22, .55, 5);
        }
        for (var r = 0; r < 2; r++) {
          box(soft, .08, .60 + r * .11, .47, .68 + r * .11, 6);
          box(soft, .53, .60 + r * .11, .92, .68 + r * .11, 6);
        }
        box(soft, .10, .87, .90, .96, 12);
        box(accSoft, .14, .89, .44, .94, 10);
        dot(line, .60, .915, 3);
        dot(line, .78, .915, 3);
        break;
      case 'rail':
        c.drawRect(Rect.fromLTWH(0, 0, w * .17, h), soft);
        box(acc, .035, .04, .135, .10, 4);
        for (var i = 0; i < 4; i++) {
          dot(i == 0 ? acc : line, .085, .20 + i * .09, 3.4);
        }
        for (var i = 0; i < 10; i++) {
          final head = i == 0 || i == 5;
          if (head) {
            box(accSoft, .24, .06 + i * .088, .62, .09 + i * .088, 2);
          } else {
            box(soft, .24, .06 + i * .088, .92, .102 + i * .088, 2);
          }
        }
        break;
      case 'tabs':
        c.drawRect(Rect.fromLTWH(0, 0, w, h * .13), soft);
        for (var i = 0; i < 4; i++) {
          dot(i == 0 ? acc : line, .14 + i * .24, .05, 3.2);
        }
        box(acc, .06, .115, .28, .13, 1);
        box(soft, .08, .17, .92, .24, 12);
        for (var r = 0; r < 3; r++) {
          for (var col = 0; col < 4; col++) {
            dot(col + r == 0 ? accSoft : soft, .16 + col * .225, .36 + r * .17, w * .075);
          }
        }
        break;
      default: // classic
        box(line, .08, .05, .50, .085, 2);
        box(soft, .08, .12, .92, .25, 8);
        for (var r = 0; r < 3; r++) {
          for (var col = 0; col < 3; col++) {
            box(soft, .08 + col * .30, .29 + r * .17, .32 + col * .30, .42 + r * .17, 5);
          }
        }
        c.drawRect(Rect.fromLTWH(0, h * .89, w, h * .11), soft);
        for (var i = 0; i < 4; i++) {
          dot(i == 0 ? acc : line, .14 + i * .24, .945, 3.2);
        }
        break;
    }
  }

  @override
  bool shouldRepaint(covariant _WirePainter old) => old.id != id || old.fg != fg || old.accent != accent;
}
