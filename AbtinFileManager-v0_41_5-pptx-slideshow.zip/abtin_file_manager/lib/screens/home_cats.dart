import 'package:flutter/material.dart';
import '../core/l10n.dart';
import '../core/theme.dart';
import '../services/file_ops.dart';
import 'apps_screen.dart';
import 'browser_screen.dart';
import 'category_screen.dart';
import 'ext_screen.dart';
import 'media_screen.dart';
import 'music_library_screen.dart';
import 'path_list_screen.dart';
import 'photo_albums_screen.dart';
import 'trash_screen.dart';

/// One shortcut of the home screen (also used by the drawer / launcher / dashboard layouts).
class HomeCat {
  final IconData icon;
  final String key; // L.t key
  final Color color;
  final Widget page;
  const HomeCat(this.icon, this.key, this.color, this.page);
}

List<HomeCat> homeCats() => [
      HomeCat(Icons.article_rounded, 'word', const Color(0xFF2B7CD3), ExtScreen(title: L.t('word'), exts: const {'docx', 'docm', 'dotx', 'dotm', 'doc'})),
      HomeCat(Icons.picture_as_pdf_rounded, 'pdf', const Color(0xFFFF5C7A), ExtScreen(title: L.t('pdf'), exts: const {'pdf'})),
      HomeCat(Icons.text_snippet_rounded, 'text', Colors.blueGrey, ExtScreen(title: L.t('text'), exts: FileOps.textExts)),
      const HomeCat(Icons.image_rounded, 'images', Color(0xFF2ECC71), PhotoAlbumsScreen()),
      const HomeCat(Icons.perm_media_rounded, 'media', AppColors.purple, MediaScreen()),
      const HomeCat(Icons.play_circle_rounded, 'videos', AppColors.purple, CategoryScreen(cat: Cat.videos)),
      const HomeCat(Icons.music_note_rounded, 'music', AppColors.gold, MusicLibraryScreen()),
      const HomeCat(Icons.description_rounded, 'docs', Color(0xFFFF5C7A), CategoryScreen(cat: Cat.docs)),
      const HomeCat(Icons.android_rounded, 'apps', Color(0xFF3DDC84), AppsScreen()),
      const HomeCat(Icons.archive_rounded, 'archives', Color(0xFFFF9F43), CategoryScreen(cat: Cat.archives)),
      const HomeCat(Icons.download_rounded, 'downloads', AppColors.blue, BrowserScreen(initialPath: FileOps.downloads)),
      HomeCat(Icons.star_rounded, 'favorites', Colors.amber, PathListScreen(title: L.t('favorites'), fav: true)),
      HomeCat(Icons.history_rounded, 'recents', Colors.cyan, PathListScreen(title: L.t('recents'), fav: false)),
      const HomeCat(Icons.delete_rounded, 'trash', Colors.blueGrey, TrashScreen()),
    ];

HomeCat? homeCat(List<HomeCat> all, String key) {
  for (final c in all) {
    if (c.key == key) return c;
  }
  return null;
}
