import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../services/file_ops.dart';
import '../services/media_events.dart';
import '../services/trash_service.dart';
import '../widgets/ui.dart';
import 'saf_prompt.dart';

/// Deletes the file that is currently open in a viewer / player (image, video, audio, pdf, text …).
/// Uses the same rules as the file browser: confirmation (if enabled), recycle bin (if enabled, with Undo),
/// SD-card access prompt. Returns true when the file is gone, so the caller can close / skip to the next item.
Future<bool> deleteFromViewer(BuildContext context, String path) async {
  final st = context.read<AppSettings>();
  final messenger = ScaffoldMessenger.maybeOf(context);
  if (!await ensureSdAll(context, [path])) return false;
  if (!context.mounted) return false;
  final useTrash = st.trashEnabled && !TrashService.isInTrash(path);
  if (st.confirmDelete) {
    final msg = useTrash ? '${L.t('moveToTrash')}?' : '${L.t('deletePermanent')}?';
    if (!await confirm(context, msg)) return false;
  }
  if (!context.mounted) return false;
  TrashEntry? entry;
  final ok = await busy(context, () async {
    if (useTrash) {
      try {
        entry = await TrashService.moveToTrash(File(path));
        return;
      } on OpError catch (x) {
        if (x.key != 'trashFail') rethrow;
        // trash not possible on this volume → fall through to a permanent delete
      }
    }
    await FileOps.delete(File(path));
  });
  if (!ok) return false;
  st.removePath(path);
  MediaEvents.deleted([path]);
  final e = entry;
  if (e != null && messenger != null) {
    messenger.hideCurrentSnackBar();
    messenger.showSnackBar(SnackBar(
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 8),
      content: Text(L.t('movedToTrash')),
      action: SnackBarAction(
        label: L.t('undo'),
        onPressed: () async {
          try {
            await TrashService.restore(e);
            MediaEvents.restored(e.orig);
          } catch (_) {}
        },
      ),
    ));
  }
  return true;
}
