import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:path/path.dart' as p;
import 'package:open_filex/open_filex.dart';
import '../core/l10n.dart';
import '../services/doc_legacy.dart';
import '../services/sec_native.dart';
import '../services/file_ops.dart';
import '../widgets/ui.dart';
import 'docx_editor_screen.dart';

/// Opens a legacy binary .doc inside the app: text is extracted, can be edited,
/// and "Save" writes a new .docx next to the original (the .doc itself is never altered).
class DocLegacyScreen extends StatefulWidget {
  final String path;
  const DocLegacyScreen({super.key, required this.path});
  @override
  State<DocLegacyScreen> createState() => _DocLegacyScreenState();
}

class _DocLegacyScreenState extends State<DocLegacyScreen> {
  final ctl = TextEditingController();
  bool loading = true, dirty = false, edit = false;
  List<DocPara>? paras;
  final Map<int, int> headingLevels = {};
  String? _openedPassword;
  bool _openedProtected = false;
  double font = 16;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      var bytes = await File(widget.path).readAsBytes();
      if (DocLegacy.isProtected(bytes)) {
        Uint8List? clear;
        for (var attempt = 0; attempt < 3 && clear == null; attempt++) {
          final pw =
              await promptText(context, L.t('docPassword'), obscure: true);
          if (pw == null) {
            if (mounted) Navigator.pop(context);
            return;
          }
          clear = await Sec.docDecrypt(bytes, pw);
          if (clear != null) {
            _openedPassword = pw;
            _openedProtected = true;
          }
          if (clear == null && mounted) snack(context, L.t('wrongPassword'));
        }
        if (clear == null) {
          if (mounted) Navigator.pop(context);
          return;
        }
        bytes = clear;
      }
      try {
        paras = DocLegacy.extractFormatted(bytes);
        if (paras!.isEmpty) paras = null;
      } catch (_) {
        paras = null;
      }
      ctl.text = paras != null
          ? paras!.map((e) => e.text).join('\n')
          : DocLegacy.extractText(bytes);
      headingLevels.clear();
      if (paras != null) {
        for (var i = 0; i < paras!.length; i++) {
          if (paras![i].heading > 0) headingLevels[i] = paras![i].heading;
        }
      }
      edit = paras == null;
      if (mounted) setState(() => loading = false);
    } catch (e) {
      if (!mounted) return;
      snack(context, '${L.t('error')}: $e');
      await OpenFilex.open(widget.path); // fall back to another app
      if (mounted) Navigator.pop(context);
    }
  }

  TextDirection get _dir =>
      RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(ctl.text)
          ? TextDirection.rtl
          : TextDirection.ltr;

  Future<void> _saveDocx() async {
    if (!await ensureSdAll(context, [widget.path])) return;
    if (!mounted) return;
    String? target;
    final ok = await busy(context, () async {
      target = FileOps.unique(p.dirname(widget.path),
          '${p.basenameWithoutExtension(widget.path)}.docx');
      await Saf.writeBytes(
          target!,
          edit || paras == null
              ? DocLegacy.buildDocx(ctl.text, headingLevels: headingLevels)
              : DocLegacy.buildDocxFormatted(paras!));
    });
    if (ok && mounted && target != null) {
      setState(() => dirty = false);
      snack(context, '${L.t('done')}: ${p.basename(target!)}');
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => DocxEditorScreen(path: target!)));
    }
  }

  int get _cursorLine {
    final at = ctl.selection.isValid
        ? ctl.selection.baseOffset.clamp(0, ctl.text.length).toInt()
        : ctl.text.length;
    return '\n'.allMatches(ctl.text.substring(0, at)).length;
  }

  void _setHeading(int level) {
    final line = _cursorLine;
    setState(() {
      if (level == 0) {
        headingLevels.remove(line);
      } else {
        headingLevels[line] = level;
      }
      dirty = true;
    });
    snack(context,
        level == 0 ? L.t('docNormalStyle') : '${L.t('docHeading')} $level');
  }

  Future<void> _insertTable() async {
    final rows = TextEditingController(text: '3'),
        cols = TextEditingController(text: '3');
    final ok = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
              title: Text(L.t('insertTable')),
              content: Column(mainAxisSize: MainAxisSize.min, children: [
                TextField(
                    controller: rows,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: L.t('rows'))),
                const SizedBox(height: 8),
                TextField(
                    controller: cols,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(labelText: L.t('cols'))),
              ]),
              actions: [
                CancelButton(onPressed: () => Navigator.pop(c, false)),
                FilledButton(
                    onPressed: () => Navigator.pop(c, true),
                    child: Text(L.t('ok')))
              ],
            ));
    if (ok != true || !mounted) return;
    final r = (int.tryParse(rows.text) ?? 3).clamp(1, 30).toInt();
    final colCount = (int.tryParse(cols.text) ?? 3).clamp(1, 12).toInt();
    final at = ctl.selection.isValid
        ? ctl.selection.start.clamp(0, ctl.text.length).toInt()
        : ctl.text.length;
    final start = ctl.text.lastIndexOf('\n', at > 0 ? at - 1 : 0) + 1;
    final end0 = ctl.text.indexOf('\n', at);
    final end = end0 < 0 ? ctl.text.length : end0;
    final table = List.generate(r, (_) => List.filled(colCount, '').join('\t'))
        .join('\n');
    final text = ctl.text.replaceRange(start, end, table);
    ctl.value = TextEditingValue(
        text: text,
        selection: TextSelection.collapsed(offset: start + table.length));
    if (mounted)
      setState(() {
        dirty = true;
        edit = true;
      });
  }

  Future<void> _saveDoc({bool protect = false}) async {
    if (!await ensureSdAll(context, [widget.path])) return;
    if (!await confirm(context, L.t('docOverwriteWarning'))) return;
    var payload = DocLegacy.buildRtf(ctl.text, headingLevels: headingLevels);
    String? pw = _openedProtected ? _openedPassword : null;
    if (protect) {
      pw = await promptText(context, L.t('docNewPassword'), obscure: true);
      if (pw == null) return;
      if (pw.length < 4) {
        snack(context, L.t('docPasswordShort'));
        return;
      }
      final again =
          await promptText(context, L.t('docConfirmPassword'), obscure: true);
      if (again != pw) {
        snack(context, L.t('docPasswordMismatch'));
        return;
      }
    }
    if (pw != null) payload = await Sec.docEncrypt(payload, pw);
    final ok =
        await busy(context, () async => Saf.writeBytes(widget.path, payload));
    if (ok && mounted) {
      _openedProtected = pw != null;
      _openedPassword = pw;
      setState(() => dirty = false);
      snack(context, L.t(pw == null ? 'docSaved' : 'docSavedProtected'));
    }
  }

  Widget _paraView(DocPara p) {
    final align = switch (p.jc) {
      1 => TextAlign.center,
      2 => TextAlign.end,
      3 => TextAlign.justify,
      _ => TextAlign.start
    };
    return Directionality(
      textDirection: p.rtl ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: SelectableText.rich(
          TextSpan(children: [
            for (final r in p.runs)
              TextSpan(
                text: r.text,
                style: TextStyle(
                  fontWeight: r.b ? FontWeight.bold : null,
                  fontStyle: r.i ? FontStyle.italic : null,
                  decoration: r.u ? TextDecoration.underline : null,
                  fontSize: r.sz > 0 ? r.sz / 2 * (font / 12) : font,
                  color: r.color != null ? Color(0xFF000000 | r.color!) : null,
                ),
              ),
            if (p.runs.isEmpty) const TextSpan(text: ' '),
          ], style: TextStyle(fontSize: font)),
          textAlign: align,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => PopScope(
        canPop: !dirty,
        onPopInvokedWithResult: (did, _) async {
          if (did) return;
          if (await confirm(context, '${L.t('docSaveSame')}?') && mounted) {
            await _saveDoc();
          } else if (mounted) {
            Navigator.pop(context);
          }
        },
        child: Scaffold(
          appBar: AppBar(
            title: Text(p.basename(widget.path),
                style: const TextStyle(fontSize: 15)),
            actions: [
              IconButton(
                  icon: const Icon(Icons.text_decrease_rounded),
                  onPressed: () =>
                      setState(() => font = (font - 1).clamp(10, 36))),
              IconButton(
                  icon: const Icon(Icons.text_increase_rounded),
                  onPressed: () =>
                      setState(() => font = (font + 1).clamp(10, 36))),
              if (paras != null)
                IconButton(
                  icon: Icon(
                      edit ? Icons.visibility_rounded : Icons.edit_rounded),
                  tooltip: edit ? L.t('formatted') : L.t('editPlain'),
                  onPressed: () async {
                    if (!edit && !await confirm(context, L.t('editPlainWarn')))
                      return;
                    setState(() => edit = !edit);
                  },
                ),
              IconButton(
                  icon: const Icon(Icons.open_in_new_rounded),
                  tooltip: L.t('openWith'),
                  onPressed: () => OpenFilex.open(widget.path)),
              PopupMenuButton<int>(
                tooltip: L.t('docHeading'),
                icon: const Icon(Icons.title_rounded),
                onSelected: _setHeading,
                itemBuilder: (_) => [
                  PopupMenuItem(value: 0, child: Text(L.t('docNormalStyle'))),
                  for (var i = 1; i <= 3; i++)
                    PopupMenuItem(
                        value: i, child: Text('${L.t('docHeading')} $i')),
                ],
              ),
              PopupMenuButton<String>(
                icon: Icon(Icons.save_rounded,
                    color: dirty ? Colors.amber : null),
                tooltip: L.t('save'),
                onSelected: (v) {
                  if (v == 'table') _insertTable();
                  if (v == 'doc') _saveDoc();
                  if (v == 'protected') _saveDoc(protect: true);
                  if (v == 'docx') _saveDocx();
                },
                itemBuilder: (_) => [
                  PopupMenuItem(
                      value: 'table', child: Text(L.t('insertTable'))),
                  PopupMenuItem(value: 'doc', child: Text(L.t('docSaveSame'))),
                  PopupMenuItem(
                      value: 'protected', child: Text(L.t('docSaveProtected'))),
                  PopupMenuItem(value: 'docx', child: Text(L.t('saveAsDocx'))),
                ],
              ),
            ],
          ),
          body: loading
              ? const Center(child: CircularProgressIndicator())
              : Column(children: [
                  Container(
                    width: double.infinity,
                    color: Colors.amber.withOpacity(.15),
                    padding: const EdgeInsets.all(8),
                    child: Text(L.t('legacyDocNote'),
                        style: const TextStyle(fontSize: 12)),
                  ),
                  Expanded(
                    child: !edit && paras != null
                        ? ListView.builder(
                            padding: const EdgeInsets.all(14),
                            itemCount: paras!.length,
                            itemBuilder: (_, i) => _paraView(paras![i]),
                          )
                        : TextField(
                            controller: ctl,
                            maxLines: null,
                            expands: true,
                            textDirection: _dir,
                            textAlignVertical: TextAlignVertical.top,
                            style: TextStyle(fontSize: font),
                            onChanged: (_) {
                              if (!dirty) setState(() => dirty = true);
                            },
                            decoration: const InputDecoration(
                                border: InputBorder.none,
                                contentPadding: EdgeInsets.all(12)),
                          ),
                  ),
                ]),
        ),
      );
}
