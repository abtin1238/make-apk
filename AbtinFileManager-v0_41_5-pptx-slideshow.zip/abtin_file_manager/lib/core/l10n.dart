import 'dart:convert';
import 'package:flutter/services.dart';

/// Translations live in ARB files: assets/l10n/app_<lang>.arb (flat key -> text).
/// To add a language, copy app_en.arb to app_<code>.arb, translate the values and set
/// "@@language_name"; it shows up in Settings automatically. Missing keys fall back to English.
class L {
  static String lang = 'fa';
  static const rtlLangs = {'fa', 'ar', 'he', 'ur', 'ps', 'ku', 'ckb', 'sd', 'yi'};
  static bool get rtl => rtlLangs.contains(lang);

  static final Map<String, Map<String, String>> _m = {};
  static final Map<String, String> _names = {};

  static List<String> get langs => _m.keys.toList()..sort();
  static String nameOf(String code) => _names[code] ?? code;

  /// Loads every assets/l10n/app_*.arb that is bundled with the app.
  static Future<void> init() async {
    final manifest = await AssetManifest.loadFromAssetBundle(rootBundle);
    for (final a in manifest.listAssets()) {
      final m = RegExp(r'assets/l10n/app_([A-Za-z_]+)\.arb$').firstMatch(a);
      if (m == null) continue;
      add(m[1]!, await rootBundle.loadString(a));
    }
    if (!_m.containsKey('en')) add('en', await rootBundle.loadString('assets/l10n/app_en.arb'));
  }

  /// Registers one ARB document (also used by tests).
  static void add(String code, String arbJson) {
    final j = jsonDecode(arbJson) as Map<String, dynamic>;
    final out = <String, String>{};
    j.forEach((k, v) {
      if (k == '@@language_name') {
        _names[code] = '$v';
      } else if (!k.startsWith('@') && v is String) {
        out[k] = v;
      }
    });
    _m[code] = out;
  }

  /// Sets the language when it is available, otherwise English.
  static void use(String code) => lang = _m.containsKey(code) ? code : 'en';

  static String t(String k) => _m[lang]?[k] ?? _m['en']?[k] ?? k;

  /// Text with {name} placeholders, e.g. L.tr('hello', {'name': 'Ali'}).
  static String tr(String k, Map<String, Object> args) {
    var s = t(k);
    args.forEach((a, v) => s = s.replaceAll('{$a}', '$v'));
    return s;
  }

  static bool has(String code, String k) => _m[code]?.containsKey(k) ?? false;
}
