import 'package:flutter/material.dart';
import 'color_spec.dart';
import 'l10n.dart';
import 'theme.dart';

/// One icon of the Abtin icon sheet (gradient icon set).
class PackIcon {
  final IconData icon;
  final String fa, en;
  const PackIcon(this.icon, this.fa, this.en);
  String get name => L.lang == 'fa' ? fa : en;
}

/// The Abtin icon sheet: 7 rows x 9 icons, in the same order as the design sheet.
/// Every icon of the sheet can be recoloured on its own (solid or gradient), the change applies everywhere
/// the icon is used in the app.
const List<PackIcon> iconPack = [
  // row 1
  PackIcon(Icons.home_rounded, 'خانه', 'Home'),
  PackIcon(Icons.search_rounded, 'جست‌وجو', 'Search'),
  PackIcon(Icons.arrow_back_rounded, 'بازگشت', 'Back'),
  PackIcon(Icons.arrow_forward_rounded, 'بعدی', 'Forward'),
  PackIcon(Icons.sync_rounded, 'همگام‌سازی', 'Sync'),
  PackIcon(Icons.settings_rounded, 'تنظیمات', 'Settings'),
  PackIcon(Icons.star_rounded, 'ستاره', 'Star'),
  PackIcon(Icons.favorite_rounded, 'علاقه‌مندی', 'Favourite'),
  PackIcon(Icons.info_rounded, 'اطلاعات', 'Info'),
  // row 2
  PackIcon(Icons.create_new_folder_rounded, 'پوشهٔ جدید', 'New folder'),
  PackIcon(Icons.manage_history_rounded, 'پوشهٔ اخیر', 'Recent folder'),
  PackIcon(Icons.delete_rounded, 'زباله‌دان', 'Trash'),
  PackIcon(Icons.download_rounded, 'دانلود', 'Download'),
  PackIcon(Icons.upload_rounded, 'آپلود', 'Upload'),
  PackIcon(Icons.share_rounded, 'اشتراک‌گذاری', 'Share'),
  PackIcon(Icons.link_rounded, 'پیوند', 'Link'),
  PackIcon(Icons.filter_alt_rounded, 'فیلتر', 'Filter'),
  PackIcon(Icons.sort_rounded, 'مرتب‌سازی', 'Sort'),
  // row 3
  PackIcon(Icons.play_arrow_rounded, 'پخش', 'Play'),
  PackIcon(Icons.pause_rounded, 'توقف موقت', 'Pause'),
  PackIcon(Icons.stop_rounded, 'توقف', 'Stop'),
  PackIcon(Icons.fast_forward_rounded, 'جلو', 'Fast forward'),
  PackIcon(Icons.skip_previous_rounded, 'قبلی', 'Previous'),
  PackIcon(Icons.headphones_rounded, 'هدفون', 'Headphones'),
  PackIcon(Icons.music_note_rounded, 'موسیقی', 'Music'),
  PackIcon(Icons.videocam_rounded, 'ویدیو', 'Video'),
  PackIcon(Icons.image_rounded, 'تصویر', 'Image'),
  // row 4
  PackIcon(Icons.description_rounded, 'سند', 'Document'),
  PackIcon(Icons.picture_as_pdf_rounded, 'پی‌دی‌اف', 'PDF'),
  PackIcon(Icons.folder_zip_rounded, 'فایل فشرده', 'Zip'),
  PackIcon(Icons.inventory_2_rounded, 'بایگانی', 'Archive'),
  PackIcon(Icons.article_rounded, 'متن', 'Text'),
  PackIcon(Icons.table_chart_rounded, 'جدول', 'Table'),
  PackIcon(Icons.cloud_download_rounded, 'دانلود ابری', 'Cloud download'),
  PackIcon(Icons.cloud_upload_rounded, 'آپلود ابری', 'Cloud upload'),
  PackIcon(Icons.cloud_done_rounded, 'ابر همگام', 'Cloud synced'),
  // row 5
  PackIcon(Icons.verified_user_rounded, 'سپر امنیتی', 'Shield'),
  PackIcon(Icons.lock_rounded, 'قفل', 'Lock'),
  PackIcon(Icons.lock_open_rounded, 'قفل باز', 'Unlock'),
  PackIcon(Icons.bookmark_rounded, 'نشانک', 'Bookmark'),
  PackIcon(Icons.history_rounded, 'تاریخچه', 'History'),
  PackIcon(Icons.calendar_month_rounded, 'تقویم', 'Calendar'),
  PackIcon(Icons.mic_rounded, 'میکروفون', 'Microphone'),
  PackIcon(Icons.photo_camera_rounded, 'دوربین', 'Camera'),
  PackIcon(Icons.crop_free_rounded, 'اسکن', 'Scan'),
  // row 6
  PackIcon(Icons.location_on_rounded, 'مکان', 'Location'),
  PackIcon(Icons.language_rounded, 'وب', 'Web'),
  PackIcon(Icons.wifi_rounded, 'وای‌فای', 'Wi-Fi'),
  PackIcon(Icons.bluetooth_rounded, 'بلوتوث', 'Bluetooth'),
  PackIcon(Icons.flight_rounded, 'حالت پرواز', 'Airplane'),
  PackIcon(Icons.battery_std_rounded, 'باتری', 'Battery'),
  PackIcon(Icons.battery_charging_full_rounded, 'شارژ', 'Charging'),
  PackIcon(Icons.smartphone_rounded, 'گوشی', 'Phone'),
  PackIcon(Icons.desktop_windows_rounded, 'رایانه', 'Desktop'),
  // row 7
  PackIcon(Icons.cleaning_services_rounded, 'پاک‌سازی', 'Clean'),
  PackIcon(Icons.auto_fix_high_rounded, 'پاک‌سازی هوشمند', 'Smart clean'),
  PackIcon(Icons.extension_rounded, 'افزونه', 'Plugin'),
  PackIcon(Icons.view_in_ar_rounded, 'مکعب', 'Cube'),
  PackIcon(Icons.palette_rounded, 'رنگ‌ها', 'Palette'),
  PackIcon(Icons.mood_rounded, 'شکلک', 'Smile'),
  PackIcon(Icons.dark_mode_rounded, 'حالت تاریک', 'Dark mode'),
  PackIcon(Icons.light_mode_rounded, 'حالت روشن', 'Light mode'),
  PackIcon(Icons.tune_rounded, 'تنظیم دقیق', 'Tune'),
];

/// User-chosen colour / shape of the folder and file-type icons, the colour of every icon of the icon sheet
/// and the app-wide icon style (settings -> icon style).
class IconPrefs {
  /// File-type key (folder, images, ...) -> colour (solid or gradient).
  static final specs = <String, ColorSpec>{};
  static final shapes = <String, int>{};

  /// Icon id (see [idOf]) -> colour. Wins over everything else, wherever that icon is drawn.
  static final overrides = <String, ColorSpec>{};

  /// App-wide icon style for icons without an explicit colour: 0 = as the theme draws them,
  /// 1 = theme gradient (primary -> secondary), 2 = [custom].
  static int mode = 0;
  static ColorSpec custom = const ColorSpec(0xFF2F6BFF, 0xFF8B5CF6);

  static String idOf(IconData d) => '${d.fontFamily}:${d.codePoint}';

  /// key -> available shapes (index 0 = default)
  static const Map<String, List<IconData>> options = {
    'folder': [Icons.folder_rounded, Icons.folder_outlined, Icons.folder_open_rounded, Icons.folder_special_rounded, Icons.snippet_folder_rounded, Icons.folder_copy_rounded, Icons.create_new_folder_rounded, Icons.manage_history_rounded],
    'images': [Icons.image_rounded, Icons.photo_rounded, Icons.photo_library_rounded, Icons.landscape_rounded, Icons.photo_camera_rounded],
    'videos': [Icons.play_circle_rounded, Icons.movie_rounded, Icons.videocam_rounded, Icons.smart_display_rounded, Icons.theaters_rounded, Icons.play_arrow_rounded],
    'audio': [Icons.music_note_rounded, Icons.audiotrack_rounded, Icons.headphones_rounded, Icons.library_music_rounded, Icons.equalizer_rounded, Icons.mic_rounded],
    'docs': [Icons.description_rounded, Icons.article_rounded, Icons.text_snippet_rounded, Icons.sticky_note_2_rounded, Icons.menu_book_rounded, Icons.table_chart_rounded],
    'pdf': [Icons.picture_as_pdf_rounded, Icons.picture_as_pdf_outlined, Icons.description_rounded, Icons.article_rounded],
    'apps': [Icons.android_rounded, Icons.apps_rounded, Icons.widgets_rounded, Icons.install_mobile_rounded, Icons.extension_rounded, Icons.view_in_ar_rounded],
    'archives': [Icons.archive_rounded, Icons.folder_zip_rounded, Icons.inventory_2_rounded, Icons.compress_rounded],
    'other': [Icons.insert_drive_file_rounded, Icons.description_rounded, Icons.attach_file_rounded, Icons.note_rounded],
  };

  static const keys = ['folder', 'images', 'videos', 'audio', 'docs', 'pdf', 'apps', 'archives', 'other'];

  /// Quick swatches of the colour picker.
  static const palette = <int>[
    0xFFFFB84D, 0xFFFF9F43, 0xFFFF5C7A, 0xFFE53935, 0xFFEC407A, 0xFF8B5CF6, 0xFF2F6BFF,
    0xFF29B6F6, 0xFF26C6DA, 0xFF2ECC71, 0xFF9CCC65, 0xFFF5A623, 0xFF8D6E63, 0xFF78909C, 0xFFFFFFFF,
  ];

  /// Ready-made gradients of the colour picker.
  static const gradients = <List<int>>[
    [0xFF2F6BFF, 0xFF8B5CF6],
    [0xFF00D4FF, 0xFF8B3DFF],
    [0xFF2DD4BF, 0xFF3B82F6],
    [0xFFFF9F43, 0xFFFF5C7A],
    [0xFFF5A623, 0xFFE53935],
    [0xFF2ECC71, 0xFF26C6DA],
    [0xFFEC407A, 0xFF8B5CF6],
    [0xFFFFD54F, 0xFFFF7043],
  ];

  static Color defaultColor(String key) {
    switch (key) {
      case 'folder': return const Color(0xFFFFB84D);
      case 'images': return const Color(0xFF2ECC71);
      case 'videos': return AppColors.purple;
      case 'audio': return AppColors.gold;
      case 'docs':
      case 'pdf': return const Color(0xFFFF5C7A);
      case 'apps': return const Color(0xFF3DDC84);
      case 'archives': return const Color(0xFFFF9F43);
      default: return Colors.blueGrey;
    }
  }

  static ColorSpec spec(String key) => specs[key] ?? ColorSpec.solid(defaultColor(key).value);

  /// First colour of [spec] (kept for code that only needs a flat colour).
  static Color color(String key) => spec(key).color1;

  static IconData icon(String key) {
    final l = options[key] ?? options['other']!;
    final i = shapes[key] ?? 0;
    return l[i >= 0 && i < l.length ? i : 0];
  }

  // ---- (de)serialisation, used by AppSettings
  static Map<String, dynamic> toJson() => {
        'g': {for (final e in specs.entries) e.key: e.value.encode()},
        's': shapes,
        'o': {for (final e in overrides.entries) e.key: e.value.encode()},
        'm': mode,
        'u': custom.encode(),
      };

  static void fromJson(Map m) {
    specs.clear();
    shapes.clear();
    overrides.clear();
    // old format: {'c': {key: argb}}
    for (final e in (m['c'] as Map? ?? {}).entries) {
      final v = ColorSpec.decode(e.value);
      if (v != null) specs['${e.key}'] = v;
    }
    for (final e in (m['g'] as Map? ?? {}).entries) {
      final v = ColorSpec.decode(e.value);
      if (v != null) specs['${e.key}'] = v;
    }
    for (final e in (m['s'] as Map? ?? {}).entries) {
      shapes['${e.key}'] = (e.value as num).toInt();
    }
    for (final e in (m['o'] as Map? ?? {}).entries) {
      final v = ColorSpec.decode(e.value);
      if (v != null) overrides['${e.key}'] = v;
    }
    final mm = ((m['m'] as num?) ?? 0).toInt();
    mode = mm < 0 ? 0 : (mm > 2 ? 2 : mm);
    custom = ColorSpec.decode(m['u']) ?? const ColorSpec(0xFF2F6BFF, 0xFF8B5CF6);
  }
}
