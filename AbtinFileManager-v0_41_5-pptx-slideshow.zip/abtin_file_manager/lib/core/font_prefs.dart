import 'l10n.dart';

/// A selectable UI font (Settings -> Font). [family] is the family name declared in pubspec.yaml.
class AppFont {
  final String id, fa, en;
  final String? family; // null = system font
  const AppFont(this.id, this.fa, this.en, this.family);
  String get name => L.lang == 'fa' ? fa : en;
}

const List<AppFont> appFonts = [
  AppFont('auto', 'خودکار (وزیر برای فارسی)', 'Auto (Vazir for Persian)', null),
  AppFont('system', 'فونت سیستم', 'System font', null),
  AppFont('vazir', 'وزیر', 'Vazir', 'Vazir'),
  AppFont('sade', 'ساده', 'A Sade', 'ASade'),
  AppFont('titr', 'تیتر', 'B Titr', 'BTitr'),
  AppFont('badr', 'بدر', 'Badr', 'BadrBold'),
  AppFont('badkhat', 'بدخط', 'Badkhat', 'Badkhat'),
  AppFont('shekasteh', 'شکسته', 'Shekasteh', 'Shekasteh'),
];

AppFont fontById(String id) => appFonts.firstWhere((f) => f.id == id, orElse: () => appFonts.first);

class FontPrefs {
  static String current = 'auto';

  /// Family used by the theme right now.
  static String? family() {
    if (current == 'auto') return L.lang == 'fa' ? 'Vazir' : null;
    return fontById(current).family;
  }
}
