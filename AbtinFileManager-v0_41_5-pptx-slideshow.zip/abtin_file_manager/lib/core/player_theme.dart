import 'package:flutter/material.dart';

/// Fixed look of the video player (no selectable themes).
class PlayerTheme {
  PlayerTheme._();
  static final PlayerTheme I = PlayerTheme._();

  final Color accent = const Color(0xFF8A2BFF);
  final Color accent2 = const Color(0xFF5B21B6);
  final Color highlight = const Color(0xFFB57BFF);
  final double glass = .42;
  final double glow = .8;
  final bool blur = true;
  final bool badge = true;

  LinearGradient get gradient => LinearGradient(colors: [accent, accent2], begin: Alignment.topLeft, end: Alignment.bottomRight);
  LinearGradient get seekGradient => LinearGradient(colors: [highlight, accent]);
}
