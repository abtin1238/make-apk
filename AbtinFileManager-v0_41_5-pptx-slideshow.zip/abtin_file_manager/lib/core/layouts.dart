import 'package:flutter/material.dart';
import 'l10n.dart';

/// Inline fa / en text (layout names are not worth ARB keys).
String tr2(String fa, String en) => L.lang == 'fa' ? fa : en;

/// A layout theme changes the STRUCTURE of the app (navigation, home screen, list density),
/// not only its colours.
class AppLayout {
  final String id, fa, en, faDesc, enDesc;
  final IconData icon;
  final bool grid; // file view that fits this layout (applied when it is chosen)
  const AppLayout(this.id, this.fa, this.en, this.faDesc, this.enDesc, this.icon, this.grid);
  String get name => tr2(fa, en);
  String get desc => tr2(faDesc, enDesc);
}

const List<AppLayout> appLayouts = [
  AppLayout('classic', 'کلاسیک', 'Classic', 'نوار پایین، صفحهٔ خانهٔ کارتی، فهرست فایل‌ها', 'Bottom bar, card home, file list', Icons.dashboard_rounded, false),
  AppLayout('drawer', 'منوی کشویی', 'Drawer', 'بدون نوار پایین؛ منوی کنار با همهٔ بخش‌ها، خانهٔ فهرستی', 'No bottom bar; side menu with every section, list-style home', Icons.menu_open_rounded, false),
  AppLayout('dashboard', 'داشبورد', 'Dashboard', 'نوار شناور گرد، کارت بزرگ حافظه، فایل‌های اخیر، فایل‌ها به‌صورت شبکه', 'Floating pill bar, big storage card, recent files, grid files', Icons.space_dashboard_rounded, true),
  AppLayout('rail', 'حرفه‌ای (ریل)', 'Pro (rail)', 'ریل باریک کنار صفحه، خانهٔ بخش‌بندی‌شدهٔ جمع‌شونده، فهرست فشرده', 'Slim side rail, collapsible sections home, dense lists', Icons.view_sidebar_rounded, false),
  AppLayout('tabs', 'تب‌های بالا', 'Top tabs', 'تب‌ها بالای صفحه، خانه به سبک لانچر با آیکن‌های گرد، فایل‌ها شبکه‌ای', 'Tabs on top, launcher-style home with round icons, grid files', Icons.tab_rounded, true),
];

AppLayout layoutById(String id) => appLayouts.firstWhere((l) => l.id == id, orElse: () => appLayouts.first);
