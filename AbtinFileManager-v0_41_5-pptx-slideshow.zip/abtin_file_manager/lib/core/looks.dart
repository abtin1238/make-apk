import 'package:flutter/material.dart';
import 'layouts.dart';

/// A "look" is a visual theme: how cards, borders, the storage card and the home screen are drawn.
/// Colours stay free: every look starts with its own palette but the user can change any colour afterwards
/// (Settings -> theme colours), including the gradient of the accent.
class AppLook {
  final String id, fa, en, faDesc, enDesc;
  final IconData icon;

  /// Palette (index in appPalettes) applied when the look is chosen; -1 = leave the palette alone.
  final int palette;

  /// Layout applied when the look is chosen; null = leave it alone.
  final String? layout;
  const AppLook(this.id, this.fa, this.en, this.faDesc, this.enDesc, this.icon, this.palette, this.layout);
  String get name => tr2(fa, en);
  String get desc => tr2(faDesc, enDesc);
}

const List<AppLook> appLooks = [
  AppLook('neon', 'نئون', 'Neon', 'پس‌زمینهٔ سیاه، کارت‌های دورنورانی، حلقهٔ حافظهٔ گرادیانتی و ریل کناری', 'Black background, glowing outlined cards, gradient storage ring and a side rail', Icons.auto_awesome_rounded, 0, 'rail'),
  AppLook('glass', 'شیشه‌ای', 'Glass', 'کارت‌های شیشه‌ای نیمه‌شفاف، دسترسی سریع و فهرست پوشه‌ها، نوار پایین', 'Translucent glass cards, quick access, folder list, bottom bar', Icons.blur_on_rounded, 1, 'classic'),
];

AppLook lookById(String id) => appLooks.firstWhere((l) => l.id == id, orElse: () => appLooks.first);

/// Current look + the accent-gradient switch. Set by AppSettings (static, like IconPrefs) so that plain
/// widgets such as GradCard can read them; widgets that must repaint depend on AppStyleScope.
class Looks {
  static String current = 'neon';

  /// true: accent surfaces (storage card, selected pills, drawer header) use a primary -> secondary gradient;
  /// false: they use the solid primary colour.
  static bool accentGradient = true;

  static bool get isClassic => false;

  /// The accent paint: a gradient (or the solid primary colour when the gradient is switched off).
  static BoxDecoration accent(ColorScheme cs, {BorderRadius? radius, BoxShape shape = BoxShape.rectangle}) => accentGradient
      ? BoxDecoration(gradient: LinearGradient(colors: [cs.primary, cs.secondary], begin: Alignment.topLeft, end: Alignment.bottomRight), borderRadius: shape == BoxShape.circle ? null : radius, shape: shape)
      : BoxDecoration(color: cs.primary, borderRadius: shape == BoxShape.circle ? null : radius, shape: shape);

  /// Colours of the accent (one colour twice when the gradient is off).
  static List<Color> accentColors(ColorScheme cs) => accentGradient ? [cs.primary, cs.secondary] : [cs.primary, cs.primary];

  /// Decoration of a card / tile in the current look.
  static BoxDecoration card(BuildContext c, {double radius = 18, Color? accent}) {
    final t = Theme.of(c);
    final dark = t.brightness == Brightness.dark;
    final a = accent ?? t.colorScheme.primary;
    final r = BorderRadius.circular(radius);
    switch (current) {
      case 'neon':
        return BoxDecoration(
          color: dark ? Color.alphaBlend(a.withOpacity(.07), t.cardColor) : t.cardColor,
          borderRadius: r,
          border: Border.all(color: a.withOpacity(dark ? .75 : .55), width: 1.2),
          boxShadow: [BoxShadow(color: a.withOpacity(dark ? .28 : .16), blurRadius: 14, spreadRadius: -2)],
        );
      case 'glass':
        return BoxDecoration(
          color: dark ? Colors.white.withOpacity(.06) : Colors.white.withOpacity(.78),
          borderRadius: r,
          border: Border.all(color: (dark ? Colors.white : Colors.black).withOpacity(dark ? .10 : .06)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(dark ? .25 : .07), blurRadius: 16, offset: const Offset(0, 6))],
        );
      case 'gradient':
        return BoxDecoration(color: t.cardColor, borderRadius: r, border: Border.all(color: a.withOpacity(dark ? .22 : .18)));
    }
    return BoxDecoration(color: t.cardColor, borderRadius: r);
  }
}
