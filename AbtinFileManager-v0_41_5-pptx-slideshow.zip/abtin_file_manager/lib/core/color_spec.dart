import 'package:flutter/material.dart';

/// A colour that is either solid ([c2] == null) or a two-colour linear gradient.
/// Used for icons, theme accents and anything else the user can recolour.
class ColorSpec {
  final int c1;
  final int? c2;

  /// Gradient direction: 0 = top-left → bottom-right, 1 = top → bottom, 2 = left → right, 3 = bottom-left → top-right.
  final int dir;
  const ColorSpec(this.c1, [this.c2, this.dir = 0]);
  const ColorSpec.solid(this.c1)
      : c2 = null,
        dir = 0;

  static const _begin = [Alignment.topLeft, Alignment.topCenter, Alignment.centerLeft, Alignment.bottomLeft];
  static const _end = [Alignment.bottomRight, Alignment.bottomCenter, Alignment.centerRight, Alignment.topRight];

  bool get isGradient => c2 != null && c2 != c1;
  Color get color1 => Color(c1);
  Color get color2 => Color(c2 ?? c1);

  LinearGradient get gradient {
    final d = dir < 0 ? 0 : (dir > 3 ? 3 : dir);
    return LinearGradient(colors: [color1, color2], begin: _begin[d], end: _end[d]);
  }

  /// BoxDecoration-ready paint: gradient when it is one, solid colour otherwise.
  BoxDecoration decoration({BorderRadius? radius, BoxShape shape = BoxShape.rectangle}) => isGradient
      ? BoxDecoration(gradient: gradient, borderRadius: shape == BoxShape.circle ? null : radius, shape: shape)
      : BoxDecoration(color: color1, borderRadius: shape == BoxShape.circle ? null : radius, shape: shape);

  ColorSpec withC1(int v) => ColorSpec(v, c2, dir);
  ColorSpec withC2(int? v) => ColorSpec(c1, v, dir);
  ColorSpec withDir(int v) => ColorSpec(c1, c2, v);

  @override
  bool operator ==(Object o) => o is ColorSpec && o.c1 == c1 && o.c2 == c2 && o.dir == dir;
  @override
  int get hashCode => Object.hash(c1, c2, dir);

  /// "c1|c2|dir" (c2 empty for solid colours).
  String encode() => '$c1|${c2 ?? ''}|$dir';

  static ColorSpec? decode(Object? v) {
    if (v is num) return ColorSpec.solid(v.toInt()); // old format: plain ARGB int
    if (v is! String) return null;
    final p = v.split('|');
    if (p.isEmpty) return null;
    final a = int.tryParse(p[0]);
    if (a == null) return null;
    final b = p.length > 1 && p[1].isNotEmpty ? int.tryParse(p[1]) : null;
    final d = p.length > 2 ? (int.tryParse(p[2]) ?? 0) : 0;
    return ColorSpec(a, b, d);
  }
}

/// Paints [child] (an icon / text drawn in opaque white) with [spec].
/// Solid specs simply tint; gradients use a shader mask.
Widget paintWithSpec(ColorSpec spec, Widget child) {
  if (!spec.isGradient) return child;
  return ShaderMask(
    blendMode: BlendMode.srcIn,
    shaderCallback: (Rect r) => spec.gradient.createShader(r),
    child: child,
  );
}
