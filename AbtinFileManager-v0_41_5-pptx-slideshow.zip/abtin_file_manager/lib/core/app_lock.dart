import 'dart:convert';
import 'dart:math';
import 'package:flutter/widgets.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/sec_native.dart';
import '../services/vault_service.dart';

/// 0 = ok, 1 = wrong PIN, 2 = temporarily locked out
enum PinResult { ok, wrong, lockedOut }

/// PIN / fingerprint app lock. The PIN is never stored: only a salted PBKDF2-SHA256 hash.
class AppLock extends ChangeNotifier with WidgetsBindingObserver {
  static const _iter = 100000;
  static const timeouts = [0, 30, 60, 300]; // seconds in background before the app locks again
  static const _vaultTimeout = 120;

  late SharedPreferences _p;
  bool enabled = false, bio = false, hideRecents = false, locked = false;
  int timeout = 60, pinLength = 4;
  int _fails = 0, _until = 0;
  DateTime? _bgAt;

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    enabled = _p.getString('lk_hash') != null;
    bio = enabled && (_p.getBool('lk_bio') ?? false);
    hideRecents = _p.getBool('lk_secure') ?? false;
    timeout = _p.getInt('lk_to') ?? 60;
    pinLength = _p.getInt('lk_len') ?? 4;
    _fails = _p.getInt('lk_fail') ?? 0;
    _until = _p.getInt('lk_until') ?? 0;
    locked = enabled; // cold start
    await Sec.setSecure(hideRecents);
    WidgetsBinding.instance.addObserver(this);
  }

  /// Seconds left of the brute-force lockout (0 = none).
  int get lockoutLeft {
    final left = _until - DateTime.now().millisecondsSinceEpoch;
    return left <= 0 ? 0 : (left / 1000).ceil();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.paused) {
      _bgAt = DateTime.now();
    } else if (s == AppLifecycleState.resumed && _bgAt != null) {
      final secs = DateTime.now().difference(_bgAt!).inSeconds;
      _bgAt = null;
      if (VaultService.unlocked && (enabled ? secs >= timeout : secs >= _vaultTimeout)) VaultService.lock();
      if (enabled && !locked && secs >= timeout) lock();
    }
  }

  void lock() {
    if (!enabled || locked) return;
    VaultService.lock();
    locked = true;
    notifyListeners();
  }

  void unlock() {
    _fails = 0;
    _until = 0;
    _p.setInt('lk_fail', 0);
    _p.setInt('lk_until', 0);
    locked = false;
    notifyListeners();
  }

  Future<String> _hash(String pin, String salt) => Sec.pbkdf2(pin, salt, _iter);

  Future<PinResult> verify(String pin) async {
    if (lockoutLeft > 0) return PinResult.lockedOut;
    final salt = _p.getString('lk_salt') ?? '';
    final h = await _hash(pin, salt);
    final want = _p.getString('lk_hash') ?? '';
    var diff = h.length ^ want.length;
    for (var i = 0; i < min(h.length, want.length); i++) {
      diff |= h.codeUnitAt(i) ^ want.codeUnitAt(i);
    }
    if (diff == 0) return PinResult.ok;
    _fails++;
    if (_fails >= 5) {
      // 30 s after the 5th mistake, then doubling, capped at 1 hour
      final secs = min(3600, 30 * (1 << min(_fails - 5, 7)));
      _until = DateTime.now().millisecondsSinceEpoch + secs * 1000;
    }
    await _p.setInt('lk_fail', _fails);
    await _p.setInt('lk_until', _until);
    notifyListeners();
    return _until > DateTime.now().millisecondsSinceEpoch ? PinResult.lockedOut : PinResult.wrong;
  }

  Future<void> setPin(String pin) async {
    final r = Random.secure();
    final salt = base64.encode(List.generate(16, (_) => r.nextInt(256)));
    await _p.setString('lk_salt', salt);
    await _p.setString('lk_hash', await _hash(pin, salt));
    await _p.setInt('lk_len', pin.length);
    pinLength = pin.length;
    enabled = true;
    notifyListeners();
  }

  Future<void> disable() async {
    for (final k in ['lk_hash', 'lk_salt', 'lk_len', 'lk_bio', 'lk_fail', 'lk_until']) {
      await _p.remove(k);
    }
    enabled = false;
    bio = false;
    locked = false;
    _fails = 0;
    _until = 0;
    notifyListeners();
  }

  void setBio(bool v) { bio = v; _p.setBool('lk_bio', v); notifyListeners(); }
  void setTimeout(int v) { timeout = v; _p.setInt('lk_to', v); notifyListeners(); }
  void setHideRecents(bool v) { hideRecents = v; _p.setBool('lk_secure', v); Sec.setSecure(v); notifyListeners(); }
}
