import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'file_ops.dart';
import 'native.dart';
import 'saf.dart';
import 'sec_native.dart';

class VaultEntry {
  final String id, name, orig;
  int size;
  final int time;
  VaultEntry(this.id, this.name, this.orig, this.size, this.time);
  factory VaultEntry.fromJson(Map<String, dynamic> j) =>
      VaultEntry(j['id'] as String, j['name'] as String, j['orig'] as String, (j['size'] as num).toInt(), (j['time'] as num).toInt());
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'orig': orig, 'size': size, 'time': time};
}

/// Encrypted vault on internal storage: `<root>/.AbtinVault/<id>.abv` (AES-256-GCM, random ids),
/// names and original paths live only in the encrypted `index.abv`. The password is turned into a key
/// with PBKDF2; it can not be recovered.
class VaultService {
  static bool unlocked = false;
  static List<VaultEntry> entries = [];

  static String get dir => p.join(FileOps.root, '.AbtinVault');
  static String get _meta => p.join(dir, 'vault.json');
  static String get _index => p.join(dir, 'index.abv');
  static bool get exists => File(_meta).existsSync();
  static String _file(String id) => p.join(dir, '$id.abv');

  static Future<void> create(String pw) async {
    await Sec.vaultCreate(dir, pw);
    unlocked = true;
    entries = [];
    await _save();
  }

  static Future<bool> unlock(String pw) async {
    final ok = await Sec.vaultUnlock(dir, pw);
    if (!ok) return false;
    unlocked = true;
    try {
      await _load();
    } catch (_) {
      await lock();
      rethrow;
    }
    return true;
  }

  static Future<void> lock() async {
    unlocked = false;
    entries = [];
    await Sec.vaultLock();
    await clearTemp();
  }

  static Future<bool> changePassword(String oldPw, String newPw) => Sec.vaultChangePw(dir, oldPw, newPw);

  static Future<void> _load() async {
    final s = await Sec.vaultReadIndex(_index);
    entries = s == null ? [] : (jsonDecode(s) as List).map((e) => VaultEntry.fromJson(e as Map<String, dynamic>)).toList();
    entries.sort((a, b) => b.time.compareTo(a.time));
  }

  static Future<void> _save() => Sec.vaultWriteIndex(_index, jsonEncode(entries.map((e) => e.toJson()).toList()));

  static String _newId() {
    final r = Random.secure();
    return List.generate(16, (_) => r.nextInt(256).toRadixString(16).padLeft(2, '0')).join();
  }

  /// Encrypts files / folders into the vault and deletes the originals once each file is safely stored.
  static Future<void> addPaths(List<String> paths) async {
    if (!unlocked) throw const OpError('vaultLocked');
    for (final path in paths) {
      if (await Saf.use(path)) throw const OpError('vaultSaf');
    }
    for (final path in paths) {
      if (p.isWithin(dir, path) || p.equals(dir, path)) continue;
      final t = FileSystemEntity.typeSync(path, followLinks: false);
      if (t == FileSystemEntityType.directory) {
        final files = <File>[];
        await for (final f in FileOps.walk(path, hidden: true)) {
          files.add(f);
        }
        for (final f in files) {
          await _addFile(f);
        }
        // everything inside was stored: drop the (now empty) folder tree
        await FileOps.delete(Directory(path));
      } else if (t == FileSystemEntityType.file) {
        await _addFile(File(path));
      }
    }
    await _save();
  }

  static Future<void> _addFile(File f) async {
    final id = _newId();
    final size = await f.length();
    await Sec.vaultEncrypt(f.path, _file(id));
    entries.insert(0, VaultEntry(id, p.basename(f.path), f.path, size, DateTime.now().millisecondsSinceEpoch));
    await _save(); // index first, then remove the original: a crash can never lose the file
    await FileOps.delete(f);
  }

  /// Puts the file back at its original path (a free name is chosen on clashes).
  static Future<String> restore(VaultEntry e) async {
    var parent = p.dirname(e.orig);
    try {
      await Directory(parent).create(recursive: true);
    } catch (_) {
      parent = p.join(FileOps.root, 'Restored from vault');
      await Directory(parent).create(recursive: true);
    }
    final target = FileOps.unique(parent, e.name);
    await Sec.vaultDecrypt(_file(e.id), target);
    await Native.scan(target);
    await remove(e);
    return target;
  }

  static Future<void> remove(VaultEntry e) async {
    entries.removeWhere((x) => x.id == e.id);
    await _save();
    try { await File(_file(e.id)).delete(); } catch (_) {}
  }

  static Future<Directory> _tmp() async => Directory(p.join((await getTemporaryDirectory()).path, 'vault_tmp'));

  /// Decrypts into the app cache (wiped when the vault locks) so the normal viewers can open it.
  static Future<String> openTemp(VaultEntry e) async {
    final d = Directory(p.join((await _tmp()).path, e.id));
    await d.create(recursive: true);
    final out = p.join(d.path, e.name);
    await Sec.vaultDecrypt(_file(e.id), out);
    return out;
  }

  /// Re-encrypts an edited temp copy over the stored file.
  static Future<void> updateFrom(VaultEntry e, String tempPath) async {
    await Sec.vaultEncrypt(tempPath, _file(e.id));
    e.size = await File(tempPath).length();
    await _save();
  }

  static Future<void> clearTemp() async {
    try {
      final d = await _tmp();
      if (d.existsSync()) await d.delete(recursive: true);
    } catch (_) {}
  }
}
