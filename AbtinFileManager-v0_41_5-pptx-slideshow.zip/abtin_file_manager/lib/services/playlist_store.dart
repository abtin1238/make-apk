import 'dart:convert';
import 'dart:io';
import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'file_ops.dart';

class Playlist {
  String name;
  final List<String> tracks;
  Playlist(this.name, [List<String>? t]) : tracks = t ?? [];
}

/// User playlists (stored in SharedPreferences) + .m3u / .m3u8 import and export.
class PlaylistStore {
  static SharedPreferences? _p;
  static final lists = <Playlist>[];

  static Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    try {
      for (final e in jsonDecode(_p!.getString('playlists') ?? '[]') as List) {
        lists.add(Playlist(e['n'] as String, [for (final t in e['t'] as List) '$t']));
      }
    } catch (_) {}
  }

  static void save() => _p?.setString('playlists', jsonEncode([for (final l in lists) {'n': l.name, 't': l.tracks}]));

  static Playlist create(String name, [List<String>? tracks]) {
    final l = Playlist(name.trim().isEmpty ? 'Playlist' : name.trim(), tracks);
    lists.add(l);
    save();
    return l;
  }

  static void remove(Playlist l) {
    lists.remove(l);
    save();
  }

  static void add(Playlist l, Iterable<String> paths) {
    for (final x in paths) {
      if (!l.tracks.contains(x)) l.tracks.add(x);
    }
    save();
  }

  /// Parses .m3u / .m3u8 (relative paths are resolved against the file's folder). Missing local files are skipped.
  static Future<List<String>> parseM3u(String file) async {
    final bytes = await File(file).readAsBytes();
    String txt;
    try {
      txt = utf8.decode(bytes);
    } catch (_) {
      txt = latin1.decode(bytes);
    }
    final dir = p.dirname(file);
    final out = <String>[];
    for (var line in const LineSplitter().convert(txt)) {
      line = line.trim().replaceAll('\uFEFF', '');
      if (line.isEmpty || line.startsWith('#')) continue;
      if (RegExp(r'^[a-z]+://', caseSensitive: false).hasMatch(line)) {
        out.add(line);
        continue;
      }
      final path = p.isAbsolute(line) ? line : p.normalize(p.join(dir, line.replaceAll('\\', '/')));
      if (File(path).existsSync()) out.add(path);
    }
    return out;
  }

  /// Writes <Music>/Playlists/<name>.m3u8 (relative paths when possible) and returns its path.
  static Future<String> exportM3u(Playlist l) async {
    final dir = p.join(FileOps.root, 'Music', 'Playlists');
    await Directory(dir).create(recursive: true);
    final safe = l.name.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');
    final path = p.join(dir, '$safe.m3u8');
    final b = StringBuffer('#EXTM3U\n');
    for (final t in l.tracks) {
      b.writeln('#EXTINF:-1,${p.basenameWithoutExtension(t)}');
      b.writeln(t.startsWith('http') ? t : p.relative(t, from: dir).replaceAll('\\', '/'));
    }
    await File(path).writeAsString(b.toString());
    return path;
  }
}

/// Cached title / artist / album of audio files (for album and artist views).
class TagCache {
  static SharedPreferences? _p;
  static final Map<String, List<String>> _m = {}; // path|size -> [title, artist, album]

  static Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    try {
      (jsonDecode(_p!.getString('tagcache') ?? '{}') as Map).forEach((k, v) => _m['$k'] = [for (final e in v as List) '$e']);
    } catch (_) {}
  }

  static String _k(String path, int size) => '$path|$size';

  /// Entries are keyed by path + size, so an edited file simply gets a new key on the next scan.
  static void invalidate() {}
  static List<String>? get(String path, int size) => _m[_k(path, size)];

  /// Reads tags of every file not cached yet; [onStep] is called regularly so the UI can refresh.
  static Future<void> scan(Iterable<MapEntry<String, int>> files, bool Function() alive, void Function() onStep) async {
    var n = 0;
    for (final f in files) {
      if (!alive()) return;
      final k = _k(f.key, f.value);
      if (_m.containsKey(k)) continue;
      var v = ['', '', ''];
      try {
        final m = await Future.sync(() => readMetadata(File(f.key), getImage: false));
        v = [(m.title ?? '').trim(), (m.artist ?? '').trim(), (m.album ?? '').trim()];
      } catch (_) {}
      _m[k] = v;
      if (++n % 20 == 0) {
        onStep();
        await Future<void>.delayed(Duration.zero);
      }
    }
    _p?.setString('tagcache', jsonEncode(_m));
    onStep();
  }
}


/// Cover art of audio files for the album grid: embedded picture, else cover.jpg / folder.jpg in the folder.
/// Pictures are written to a cache folder once and shown with a reduced decode size.
class ArtCache {
  static final _mem = <String, Future<File?>>{};

  static Future<File?> get(String path) => _mem.putIfAbsent(path, () async {
        try {
          final dir = Directory('${Directory.systemTemp.path}/abtin_art');
          final f = File('${dir.path}/${path.hashCode}_${File(path).lengthSync()}.img');
          if (f.existsSync()) return f.lengthSync() == 0 ? _folderArt(path) : f;
          await dir.create(recursive: true);
          final m = await Future.sync(() => readMetadata(File(path), getImage: true));
          if (m.pictures.isEmpty) {
            await f.writeAsBytes(const []);
            return _folderArt(path);
          }
          await f.writeAsBytes(m.pictures.first.bytes);
          return f;
        } catch (_) {
          return _folderArt(path);
        }
      });

  static File? _folderArt(String path) {
    final d = p.dirname(path);
    for (final n in ['cover', 'folder', 'album', 'front', 'albumart']) {
      for (final e in ['jpg', 'jpeg', 'png']) {
        final f = File(p.join(d, '$n.$e'));
        if (f.existsSync()) return f;
      }
    }
    return null;
  }

  static void forget(String path) => _mem.remove(path);
}
