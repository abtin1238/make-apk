import 'dart:io';
import 'package:path/path.dart' as p;
import 'playlist_store.dart';

/// Lightweight audio library used by the Android Auto / media-browser tree.
class LibraryIndex {
  static const exts = {'.mp3', '.m4a', '.aac', '.flac', '.ogg', '.opus', '.wav', '.wma'};
  static const max = 1500;
  static List<_T> _all = [];
  static DateTime? _at;

  static Future<void> ensure() async {
    if (_at != null && DateTime.now().difference(_at!) < const Duration(minutes: 5)) return;
    final out = <_T>[];
    for (final r in const ['/storage/emulated/0/Music', '/storage/emulated/0/Download', '/storage/emulated/0/Podcasts', '/storage/emulated/0/Audiobooks']) {
      final d = Directory(r);
      if (!await d.exists()) continue;
      try {
        await for (final e in d.list(recursive: true, followLinks: false)) {
          if (out.length >= max) break;
          if (e is File && exts.contains(p.extension(e.path).toLowerCase())) {
            int size = 0;
            try { size = await e.length(); } catch (_) {}
            final m = TagCache.get(e.path, size);
            out.add(_T(e.path, m != null && m[0].isNotEmpty ? m[0] : p.basenameWithoutExtension(e.path), m != null && m[1].isNotEmpty ? m[1] : p.basename(p.dirname(e.path)), m != null && m[2].isNotEmpty ? m[2] : p.basename(p.dirname(e.path))));
          }
        }
      } catch (_) {}
    }
    out.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
    _all = out;
    _at = DateTime.now();
  }

  /// contexts: all | pl:<i> | album:<name> | artist:<name>
  static List<String> albums() => (_all.map((e) => e.album).toSet().toList()..sort());
  static List<String> artists() => (_all.map((e) => e.artist).toSet().toList()..sort());

  static List<_T> tracks(String ctx) {
    if (ctx == 'all') return _all;
    if (ctx.startsWith('album:')) return _all.where((e) => e.album == ctx.substring(6)).toList();
    if (ctx.startsWith('artist:')) return _all.where((e) => e.artist == ctx.substring(7)).toList();
    if (ctx.startsWith('pl:')) {
      final i = int.tryParse(ctx.substring(3)) ?? -1;
      if (i < 0 || i >= PlaylistStore.lists.length) return [];
      return [
        for (final t in PlaylistStore.lists[i].tracks)
          () {
            final f = _all.where((e) => e.path == t);
            return f.isNotEmpty ? f.first : _T(t, p.basenameWithoutExtension(t), p.basename(p.dirname(t)), '');
          }()
      ];
    }
    return [];
  }
}

class _T {
  final String path, title, artist, album;
  _T(this.path, this.title, this.artist, this.album);
}

typedef LibTrack = _T;
