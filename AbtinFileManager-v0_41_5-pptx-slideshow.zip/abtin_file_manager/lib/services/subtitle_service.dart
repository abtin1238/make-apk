import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';

class SubResult {
  final int fileId;
  final String name, lang;
  final int downloads;
  final bool hashMatch;
  SubResult(this.fileId, this.name, this.lang, this.downloads, this.hashMatch);
}

/// Subtitle search / download through the OpenSubtitles.com REST API (v1).
/// The API needs a free consumer key and an account; they are entered once and kept in the app's private preferences.
class SubtitleService {
  static const _base = 'https://api.opensubtitles.com/api/v1';
  static const _ua = 'AbtinFileManager v0.26';
  static String? _token;
  static DateTime _tokenAt = DateTime.fromMillisecondsSinceEpoch(0);

  static Future<SharedPreferences> get _p => SharedPreferences.getInstance();

  static Future<({String key, String user, String pass, String lang})> settings() async {
    final p = await _p;
    return (key: p.getString('os_key') ?? '', user: p.getString('os_user') ?? '', pass: p.getString('os_pass') ?? '', lang: p.getString('os_lang') ?? 'fa,en');
  }

  static Future<void> saveSettings({String? key, String? user, String? pass, String? lang}) async {
    final p = await _p;
    if (key != null) await p.setString('os_key', key.trim());
    if (user != null) await p.setString('os_user', user.trim());
    if (pass != null) await p.setString('os_pass', pass);
    if (lang != null) await p.setString('os_lang', lang);
    _token = null;
  }

  static Future<Map<String, dynamic>> _req(String method, String path, {Map<String, dynamic>? body, Map<String, String>? query, bool auth = false}) async {
    final s = await settings();
    if (s.key.isEmpty) throw StateError('NO_KEY');
    final uri = Uri.parse('$_base$path').replace(queryParameters: query);
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      final rq = await (method == 'GET' ? c.getUrl(uri) : c.postUrl(uri));
      rq.headers.set('Api-Key', s.key);
      rq.headers.set('User-Agent', _ua);
      rq.headers.set('Accept', 'application/json');
      rq.headers.set('Content-Type', 'application/json');
      if (auth) rq.headers.set('Authorization', 'Bearer ${await _login(s.user, s.pass)}');
      if (body != null) rq.add(utf8.encode(jsonEncode(body)));
      final rs = await rq.close().timeout(const Duration(seconds: 30));
      final txt = await rs.transform(utf8.decoder).join();
      if (rs.statusCode >= 400) throw HttpException('${rs.statusCode} $txt');
      return jsonDecode(txt) as Map<String, dynamic>;
    } finally {
      c.close(force: true);
    }
  }

  static Future<String> _login(String user, String pass) async {
    if (_token != null && DateTime.now().difference(_tokenAt) < const Duration(hours: 20)) return _token!;
    if (user.isEmpty || pass.isEmpty) throw StateError('NO_LOGIN');
    final r = await _req('POST', '/login', body: {'username': user, 'password': pass});
    _token = r['token'] as String?;
    if (_token == null) throw StateError('NO_LOGIN');
    _tokenAt = DateTime.now();
    return _token!;
  }

  /// OpenSubtitles file hash (size + 64 KiB head + 64 KiB tail), exact match for the video file.
  static Future<String?> movieHash(String path) async {
    try {
      final f = File(path);
      final size = await f.length();
      if (size < 65536 * 2) return null;
      final raf = await f.open();
      try {
        var h = size;
        for (final pos in [0, size - 65536]) {
          await raf.setPosition(pos);
          final b = await raf.read(65536);
          final bd = ByteData.sublistView(b);
          for (var i = 0; i + 8 <= b.length; i += 8) {
            h += bd.getUint64(i, Endian.little);
          }
        }
        return BigInt.from(h).toUnsigned(64).toRadixString(16).padLeft(16, '0');
      } finally {
        await raf.close();
      }
    } catch (_) {
      return null;
    }
  }

  /// "The.Movie.2019.1080p.BluRay.x264-GRP.mkv" -> "The Movie"
  static String cleanTitle(String file) {
    var n = p.basenameWithoutExtension(file).replaceAll(RegExp(r'[._]+'), ' ');
    n = n.replaceAll(RegExp(r'\s*[\(\[]?((19|20)\d{2}|480p|576p|720p|1080p|2160p|4k|bluray|brrip|bdrip|webrip|web-dl|webdl|hdtv|dvdrip|x264|x265|h264|h265|hevc)\b.*$', caseSensitive: false), '');
    return n.trim();
  }

  static Future<List<SubResult>> search({required String query, required String langs, String? hash}) async {
    final q = <String, String>{
      'languages': langs,
      'order_by': 'download_count',
      if (hash != null) 'moviehash': hash,
      if (query.trim().isNotEmpty) 'query': query.trim(),
    };
    final r = await _req('GET', '/subtitles', query: q);
    final out = <SubResult>[];
    for (final e in (r['data'] as List? ?? const [])) {
      final a = (e as Map)['attributes'] as Map? ?? const {};
      final files = a['files'] as List? ?? const [];
      if (files.isEmpty) continue;
      out.add(SubResult((files.first as Map)['file_id'] as int, '${a['release'] ?? (files.first as Map)['file_name'] ?? ''}', '${a['language'] ?? ''}',
          (a['download_count'] as num?)?.toInt() ?? 0, a['moviehash_match'] == true));
    }
    out.sort((a, b) => a.hashMatch == b.hashMatch ? b.downloads.compareTo(a.downloads) : (a.hashMatch ? -1 : 1));
    return out;
  }

  /// Downloads the subtitle next to the video (or into the cache folder when that is not writable); returns the file path.
  static Future<String> download(SubResult r, String videoPath) async {
    final d = await _req('POST', '/download', body: {'file_id': r.fileId, 'sub_format': 'srt'}, auth: true);
    final link = d['link'] as String?;
    if (link == null) throw StateError('No download link');
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      final rq = await c.getUrl(Uri.parse(link));
      rq.headers.set('User-Agent', _ua);
      final rs = await rq.close().timeout(const Duration(seconds: 30));
      final bytes = <int>[];
      await for (final ch in rs) {
        bytes.addAll(ch);
      }
      final local = !RegExp(r'^[a-z]+://', caseSensitive: false).hasMatch(videoPath);
      final name = local ? '${p.withoutExtension(videoPath)}.${r.lang}.srt' : '${Directory.systemTemp.path}/abtin_subs/${DateTime.now().millisecondsSinceEpoch}.${r.lang}.srt';
      try {
        await Directory(p.dirname(name)).create(recursive: true);
        await File(name).writeAsBytes(bytes);
        return name;
      } catch (_) {
        final alt = '${Directory.systemTemp.path}/abtin_subs/${p.basename(name)}';
        await Directory(p.dirname(alt)).create(recursive: true);
        await File(alt).writeAsBytes(bytes);
        return alt;
      }
    } finally {
      c.close(force: true);
    }
  }
}
