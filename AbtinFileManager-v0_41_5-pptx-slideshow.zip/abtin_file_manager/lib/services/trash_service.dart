import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'file_ops.dart';
import 'native.dart';
import 'saf.dart';
import 'folder_sizes.dart';

class TrashEntry {
  final String id, root, name, orig;
  final DateTime time;
  final bool isDir;
  int size; // -1 = not computed yet (folders)
  TrashEntry(this.id, this.root, this.name, this.orig, this.time, this.isDir, this.size);
  String get dir => p.join(root, TrashService.dirName, id);
  String get item => p.join(dir, name);
  String get meta => p.join(root, TrashService.dirName, '$id.json');
}

/// Recycle bin: one hidden `.AbtinTrash` folder on every storage volume,
/// so moving an item in is an instant rename.
class TrashService {
  static const dirName = '.AbtinTrash';
  static int _n = 0;

  static String _m(Object x) {
    if (x is FileSystemException) return x.osError?.message ?? x.message;
    if (x is OpError) return x.arg ?? x.key;
    return '$x';
  }

  static String volumeOf(String path) {
    for (final r in FileOps.roots()) {
      if (p.equals(r.path, path) || p.isWithin(r.path, path)) return r.path;
    }
    return FileOps.root;
  }

  static bool isInTrash(String path) => p.split(path).contains(dirName);

  static Future<List<String>> _files(String path, bool isDir) async {
    if (!isDir) return [path];
    final out = <String>[];
    await for (final f in FileOps.walk(path, hidden: true)) {
      out.add(f.path);
      if (out.length >= 5000) break;
    }
    return out;
  }

  static Future<void> _scan(List<String> l) async {
    for (var i = 0; i < l.length; i += 400) {
      await Native.scanMany(l.sublist(i, (i + 400).clamp(0, l.length)));
    }
  }

  /// Throws [OpError] `trashFail` when the item cannot be moved into the bin.
  static Future<TrashEntry> moveToTrash(FileSystemEntity e) async {
    final t = FileSystemEntity.typeSync(e.path, followLinks: false);
    if (t == FileSystemEntityType.notFound) throw OpError('delFail', p.basename(e.path));
    final isDir = t == FileSystemEntityType.directory;
    FolderSizes.invalidate(e.path);
    final root = volumeOf(e.path);
    final base = p.join(root, dirName);
    final id = '${DateTime.now().microsecondsSinceEpoch}${_n++}';
    final name = p.basename(e.path);
    final dir = p.join(base, id);
    final saf = await Saf.use(e.path);
    try {
      final nm = File(p.join(base, '.nomedia'));
      if (saf) {
        await Saf.mkdirs(dir);
        if (!nm.existsSync()) await Saf.createFile(nm.path);
      } else {
        await Directory(dir).create(recursive: true);
        if (!nm.existsSync()) await nm.create();
      }
    } catch (x) {
      throw OpError('trashFail', _m(x));
    }
    final gone = await _files(e.path, isDir);
    final dst = p.join(dir, name);
    try {
      if (saf) {
        await Saf.move(e.path, dir, name);
      } else if (t == FileSystemEntityType.link) {
        await Link(e.path).rename(dst);
      } else if (isDir) {
        await Directory(e.path).rename(dst);
      } else {
        await File(e.path).rename(dst);
      }
    } catch (x) {
      try {
        if (saf) {
          await Saf.delete(dir);
        } else {
          await Directory(dir).delete(recursive: true);
        }
      } catch (_) {}
      throw OpError('trashFail', _m(x));
    }
    var size = -1;
    if (!isDir) {
      try { size = await File(dst).length(); } catch (_) { size = 0; }
    }
    final entry = TrashEntry(id, root, name, e.path, DateTime.now(), isDir, size);
    final meta = jsonEncode({
      'name': name, 'orig': e.path, 'time': entry.time.millisecondsSinceEpoch, 'dir': isDir, 'size': size,
    });
    if (saf) {
      await Saf.writeText(entry.meta, meta);
    } else {
      await File(entry.meta).writeAsString(meta);
    }
    await _scan(gone);
    return entry;
  }

  static Future<List<TrashEntry>> list() async {
    final out = <TrashEntry>[];
    for (final r in FileOps.roots()) {
      final base = Directory(p.join(r.path, dirName));
      if (!base.existsSync()) continue;
      try {
        await for (final m in base.list(followLinks: false)) {
          if (m is! File || !m.path.endsWith('.json')) continue;
          try {
            final j = jsonDecode(await m.readAsString()) as Map<String, dynamic>;
            final e = TrashEntry(
              p.basenameWithoutExtension(m.path), r.path, j['name'] as String, j['orig'] as String,
              DateTime.fromMillisecondsSinceEpoch((j['time'] as num).toInt()), j['dir'] == true, (j['size'] as num).toInt(),
            );
            if (FileSystemEntity.typeSync(e.item, followLinks: false) == FileSystemEntityType.notFound) {
              try { await m.delete(); } catch (_) {}
              continue;
            }
            out.add(e);
          } catch (_) {}
        }
      } catch (_) {}
    }
    out.sort((a, b) => b.time.compareTo(a.time));
    return out;
  }

  static Future<void> _cleanup(TrashEntry e) async {
    if (await Saf.use(e.dir)) {
      try { await Saf.delete(e.dir); } catch (_) {}
      try { await Saf.delete(e.meta); } catch (_) {}
      return;
    }
    try { await Directory(e.dir).delete(recursive: true); } catch (_) {}
    try { await File(e.meta).delete(); } catch (_) {}
  }

  /// Puts the item back where it came from (a free name is chosen on clashes).
  static Future<void> restore(TrashEntry e) async {
    final parent = p.dirname(e.orig);
    FolderSizes.invalidate(e.orig);
    final saf = await Saf.use(e.orig);
    if (saf) {
      await Saf.mkdirs(parent);
    } else {
      await Directory(parent).create(recursive: true);
    }
    final target = FileOps.exists(e.orig) ? FileOps.unique(parent, e.name) : e.orig;
    final src = e.item;
    final t = FileSystemEntity.typeSync(src, followLinks: false);
    try {
      if (saf) {
        await Saf.move(src, parent, p.basename(target));
      } else if (t == FileSystemEntityType.link) {
        await Link(src).rename(target);
      } else if (t == FileSystemEntityType.directory) {
        await Directory(src).rename(target);
      } else {
        await File(src).rename(target);
      }
    } on FileSystemException {
      final ent = t == FileSystemEntityType.directory ? Directory(src) as FileSystemEntity : File(src);
      await FileOps.move(ent, parent);
    }
    await _cleanup(e);
    await _scan(await _files(target, e.isDir));
  }

  static Future<void> purge(TrashEntry e) => _cleanup(e);

  static Future<int> empty() async {
    final l = await list();
    for (final e in l) {
      await purge(e);
    }
    return l.length;
  }
}
