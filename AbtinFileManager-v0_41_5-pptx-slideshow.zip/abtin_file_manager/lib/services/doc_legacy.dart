import 'dart:convert';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'ole.dart';

/// Minimal reader for legacy Word 97-2003 (.doc, OLE2/CFB) files: extracts the
/// main-document text via the FIB + piece table (CLX). Formatting is not kept.
class DocLegacy {
  static const _free = 0xFFFFFFFF, _endOfChain = 0xFFFFFFFE;
  static const _cp1252 = <int, int>{
    0x80: 0x20AC,
    0x82: 0x201A,
    0x83: 0x0192,
    0x84: 0x201E,
    0x85: 0x2026,
    0x86: 0x2020,
    0x87: 0x2021,
    0x88: 0x02C6,
    0x89: 0x2030,
    0x8A: 0x0160,
    0x8B: 0x2039,
    0x8C: 0x0152,
    0x8E: 0x017D,
    0x91: 0x2018,
    0x92: 0x2019,
    0x93: 0x201C,
    0x94: 0x201D,
    0x95: 0x2022,
    0x96: 0x2013,
    0x97: 0x2014,
    0x98: 0x02DC,
    0x99: 0x2122,
    0x9A: 0x0161,
    0x9B: 0x203A,
    0x9C: 0x0153,
    0x9E: 0x017E,
    0x9F: 0x0178,
  };

  static int _win1252(int b) => _cp1252[b] ?? b;
  static bool isProtected(Uint8List b) =>
      b.length >= 5 && latin1.decode(b.sublist(0, 5)) == 'ADOC\x01';

  /// Exports editable text as Word-readable RTF stored at the original .doc path.
  /// Tab-separated lines are emitted as native RTF table rows.
  static Uint8List buildRtf(String text,
      {Map<int, int> headingLevels = const {}}) {
    String esc(String s) {
      final out = StringBuffer();
      const reverse = <int, int>{
        0x20AC: 0x80,
        0x201A: 0x82,
        0x0192: 0x83,
        0x201E: 0x84,
        0x2026: 0x85,
        0x2020: 0x86,
        0x2021: 0x87,
        0x02C6: 0x88,
        0x2030: 0x89,
        0x0160: 0x8A,
        0x2039: 0x8B,
        0x0152: 0x8C,
        0x017D: 0x8E,
        0x2018: 0x91,
        0x2019: 0x92,
        0x201C: 0x93,
        0x201D: 0x94,
        0x2022: 0x95,
        0x2013: 0x96,
        0x2014: 0x97,
        0x02DC: 0x98,
        0x2122: 0x99,
        0x0161: 0x9A,
        0x203A: 0x9B,
        0x0153: 0x9C,
        0x017E: 0x9E,
        0x0178: 0x9F,
      };
      for (final u in s.codeUnits) {
        if (u == 0x5C || u == 0x7B || u == 0x7D) {
          out.write('\\${String.fromCharCode(u)}');
        } else if (u == 0x0A) {
          out.write(r'\line ');
        } else if (u == 0x09) {
          out.write(r'\tab ');
        } else if (u >= 0x20 && u <= 0x7E) {
          out.writeCharCode(u);
        } else {
          final b = reverse[u];
          if (b != null) {
            out.write("\\'${b.toRadixString(16).padLeft(2, '0')}");
          } else {
            final signed = u > 0x7FFF ? u - 0x10000 : u;
            out.write('\\u$signed?');
          }
        }
      }
      return out.toString();
    }

    final out = StringBuffer(r'{\rtf1\ansi\ansicpg1252\uc1\deff0');
    out.write(r'{\fonttbl{\f0\fnil\fcharset0 Calibri;}}');
    out.write(
        r'{\stylesheet{\s0 Normal;}{\s1\sbasedon0\keepn\b\fs32 Heading 1;}{\s2\sbasedon0\keepn\b\fs28 Heading 2;}{\s3\sbasedon0\keepn\b\fs24 Heading 3;}}');
    final lines = text.split('\n');
    for (var i = 0; i < lines.length; i++) {
      final line = lines[i];
      if (line.contains('\t')) {
        final cells = line.split('\t');
        out.write(r'\trowd\trgaph108\trleft0');
        for (var c = 0; c < cells.length; c++) {
          out.write('\\cellx${(c + 1) * 2400}');
        }
        for (final cell in cells) {
          out.write('\\pard\\intbl ${esc(cell)}\\cell');
        }
        out.write(r'\row ');
      } else {
        final level = (headingLevels[i] ?? 0).clamp(0, 3);
        out.write('\\pard\\s$level ${esc(line)}\\par ');
      }
    }
    out.write('}');
    return Uint8List.fromList(latin1.encode(out.toString()));
  }

  /// Reads the RTF subset written by [buildRtf], including CP1252 hex and Unicode escapes.
  static String _rtfText(Uint8List bytes) {
    final s = latin1.decode(bytes);
    final start = s.indexOf(r'\pard');
    if (start < 0) return '';
    final out = StringBuffer();
    var i = start, uc = 1;
    while (i < s.length) {
      final c = s.codeUnitAt(i++);
      if (c == 0x7D) break;
      if (c == 0x7B) continue;
      if (c != 0x5C) {
        out.writeCharCode(c);
        continue;
      }
      if (i >= s.length) break;
      final n = s.codeUnitAt(i++);
      if (n == 0x5C || n == 0x7B || n == 0x7D) {
        out.writeCharCode(n);
        continue;
      }
      if (n == 0x27 && i + 1 < s.length) {
        final b = int.tryParse(s.substring(i, i + 2), radix: 16);
        if (b != null) out.writeCharCode(_win1252(b));
        i += 2;
        continue;
      }
      if (!((n >= 65 && n <= 90) || (n >= 97 && n <= 122))) continue;
      final w = StringBuffer()..writeCharCode(n);
      while (i < s.length) {
        final x = s.codeUnitAt(i);
        if (!((x >= 65 && x <= 90) || (x >= 97 && x <= 122))) break;
        w.writeCharCode(x);
        i++;
      }
      final word = w.toString();
      var sign = 1;
      if (i < s.length && s.codeUnitAt(i) == 45) {
        sign = -1;
        i++;
      }
      final numStart = i;
      while (i < s.length && s.codeUnitAt(i) >= 48 && s.codeUnitAt(i) <= 57) {
        i++;
      }
      final value =
          i > numStart ? sign * int.parse(s.substring(numStart, i)) : null;
      if (i < s.length && s.codeUnitAt(i) == 32) i++;
      switch (word) {
        case 'uc':
          if (value != null) uc = value.clamp(0, 8).toInt();
          break;
        case 'u':
          if (value != null) {
            out.writeCharCode(value & 0xFFFF);
            i = (i + uc).clamp(0, s.length).toInt();
          }
          break;
        case 'par':
        case 'line':
          out.write('\n');
          break;
        case 'tab':
        case 'cell':
          out.write('\t');
          break;
        case 'row':
          out.write('\n');
          break;
      }
    }
    var result = out.toString().replaceAll(RegExp(r'\t+\n'), '\n');
    if (result.endsWith('\n')) result = result.substring(0, result.length - 1);
    return result;
  }

  static Map<int, int> rtfHeadingLevels(Uint8List bytes) {
    final s = latin1.decode(bytes);
    final start = s.indexOf(r'\pard');
    if (start < 0) return {};
    final result = <int, int>{};
    var line = 0, inTable = false, afterPard = false;
    final re = RegExp(r'\\(trowd|row|pard|par|s)(-?\d*)');
    for (final m in re.allMatches(s, start)) {
      switch (m[1]) {
        case 'trowd':
          inTable = true;
          afterPard = false;
          break;
        case 'row':
          line++;
          inTable = false;
          afterPard = false;
          break;
        case 'pard':
          afterPard = !inTable;
          break;
        case 'par':
          line++;
          afterPard = false;
          break;
        case 's':
          final level = int.tryParse(m[2] ?? '');
          if (afterPard &&
              !inTable &&
              level != null &&
              level >= 1 &&
              level <= 3) result[line] = level;
          afterPard = false;
          break;
      }
    }
    return result;
  }

  /// Returns plain text (paragraphs separated by \n). Throws on unsupported files.
  static String extractText(Uint8List b) {
    if (b.length > 5 && latin1.decode(b.sublist(0, 5)).startsWith('{\\rtf'))
      return _rtfText(b);
    final ole = Ole.parse(b);
    Uint8List stream(String n) => ole.stream(n);

    final wd = stream('WordDocument');
    final w = ByteData.sublistView(wd);
    if (w.getUint16(0, Endian.little) != 0xA5EC)
      throw Exception('Not a Word binary document');
    final flags = w.getUint16(0x0A, Endian.little);
    if (flags & 0x0100 != 0) throw Exception('Encrypted .doc is not supported');
    final tbl = stream((flags & 0x0200) != 0 ? '1Table' : '0Table');
    final ccpText = w.getUint32(0x4C, Endian.little);
    final fcClx = w.getUint32(0x1A2, Endian.little);
    final lcbClx = w.getUint32(0x1A6, Endian.little);
    final t = ByteData.sublistView(tbl);
    var pos = fcClx;
    final end = fcClx + lcbClx;
    while (pos < end && tbl[pos] == 1) {
      pos += 3 + t.getUint16(pos + 1, Endian.little); // skip Prc
    }
    if (pos >= end || tbl[pos] != 2) throw Exception('Piece table not found');
    final lcb = t.getUint32(pos + 1, Endian.little);
    pos += 5;
    final n = (lcb - 4) ~/ 12;
    final cps = [
      for (var i = 0; i <= n; i++) t.getUint32(pos + i * 4, Endian.little)
    ];
    final pcd = pos + (n + 1) * 4;
    final sb = StringBuffer();
    for (var i = 0; i < n; i++) {
      var cnt = cps[i + 1] - cps[i];
      if (cps[i] >= ccpText) break;
      if (cps[i] + cnt > ccpText) cnt = ccpText - cps[i];
      final fc = t.getUint32(pcd + i * 8 + 2, Endian.little);
      if (fc & 0x40000000 != 0) {
        final o = (fc & 0x3FFFFFFF) ~/ 2;
        if (o + cnt <= wd.length)
          sb.write(String.fromCharCodes(
              [for (final v in wd.sublist(o, o + cnt)) _win1252(v)]));
      } else {
        if (fc + cnt * 2 <= wd.length) {
          sb.write(String.fromCharCodes(Uint16List.fromList([
            for (var k = 0; k < cnt; k++) w.getUint16(fc + k * 2, Endian.little)
          ])));
        }
      }
    }
    var s = sb.toString();
    s = s
        .replaceAll(RegExp(r'\x13[^\x14\x15]*\x14'), '')
        .replaceAll(RegExp(r'[\x13\x14\x15]'), ''); // fields: keep result
    s = s
        .replaceAll('\r\x07', '\t')
        .replaceAll('\x07', '\t')
        .replaceAll('\r', '\n')
        .replaceAll('\x0B', '\n')
        .replaceAll('\x0C', '\n');
    s = s.replaceAll(RegExp(r'[\x00-\x08\x0E-\x1F]'), '');
    return s;
  }

  /// Builds a minimal valid .docx from plain-text paragraphs.
  static List<int> buildDocx(String text,
      {Map<int, int> headingLevels = const {}}) {
    final paras = text.split('\n').asMap().entries.map((entry) {
      final i = entry.key, l = entry.value;
      final rtl = RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(l);
      return _paraXml(DocPara(
          rtl: rtl, heading: (headingLevels[i] ?? 0).clamp(0, 3).toInt())
        ..runs.add(DocRun(l)));
    }).join();
    return _pack(paras);
  }

  /// Builds a .docx that keeps bold / italic / underline / size / colour / alignment / direction.
  static List<int> buildDocxFormatted(List<DocPara> ps) =>
      _pack(ps.map(_paraXml).join());

  static String _esc(String s) => s
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;');

  static String _paraXml(DocPara p) {
    final ppr = StringBuffer();
    if (p.heading > 0)
      ppr.write(
          '<w:pStyle w:val="Heading${p.heading}"/><w:keepNext/><w:outlineLvl w:val="${p.heading - 1}"/>');
    if (p.rtl) ppr.write('<w:bidi/>');
    if (p.jc != 0)
      ppr.write('<w:jc w:val="${const [
        'left',
        'center',
        'right',
        'both'
      ][p.jc.clamp(0, 3)]}"/>');
    final b = StringBuffer('<w:p>');
    if (ppr.isNotEmpty) b.write('<w:pPr>$ppr</w:pPr>');
    for (final r in p.runs) {
      final rpr = StringBuffer();
      if (r.b) rpr.write('<w:b/><w:bCs/>');
      if (r.i) rpr.write('<w:i/><w:iCs/>');
      if (r.color != null)
        rpr.write(
            '<w:color w:val="${r.color!.toRadixString(16).padLeft(6, '0').toUpperCase()}"/>');
      if (r.sz > 0)
        rpr.write('<w:sz w:val="${r.sz}"/><w:szCs w:val="${r.sz}"/>');
      if (r.u) rpr.write('<w:u w:val="single"/>');
      if (p.rtl || RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(r.text))
        rpr.write('<w:rtl/>');
      final head = rpr.isEmpty ? '' : '<w:rPr>$rpr</w:rPr>';
      final buf = StringBuffer();
      void flush() {
        if (buf.isEmpty) return;
        b.write(
            '<w:r>$head<w:t xml:space="preserve">${_esc(buf.toString())}</w:t></w:r>');
        buf.clear();
      }

      for (final ch in r.text.split('')) {
        if (ch == '\t') {
          flush();
          b.write('<w:r>$head<w:tab/></w:r>');
        } else if (ch == '\n') {
          flush();
          b.write('<w:r>$head<w:br/></w:r>');
        } else {
          buf.write(ch);
        }
      }
      flush();
    }
    b.write('</w:p>');
    return b.toString();
  }

  static List<int> _pack(String paras) {
    const ns =
        'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"';
    final files = <String, String>{
      '[Content_Types].xml':
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>',
      '_rels/.rels':
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>',
      'word/document.xml':
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document $ns><w:body>$paras<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>',
      'word/_rels/document.xml.rels':
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
      'word/styles.xml':
          '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles $ns><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:keepNext/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:sz w:val="32"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:keepNext/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:sz w:val="28"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:keepNext/><w:outlineLvl w:val="2"/></w:pPr><w:rPr><w:b/><w:sz w:val="24"/></w:rPr></w:style></w:styles>',
    };
    final arc = Archive();
    files.forEach((k, v) {
      final bytes = utf8.encode(v);
      arc.addFile(ArchiveFile(k, bytes.length, bytes));
    });
    return ZipEncoder().encode(arc)!;
  }

  // ------------------------------------------------------------ formatted extraction (CHPX / PAPX)
  static const _ico = [
    0,
    0x000000,
    0x0000FF,
    0x00FFFF,
    0x00FF00,
    0xFF00FF,
    0xFF0000,
    0xFFFF00,
    0xFFFFFF,
    0x000080,
    0x008080,
    0x008000,
    0x800080,
    0x800000,
    0x808000,
    0x808080,
    0xC0C0C0
  ];

  static void _sprms(
      Uint8List d, int s, int e, void Function(int op, int pos) f) {
    var pos = s;
    final bd = ByteData.sublistView(d);
    while (pos + 2 <= e) {
      final op = bd.getUint16(pos, Endian.little);
      pos += 2;
      int len;
      switch (op >> 13) {
        case 0:
        case 1:
          len = 1;
          break;
        case 2:
        case 4:
        case 5:
          len = 2;
          break;
        case 3:
          len = 4;
          break;
        case 7:
          len = 3;
          break;
        default:
          if (pos >= e) return;
          len =
              op == 0xD608 ? bd.getUint16(pos, Endian.little) + 1 : d[pos] + 1;
      }
      if (pos + len > e) return;
      f(op, pos);
      pos += len;
    }
  }

  /// Paragraphs with run formatting. Style-sheet based formatting (e.g. heading styles) is not resolved.
  static List<DocPara> extractFormatted(Uint8List bytes) {
    if (bytes.length > 5 &&
        latin1.decode(bytes.sublist(0, 5)).startsWith('{\\rtf')) {
      final levels = rtfHeadingLevels(bytes);
      return _rtfText(bytes)
          .split('\n')
          .asMap()
          .entries
          .map((e) =>
              DocPara(heading: levels[e.key] ?? 0)..runs.add(DocRun(e.value)))
          .toList();
    }
    final ole = Ole.parse(bytes);
    final wd = ole.stream('WordDocument');
    final w = ByteData.sublistView(wd);
    if (w.getUint16(0, Endian.little) != 0xA5EC)
      throw Exception('Not a Word binary document');
    final flags = w.getUint16(0x0A, Endian.little);
    if (flags & 0x0100 != 0) throw Exception('Encrypted .doc is not supported');
    final tbl = ole.stream((flags & 0x0200) != 0 ? '1Table' : '0Table');
    final t = ByteData.sublistView(tbl);
    final ccpText = w.getUint32(0x4C, Endian.little);
    final fcClx = w.getUint32(0x1A2, Endian.little);
    final lcbClx = w.getUint32(0x1A6, Endian.little);
    var pos = fcClx;
    final end = fcClx + lcbClx;
    while (pos < end && tbl[pos] == 1) {
      pos += 3 + t.getUint16(pos + 1, Endian.little);
    }
    if (pos >= end || tbl[pos] != 2) throw Exception('Piece table not found');
    final lcb = t.getUint32(pos + 1, Endian.little);
    pos += 5;
    final n = (lcb - 4) ~/ 12;
    final cps = [
      for (var i = 0; i <= n; i++) t.getUint32(pos + i * 4, Endian.little)
    ];
    final pcd = pos + (n + 1) * 4;
    // pieces: cpStart, cpEnd, byte offset of first char, bytes per char
    final pcs = <List<int>>[];
    final raw = List<int>.filled(ccpText, 0x20);
    for (var i = 0; i < n; i++) {
      var cs = cps[i], ce = cps[i + 1];
      if (cs >= ccpText) break;
      if (ce > ccpText) ce = ccpText;
      final fc = t.getUint32(pcd + i * 8 + 2, Endian.little);
      final comp = fc & 0x40000000 != 0;
      final off = comp ? (fc & 0x3FFFFFFF) ~/ 2 : fc;
      final bpc = comp ? 1 : 2;
      pcs.add([cs, ce, off, bpc]);
      for (var k = 0; k < ce - cs; k++) {
        final o = off + k * bpc;
        if (o + bpc > wd.length) break;
        raw[cs + k] = comp ? _win1252(wd[o]) : w.getUint16(o, Endian.little);
      }
    }
    int? cpOfFc(int fc) {
      for (final p in pcs) {
        final len = (p[1] - p[0]) * p[3];
        if (fc >= p[2] && fc < p[2] + len) return p[0] + (fc - p[2]) ~/ p[3];
      }
      return null;
    }

    int? fcOfCp(int cp) {
      for (final p in pcs) {
        if (cp >= p[0] && cp < p[1]) return p[2] + (cp - p[0]) * p[3];
      }
      return null;
    }

    // character formatting
    final props = <DocRun>[DocRun('')];
    final fmtId = Uint32List(ccpText);
    final fcChpx = w.getUint32(0xFA, Endian.little),
        lcbChpx = w.getUint32(0xFE, Endian.little);
    try {
      final nb = (lcbChpx - 4) ~/ 8;
      for (var b = 0; b < nb; b++) {
        final pn = t.getUint32(fcChpx + (nb + 1) * 4 + b * 4, Endian.little);
        final po = pn * 512;
        if (po + 512 > wd.length) continue;
        final page = Uint8List.sublistView(wd, po, po + 512);
        final pg = ByteData.sublistView(page);
        final crun = page[511];
        for (var i = 0; i < crun; i++) {
          final off = page[(crun + 1) * 4 + i] * 2;
          if (off == 0) continue;
          final cb = page[off];
          final r = DocRun('');
          _sprms(page, off + 1, off + 1 + cb, (op, p) {
            switch (op) {
              case 0x0835:
              case 0x085C:
                r.b = page[p] == 1 || page[p] == 0x81;
                break;
              case 0x0836:
              case 0x085D:
                r.i = page[p] == 1 || page[p] == 0x81;
                break;
              case 0x2A3E:
                r.u = page[p] != 0;
                break;
              case 0x4A43:
              case 0x4A61:
                r.sz = pg.getUint16(p, Endian.little);
                break;
              case 0x2A42:
                if (page[p] > 0 && page[p] < _ico.length)
                  r.color = _ico[page[p]];
                break;
              case 0x6870:
                if (page[p + 3] == 0)
                  r.color = (page[p] << 16) | (page[p + 1] << 8) | page[p + 2];
                break;
            }
          });
          if (!r.b && !r.i && !r.u && r.sz == 0 && r.color == null) continue;
          props.add(r);
          final id = props.length - 1;
          final fa = pg.getUint32(i * 4, Endian.little),
              fb = pg.getUint32((i + 1) * 4, Endian.little);
          for (final p in pcs) {
            final lo = fa > p[2] ? fa : p[2];
            final hi = fb < p[2] + (p[1] - p[0]) * p[3]
                ? fb
                : p[2] + (p[1] - p[0]) * p[3];
            if (lo >= hi) continue;
            final c0 = p[0] + (lo - p[2]) ~/ p[3],
                c1 = p[0] + (hi - p[2] + p[3] - 1) ~/ p[3];
            for (var c = c0; c < c1 && c < ccpText; c++) {
              fmtId[c] = id;
            }
          }
        }
      }
    } catch (_) {}

    // paragraph formatting: fc range -> (jc, bidi)
    final pRuns = <List<int>>[]; // fa, fb, jc, bidi
    final fcPapx = w.getUint32(0x102, Endian.little),
        lcbPapx = w.getUint32(0x106, Endian.little);
    try {
      final nb = (lcbPapx - 4) ~/ 8;
      for (var b = 0; b < nb; b++) {
        final pn = t.getUint32(fcPapx + (nb + 1) * 4 + b * 4, Endian.little);
        final po = pn * 512;
        if (po + 512 > wd.length) continue;
        final page = Uint8List.sublistView(wd, po, po + 512);
        final pg = ByteData.sublistView(page);
        final crun = page[511];
        for (var i = 0; i < crun; i++) {
          final off = page[(crun + 1) * 4 + i * 13] * 2;
          var jc = 0, bidi = 0;
          if (off != 0) {
            var cb = page[off], st = off + 1;
            if (cb == 0) {
              cb = page[off + 1] * 2;
              st = off + 2;
            } else {
              cb = cb * 2 - 1;
            }
            _sprms(page, st + 2, st + cb, (op, p) {
              if (op == 0x2461 || op == 0x2403) jc = page[p];
              if (op == 0x2441) bidi = page[p];
            });
          }
          pRuns.add([
            pg.getUint32(i * 4, Endian.little),
            pg.getUint32((i + 1) * 4, Endian.little),
            jc,
            bidi
          ]);
        }
      }
    } catch (_) {}

    // build paragraphs
    final out = <DocPara>[];
    var cur = DocPara();
    var curStart = 0;
    final codeStack = <bool>[];
    void finish(int endCp) {
      final fc = fcOfCp(curStart);
      if (fc != null) {
        for (final r in pRuns) {
          if (fc >= r[0] && fc < r[1]) {
            cur.jc = r[2];
            cur.rtl = r[3] == 1;
            break;
          }
        }
      }
      if (!cur.rtl) {
        final txt = cur.runs.map((r) => r.text).join();
        if (RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(txt) &&
            !RegExp(r'[A-Za-z]').hasMatch(txt)) cur.rtl = true;
      }
      out.add(cur);
      cur = DocPara();
      curStart = endCp + 1;
    }

    void put(String ch, int id) {
      final base = props[id];
      if (cur.runs.isNotEmpty) {
        final l = cur.runs.last;
        if (l.b == base.b &&
            l.i == base.i &&
            l.u == base.u &&
            l.sz == base.sz &&
            l.color == base.color) {
          l.text += ch;
          return;
        }
      }
      cur.runs.add(DocRun(ch,
          b: base.b, i: base.i, u: base.u, sz: base.sz, color: base.color));
    }

    for (var cp = 0; cp < ccpText; cp++) {
      final c = raw[cp];
      if (c == 0x13) {
        codeStack.add(true);
        continue;
      }
      if (c == 0x14) {
        if (codeStack.isNotEmpty) codeStack[codeStack.length - 1] = false;
        continue;
      }
      if (c == 0x15) {
        if (codeStack.isNotEmpty) codeStack.removeLast();
        continue;
      }
      if (codeStack.contains(true)) continue;
      if (c == 0x0D) {
        finish(cp);
      } else if (c == 0x07) {
        put('\t', fmtId[cp]);
      } else if (c == 0x0B || c == 0x0C) {
        put('\n', fmtId[cp]);
      } else if (c == 0x1E) {
        put('-', fmtId[cp]);
      } else if (c < 0x20 && c != 0x09) {
        continue;
      } else {
        put(String.fromCharCode(c), fmtId[cp]);
      }
    }
    if (cur.runs.isNotEmpty) finish(ccpText);
    return out;
  }
}

class DocRun {
  String text;
  bool b, i, u;
  int sz; // half-points, 0 = default
  int? color;
  DocRun(this.text,
      {this.b = false,
      this.i = false,
      this.u = false,
      this.sz = 0,
      this.color});
}

class DocPara {
  final runs = <DocRun>[];
  int jc = 0; // 0 start, 1 center, 2 end, 3 justify
  int heading; // 0 normal, 1..3 built-in heading styles
  bool rtl;
  DocPara({this.rtl = false, this.heading = 0});
  String get text => runs.map((r) => r.text).join();
}
