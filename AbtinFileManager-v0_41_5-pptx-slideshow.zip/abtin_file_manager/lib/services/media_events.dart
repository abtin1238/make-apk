import 'dart:async';
import 'thumbs.dart';

/// App-wide "a media file was deleted / restored" events, so every open list
/// (gallery, albums, file browser) drops or re-adds it at once, even while the viewer is still on top.
class MediaEvents {
  static final _del = StreamController<Set<String>>.broadcast();
  static final _res = StreamController<String>.broadcast();

  static Stream<Set<String>> get onDeleted => _del.stream;
  static Stream<String> get onRestored => _res.stream;

  /// Call right after files were removed (or moved to the trash).
  static void deleted(Iterable<String> paths) {
    final s = paths.toSet();
    if (s.isEmpty) return;
    for (final p in s) {
      Thumbs.evict(p);
    }
    _del.add(s);
  }

  /// Call after a file was put back (trash "Undo").
  static void restored(String path) => _res.add(path);
}
