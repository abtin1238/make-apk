import 'dart:io';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'file_ops.dart';

class DupFile {
  final String path;
  final int size;
  final DateTime modified;
  const DupFile(this.path, this.size, this.modified);
}

class DupGroup {
  final int size;
  final List<DupFile> files;
  DupGroup(this.size, this.files);
  int get wasted => size * (files.length - 1);
}

class _Stop implements Exception {
  const _Stop();
}

/// Finds files with identical content: size -> first/last 64 KB fingerprint -> full SHA-1.
class DupService {
  static const _edge = 64 * 1024;

  static Future<List<DupGroup>> scan(
    String dir, {
    int minSize = 1,
    bool hidden = false,
    void Function(String phase, double? v)? onProgress,
    bool Function()? cancelled,
  }) async {
    bool stop() => cancelled?.call() == true;

    // 1) group by size
    final bySize = <int, List<DupFile>>{};
    var seen = 0;
    await for (final f in FileOps.walk(dir, hidden: hidden, skipAndroid: true)) {
      if (stop()) return [];
      try {
        final s = await f.stat();
        if (s.size >= minSize) (bySize[s.size] ??= []).add(DupFile(f.path, s.size, s.modified));
      } catch (_) {}
      if (++seen % 200 == 0) {
        onProgress?.call('list', null);
        await Future<void>.delayed(Duration.zero);
      }
    }
    final cand = bySize.values.where((l) => l.length > 1).toList();

    // 2) cheap fingerprint of head + tail
    final byEdge = <String, List<DupFile>>{};
    var i = 0;
    final n = cand.fold<int>(0, (a, l) => a + l.length);
    for (final l in cand) {
      for (final f in l) {
        if (stop()) return [];
        final k = await _edgeKey(f);
        if (k != null) (byEdge[k] ??= []).add(f);
        if (++i % 20 == 0) {
          onProgress?.call('quick', n == 0 ? 1 : i / n);
          await Future<void>.delayed(Duration.zero);
        }
      }
    }
    final cand2 = byEdge.values.where((l) => l.length > 1).toList();

    // 3) full hash
    final total = cand2.fold<int>(0, (a, l) => a + l.fold<int>(0, (b, f) => b + f.size));
    var done = 0;
    final sw = Stopwatch()..start();
    final out = <DupGroup>[];
    try {
      for (final l in cand2) {
        final byHash = <String, List<DupFile>>{};
        for (final f in l) {
          if (stop()) return [];
          final h = await _fullHash(f.path, (c) {
            if (stop()) throw const _Stop();
            done += c;
            if (sw.elapsedMilliseconds > 100) {
              sw.reset();
              onProgress?.call('hash', total == 0 ? 1 : done / total);
            }
          });
          if (h != null) (byHash[h] ??= []).add(f);
        }
        for (final g in byHash.values) {
          if (g.length > 1) {
            g.sort((a, b) => a.modified.compareTo(b.modified));
            out.add(DupGroup(g.first.size, g));
          }
        }
      }
    } on _Stop {
      return [];
    }
    out.sort((a, b) => b.wasted.compareTo(a.wasted));
    return out;
  }

  static Future<String?> _edgeKey(DupFile f) async {
    RandomAccessFile? r;
    try {
      r = await File(f.path).open();
      final head = await r.read(_edge);
      Uint8List tail = Uint8List(0);
      if (f.size > _edge * 2) {
        await r.setPosition(f.size - _edge);
        tail = await r.read(_edge);
      }
      final d = md5.convert([...head, ...tail]);
      return '${f.size}:$d';
    } catch (_) {
      return null;
    } finally {
      await r?.close();
    }
  }

  static Future<String?> _fullHash(String path, void Function(int) onChunk) async {
    try {
      final s = File(path).openRead().map((c) {
        onChunk(c.length);
        return c;
      });
      return (await sha1.bind(s).first).toString();
    } on _Stop {
      rethrow;
    } catch (_) {
      return null;
    }
  }
}
