import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Remembers playback position of videos / long audio ("continue watching").
class MediaStore {
  static SharedPreferences? _p;
  static final Map<String, List<int>> _pos = {}; // path -> [positionMs, durationMs]

  static Future<void> init() async {
    _p = await SharedPreferences.getInstance();
    try {
      final m = jsonDecode(_p!.getString('mpos') ?? '{}') as Map;
      m.forEach((k, v) => _pos[k as String] = (v as List).map((e) => (e as num).toInt()).toList());
    } catch (_) {}
  }

  static Map<String, List<int>> get all => _pos;
  static List<int>? state(String path) => _pos[path];

  static void savePos(String path, Duration pos, Duration dur) {
    if (dur.inSeconds < 1) return;
    if (pos.inSeconds < 5 || dur - pos < const Duration(seconds: 10)) {
      _pos.remove(path);
    } else {
      _pos.remove(path); // keep most recent last
      _pos[path] = [pos.inMilliseconds, dur.inMilliseconds];
    }
    while (_pos.length > 300) {
      _pos.remove(_pos.keys.first);
    }
    _p?.setString('mpos', jsonEncode(_pos));
  }

  static void clear(String path) {
    _pos.remove(path);
    _p?.setString('mpos', jsonEncode(_pos));
  }
}
