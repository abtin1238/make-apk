import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class RemoteError implements Exception {
  final String msg;
  const RemoteError(this.msg);
  @override
  String toString() => msg;
}

class RemoteEntry {
  final String name;
  final bool dir;
  final int? size;
  final DateTime? modified;
  const RemoteEntry(this.name, this.dir, {this.size, this.modified});
}

typedef Prog = void Function(int done, int total);

/// Posix-style remote paths: always absolute, '/' separated.
class RPath {
  static String join(String a, String b) => a == '/' || a.isEmpty ? '/$b' : (a.endsWith('/') ? '$a$b' : '$a/$b');
  static String parent(String p) {
    final t = p.endsWith('/') && p.length > 1 ? p.substring(0, p.length - 1) : p;
    final i = t.lastIndexOf('/');
    return i <= 0 ? '/' : t.substring(0, i);
  }

  static String name(String p) {
    final t = p.endsWith('/') && p.length > 1 ? p.substring(0, p.length - 1) : p;
    return t.substring(t.lastIndexOf('/') + 1);
  }

  static List<String> segs(String p) => p.split('/').where((s) => s.isNotEmpty).toList();
}

abstract class RemoteFs {
  /// Start directory after connect.
  String home = '/';
  Future<void> connect();
  Future<List<RemoteEntry>> list(String path);
  Future<void> download(String path, String local, {Prog? onProgress});
  Future<void> upload(String local, String path, {Prog? onProgress});
  Future<void> mkdir(String path);
  Future<void> delete(String path, bool dir);
  Future<void> rename(String from, String to);
  Future<void> close();

  /// Delete a folder with everything inside.
  Future<void> deleteTree(String path, bool dir) async {
    if (dir) {
      for (final e in await list(path)) {
        await deleteTree(RPath.join(path, e.name), e.dir);
      }
    }
    await delete(path, dir);
  }
}

class RemoteProfile {
  String id, name, type; // ftp sftp smb webdav dropbox gdrive
  String host, user, pass, path, extra;
  int port;
  bool savePass, flag; // flag: ftp=FTPES, webdav=accept any certificate
  RemoteProfile({
    required this.id,
    this.name = '',
    this.type = 'ftp',
    this.host = '',
    this.user = '',
    this.pass = '',
    this.path = '/',
    this.extra = '',
    this.port = 21,
    this.savePass = false,
    this.flag = false,
  });

  static const types = ['ftp', 'sftp', 'smb', 'webdav', 'dropbox', 'gdrive'];
  static int defaultPort(String t) => const {'ftp': 21, 'sftp': 22, 'smb': 445, 'webdav': 443}[t] ?? 0;
  bool get cloud => type == 'dropbox' || type == 'gdrive';

  Map<String, dynamic> toJson() => {
        'id': id, 'name': name, 'type': type, 'host': host, 'user': user,
        'pass': savePass ? pass : '', 'path': path, 'extra': extra, 'port': port, 'sp': savePass, 'flag': flag,
      };

  static RemoteProfile fromJson(Map m) => RemoteProfile(
        id: '${m['id']}', name: '${m['name'] ?? ''}', type: '${m['type'] ?? 'ftp'}', host: '${m['host'] ?? ''}',
        user: '${m['user'] ?? ''}', pass: '${m['pass'] ?? ''}', path: '${m['path'] ?? '/'}', extra: '${m['extra'] ?? ''}',
        port: (m['port'] as num?)?.toInt() ?? 21, savePass: m['sp'] == true, flag: m['flag'] == true,
      );
}

class RemoteStore {
  static const _k = 'remoteProfiles';

  static Future<List<RemoteProfile>> load() async {
    final p = await SharedPreferences.getInstance();
    try {
      final l = jsonDecode(p.getString(_k) ?? '[]') as List;
      return [for (final m in l) RemoteProfile.fromJson(m as Map)];
    } catch (_) {
      return [];
    }
  }

  static Future<void> save(List<RemoteProfile> l) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_k, jsonEncode([for (final e in l) e.toJson()]));
  }

  static Future<void> remove(RemoteProfile pr) async {
    final l = await load();
    l.removeWhere((e) => e.id == pr.id);
    await save(l);
    final p = await SharedPreferences.getInstance();
    await p.remove('tok_${pr.id}');
  }
}
