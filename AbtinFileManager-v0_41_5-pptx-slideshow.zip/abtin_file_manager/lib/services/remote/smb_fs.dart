import 'dart:io';
import 'package:smb_connect/smb_connect.dart';
import 'remote_fs.dart';

/// SMB / CIFS (pure Dart, package smb_connect). Root '/' lists the shares.
/// Member access goes through `dynamic` with fallbacks because the package API is young.
class SmbFs extends RemoteFs {
  final RemoteProfile pr;
  SmbConnect? _c;
  SmbFs(this.pr);

  @override
  Future<void> connect() async {
    _c = await SmbConnect.connectAuth(
      host: pr.host,
      domain: pr.extra,
      username: pr.user.isEmpty ? 'guest' : pr.user,
      password: pr.pass,
    );
    home = pr.path.isEmpty ? '/' : pr.path;
  }

  String _dir(String path) => path == '/' ? '/' : (path.endsWith('/') ? path : '$path/');

  static String _nameOf(dynamic f) {
    String s = '';
    try {
      s = '${f.path}';
    } catch (_) {}
    while (s.length > 1 && s.endsWith('/')) {
      s = s.substring(0, s.length - 1);
    }
    return s.substring(s.lastIndexOf('/') + 1);
  }

  static bool _isDir(dynamic f) {
    try {
      return f.isDirectory() == true;
    } catch (_) {
      return '${f.path}'.endsWith('/');
    }
  }

  static int? _size(dynamic f) {
    try {
      return (f.size as num?)?.toInt();
    } catch (_) {
      return null;
    }
  }

  static DateTime? _mod(dynamic f) {
    try {
      final m = (f.lastModified as num?)?.toInt();
      return m == null || m <= 0 ? null : DateTime.fromMillisecondsSinceEpoch(m);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<List<RemoteEntry>> list(String path) async {
    if (path == '/') {
      final shares = await _c!.listShares();
      return [for (final s in shares) RemoteEntry(_nameOf(s), true)];
    }
    final folder = await _c!.file(_dir(path));
    final l = await _c!.listFiles(folder);
    return [
      for (final f in l)
        if (_nameOf(f).isNotEmpty && _nameOf(f) != '.' && _nameOf(f) != '..')
          RemoteEntry(_nameOf(f), _isDir(f), size: _isDir(f) ? null : _size(f), modified: _mod(f)),
    ];
  }

  @override
  Future<void> download(String path, String local, {Prog? onProgress}) async {
    final f = await _c!.file(path);
    final total = _size(f) ?? 0;
    final sink = File(local).openWrite();
    var got = 0;
    try {
      await for (final chunk in await _c!.openRead(f)) {
        sink.add(chunk);
        got += chunk.length;
        onProgress?.call(got, total);
      }
    } finally {
      await sink.close();
    }
  }

  @override
  Future<void> upload(String local, String path, {Prog? onProgress}) async {
    final len = await File(local).length();
    final f = await _c!.createFile(path);
    final w = await _c!.openWrite(f);
    var sent = 0;
    try {
      await for (final chunk in File(local).openRead()) {
        w.add(chunk);
        sent += chunk.length;
        onProgress?.call(sent, len);
      }
      await w.flush();
    } finally {
      await w.close();
    }
  }

  @override
  Future<void> mkdir(String path) async {
    await _c!.createFolder(_dir(path));
  }

  @override
  Future<void> delete(String path, bool dir) async {
    final f = await _c!.file(dir ? _dir(path) : path);
    await _c!.delete(f);
  }

  @override
  Future<void> rename(String from, String to) async {
    final f = await _c!.file(from);
    await _c!.rename(f, to);
  }

  @override
  Future<void> close() async {
    try {
      await _c?.close();
    } catch (_) {}
    _c = null;
  }
}
