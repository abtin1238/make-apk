import 'dart:io';
import 'dart:typed_data';
import 'package:dartssh2/dartssh2.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'remote_fs.dart';

/// SFTP over SSH (dartssh2). Password or PEM private key (profile.extra).
/// Host key: trusted on first use, refused when it changes later.
class SftpFs extends RemoteFs {
  final RemoteProfile pr;
  SSHClient? _c;
  SftpClient? _s;
  SftpFs(this.pr);

  static String _hex(Uint8List b) => b.map((e) => e.toRadixString(16).padLeft(2, '0')).join(':');

  @override
  Future<void> connect() async {
    final prefs = await SharedPreferences.getInstance();
    final hkKey = 'hk_${pr.host}:${pr.port}';
    var changed = false;
    final sock = await SSHSocket.connect(pr.host, pr.port, timeout: const Duration(seconds: 20));
    List<SSHKeyPair>? ids;
    if (pr.extra.trim().isNotEmpty) {
      ids = SSHKeyPair.fromPem(pr.extra.trim(), pr.pass.isEmpty ? null : pr.pass);
    }
    _c = SSHClient(
      sock,
      username: pr.user,
      identities: ids,
      onPasswordRequest: pr.pass.isEmpty || ids != null ? null : () => pr.pass,
      onVerifyHostKey: (type, fp) {
        final h = '$type ${_hex(fp)}';
        final old = prefs.getString(hkKey);
        if (old == null) {
          prefs.setString(hkKey, h);
          return true;
        }
        if (old != h) changed = true;
        return old == h;
      },
    );
    try {
      await _c!.authenticated;
    } catch (e) {
      await close();
      if (changed) throw const RemoteError('Host key changed – connection refused');
      rethrow;
    }
    _s = await _c!.sftp();
    var h = pr.path;
    if (h.isEmpty || h == '/') {
      try {
        h = await _s!.absolute('.');
      } catch (_) {
        h = '/';
      }
    }
    home = h;
  }

  @override
  Future<List<RemoteEntry>> list(String path) async {
    final items = await _s!.listdir(path);
    final out = <RemoteEntry>[];
    for (final n in items) {
      if (n.filename == '.' || n.filename == '..') continue;
      var dir = n.attr.isDirectory;
      if (n.longname.startsWith('l')) {
        try {
          dir = (await _s!.stat(RPath.join(path, n.filename))).isDirectory;
        } catch (_) {}
      }
      final t = n.attr.modifyTime;
      out.add(RemoteEntry(n.filename, dir,
          size: n.attr.size, modified: t == null ? null : DateTime.fromMillisecondsSinceEpoch(t * 1000)));
    }
    return out;
  }

  @override
  Future<void> download(String path, String local, {Prog? onProgress}) async {
    final f = await _s!.open(path);
    final total = (await f.stat()).size ?? 0;
    final sink = File(local).openWrite();
    var got = 0;
    try {
      await for (final chunk in f.read()) {
        sink.add(chunk);
        got += chunk.length;
        onProgress?.call(got, total);
      }
    } finally {
      await sink.close();
      await f.close();
    }
  }

  @override
  Future<void> upload(String local, String path, {Prog? onProgress}) async {
    final len = await File(local).length();
    final f = await _s!.open(path, mode: SftpFileOpenMode.create | SftpFileOpenMode.write | SftpFileOpenMode.truncate);
    try {
      final w = f.write(File(local).openRead().cast<Uint8List>(), onProgress: (n) => onProgress?.call(n, len));
      await w.done;
    } finally {
      await f.close();
    }
  }

  @override
  Future<void> mkdir(String path) => _s!.mkdir(path);

  @override
  Future<void> delete(String path, bool dir) => dir ? _s!.rmdir(path) : _s!.remove(path);

  @override
  Future<void> rename(String from, String to) => _s!.rename(from, to);

  @override
  Future<void> close() async {
    try {
      _s?.close();
      _c?.close();
    } catch (_) {}
    _s = null;
    _c = null;
  }
}
