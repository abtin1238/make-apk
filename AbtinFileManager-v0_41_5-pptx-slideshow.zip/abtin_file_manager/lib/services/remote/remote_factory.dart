import 'cloud_fs.dart';
import 'ftp_fs.dart';
import 'remote_fs.dart';
import 'sftp_fs.dart';
import 'smb_fs.dart';
import 'webdav_fs.dart';

RemoteFs createRemote(RemoteProfile p) {
  switch (p.type) {
    case 'sftp': return SftpFs(p);
    case 'smb': return SmbFs(p);
    case 'webdav': return WebDavFs(p);
    case 'dropbox': return DropboxFs(p);
    case 'gdrive': return DriveFs(p);
    default: return FtpFs(p);
  }
}
