import 'dart:convert';
import 'dart:io';
import 'package:xml/xml.dart';
import 'remote_fs.dart';

/// WebDAV client on dart:io (PROPFIND / GET / PUT / MKCOL / DELETE / MOVE).
/// profile.host = full URL of the DAV root, e.g. https://cloud.example.com/remote.php/dav/files/me/
class WebDavFs extends RemoteFs {
  final RemoteProfile pr;
  late final Uri _base;
  HttpClient? _h;
  WebDavFs(this.pr);

  @override
  Future<void> connect() async {
    var u = pr.host.trim();
    if (!u.contains('://')) u = 'https://$u';
    _base = Uri.parse(u);
    _h = HttpClient()..connectionTimeout = const Duration(seconds: 20);
    if (pr.flag) _h!.badCertificateCallback = (c, h, p) => true;
    await list('/'); // verifies URL + credentials
    home = pr.path.isEmpty ? '/' : pr.path;
  }

  Uri _url(String path, {bool dir = false}) {
    final segs = [..._base.pathSegments.where((s) => s.isNotEmpty), ...RPath.segs(path)];
    if (dir) segs.add('');
    return _base.replace(pathSegments: segs, query: null);
  }

  String get _auth => 'Basic ${base64.encode(utf8.encode('${pr.user}:${pr.pass}'))}';

  Future<HttpClientResponse> _req(String method, Uri u, {Map<String, String>? headers, List<int>? body}) async {
    final r = await _h!.openUrl(method, u);
    r.headers.set('Authorization', _auth);
    headers?.forEach(r.headers.set);
    if (body != null) {
      r.headers.contentLength = body.length;
      r.add(body);
    }
    return r.close();
  }

  static Never _fail(HttpClientResponse res) {
    res.drain<void>();
    throw RemoteError(res.statusCode == 401 ? 'HTTP 401 – wrong user or password' : 'HTTP ${res.statusCode}');
  }

  static const _propBody = '<?xml version="1.0"?><d:propfind xmlns:d="DAV:"><d:prop><d:resourcetype/><d:getcontentlength/><d:getlastmodified/></d:prop></d:propfind>';

  @override
  Future<List<RemoteEntry>> list(String path) async {
    final u = _url(path, dir: true);
    final res = await _req('PROPFIND', u, headers: {'Depth': '1', 'Content-Type': 'application/xml'}, body: utf8.encode(_propBody));
    if (res.statusCode != 207 && res.statusCode != 200) _fail(res);
    final text = await utf8.decodeStream(res);
    return parseMultistatus(text, u.path);
  }

  /// Parses a PROPFIND 207 body; [selfPath] (the folder itself) is skipped.
  static List<RemoteEntry> parseMultistatus(String xml, String selfPath) {
    String norm(String s) {
      var t = Uri.decodeFull(s);
      final i = t.indexOf('://');
      if (i >= 0) {
        final j = t.indexOf('/', i + 3);
        t = j < 0 ? '/' : t.substring(j);
      }
      while (t.length > 1 && t.endsWith('/')) {
        t = t.substring(0, t.length - 1);
      }
      return t;
    }

    final self = norm(selfPath);
    final doc = XmlDocument.parse(xml);
    XmlElement? child(XmlElement e, String n) {
      for (final c in e.descendantElements) {
        if (c.name.local == n) return c;
      }
      return null;
    }

    final out = <RemoteEntry>[];
    for (final r in doc.descendantElements.where((e) => e.name.local == 'response')) {
      final href = child(r, 'href')?.innerText.trim();
      if (href == null) continue;
      final h = norm(href);
      if (h == self) continue;
      final isDir = child(r, 'resourcetype')?.descendantElements.any((e) => e.name.local == 'collection') ?? false;
      final len = int.tryParse(child(r, 'getcontentlength')?.innerText.trim() ?? '');
      DateTime? mod;
      final lm = child(r, 'getlastmodified')?.innerText.trim();
      if (lm != null && lm.isNotEmpty) {
        try {
          mod = HttpDate.parse(lm);
        } catch (_) {}
      }
      final name = h.substring(h.lastIndexOf('/') + 1);
      if (name.isEmpty) continue;
      out.add(RemoteEntry(name, isDir, size: isDir ? null : len, modified: mod));
    }
    return out;
  }

  @override
  Future<void> download(String path, String local, {Prog? onProgress}) async {
    final res = await _req('GET', _url(path));
    if (res.statusCode != 200) _fail(res);
    final total = res.contentLength;
    final sink = File(local).openWrite();
    var got = 0;
    try {
      await for (final c in res) {
        sink.add(c);
        got += c.length;
        onProgress?.call(got, total < 0 ? 0 : total);
      }
    } finally {
      await sink.close();
    }
  }

  @override
  Future<void> upload(String local, String path, {Prog? onProgress}) async {
    final len = await File(local).length();
    final r = await _h!.openUrl('PUT', _url(path));
    r.headers.set('Authorization', _auth);
    r.headers.contentLength = len;
    var sent = 0;
    await r.addStream(File(local).openRead().map((c) {
      sent += c.length;
      onProgress?.call(sent, len);
      return c;
    }));
    final res = await r.close();
    if (res.statusCode >= 300) _fail(res);
    await res.drain<void>();
  }

  @override
  Future<void> mkdir(String path) async {
    final res = await _req('MKCOL', _url(path, dir: true));
    if (res.statusCode >= 300) _fail(res);
    await res.drain<void>();
  }

  @override
  Future<void> delete(String path, bool dir) async {
    final res = await _req('DELETE', _url(path, dir: dir));
    if (res.statusCode >= 300) _fail(res);
    await res.drain<void>();
  }

  @override
  Future<void> rename(String from, String to) async {
    final res = await _req('MOVE', _url(from), headers: {'Destination': _url(to).toString(), 'Overwrite': 'F'});
    if (res.statusCode >= 300) _fail(res);
    await res.drain<void>();
  }

  @override
  Future<void> close() async {
    _h?.close(force: true);
    _h = null;
  }
}
