import 'package:flutter/services.dart';

/// Pushes now-playing info to the home-screen widget (channel abtin/widget).
class WidgetNative {
  static const _ch = MethodChannel('abtin/widget');
  static String _last = '';
  static Future<void> update(String title, String artist, bool playing) async {
    final k = '$title|$artist|$playing';
    if (k == _last) return;
    _last = k;
    try {
      await _ch.invokeMethod('update', {'title': title, 'artist': artist, 'playing': playing});
    } catch (_) {}
  }
}
