import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import 'file_ops.dart';
import 'fgs.dart';
import 'native.dart';
import 'saf.dart';
import 'folder_sizes.dart';

enum Resolution { replace, skip, rename }

class Conflict {
  final String name;
  final bool srcIsDir, dstIsDir;
  final int srcSize, dstSize;
  final DateTime srcTime, dstTime;
  const Conflict(this.name, this.srcIsDir, this.dstIsDir, this.srcSize, this.dstSize, this.srcTime, this.dstTime);
}

class ConflictAnswer {
  final Resolution res;
  final bool all;
  const ConflictAnswer(this.res, this.all);
}

/// Return null to cancel the whole job.
typedef ConflictAsker = Future<ConflictAnswer?> Function(Conflict c);

class _Cancelled implements Exception {}

/// Copy / move with progress, cancel and conflict resolution (replace / skip / rename).
class CopyJob extends ChangeNotifier {
  final bool move;
  CopyJob({required this.move});

  bool cancelled = false, counting = true, finished = false;
  int totalBytes = 0, doneBytes = 0, totalFiles = 0, doneFiles = 0;
  String current = '';
  DateTime? started;
  final errors = <String>[];
  final _touched = <String>[];
  Resolution? _all;
  DateTime _last = DateTime.fromMillisecondsSinceEpoch(0);

  /// Jobs at least this big (or with this many files) run under the foreground service so they survive
  /// the app going to the background / the screen turning off. Set to a huge value to disable.
  static int bigBytes = 32 * 1024 * 1024, bigFiles = 300;
  static bool background = true; // user switch (Settings)
  bool _fg = false;
  DateTime _lastNote = DateTime.fromMillisecondsSinceEpoch(0);

  void cancel() {
    cancelled = true;
    notifyListeners();
  }

  double? get fraction {
    if (counting) return null;
    if (totalBytes > 0) return (doneBytes / totalBytes).clamp(0.0, 1.0);
    if (totalFiles > 0) return (doneFiles / totalFiles).clamp(0.0, 1.0);
    return null;
  }

  int get speed {
    final s = started;
    if (s == null) return 0;
    final ms = DateTime.now().difference(s).inMilliseconds;
    return ms < 500 ? 0 : (doneBytes * 1000 / ms).round();
  }

  void _tick({bool force = false}) {
    final n = DateTime.now();
    if (force || n.difference(_last).inMilliseconds > 80) {
      _last = n;
      notifyListeners();
      _note();
    }
  }

  void _note({bool force = false}) {
    if (!_fg) return;
    final n = DateTime.now();
    if (!force && n.difference(_lastNote).inMilliseconds < 1000) return;
    _lastNote = n;
    final f = fraction;
    Fgs.hold('copy', current.isEmpty ? '$doneFiles / $totalFiles' : '$doneFiles / $totalFiles  •  ${p.basename(current)}',
        title: move ? L.t('moving') : L.t('copying'), progress: f == null ? -1 : (f * 100).round());
  }

  void _check() {
    if (cancelled) throw _Cancelled();
  }

  void _advance(int bytes, int files) {
    doneBytes += bytes;
    doneFiles += files;
    _tick();
  }

  void _touch(String path) {
    if (_touched.length < 5000) _touched.add(path);
  }

  static String _msg(Object x) {
    if (x is OpError) return x.arg == null ? L.t(x.key) : '${L.t(x.key)}: ${x.arg}';
    if (x is FileSystemException) return x.osError?.message ?? x.message;
    return '$x';
  }

  Future<void> run(List<FileSystemEntity> items, String dest, ConflictAsker ask) async {
    try {
      for (final e in items) {
        _check();
        final t = FileSystemEntity.typeSync(e.path, followLinks: false);
        if (t == FileSystemEntityType.directory) {
          for (final f in await _walk(e.path)) {
            totalBytes += f.$2;
            totalFiles++;
          }
        } else if (t != FileSystemEntityType.notFound) {
          try { totalBytes += await File(e.path).length(); } catch (_) {}
          totalFiles++;
        }
      }
      counting = false;
      started = DateTime.now();
      if (background && (totalBytes >= bigBytes || totalFiles >= bigFiles)) {
        _fg = true;
        _note(force: true);
      }
      _tick(force: true);
      for (final e in items) {
        _check();
        try {
          await _process(e, dest, ask);
        } on _Cancelled {
          rethrow;
        } catch (x) {
          errors.add('${p.basename(e.path)}: ${_msg(x)}');
        }
      }
    } on _Cancelled {
      cancelled = true;
    } finally {
      finished = true;
      counting = false;
      FolderSizes.invalidate(dest);
      if (move) {
        for (final e in items) {
          FolderSizes.invalidate(e.path);
        }
      }
      for (var i = 0; i < _touched.length; i += 400) {
        await Native.scanMany(_touched.sublist(i, (i + 400).clamp(0, _touched.length)));
      }
      if (_fg) {
        _fg = false;
        await Fgs.release('copy');
      }
      notifyListeners();
    }
  }

  Future<void> _mkdir(String path) async {
    if (await Saf.use(path)) {
      await Saf.mkdirs(path);
    } else {
      await Directory(path).create(recursive: true);
    }
  }

  Future<void> _rm(String path, bool isDir) async {
    if (await Saf.use(path)) {
      await Saf.delete(path);
    } else if (isDir) {
      await Directory(path).delete(recursive: true);
    } else {
      await File(path).delete();
    }
  }

  /// Instant move (rename) when source and target are on the same volume. false = copy + delete needed.
  Future<bool> _fastMove(String src, String target, bool isDir) async {
    final sSaf = await Saf.use(src), dSaf = await Saf.use(target);
    try {
      if (!sSaf && !dSaf) {
        if (isDir) {
          await Directory(src).rename(target);
        } else {
          await File(src).rename(target);
        }
        return true;
      }
      if (sSaf && dSaf && Saf.volumeOf(src) == Saf.volumeOf(target)) {
        await Saf.move(src, p.dirname(target), p.basename(target));
        return true;
      }
    } on FileSystemException {
      return false;
    } on OpError {
      return false;
    }
    return false;
  }

  Future<List<(String, int)>> _walk(String dir) async {
    final out = <(String, int)>[];
    try {
      await for (final e in Directory(dir).list(recursive: true, followLinks: false)) {
        if (e is File) {
          var n = 0;
          try { n = await e.length(); } catch (_) {}
          out.add((e.path, n));
        }
      }
    } catch (_) {}
    return out;
  }

  Future<void> _skipped(String path, bool isDir) async {
    if (isDir) {
      var b = 0, f = 0;
      for (final x in await _walk(path)) {
        b += x.$2;
        f++;
      }
      _advance(b, f);
    } else {
      var n = 0;
      try { n = await File(path).length(); } catch (_) {}
      _advance(n, 1);
    }
  }

  Future<void> _process(FileSystemEntity src, String destDir, ConflictAsker ask) async {
    _check();
    final name = p.basename(src.path);
    final type = FileSystemEntity.typeSync(src.path, followLinks: false);
    if (type == FileSystemEntityType.notFound) return;
    final isDir = type == FileSystemEntityType.directory;
    if (isDir && (p.equals(src.path, destDir) || p.isWithin(src.path, destDir))) throw const OpError('selfCopy');

    var target = p.join(destDir, name);
    if (p.equals(src.path, target)) {
      if (move) {
        await _skipped(src.path, isDir);
        return;
      }
      target = FileOps.unique(destDir, name); // duplicate in the same folder
    } else {
      final tt = FileSystemEntity.typeSync(target, followLinks: false);
      if (tt != FileSystemEntityType.notFound) {
        final tIsDir = tt == FileSystemEntityType.directory;
        if (isDir && tIsDir) {
          current = name;
          _tick(force: true);
          await _dirInto(src.path, target, ask); // merge folders
          return;
        }
        Resolution res;
        if (_all != null) {
          res = _all!;
        } else {
          final ss = await FileStat.stat(src.path), ts = await FileStat.stat(target);
          final a = await ask(Conflict(name, isDir, tIsDir, ss.size, ts.size, ss.modified, ts.modified));
          if (a == null) throw _Cancelled();
          res = a.res;
          if (a.all) _all = res;
        }
        switch (res) {
          case Resolution.skip:
            await _skipped(src.path, isDir);
            return;
          case Resolution.rename:
            target = FileOps.unique(destDir, name);
            break;
          case Resolution.replace:
            await _rm(target, tIsDir);
            _touch(target);
            break;
        }
      }
    }

    current = name;
    _tick(force: true);
    if (isDir) {
      if (move) {
        final before = await _walk(src.path);
        if (await _fastMove(src.path, target, true)) {
          var b = 0;
          for (final f in before) {
            b += f.$2;
            _touch(f.$1);
            _touch(p.join(target, p.relative(f.$1, from: src.path)));
          }
          _advance(b, before.length);
          return;
        }
        // different volume: fall through to copy + delete
      }
      await _mkdir(target);
      await _dirInto(src.path, target, ask, created: true);
    } else if (type == FileSystemEntityType.link) {
      if (await Saf.use(target)) {
        _advance(0, 1); // links cannot be created on SAF volumes
        return;
      }
      final l = await Link(src.path).target();
      await Link(target).create(l);
      if (move) await Link(src.path).delete();
      _advance(0, 1);
    } else {
      await _file(File(src.path), target);
    }
  }

  Future<void> _dirInto(String srcDir, String targetDir, ConflictAsker ask, {bool created = false}) async {
    final kids = await Directory(srcDir).list(followLinks: false).toList();
    for (final c in kids) {
      _check();
      try {
        await _process(c, targetDir, ask);
      } on _Cancelled {
        rethrow;
      } catch (x) {
        errors.add('${p.basename(c.path)}: ${_msg(x)}');
      }
    }
    if (move) {
      try {
        if (await Saf.use(srcDir)) {
          if (Directory(srcDir).listSync().isEmpty) await Saf.delete(srcDir);
        } else {
          await Directory(srcDir).delete(); // only succeeds when empty
        }
      } catch (_) {}
    }
  }

  Future<void> _file(File src, String target) async {
    current = p.basename(src.path);
    _tick(force: true);
    if (move) {
      int len = 0;
      try { len = await src.length(); } catch (_) {}
      if (await _fastMove(src.path, target, false)) {
        _touch(src.path);
        _touch(target);
        _advance(len, 1);
        return;
      }
      // different volume: copy + delete
    }
    await _copyStream(src, target);
    if (move) {
      await _rm(src.path, false);
      _touch(src.path);
    }
  }

  Future<void> _copyStreamSaf(File src, String target, int len) async {
    final startDone = doneBytes;
    RandomAccessFile? r;
    int? h;
    var ok = false;
    try {
      r = await src.open();
      h = await Saf.open(target);
      while (true) {
        _check();
        final b = await r.read(1 << 20);
        if (b.isEmpty) break;
        await Saf.write(h, b);
        doneBytes += b.length;
        _tick();
      }
      ok = true;
    } finally {
      try { await r?.close(); } catch (_) {}
      if (h != null) {
        try { await Saf.close(h); } catch (_) {}
      }
      if (!ok) {
        try { await Saf.delete(target); } catch (_) {}
        doneBytes = startDone + len;
      }
    }
    _touch(target);
    _advance(0, 1);
    _tick(force: true);
  }

  Future<void> _copyStream(File src, String target) async {
    final tmp = '$target.abtinpart';
    final len = await src.length();
    if (await Saf.use(target)) return _copyStreamSaf(src, target, len);
    final startDone = doneBytes;
    RandomAccessFile? r, w;
    var ok = false;
    try {
      r = await src.open();
      w = await File(tmp).open(mode: FileMode.write);
      while (true) {
        _check();
        final b = await r.read(1 << 20);
        if (b.isEmpty) break;
        await w.writeFrom(b);
        doneBytes += b.length;
        _tick();
      }
      await w.close();
      w = null;
      await r.close();
      r = null;
      await File(tmp).rename(target);
      ok = true;
    } finally {
      try { await r?.close(); } catch (_) {}
      try { await w?.close(); } catch (_) {}
      if (!ok) {
        try { await File(tmp).delete(); } catch (_) {}
        doneBytes = startDone + len;
      }
    }
    try { await File(target).setLastModified(await src.lastModified()); } catch (_) {}
    _touch(target);
    _advance(0, 1);
    _tick(force: true);
  }
}
