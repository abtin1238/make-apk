import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:path/path.dart' as p;
import 'package:xml/xml.dart';

class CastDevice {
  final String id, name, host;
  final bool chromecast; // false = DLNA / UPnP renderer
  final int port;
  final String? control; // DLNA AVTransport control URL
  CastDevice(this.id, this.name, this.host, this.chromecast, {this.port = 8009, this.control});
}

String _mime(String path) {
  switch (p.extension(path).toLowerCase().replaceFirst('.', '')) {
    case 'mp4': case 'm4v': return 'video/mp4';
    case 'mkv': return 'video/x-matroska';
    case 'webm': return 'video/webm';
    case 'avi': return 'video/x-msvideo';
    case 'mov': return 'video/quicktime';
    case 'ts': return 'video/mp2t';
    case 'mp3': return 'audio/mpeg';
    case 'm4a': return 'audio/mp4';
    case 'flac': return 'audio/flac';
    case 'wav': return 'audio/wav';
    case 'ogg': return 'audio/ogg';
  }
  return 'application/octet-stream';
}

/// Tiny HTTP file server with Range support, so TVs / Chromecast can stream a local file.
class _FileServer {
  HttpServer? _s;
  String? path;

  Future<int> start() async {
    if (_s == null) {
      final srv = await HttpServer.bind(InternetAddress.anyIPv4, 0);
      srv.listen(_handle, onError: (_) {});
      _s = srv;
    }
    return _s!.port;
  }

  Future<void> stop() async {
    await _s?.close(force: true);
    _s = null;
  }

  Future<void> _handle(HttpRequest rq) async {
    final res = rq.response;
    try {
      final f = path == null ? null : File(path!);
      if (f == null || !await f.exists()) {
        res.statusCode = 404;
        await res.close();
        return;
      }
      final len = await f.length();
      res.headers.set('Accept-Ranges', 'bytes');
      res.headers.set('Access-Control-Allow-Origin', '*'); // Chromecast fetches with CORS
      res.headers.set('transferMode.dlna.org', 'Streaming');
      res.headers.set('contentFeatures.dlna.org', 'DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000');
      res.headers.contentType = ContentType.parse(_mime(f.path));
      var start = 0, end = len - 1;
      final r = rq.headers.value('range');
      if (r != null) {
        final m = RegExp(r'bytes=(\d*)-(\d*)').firstMatch(r);
        if (m != null) {
          if (m[1]!.isNotEmpty) {
            start = int.parse(m[1]!);
            if (m[2]!.isNotEmpty) end = int.parse(m[2]!);
          } else if (m[2]!.isNotEmpty) {
            start = len - int.parse(m[2]!);
          }
        }
        if (end >= len) end = len - 1;
        if (start < 0 || start > end) {
          res.statusCode = 416;
          await res.close();
          return;
        }
        res.statusCode = 206;
        res.headers.set('Content-Range', 'bytes $start-$end/$len');
      }
      res.contentLength = end - start + 1;
      if (rq.method == 'HEAD') {
        await res.close();
        return;
      }
      await res.addStream(f.openRead(start, end + 1));
      await res.close();
    } catch (_) {
      try { await res.close(); } catch (_) {}
    }
  }
}

/// Cast a video to DLNA / UPnP renderers (smart TVs, Kodi, VLC …) and Chromecast (Cast v2 protocol, default media receiver).
class CastService extends ChangeNotifier {
  static final CastService I = CastService._();
  CastService._();

  final _server = _FileServer();
  final devices = <CastDevice>[];
  bool scanning = false;
  CastDevice? active;
  bool playing = false;
  Duration position = Duration.zero, duration = Duration.zero;
  String? error;

  // ---------- discovery ----------
  Future<void> discover() async {
    scanning = true;
    devices.clear();
    notifyListeners();
    final found = <CastDevice>[];
    await Future.wait([_ssdp(found), _mdns(found)].map((f) => f.catchError((_) {})));
    devices.addAll(found);
    scanning = false;
    notifyListeners();
  }

  Future<void> _ssdp(List<CastDevice> out) async {
    final sock = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    final locs = <String>{};
    sock.listen((e) {
      if (e != RawSocketEvent.read) return;
      final d = sock.receive();
      if (d == null) return;
      final m = RegExp(r'^location:\s*(.+)$', caseSensitive: false, multiLine: true).firstMatch(utf8.decode(d.data, allowMalformed: true));
      if (m != null) locs.add(m[1]!.trim());
    });
    const msg = 'M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: "ssdp:discover"\r\nMX: 2\r\nST: urn:schemas-upnp-org:service:AVTransport:1\r\n\r\n';
    for (var i = 0; i < 2; i++) {
      sock.send(utf8.encode(msg), InternetAddress('239.255.255.250'), 1900);
      await Future<void>.delayed(const Duration(milliseconds: 400));
    }
    await Future<void>.delayed(const Duration(seconds: 2));
    sock.close();
    for (final loc in locs) {
      try {
        final uri = Uri.parse(loc);
        final c = HttpClient()..connectionTimeout = const Duration(seconds: 3);
        final rq = await c.getUrl(uri);
        final rs = await rq.close().timeout(const Duration(seconds: 4));
        final xml = XmlDocument.parse(await rs.transform(utf8.decoder).join());
        c.close(force: true);
        final name = xml.findAllElements('friendlyName').firstOrNull?.innerText ?? uri.host;
        String? ctl;
        for (final s in xml.findAllElements('service')) {
          if ((s.findElements('serviceType').firstOrNull?.innerText ?? '').contains('AVTransport')) {
            ctl = s.findElements('controlURL').firstOrNull?.innerText;
          }
        }
        if (ctl == null) continue;
        final url = uri.resolve(ctl).toString();
        if (out.any((d) => d.control == url)) continue;
        out.add(CastDevice('dlna:$url', name, uri.host, false, control: url));
      } catch (_) {}
    }
  }

  // ----- mDNS (unicast-response query) for _googlecast._tcp -----
  static (String, int) _name(Uint8List b, int off) {
    final parts = <String>[];
    var pos = off;
    int? end;
    for (var guard = 0; guard < 64; guard++) {
      final l = b[pos];
      if (l == 0) {
        pos++;
        break;
      }
      if (l & 0xC0 == 0xC0) {
        end ??= pos + 2;
        pos = ((l & 0x3F) << 8) | b[pos + 1];
        continue;
      }
      parts.add(utf8.decode(b.sublist(pos + 1, pos + 1 + l), allowMalformed: true));
      pos += 1 + l;
    }
    return (parts.join('.'), end ?? pos);
  }

  Future<void> _mdns(List<CastDevice> out) async {
    final sock = await RawDatagramSocket.bind(InternetAddress.anyIPv4, 0);
    final inst = <String, String>{}; // instance -> source ip
    final srv = <String, (int, String)>{};
    final addr = <String, String>{};
    final fn = <String, String>{};
    sock.listen((e) {
      if (e != RawSocketEvent.read) return;
      final d = sock.receive();
      if (d == null) return;
      try {
        final b = d.data;
        final bd = ByteData.sublistView(b);
        final qd = bd.getUint16(4), total = bd.getUint16(6) + bd.getUint16(8) + bd.getUint16(10);
        var pos = 12;
        for (var i = 0; i < qd; i++) {
          pos = _name(b, pos).$2 + 4;
        }
        for (var i = 0; i < total; i++) {
          final (n, e1) = _name(b, pos);
          pos = e1;
          final type = bd.getUint16(pos), len = bd.getUint16(pos + 8), rd = pos + 10;
          pos = rd + len;
          if (type == 12 && n == '_googlecast._tcp.local') {
            inst[_name(b, rd).$1] = d.address.address;
          } else if (type == 33) {
            srv[n] = (bd.getUint16(rd + 4), _name(b, rd + 6).$1);
          } else if (type == 1) {
            addr[n] = '${b[rd]}.${b[rd + 1]}.${b[rd + 2]}.${b[rd + 3]}';
          } else if (type == 16) {
            var q = rd;
            while (q < rd + len) {
              final l = b[q];
              final s = utf8.decode(b.sublist(q + 1, q + 1 + l), allowMalformed: true);
              q += 1 + l;
              if (s.startsWith('fn=')) fn[n] = s.substring(3);
            }
          }
        }
      } catch (_) {}
    });
    final q = BytesBuilder()
      ..add([0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0]);
    for (final l in ['_googlecast', '_tcp', 'local']) {
      q.addByte(l.length);
      q.add(utf8.encode(l));
    }
    q.add([0, 0, 12, 0x80, 0x01]); // PTR, class IN + unicast-response bit
    for (var i = 0; i < 3; i++) {
      sock.send(q.toBytes(), InternetAddress('224.0.0.251'), 5353);
      await Future<void>.delayed(const Duration(milliseconds: 500));
    }
    await Future<void>.delayed(const Duration(milliseconds: 1500));
    sock.close();
    for (final e in inst.entries) {
      final s = srv[e.key];
      final host = (s == null ? null : addr[s.$2]) ?? e.value;
      final name = fn[e.key] ?? e.key.split('._googlecast').first;
      if (out.any((d) => d.host == host && d.chromecast)) continue;
      out.add(CastDevice('cc:$host', name, host, true, port: s?.$1 ?? 8009));
    }
  }

  // ---------- casting ----------
  Future<String> _urlFor(String path) async {
    if (RegExp(r'^[a-z]+://', caseSensitive: false).hasMatch(path)) return path;
    _server.path = path;
    final port = await _server.start();
    final ip = await NetworkInfo().getWifiIP();
    if (ip == null) throw StateError('Wi-Fi IP unknown');
    return 'http://$ip:$port/media/${Uri.encodeComponent(p.basename(path))}';
  }

  Future<void> cast(CastDevice d, String path, String title, Duration start) async {
    error = null;
    await stop(silent: true);
    active = d;
    position = start;
    duration = Duration.zero;
    notifyListeners();
    try {
      final url = await _urlFor(path);
      if (d.chromecast) {
        await _ccLoad(d, url, _mime(path), title, start);
      } else {
        await _dlnaLoad(d, url, _mime(path), title, start);
      }
      playing = true;
    } catch (e) {
      error = '$e';
      active = null;
    }
    notifyListeners();
  }

  Future<void> play() async {
    if (active == null) return;
    active!.chromecast ? _ccMedia('PLAY') : await _soap('Play', '<Speed>1</Speed>');
    playing = true;
    notifyListeners();
  }

  Future<void> pause() async {
    if (active == null) return;
    active!.chromecast ? _ccMedia('PAUSE') : await _soap('Pause', '');
    playing = false;
    notifyListeners();
  }

  Future<void> seek(Duration t) async {
    if (active == null) return;
    if (t < Duration.zero) t = Duration.zero;
    if (active!.chromecast) {
      _ccMedia('SEEK', {'currentTime': t.inMilliseconds / 1000.0});
    } else {
      await _soap('Seek', '<Unit>REL_TIME</Unit><Target>${_hms(t)}</Target>');
    }
    position = t;
    notifyListeners();
  }

  Future<void> stop({bool silent = false}) async {
    final d = active;
    _poll?.cancel();
    _poll = null;
    if (d != null) {
      try {
        if (d.chromecast) {
          _ccSend('urn:x-cast:com.google.cast.receiver', 'receiver-0', {'type': 'STOP', 'sessionId': _ccSession ?? '', 'requestId': _rid++});
          await Future<void>.delayed(const Duration(milliseconds: 150));
          _ccClose();
        } else {
          await _soap('Stop', '');
        }
      } catch (_) {}
    }
    active = null;
    playing = false;
    await _server.stop();
    if (!silent) notifyListeners();
  }

  static String _hms(Duration d) => '${d.inHours.toString().padLeft(2, '0')}:${(d.inMinutes % 60).toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
  static Duration _parseHms(String s) {
    final m = RegExp(r'(\d+):(\d+):(\d+)').firstMatch(s);
    return m == null ? Duration.zero : Duration(hours: int.parse(m[1]!), minutes: int.parse(m[2]!), seconds: int.parse(m[3]!));
  }

  // ---------- DLNA ----------
  Timer? _poll;

  Future<String> _soap(String action, String args) async {
    final d = active;
    if (d == null || d.control == null) throw StateError('no device');
    final body = '<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body>'
        '<u:$action xmlns:u="urn:schemas-upnp-org:service:AVTransport:1"><InstanceID>0</InstanceID>$args</u:$action></s:Body></s:Envelope>';
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 5);
    try {
      final rq = await c.postUrl(Uri.parse(d.control!));
      rq.headers.set('Content-Type', 'text/xml; charset="utf-8"');
      rq.headers.set('SOAPACTION', '"urn:schemas-upnp-org:service:AVTransport:1#$action"');
      rq.add(utf8.encode(body));
      final rs = await rq.close().timeout(const Duration(seconds: 8));
      final txt = await rs.transform(utf8.decoder).join();
      if (rs.statusCode >= 400) throw HttpException('${rs.statusCode}');
      return txt;
    } finally {
      c.close(force: true);
    }
  }

  static String _xmlEsc(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');

  Future<void> _dlnaLoad(CastDevice d, String url, String mime, String title, Duration start) async {
    final cls = mime.startsWith('audio') ? 'object.item.audioItem' : 'object.item.videoItem';
    final didl = '<DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/">'
        '<item id="0" parentID="-1" restricted="1"><dc:title>${_xmlEsc(title)}</dc:title><upnp:class>$cls</upnp:class>'
        '<res protocolInfo="http-get:*:$mime:*">${_xmlEsc(url)}</res></item></DIDL-Lite>';
    await _soap('SetAVTransportURI', '<CurrentURI>${_xmlEsc(url)}</CurrentURI><CurrentURIMetaData>${_xmlEsc(didl)}</CurrentURIMetaData>');
    await _soap('Play', '<Speed>1</Speed>');
    if (start > const Duration(seconds: 3)) {
      await Future<void>.delayed(const Duration(seconds: 2)); // many TVs reject Seek before playback has started
      try { await _soap('Seek', '<Unit>REL_TIME</Unit><Target>${_hms(start)}</Target>'); } catch (_) {}
    }
    _poll = Timer.periodic(const Duration(seconds: 1), (_) async {
      try {
        final x = XmlDocument.parse(await _soap('GetPositionInfo', ''));
        position = _parseHms(x.findAllElements('RelTime').firstOrNull?.innerText ?? '');
        duration = _parseHms(x.findAllElements('TrackDuration').firstOrNull?.innerText ?? '');
        notifyListeners();
      } catch (_) {}
    });
  }

  // ---------- Chromecast (Cast v2) ----------
  SecureSocket? _sock;
  final _rx = BytesBuilder();
  Timer? _hb;
  int _rid = 1;
  String? _ccSession, _ccTransport;
  int? _ccMediaSession;
  Completer<void>? _ccReady;

  static List<int> _varint(int v) {
    final o = <int>[];
    while (v > 0x7F) {
      o.add((v & 0x7F) | 0x80);
      v >>= 7;
    }
    o.add(v);
    return o;
  }

  static List<int> _field(int no, String s) {
    final b = utf8.encode(s);
    return [(no << 3) | 2, ..._varint(b.length), ...b];
  }

  void _ccSend(String ns, String dest, Map<String, dynamic> payload) {
    final msg = <int>[
      0x08, 0, // protocol version
      ..._field(2, 'sender-0'),
      ..._field(3, dest),
      ..._field(4, ns),
      0x28, 0, // payload type STRING
      ..._field(6, jsonEncode(payload)),
    ];
    final fr = ByteData(4)..setUint32(0, msg.length);
    _sock?.add([...fr.buffer.asUint8List(), ...msg]);
  }

  void _ccMedia(String type, [Map<String, dynamic> extra = const {}]) {
    if (_ccTransport == null || _ccMediaSession == null) return;
    _ccSend('urn:x-cast:com.google.cast.media', _ccTransport!, {'type': type, 'mediaSessionId': _ccMediaSession, 'requestId': _rid++, ...extra});
  }

  void _ccClose() {
    _hb?.cancel();
    _hb = null;
    try { _sock?.destroy(); } catch (_) {}
    _sock = null;
    _rx.clear();
    _ccSession = _ccTransport = null;
    _ccMediaSession = null;
  }

  void _ccData(List<int> data) {
    _rx.add(data);
    var buf = _rx.toBytes();
    while (buf.length >= 4) {
      final len = ByteData.sublistView(buf, 0, 4).getUint32(0);
      if (buf.length < 4 + len) break;
      _ccMsg(buf.sublist(4, 4 + len));
      buf = buf.sublist(4 + len);
    }
    _rx
      ..clear()
      ..add(buf);
  }

  void _ccMsg(Uint8List m) {
    String ns = '', payload = '';
    var i = 0;
    while (i < m.length) {
      final tag = m[i++];
      final no = tag >> 3, wt = tag & 7;
      if (wt == 0) {
        while (i < m.length && m[i++] & 0x80 != 0) {}
      } else if (wt == 2) {
        var len = 0, shift = 0;
        while (i < m.length) {
          final b = m[i++];
          len |= (b & 0x7F) << shift;
          shift += 7;
          if (b & 0x80 == 0) break;
        }
        final s = utf8.decode(m.sublist(i, i + len), allowMalformed: true);
        i += len;
        if (no == 4) ns = s;
        if (no == 6) payload = s;
      } else {
        break;
      }
    }
    Map<String, dynamic> j;
    try {
      j = jsonDecode(payload) as Map<String, dynamic>;
    } catch (_) {
      return;
    }
    if (ns.endsWith('heartbeat') && j['type'] == 'PING') {
      _ccSend('urn:x-cast:com.google.cast.tp.heartbeat', 'receiver-0', {'type': 'PONG'});
    } else if (ns.endsWith('receiver') && j['type'] == 'RECEIVER_STATUS') {
      final apps = (j['status']?['applications'] as List?) ?? const [];
      for (final a in apps) {
        if ((a as Map)['appId'] == 'CC1AD845') {
          _ccSession = a['sessionId'] as String?;
          _ccTransport = a['transportId'] as String?;
          if (_ccTransport != null && !(_ccReady?.isCompleted ?? true)) _ccReady!.complete();
        }
      }
    } else if (ns.endsWith('media') && j['type'] == 'MEDIA_STATUS') {
      final st = (j['status'] as List?) ?? const [];
      if (st.isNotEmpty) {
        final s = st.first as Map;
        _ccMediaSession = (s['mediaSessionId'] as num?)?.toInt() ?? _ccMediaSession;
        position = Duration(milliseconds: (((s['currentTime'] as num?) ?? 0) * 1000).round());
        final d = (s['media']?['duration'] as num?);
        if (d != null) duration = Duration(milliseconds: (d * 1000).round());
        playing = s['playerState'] == 'PLAYING' || s['playerState'] == 'BUFFERING';
        notifyListeners();
      }
    }
  }

  Future<void> _ccLoad(CastDevice d, String url, String mime, String title, Duration start) async {
    _ccClose();
    _sock = await SecureSocket.connect(d.host, d.port, onBadCertificate: (_) => true, timeout: const Duration(seconds: 6));
    _sock!.listen(_ccData, onDone: () {
      if (active == d) {
        active = null;
        playing = false;
        notifyListeners();
      }
    }, onError: (_) {});
    _ccReady = Completer<void>();
    _ccSend('urn:x-cast:com.google.cast.tp.connection', 'receiver-0', {'type': 'CONNECT'});
    _hb = Timer.periodic(const Duration(seconds: 5), (_) => _ccSend('urn:x-cast:com.google.cast.tp.heartbeat', 'receiver-0', {'type': 'PING'}));
    _ccSend('urn:x-cast:com.google.cast.receiver', 'receiver-0', {'type': 'LAUNCH', 'appId': 'CC1AD845', 'requestId': _rid++});
    await _ccReady!.future.timeout(const Duration(seconds: 12));
    _ccSend('urn:x-cast:com.google.cast.tp.connection', _ccTransport!, {'type': 'CONNECT'});
    _ccSend('urn:x-cast:com.google.cast.media', _ccTransport!, {
      'type': 'LOAD',
      'requestId': _rid++,
      'sessionId': _ccSession,
      'autoplay': true,
      'currentTime': start.inMilliseconds / 1000.0,
      'media': {
        'contentId': url,
        'streamType': 'BUFFERED',
        'contentType': mime,
        'metadata': {'metadataType': 0, 'title': title},
      },
    });
    _poll = Timer.periodic(const Duration(seconds: 2), (_) => _ccSend('urn:x-cast:com.google.cast.media', _ccTransport ?? 'receiver-0', {'type': 'GET_STATUS', 'requestId': _rid++}));
  }
}
