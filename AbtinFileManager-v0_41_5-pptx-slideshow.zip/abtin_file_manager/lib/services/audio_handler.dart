import 'package:audio_service/audio_service.dart';
import 'library_index.dart';
import 'playlist_store.dart';
import 'player_service.dart';

/// Bridges [PlayerService] to the Android media session: notification,
/// lock-screen controls, headset / Bluetooth buttons and background playback.
class AbtinAudioHandler extends BaseAudioHandler with SeekHandler {
  final PlayerService ps;
  AbtinAudioHandler(this.ps);

  @override
  Future<void> play() => ps.player.play();
  @override
  Future<void> pause() => ps.player.pause();
  @override
  Future<void> stop() async {
    await ps.stopAll();
    await super.stop();
  }

  @override
  Future<void> seek(Duration position) => ps.player.seek(position);
  @override
  Future<void> skipToNext() => ps.player.next();
  @override
  Future<void> skipToPrevious() => ps.player.previous();
  @override
  Future<void> skipToQueueItem(int index) => ps.player.jump(index);
  @override
  Future<void> setSpeed(double speed) => ps.player.setRate(speed);
  @override
  Future<void> fastForward() => ps.seekBy(const Duration(seconds: 10));
  @override
  Future<void> rewind() => ps.seekBy(const Duration(seconds: -10));

  // ---------- Android Auto / media browser ----------
  @override
  Future<List<MediaItem>> getChildren(String parentMediaId, [Map<String, dynamic>? options]) async {
    await LibraryIndex.ensure();
    MediaItem folder(String id, String t) => MediaItem(id: id, title: t, playable: false);
    switch (parentMediaId) {
      case AudioService.browsableRootId:
      case AudioService.recentRootId:
        return [folder('f|pl', 'Playlists'), folder('f|album', 'Albums'), folder('f|artist', 'Artists'), folder('f|all', 'All songs')];
      case 'f|pl':
        return [for (var i = 0; i < PlaylistStore.lists.length; i++) folder('f|pl:$i', PlaylistStore.lists[i].name)];
      case 'f|album':
        return [for (final a in LibraryIndex.albums().take(300)) folder('f|album:$a', a)];
      case 'f|artist':
        return [for (final a in LibraryIndex.artists().take(300)) folder('f|artist:$a', a)];
    }
    if (parentMediaId.startsWith('f|')) {
      final ctx = parentMediaId.substring(2);
      final tr = LibraryIndex.tracks(ctx);
      return [
        for (var i = 0; i < tr.length && i < 300; i++) MediaItem(id: 't|$ctx|$i', title: tr[i].title, artist: tr[i].artist, album: tr[i].album, playable: true)
      ];
    }
    return [];
  }

  @override
  Future<void> playFromMediaId(String mediaId, [Map<String, dynamic>? extras]) async {
    final parts = mediaId.split('|');
    if (parts.length < 3 || parts[0] != 't') return;
    final idx = int.tryParse(parts.last) ?? 0;
    final ctx = parts.sublist(1, parts.length - 1).join('|');
    await LibraryIndex.ensure();
    final tr = LibraryIndex.tracks(ctx).take(300).toList();
    if (tr.isEmpty) return;
    await ps.playList([for (final t in tr) t.path], idx.clamp(0, tr.length - 1));
  }

  void publish() {
    final st = ps.player.state;
    playbackState.add(PlaybackState(
      controls: [
        MediaControl.skipToPrevious,
        ps.playing ? MediaControl.pause : MediaControl.play,
        MediaControl.skipToNext,
        MediaControl.stop,
      ],
      systemActions: const {MediaAction.seek, MediaAction.seekForward, MediaAction.seekBackward},
      androidCompactActionIndices: const [0, 1, 2],
      processingState: ps.hasQueue ? (st.buffering ? AudioProcessingState.buffering : AudioProcessingState.ready) : AudioProcessingState.idle,
      playing: ps.playing,
      updatePosition: st.position,
      bufferedPosition: st.buffer,
      speed: st.rate,
      queueIndex: ps.hasQueue ? ps.index : null,
    ));
  }

  void setItem(MediaItem item) => mediaItem.add(item);

  void clear() {
    playbackState.add(PlaybackState(processingState: AudioProcessingState.idle, playing: false));
  }
}
