import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

/// Android foreground service (keeps the process alive and the CPU awake with the screen off).
/// Shared by several users (LAN server, big copy jobs): the service runs while at least one holder is registered,
/// and the notification shows the most recently updated holder. Channel: abtin/fgs
class Fgs {
  static const _c = MethodChannel('abtin/fgs');

  static final Map<String, _Hold> _holds = {};
  static String? _top;
  static bool _askedNotif = false;

  static bool get active => _holds.isNotEmpty;

  /// Registers / updates a holder. [progress]: 0..100, -1 = indeterminate, -2 = no bar.
  static Future<void> hold(String tag, String text, {String title = 'Abtin', int progress = -2, bool wifi = false}) async {
    final first = _holds.isEmpty;
    _holds[tag] = _Hold(title, text, progress, wifi);
    _top = tag;
    if (first && !_askedNotif) {
      _askedNotif = true;
      try { await Permission.notification.request(); } catch (_) {}
    }
    await _push();
  }

  static Future<void> release(String tag) async {
    if (_holds.remove(tag) == null) return;
    if (_holds.isEmpty) {
      _top = null;
      try { await _c.invokeMethod('stop'); } catch (_) {}
    } else {
      _top = _holds.keys.last;
      await _push();
    }
  }

  static Future<void> _push() async {
    final h = _holds[_top];
    if (h == null) return;
    try {
      await _c.invokeMethod('start', {
        'title': h.title,
        'text': h.text,
        'progress': h.progress,
        'wifi': _holds.values.any((e) => e.wifi),
      });
    } catch (_) {}
  }

  // LAN server (kept for the old call sites)
  static Future<void> start(String text) => hold('lan', text, title: 'Abtin – LAN server', wifi: true);
  static Future<void> stop() => release('lan');
}

class _Hold {
  final String title, text;
  final int progress;
  final bool wifi;
  const _Hold(this.title, this.text, this.progress, this.wifi);
}
