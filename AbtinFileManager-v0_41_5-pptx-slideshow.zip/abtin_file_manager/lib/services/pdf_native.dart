import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'saf.dart';

/// PDF operations that keep vector content / selectable text (PdfBox-Android, see PdfNative.kt).
class PdfNative {
  static const _c = MethodChannel('abtin/pdf');

  /// Runs [job] with a writable output path. On an SD card that needs SAF the native code writes
  /// to a temp file which is then copied onto [dst].
  static Future<T> _out<T>(String dst, Future<T> Function(String out) job) async {
    if (!await Saf.use(dst)) return job(dst);
    final t = '${Directory.systemTemp.path}/abtin_pdf_${DateTime.now().microsecondsSinceEpoch}.pdf';
    try {
      final r = await job(t);
      await Saf.copyFileIn(t, dst);
      return r;
    } finally {
      try { File(t).deleteSync(); } catch (_) {}
    }
  }

  static Future<void> merge(List<String> srcs, String dst) => _out(dst, (o) => _c.invokeMethod('merge', {'srcs': srcs, 'dst': o}));

  /// pages are 1-based
  static Future<void> extract(String src, String dst, List<int> pages) => _out(dst, (o) => _c.invokeMethod('extract', {'src': src, 'dst': o, 'pages': pages}));

  /// empty [pages] = all pages
  static Future<void> rotate(String src, String dst, List<int> pages, int deg) => _out(dst, (o) => _c.invokeMethod('rotate', {'src': src, 'dst': o, 'pages': pages, 'deg': deg}));

  static Future<String> text(String src, int page) async => (await _c.invokeMethod<String>('text', {'src': src, 'page': page})) ?? '';

  static Future<List<Map<String, dynamic>>> search(String src, String q) async {
    final r = await _c.invokeMethod<List>('search', {'src': src, 'q': q});
    return (r ?? []).map((e) => (e as Map).map((k, v) => MapEntry('$k', v))).toList();
  }

  static Future<List<Map<String, dynamic>>> fields(String src) async {
    final r = await _c.invokeMethod<List>('fields', {'src': src});
    return (r ?? []).map((e) => (e as Map).map((k, v) => MapEntry('$k', v))).toList();
  }

  /// returns names of fields that could not be set
  static Future<List<String>> fill(String src, String dst, Map<String, dynamic> values) async {
    final r = await _out(dst, (o) => _c.invokeMethod<List>('fill', {'src': src, 'dst': o, 'values': values}));
    return (r ?? []).map((e) => '$e').toList();
  }

  /// anchor: 0 bottom-right, 1 bottom-left, 2 centre, 3 top-right, 4 top-left; w = fraction of page width
  static Future<void> stamp(String src, String dst, int page, int anchor, double w, Uint8List png) =>
      _out(dst, (o) => _c.invokeMethod('stamp', {'src': src, 'dst': o, 'page': page, 'anchor': anchor, 'w': w, 'png': png}));

  /// true when the file needs a password to open.
  static Future<bool> isEncrypted(String src) async => (await _c.invokeMethod<bool>('isEncrypted', {'src': src})) ?? false;

  /// Writes an unprotected copy. false = wrong password.
  static Future<bool> decrypt(String src, String dst, String password) async =>
      (await _c.invokeMethod<bool>('decrypt', {'src': src, 'dst': dst, 'password': password})) ?? false;

  /// AES-256 password protection (same password opens and owns the file).
  static Future<void> encrypt(String src, String dst, String password) => _out(dst, (o) => _c.invokeMethod('encrypt', {'src': src, 'dst': o, 'password': password}));

  /// Text lines of a page. x/y/w/h are fractions of the displayed page (top-left origin); `pt` = text height in points.
  static Future<List<Map<String, dynamic>>> boxes(String src, int page) async {
    final r = await _c.invokeMethod<List>('boxes', {'src': src, 'page': page});
    return (r ?? []).map((e) => (e as Map).map((k, v) => MapEntry('$k', v))).toList();
  }

  /// Adds vector edits and applies page order / deletions (original pages keep their selectable text).
  /// [order] = original page numbers (1-based) in the new order; [ops] = [{page, items:[...]}], see pdf_editor_screen.dart.
  /// Returns the number of glyphs really removed from the content stream (items {k:'r', rm:true} = replace text).
  static Future<int> edit(String src, String dst, List<int> order, List<Map<String, dynamic>> ops) async =>
      await _out<int>(dst, (o) async => (await _c.invokeMethod<int>('edit', {'src': src, 'dst': o, 'order': order, 'ops': ops})) ?? 0);

  /// Real PDF text-markup annotation. [kind] = highlight | underline | strike; [rects] = [x, y, w, h] fractions of the displayed page.
  static Future<void> markup(String src, String dst, int page, String kind, List<List<double>> rects, int r, int g, int b) =>
      _out(dst, (o) => _c.invokeMethod('markup', {'src': src, 'dst': o, 'page': page, 'kind': kind, 'rects': rects, 'r': r, 'g': g, 'b': b}));

  /// Places a PNG at fractions (x, y = top-left, w = width) of the displayed page; correct on rotated pages.
  static Future<void> stampAt(String src, String dst, int page, double x, double y, double w, Uint8List png) =>
      _out(dst, (o) => _c.invokeMethod('stampAt', {'src': src, 'dst': o, 'page': page, 'x': x, 'y': y, 'w': w, 'png': png}));
}
