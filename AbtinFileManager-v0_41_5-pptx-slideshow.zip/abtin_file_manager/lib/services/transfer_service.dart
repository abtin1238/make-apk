import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'dart:math';
import 'package:archive/archive_io.dart';
import 'package:basic_utils/basic_utils.dart';
import 'package:crypto/crypto.dart';
import 'package:flutter/foundation.dart';
import 'package:network_info_plus/network_info_plus.dart';
import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';
import 'package:pointycastle/export.dart' show RSAPrivateKey, RSAPublicKey;
import 'package:shared_preferences/shared_preferences.dart';
import 'fgs.dart';
import 'file_ops.dart';

class Peer {
  final String name, ip;
  final int port;
  DateTime seen;
  Peer(this.name, this.ip, this.port) : seen = DateTime.now();
}

class NeedPin implements Exception {
  @override
  String toString() => 'PIN required';
}

/// An incoming upload waiting for the user's decision.
class Approval {
  final String name, ip;
  final Completer<bool> _c = Completer<bool>();
  Approval(this.name, this.ip);
}

/// LAN transfer: embedded HTTP server (browser + app-to-app) + UDP discovery.
class TransferService extends ChangeNotifier {
  static const port = 8080, tlsPort = 8443, discPort = 45454;
  static const defaultReceiveDir = '/storage/emulated/0/Download/Abtin';

  // ---- security settings (persisted) ----
  String receiveDir = defaultReceiveDir;
  bool requirePin = true, requireApproval = true, useHttps = true;
  bool get secure => _tls != null;
  final _batches = <String, String>{};
  final _pins = <String, String>{}; // host -> sha256 of the certificate (trust on first use)
  String pin = '';
  final pending = <Approval>[];
  final _tokens = <String>{};
  final _approved = <String>{};
  final _fails = <String, int>{};
  final _lockUntil = <String, DateTime>{};
  SharedPreferences? _sp;

  HttpServer? _server, _tls;
  RawDatagramSocket? _udp;
  Timer? _beacon;
  String? url, myIp;
  final shared = <String, String>{};
  final peers = <String, Peer>{};
  final log = <String>[];
  double? progress;
  String? status;
  final deviceName = 'Abtin-${Platform.localHostname}';
  bool get running => _server != null;

  Future<void> _prefs() async {
    _sp ??= await SharedPreferences.getInstance();
    receiveDir = _sp!.getString('recvDir') ?? defaultReceiveDir;
    requirePin = _sp!.getBool('recvPin') ?? true;
    requireApproval = _sp!.getBool('recvAsk') ?? true;
    useHttps = _sp!.getBool('useHttps') ?? true;
    try {
      (jsonDecode(_sp!.getString('tlsPins') ?? '{}') as Map).forEach((k, v) => _pins['$k'] = '$v');
    } catch (_) {}
  }

  void setUseHttps(bool v) {
    useHttps = v;
    _sp?.setBool('useHttps', v);
    notifyListeners();
  }

  static (String, String) _genCert(String cn) {
    final pair = CryptoUtils.generateRSAKeyPair(keySize: 2048);
    final priv = pair.privateKey as RSAPrivateKey, pub = pair.publicKey as RSAPublicKey;
    final csr = X509Utils.generateRsaCsrPem({'CN': cn, 'O': 'Abtin File Manager'}, priv, pub);
    final cert = X509Utils.generateSelfSignedCertificate(priv, csr, 3650);
    return (cert, CryptoUtils.encodeRSAPrivateKeyToPem(priv));
  }

  /// Self-signed certificate, generated once (RSA-2048, a few seconds on a phone) and kept in app-private prefs.
  Future<SecurityContext> _context() async {
    var cert = _sp!.getString('tlsCert'), key = _sp!.getString('tlsKey');
    if (cert == null || key == null) {
      status = 'TLS';
      notifyListeners();
      final cn = deviceName;
      final r = await Isolate.run(() => _genCert(cn));
      cert = r.$1;
      key = r.$2;
      await _sp!.setString('tlsCert', cert);
      await _sp!.setString('tlsKey', key);
      status = null;
    }
    return SecurityContext()
      ..useCertificateChainBytes(utf8.encode(cert))
      ..usePrivateKeyBytes(utf8.encode(key));
  }

  bool _trust(X509Certificate c, String host) {
    final fp = sha256.convert(c.der).toString();
    final known = _pins[host];
    if (known == null) {
      _pins[host] = fp;
      _sp?.setString('tlsPins', jsonEncode(_pins));
      return true;
    }
    return known == fp;
  }

  static String _rnd(int bytes) {
    final r = Random.secure();
    return List.generate(bytes, (_) => r.nextInt(256).toRadixString(16).padLeft(2, '0')).join();
  }

  void newPin() {
    pin = Random.secure().nextInt(10000).toString().padLeft(4, '0');
    _tokens.clear(); // old sessions are signed out
    notifyListeners();
  }

  void setRequirePin(bool v) {
    requirePin = v;
    _sp?.setBool('recvPin', v);
    notifyListeners();
  }

  void setRequireApproval(bool v) {
    requireApproval = v;
    _sp?.setBool('recvAsk', v);
    notifyListeners();
  }

  void setReceiveDir(String d) {
    receiveDir = d;
    _sp?.setString('recvDir', d);
    notifyListeners();
  }

  /// Address for the QR code: opens the page already signed in.
  String? get qrData => url == null ? null : requirePin ? '$url/?pin=$pin' : url;

  void decide(Approval a, bool ok) {
    if (ok) _approved.add(a.ip);
    if (!a._c.isCompleted) a._c.complete(ok);
    pending.remove(a);
    notifyListeners();
  }

  Future<bool> _ask(String ip, String name) async {
    final a = Approval(name, ip);
    pending.add(a);
    notifyListeners();
    final ok = await a._c.future.timeout(const Duration(seconds: 60), onTimeout: () => false);
    if (pending.remove(a)) notifyListeners();
    return ok;
  }

  /// Returns a session token for a correct PIN (5 wrong tries lock the address for a minute).
  String? _login(String ip, String given) {
    final lock = _lockUntil[ip];
    if (lock != null && DateTime.now().isBefore(lock)) return null;
    if (given.isNotEmpty && given == pin) {
      _fails.remove(ip);
      final t = _rnd(16);
      _tokens.add(t);
      return t;
    }
    final n = (_fails[ip] ?? 0) + 1;
    _fails[ip] = n;
    if (n >= 5) {
      _lockUntil[ip] = DateTime.now().add(const Duration(minutes: 1));
      _fails.remove(ip);
      log.insert(0, 'Too many wrong PINs from $ip');
      notifyListeners();
    }
    return null;
  }

  bool _authed(HttpRequest r) {
    if (!requirePin) return true;
    String? t = r.headers.value('x-abt-token');
    if (t == null) {
      for (final c in r.cookies) {
        if (c.name == 'abt') t = c.value;
      }
    }
    return t != null && _tokens.contains(t);
  }

  Future<void> start() async {
    if (running) return;
    await _prefs();
    newPin();
    _approved.clear();
    try {
      await Permission.notification.request();
    } catch (_) {}
    myIp = await NetworkInfo().getWifiIP();
    _server = await HttpServer.bind(InternetAddress.anyIPv4, port, shared: true);
    _server!.listen((r) => _handle(r, false));
    if (useHttps) {
      try {
        _tls = await HttpServer.bindSecure(InternetAddress.anyIPv4, tlsPort, await _context(), shared: true);
        _tls!.listen((r) => _handle(r, true));
      } catch (e) {
        _tls = null;
        log.add('HTTPS unavailable: $e');
      }
    }
    url = _tls != null ? 'https://$myIp:$tlsPort' : 'http://$myIp:$port';
    await Fgs.start('$url');
    try {
      _udp = await RawDatagramSocket.bind(InternetAddress.anyIPv4, discPort, reuseAddress: true);
      _udp!.broadcastEnabled = true;
      _udp!.listen((ev) {
        if (ev != RawSocketEvent.read) return;
        final d = _udp!.receive();
        if (d == null) return;
        final parts = utf8.decode(d.data, allowMalformed: true).split('|');
        if (parts.length == 3 && parts[0] == 'ABTIN' && d.address.address != myIp) {
          peers[d.address.address] = Peer(parts[1], d.address.address, int.tryParse(parts[2]) ?? port);
          notifyListeners();
        }
      });
      _beacon = Timer.periodic(const Duration(seconds: 2), (_) {
        _udp?.send(utf8.encode('ABTIN|$deviceName|$port'), InternetAddress('255.255.255.255'), discPort);
        final before = peers.length;
        peers.removeWhere((_, v) => DateTime.now().difference(v.seen).inSeconds > 3 && false);
        if (before != peers.length) notifyListeners();
      });
    } catch (e) {
      log.add('Discovery unavailable: $e');
    }
    notifyListeners();
  }

  Future<void> stop() async {
    _beacon?.cancel();
    _udp?.close();
    await _server?.close(force: true);
    await _tls?.close(force: true);
    _server = null;
    _tls = null;
    _batches.clear();
    _udp = null;
    url = null;
    for (final a in List.of(pending)) {
      decide(a, false);
    }
    _tokens.clear();
    await Fgs.stop();
    peers.clear();
    notifyListeners();
  }

  void share(List<String> paths) {
    for (final x in paths) {
      if (File(x).existsSync() || Directory(x).existsSync()) shared[p.basename(x)] = x;
    }
    notifyListeners();
  }

  void unshare(String name) {
    shared.remove(name);
    notifyListeners();
  }

  static bool _badSeg(String s) => s == '..' || s == '.' || s.contains('\\') || s.contains('\u0000');

  Future<void> _handle(HttpRequest r, bool secure) async {
    try {
      final path = r.uri.path;
      final ip = r.connectionInfo?.remoteAddress.address ?? '';
      if (r.method == 'GET' && path == '/ping') {
        r.response.write(deviceName);
        return;
      }
      if (r.method == 'GET' && path == '/info') {
        r.response.headers.contentType = ContentType.json;
        r.response.write(jsonEncode({'pin': requirePin, 'approve': requireApproval, 'tls': _tls != null, 'tlsPort': tlsPort}));
        return;
      }
      if (_tls != null && !secure) {
        // with HTTPS active the plain-HTTP port only redirects (PIN and files never travel in clear text)
        if (r.method == 'GET' && path == '/') {
          final host = (r.headers.host ?? myIp ?? '').toString();
          r.response.statusCode = 302;
          r.response.headers.set('location', 'https://$host:$tlsPort/');
        } else {
          r.response.statusCode = 426;
        }
        return;
      }
      if (r.method == 'POST' && path == '/auth') {
        final t = _login(ip, (await utf8.decoder.bind(r).join()).trim());
        if (t == null) {
          r.response.statusCode = 401;
        } else {
          r.response.cookies.add(Cookie('abt', t)..path = '/'..httpOnly = true);
          r.response.write(t);
        }
        return;
      }
      if (r.method == 'GET' && path == '/' && r.uri.queryParameters.containsKey('pin')) {
        final t = _login(ip, r.uri.queryParameters['pin'] ?? '');
        if (t != null) r.response.cookies.add(Cookie('abt', t)..path = '/'..httpOnly = true);
        r.response.statusCode = 302;
        r.response.headers.set('location', '/');
        return;
      }
      if (!_authed(r)) {
        if (r.method == 'GET' && path == '/') {
          r.response.headers.contentType = ContentType.html;
          r.response.write(_loginPage());
        } else {
          r.response.statusCode = 401;
        }
        return;
      }
      if (r.method == 'GET' && path == '/') {
        r.response.headers.contentType = ContentType.html;
        r.response.write(_page());
      } else if (r.method == 'GET' && path.startsWith('/zip/')) {
        final name = Uri.decodeComponent(path.substring(5));
        final root = shared[name];
        if (root == null || !Directory(root).existsSync()) {
          r.response.statusCode = 404;
        } else {
          final tmp = '${Directory.systemTemp.path}/abt_${_rnd(4)}.zip';
          try {
            ZipFileEncoder().zipDirectory(Directory(root), filename: tmp);
            r.response.headers.contentType = ContentType('application', 'zip');
            r.response.headers.add('content-disposition', "attachment; filename*=UTF-8''${Uri.encodeComponent('$name.zip')}");
            r.response.contentLength = await File(tmp).length();
            await r.response.addStream(File(tmp).openRead());
          } finally {
            try { File(tmp).deleteSync(); } catch (_) {}
          }
        }
      } else if (r.method == 'GET' && path.startsWith('/dl/')) {
        final segs = Uri.decodeComponent(path.substring(4)).split('/');
        final name = segs.first;
        final root = shared[name];
        final sub = segs.skip(1).where((x) => x.isNotEmpty).toList();
        if (root == null || sub.any(_badSeg)) {
          r.response.statusCode = root == null ? 404 : 400;
        } else {
          final target = sub.isEmpty ? root : p.joinAll([root, ...sub]);
          if (Directory(target).existsSync()) {
            r.response.headers.contentType = ContentType.html;
            r.response.write(_folderPage(name, sub, target));
          } else if (File(target).existsSync()) {
            final f = File(target);
            r.response.headers.contentType = ContentType.binary;
            r.response.headers.add('content-disposition', "attachment; filename*=UTF-8''${Uri.encodeComponent(p.basename(target))}");
            r.response.contentLength = await f.length();
            await r.response.addStream(f.openRead());
          } else {
            r.response.statusCode = 404;
          }
        }
      } else if ((r.method == 'PUT' || r.method == 'POST') && path.startsWith('/up/')) {
        final segs = Uri.decodeComponent(path.substring(4)).split('/').where((x) => x.isNotEmpty).toList();
        if (segs.isEmpty || segs.any(_badSeg)) {
          r.response.statusCode = 400;
          return;
        }
        final name = segs.length > 1 ? '${segs.first}/…' : segs.first;
        if (requireApproval && !_approved.contains(ip) && !await _ask(ip, name)) {
          r.response.statusCode = 403;
          log.insert(0, 'Rejected: $name from $ip');
          notifyListeners();
          return;
        }
        await Directory(receiveDir).create(recursive: true);
        String target;
        if (segs.length == 1) {
          target = FileOps.unique(receiveDir, segs.first);
        } else {
          // folder upload: one fresh top-level folder per batch, sub-structure preserved
          final key = '$ip|${r.headers.value('x-abt-batch') ?? ''}|${segs.first}';
          if (_batches.length > 200) _batches.clear();
          final top = _batches.putIfAbsent(key, () => FileOps.unique(receiveDir, segs.first));
          target = p.joinAll([top, ...segs.skip(1)]);
          await Directory(p.dirname(target)).create(recursive: true);
        }
        final sink = File(target).openWrite();
        await sink.addStream(r);
        await sink.close();
        log.insert(0, 'Received: ${segs.length > 1 ? segs.join('/') : p.basename(target)}');
        notifyListeners();
        r.response.write('ok');
      } else {
        r.response.statusCode = 404;
      }
    } catch (e) {
      r.response.statusCode = 500;
      log.insert(0, 'Error: $e');
      notifyListeners();
    } finally {
      await r.response.close();
    }
  }

  String _loginPage() => '''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Abtin</title>
<style>body{font-family:sans-serif;background:#070b1a;color:#fff;padding:30px;max-width:420px;margin:auto;text-align:center}input{font-size:26px;width:140px;text-align:center;border-radius:10px;border:0;padding:8px}button{background:#2f6bff;color:#fff;border:0;border-radius:10px;padding:12px 22px;font-size:16px;margin-top:14px}</style></head>
<body><h2>Abtin File Manager</h2><div>${const HtmlEscape().convert(deviceName)}</div><form method="get" action="/"><p>PIN</p><input name="pin" inputmode="numeric" autofocus><br><button>OK</button></form></body></html>''';

  String _page() {
    final items = shared.entries.map((e) {
      final dir = Directory(e.value).existsSync();
      final n = e.key, enc = Uri.encodeComponent(n), esc = const HtmlEscape().convert(n);
      return dir ? '<li>📁 <a href="/dl/$enc/">$esc</a> — <a href="/zip/$enc">zip</a></li>' : '<li><a href="/dl/$enc">$esc</a></li>';
    }).join();
    return _html.replaceAll('{{NAME}}', deviceName).replaceAll('{{ITEMS}}', items.isEmpty ? '<li>-</li>' : items);
  }

  String _folderPage(String top, List<String> sub, String dir) {
    const esc = HtmlEscape();
    final base = '/dl/${Uri.encodeComponent(top)}/${sub.map(Uri.encodeComponent).map((x) => '$x/').join()}';
    final ents = Directory(dir).listSync(followLinks: false)..sort((a, b) => p.basename(a.path).toLowerCase().compareTo(p.basename(b.path).toLowerCase()));
    final b = StringBuffer('<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc.convert(top)}</title><style>body{font-family:sans-serif;background:#070b1a;color:#fff;padding:20px;max-width:640px;margin:auto}a{color:#7aa2ff}li{margin:6px 0}</style></head><body>');
    b.write('<h3>${esc.convert([top, ...sub].join(' / '))}</h3><p><a href="/">⌂</a>');
    if (sub.isEmpty) b.write(' — <a href="/zip/${Uri.encodeComponent(top)}">zip</a>');
    b.write('</p><ul>');
    if (sub.isNotEmpty) b.write('<li><a href="../">..</a></li>');
    for (final e in ents) {
      final n = p.basename(e.path), enc = Uri.encodeComponent(n);
      b.write(e is Directory ? '<li>📁 <a href="$base$enc/">${esc.convert(n)}</a></li>' : '<li><a href="$base$enc">${esc.convert(n)}</a></li>');
    }
    b.write('</ul></body></html>');
    return b.toString();
  }

  static const _html = r'''<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Abtin File Manager</title><style>body{font-family:sans-serif;background:#070b1a;color:#fff;padding:20px;max-width:640px;margin:auto}
a{color:#7aa2ff}.box{background:#111a33;border-radius:14px;padding:16px;margin:14px 0}button{background:#2f6bff;color:#fff;border:0;border-radius:10px;padding:10px 18px;font-size:16px}
progress{width:100%}</style></head><body><h2>Abtin File Manager</h2><div>{{NAME}}</div>
<div class="box"><h3>Download from device</h3><ul>{{ITEMS}}</ul></div>
<div class="box"><h3>Upload to device</h3><input type="file" id="f" multiple><br><br><input type="file" id="d" webkitdirectory multiple><br><br><button onclick="up()">Upload</button><br><br><progress id="p" value="0" max="100"></progress><div id="s"></div></div>
<script>
async function up(){const fs=[...document.getElementById('f').files,...document.getElementById('d').files];const b=Math.random().toString(36).slice(2);for(const f of fs){const nm=f.webkitRelativePath||f.name;await new Promise(res=>{const x=new XMLHttpRequest();
x.open('PUT','/up/'+nm.split('/').map(encodeURIComponent).join('/'));x.setRequestHeader('x-abt-batch',b);x.upload.onprogress=e=>{document.getElementById('p').value=e.loaded/e.total*100};
x.onload=()=>{document.getElementById('s').innerText+='\n'+nm+' OK';res()};x.onerror=()=>{document.getElementById('s').innerText+='\n'+nm+' FAILED';res()};x.send(f)})}}
</script></body></html>''';

  /// Sends files and/or folders (structure preserved) to another Abtin device. HTTPS is used when the receiver offers it
  /// (certificate pinned on first use). Throws [NeedPin] when the receiver requires a PIN and none was given.
  Future<void> sendTo(String ip, int prt, List<String> paths, {String? pin}) async {
    await _prefs();
    final c = HttpClient()
      ..connectionTimeout = const Duration(seconds: 4)
      ..badCertificateCallback = (cert, host, _) => _trust(cert, host);
    try {
      var scheme = 'http', pt = prt;
      var needPin = false;
      Future<bool> probe(String sc, int port) async {
        try {
          final rq = await c.getUrl(Uri.parse('$sc://$ip:$port/info'));
          final rs = await rq.close();
          final body = await utf8.decodeStream(rs);
          if (rs.statusCode == 200) {
            needPin = (jsonDecode(body) as Map)['pin'] == true;
            return true;
          }
        } on HandshakeException {
          throw 'Certificate of $ip changed – refusing to send';
        } catch (_) {}
        return false;
      }

      if (await probe('https', tlsPort)) {
        scheme = 'https';
        pt = tlsPort;
      } else {
        await probe('http', prt);
      }
      String? token;
      if (needPin) {
        if (pin == null || pin.isEmpty) throw NeedPin();
        final rq = await c.postUrl(Uri.parse('$scheme://$ip:$pt/auth'));
        rq.write(pin);
        final rs = await rq.close();
        final body = await utf8.decodeStream(rs);
        if (rs.statusCode != 200) throw 'Wrong PIN';
        token = body.trim();
      }
      final items = <(String, String)>[];
      for (final x in paths) {
        if (FileSystemEntity.isDirectorySync(x)) {
          final base = p.dirname(x);
          await for (final e in Directory(x).list(recursive: true, followLinks: false)) {
            if (e is File) items.add((e.path, p.relative(e.path, from: base).replaceAll('\\', '/')));
          }
        } else {
          items.add((x, p.basename(x)));
        }
      }
      final batch = _rnd(6);
      var n = 0;
      for (final (f, rel) in items) {
        n++;
        final file = File(f);
        final len = await file.length();
        status = '$rel ($n/${items.length})';
        var sent = 0;
        final enc = rel.split('/').map(Uri.encodeComponent).join('/');
        final req = await c.putUrl(Uri.parse('$scheme://$ip:$pt/up/$enc'));
        if (token != null) req.headers.set('x-abt-token', token);
        req.headers.set('x-abt-batch', batch);
        req.contentLength = len;
        HttpClientResponse res;
        try {
          await req.addStream(file.openRead().map((chunk) {
            sent += chunk.length;
            progress = len == 0 ? 1 : sent / len;
            notifyListeners();
            return chunk;
          }));
          res = await req.close();
        } on SocketException {
          throw 'Rejected by the receiver or connection lost';
        }
        await res.drain();
        if (res.statusCode == 403) throw 'Rejected by the receiver';
        if (res.statusCode != 200) throw 'HTTP ${res.statusCode}';
        log.insert(0, 'Sent: $rel -> $ip');
      }
    } finally {
      c.close();
      progress = null;
      status = null;
      notifyListeners();
    }
  }
}
