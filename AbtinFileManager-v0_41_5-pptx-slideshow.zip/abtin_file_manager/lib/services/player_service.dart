import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:audio_service/audio_service.dart'
    show AudioService, AudioServiceConfig, MediaItem;
import 'package:audio_session/audio_session.dart';
import 'package:audio_metadata_reader/audio_metadata_reader.dart';
import 'package:flutter/foundation.dart';
import 'package:media_kit/media_kit.dart';
import 'package:path/path.dart' as p;
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'audio_handler.dart';
import 'media_store.dart';
import 'widget_native.dart';

class TrackMeta {
  final String title, artist, album;
  final Uint8List? art;
  final String? artPath;
  TrackMeta(this.title, this.artist, this.album, this.art, this.artPath);
}

class PlayerService extends ChangeNotifier {
  final Player player = Player();
  AbtinAudioHandler? handler;
  List<String> queue = [];
  int index = 0;
  bool playing = false, shuffle = false;
  PlaylistMode mode = PlaylistMode.none;
  List<double> eq = List.filled(10, 0);
  double bass = 0, preamp = 0, volume = 100;
  bool eqOn = false;
  // playback options
  bool gapless = true;
  double crossfade = 0; // seconds, 0 = off
  String rgMode = 'no'; // ReplayGain: no | track | album
  double rgPreamp = 0; // dB
  bool rgClip = true; // prevent clipping
  String _af = '';
  Player?
      _fx; // plays the tail of the outgoing track while the main player fades the next one in
  bool _fading = false;
  Timer? _fadeT;
  static const eqFreqs = [
    60,
    170,
    310,
    600,
    1000,
    3000,
    6000,
    12000,
    14000,
    16000
  ];

  // sleep timer
  Timer? _sleep;
  DateTime? sleepAt;
  bool sleepEndOfTrack = false;

  // A-B loop: 0 off, 1 A set, 2 looping
  int abStage = 0;

  final Map<String, TrackMeta> _meta = {};
  bool _focusPaused = false, _askedNotif = false;
  DateTime _lastSave = DateTime.fromMillisecondsSinceEpoch(0),
      _lastPub = DateTime.fromMillisecondsSinceEpoch(0);

  void touch() => notifyListeners();
  bool get hasQueue => queue.isNotEmpty;
  String get current => hasQueue ? queue[index.clamp(0, queue.length - 1)] : '';
  TrackMeta? get meta => _meta[current];
  String get title =>
      meta?.title ?? p.basenameWithoutExtension(Uri.decodeFull(current));
  String get artist =>
      meta?.artist ??
      (hasQueue && !current.startsWith('http')
          ? p.basename(p.dirname(current))
          : '');
  String get album => meta?.album ?? '';

  PlayerService() {
    player.stream.playing.listen((v) {
      playing = v;
      if (_fading) {
        if (v) {
          _fx?.play();
        } else {
          _fx?.pause();
        }
      }
      handler?.publish();
      if (hasQueue) WidgetNative.update(title, artist, v);
      notifyListeners();
    });
    player.stream.playlist.listen((pl) {
      if (pl.index != index) {
        index = pl.index;
        _onTrackChanged();
      }
      notifyListeners();
    });
    player.stream.position.listen(_tick);
    player.stream.duration.listen((_) => _pushItem());
    player.stream.buffering.listen((_) => handler?.publish());
    _loadPrefs();
  }

  // ---------- background / session ----------
  Future<void> initBackground() async {
    try {
      final s = await AudioSession.instance;
      await s.configure(const AudioSessionConfiguration.music());
      s.interruptionEventStream.listen((e) {
        if (e.begin) {
          if (e.type == AudioInterruptionType.duck) {
            player.setVolume(volume * .3);
          } else if (playing) {
            _focusPaused = true;
            player.pause();
          }
        } else {
          if (e.type == AudioInterruptionType.duck) {
            player.setVolume(volume);
          } else if (_focusPaused) {
            _focusPaused = false;
            player.play();
          }
        }
      });
      s.becomingNoisyEventStream.listen((_) => player.pause());
    } catch (_) {}
    try {
      handler = await AudioService.init(
        builder: () => AbtinAudioHandler(this),
        config: const AudioServiceConfig(
          androidNotificationChannelId: 'ir.abtin.filemanager.audio',
          androidNotificationChannelName: 'Abtin Media',
          androidNotificationOngoing: true,
          androidStopForegroundOnPause: true,
        ),
      );
    } catch (_) {}
  }

  // ---------- metadata ----------
  Future<void> _loadMeta(String path) async {
    if (_meta.containsKey(path) || path.startsWith('http')) return;
    var title = p.basenameWithoutExtension(path), artist = '', album = '';
    Uint8List? art;
    String? artPath;
    try {
      final m =
          await Future.sync(() => readMetadata(File(path), getImage: true));
      if ((m.title ?? '').trim().isNotEmpty) title = m.title!.trim();
      artist = (m.artist ?? '').trim();
      album = (m.album ?? '').trim();
      if (m.pictures.isNotEmpty) {
        art = m.pictures.first.bytes;
        final f =
            File('${Directory.systemTemp.path}/abtin_art_${path.hashCode}.img');
        if (!f.existsSync()) await f.writeAsBytes(art);
        artPath = f.path;
      }
    } catch (_) {}
    if (artist.isEmpty) artist = p.basename(p.dirname(path));
    if (_meta.length > 150) _meta.remove(_meta.keys.first);
    _meta[path] = TrackMeta(title, artist, album, art, artPath);
    if (current == path) {
      _pushItem();
      notifyListeners();
    }
  }

  void _pushItem() {
    final h = handler;
    if (h == null || !hasQueue) return;
    final d = player.state.duration;
    h.setItem(MediaItem(
      id: current,
      title: title,
      artist: artist,
      album: album.isEmpty ? null : album,
      duration: d == Duration.zero ? null : d,
      artUri: meta?.artPath != null ? Uri.file(meta!.artPath!) : null,
    ));
    h.publish();
    WidgetNative.update(title, artist, playing);
  }

  Future<void> _onTrackChanged() async {
    abStage = 0;
    await _loadMeta(current);
    _pushItem();
    _resume(current);
  }

  Future<void> _resume(String path) async {
    final st = MediaStore.state(path);
    if (st == null || !_isLong(st[1])) return;
    try {
      await player.stream.duration
          .firstWhere((d) => d > Duration.zero)
          .timeout(const Duration(seconds: 6));
      if (current == path) await player.seek(Duration(milliseconds: st[0]));
    } catch (_) {}
  }

  static bool _isLong(int durMs) =>
      durMs > 10 * 60 * 1000; // remember position of podcasts / audiobooks only

  void _tick(Duration pos) {
    final now = DateTime.now();
    final dur = player.state.duration;
    if (sleepEndOfTrack &&
        dur > Duration.zero &&
        dur - pos < const Duration(milliseconds: 700)) {
      sleepEndOfTrack = false;
      player.pause();
      notifyListeners();
    }
    if (crossfade > 0 &&
        !_fading &&
        playing &&
        abStage == 0 &&
        !sleepEndOfTrack &&
        mode != PlaylistMode.single &&
        _hasNext &&
        dur.inSeconds > crossfade * 2 + 2) {
      final rem = dur - pos;
      if (rem <= Duration(milliseconds: (crossfade * 1000).round()) &&
          rem > const Duration(milliseconds: 500)) _startFade();
    }
    if (now.difference(_lastPub) > const Duration(seconds: 1)) {
      _lastPub = now;
      handler?.publish();
    }
    if (hasQueue &&
        playing &&
        now.difference(_lastSave) > const Duration(seconds: 5) &&
        _isLong(dur.inMilliseconds)) {
      _lastSave = now;
      MediaStore.savePos(current, pos, dur);
    }
  }

  // ---------- playback ----------
  Future<void> playList(List<String> paths, int start) async {
    _cancelFade();
    queue = List.of(paths);
    index = start.clamp(0, paths.length - 1);
    abStage = 0;
    try {
      await (await AudioSession.instance).setActive(true);
    } catch (_) {}
    if (!_askedNotif) {
      _askedNotif = true;
      try {
        Permission.notification.request();
      } catch (_) {}
    }
    await player
        .open(Playlist(queue.map((e) => Media(e)).toList(), index: index));
    await _applyOptsTo(player);
    if (_af.isNotEmpty) {
      try {
        await (player.platform as dynamic).setProperty('af', _af);
      } catch (_) {}
    }
    _onTrackChanged();
    notifyListeners();
  }

  /// Adds a track to the queue (right after the current one when [next]).
  Future<void> enqueue(String path, {bool next = false}) async {
    if (!hasQueue) return playList([path], 0);
    await player.add(Media(path));
    queue.add(path);
    if (next && queue.length - 1 != index + 1)
      await moveItem(queue.length - 1, index + 1);
    notifyListeners();
  }

  /// [to] is the final index of the moved item.
  Future<void> moveItem(int from, int to) async {
    if (from == to) return;
    await player.move(from, to);
    final it = queue.removeAt(from);
    queue.insert(to, it);
    if (index == from) {
      index = to;
    } else if (from < index && to >= index) {
      index--;
    } else if (from > index && to <= index) {
      index++;
    }
    notifyListeners();
  }

  Future<void> removeAt(int i) async {
    if (queue.length <= 1) return stopAll();
    await player.remove(i);
    queue.removeAt(i);
    if (i < index) index--;
    notifyListeners();
  }

  Future<void> seekBy(Duration d) async {
    final dur = player.state.duration;
    var t = player.state.position + d;
    if (t < Duration.zero) t = Duration.zero;
    if (dur > Duration.zero && t > dur) t = dur;
    await player.seek(t);
  }

  Future<void> setVolume(double v) async {
    volume = v.clamp(0, 100).toDouble();
    await player.setVolume(volume);
    _savePrefs();
    notifyListeners();
  }

  Future<void> cycleMode() async {
    mode = mode == PlaylistMode.none
        ? PlaylistMode.loop
        : mode == PlaylistMode.loop
            ? PlaylistMode.single
            : PlaylistMode.none;
    await player.setPlaylistMode(mode);
    _savePrefs();
    notifyListeners();
  }

  Future<void> toggleShuffle() async {
    shuffle = !shuffle;
    await player.setShuffle(shuffle);
    _savePrefs();
    notifyListeners();
  }

  Future<void> setRate(double r) async {
    await player.setRate(r);
    handler?.publish();
    notifyListeners();
  }

  Future<void> toggleAB() async {
    final pos = (player.state.position.inMilliseconds / 1000).toString();
    try {
      final np = player.platform as dynamic;
      if (abStage == 0) {
        await np.setProperty('ab-loop-a', pos);
        abStage = 1;
      } else if (abStage == 1) {
        await np.setProperty('ab-loop-b', pos);
        abStage = 2;
      } else {
        await np.setProperty('ab-loop-a', 'no');
        await np.setProperty('ab-loop-b', 'no');
        abStage = 0;
      }
    } catch (_) {}
    notifyListeners();
  }

  // ---------- gapless / crossfade / ReplayGain ----------
  bool get _hasNext =>
      queue.length > 1 &&
      (index < queue.length - 1 || mode == PlaylistMode.loop || shuffle);

  Future<void> _applyOptsTo(Player pl) async {
    try {
      final np = pl.platform as dynamic;
      await np.setProperty('gapless-audio', gapless ? 'yes' : 'no');
      await np.setProperty('prefetch-playlist', 'yes');
      await np.setProperty('replaygain', rgMode);
      await np.setProperty('replaygain-preamp', rgPreamp.toStringAsFixed(1));
      await np.setProperty('replaygain-clip', rgClip ? 'yes' : 'no');
      await np.setProperty('af', _af);
    } catch (_) {}
  }

  /// Applies gapless / ReplayGain to the players and stores the settings. ReplayGain takes effect from the next track.
  Future<void> applyAudioOpts() async {
    if (crossfade <= 0) _cancelFade();
    await _applyOptsTo(player);
    if (_fx != null) await _applyOptsTo(_fx!);
    _savePrefs();
    notifyListeners();
  }

  void _cancelFade() {
    _fadeT?.cancel();
    _fadeT = null;
    if (_fading) {
      _fading = false;
      player.setVolume(volume);
      _fx?.stop();
    }
  }

  /// Real overlap: the outgoing track keeps playing on a second player (fading out) while the main player
  /// jumps to the next track (fading in), so queue state, notification and lyrics follow the main player.
  Future<void> _startFade() async {
    _fading = true;
    final old = current;
    final pos = player.state.position;
    final sw = Stopwatch()..start();
    try {
      final fx = _fx ??= Player();
      await _applyOptsTo(fx);
      await fx.setVolume(volume);
      await fx.open(Media(old), play: false);
      if (fx.state.duration == Duration.zero) {
        await fx.stream.duration
            .firstWhere((d) => d > Duration.zero)
            .timeout(const Duration(seconds: 2));
      }
      await fx.seek(pos + sw.elapsed);
      await fx.play();
      await player.setVolume(0);
      await player.next();
    } catch (_) {
      _cancelFade();
      return;
    }
    final steps = (crossfade * 20).round().clamp(1, 1000).toInt();
    var k = 0;
    _fadeT = Timer.periodic(const Duration(milliseconds: 50), (t) {
      k++;
      final x = (k / steps).clamp(0.0, 1.0).toDouble();
      player.setVolume(volume * x);
      _fx?.setVolume(volume * (1 - x));
      if (k >= steps) {
        t.cancel();
        _fadeT = null;
        _fx?.stop();
        _fading = false;
      }
    });
  }

  /// Re-reads title / artist / art of a file after its tags were edited.
  Future<void> reloadMeta(String path) async {
    _meta.remove(path);
    final old =
        File('${Directory.systemTemp.path}/abtin_art_${path.hashCode}.img');
    try {
      if (old.existsSync()) old.deleteSync();
    } catch (_) {}
    await _loadMeta(path);
  }

  // ---------- sleep timer ----------
  void setSleep(Duration? d, {bool endOfTrack = false}) {
    _sleep?.cancel();
    _sleep = null;
    sleepAt = null;
    sleepEndOfTrack = endOfTrack;
    if (d != null) {
      sleepAt = DateTime.now().add(d);
      _sleep = Timer(d, () {
        player.pause();
        sleepAt = null;
        notifyListeners();
      });
    }
    notifyListeners();
  }

  bool get sleepActive => sleepAt != null || sleepEndOfTrack;

  // ---------- equalizer ----------
  Future<void> applyEq() async {
    final f = <String>[];
    if (eqOn) {
      if (preamp != 0) f.add('volume=${preamp.toStringAsFixed(1)}dB');
      if (bass != 0) f.add('bass=g=${bass.toStringAsFixed(1)}');
      for (var i = 0; i < 10; i++) {
        if (eq[i] != 0)
          f.add(
              'equalizer=f=${eqFreqs[i]}:t=o:w=1:g=${eq[i].toStringAsFixed(1)}');
      }
    }
    _af = f.isEmpty ? '' : 'lavfi=[${f.join(',')}]';
    try {
      await (player.platform as dynamic).setProperty('af', _af);
    } catch (_) {}
    if (_fx != null) {
      try {
        await (_fx!.platform as dynamic).setProperty('af', _af);
      } catch (_) {}
    }
    _savePrefs();
    notifyListeners();
  }

  // ---------- prefs ----------
  Future<void> _loadPrefs() async {
    try {
      final p = await SharedPreferences.getInstance();
      final e = p.getStringList('eq');
      if (e != null && e.length == 10) eq = e.map(double.parse).toList();
      bass = p.getDouble('bass') ?? 0;
      preamp = p.getDouble('preamp') ?? 0;
      eqOn = p.getBool('eqOn') ?? false;
      volume = p.getDouble('vol') ?? 100;
      shuffle = p.getBool('shuffle') ?? false;
      mode = PlaylistMode.values[(p.getInt('loop') ?? 0).clamp(0, 2)];
      gapless = p.getBool('gapless') ?? true;
      crossfade = p.getDouble('xfade') ?? 0;
      rgMode = p.getString('rgMode') ?? 'no';
      rgPreamp = p.getDouble('rgPre') ?? 0;
      rgClip = p.getBool('rgClip') ?? true;
      await player.setVolume(volume);
      await player.setShuffle(shuffle);
      await player.setPlaylistMode(mode);
      if (eqOn) await applyEq();
      await _applyOptsTo(player);
      notifyListeners();
    } catch (_) {}
  }

  Future<void> _savePrefs() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setStringList('eq', eq.map((e) => e.toString()).toList());
      await p.setDouble('bass', bass);
      await p.setDouble('preamp', preamp);
      await p.setBool('eqOn', eqOn);
      await p.setDouble('vol', volume);
      await p.setBool('shuffle', shuffle);
      await p.setInt('loop', mode.index);
      await p.setBool('gapless', gapless);
      await p.setDouble('xfade', crossfade);
      await p.setString('rgMode', rgMode);
      await p.setDouble('rgPre', rgPreamp);
      await p.setBool('rgClip', rgClip);
    } catch (_) {}
  }

  Future<void> stopAll() async {
    _cancelFade();
    if (hasQueue && _isLong(player.state.duration.inMilliseconds))
      MediaStore.savePos(current, player.state.position, player.state.duration);
    setSleep(null);
    await player.stop();
    queue = [];
    index = 0;
    abStage = 0;
    handler?.clear();
    notifyListeners();
  }

  @override
  void dispose() {
    _sleep?.cancel();
    _fadeT?.cancel();
    _fx?.dispose();
    player.dispose();
    super.dispose();
  }
}
