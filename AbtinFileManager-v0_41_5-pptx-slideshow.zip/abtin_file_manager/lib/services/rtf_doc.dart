import 'doc_legacy.dart' show DocPara, DocRun;

/// RTF reader/writer that keeps bold / italic / underline / size / colour / alignment / direction.
/// Code pages: 1256 (Arabic/Persian) and 1252 are decoded; \uN escapes always work.
class RtfDoc {
  // Windows-1256 0x80..0xFF
  static const _cp1256 = [
    0x20AC, 0x067E, 0x201A, 0x0192, 0x201E, 0x2026, 0x2020, 0x2021, 0x02C6, 0x2030, 0x0679, 0x2039, 0x0152, 0x0686, 0x0698, 0x0688,
    0x06AF, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014, 0x06A9, 0x2122, 0x0691, 0x203A, 0x0153, 0x200C, 0x200D, 0x06BA,
    0x00A0, 0x060C, 0x00A2, 0x00A3, 0x00A4, 0x00A5, 0x00A6, 0x00A7, 0x00A8, 0x00A9, 0x06BE, 0x00AB, 0x00AC, 0x00AD, 0x00AE, 0x00AF,
    0x00B0, 0x00B1, 0x00B2, 0x00B3, 0x00B4, 0x00B5, 0x00B6, 0x00B7, 0x00B8, 0x00B9, 0x061B, 0x00BB, 0x00BC, 0x00BD, 0x00BE, 0x061F,
    0x06C1, 0x0621, 0x0622, 0x0623, 0x0624, 0x0625, 0x0626, 0x0627, 0x0628, 0x0629, 0x062A, 0x062B, 0x062C, 0x062D, 0x062E, 0x062F,
    0x0630, 0x0631, 0x0632, 0x0633, 0x0634, 0x0635, 0x0636, 0x00D7, 0x0637, 0x0638, 0x0639, 0x063A, 0x0640, 0x0641, 0x0642, 0x0643,
    0x00E0, 0x0644, 0x00E2, 0x0645, 0x0646, 0x0647, 0x0648, 0x00E7, 0x00E8, 0x00E9, 0x00EA, 0x00EB, 0x0649, 0x064A, 0x00EE, 0x00EF,
    0x064B, 0x064C, 0x064D, 0x064E, 0x00F4, 0x064F, 0x0650, 0x00F7, 0x0651, 0x00F9, 0x0652, 0x00FB, 0x00FC, 0x200E, 0x200F, 0x06D2,
  ];

  static const _skipDest = {'fonttbl', 'colortbl', 'stylesheet', 'info', 'pict', 'header', 'footer', 'headerl', 'headerr', 'footerl', 'footerr', 'fldinst', 'listtable', 'listoverridetable', 'rsidtbl', 'generator', 'themedata', 'colorschememapping', 'datastore', 'latentstyles', 'xmlnstbl', 'object', 'private'};
  static const _chars = {'emdash': '—', 'endash': '–', 'bullet': '•', 'lquote': '‘', 'rquote': '’', 'ldblquote': '“', 'rdblquote': '”', 'tab': '\t', 'line': '\n', 'cell': '\t', 'emspace': ' ', 'enspace': ' ', 'zwnj': '\u200C', 'zwj': '\u200D', 'ltrmark': '\u200E', 'rtlmark': '\u200F'};

  static bool _isL(int c) => (c >= 65 && c <= 90) || (c >= 97 && c <= 122);

  static List<DocPara> parse(String s) {
    final cpM = RegExp(r'\\ansicpg(\d+)').firstMatch(s);
    final cp = cpM == null ? 1252 : int.parse(cpM[1]!);
    // colour table
    final colors = <int?>[null];
    final ct = RegExp(r'\{\\colortbl([^}]*)\}').firstMatch(s);
    if (ct != null) {
      final parts = ct[1]!.split(';');
      for (var k = 0; k < parts.length - 1; k++) {
        final r = RegExp(r'\\red(\d+)').firstMatch(parts[k]), g = RegExp(r'\\green(\d+)').firstMatch(parts[k]), b = RegExp(r'\\blue(\d+)').firstMatch(parts[k]);
        if (k == 0 && r == null) continue; // auto
        colors.add(r == null ? null : (int.parse(r[1]!) << 16) | (int.parse(g?[1] ?? '0') << 8) | int.parse(b?[1] ?? '0'));
      }
    }
    final out = <DocPara>[];
    var cur = DocPara();
    var jc = 0;
    var rtl = false;
    var b = false, it = false, u = false;
    var sz = 0, cf = 0;
    var skip = false;
    var uc = 1, pend = 0;
    final stack = <List<Object>>[];

    void emit(String t) {
      if (skip) return;
      if (pend > 0) {
        pend--;
        return;
      }
      final col = cf > 0 && cf < colors.length ? colors[cf] : null;
      if (cur.runs.isNotEmpty) {
        final l = cur.runs.last;
        if (l.b == b && l.i == it && l.u == u && l.sz == sz && l.color == col) {
          l.text += t;
          return;
        }
      }
      cur.runs.add(DocRun(t, b: b, i: it, u: u, sz: sz, color: col));
    }

    void par() {
      if (skip) return;
      cur.jc = jc;
      cur.rtl = rtl;
      out.add(cur);
      cur = DocPara();
    }

    var i = 0;
    while (i < s.length) {
      final c = s[i];
      if (c == '{') {
        stack.add([skip, b, it, u, sz, cf, uc]);
        i++;
      } else if (c == '}') {
        if (stack.isNotEmpty) {
          final st = stack.removeLast();
          skip = st[0] as bool;
          b = st[1] as bool;
          it = st[2] as bool;
          u = st[3] as bool;
          sz = st[4] as int;
          cf = st[5] as int;
          uc = st[6] as int;
        }
        i++;
      } else if (c == '\\') {
        if (i + 1 >= s.length) break;
        final n = s[i + 1];
        if (n == '\\' || n == '{' || n == '}') {
          emit(n);
          i += 2;
        } else if (n == "'") {
          final h = i + 4 <= s.length ? int.tryParse(s.substring(i + 2, i + 4), radix: 16) : null;
          if (h != null) emit(String.fromCharCode(h >= 0x80 && cp == 1256 ? _cp1256[h - 0x80] : h));
          i += 4;
        } else if (n == '*') {
          skip = true;
          i += 2;
        } else if (n == '~') {
          emit('\u00A0');
          i += 2;
        } else if (n == '-') {
          i += 2;
        } else if (n == '_') {
          emit('-');
          i += 2;
        } else if (_isL(n.codeUnitAt(0))) {
          var j = i + 1;
          while (j < s.length && _isL(s.codeUnitAt(j))) {
            j++;
          }
          final w = s.substring(i + 1, j);
          var k = j;
          if (k < s.length && (s[k] == '-' || (s.codeUnitAt(k) >= 48 && s.codeUnitAt(k) <= 57))) {
            k++;
            while (k < s.length && s.codeUnitAt(k) >= 48 && s.codeUnitAt(k) <= 57) {
              k++;
            }
          }
          final param = k > j ? int.tryParse(s.substring(j, k)) : null;
          if (k < s.length && s[k] == ' ') k++;
          switch (w) {
            case 'u':
              if (param != null) {
                emit(String.fromCharCode(param < 0 ? param + 65536 : param));
                if (!skip) pend = uc;
              }
              break;
            case 'uc':
              if (param != null) uc = param;
              break;
            case 'b':
              b = param != 0;
              break;
            case 'i':
              it = param != 0;
              break;
            case 'ul':
            case 'uld':
            case 'uldb':
            case 'ulw':
              u = param != 0;
              break;
            case 'ulnone':
              u = false;
              break;
            case 'fs':
              if (param != null) sz = param;
              break;
            case 'cf':
              if (param != null) cf = param;
              break;
            case 'plain':
              b = false;
              it = false;
              u = false;
              sz = 0;
              cf = 0;
              break;
            case 'pard':
              jc = 0;
              rtl = false;
              break;
            case 'qc':
              jc = 1;
              break;
            case 'qr':
              jc = 2;
              break;
            case 'qj':
              jc = 3;
              break;
            case 'ql':
              jc = 0;
              break;
            case 'rtlpar':
              rtl = true;
              break;
            case 'ltrpar':
              rtl = false;
              break;
            case 'par':
            case 'sect':
            case 'page':
              par();
              break;
            case 'row':
              emit('\n');
              break;
            default:
              if (_skipDest.contains(w)) {
                skip = true;
              } else if (_chars.containsKey(w)) {
                emit(_chars[w]!);
              }
          }
          i = k;
        } else {
          i += 2;
        }
      } else if (c == '\n' || c == '\r') {
        i++;
      } else {
        emit(c);
        i++;
      }
    }
    if (cur.runs.isNotEmpty) par();
    return out;
  }

  static String _esc(String t) {
    final b = StringBuffer();
    for (final u in t.codeUnits) {
      if (u == 10) {
        b.write('\\line ');
      } else if (u == 13) {
        continue;
      } else if (u == 9) {
        b.write('\\tab ');
      } else if (u == 92 || u == 123 || u == 125) {
        b.write('\\${String.fromCharCode(u)}');
      } else if (u < 128) {
        b.writeCharCode(u);
      } else {
        b.write('\\u${u > 32767 ? u - 65536 : u}?');
      }
    }
    return b.toString();
  }

  static String write(List<DocPara> ps) {
    final cols = <int>[];
    for (final p in ps) {
      for (final r in p.runs) {
        if (r.color != null && !cols.contains(r.color)) cols.add(r.color!);
      }
    }
    final b = StringBuffer(r'{\rtf1\ansi\ansicpg1252\deff0{\fonttbl{\f0\fnil Arial;}}');
    if (cols.isNotEmpty) {
      b.write(r'{\colortbl;');
      for (final c in cols) {
        b.write('\\red${(c >> 16) & 255}\\green${(c >> 8) & 255}\\blue${c & 255};');
      }
      b.write('}');
    }
    b.write(r'\f0\fs24 ');
    for (final p in ps) {
      b.write('\\pard');
      if (p.rtl) b.write('\\rtlpar');
      b.write(const ['\\ql', '\\qc', '\\qr', '\\qj'][p.jc.clamp(0, 3)]);
      b.write(' ');
      for (final r in p.runs) {
        b.write('{');
        if (p.rtl) b.write('\\rtlch');
        if (r.b) b.write('\\b\\ab');
        if (r.i) b.write('\\i\\ai');
        if (r.u) b.write('\\ul');
        if (r.sz > 0) b.write('\\fs${r.sz}\\afs${r.sz}');
        if (r.color != null) b.write('\\cf${cols.indexOf(r.color!) + 1}');
        b.write(' ${_esc(r.text)}}');
      }
      b.write('\\par\n');
    }
    b.write('}');
    return b.toString();
  }
}
