import 'dart:convert';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'office_service.dart' show colName;
import 'ole.dart';

class XlsSheet {
  final String name;
  final Map<(int, int), String> cells = {}; // (row, col) 0-based
  int rows = 0, cols = 0;
  XlsSheet(this.name);
  String at(int r, int c) => cells[(r, c)] ?? '';
}

class _Seg {
  final Uint8List d;
  final List<List<int>> segs; // [start, length]
  int si = 0, off = 0;
  _Seg(this.d, this.segs) {
    off = segs.isEmpty ? 0 : segs[0][0];
  }
  int get _end => segs[si][0] + segs[si][1];
  void _norm() {
    while (off >= _end && si + 1 < segs.length) {
      si++;
      off = segs[si][0];
    }
  }

  bool get done {
    _norm();
    return off >= _end;
  }

  int u8() {
    _norm();
    return d[off++];
  }

  int u16() => u8() | (u8() << 8);
  int u32() => u16() | (u16() << 16);
  void skip(int n) {
    while (n > 0 && !done) {
      final k = (_end - off) < n ? _end - off : n;
      off += k;
      n -= k;
    }
  }

  String chars(int cch, bool wide) {
    final sb = StringBuffer();
    for (var k = 0; k < cch; k++) {
      if (off >= _end) {
        if (si + 1 >= segs.length) break;
        si++;
        off = segs[si][0];
        wide = (d[off++] & 1) == 1; // continuation re-states the encoding flag
      }
      if (wide) {
        if (off + 1 >= d.length) break;
        sb.writeCharCode(d[off] | (d[off + 1] << 8));
        off += 2;
      } else {
        sb.writeCharCode(d[off++]);
      }
    }
    return sb.toString();
  }
}

/// Read-only BIFF8 (.xls, Excel 97-2003) reader: values and cached formula results.
class XlsLegacy {
  static String _num(double d) => d == d.truncateToDouble() && d.abs() < 1e15 ? d.toInt().toString() : d.toString();

  static double _rk(int v) {
    double d;
    if (v & 2 != 0) {
      d = (v.toSigned(32) >> 2).toDouble();
    } else {
      final bd = ByteData(8)..setUint32(4, v & 0xFFFFFFFC, Endian.little);
      d = bd.getFloat64(0, Endian.little);
    }
    return v & 1 != 0 ? d / 100 : d;
  }

  static List<XlsSheet> parse(Uint8List b) {
    final ole = Ole.parse(b);
    final wb = ole.has('Workbook') ? ole.stream('Workbook') : ole.stream('Book');
    final bd = ByteData.sublistView(wb);
    final recs = <List<int>>[]; // type, dataStart, len
    var pos = 0;
    while (pos + 4 <= wb.length) {
      final t = bd.getUint16(pos, Endian.little), l = bd.getUint16(pos + 2, Endian.little);
      if (pos + 4 + l > wb.length) break;
      recs.add([t, pos + 4, l]);
      pos += 4 + l;
    }
    // shared strings
    final sst = <String>[];
    for (var i = 0; i < recs.length; i++) {
      if (recs[i][0] != 0x00FC) continue;
      final segs = <List<int>>[[recs[i][1], recs[i][2]]];
      var j = i + 1;
      while (j < recs.length && recs[j][0] == 0x003C) {
        segs.add([recs[j][1], recs[j][2]]);
        j++;
      }
      final r = _Seg(wb, segs);
      r.skip(4);
      final uniq = r.u32();
      for (var k = 0; k < uniq && !r.done; k++) {
        final cch = r.u16();
        final fl = r.u8();
        final rich = fl & 8 != 0 ? r.u16() : 0;
        final ext = fl & 4 != 0 ? r.u32() : 0;
        sst.add(r.chars(cch, fl & 1 != 0));
        r.skip(rich * 4 + ext);
      }
      break;
    }
    // sheets
    final sheets = <(String, int)>[];
    for (final r in recs) {
      if (r[0] != 0x0085) continue;
      final s = r[1];
      final type = wb[s + 5];
      final cch = wb[s + 6], fl = wb[s + 7];
      if (type != 0) continue;
      final name = fl & 1 != 0
          ? String.fromCharCodes([for (var k = 0; k < cch; k++) bd.getUint16(s + 8 + k * 2, Endian.little)])
          : latin1.decode(wb.sublist(s + 8, s + 8 + cch));
      sheets.add((name, bd.getUint32(s, Endian.little)));
    }
    final out = <XlsSheet>[];
    for (final (name, off) in sheets) {
      final sh = XlsSheet(name);
      var i = recs.indexWhere((r) => r[1] - 4 == off);
      if (i < 0) continue;
      var depth = 0;
      void put(int r, int c, String v) {
        if (v.isEmpty) return;
        sh.cells[(r, c)] = v;
        if (r + 1 > sh.rows) sh.rows = r + 1;
        if (c + 1 > sh.cols) sh.cols = c + 1;
      }

      for (; i < recs.length; i++) {
        final t = recs[i][0], s = recs[i][1], l = recs[i][2];
        if (t == 0x0809) {
          depth++;
          continue;
        }
        if (t == 0x000A) {
          depth--;
          if (depth <= 0) break;
          continue;
        }
        if (depth != 1 || l < 4) continue;
        final row = bd.getUint16(s, Endian.little), col = bd.getUint16(s + 2, Endian.little);
        switch (t) {
          case 0x00FD:
            final k = bd.getUint32(s + 6, Endian.little);
            if (k < sst.length) put(row, col, sst[k]);
            break;
          case 0x0203:
            put(row, col, _num(bd.getFloat64(s + 6, Endian.little)));
            break;
          case 0x027E:
            put(row, col, _num(_rk(bd.getUint32(s + 6, Endian.little))));
            break;
          case 0x00BD:
            var p = s + 4;
            final last = bd.getUint16(s + l - 2, Endian.little);
            for (var c = col; c <= last && p + 6 <= s + l - 2; c++, p += 6) {
              put(row, c, _num(_rk(bd.getUint32(p + 2, Endian.little))));
            }
            break;
          case 0x0204:
            final cch = bd.getUint16(s + 6, Endian.little), fl = wb[s + 8];
            final st = s + 9;
            put(row, col, fl & 1 != 0 ? String.fromCharCodes([for (var k = 0; k < cch && st + k * 2 + 1 < wb.length; k++) bd.getUint16(st + k * 2, Endian.little)]) : latin1.decode(wb.sublist(st, (st + cch).clamp(0, wb.length))));
            break;
          case 0x0205:
            if (wb[s + 7] == 0) put(row, col, wb[s + 6] == 0 ? 'FALSE' : 'TRUE');
            break;
          case 0x0006:
            if (bd.getUint16(s + 12, Endian.little) == 0xFFFF) {
              if (wb[s + 6] == 0 && i + 1 < recs.length && recs[i + 1][0] == 0x0207) {
                final ss = recs[i + 1][1];
                final cch = bd.getUint16(ss, Endian.little), fl = wb[ss + 2];
                put(row, col, fl & 1 != 0 ? String.fromCharCodes([for (var k = 0; k < cch && ss + 3 + k * 2 + 1 < wb.length; k++) bd.getUint16(ss + 3 + k * 2, Endian.little)]) : latin1.decode(wb.sublist(ss + 3, (ss + 3 + cch).clamp(0, wb.length))));
              }
            } else {
              put(row, col, _num(bd.getFloat64(s + 6, Endian.little)));
            }
            break;
        }
      }
      out.add(sh);
    }
    return out;
  }

  /// Minimal .xlsx (values only) so the converted file opens in the xlsx editor.
  static List<int> toXlsx(List<XlsSheet> sheets) {
    String esc(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;');
    final files = <String, String>{};
    final ct = StringBuffer('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>');
    final wbs = StringBuffer(), rels = StringBuffer('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">');
    for (var n = 0; n < sheets.length; n++) {
      final sh = sheets[n];
      ct.write('<Override PartName="/xl/worksheets/sheet${n + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>');
      wbs.write('<sheet name="${esc(sh.name.length > 31 ? sh.name.substring(0, 31) : sh.name).replaceAll('"', '&quot;')}" sheetId="${n + 1}" r:id="rId${n + 1}"/>');
      rels.write('<Relationship Id="rId${n + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${n + 1}.xml"/>');
      final keys = sh.cells.keys.toList()..sort((a, b) => a.$1 != b.$1 ? a.$1.compareTo(b.$1) : a.$2.compareTo(b.$2));
      final sd = StringBuffer();
      int? cr;
      for (final k in keys) {
        if (k.$1 != cr) {
          if (cr != null) sd.write('</row>');
          sd.write('<row r="${k.$1 + 1}">');
          cr = k.$1;
        }
        final v = sh.cells[k]!;
        final ref = '${colName(k.$2)}${k.$1 + 1}';
        if (RegExp(r'^-?(0|[1-9]\d*)(\.\d+)?$').hasMatch(v)) {
          sd.write('<c r="$ref"><v>$v</v></c>');
        } else {
          sd.write('<c r="$ref" t="inlineStr"><is><t xml:space="preserve">${esc(v)}</t></is></c>');
        }
      }
      if (cr != null) sd.write('</row>');
      files['xl/worksheets/sheet${n + 1}.xml'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>$sd</sheetData></worksheet>';
    }
    ct.write('</Types>');
    rels.write('<Relationship Id="rId${sheets.length + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>');
    files['[Content_Types].xml'] = ct.toString();
    files['_rels/.rels'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>';
    files['xl/workbook.xml'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>$wbs</sheets></workbook>';
    files['xl/_rels/workbook.xml.rels'] = rels.toString();
    files['xl/styles.xml'] = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs></styleSheet>';
    final arc = Archive();
    files.forEach((k, v) {
      final bytes = utf8.encode(v);
      arc.addFile(ArchiveFile(k, bytes.length, bytes));
    });
    return ZipEncoder().encode(arc)!;
  }
}

/// Read-only .ppt (PowerPoint 97-2003) text extraction, one list of paragraphs per slide.
class PptLegacy {
  static List<List<String>> parse(Uint8List b) {
    final ole = Ole.parse(b);
    final d = ole.stream('PowerPoint Document');
    final bd = ByteData.sublistView(d);
    final list = <List<String>>[]; // SlideListWithText
    final boxes = <List<String>>[]; // text inside Slide containers
    List<String>? curList, curBox;
    List<String> split(String s) => s.split(RegExp(r'[\r\x0B]')).map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

    void walk(int s, int e, {bool inSlwt = false, bool inSlide = false}) {
      var p = s;
      while (p + 8 <= e) {
        final vi = bd.getUint16(p, Endian.little), type = bd.getUint16(p + 2, Endian.little), len = bd.getUint32(p + 4, Endian.little);
        final ds = p + 8, de = ds + len;
        if (de > e) break;
        final ver = vi & 0xF, inst = vi >> 4;
        if (ver == 0xF) {
          if (type == 0x0FF0) {
            walk(ds, de, inSlwt: inst == 0, inSlide: inSlide);
          } else if (type == 0x03EE) {
            curBox = [];
            boxes.add(curBox!);
            walk(ds, de, inSlide: true);
          } else if (type == 0x03F8 || type == 0x03F0 || type == 0x0FF0) {
            // masters and notes: skipped
          } else {
            walk(ds, de, inSlwt: inSlwt, inSlide: inSlide);
          }
        } else if (type == 0x03F3 && inSlwt) {
          curList = [];
          list.add(curList!);
        } else if (type == 0x0FA0 || type == 0x0FA8) {
          final txt = type == 0x0FA0 ? String.fromCharCodes([for (var k = 0; k + 1 < len; k += 2) bd.getUint16(ds + k, Endian.little)]) : latin1.decode(d.sublist(ds, de));
          if (inSlide) {
            curBox?.addAll(split(txt));
          } else if (inSlwt) {
            curList?.addAll(split(txt));
          }
        }
        p = de;
      }
    }

    walk(0, d.length);
    final n = list.length > boxes.length ? list.length : boxes.length;
    return [for (var i = 0; i < n; i++) [if (i < list.length) ...list[i], if (i < boxes.length) ...boxes[i]]];
  }
}
