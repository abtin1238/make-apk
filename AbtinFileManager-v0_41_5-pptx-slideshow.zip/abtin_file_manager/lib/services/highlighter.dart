import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

class _Lang {
  final RegExp re;
  final List<String> names;
  _Lang(this.re, this.names);
}

/// Lightweight regex-based syntax highlighter (no external package).
class Hl {
  static const maxLen = 300000;

  static const _dark = {
    'c': Color(0xFF6A9955), 's': Color(0xFFCE9178), 'n': Color(0xFFB5CEA8),
    'k': Color(0xFF569CD6), 't': Color(0xFF4EC9B0), 'a': Color(0xFF9CDCFE),
  };
  static const _light = {
    'c': Color(0xFF008000), 's': Color(0xFFA31515), 'n': Color(0xFF098658),
    'k': Color(0xFF0000FF), 't': Color(0xFF267F99), 'a': Color(0xFF001080),
  };

  static const _clike = {'dart', 'kt', 'kts', 'java', 'js', 'ts', 'tsx', 'jsx', 'c', 'cpp', 'h', 'hpp', 'cs', 'go', 'rs', 'swift', 'php', 'gradle', 'scala', 'groovy'};
  static const _hash = {'py': 'py', 'rb': 'py', 'sh': 'sh', 'bash': 'sh', 'yaml': 'data', 'yml': 'data', 'toml': 'data', 'ini': 'data', 'conf': 'data', 'cfg': 'data', 'properties': 'data'};

  /// Language key for a file path, '' when no highlighting applies.
  static String langOf(String path) {
    final e = p.extension(path).toLowerCase().replaceFirst('.', '');
    if (_clike.contains(e)) return 'clike';
    if (_hash.containsKey(e)) return _hash[e]!;
    switch (e) {
      case 'xml': case 'html': case 'htm': case 'svg': return 'xml';
      case 'json': return 'json';
      case 'css': case 'scss': return 'css';
      case 'sql': return 'sql';
      case 'md': return 'md';
    }
    return '';
  }

  static const _kwClike = 'abstract as assert async await break case catch class const continue default defer do else enum export extends extern final finally for fun function get if implements import in interface is late let new null object on operator override package private protected public required return sealed set static struct super switch sync this throw throws try typedef typeof val var void when while with yield true false int double bool String num dynamic char long short float unsigned signed auto namespace using template typename virtual inline volatile goto instanceof boolean byte transient synchronized native delete from of type readonly declare func chan map range go select fn pub mut impl trait mod use crate match loop where self unsafe move ref init constructor companion data inner open lateinit by out suspend vararg echo foreach';
  static const _kwPy = 'and as assert async await break class continue def del elif else except finally for from global if import in is lambda None nonlocal not or pass raise return try while with yield True False self end do module begin rescue unless';
  static const _kwSh = 'if then else elif fi for while do done case esac function in echo export local return exit cd set unset source alias';
  static const _kwData = 'true false null yes no on off';
  static const _kwSql = 'select from where and or not insert into values update set delete create table alter drop index join left right inner outer on group by order having limit offset as distinct null is in like between union all primary key foreign references default unique case when then else end';

  static const _dq = r'"(?:\\.|[^"\\\n])*"?';
  static const _sq = r"'(?:\\.|[^'\\\n])*'?";
  static const _bt = r'`(?:\\.|[^`\\])*`?';
  static const _tdq = r'"""[\s\S]*?(?:"""|$)';
  static const _tsq = r"'''[\s\S]*?(?:'''|$)";
  static const _num = r'\b(?:0[xX][0-9a-fA-F]+|\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)\b';

  static final _cache = <String, _Lang?>{};

  static String _g(String n, String pat) => '(?<$n>$pat)';
  static String _kw(String words) => '\\b(?:${words.split(' ').join('|')})\\b';

  static _Lang? _build(String lang) {
    final parts = <String>[];
    final names = <String>[];
    void add(String n, String pat) { parts.add(_g(n, pat)); names.add(n); }
    var multi = false, icase = false;
    switch (lang) {
      case 'clike':
        add('c', r'//[^\n]*|/\*[\s\S]*?(?:\*/|$)');
        add('s', '$_tdq|$_dq|$_sq|$_bt');
        add('a', r'@[A-Za-z_]\w*');
        add('n', _num);
        add('k', _kw(_kwClike));
        add('t', r'\b[A-Z][A-Za-z0-9_]*\b');
      case 'py':
        add('c', r'#[^\n]*');
        add('s', '$_tdq|$_tsq|$_dq|$_sq');
        add('a', r'@[A-Za-z_][\w.]*');
        add('n', _num);
        add('k', _kw(_kwPy));
      case 'sh':
        add('c', r'#[^\n]*');
        add('s', '$_dq|$_sq');
        add('a', r'\$\{?[A-Za-z_]\w*\}?');
        add('n', _num);
        add('k', _kw(_kwSh));
      case 'data':
        multi = true;
        add('c', r'#[^\n]*');
        add('s', '$_dq|$_sq');
        add('a', r'^[ \t-]*[\w.\-]+(?=[ \t]*[:=])');
        add('n', _num);
        add('k', _kw(_kwData));
      case 'xml':
        add('c', r'<!--[\s\S]*?(?:-->|$)');
        add('s', r'''(?<==)(?:"[^"]*"?|'[^']*'?)''');
        add('t', r'</?[A-Za-z][\w:.-]*|/?>');
        add('a', r'\b[\w:.-]+(?==)');
      case 'json':
        add('a', r'"(?:\\.|[^"\\\n])*"(?=\s*:)');
        add('s', _dq);
        add('n', r'-?\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b');
        add('k', r'\b(?:true|false|null)\b');
      case 'css':
        add('c', r'/\*[\s\S]*?(?:\*/|$)');
        add('s', '$_dq|$_sq');
        add('n', r'#[0-9a-fA-F]{3,8}\b|-?\b\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw|s|ms|deg)?\b');
        add('a', r'[\w-]+(?=\s*:)');
        add('t', r'[.#][A-Za-z_][\w-]*');
        add('k', r'@[\w-]+');
      case 'sql':
        icase = true;
        add('c', r'--[^\n]*|/\*[\s\S]*?(?:\*/|$)');
        add('s', r"'(?:''|[^'])*'?");
        add('n', _num);
        add('k', _kw(_kwSql));
      case 'md':
        multi = true;
        add('k', r'^#{1,6}[^\n]*');
        add('s', r'`[^`\n]+`');
        add('a', r'\*\*[^*\n]+\*\*');
      default:
        return null;
    }
    return _Lang(RegExp(parts.join('|'), multiLine: multi, caseSensitive: !icase), names);
  }

  static List<TextSpan> spans(String text, String lang, bool dark) {
    final l = _cache.putIfAbsent(lang, () => _build(lang));
    if (l == null) return [TextSpan(text: text)];
    final pal = dark ? _dark : _light;
    final out = <TextSpan>[];
    var last = 0;
    for (final m in l.re.allMatches(text)) {
      if (m.end == m.start) continue;
      if (m.start > last) out.add(TextSpan(text: text.substring(last, m.start)));
      String? g;
      for (final n in l.names) {
        if (m.namedGroup(n) != null) { g = n; break; }
      }
      out.add(TextSpan(
        text: text.substring(m.start, m.end),
        style: TextStyle(color: pal[g], fontStyle: g == 'c' ? FontStyle.italic : null),
      ));
      last = m.end;
    }
    if (last < text.length) out.add(TextSpan(text: text.substring(last)));
    return out;
  }
}

/// TextEditingController that paints syntax colours (falls back to plain text
/// while an IME composition is active or when the file is very large).
class CodeController extends TextEditingController {
  String lang;
  bool dark;
  bool enabled = true;
  CodeController({super.text, this.lang = '', this.dark = true});

  String? _t;
  String? _l;
  bool? _d;
  List<TextSpan>? _cached;

  @override
  TextSpan buildTextSpan({required BuildContext context, TextStyle? style, required bool withComposing}) {
    if (!enabled || lang.isEmpty || text.length > Hl.maxLen || (withComposing && value.composing.isValid && !value.composing.isCollapsed)) {
      return super.buildTextSpan(context: context, style: style, withComposing: withComposing);
    }
    if (_t != text || _l != lang || _d != dark || _cached == null) {
      _cached = Hl.spans(text, lang, dark);
      _t = text;
      _l = lang;
      _d = dark;
    }
    return TextSpan(style: style, children: _cached);
  }
}
