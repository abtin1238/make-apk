import 'dart:io';
import 'package:archive/archive.dart' show getCrc32;
import 'package:crypto/crypto.dart';
import 'file_ops.dart';

class _Cap implements Sink<Digest> {
  Digest? d;
  @override
  void add(Digest data) => d = data;
  @override
  void close() {}
}

class HashService {
  static final Map<String, Hash> _algos = {'MD5': md5, 'SHA-1': sha1, 'SHA-256': sha256, 'SHA-512': sha512};

  /// Streams the file once and returns CRC32 + MD5 + SHA-1/256/512 (lower-case hex).
  static Future<Map<String, String>> compute(String path, {void Function(double)? onProgress, bool Function()? cancelled}) async {
    final f = File(path);
    final total = await f.length();
    final caps = {for (final k in _algos.keys) k: _Cap()};
    final convs = {for (final e in _algos.entries) e.key: e.value.startChunkedConversion(caps[e.key]!)};
    var crc = 0, done = 0;
    final sw = Stopwatch()..start();
    await for (final chunk in f.openRead()) {
      if (cancelled?.call() == true) throw const OpError('cancelled');
      for (final c in convs.values) { c.add(chunk); }
      crc = getCrc32(chunk, crc);
      done += chunk.length;
      if (sw.elapsedMilliseconds > 12) {
        onProgress?.call(total == 0 ? 1 : done / total);
        await Future<void>.delayed(Duration.zero);
        sw.reset();
      }
    }
    for (final c in convs.values) { c.close(); }
    onProgress?.call(1);
    return {
      'CRC32': (crc & 0xFFFFFFFF).toRadixString(16).padLeft(8, '0'),
      for (final k in caps.keys) k: caps[k]!.d.toString(),
    };
  }
}
