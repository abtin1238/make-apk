import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:isolate';
import 'package:path_provider/path_provider.dart';

int _dirBytes(String path) {
  var total = 0;
  final stack = <String>[path];
  while (stack.isNotEmpty) {
    final d = stack.removeLast();
    List<FileSystemEntity> l;
    try {
      l = Directory(d).listSync(followLinks: false);
    } catch (_) {
      continue;
    }
    for (final e in l) {
      if (e is Directory) {
        stack.add(e.path);
      } else if (e is File) {
        try { total += e.lengthSync(); } catch (_) {}
      }
    }
  }
  return total;
}

/// Persistent folder-size cache. Sizes are computed in a background isolate,
/// remembered across launches and dropped when the app changes the folder.
class FolderSizes {
  static const _ttl = Duration(minutes: 30);
  static const _maxEntries = 3000;

  static final _m = <String, List<int>>{}; // path -> [bytes, computedAtMs, folderMtimeMs]
  static final _pending = <String, Future<int>>{};
  static int _gen = 0;
  static File? _file;
  static Timer? _saveTimer;
  static int _running = 0;
  static final _waiters = <Completer<void>>[];

  static Future<void> init() async {
    try {
      final dir = await getApplicationSupportDirectory();
      _file = File('${dir.path}/folder_sizes.json');
      if (_file!.existsSync()) {
        final j = jsonDecode(await _file!.readAsString()) as Map<String, dynamic>;
        j.forEach((k, v) {
          final l = (v as List).map((e) => (e as num).toInt()).toList();
          if (l.length == 3) _m[k] = l;
        });
      }
    } catch (_) {}
  }

  static int? cached(String path) => _m[path]?[0];

  static bool fresh(String path, DateTime mtime) {
    final e = _m[path];
    if (e == null) return false;
    return DateTime.now().millisecondsSinceEpoch - e[1] < _ttl.inMilliseconds && e[2] == mtime.millisecondsSinceEpoch;
  }

  static Future<void> _acquire() async {
    if (_running < 2) {
      _running++;
      return;
    }
    final c = Completer<void>();
    _waiters.add(c);
    await c.future;
  }

  static void _release() {
    if (_waiters.isNotEmpty) {
      _waiters.removeAt(0).complete();
    } else {
      _running--;
    }
  }

  static Future<int> get(String path, {DateTime? mtime, bool force = false}) {
    mtime ??= () {
      try { return Directory(path).statSync().modified; } catch (_) { return DateTime.fromMillisecondsSinceEpoch(0); }
    }();
    if (!force && fresh(path, mtime)) return Future.value(_m[path]![0]);
    final running = _pending[path];
    if (running != null && !force) return running;
    final gen = _gen;
    final m = mtime;
    final f = () async {
      await _acquire();
      try {
        final size = await Isolate.run(() => _dirBytes(path));
        if (gen == _gen) {
          _m[path] = [size, DateTime.now().millisecondsSinceEpoch, m.millisecondsSinceEpoch];
          _scheduleSave();
        }
        return size;
      } finally {
        _release();
        _pending.remove(path);
      }
    }();
    _pending[path] = f;
    return f;
  }

  /// Call after the app changed [path] (created / deleted / renamed / copied into).
  static void invalidate(String path) {
    _gen++;
    _m.removeWhere((k, _) => k == path || path.startsWith('$k/') || k.startsWith('$path/'));
    _scheduleSave();
  }

  static void _scheduleSave() {
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(seconds: 3), () async {
      final f = _file;
      if (f == null) return;
      try {
        if (_m.length > _maxEntries) {
          final keys = _m.keys.toList()..sort((a, b) => _m[a]![1].compareTo(_m[b]![1]));
          for (final k in keys.take(_m.length - _maxEntries)) {
            _m.remove(k);
          }
        }
        await f.writeAsString(jsonEncode(_m));
      } catch (_) {}
    });
  }
}
