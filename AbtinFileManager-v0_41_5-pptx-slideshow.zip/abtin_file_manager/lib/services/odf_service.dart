import 'dart:typed_data';
import 'package:xml/xml.dart';
import 'office_service.dart';

/// ODS sheet: sparse grid of display strings with the XML kept alongside for editing.
class OSheet {
  final String name;
  final XmlElement el;
  final Map<String, String> cells = {};
  int rows = 0, cols = 0;
  OSheet(this.name, this.el);
}

String _cellText(XmlElement c) {
  final ps = c.findElements('p', namespace: '*').toList();
  if (ps.isNotEmpty) return ps.map(paraText).join('\n');
  return c.getAttribute('office:value') ?? c.getAttribute('office:string-value') ?? '';
}

class OdsFile {
  final OfficeZip z;
  final sheets = <OSheet>[];
  OdsFile._(this.z);

  static Future<OdsFile> open(String path) async {
    final x = OdsFile._(await OfficeZip.open(path));
    final d = x.z.xml('content.xml');
    if (d == null) throw 'Not a valid ods';
    for (final t in d.findAllElements('table', namespace: '*')) {
      if (t.name.prefix != 'table' || t.parent is! XmlElement || (t.parent as XmlElement).name.local != 'spreadsheet') continue;
      x.sheets.add(x._read(t));
    }
    return x;
  }

  int _rep(XmlElement e, String attr) => int.tryParse(e.getAttribute(attr) ?? '1') ?? 1;

  OSheet _read(XmlElement t) {
    final sh = OSheet(t.getAttribute('table:name') ?? 'Sheet', t);
    sh.cells.clear();
    var r = 0;
    for (final row in _rows(t)) {
      final rr = _rep(row, 'table:number-rows-repeated');
      var c = 0;
      final vals = <int, String>{};
      for (final cell in row.children.whereType<XmlElement>().where((e) => e.name.local == 'table-cell' || e.name.local == 'covered-table-cell')) {
        final cr = _rep(cell, 'table:number-columns-repeated');
        final txt = _cellText(cell);
        if (txt.isNotEmpty) {
          for (var k = 0; k < cr && k < 50; k++) {
            vals[c + k] = txt;
          }
        }
        c += cr;
      }
      for (var k = 0; k < rr && k < 200; k++) {
        if (vals.isNotEmpty) {
          vals.forEach((ci, v) {
            sh.cells['${colName(ci)}${r + k + 1}'] = v;
            if (ci + 1 > sh.cols) sh.cols = ci + 1;
          });
          if (r + k + 1 > sh.rows) sh.rows = r + k + 1;
        }
      }
      r += rr;
      if (r > 20000) break;
    }
    return sh;
  }

  Iterable<XmlElement> _rows(XmlElement t) sync* {
    for (final e in t.children.whereType<XmlElement>()) {
      if (e.name.local == 'table-row') {
        yield e;
      } else if (e.name.local == 'table-header-rows' || e.name.local == 'table-row-group' || e.name.local == 'table-rows') {
        yield* _rows(e);
      }
    }
  }

  /// Splits repeated rows / cells so that exactly (row, col) is addressable, returns that cell.
  XmlElement _ensure(OSheet sh, int row, int col) {
    final t = sh.el;
    var r = 0;
    XmlElement? target;
    XmlElement? lastRow;
    for (final rw in _rows(t).toList()) {
      lastRow = rw;
      final rr = _rep(rw, 'table:number-rows-repeated');
      if (row < r + rr) {
        final before = row - r, after = r + rr - row - 1;
        final parent = rw.parent!;
        var idx = parent.children.indexOf(rw);
        rw.removeAttribute('table:number-rows-repeated');
        if (before > 0) {
          final b = rw.copy()..setAttribute('table:number-rows-repeated', '$before');
          parent.children.insert(idx, b);
          idx++;
        }
        if (after > 0) {
          final a = rw.copy()..setAttribute('table:number-rows-repeated', '$after');
          parent.children.insert(idx + 1, a);
        }
        target = rw;
        break;
      }
      r += rr;
    }
    if (target == null) {
      // append rows
      final parent = lastRow?.parent ?? t;
      while (r <= row) {
        final nr = XmlElement(XmlName('table-row', 'table'));
        parent.children.add(nr);
        target = nr;
        r++;
      }
    }
    var c = 0;
    XmlElement? cellEl;
    for (final ce in target!.children.whereType<XmlElement>().toList()) {
      if (ce.name.local != 'table-cell' && ce.name.local != 'covered-table-cell') continue;
      final cr = _rep(ce, 'table:number-columns-repeated');
      if (col < c + cr) {
        final before = col - c, after = c + cr - col - 1;
        var idx = target.children.indexOf(ce);
        ce.removeAttribute('table:number-columns-repeated');
        if (before > 0) {
          target.children.insert(idx, ce.copy()..setAttribute('table:number-columns-repeated', '$before'));
          idx++;
        }
        if (after > 0) target.children.insert(idx + 1, ce.copy()..setAttribute('table:number-columns-repeated', '$after'));
        cellEl = ce;
        break;
      }
      c += cr;
    }
    if (cellEl == null) {
      while (c <= col) {
        cellEl = XmlElement(XmlName('table-cell', 'table'));
        target.children.add(cellEl);
        c++;
      }
    }
    return cellEl!;
  }

  void setCell(OSheet sh, String ref, String text) {
    final m = RegExp(r'^([A-Z]+)(\d+)$').firstMatch(ref.toUpperCase())!;
    final col = colIndex(m[1]!), row = int.parse(m[2]!) - 1;
    final cell = _ensure(sh, row, col);
    for (final a in ['office:value', 'office:string-value', 'office:value-type', 'calcext:value-type', 'table:formula', 'office:date-value', 'office:boolean-value', 'office:currency']) {
      cell.removeAttribute(a);
    }
    cell.children.removeWhere((e) => e is XmlElement && e.name.local == 'p');
    if (text.isNotEmpty) {
      final num = double.tryParse(text);
      if (num != null) {
        cell.setAttribute('office:value-type', 'float');
        cell.setAttribute('office:value', text);
      } else {
        cell.setAttribute('office:value-type', 'string');
      }
      cell.children.add(XmlElement(XmlName('p', 'text'), [], [XmlText(text)]));
      sh.cells[ref.toUpperCase()] = text;
      if (col + 1 > sh.cols) sh.cols = col + 1;
      if (row + 1 > sh.rows) sh.rows = row + 1;
    } else {
      sh.cells.remove(ref.toUpperCase());
    }
    z.touch('content.xml');
  }
}

class OPage {
  final List<XmlElement> paras;
  final List<Uint8List> images;
  OPage(this.paras, this.images);
}

class OdpFile {
  final OfficeZip z;
  final pages = <OPage>[];
  OdpFile._(this.z);

  static Future<OdpFile> open(String path) async {
    final x = OdpFile._(await OfficeZip.open(path));
    final d = x.z.xml('content.xml');
    if (d == null) throw 'Not a valid odp';
    for (final pg in d.findAllElements('page', namespace: '*')) {
      if (pg.name.prefix != 'draw') continue;
      final ps = <XmlElement>[];
      for (final e in pg.findAllElements('*', namespace: '*')) {
        if (e.name.prefix == 'text' && (e.name.local == 'p' || e.name.local == 'h') && !e.ancestors.whereType<XmlElement>().takeWhile((a) => a != pg).any((a) => a.name.prefix == 'text' && (a.name.local == 'p' || a.name.local == 'h'))) ps.add(e);
      }
      final imgs = <Uint8List>[];
      for (final im in pg.findAllElements('image', namespace: '*')) {
        final h = im.getAttribute('xlink:href');
        if (h == null || h.startsWith('http')) continue;
        final b = x.z.bytes(h.startsWith('./') ? h.substring(2) : h);
        if (b != null) imgs.add(b);
      }
      x.pages.add(OPage(ps, imgs));
    }
    return x;
  }

  void setText(XmlElement para, String text) {
    para.children
      ..clear()
      ..add(XmlText(text));
    z.touch('content.xml');
  }
}
