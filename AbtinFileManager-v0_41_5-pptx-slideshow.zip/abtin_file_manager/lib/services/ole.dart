import 'dart:typed_data';

/// Minimal OLE2 / CFB container reader (Word, Excel, PowerPoint 97-2003).
class Ole {
  static const _free = 0xFFFFFFFF, _endOfChain = 0xFFFFFFFE;
  final Uint8List Function(String) stream;
  final bool Function(String) has;
  Ole._(this.stream, this.has);

  static Ole parse(Uint8List b) {
    final bd = ByteData.sublistView(b);
    if (b.length < 512 || bd.getUint32(0, Endian.little) != 0xE011CFD0) {
      throw Exception('Not an OLE2 (97-2003) file');
    }
    final ss = 1 << bd.getUint16(0x1E, Endian.little);
    final mss = 1 << bd.getUint16(0x20, Endian.little);
    final nFat = bd.getUint32(0x2C, Endian.little);
    final dirStart = bd.getUint32(0x30, Endian.little);
    final cutoff = bd.getUint32(0x38, Endian.little);
    final miniStart = bd.getUint32(0x3C, Endian.little);
    var difStart = bd.getUint32(0x44, Endian.little);
    final nDif = bd.getUint32(0x48, Endian.little);

    int off(int sec) => (sec + 1) * ss;
    Uint8List sector(int s) {
      final o = off(s);
      if (o + ss > b.length) return Uint8List(0);
      return Uint8List.sublistView(b, o, o + ss);
    }

    // FAT sector list from DIFAT
    final fatSecs = <int>[];
    for (var i = 0; i < 109 && fatSecs.length < nFat; i++) {
      final v = bd.getUint32(0x4C + i * 4, Endian.little);
      if (v != _free) fatSecs.add(v);
    }
    for (var d = 0; d < nDif && difStart != _endOfChain && difStart != _free; d++) {
      final s = ByteData.sublistView(sector(difStart));
      final per = ss ~/ 4 - 1;
      for (var i = 0; i < per && fatSecs.length < nFat; i++) {
        final v = s.getUint32(i * 4, Endian.little);
        if (v != _free) fatSecs.add(v);
      }
      difStart = s.getUint32(per * 4, Endian.little);
    }
    final fat = <int>[];
    for (final fs in fatSecs) {
      final s = ByteData.sublistView(sector(fs));
      for (var i = 0; i + 4 <= s.lengthInBytes; i += 4) {
        fat.add(s.getUint32(i, Endian.little));
      }
    }

    Uint8List chain(int start, {int? size}) {
      final out = BytesBuilder();
      var s = start, guard = 0;
      while (s != _endOfChain && s != _free && s < fat.length && guard++ < 1 << 22) {
        out.add(sector(s));
        s = fat[s];
      }
      final all = out.toBytes();
      return size != null && size < all.length ? Uint8List.sublistView(all, 0, size) : all;
    }

    // directory
    final dir = chain(dirStart);
    final dd = ByteData.sublistView(dir);
    final entries = <String, List<int>>{}; // name -> [start,size]
    int rootStart = 0, rootSize = 0;
    for (var i = 0; i + 128 <= dir.length; i += 128) {
      final nl = dd.getUint16(i + 0x40, Endian.little);
      if (nl < 2) continue;
      final name = String.fromCharCodes(Uint16List.fromList([for (var k = 0; k < (nl - 2) ~/ 2; k++) dd.getUint16(i + k * 2, Endian.little)]));
      final type = dir[i + 0x42];
      final start = dd.getUint32(i + 0x74, Endian.little);
      final size = dd.getUint32(i + 0x78, Endian.little);
      if (type == 5) {
        rootStart = start;
        rootSize = size;
      } else if (type == 2) {
        entries[name] = [start, size];
      }
    }
    final miniStream = chain(rootStart, size: rootSize);
    final miniFat = <int>[];
    if (miniStart != _endOfChain) {
      final mf = ByteData.sublistView(chain(miniStart));
      for (var i = 0; i + 4 <= mf.lengthInBytes; i += 4) {
        miniFat.add(mf.getUint32(i, Endian.little));
      }
    }

    Uint8List stream(String name) {
      final e = entries[name];
      if (e == null) throw Exception('Stream $name missing');
      if (e[1] >= cutoff) return chain(e[0], size: e[1]);
      final out = BytesBuilder();
      var s = e[0], guard = 0;
      while (s != _endOfChain && s != _free && s < miniFat.length && guard++ < 1 << 20) {
        final o = s * mss;
        if (o + mss > miniStream.length) break;
        out.add(Uint8List.sublistView(miniStream, o, o + mss));
        s = miniFat[s];
      }
      final all = out.toBytes();
      return e[1] < all.length ? Uint8List.sublistView(all, 0, e[1]) : all;
    }
    return Ole._(stream, (n) => entries.containsKey(n));
  }
}
