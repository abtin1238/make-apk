import 'dart:io';
import 'dart:typed_data';
import 'dart:convert';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'file_ops.dart';

/// Storage Access Framework fallback for removable SD cards that the normal
/// File API cannot write to (Android 10- without legacy access, and Android 11+
/// on devices / modes where all-files access does not cover the card).
/// Reading always uses the normal File API; only writes go through here.
class Saf {
  static const _c = MethodChannel('abtin/saf');
  static final _needs = <String, bool>{};

  /// Volume id (`XXXX-XXXX`) when [path] is on removable storage, otherwise null.
  static String? volumeOf(String path) {
    final parts = p.split(path);
    if (parts.length >= 3 && parts[0] == '/' && parts[1] == 'storage' && parts[2] != 'emulated' && parts[2] != 'self') return parts[2];
    return null;
  }

  static void resetCache() => _needs.clear();

  /// true if [path] is on a removable volume that cannot be written with the File API.
  static Future<bool> needsSaf(String path) async {
    final u = volumeOf(path);
    if (u == null) return false;
    final c = _needs[u];
    if (c != null) return c;
    var need = true;
    try {
      final f = File('/storage/$u/.abtin_probe');
      await f.writeAsString('x');
      await f.delete();
      need = false;
    } catch (_) {}
    return _needs[u] = need;
  }

  static Future<bool> has(String uuid) async {
    try {
      return (await _c.invokeMethod<bool>('has', {'uuid': uuid})) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> request(String uuid) async {
    try {
      return (await _c.invokeMethod<bool>('request', {'uuid': uuid})) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> revoke(String uuid) async {
    try { await _c.invokeMethod('revoke', {'uuid': uuid}); } catch (_) {}
  }

  /// true -> use the SAF methods for [path]; false -> use the File API.
  /// Throws [OpError] `safNeed` when SAF is required but not granted yet.
  static Future<bool> use(String path) async {
    final u = volumeOf(path);
    if (u == null) return false;
    if (!await needsSaf(path)) return false;
    if (!await has(u)) throw const OpError('safNeed');
    return true;
  }

  static Future<T?> _inv<T>(String m, Map<String, Object?> a) async {
    try {
      return await _c.invokeMethod<T>(m, a);
    } on PlatformException catch (e) {
      throw OpError('safFail', e.message);
    }
  }

  static Future<void> mkdirs(String path) => _inv('mkdirs', {'path': path});
  static Future<void> createFile(String path) => _inv('create', {'path': path});
  static Future<void> delete(String path) => _inv('delete', {'path': path});
  static Future<void> rename(String path, String name) => _inv('rename', {'path': path, 'name': name});

  /// Moves [src] into folder [dstDir] (same volume) and names it [newName].
  static Future<void> move(String src, String dstDir, String newName) => _inv('move', {'path': src, 'dst': dstDir, 'name': newName});

  static Future<int> open(String path) async => (await _inv<int>('open', {'path': path}))!;
  static Future<void> write(int h, Uint8List data) => _inv('write', {'h': h, 'data': data});
  static Future<void> close(int h) => _inv('close', {'h': h});

  static Future<void> writeText(String path, String text) async {
    final h = await open(path);
    try {
      await write(h, Uint8List.fromList(utf8.encode(text)));
    } finally {
      await close(h);
    }
  }

  /// Writes [data] to [path]: through SAF when the SD card needs it, else the normal File API.
  /// Call `ensureSdAll` first so the access prompt has been shown.
  static Future<void> writeBytes(String path, List<int> data) async {
    if (!await use(path)) {
      await File(path).writeAsBytes(data);
      return;
    }
    final h = await open(path);
    try {
      const n = 1 << 20;
      for (var i = 0; i < data.length; i += n) {
        final e = i + n > data.length ? data.length : i + n;
        await write(h, data is Uint8List ? data.sublist(i, e) : Uint8List.fromList(data.sublist(i, e)));
      }
    } finally {
      await close(h);
    }
  }

  static Future<void> writeString(String path, String text) => writeBytes(path, utf8.encode(text));

  /// Copies local file [src] to [dst] (SAF-aware).
  static Future<void> copyTo(String src, String dst) async {
    if (await use(dst)) {
      await copyFileIn(src, dst);
    } else {
      await File(src).copy(dst);
    }
  }

  /// Copies a local file onto the SD card (no progress; used for small jobs).
  static Future<void> copyFileIn(String src, String dst) async {
    final r = await File(src).open();
    final h = await open(dst);
    try {
      while (true) {
        final b = await r.read(1 << 20);
        if (b.isEmpty) break;
        await write(h, b);
      }
    } finally {
      await r.close();
      await close(h);
    }
  }
}
