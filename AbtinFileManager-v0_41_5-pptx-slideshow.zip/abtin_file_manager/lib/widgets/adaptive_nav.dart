import 'package:flutter/material.dart' hide Icon;
import 'app_icon.dart';

class NavItem {
  final IconData icon;
  final String label;
  const NavItem(this.icon, this.label);
}

/// Bottom NavigationBar on phones, NavigationRail (on the start side, so right in RTL) on tablets / wide windows.
class AdaptiveNav extends StatelessWidget {
  final int selected;
  final ValueChanged<int> onSelect;
  final List<NavItem> items;
  final Widget body;
  final Widget? bottom; // e.g. mini player, shown above the bar / under the content
  static const breakpoint = 720.0;
  const AdaptiveNav({super.key, required this.selected, required this.onSelect, required this.items, required this.body, this.bottom});

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.of(context).size.width >= breakpoint;
    if (!wide) {
      return Scaffold(
        body: body,
        bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
          if (bottom != null) bottom!,
          NavigationBar(
            selectedIndex: selected,
            onDestinationSelected: onSelect,
            destinations: [for (final i in items) NavigationDestination(icon: Icon(i.icon), label: i.label)],
          ),
        ]),
      );
    }
    return Scaffold(
      body: Row(children: [
        SafeArea(
          child: NavigationRail(
            selectedIndex: selected,
            onDestinationSelected: onSelect,
            labelType: NavigationRailLabelType.all,
            destinations: [for (final i in items) NavigationRailDestination(icon: Icon(i.icon), label: Text(i.label))],
          ),
        ),
        const VerticalDivider(width: 1),
        Expanded(child: Column(children: [Expanded(child: body), if (bottom != null) bottom!])),
      ]),
    );
  }
}

/// Centers content and caps its width on tablets so forms and lists stay readable.
class MaxWidth extends StatelessWidget {
  final Widget child;
  final double width;
  const MaxWidth({super.key, required this.child, this.width = 720});
  @override
  Widget build(BuildContext context) => Align(alignment: Alignment.topCenter, child: ConstrainedBox(constraints: BoxConstraints(maxWidth: width), child: child));
}
