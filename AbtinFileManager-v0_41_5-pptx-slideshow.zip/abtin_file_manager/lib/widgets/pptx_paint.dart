import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../services/pptx_service.dart';

Color _c(int rgb, [double a = 1]) => Color(0xFF000000 | (rgb & 0xFFFFFF)).withOpacity(a);

/// Draws the geometry (fill + outline) of a slide shape: preset shapes, freeforms and lines.
class ShapePainter extends CustomPainter {
  final String geom;
  final double adj;
  final List<PCust> cust;
  final int? fill, line;
  final double fillAlpha;
  final List<int>? grad;
  final double gradAngle;
  final double linePx; // outline width in px
  final bool flipH, flipV;
  final bool isLine;
  ShapePainter({
    required this.geom,
    required this.adj,
    required this.cust,
    required this.fill,
    required this.line,
    required this.fillAlpha,
    required this.grad,
    required this.gradAngle,
    required this.linePx,
    required this.flipH,
    required this.flipV,
  }) : isLine = geom == 'line' || geom == 'straightConnector1' || geom.startsWith('bentConnector') || geom.startsWith('curvedConnector');

  Path _poly(List<Offset> pts) {
    final p = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (final o in pts.skip(1)) {
      p.lineTo(o.dx, o.dy);
    }
    return p..close();
  }

  Path _path(Size s) {
    final w = s.width, h = s.height;
    switch (geom) {
      case 'ellipse':
        return Path()..addOval(Rect.fromLTWH(0, 0, w, h));
      case 'roundRect':
        final r = math.min(w, h) * (adj / 100000).clamp(0.0, .5).toDouble();
        return Path()..addRRect(RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, w, h), Radius.circular(r)));
      case 'triangle':
        return _poly([Offset(w / 2, 0), Offset(w, h), Offset(0, h)]);
      case 'rtTriangle':
        return _poly([Offset(0, 0), Offset(w, h), Offset(0, h)]);
      case 'diamond':
        return _poly([Offset(w / 2, 0), Offset(w, h / 2), Offset(w / 2, h), Offset(0, h / 2)]);
      case 'parallelogram':
        final o = w * .25;
        return _poly([Offset(o, 0), Offset(w, 0), Offset(w - o, h), Offset(0, h)]);
      case 'trapezoid':
        final o = w * .2;
        return _poly([Offset(o, 0), Offset(w - o, 0), Offset(w, h), Offset(0, h)]);
      case 'pentagon':
      case 'homePlate':
        final o = math.min(w, h) * .5;
        return _poly([Offset(0, 0), Offset(w - o, 0), Offset(w, h / 2), Offset(w - o, h), Offset(0, h)]);
      case 'hexagon':
        final o = w * .25;
        return _poly([Offset(o, 0), Offset(w - o, 0), Offset(w, h / 2), Offset(w - o, h), Offset(o, h), Offset(0, h / 2)]);
      case 'chevron':
        final o = math.min(w, h) * .5;
        return _poly([Offset(0, 0), Offset(w - o, 0), Offset(w, h / 2), Offset(w - o, h), Offset(0, h), Offset(o, h / 2)]);
      case 'rightArrow':
        return _poly([Offset(0, h * .25), Offset(w * .6, h * .25), Offset(w * .6, 0), Offset(w, h / 2), Offset(w * .6, h), Offset(w * .6, h * .75), Offset(0, h * .75)]);
      case 'leftArrow':
        return _poly([Offset(w, h * .25), Offset(w * .4, h * .25), Offset(w * .4, 0), Offset(0, h / 2), Offset(w * .4, h), Offset(w * .4, h * .75), Offset(w, h * .75)]);
      case 'upArrow':
        return _poly([Offset(w * .25, h), Offset(w * .25, h * .4), Offset(0, h * .4), Offset(w / 2, 0), Offset(w, h * .4), Offset(w * .75, h * .4), Offset(w * .75, h)]);
      case 'downArrow':
        return _poly([Offset(w * .25, 0), Offset(w * .25, h * .6), Offset(0, h * .6), Offset(w / 2, h), Offset(w, h * .6), Offset(w * .75, h * .6), Offset(w * .75, 0)]);
      case 'plus':
      case 'mathPlus':
        final a = w * .33, b = h * .33;
        return _poly([Offset(a, 0), Offset(w - a, 0), Offset(w - a, b), Offset(w, b), Offset(w, h - b), Offset(w - a, h - b), Offset(w - a, h), Offset(a, h), Offset(a, h - b), Offset(0, h - b), Offset(0, b), Offset(a, b)]);
      case 'star5':
        final pts = <Offset>[];
        for (var i = 0; i < 10; i++) {
          final r = i.isEven ? 1.0 : .4;
          final a = -math.pi / 2 + i * math.pi / 5;
          pts.add(Offset(w / 2 + math.cos(a) * r * w / 2, h / 2 + math.sin(a) * r * h / 2));
        }
        return _poly(pts);
    }
    return Path()..addRect(Rect.fromLTWH(0, 0, w, h));
  }

  Path _custom(Size s) {
    final out = Path();
    for (final c in cust) {
      final kx = s.width / c.w, ky = s.height / c.h;
      for (final cmd in c.cmds) {
        final q = cmd.$2;
        switch (cmd.$1) {
          case 'moveTo':
            if (q.length >= 2) out.moveTo(q[0] * kx, q[1] * ky);
            break;
          case 'lnTo':
            if (q.length >= 2) out.lineTo(q[0] * kx, q[1] * ky);
            break;
          case 'cubicBezTo':
            if (q.length >= 6) out.cubicTo(q[0] * kx, q[1] * ky, q[2] * kx, q[3] * ky, q[4] * kx, q[5] * ky);
            break;
          case 'quadBezTo':
            if (q.length >= 4) out.quadraticBezierTo(q[0] * kx, q[1] * ky, q[2] * kx, q[3] * ky);
            break;
          case 'close':
            out.close();
            break;
        }
      }
    }
    return out;
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;
    canvas.save();
    if (flipH || flipV) {
      canvas.translate(flipH ? size.width : 0, flipV ? size.height : 0);
      canvas.scale(flipH ? -1 : 1, flipV ? -1 : 1);
    }
    final lp = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = linePx < .5 ? .5 : linePx
      ..color = _c(line ?? 0x000000);
    if (isLine) {
      canvas.drawLine(Offset.zero, Offset(size.width, size.height), lp);
      canvas.restore();
      return;
    }
    final path = geom == 'cust' ? _custom(size) : _path(size);
    if (grad != null && grad!.length >= 2) {
      final a = gradAngle * math.pi / 180;
      final dx = math.cos(a), dy = math.sin(a);
      final c = size.center(Offset.zero);
      final half = Offset(dx * size.width / 2, dy * size.height / 2);
      canvas.drawPath(path, Paint()..shader = _gradShader(c - half, c + half));
    } else if (fill != null) {
      canvas.drawPath(path, Paint()..color = _c(fill!, fillAlpha));
    }
    if (line != null && linePx > 0) canvas.drawPath(path, lp);
    canvas.restore();
  }

  Shader _gradShader(Offset a, Offset b) => LinearGradient(colors: [for (final g in grad!) _c(g)]).createShader(Rect.fromPoints(a, b));

  @override
  bool shouldRepaint(ShapePainter o) =>
      o.geom != geom || o.fill != fill || o.line != line || o.linePx != linePx || o.fillAlpha != fillAlpha || o.adj != adj || o.flipH != flipH || o.flipV != flipV || o.grad != grad || o.cust != cust;
}

// ------------------------------------------------------------------ charts

/// Draws a chart (column / bar / line / area / pie / doughnut / scatter, combinations of them) from the numbers cached in the file.
class ChartPainter extends CustomPainter {
  final PChart chart;
  final Color fg;
  ChartPainter(this.chart, this.fg);

  Color _col(PChartGroup g, int si, int? override) {
    final s = g.series[si];
    final v = override ?? s.color ?? chart.palette[si % chart.palette.length];
    return _c(v);
  }

  TextPainter _tp(String t, double size, {Color? color, double? maxW, TextAlign align = TextAlign.left, bool bold = false}) {
    final tp = TextPainter(
      text: TextSpan(text: t, style: TextStyle(fontSize: size, color: color ?? fg, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
      textDirection: TextDirection.ltr,
      textAlign: align,
      maxLines: 1,
      ellipsis: '…',
    )..layout(maxWidth: maxW ?? double.infinity);
    return tp;
  }

  String _fmt(double v) {
    final a = v.abs();
    if (a >= 1e9) return '${(v / 1e9).toStringAsFixed(1)}B';
    if (a >= 1e6) return '${(v / 1e6).toStringAsFixed(1)}M';
    if (a >= 1e4) return '${(v / 1e3).toStringAsFixed(0)}K';
    if (v == v.roundToDouble()) return v.toStringAsFixed(0);
    return v.toStringAsFixed(a < 10 ? 2 : 1);
  }

  /// "Nice" axis maximum / step.
  (double, double, double) _axis(double lo, double hi) {
    if (hi == lo) hi = lo + 1;
    final span = hi - lo;
    final raw = span / 5;
    final mag = math.pow(10, (math.log(raw) / math.ln10).floor()).toDouble();
    final n = raw / mag;
    final step = (n <= 1 ? 1 : (n <= 2 ? 2 : (n <= 5 ? 5 : 10))) * mag;
    final nlo = (lo / step).floor() * step, nhi = (hi / step).ceil() * step;
    return (nlo, nhi, step);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final fs = math.max(7.0, math.min(size.height / 14, size.width / 26));
    var top = 4.0, bottom = size.height - 4;
    if (chart.title != null) {
      final t = _tp(chart.title!, fs * 1.25, maxW: size.width - 8, bold: true, align: TextAlign.center);
      t.paint(canvas, Offset((size.width - t.width) / 2, 3));
      top = t.height + 8;
    }
    // legend
    final names = <(String, Color)>[];
    final first = chart.groups.first;
    if (first.kind == 'pie' || first.kind == 'doughnut') {
      final ser = first.series.first;
      for (var i = 0; i < ser.vals.length; i++) {
        names.add((i < chart.cats.length ? chart.cats[i] : '${i + 1}', _c(ser.pointColors[i] ?? chart.palette[i % chart.palette.length])));
      }
    } else {
      for (final g in chart.groups) {
        for (var i = 0; i < g.series.length; i++) {
          names.add((g.series[i].name.isEmpty ? 'Series ${names.length + 1}' : g.series[i].name, _col(g, i, null)));
        }
      }
    }
    if (chart.legend && names.isNotEmpty) {
      var x = 6.0;
      final y = bottom - fs * 1.3;
      for (final n in names) {
        final t = _tp(n.$1, fs, maxW: size.width / 3);
        if (x + fs + 4 + t.width > size.width - 4) break;
        canvas.drawRect(Rect.fromLTWH(x, y + fs * .2, fs * .8, fs * .8), Paint()..color = n.$2);
        t.paint(canvas, Offset(x + fs, y));
        x += fs + t.width + fs;
      }
      bottom = y - 4;
    }
    final area = Rect.fromLTRB(4, top, size.width - 4, bottom);
    if (area.width < 20 || area.height < 20) return;
    if (first.kind == 'pie' || first.kind == 'doughnut') {
      _pie(canvas, area, first);
      return;
    }
    if (first.kind == 'scatter') {
      _scatter(canvas, area, fs);
      return;
    }
    _axes(canvas, area, fs);
  }

  void _pie(Canvas canvas, Rect area, PChartGroup g) {
    final ser = g.series.first;
    final total = ser.vals.fold<double>(0, (a, b) => a + b.abs());
    if (total <= 0) return;
    final r = math.min(area.width, area.height) / 2 - 2;
    final c = area.center;
    var a0 = -math.pi / 2;
    for (var i = 0; i < ser.vals.length; i++) {
      final sw = ser.vals[i].abs() / total * 2 * math.pi;
      final col = _c(ser.pointColors[i] ?? chart.palette[i % chart.palette.length]);
      canvas.drawArc(Rect.fromCircle(center: c, radius: r), a0, sw, true, Paint()..color = col);
      canvas.drawArc(Rect.fromCircle(center: c, radius: r), a0, sw, true, Paint()..style = PaintingStyle.stroke..strokeWidth = 1..color = Colors.white);
      a0 += sw;
    }
    if (g.kind == 'doughnut') canvas.drawCircle(c, r * .5, Paint()..color = Colors.white);
  }

  void _scatter(Canvas canvas, Rect area, double fs) {
    final xs = <double>[], ys = <double>[];
    for (final g in chart.groups) {
      for (final s in g.series) {
        xs.addAll(s.xs.isEmpty ? [for (var i = 0; i < s.vals.length; i++) i + 1.0] : s.xs);
        ys.addAll(s.vals);
      }
    }
    if (xs.isEmpty) return;
    final ax = _axis(xs.reduce(math.min), xs.reduce(math.max)), ay = _axis(math.min(0, ys.reduce(math.min)), ys.reduce(math.max));
    final plot = Rect.fromLTRB(area.left + fs * 3, area.top + 4, area.right - 6, area.bottom - fs * 1.6);
    _grid(canvas, plot, ay.$1, ay.$2, ay.$3, fs);
    for (final g in chart.groups) {
      for (var si = 0; si < g.series.length; si++) {
        final s = g.series[si];
        final col = _col(g, si, null);
        for (var i = 0; i < s.vals.length; i++) {
          final x = s.xs.isEmpty ? i + 1.0 : s.xs[i];
          final px = plot.left + (x - ax.$1) / (ax.$2 - ax.$1) * plot.width;
          final py = plot.bottom - (s.vals[i] - ay.$1) / (ay.$2 - ay.$1) * plot.height;
          canvas.drawCircle(Offset(px, py), 3, Paint()..color = col);
        }
      }
    }
    for (var v = ax.$1; v <= ax.$2 + ax.$3 / 2; v += ax.$3) {
      final t = _tp(_fmt(v), fs * .9);
      t.paint(canvas, Offset(plot.left + (v - ax.$1) / (ax.$2 - ax.$1) * plot.width - t.width / 2, plot.bottom + 2));
    }
  }

  void _grid(Canvas canvas, Rect plot, double lo, double hi, double step, double fs) {
    final gp = Paint()..color = fg.withOpacity(.15)..strokeWidth = 1;
    for (var v = lo; v <= hi + step / 2; v += step) {
      final y = plot.bottom - (v - lo) / (hi - lo) * plot.height;
      canvas.drawLine(Offset(plot.left, y), Offset(plot.right, y), gp);
      final t = _tp(_fmt(v), fs * .9, align: TextAlign.right);
      t.paint(canvas, Offset(plot.left - t.width - 3, y - t.height / 2));
    }
    canvas.drawLine(plot.bottomLeft, plot.bottomRight, Paint()..color = fg.withOpacity(.5));
  }

  void _axes(Canvas canvas, Rect area, double fs) {
    final horizontal = chart.groups.any((g) => g.kind == 'bar');
    var n = chart.cats.length;
    for (final g in chart.groups) {
      for (final s in g.series) {
        n = math.max(n, s.vals.length);
      }
    }
    if (n == 0) return;
    // value range (stacked groups add up)
    var lo = 0.0, hi = 0.0;
    for (final g in chart.groups) {
      if (g.stacked || g.percent) {
        for (var i = 0; i < n; i++) {
          var pos = 0.0, neg = 0.0;
          for (final s in g.series) {
            final v = i < s.vals.length ? s.vals[i] : 0.0;
            if (v >= 0) {
              pos += v;
            } else {
              neg += v;
            }
          }
          hi = math.max(hi, g.percent ? 100 : pos);
          lo = math.min(lo, neg);
        }
      } else {
        for (final s in g.series) {
          for (final v in s.vals) {
            hi = math.max(hi, v);
            lo = math.min(lo, v);
          }
        }
      }
    }
    final ax = _axis(lo, hi);
    final lo2 = ax.$1, hi2 = ax.$2, step = ax.$3;
    final catLabel = fs * .9;
    final plot = horizontal
        ? Rect.fromLTRB(area.left + fs * 5, area.top + 4, area.right - 8, area.bottom - fs * 1.4)
        : Rect.fromLTRB(area.left + fs * 3.2, area.top + 4, area.right - 6, area.bottom - fs * 1.6);
    if (plot.width < 10 || plot.height < 10) return;
    double pos(double v) => horizontal ? plot.left + (v - lo2) / (hi2 - lo2) * plot.width : plot.bottom - (v - lo2) / (hi2 - lo2) * plot.height;
    // grid + value labels
    final gp = Paint()..color = fg.withOpacity(.15)..strokeWidth = 1;
    for (var v = lo2; v <= hi2 + step / 2; v += step) {
      final p = pos(v);
      if (horizontal) {
        canvas.drawLine(Offset(p, plot.top), Offset(p, plot.bottom), gp);
        final t = _tp(_fmt(v), catLabel);
        t.paint(canvas, Offset(p - t.width / 2, plot.bottom + 2));
      } else {
        canvas.drawLine(Offset(plot.left, p), Offset(plot.right, p), gp);
        final t = _tp(_fmt(v), catLabel, align: TextAlign.right);
        t.paint(canvas, Offset(plot.left - t.width - 3, p - t.height / 2));
      }
    }
    final slot = (horizontal ? plot.height : plot.width) / n;
    final barGroups = chart.groups.where((g) => g.kind == 'col' || g.kind == 'bar').toList();
    var clustered = 0;
    for (final g in barGroups) {
      clustered += (g.stacked || g.percent) ? 1 : g.series.length;
    }
    if (clustered == 0) clustered = 1;
    final bw = slot * .7 / clustered;
    var bi = 0;
    final zero = pos(0);
    for (final g in barGroups) {
      final stackedG = g.stacked || g.percent;
      for (var si = 0; si < g.series.length; si++) {
        final s = g.series[si];
        for (var i = 0; i < s.vals.length && i < n; i++) {
          var v = s.vals[i];
          var base = 0.0;
          if (stackedG) {
            var tot = 0.0;
            for (final o in g.series) {
              tot += i < o.vals.length ? o.vals[i].abs() : 0;
            }
            for (var k = 0; k < si; k++) {
              base += i < g.series[k].vals.length ? g.series[k].vals[i] : 0;
            }
            if (g.percent && tot > 0) {
              base = base / tot * 100;
              v = v / tot * 100;
            }
          }
          final col = _c(s.pointColors[i] ?? s.color ?? chart.palette[si % chart.palette.length]);
          final slotStart = (horizontal ? plot.top : plot.left) + slot * i + slot * .15;
          final off = stackedG ? 0.0 : bw * (bi + si);
          final a = pos(base), b = pos(base + v);
          final r = horizontal
              ? Rect.fromLTRB(math.min(a, b), slotStart + off, math.max(a, b), slotStart + off + (stackedG ? slot * .7 : bw))
              : Rect.fromLTRB(slotStart + off, math.min(a, b), slotStart + off + (stackedG ? slot * .7 : bw), math.max(a, b));
          canvas.drawRect(r, Paint()..color = col);
        }
      }
      bi += stackedG ? 1 : g.series.length;
    }
    // areas and lines
    for (final g in chart.groups) {
      if (g.kind != 'line' && g.kind != 'area') continue;
      final stackedG = g.stacked || g.percent;
      final acc = List<double>.filled(n, 0);
      for (var si = 0; si < g.series.length; si++) {
        final s = g.series[si];
        final col = _col(g, si, null);
        final pts = <Offset>[];
        for (var i = 0; i < s.vals.length && i < n; i++) {
          var v = s.vals[i];
          if (stackedG) {
            acc[i] += v;
            v = acc[i];
          }
          pts.add(Offset(plot.left + slot * (i + .5), pos(v)));
        }
        if (pts.isEmpty) continue;
        if (g.kind == 'area') {
          final path = Path()..moveTo(pts.first.dx, zero);
          for (final p in pts) {
            path.lineTo(p.dx, p.dy);
          }
          path.lineTo(pts.last.dx, zero);
          path.close();
          canvas.drawPath(path, Paint()..color = col.withOpacity(.55));
        }
        final lp = Path()..moveTo(pts.first.dx, pts.first.dy);
        for (final p in pts.skip(1)) {
          lp.lineTo(p.dx, p.dy);
        }
        canvas.drawPath(lp, Paint()..style = PaintingStyle.stroke..strokeWidth = 2.2..color = col..strokeJoin = StrokeJoin.round);
        if (g.kind == 'line') {
          for (final p in pts) {
            canvas.drawCircle(p, 3, Paint()..color = col);
          }
        }
      }
    }
    // axis line + category labels
    canvas.drawLine(horizontal ? Offset(zero, plot.top) : Offset(plot.left, zero), horizontal ? Offset(zero, plot.bottom) : Offset(plot.right, zero), Paint()..color = fg.withOpacity(.5));
    final every = math.max(1, (n / ((horizontal ? plot.height : plot.width) / (catLabel * 4))).ceil());
    for (var i = 0; i < n; i += every) {
      final label = i < chart.cats.length ? chart.cats[i] : '${i + 1}';
      if (horizontal) {
        final t = _tp(label, catLabel, maxW: fs * 5, align: TextAlign.right);
        t.paint(canvas, Offset(plot.left - t.width - 4, plot.top + slot * (i + .5) - t.height / 2));
      } else {
        final t = _tp(label, catLabel, maxW: slot * every, align: TextAlign.center);
        t.paint(canvas, Offset(plot.left + slot * (i + .5) - t.width / 2, plot.bottom + 3));
      }
    }
  }

  @override
  bool shouldRepaint(ChartPainter o) => o.chart != chart || o.fg != fg;
}
