import 'dart:typed_data';
import 'package:flutter/material.dart' hide Icon;
import 'app_icon.dart';
import '../services/file_ops.dart';
import '../services/folder_sizes.dart';
import '../services/thumbs.dart';
import 'ui.dart';

/// Image thumbnail / video frame / APK icon / folder or file icon.
class FileThumb extends StatefulWidget {
  final FItem item;
  final double size;
  const FileThumb({super.key, required this.item, this.size = 44});
  @override
  State<FileThumb> createState() => _FileThumbState();
}

class _FileThumbState extends State<FileThumb> {
  Future<Uint8List?>? _f;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(FileThumb old) {
    super.didUpdateWidget(old);
    if (old.item.path != widget.item.path || old.item.modified != widget.item.modified) _load();
  }

  void _load() {
    final i = widget.item;
    if (i.isDir) {
      _f = null;
    } else if (FileOps.isCat(i.path, Cat.videos)) {
      _f = Thumbs.video(i);
    } else if (FileOps.ext(i.path) == 'apk') {
      _f = Thumbs.apkIcon(i);
    } else {
      _f = null;
    }
  }

  Widget _icon(double s) => TypeIcon(widget.item.path, widget.item.isDir, size: s * .8);

  @override
  Widget build(BuildContext context) {
    final i = widget.item, s = widget.size;
    Widget child;
    if (!i.isDir && FileOps.isCat(i.path, Cat.images) && FileOps.ext(i.path) != 'svg') {
      child = ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: ImageThumb(item: i, size: s, fallback: _icon(s)),
      );
    } else if (_f != null) {
      final apk = FileOps.ext(i.path) == 'apk';
      child = FutureBuilder<Uint8List?>(
        future: _f,
        builder: (_, snap) {
          final d = snap.data;
          if (d == null) return _icon(s);
          if (apk) return Padding(padding: EdgeInsets.all(s * .08), child: Image.memory(d, fit: BoxFit.contain, gaplessPlayback: true));
          return ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Stack(fit: StackFit.expand, children: [
              Image.memory(d, fit: BoxFit.cover, gaplessPlayback: true),
              Align(
                alignment: Alignment.bottomRight,
                child: Container(
                  margin: const EdgeInsets.all(2),
                  decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                  child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: (s * .28).clamp(12, 26).toDouble()),
                ),
              ),
            ]),
          );
        },
      );
    } else {
      child = _icon(s);
    }
    return SizedBox(width: s, height: s, child: Center(child: child));
  }
}

/// Folder size line (`12.4 MB • date`), cached and refreshed in the background.
class FolderSizeText extends StatefulWidget {
  final String path;
  final DateTime modified;
  final String suffix;
  final TextStyle? style;
  const FolderSizeText({super.key, required this.path, required this.modified, this.suffix = '', this.style});
  @override
  State<FolderSizeText> createState() => _FolderSizeTextState();
}

class _FolderSizeTextState extends State<FolderSizeText> {
  int? size;

  @override
  void initState() {
    super.initState();
    _check();
  }

  @override
  void didUpdateWidget(FolderSizeText old) {
    super.didUpdateWidget(old);
    _check();
  }

  void _check() {
    size = FolderSizes.cached(widget.path);
    if (!FolderSizes.fresh(widget.path, widget.modified)) {
      final path = widget.path;
      FolderSizes.get(path, mtime: widget.modified).then((v) {
        if (mounted && widget.path == path) setState(() => size = v);
      });
    }
  }

  @override
  Widget build(BuildContext context) => Text(
        '${size == null ? '…' : FileOps.fmt(size!)}${widget.suffix}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: widget.style,
      );
}


/// Fast square image preview: native sub-sampled thumbnail + disk cache, queued newest-first and
/// cancelled when the tile scrolls off-screen. Shows a calm placeholder while loading.
class ImageThumb extends StatefulWidget {
  final FItem item;
  final double size;
  final BoxFit fit;
  final Widget? fallback;
  const ImageThumb({super.key, required this.item, required this.size, this.fit = BoxFit.cover, this.fallback});
  @override
  State<ImageThumb> createState() => _ImageThumbState();
}

class _ImageThumbState extends State<ImageThumb> {
  Uint8List? _data;
  ThumbJob? _job;
  String? _key;
  bool _failed = false;

  int _pxFor(BuildContext c) {
    final want = widget.size * MediaQuery.of(c).devicePixelRatio;
    for (final b in const [96, 128, 192, 256, 384, 512]) {
      if (want <= b) return b;
    }
    return 512;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _load();
  }

  @override
  void didUpdateWidget(ImageThumb old) {
    super.didUpdateWidget(old);
    _load();
  }

  @override
  void dispose() {
    _job?.cancel();
    super.dispose();
  }

  void _load() {
    final it = widget.item;
    final px = _pxFor(context);
    final key = Thumbs.imageKey(it, px);
    if (key == _key) return;
    _key = key;
    _job?.cancel();
    _job = null;
    _failed = false;
    final hit = Thumbs.peekImage(it, px);
    if (hit != null) {
      _data = hit;
      return;
    }
    _data = null;
    if (Thumbs.isImageFailed(it, px)) {
      _failed = true;
      return;
    }
    _job = Thumbs.requestImage(it, px, (d) {
      if (!mounted) return;
      setState(() {
        _data = d;
        _failed = d == null;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.size;
    final d = _data;
    if (d != null) {
      return Image.memory(d, width: s, height: s, fit: widget.fit, gaplessPlayback: true, filterQuality: FilterQuality.low);
    }
    if (_failed) {
      return SizedBox(width: s, height: s, child: Center(child: widget.fallback ?? Icon(Icons.broken_image_rounded, size: s * .4, color: Theme.of(context).hintColor)));
    }
    return Container(width: s, height: s, color: Theme.of(context).colorScheme.onSurface.withOpacity(.06));
  }
}
