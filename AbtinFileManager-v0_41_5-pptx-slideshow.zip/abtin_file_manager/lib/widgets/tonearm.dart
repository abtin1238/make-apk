import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../services/player_service.dart';

/// Gramophone tonearm drawn over a 340 x 350 area (the record is 300 px at top 45, centre (150,195)).
/// Play  -> the arm swings in and drops the needle on the outer groove,
///          then creeps towards the label while the song advances.
/// Pause -> the arm lifts and swings back to its rest post.
class Tonearm extends StatefulWidget {
  final PlayerService pl;
  const Tonearm({super.key, required this.pl});
  static const size = Size(340, 350);
  @override
  State<Tonearm> createState() => _TonearmState();
}

class _TonearmState extends State<Tonearm> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1100), value: widget.pl.playing ? 1 : 0);

  @override
  void didUpdateWidget(Tonearm old) {
    super.didUpdateWidget(old);
    _sync();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _sync();
  }

  void _sync() {
    if (widget.pl.playing) {
      if (_c.status != AnimationStatus.forward && _c.value < 1) _c.forward();
    } else {
      if (_c.status != AnimationStatus.reverse && _c.value > 0) _c.reverse();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.pl.player;
    return StreamBuilder<Duration>(
      stream: p.stream.position,
      builder: (_, snap) {
        final d = p.state.duration.inMilliseconds;
        final pos = (snap.data ?? p.state.position).inMilliseconds;
        final prog = d <= 0 ? 0.0 : (pos / d).clamp(0.0, 1.0).toDouble();
        return TweenAnimationBuilder<double>(
          tween: Tween<double>(end: prog),
          duration: const Duration(milliseconds: 600),
          builder: (_, sm, __) => AnimatedBuilder(
            animation: _c,
            builder: (_, __) => CustomPaint(
              size: Tonearm.size,
              painter: _ArmPainter(Curves.easeInOutCubic.transform(_c.value), sm),
            ),
          ),
        );
      },
    );
  }
}

class _ArmPainter extends CustomPainter {
  final double engaged; // 0 = resting, 1 = needle on the record
  final double progress; // 0..1 position in the song
  _ArmPainter(this.engaged, this.progress);

  static const pivot = Offset(300, 52);
  static const center = Offset(150, 195);
  static const armLen = 235.0;
  static const restAngle = 82 * math.pi / 180;

  /// Arm angle for which the needle touches the circle of radius [r] around the record centre.
  static double phiFor(double r) {
    final d = (center - pivot).distance;
    final base = math.atan2(center.dy - pivot.dy, center.dx - pivot.dx);
    final ca = ((armLen * armLen + d * d - r * r) / (2 * armLen * d)).clamp(-1.0, 1.0).toDouble();
    return base - math.acos(ca);
  }

  @override
  void paint(Canvas canvas, Size s) {
    final play = ui.lerpDouble(phiFor(142), phiFor(106), progress)!;
    final phi = ui.lerpDouble(restAngle, play, engaged)!;
    final dir = Offset(math.cos(phi), math.sin(phi));
    final nrm = Offset(-dir.dy, dir.dx);
    final tip = pivot + dir * armLen;
    final lift = 1 - engaged;
    final so = Offset(3 + 6 * lift, 5 + 8 * lift);

    // straight shaft that bends gently towards the record near the head
    final c1 = pivot + dir * (armLen * .55);
    final c2 = pivot + dir * (armLen * .82) + nrm * 9;
    final arm = Path()
      ..moveTo(pivot.dx, pivot.dy)
      ..cubicTo(c1.dx, c1.dy, c2.dx, c2.dy, tip.dx, tip.dy);
    final tan = tip - c2;
    final tAng = math.atan2(tan.dy, tan.dx);

    // shadow
    canvas.save();
    canvas.translate(so.dx, so.dy);
    canvas.drawPath(
        arm,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeWidth = 9
          ..color = Colors.black.withOpacity(.28)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, 4 + 5 * lift));
    canvas.restore();

    // pivot base
    canvas.drawCircle(pivot + const Offset(0, 2), 27, Paint()..color = Colors.black.withOpacity(.22)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5));
    canvas.drawCircle(pivot, 26, Paint()..color = Colors.white.withOpacity(.14));
    canvas.drawCircle(pivot, 26, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = Colors.white.withOpacity(.25));

    // arm tube
    canvas.drawPath(arm, Paint()..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeWidth = 9..color = Colors.white);

    // pivot cap
    canvas.drawCircle(pivot, 19, Paint()..color = Colors.white);
    canvas.drawCircle(pivot, 9, Paint()..color = Colors.black.withOpacity(.38));
    canvas.drawCircle(pivot, 9, Paint()..style = PaintingStyle.stroke..strokeWidth = 1..color = Colors.white.withOpacity(.5));

    // head shell: white block with two grooves, ends at the needle point
    canvas.save();
    canvas.translate(tip.dx, tip.dy);
    canvas.rotate(tAng + .30);
    final head = RRect.fromRectAndRadius(const Rect.fromLTWH(-34, -8.5, 34, 17), const Radius.circular(4));
    canvas.drawRRect(head.shift(const Offset(1.5, 2.5)), Paint()..color = Colors.black.withOpacity(.25)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3));
    canvas.drawRRect(head, Paint()..color = Colors.white);
    final g = Paint()..color = Colors.black.withOpacity(.28)..strokeWidth = 2..strokeCap = StrokeCap.round;
    canvas.drawLine(const Offset(-12, -4), const Offset(-12, 4), g);
    canvas.drawLine(const Offset(-6, -4), const Offset(-6, 4), g);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _ArmPainter o) => o.engaged != engaged || o.progress != progress;
}
