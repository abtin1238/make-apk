import 'package:flutter/material.dart';
import '../core/looks.dart';
import 'adaptive_nav.dart';

// Building blocks of the Neon look (pixel-matched to the supplied mockup):
//   NeonCutCard  – glowing card with two bevelled (cut) corners
//   NeonBackdrop – black background with diagonal glowing light lines
//   NeonRail     – slim side rail with a glowing selected icon

/// Outline of a card with the top-left and bottom-right corners cut by [cut] and
/// the other two corners cut by a smaller amount.
Path neonCutPath(Size s, double cut) {
  final big = cut;
  final small = cut * .4;
  return Path()
    ..moveTo(big, 0)
    ..lineTo(s.width - small, 0)
    ..lineTo(s.width, small)
    ..lineTo(s.width, s.height - big)
    ..lineTo(s.width - big, s.height)
    ..lineTo(small, s.height)
    ..lineTo(0, s.height - small)
    ..lineTo(0, big)
    ..close();
}

class _CutClipper extends CustomClipper<Path> {
  final double cut;
  const _CutClipper(this.cut);
  @override
  Path getClip(Size size) => neonCutPath(size, cut);
  @override
  bool shouldReclip(_CutClipper old) => old.cut != cut;
}

class _NeonCutPainter extends CustomPainter {
  final List<Color> colors;
  final double cut;
  final bool dark;
  _NeonCutPainter(this.colors, this.cut, this.dark);

  @override
  void paint(Canvas canvas, Size size) {
    final path = neonCutPath(size, cut);
    final rect = Offset.zero & size;
    final a = colors.first;
    final b = colors.last;
    // fill
    canvas.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: dark
              ? [Color.alphaBlend(a.withOpacity(.16), const Color(0xFF070B1A)), Color.alphaBlend(b.withOpacity(.14), const Color(0xFF0B0820))]
              : [Color.alphaBlend(a.withOpacity(.08), Colors.white), Color.alphaBlend(b.withOpacity(.08), Colors.white)],
        ).createShader(rect),
    );
    // soft outer glow
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9)
        ..shader = LinearGradient(colors: [a.withOpacity(dark ? .55 : .35), b.withOpacity(dark ? .55 : .35)], begin: Alignment.topLeft, end: Alignment.bottomRight).createShader(rect),
    );
    // crisp gradient outline
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.6
        ..strokeJoin = StrokeJoin.round
        ..shader = LinearGradient(colors: [a, b], begin: Alignment.topLeft, end: Alignment.bottomRight).createShader(rect),
    );
  }

  @override
  bool shouldRepaint(_NeonCutPainter o) => o.cut != cut || o.dark != dark || o.colors.first != colors.first || o.colors.last != colors.last;
}

/// Glowing card with bevelled corners.
class NeonCutCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double cut;
  final VoidCallback? onTap;
  const NeonCutCard({super.key, required this.child, this.padding = const EdgeInsets.all(18), this.cut = 26, this.onTap});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return CustomPaint(
      painter: _NeonCutPainter(Looks.accentColors(t.colorScheme), cut, t.brightness == Brightness.dark),
      child: ClipPath(
        clipper: _CutClipper(cut),
        child: Material(
          type: MaterialType.transparency,
          child: InkWell(onTap: onTap, child: Padding(padding: padding, child: child)),
        ),
      ),
    );
  }
}

class _BackdropPainter extends CustomPainter {
  final Color a, b;
  _BackdropPainter(this.a, this.b);

  void _line(Canvas canvas, Path p, Color c, double w, double glow) {
    canvas.drawPath(p, Paint()..style = PaintingStyle.stroke..strokeWidth = w + 5..color = c.withOpacity(.35)..maskFilter = MaskFilter.blur(BlurStyle.normal, glow));
    canvas.drawPath(p, Paint()..style = PaintingStyle.stroke..strokeWidth = w..strokeJoin = StrokeJoin.round..color = c.withOpacity(.9));
  }

  @override
  void paint(Canvas canvas, Size s) {
    final w = s.width, h = s.height;
    // long cyan diagonal rising from the bottom-left
    _line(canvas, Path()..moveTo(0, h * .93)..lineTo(w * .46, h * .83)..lineTo(w * .88, h * .52)..lineTo(w * .88, h * .30), a, 1.4, 6);
    // lower purple diagonal and corner
    _line(canvas, Path()..moveTo(w * .30, h)..lineTo(w * .44, h * .965)..lineTo(w * .80, h * .965)..lineTo(w, h * .86), b, 1.6, 8);
    // right purple edge
    _line(canvas, Path()..moveTo(w, h * .70)..lineTo(w * .93, h * .78)..lineTo(w * .93, h * .90), b, 1.2, 6);
    // faint floor glow
    canvas.drawRect(
      Rect.fromLTWH(0, h * .70, w, h * .30),
      Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, b.withOpacity(.10)]).createShader(Rect.fromLTWH(0, h * .70, w, h * .30)),
    );
  }

  @override
  bool shouldRepaint(_BackdropPainter o) => o.a != a || o.b != b;
}

/// Diagonal glowing lines behind the content (only drawn in dark mode).
class NeonBackdrop extends StatelessWidget {
  final Widget child;
  const NeonBackdrop({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    if (t.brightness != Brightness.dark) return child;
    final c = Looks.accentColors(t.colorScheme);
    return Stack(children: [
      Positioned.fill(child: IgnorePointer(child: RepaintBoundary(child: CustomPaint(painter: _BackdropPainter(c.first, c.last))))),
      child,
    ]);
  }
}

/// Slim rail with the destination icons; the selected one sits in a glowing rounded square.
class NeonRail extends StatelessWidget {
  final int selected; // index inside [items]; -1 = none
  final ValueChanged<int> onSelect;
  final List<NavItem> items;
  const NeonRail({super.key, required this.selected, required this.onSelect, required this.items});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final cs = t.colorScheme;
    final c = Looks.accentColors(cs);
    final dark = t.brightness == Brightness.dark;
    return Container(
      width: 72,
      decoration: BoxDecoration(
        border: BorderDirectional(end: BorderSide(color: c.first.withOpacity(.55), width: 1)),
        boxShadow: [BoxShadow(color: c.first.withOpacity(.22), blurRadius: 12, spreadRadius: -4)],
      ),
      child: SafeArea(
        child: Column(children: [
          const SizedBox(height: 18),
          for (var i = 0; i < items.length; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: 14),
              child: Tooltip(
                message: items[i].label,
                child: InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => onSelect(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 180),
                    width: 52,
                    height: 52,
                    decoration: i == selected
                        ? BoxDecoration(
                            borderRadius: BorderRadius.circular(16),
                            color: c.first.withOpacity(dark ? .20 : .14),
                            border: Border.all(color: c.first, width: 1.4),
                            boxShadow: [BoxShadow(color: c.first.withOpacity(.55), blurRadius: 14, spreadRadius: -1)],
                          )
                        : BoxDecoration(borderRadius: BorderRadius.circular(16)),
                    child: Icon(items[i].icon, size: 28, color: i == selected ? (dark ? Colors.white : c.first) : cs.onSurface.withOpacity(.78)),
                  ),
                ),
              ),
            ),
        ]),
      ),
    );
  }
}
