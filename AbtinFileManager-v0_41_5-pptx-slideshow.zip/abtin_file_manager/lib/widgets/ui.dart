import 'package:flutter/material.dart' hide Icon;
import 'app_icon.dart';
import '../core/l10n.dart';
import '../core/icon_prefs.dart';
import '../core/looks.dart';
import '../core/theme.dart';
import '../services/file_ops.dart';

String iconKey(String path, bool dir) {
  if (dir) return 'folder';
  switch (FileOps.catOf(path)) {
    case Cat.images: return 'images';
    case Cat.videos: return 'videos';
    case Cat.audio: return 'audio';
    case Cat.docs: return FileOps.ext(path) == 'pdf' ? 'pdf' : 'docs';
    case Cat.apps: return 'apps';
    case Cat.archives: return 'archives';
    default: return 'other';
  }
}

IconData iconFor(String path, bool dir) => IconPrefs.icon(iconKey(path, dir));

Color colorFor(String path, bool dir) => IconPrefs.color(iconKey(path, dir));

/// Folder / file-type icon in the user's shape and colour (solid or gradient).
class TypeIcon extends StatelessWidget {
  final String path;
  final bool dir;
  final double? size;
  const TypeIcon(this.path, this.dir, {super.key, this.size});
  @override
  Widget build(BuildContext context) => KeyIcon(iconKey(path, dir), size: size);
}

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c).hideCurrentSnackBar();
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));
}

Future<String?> promptText(BuildContext c, String title, {String initial = '', bool obscure = false}) {
  final ctl = TextEditingController(text: initial);
  final dot = initial.lastIndexOf('.');
  ctl.selection = TextSelection(baseOffset: 0, extentOffset: dot > 0 ? dot : initial.length);
  return showDialog<String>(
    context: c,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: ctl, autofocus: true, obscureText: obscure,
        onSubmitted: (v) => Navigator.pop(c, v.trim()),
      ),
      actions: [
        CancelButton(onPressed: () => Navigator.pop(c)),
        FilledButton(onPressed: () => Navigator.pop(c, ctl.text.trim()), child: Text(L.t('ok'))),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      content: Text(msg),
      actions: [
        CancelButton(onPressed: () => Navigator.pop(c, false)),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(L.t('ok'))),
      ],
    ),
  );
  return r ?? false;
}

/// Runs [job] behind a blocking spinner; shows error in a snackbar.
Future<bool> busy(BuildContext c, Future<void> Function() job) async {
  showDialog(
    context: c,
    barrierDismissible: false,
    builder: (_) => const PopScope(canPop: false, child: Center(child: CircularProgressIndicator())),
  );
  var ok = true;
  try {
    await job();
  } catch (e) {
    ok = false;
    final msg = e is OpError ? (e.arg == null ? L.t(e.key) : '${L.t(e.key)}: ${e.arg}') : '${L.t('error')}: $e';
    if (c.mounted) snack(c, msg);
  }
  if (c.mounted) Navigator.of(c, rootNavigator: true).pop();
  return ok;
}

/// Like [busy] but shows a title and a percentage bar. The job reports its
/// progress through the callback: 0..1, or null for "unknown" (indeterminate).
Future<bool> busyProgress(BuildContext c, String title, Future<void> Function(void Function(double?) report) job) async {
  final prog = ValueNotifier<double?>(null);
  showDialog(
    context: c,
    barrierDismissible: false,
    builder: (_) => PopScope(
      canPop: false,
      child: AlertDialog(
        title: Text(title),
        content: ValueListenableBuilder<double?>(
          valueListenable: prog,
          builder: (_, v, __) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            LinearProgressIndicator(value: v, minHeight: 8, borderRadius: BorderRadius.circular(6)),
            const SizedBox(height: 8),
            Text(v == null ? '…' : '${(v * 100).clamp(0, 100).round()}%'),
          ]),
        ),
      ),
    ),
  );
  var ok = true;
  try {
    await job((v) => prog.value = v);
  } catch (e) {
    ok = false;
    final msg = e is OpError ? (e.arg == null ? L.t(e.key) : '${L.t(e.key)}: ${e.arg}') : '${L.t('error')}: $e';
    if (c.mounted) snack(c, msg);
  }
  if (c.mounted) Navigator.of(c, rootNavigator: true).pop();
  prog.dispose();
  return ok;
}

class GradCard extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  final double radius;
  const GradCard({super.key, required this.child, this.onTap, this.padding = const EdgeInsets.all(14), this.radius = 18});
  @override
  Widget build(BuildContext context) {
    AppStyleScope.watch(context); // repaint when the look changes
    final r = BorderRadius.circular(radius);
    return DecoratedBox(
      decoration: Looks.card(context, radius: radius),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(borderRadius: r, onTap: onTap, child: Padding(padding: padding, child: child)),
      ),
    );
  }
}


/// Red "cancel" button used in every dialog, so cancelling is always easy to spot.
class CancelButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final String? label;
  final bool icon;
  const CancelButton({super.key, required this.onPressed, this.label, this.icon = false});
  @override
  Widget build(BuildContext context) {
    final st = TextButton.styleFrom(foregroundColor: AppColors.danger, backgroundColor: AppColors.danger.withOpacity(.16));
    final t = Text(label ?? L.t('cancel'), maxLines: 1, overflow: TextOverflow.ellipsis);
    return icon
        ? TextButton.icon(onPressed: onPressed, style: st, icon: const Icon(Icons.close_rounded, size: 18), label: t)
        : TextButton(onPressed: onPressed, style: st, child: t);
  }
}

/// Slider that always runs left (min) -> right (max), also in Persian / RTL, so values and colour tracks never flip.
class LSlider extends StatelessWidget {
  final double value, min, max;
  final int? divisions;
  final Color? activeColor;
  final String? label;
  final ValueChanged<double>? onChanged;
  final ValueChanged<double>? onChangeEnd;
  const LSlider({super.key, required this.value, this.min = 0, this.max = 1, this.divisions, this.activeColor, this.label, this.onChanged, this.onChangeEnd});
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.ltr,
        child: Slider(value: value, min: min, max: max, divisions: divisions, label: label, activeColor: activeColor, onChanged: onChanged, onChangeEnd: onChangeEnd),
      );
}
