import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart' hide Icon;
import 'app_icon.dart';
import '../core/l10n.dart';
import '../core/player_theme.dart';

// =====================================================================================
//  Neon-glass building blocks for the video player. Everything takes a [PlayerTheme]
//  so a change of colours / glass / glow is reflected immediately.
// =====================================================================================

/// Frosted panel with a soft neon border and glow.
class Glass extends StatelessWidget {
  final PlayerTheme t;
  final Widget child;
  final double radius;
  final EdgeInsetsGeometry padding;
  final bool glowing;
  const Glass({super.key, required this.t, required this.child, this.radius = 20, this.padding = EdgeInsets.zero, this.glowing = false});

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(radius);
    final a = t.glass.clamp(0.0, 1.0).toDouble();
    final inner = Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: r,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Color.lerp(const Color(0xFF0C1330), t.accent, .14)!.withOpacity(a),
            const Color(0xFF050818).withOpacity((a + .14).clamp(0.0, 1.0).toDouble()),
          ],
        ),
        border: Border.all(
          color: Color.lerp(Colors.white, t.highlight, glowing ? .85 : .45)!.withOpacity(glowing ? .8 : .2),
          width: glowing ? 1.5 : 1,
        ),
      ),
      child: child,
    );
    final body = t.blur ? ClipRRect(borderRadius: r, child: BackdropFilter(filter: ui.ImageFilter.blur(sigmaX: 14, sigmaY: 14), child: inner)) : inner;
    final g = t.glow * (glowing ? 1.0 : .45);
    return DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: r,
        boxShadow: g <= 0 ? const [] : [BoxShadow(color: t.accent.withOpacity(.34 * g), blurRadius: glowing ? 22 : 14, spreadRadius: -3)],
      ),
      child: body,
    );
  }
}

/// Plain tappable icon used inside grouped glass bars.
class BareIcon extends StatelessWidget {
  final PlayerTheme t;
  final IconData icon;
  final VoidCallback? onTap;
  final bool on;
  final double size, pad;
  final String? tip;
  const BareIcon(this.t, this.icon, this.onTap, {super.key, this.on = false, this.size = 24, this.pad = 10, this.tip});

  @override
  Widget build(BuildContext context) {
    final w = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Padding(
        padding: EdgeInsets.all(pad),
        child: Icon(icon, size: size, color: onTap == null ? Colors.white30 : (on ? t.highlight : Colors.white), shadows: on && t.glow > 0 ? [Shadow(color: t.highlight.withOpacity(.9 * t.glow), blurRadius: 12)] : null),
      ),
    );
    return tip == null ? w : Tooltip(message: tip!, child: w);
  }
}

/// A group of icons inside one glass capsule (top-right bar of the design).
class GlassBar extends StatelessWidget {
  final PlayerTheme t;
  final List<Widget> children;
  const GlassBar({super.key, required this.t, required this.children});
  @override
  Widget build(BuildContext context) => Glass(t: t, radius: 26, padding: const EdgeInsets.symmetric(horizontal: 4), child: Row(mainAxisSize: MainAxisSize.min, children: children));
}

/// Rounded button with icon and optional label (bottom row of the design).
class GlassBtn extends StatelessWidget {
  final PlayerTheme t;
  final IconData icon;
  final String? label;
  final VoidCallback? onTap;
  final bool on;
  final double size, radius;
  final String? tip;
  const GlassBtn(this.t, this.icon, this.onTap, {super.key, this.label, this.on = false, this.size = 22, this.radius = 22, this.tip});

  @override
  Widget build(BuildContext context) {
    final col = onTap == null ? Colors.white30 : (on ? t.highlight : Colors.white);
    final w = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Glass(
        t: t,
        radius: radius,
        glowing: on,
        padding: EdgeInsets.symmetric(horizontal: label == null ? 11 : 14, vertical: 10),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: size, color: col),
          if (label != null) ...[
            const SizedBox(width: 8),
            Text(label!, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w600, color: col)),
          ],
        ]),
      ),
    );
    return tip == null ? w : Tooltip(message: tip!, child: w);
  }
}

/// Small text chip (info / speed / quality).
class GlassChip extends StatelessWidget {
  final PlayerTheme t;
  final String text;
  final IconData? icon, trailing;
  final VoidCallback? onTap;
  final bool on;
  const GlassChip(this.t, this.text, {super.key, this.icon, this.trailing, this.onTap, this.on = false});

  @override
  Widget build(BuildContext context) {
    final col = on ? t.highlight : Colors.white;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Glass(
        t: t,
        radius: 20,
        glowing: on,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (icon != null) ...[Icon(icon, size: 18, color: col), const SizedBox(width: 6)],
          Flexible(child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.w600, color: col))),
          if (trailing != null) ...[const SizedBox(width: 4), Icon(trailing, size: 18, color: col)],
        ]),
      ),
    );
  }
}

/// Big play / pause button: dark core, neon gradient ring, glow.
class NeonPlay extends StatelessWidget {
  final PlayerTheme t;
  final bool playing, buffering;
  final VoidCallback onTap;
  final double size;
  const NeonPlay({super.key, required this.t, required this.playing, required this.onTap, this.buffering = false, this.size = 84});

  @override
  Widget build(BuildContext context) => GestureDetector(
        onTap: onTap,
        child: SizedBox(
          width: size + 14,
          height: size + 14,
          child: Stack(alignment: Alignment.center, children: [
            CustomPaint(size: Size(size + 14, size + 14), painter: _RingPainter(t.accent, t.accent2, t.highlight, t.glow)),
            Icon(playing ? Icons.pause_rounded : Icons.play_arrow_rounded, size: size * .56, color: Colors.white, shadows: t.glow > 0 ? [Shadow(color: t.highlight.withOpacity(.9 * t.glow), blurRadius: 14)] : null),
            if (buffering) SizedBox(width: size + 10, height: size + 10, child: CircularProgressIndicator(strokeWidth: 3, color: t.highlight)),
          ]),
        ),
      );
}

class _RingPainter extends CustomPainter {
  final Color a, b, h;
  final double glow;
  _RingPainter(this.a, this.b, this.h, this.glow);

  @override
  void paint(Canvas c, Size s) {
    final ctr = s.center(Offset.zero);
    final r = s.width / 2 - 9;
    final rect = Rect.fromCircle(center: ctr, radius: r);
    // dark core
    c.drawCircle(ctr, r, Paint()..shader = RadialGradient(colors: [const Color(0xE6101A3C), const Color(0xF2050817)]).createShader(rect));
    final sweep = SweepGradient(colors: [h, a, b, a, h], transform: const GradientRotation(-math.pi / 2));
    if (glow > 0) {
      c.drawCircle(ctr, r, Paint()..style = PaintingStyle.stroke..strokeWidth = 8..maskFilter = MaskFilter.blur(BlurStyle.normal, 10 + 6 * glow)..shader = sweep.createShader(rect)..color = Colors.white.withOpacity(glow));
    }
    c.drawCircle(ctr, r, Paint()..style = PaintingStyle.stroke..strokeWidth = 4..shader = sweep.createShader(rect));
  }

  @override
  bool shouldRepaint(covariant _RingPainter o) => o.a != a || o.b != b || o.h != h || o.glow != glow;
}

/// Vertical glass slider with icon on top and percentage at the bottom (brightness / volume).
class VertSlider extends StatelessWidget {
  final PlayerTheme t;
  final IconData icon;
  final double value; // 0..1
  final Color c1, c2;
  final ValueChanged<double> onChanged;
  final VoidCallback? onEnd, onIconTap;
  final double width;
  const VertSlider({super.key, required this.t, required this.icon, required this.value, required this.c1, required this.c2, required this.onChanged, this.onEnd, this.onIconTap, this.width = 56});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: width,
        child: Glass(
          t: t,
          radius: width / 2,
          padding: const EdgeInsets.symmetric(vertical: 12),
          child: LayoutBuilder(builder: (_, box) {
            final showPct = box.maxHeight > 150;
            return Column(children: [
              GestureDetector(behavior: HitTestBehavior.opaque, onTap: onIconTap, child: Icon(icon, size: width * .46, color: Colors.white)),
              const SizedBox(height: 6),
              Expanded(
                child: LayoutBuilder(builder: (_, tb) {
                  final h = tb.maxHeight;
                  double f(double dy) => (1 - dy / math.max(h, 1)).clamp(0.0, 1.0).toDouble();
                  return GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTapDown: (d) => onChanged(f(d.localPosition.dy)),
                    onTapUp: (_) => onEnd?.call(),
                    onVerticalDragUpdate: (d) => onChanged(f(d.localPosition.dy)),
                    onVerticalDragEnd: (_) => onEnd?.call(),
                    child: CustomPaint(size: Size(width, h), painter: _VPainter(value.clamp(0.0, 1.0).toDouble(), c1, c2, t.glow)),
                  );
                }),
              ),
              if (showPct) ...[
                const SizedBox(height: 6),
                Text('${(value * 100).round()}%', style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w700, color: Colors.white)),
              ],
            ]);
          }),
        ),
      );
}

class _VPainter extends CustomPainter {
  final double v, glow;
  final Color c1, c2;
  _VPainter(this.v, this.c1, this.c2, this.glow);

  @override
  void paint(Canvas c, Size s) {
    const tw = 7.0, tr = 11.0;
    final cx = s.width / 2;
    final top = tr, bot = s.height - tr;
    final len = math.max(bot - top, 1);
    final y = bot - len * v;
    c.drawRRect(RRect.fromLTRBR(cx - tw / 2, top, cx + tw / 2, bot, const Radius.circular(4)), Paint()..color = Colors.white.withOpacity(.16));
    if (v > 0) {
      final fill = RRect.fromLTRBR(cx - tw / 2, y, cx + tw / 2, bot, const Radius.circular(4));
      final sh = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [c1, c2]).createShader(Rect.fromLTWH(0, top, s.width, len.toDouble()));
      if (glow > 0) c.drawRRect(fill, Paint()..shader = sh..maskFilter = MaskFilter.blur(BlurStyle.normal, 5 * glow + 1));
      c.drawRRect(fill, Paint()..shader = sh);
    }
    if (glow > 0) c.drawCircle(Offset(cx, y), tr + 4, Paint()..color = c1.withOpacity(.35 * glow)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6));
    c.drawCircle(Offset(cx, y), tr, Paint()..color = Color.lerp(Colors.white, c1, .22)!);
    c.drawCircle(Offset(cx, y), tr, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = Colors.white70);
  }

  @override
  bool shouldRepaint(covariant _VPainter o) => o.v != v || o.c1 != c1 || o.c2 != c2 || o.glow != glow;
}

/// Glass panel with an icon + title header (speed / aspect panels).
class GlassPanel extends StatelessWidget {
  final PlayerTheme t;
  final IconData icon;
  final String title;
  final Widget child;
  final double width;
  const GlassPanel({super.key, required this.t, required this.icon, required this.title, required this.child, this.width = 300});

  @override
  Widget build(BuildContext context) => SizedBox(
        width: width,
        child: Glass(
          t: t,
          radius: 26,
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
          child: Directionality(
            textDirection: L.rtl ? TextDirection.rtl : TextDirection.ltr,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row(children: [
                Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white)),
                const Spacer(),
                Icon(icon, size: 26, color: t.highlight),
              ]),
              const SizedBox(height: 12),
              child,
            ]),
          ),
        ),
      );
}

/// Grid of selectable chips (3 columns), the selected one glows and shows a check mark.
class ChoiceGrid<T> extends StatelessWidget {
  final PlayerTheme t;
  final List<(String, T)> items;
  final T selected;
  final ValueChanged<T> onPick;
  final int columns;
  const ChoiceGrid({super.key, required this.t, required this.items, required this.selected, required this.onPick, this.columns = 3});

  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    for (var i = 0; i < items.length; i += columns) {
      final cells = <Widget>[];
      for (var j = 0; j < columns; j++) {
        if (j > 0) cells.add(const SizedBox(width: 8));
        final k = i + j;
        cells.add(Expanded(child: k < items.length ? _chip(items[k].$1, items[k].$2) : const SizedBox.shrink()));
      }
      if (rows.isNotEmpty) rows.add(const SizedBox(height: 8));
      rows.add(Row(children: cells));
    }
    return Directionality(textDirection: TextDirection.ltr, child: Column(mainAxisSize: MainAxisSize.min, children: rows));
  }

  Widget _chip(String label, T v) {
    final on = v == selected;
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => onPick(v),
      child: Container(
        height: 40,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: on ? t.accent.withOpacity(.32) : Colors.white.withOpacity(.07),
          border: Border.all(color: on ? t.highlight : Colors.white.withOpacity(.1), width: on ? 1.6 : 1),
          boxShadow: on && t.glow > 0 ? [BoxShadow(color: t.highlight.withOpacity(.5 * t.glow), blurRadius: 12, spreadRadius: -2)] : null,
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          if (on) ...[Icon(Icons.check_rounded, size: 16, color: t.highlight), const SizedBox(width: 3)],
          Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13.5, fontWeight: FontWeight.w700, color: on ? Colors.white : Colors.white.withOpacity(.85)))),
        ]),
      ),
    );
  }
}

/// Seek bar painter: glowing gradient progress, buffer, chapter ticks, neon thumb.
class NeonSeek extends StatelessWidget {
  final PlayerTheme t;
  final double value, buffered; // 0..1
  final List<double> ticks;
  final bool active;
  final VoidCallback onStart, onEnd;
  final ValueChanged<double> onChanged;
  const NeonSeek({super.key, required this.t, required this.value, required this.buffered, required this.ticks, required this.active, required this.onStart, required this.onChanged, required this.onEnd});

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (_, box) {
        final w = box.maxWidth;
        double f(double dx) => (dx / w).clamp(0.0, 1.0).toDouble();
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTapUp: (d) { onStart(); onChanged(f(d.localPosition.dx)); onEnd(); },
          onHorizontalDragStart: (d) { onStart(); onChanged(f(d.localPosition.dx)); },
          onHorizontalDragUpdate: (d) => onChanged(f(d.localPosition.dx)),
          onHorizontalDragEnd: (_) => onEnd(),
          onHorizontalDragCancel: onEnd,
          child: CustomPaint(size: Size(w, 40), painter: _SeekPainter(value.clamp(0.0, 1.0).toDouble(), buffered, ticks, active, t.highlight, t.accent, t.glow)),
        );
      });
}

class _SeekPainter extends CustomPainter {
  final double v, buf, glow;
  final List<double> ticks;
  final bool active;
  final Color c1, c2;
  _SeekPainter(this.v, this.buf, this.ticks, this.active, this.c1, this.c2, this.glow);

  @override
  void paint(Canvas c, Size s) {
    const pad = 10.0;
    final w = s.width - 2 * pad;
    final cy = s.height / 2;
    final th = active ? 7.0 : 5.0;
    RRect bar(double from, double to) => RRect.fromLTRBR(pad + w * from, cy - th / 2, pad + w * to, cy + th / 2, Radius.circular(th / 2));
    c.drawRRect(bar(0, 1), Paint()..color = Colors.white.withOpacity(.18));
    if (buf > 0) c.drawRRect(bar(0, buf.clamp(0.0, 1.0).toDouble()), Paint()..color = Colors.white.withOpacity(.28));
    if (v > 0) {
      final sh = LinearGradient(colors: [c1, c2]).createShader(Rect.fromLTWH(pad, 0, math.max(w * v, 1), s.height));
      if (glow > 0) c.drawRRect(bar(0, v), Paint()..shader = sh..maskFilter = MaskFilter.blur(BlurStyle.normal, 4 + 4 * glow));
      c.drawRRect(bar(0, v), Paint()..shader = sh);
    }
    final tp = Paint()..color = Colors.white70..strokeWidth = 2;
    for (final f in ticks) {
      final x = pad + w * f.clamp(0.0, 1.0);
      c.drawLine(Offset(x, cy - th / 2 - 3), Offset(x, cy + th / 2 + 3), tp);
    }
    final x = pad + w * v;
    final r = active ? 12.0 : 9.0;
    if (glow > 0) c.drawCircle(Offset(x, cy), r + 6, Paint()..color = c1.withOpacity(.55 * glow)..maskFilter = const MaskFilter.blur(BlurStyle.normal, 7));
    c.drawCircle(Offset(x, cy), r, Paint()..color = Color.lerp(Colors.white, c1, .3)!);
    c.drawCircle(Offset(x, cy), r, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = Colors.white);
  }

  @override
  bool shouldRepaint(covariant _SeekPainter o) => o.v != v || o.buf != buf || o.active != active || o.ticks != ticks || o.c1 != c1 || o.c2 != c2 || o.glow != glow;
}

/// Gradient play-triangle logo (top-left of the design).
class AbtinLogo extends StatelessWidget {
  final PlayerTheme t;
  final double size;
  const AbtinLogo(this.t, {super.key, this.size = 40});
  @override
  Widget build(BuildContext context) => ShaderMask(
        shaderCallback: (r) => LinearGradient(colors: [t.highlight, t.accent, t.accent2], begin: Alignment.topLeft, end: Alignment.bottomRight).createShader(r),
        child: Icon(Icons.play_arrow_rounded, size: size, color: Colors.white, shadows: t.glow > 0 ? [Shadow(color: t.accent.withOpacity(.9 * t.glow), blurRadius: 14)] : null),
      );
}
