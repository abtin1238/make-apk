import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'adaptive_nav.dart';

// Building blocks of the Glass look:
//   GlassNavBar   – frosted bottom bar (Home / Recents / Starred / More)
//   UsageHistory  – remembers the used-space ratio over time (real data for the wave)
//   Sparkline     – smooth wave drawn on the storage card

/// Frosted, translucent bottom navigation bar.
class GlassNavBar extends StatelessWidget {
  final int selected;
  final ValueChanged<int> onSelect;
  final List<NavItem> items;
  final List<IconData>? selectedIcons;
  const GlassNavBar({super.key, required this.selected, required this.onSelect, required this.items, this.selectedIcons});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final cs = t.colorScheme;
    final dark = t.brightness == Brightness.dark;
    final off = cs.onSurface.withOpacity(.62);
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(26)),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 22, sigmaY: 22),
        child: Container(
          decoration: BoxDecoration(
            color: dark ? Colors.white.withOpacity(.07) : Colors.white.withOpacity(.80),
            border: Border(top: BorderSide(color: (dark ? Colors.white : Colors.black).withOpacity(dark ? .12 : .06))),
          ),
          child: SafeArea(
            top: false,
            child: SizedBox(
              height: 66,
              child: Row(children: [
                for (var i = 0; i < items.length; i++)
                  Expanded(
                    child: InkWell(
                      onTap: () => onSelect(i),
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(
                          i == selected && selectedIcons != null ? selectedIcons![i] : items[i].icon,
                          size: 26,
                          color: i == selected ? cs.primary : off,
                        ),
                        const SizedBox(height: 3),
                        Text(
                          items[i].label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontSize: 11.5, fontWeight: i == selected ? FontWeight.w700 : FontWeight.w500, color: i == selected ? cs.primary : off),
                        ),
                      ]),
                    ),
                  ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

/// Used-space ratio samples per storage root, kept in SharedPreferences
/// (at most one sample every [minGap], newest [maxSamples] kept).
class UsageHistory {
  static const minGap = Duration(hours: 6);
  static const maxSamples = 30;

  static String _key(String root) => 'usage_hist_${root.hashCode}';

  /// Samples are stored as "millisecondsSinceEpoch:ratio".
  static Future<List<double>> load(String root) async {
    final p = await SharedPreferences.getInstance();
    return _parse(p.getStringList(_key(root)) ?? const []).map((e) => e.value).toList();
  }

  static List<MapEntry<int, double>> _parse(List<String> raw) {
    final out = <MapEntry<int, double>>[];
    for (final r in raw) {
      final i = r.indexOf(':');
      if (i < 0) continue;
      final t = int.tryParse(r.substring(0, i));
      final v = double.tryParse(r.substring(i + 1));
      if (t != null && v != null) out.add(MapEntry(t, v));
    }
    return out;
  }

  /// Adds a sample (if the last one is older than [minGap]) and returns all samples, oldest first.
  static Future<List<double>> record(String root, double ratio) async {
    final p = await SharedPreferences.getInstance();
    final list = _parse(p.getStringList(_key(root)) ?? const []);
    final now = DateTime.now().millisecondsSinceEpoch;
    if (list.isEmpty || now - list.last.key >= minGap.inMilliseconds) {
      list.add(MapEntry(now, ratio.clamp(0.0, 1.0).toDouble()));
      while (list.length > maxSamples) {
        list.removeAt(0);
      }
      await p.setStringList(_key(root), [for (final e in list) '${e.key}:${e.value.toStringAsFixed(4)}']);
    }
    return list.map((e) => e.value).toList();
  }
}

class _SparkPainter extends CustomPainter {
  final List<double> values; // already normalised 0..1 (1 = top)
  final Color a, b;
  final double opacity;
  _SparkPainter(this.values, this.a, this.b, this.opacity);

  @override
  void paint(Canvas canvas, Size s) {
    if (values.length < 2) return;
    final dx = s.width / (values.length - 1);
    final pts = [for (var i = 0; i < values.length; i++) Offset(i * dx, s.height - values[i] * s.height * .8 - s.height * .1)];
    final line = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (var i = 0; i < pts.length - 1; i++) {
      final mx = (pts[i].dx + pts[i + 1].dx) / 2;
      line.cubicTo(mx, pts[i].dy, mx, pts[i + 1].dy, pts[i + 1].dx, pts[i + 1].dy);
    }
    final rect = Offset.zero & s;
    final fill = Path.from(line)..lineTo(s.width, s.height)..lineTo(0, s.height)..close();
    canvas.drawPath(
      fill,
      Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [a.withOpacity(.28 * opacity), a.withOpacity(0)]).createShader(rect),
    );
    canvas.drawPath(line, Paint()..style = PaintingStyle.stroke..strokeWidth = 5..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5)..color = a.withOpacity(.35 * opacity));
    canvas.drawPath(
      line,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..strokeCap = StrokeCap.round
        ..shader = LinearGradient(colors: [a.withOpacity(opacity), b.withOpacity(opacity)]).createShader(rect),
    );
  }

  @override
  bool shouldRepaint(_SparkPainter o) => o.values != values || o.a != a || o.b != b || o.opacity != opacity;
}

/// Smooth wave of the used-space history. With fewer than [minReal] real samples a faint decorative
/// wave is drawn instead (it is NOT data; the card has no numbers on it).
class Sparkline extends StatelessWidget {
  final List<double> samples;
  final Color a, b;
  final double height;
  static const minReal = 3;
  const Sparkline({super.key, required this.samples, required this.a, required this.b, this.height = 46});

  List<double> _decor() => [for (var i = 0; i < 24; i++) .5 + .28 * math.sin(i / 3.2) + .12 * math.sin(i / 1.4 + 1)];

  List<double> _norm() {
    var lo = samples.reduce(math.min), hi = samples.reduce(math.max);
    if (hi - lo < .01) {
      lo -= .005;
      hi += .005;
    }
    return [for (final v in samples) (v - lo) / (hi - lo)];
  }

  @override
  Widget build(BuildContext context) {
    final real = samples.length >= minReal;
    return SizedBox(
      height: height,
      width: double.infinity,
      child: CustomPaint(painter: _SparkPainter(real ? _norm() : _decor(), a, b, real ? 1 : .4)),
    );
  }
}
