# راهنمای ساخت Abtin File Manager

## پیش‌نیازها

- Flutter 3.47.9 (Dart 3.13.7)؛ این نسخه برای ساخت این پروژه آزموده شده است
- JDK 17
- Android SDK Platform 36 و Android Build Tools 36.0.0
- Android Gradle Plugin 8.11.1 و Kotlin Gradle Plugin 2.2.20 (در تنظیمات پروژه)
- Gradle Wrapper پروژه نسخهٔ 8.14.3 را به‌صورت خودکار دریافت می‌کند

## ساخت APK Release

از ریشهٔ پروژه اجرا کنید:

```bash
flutter pub get
flutter build apk --release --target-platform android-arm,android-arm64,android-x64
```

خروجی در این مسیر قرار می‌گیرد:

```text
build/app/outputs/flutter-apk/app-release.apk
```

پروژه برای Android API 36 کامپایل می‌شود و حداقل Android API آن 24 است. APK این دستور کتابخانه‌های `arm64-v8a`، `armeabi-v7a` و `x86_64` را دارد و روی همهٔ این دستگاه‌ها نصب می‌شود (حجم بیشتر از APK فقط-ARM64).

## امضای Release

فایل `android/key.properties` به keystore موجود در `android/keystore/abtin-file-manager-release.jks` اشاره می‌کند. مقادیر alias و رمزها در همان فایل تنظیم شده‌اند. برای ساخت، این دو فایل باید کنار سورس باقی بمانند.

**محرمانگی:** keystore و رمزهای آن اختیار امضای نسخه‌های بعدی برنامه را می‌دهند. فایل را در مخزن عمومی یا برای افراد دیگر منتشر نکنید و یک نسخهٔ پشتیبان امن و جداگانه نگه دارید. اگر keystore گم شود، به‌روزرسانی نصب‌های امضاشده با این کلید ممکن نخواهد بود.

## نکته دربارهٔ سورس اصلاح‌شده

برای سازگاری با Flutter 3.47.9، نسخه‌های Gradle/AGP/Kotlin به‌روزرسانی و ABI خروجی به `arm64-v8a`، `armeabi-v7a` و `x86_64` محدود شده است. آیکون اختصاصی از `assets/icons/NeonGlassFileManagerIcon.png` به اندازه‌های لازم Android تبدیل شده و در لانچر و splash استفاده می‌شود. برنامه هنگام شروع مرحلهٔ بارگذاری را نشان می‌دهد و اگر مقداردهی اولیه شکست بخورد، مرحله و جزئیات خطا را روی صفحه نمایش می‌دهد. بستهٔ `dartssh2` در `vendor/dartssh2` نگهداری می‌شود و یک null-check کوچک برای سازگاری با Dart 3.13 دارد. نسخه‌های وابستگی در `pubspec.lock` ثبت شده‌اند.
