package ir.abtin.sms

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

/** One access the call screen needs. missing(): true = off, false = on, null = cannot be detected. */
private class SetupStep(val id: String, val fa: String, val en: String, val hintFa: String?, val hintEn: String?,
                        val missing: () -> Boolean?, val open: () -> Unit)

fun isXiaomiFamily(): Boolean = Build.MANUFACTURER.lowercase().let { it.contains("xiaomi") || it.contains("redmi") || it.contains("poco") }

/** Opens the MIUI/HyperOS "Other permissions" page of this app (falls back to the app info page). */
fun openMiuiPermissions(act: ComponentActivity) {
    val ok = runCatching {
        act.startActivity(Intent("miui.intent.action.APP_PERM_EDITOR")
            .setClassName("com.miui.securitycenter", "com.miui.permcenter.permissions.PermissionsEditorActivity")
            .putExtra("extra_pkgname", act.packageName))
    }.isSuccess
    if (!ok) runCatching { act.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${act.packageName}"))) }
}

private fun buildSteps(act: ComponentActivity): List<SetupStep> {
    val nm = act.getSystemService(NotificationManager::class.java)
    val pm = act.getSystemService(PowerManager::class.java)
    val pkg = Uri.parse("package:${act.packageName}")
    val l = mutableListOf<SetupStep>()
    l += SetupStep("notif", "اعلان‌ها", "Notifications", null, null, { !nm.areNotificationsEnabled() }) {
        runCatching { act.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName)) }
    }
    if (Build.VERSION.SDK_INT >= 34) l += SetupStep("fsi", "اعلان تمام‌صفحه (روشن‌شدن صفحه قفل)", "Full-screen notifications", null, null, { !nm.canUseFullScreenIntent() }) {
        runCatching { act.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg)) }
    }
    l += SetupStep("overlay", "نمایش روی سایر برنامه‌ها", "Display over other apps", null, null, { !Settings.canDrawOverlays(act) }) {
        runCatching { act.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)) }
    }
    l += SetupStep("battery", "بدون محدودیت باتری", "Unrestricted battery", null, null, { !pm.isIgnoringBatteryOptimizations(act.packageName) }) {
        val ok = runCatching { act.startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkg)) }.isSuccess
        if (!ok) runCatching { act.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
    }
    if (isXiaomiFamily()) l += SetupStep("miui", "مجوزهای شیائومی", "Xiaomi permissions",
        "«نمایش روی صفحه قفل» و «پنجره‌های پاپ‌آپ در پس‌زمینه» را روی Allow بگذارید",
        "Set \"Show on Lock screen\" and \"Display pop-up windows while running in the background\" to Allow",
        { null }) { openMiuiPermissions(act) }
    return l
}

/** First-run guide: walks the user through every access the incoming-call screen needs. */
@Composable
fun CallAccessSetup(act: ComponentActivity, onClose: () -> Unit) {
    val p = LocalPal.current
    var tick by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }
    val tried = remember { mutableSetOf<String>() }

    fun advance() {
        val next = buildSteps(act).firstOrNull { it.id !in tried && it.missing() != false }
        if (next == null) { running = false; tick++; return }
        tried += next.id
        next.open()
    }

    DisposableEffect(act) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) { tick++; if (running) advance() }
        }
        act.lifecycle.addObserver(obs)
        onDispose { act.lifecycle.removeObserver(obs) }
    }

    @Suppress("UNUSED_VARIABLE") val t = tick
    val steps = buildSteps(act)
    val allDone = steps.all { it.missing() == false || (it.missing() == null && it.id in tried) }
    val finish = { Prefs.withProfile(true) { Prefs.callSetupDone.value = true }; onClose() }

    AlertDialog(
        onDismissRequest = { finish() },
        containerColor = p.bg2,
        title = { Text(tr("راه‌اندازی دسترسی‌های تماس", "Call access setup"), color = p.text) },
        text = {
            Column {
                Text(tr("برای اینکه تماس ورودی روی صفحه قفل روشن شود و بتوانید جواب بدهید، این دسترسی‌ها لازم است. اندروید اجازه نمی‌دهد برنامه خودش آن‌ها را روشن کند؛ با «اجازه بده» صفحه هر کدام پشت‌سرهم باز می‌شود و فقط باید روشنش کنید.",
                    "These accesses let an incoming call wake the lock screen. Android does not let an app turn them on by itself: \"Allow\" opens each page in turn and you only switch it on."),
                    color = p.sub, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                steps.forEach { s ->
                    val m = s.missing()
                    Column(Modifier.padding(vertical = 5.dp)) {
                        Text((if (m == false) "✓ " else if (m == true) "✗ " else "؟ ") + tr(s.fa, s.en), color = if (m == false) p.primary else p.text, fontSize = 15.sp)
                        if (s.hintFa != null && s.hintEn != null && m != false) Text(tr(s.hintFa, s.hintEn), color = p.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (allDone) finish() else { running = true; advance() } }) {
                Text(if (allDone) tr("تمام", "Done") else if (running) tr("ادامه", "Continue") else tr("اجازه بده", "Allow"), color = p.primary)
            }
        },
        dismissButton = { TextButton(onClick = { finish() }) { Text(tr("بعداً", "Later"), color = p.sub) } }
    )
}
