package ir.abtin.sms

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

object ScheduledSmsScheduler {
    private const val PREFS = "abtin_scheduled_sms"
    private const val KEY = "queue"
    private const val ACTION = "ir.abtin.sms.SEND_SCHEDULED_SMS"
    private fun array(c: Context) = runCatching { JSONArray(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]")) }.getOrDefault(JSONArray())
    private fun save(c: Context, a: JSONArray) { c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply() }
    private fun pi(c: Context, id: Int): PendingIntent = PendingIntent.getBroadcast(c, id, Intent(c, ScheduledSmsReceiver::class.java).setAction(ACTION).putExtra("id", id), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)

    @Synchronized fun add(c: Context, to: String, body: String, whenMs: Long): Int {
        val id = (System.currentTimeMillis() and 0x7fffffff).toInt().let { if (it == 0) 1 else it }
        val a = array(c)
        a.put(JSONObject().put("id", id).put("to", to).put("body", body).put("when", whenMs))
        save(c, a)
        val alarm = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pending = pi(c, id)
        if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, pending)
        else alarm.set(AlarmManager.RTC_WAKEUP, whenMs, pending)
        return id
    }
    @Synchronized fun list(c: Context): List<Map<String, Any>> {
        val a = array(c); val out = mutableListOf<Map<String, Any>>()
        for (i in 0 until a.length()) runCatching { a.getJSONObject(i) }.getOrNull()?.let { o ->
            out += mapOf("id" to o.optInt("id"), "to" to o.optString("to"), "body" to o.optString("body"), "when" to o.optLong("when"))
        }
        return out.sortedBy { it["when"] as Long }
    }
    @Synchronized fun remove(c: Context, id: Int): JSONObject? {
        val old = array(c); val next = JSONArray(); var found: JSONObject? = null
        for (i in 0 until old.length()) {
            val o = runCatching { old.getJSONObject(i) }.getOrNull() ?: continue
            if (o.optInt("id") == id) found = o else next.put(o)
        }
        save(c, next)
        return found
    }
    fun cancel(c: Context, id: Int) {
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, id))
        remove(c, id)
    }
    fun restore(c: Context) {
        val alarm = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        list(c).forEach { row ->
            val id = row["id"] as Int; val whenMs = row["when"] as Long
            val p = pi(c, id)
            if (whenMs <= System.currentTimeMillis()) alarm.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 1000L, p)
            else if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, whenMs, p)
            else alarm.set(AlarmManager.RTC_WAKEUP, whenMs, p)
        }
    }
    fun deliver(c: Context, id: Int) {
        val item = remove(c, id) ?: return
        runCatching { SmsRepo(c.applicationContext).send(item.optString("to"), item.optString("body")) }
    }
}

class ScheduledSmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val id = intent?.getIntExtra("id", 0) ?: return
        if (id != 0) ScheduledSmsScheduler.deliver(context, id)
    }
}

class ScheduledSmsBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED || intent?.action == "android.intent.action.MY_PACKAGE_REPLACED") ScheduledSmsScheduler.restore(context)
    }
}
