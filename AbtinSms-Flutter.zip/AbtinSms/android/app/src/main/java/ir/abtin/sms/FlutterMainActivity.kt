package ir.abtin.sms

import android.app.role.RoleManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channelName = "ir.abtin.sms/native"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(applicationContext)
        Prefs.useProfile(false)
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.READ_CONTACTS), 7822)
        }
    }
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName).setMethodCallHandler { call, result ->
            val repo = SmsRepo(applicationContext)
            try {
                when (call.method) {
                    "getContacts" -> result.success(repo.contacts().map { mapOf("name" to it.name, "phone" to it.number, "favorite" to it.starred) })
                    "sendSms" -> {
                        requireDefaultSms(result) ?: run {
                            val to = call.argument<String>("to")?.trim().orEmpty()
                            val body = call.argument<String>("body")?.trim().orEmpty()
                            require(to.isNotBlank() && body.isNotBlank()) { "گیرنده و متن پیام الزامی است" }
                            repo.send(to, body)
                            result.success(true)
                        }
                    }
                    "sendBulkSms" -> {
                        requireDefaultSms(result) ?: run {
                            val recipients = call.argument<List<String>>("recipients").orEmpty().map { it.trim() }.filter { it.isNotBlank() }.distinct()
                            val body = call.argument<String>("body")?.trim().orEmpty()
                            require(recipients.isNotEmpty() && body.isNotBlank()) { "مخاطب و متن پیام الزامی است" }
                            recipients.forEach { repo.send(it, body) }
                            result.success(recipients.size)
                        }
                    }
                    "scheduleSms" -> {
                        requireDefaultSms(result) ?: run {
                            val to = call.argument<String>("to")?.trim().orEmpty()
                            val body = call.argument<String>("body")?.trim().orEmpty()
                            val whenMs = call.argument<Number>("when")?.toLong() ?: 0L
                            require(to.isNotBlank() && body.isNotBlank() && whenMs > System.currentTimeMillis()) { "اطلاعات زمان‌بندی معتبر نیست" }
                            val id = ScheduledSmsScheduler.add(applicationContext, to, body, whenMs)
                            result.success(id)
                        }
                    }
                    "getScheduledSms" -> result.success(ScheduledSmsScheduler.list(applicationContext))
                    "cancelScheduledSms" -> {
                        val id = call.argument<Number>("id")?.toInt() ?: 0
                        ScheduledSmsScheduler.cancel(applicationContext, id)
                        result.success(true)
                    }
                    "requestDefaultSmsRole" -> {
                        if (Build.VERSION.SDK_INT >= 29) {
                            val rm = getSystemService(RoleManager::class.java)
                            if (rm.isRoleAvailable(RoleManager.ROLE_SMS)) startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_SMS), 7821)
                            else result.error("ROLE_UNAVAILABLE", "نقش برنامه پیامک در این دستگاه در دسترس نیست", null)
                        } else {
                            @Suppress("DEPRECATION")
                            startActivityForResult(Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName), 7821)
                        }
                        result.success(true)
                    }
                    "isDefaultSmsApp" -> result.success(Telephony.Sms.getDefaultSmsPackage(this) == packageName)
                    else -> result.notImplemented()
                }
            } catch (e: SecurityException) {
                result.error("PERMISSION_OR_ROLE", e.message ?: "برای ارسال باید این برنامه، برنامه پیش‌فرض پیامک باشد و مجوز SMS داشته باشد", null)
            } catch (e: Exception) {
                result.error("NATIVE_ERROR", e.message ?: "خطای سرویس Android", null)
            }
        }
    }

    private fun requireDefaultSms(result: MethodChannel.Result): Unit? {
        if (Telephony.Sms.getDefaultSmsPackage(this) != packageName) {
            result.error("DEFAULT_SMS_REQUIRED", "ابتدا آبتین را به‌عنوان برنامهٔ پیش‌فرض پیامک انتخاب کنید", null)
            return Unit
        }
        if (checkSelfPermission(android.Manifest.permission.SEND_SMS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            result.error("SMS_PERMISSION_REQUIRED", "مجوز ارسال پیامک در تنظیمات Android لازم است", null)
            return Unit
        }
        return null
    }
}
