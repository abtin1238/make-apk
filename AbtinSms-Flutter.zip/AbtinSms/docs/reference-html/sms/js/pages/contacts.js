(()=>{
const {Store,esc}=UI;
const ls=q=>Store.d.contacts.filter(c=>!q||c.name.includes(q)||c.tel.includes(q)).map(c=>`<div class="item" data-go="chat/${c.id}"><div class="av ${c.c}">${c.l}</div><div class="tx"><b>${esc(c.name)}</b><span>${c.tel}</span></div></div>`).join('')||'<div class="empty">مخاطبی یافت نشد</div>';
UI.Pages.contacts={title:'مخاطبین',
render(){return `<input class="inp" id="q" placeholder="جستجو..." style="margin-bottom:12px"><div id="ls">${ls('')}</div>`},
init(r){r.querySelector('#q').oninput=e=>r.querySelector('#ls').innerHTML=ls(e.target.value)}};
})();
