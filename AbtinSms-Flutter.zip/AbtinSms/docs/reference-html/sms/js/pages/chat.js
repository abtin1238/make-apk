(()=>{
const {Store,esc,icon}=UI;
const th=id=>(Store.d.threads[id]||[]).map(m=>`<div class="bub ${m.me?'me':'th'}">${esc(m.t)}</div>`).join('');
UI.Pages.chat={back:'inbox',raw:true,title:id=>{const c=Store.contact(id);return c?esc(c.name):'گفتگو'},
render(id){return `<div class="chat"><div class="thread" id="th">${th(id)}</div><div class="composer"><input class="inp" id="in" placeholder="پیام..."><button id="sd">${icon('send')}</button></div></div>`},
init(r,id){if(!r.querySelector('#th'))return;const t=r.querySelector('#th'),i=r.querySelector('#in');t.scrollTop=1e5;
 (Store.d.threads[id]||[]).forEach(m=>delete m.un);Store.save();
 const send=()=>{const v=i.value.trim();if(!v)return;Store.addSent(+id,v);t.innerHTML=th(id);i.value='';t.scrollTop=1e5};
 r.querySelector('#sd').onclick=send;i.onkeydown=e=>e.key==='Enter'&&send()}};
})();
