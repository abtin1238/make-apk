(()=>{
const {Store,toast}=UI,cols=['#2a9bff','#8a4dff','#19d3b0','#ff45f0'];
UI.Pages.settings={title:'تنظیمات',
render(){const d=Store.d;return `<div class="glass pad"><div class="set"><span>رنگ تم</span><div class="chips" style="margin:0">${cols.map(c=>`<button class="chip ${d.accent===c?'on':''}" data-c="${c}" style="background:${c}"></button>`).join('')}</div></div><div class="set"><span>اعلان پیام‌ها</span><button class="sw ${d.notif?'on':''}" id="nt"></button></div><div class="set"><span>برنامه پیش‌فرض پیامک</span><span style="color:var(--muted)">Abtin SMS</span></div></div>`},
init(r){r.querySelectorAll('.chip').forEach(b=>b.onclick=()=>{Store.setAccent(b.dataset.c);r.querySelectorAll('.chip').forEach(x=>x.classList.toggle('on',x===b))});
 const nt=r.querySelector('#nt');nt.onclick=()=>{Store.d.notif=!Store.d.notif;Store.save();nt.classList.toggle('on',Store.d.notif);toast(Store.d.notif?'اعلان‌ها روشن شد':'اعلان‌ها خاموش شد')}}};
})();
