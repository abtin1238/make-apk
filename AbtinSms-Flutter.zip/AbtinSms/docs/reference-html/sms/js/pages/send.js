(()=>{
const {Store,toast,go,fa,Pages}=UI;
Pages.send={title:'ارسال پیامک',
render(){return `<div class="glass pad"><label class="lb">گیرنده</label><input class="inp" id="to" placeholder="شماره یا نام مخاطب"><label class="lb">متن پیام</label><textarea class="inp" id="tx" rows="7" placeholder="پیام خود را بنویسید..."></textarea><div class="cnt" id="cnt">۰ کاراکتر · ۱ پیامک</div><button class="btn" id="ok">ارسال</button></div>`},
init(r){const tx=r.querySelector('#tx'),to=r.querySelector('#to'),cnt=r.querySelector('#cnt');
 tx.oninput=()=>{const n=tx.value.length;cnt.textContent=`${fa(n)} کاراکتر · ${fa(Math.max(1,Math.ceil(n/70)))} پیامک`};
 r.querySelector('#ok').onclick=()=>{if(!to.value.trim()||!tx.value.trim())return toast('گیرنده و متن را وارد کنید');
  const c=Store.d.contacts.find(c=>c.name===to.value.trim()||c.tel===to.value.trim());
  Store.addSent(c&&c.id,tx.value.trim(),to.value.trim());toast('پیامک ارسال شد');go('home')}}};
Pages.compose=Object.assign({},Pages.send,{title:'پیام جدید'});
})();
