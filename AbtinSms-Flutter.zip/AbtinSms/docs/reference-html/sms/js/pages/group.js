(()=>{
const {Store,toast,esc,go}=UI;
UI.Pages.group={title:'ارسال گروهی',
render(){const cs=Store.d.contacts.map(c=>`<label class="item"><div class="av ${c.c}">${c.l}</div><div class="tx"><b>${esc(c.name)}</b><span>${c.tel}</span></div><input type="checkbox" value="${c.id}"></label>`).join('');
 return `<div class="glass pad"><label class="lb">انتخاب مخاطبان</label><label class="item"><div class="tx"><b>انتخاب همه</b></div><input type="checkbox" id="all"></label>${cs}<label class="lb">متن پیام</label><textarea class="inp" id="tx" rows="4"></textarea><button class="btn" id="ok">ارسال گروهی</button></div>`},
init(r){const boxes=[...r.querySelectorAll('input[value]')];r.querySelector('#all').onchange=e=>boxes.forEach(b=>b.checked=e.target.checked);
 r.querySelector('#ok').onclick=()=>{const ids=boxes.filter(b=>b.checked).map(b=>+b.value),text=r.querySelector('#tx').value.trim();
  if(!ids.length||!text)return toast('مخاطب و متن را انتخاب کنید');ids.forEach(id=>Store.addSent(id,text));toast('پیامک گروهی ارسال شد');go('home')}}};
})();
