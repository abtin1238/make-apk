(()=>{
const {Store,esc}=UI;
UI.Pages.inbox={title:'پیام‌های دریافتی',
render(){return Store.d.order.map(id=>{const c=Store.contact(id),m=Store.last(id)||{};
 return `<div class="item" data-go="chat/${id}"><div class="av ${c.c}">${c.l}</div><div class="tx"><b>${esc(c.name)}</b><span>${esc(m.t||'')}</span></div><span class="mt">${m.ago||''}</span></div>`}).join('')}};
})();
