(()=>{
const {Store,fa}=UI;
UI.Pages.stats={title:'آمار',
render(){const d=Store.d,v=[12,30,22,40,18,35,28],days=['ش','ی','د','س','چ','پ','ج'],mx=Math.max(...v);
 return `<div class="kpi"><div class="glass"><b>${fa(d.recv)}</b><span>دریافتی</span></div><div class="glass"><b>${fa(d.sent)}</b><span>ارسالی</span></div></div><div class="glass pad"><div class="lb" style="margin:0">ارسال هفتگی</div><div class="bars">${v.map((n,i)=>`<div>${fa(n)}<i style="height:${n/mx*100}%"></i>${days[i]}</div>`).join('')}</div></div>`}};
})();
