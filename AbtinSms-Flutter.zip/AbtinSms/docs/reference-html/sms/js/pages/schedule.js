(()=>{
const {Store,toast,esc,fa}=UI;
const list=()=>Store.d.scheduled.map((s,i)=>`<div class="item"><div class="tx"><b>${esc(s.to)}</b><span>${esc(s.text)}</span></div><span class="mt">${fa(s.when.replace('T',' '))}</span><button class="x" data-del="${i}">×</button></div>`).join('')||'<div class="empty">پیامی زمان‌بندی نشده است</div>';
UI.Pages.schedule={title:'ارسال زمان‌بندی شده',
render(){return `<div class="glass pad"><label class="lb">گیرنده</label><input class="inp" id="to"><label class="lb">متن پیام</label><textarea class="inp" id="tx" rows="4"></textarea><label class="lb">زمان ارسال</label><input class="inp" id="dt" type="datetime-local" style="direction:ltr"><button class="btn" id="ok">زمان‌بندی</button></div><div style="height:14px"></div><div id="ls">${list()}</div>`},
init(r){const ls=r.querySelector('#ls'),bind=()=>ls.querySelectorAll('[data-del]').forEach(b=>b.onclick=()=>{Store.d.scheduled.splice(b.dataset.del,1);Store.save();ls.innerHTML=list();bind()});bind();
 r.querySelector('#ok').onclick=()=>{const to=r.querySelector('#to').value.trim(),text=r.querySelector('#tx').value.trim(),when=r.querySelector('#dt').value;
  if(!to||!text||!when)return toast('همه فیلدها را پر کنید');
  Store.d.scheduled.push({to,text,when});Store.save();ls.innerHTML=list();bind();toast('زمان‌بندی شد')}}};
})();
