(()=>{
const {icon,fa,esc,Store}=UI;
UI.Pages.home={render(){
 const d=Store.d;
 const rows=d.order.slice(0,4).map((id,i)=>{const c=Store.contact(id),m=Store.last(id)||{};
  return `<div class="row ${m.un?'un':''}" style="top:${52+i*60.5}px" data-go="chat/${id}"><div class="av ${c.c}">${c.l}</div><div class="nm fa">${esc(c.name)}</div><div class="pv fa">${esc(m.t||'')}</div><div class="tm">${m.ago||''}</div><i class="ud"></i></div>`}).join('');
 return `
<button class="avatar" data-go="settings">${icon('user')}<i class="dot"></i></button>
<div class="brand">Abtin <b>SMS</b></div><div class="tag fa">مدیریت و ارسال پیامک</div>
<div class="hero">
 <h2 class="fa">ارسال پیامک هوشمند</h2><p class="fa">سریع، آسان و مطمئن</p>
 <button class="btn1" data-go="send">${icon('plane')}<span class="fa">ارسال پیامک</span></button>
 <button class="arr" data-go="send">${icon('chev')}</button>
</div>
<div class="art"><div class="orbit o1"></div><div class="phone"><i></i></div><div class="bubble"><s></s><b></b><b></b><b></b></div><div class="orbit o2"></div></div>
<div class="rail">
 <button data-go="contacts">${icon('users')}</button><button data-go="history">${icon('clock')}</button><button data-go="stats">${icon('chart')}</button><button data-go="inbox">${icon('inbox')}</button><button data-go="settings">${icon('gear')}</button>
</div>
<button class="tile t-sch" data-go="schedule">${icon('cal','big')}<h3 class="fa" style="text-align:center">ارسال زمان‌بندی شده</h3><small class="fa" style="text-align:center">برنامه‌ریزی ارسال پیامک</small><span class="arr">${icon('chev')}</span></button>
<button class="tile t-grp" data-go="group">${icon('group','big')}<h3 class="fa" style="text-align:center">ارسال گروهی</h3><small class="fa" style="text-align:center">به چندین مخاطب</small><span class="arr">${icon('chev')}</span></button>
<div class="stats">
 <div class="col c1" data-go="inbox">${icon('inbox')}<b>${fa(d.recv)}</b><span class="fa" style="text-align:center">پیام‌های دریافتی</span></div>
 <hr>
 <div class="col c2" data-go="history">${icon('plane')}<b>${fa(d.sent)}</b><span class="fa" style="text-align:center">پیام‌های ارسالی</span></div>
</div>
<div class="msgs">
 <span class="pdot"></span><div class="ttl">آخرین پیام‌ها</div>
 <button class="all" data-go="inbox">${icon('chevL')}<span class="fa">مشاهده همه</span></button>
 ${rows}
</div>
<button class="fab" data-go="compose">${icon('pencil')}</button>
<div class="hind"></div>`}};
})();
