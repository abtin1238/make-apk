(()=>{
const {Store,esc,fa}=UI;
UI.Pages.history={title:'پیام‌های ارسالی',
render(){const l=Store.d.log;return l.map(m=>`<div class="item"><div class="tx"><b>${esc(m.to)}</b><span>${esc(m.text)}</span></div><span class="mt">${fa(new Date(m.ts).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'}))}</span></div>`).join('')||'<div class="empty">هنوز پیامی ارسال نکرده‌اید</div>'}};
})();
