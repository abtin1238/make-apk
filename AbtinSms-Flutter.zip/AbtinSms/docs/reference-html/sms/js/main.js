(()=>{
UI.Store.setAccent(UI.Store.d.accent);
addEventListener('resize',UI.fit);addEventListener('hashchange',UI.route);
UI.fit();UI.route();
})();
