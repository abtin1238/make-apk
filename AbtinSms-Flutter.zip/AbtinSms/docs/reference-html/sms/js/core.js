(()=>{
const S='<svg viewBox="0 0 24 24" fill="currentColor">',E='</svg>';
const st=p=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
const I={
user:S+'<circle cx="12" cy="8" r="4.2"/><path d="M3.8 21c0-4.2 3.6-6.8 8.2-6.8s8.2 2.6 8.2 6.8z"/>'+E,
plane:S+'<path d="M22 2.4 2.5 10c-.9.35-.85 1.6.1 1.9l5.7 1.8 1.9 5.8c.3.95 1.5 1.05 1.95.15l2.3-4.4 4.3 3.2c.7.5 1.7.1 1.9-.8L23.3 3.7c.2-.85-.5-1.6-1.3-1.3zM9.9 12.9l9-6.6-7 8.2-.4 3.4z"/>'+E,
chev:st('<path d="M9 5l7 7-7 7"/>'),
chevL:st('<path d="M15 5l-7 7 7 7"/>'),
users:S+'<circle cx="9" cy="8" r="3.7"/><circle cx="17.3" cy="9" r="2.9"/><path d="M2 20c0-3.7 3-6.1 7-6.1s7 2.4 7 6.1zM16.6 14.2c3 .2 5.4 1.9 5.4 5.4h-4.1c0-2-.5-3.8-1.3-5.4z"/>'+E,
clock:st('<circle cx="12" cy="12" r="9.5"/><path d="M12 6.5V12l3.8 2.3"/>'),
chart:S+'<rect x="3" y="13" width="4.6" height="8" rx="1.4"/><rect x="9.7" y="8" width="4.6" height="13" rx="1.4"/><rect x="16.4" y="3" width="4.6" height="18" rx="1.4"/>'+E,
inbox:S+'<path d="M10.8 2.5h2.4v7.6l2.6-2.6 1.7 1.7L12 14.5 6.5 9.2l1.7-1.7 2.6 2.6zM2.5 14h5.7l1.6 2.6h4.4l1.6-2.6h5.7v6a1.5 1.5 0 0 1-1.5 1.5h-16A1.5 1.5 0 0 1 2.5 20z"/>'+E,
gear:S+'<path d="M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58a.49.49 0 0 0 .12-.61l-1.92-3.32a.49.49 0 0 0-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54a.48.48 0 0 0-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58a.49.49 0 0 0-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z"/>'+E,
pencil:S+'<path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75zM20.71 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75z"/>'+E,
cal:`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="4.5" width="16" height="15.5" rx="3.2" fill="currentColor" stroke="none"/><path d="M7 2.5v4M14 2.5v4" stroke="currentColor"/><path d="M2.5 9.5h16" stroke="#3b2ea8"/><circle cx="17.2" cy="17.2" r="5" fill="#3b2ea8" stroke="currentColor"/><path d="M17.2 14.4v3l1.8 1.1" stroke="currentColor"/></svg>`,
group:S+'<circle cx="12" cy="7.2" r="3.5"/><circle cx="4.6" cy="10" r="2.6"/><circle cx="19.4" cy="10" r="2.6"/><path d="M5.2 20.5c0-3.9 3-6.2 6.8-6.2s6.8 2.3 6.8 6.2zM.8 17.5c0-2.6 1.8-4.3 4.1-4.3.9 0 1.7.2 2.3.6-1.2 1-2 2.3-2.2 3.7zM23.2 17.5c0-2.6-1.8-4.3-4.1-4.3-.9 0-1.7.2-2.3.6 1.2 1 2 2.3 2.2 3.7z"/>'+E,
send:S+'<path d="M2.01 21 23 12 2.01 3 2 10l15 2-15 2z"/>'+E
};
const fa=n=>String(n).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const icon=(n,c='')=>`<span class="ic ${c}">${I[n]}</span>`;

const def={sent:287,recv:123,accent:'#2a9bff',notif:true,
 contacts:[
 {id:1,name:'علی رضایی',l:'A',c:'g',tel:'09121110001'},
 {id:2,name:'مهدی کریمی',l:'M',c:'p',tel:'09121110002'},
 {id:3,name:'سارا محمدی',l:'S',c:'b',tel:'09121110003'},
 {id:4,name:'حسین احمدی',l:'H',c:'m',tel:'09121110004'},
 {id:5,name:'نرگس صادقی',l:'N',c:'g',tel:'09121110005'},
 {id:6,name:'رضا موسوی',l:'R',c:'b',tel:'09121110006'}],
 threads:{
 1:[{me:0,t:'سلام، وقت بخیر...',ago:'۲ دقیقه پیش',un:1}],
 2:[{me:0,t:'ممنون از راهنمایی شما...',ago:'۵ دقیقه پیش'}],
 3:[{me:0,t:'در خدمت شما هستیم...',ago:'۱۰ دقیقه پیش'}],
 4:[{me:0,t:'لطفا اطلاعات مورد نیاز را ارسال کنید.',ago:'۱۵ دقیقه پیش'}]},
 order:[1,2,3,4],log:[],scheduled:[]};
let D;try{D=Object.assign({},def,JSON.parse(localStorage.getItem('abtin_sms')||'{}'))}catch(e){D=def}
const save=()=>{try{localStorage.setItem('abtin_sms',JSON.stringify(D))}catch(e){}};
const Store={
 get d(){return D},save,
 contact:id=>D.contacts.find(c=>c.id==id),
 last(id){const t=D.threads[id]||[];return t[t.length-1]},
 addSent(id,text,to){D.sent++;D.log.unshift({to:to||(Store.contact(id)||{}).name||'',text,ts:Date.now()});
  if(id){(D.threads[id]=D.threads[id]||[]).push({me:1,t:text,ago:'همین الان'});D.order=[id,...D.order.filter(x=>x!=id)]}save()},
 setAccent(c){D.accent=c;document.documentElement.style.setProperty('--accent',c);save()}
};
function toast(m){const t=document.getElementById('toast');t.textContent=m;t.classList.add('show');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('show'),1800)}
const Pages={};
function go(h){location.hash='#/'+h}
function fit(){const w=innerWidth,h=innerHeight;let s,H=922;
 if(w<=600){s=w/427;H=Math.max(922,h/s)}else s=Math.min(h/922,w/427,1.6);
 const el=document.getElementById('screen');el.style.setProperty('--s',s);el.style.setProperty('--H',H+'px')}
function route(){
 const parts=(location.hash.replace(/^#\/?/,'')||'home').split('/'),name=Pages[parts[0]]?parts[0]:'home',arg=parts[1],p=Pages[name];
 const app=document.getElementById('app');
 if(name==='home'){app.innerHTML=`<div class="home enter">${p.render()}</div>`}
 else{app.innerHTML=`<div class="page enter"><header class="ph"><button class="back glass" data-go="${p.back||'home'}">${icon('chevL')}</button><h1 class="fa" style="text-align:center">${typeof p.title==='function'?p.title(arg):p.title}</h1><span class="sp"></span></header>${p.raw?p.render(arg):`<main class="pc">${p.render(arg)}</main>`}</div>`}
 p.init&&p.init(app,arg);
}
document.addEventListener('click',e=>{const t=e.target.closest('[data-go]');if(t)go(t.dataset.go)});
window.UI={I,icon,fa,esc,toast,Pages,Store,go,fit,route};
})();
