(() => {
  'use strict';

  const $  = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const fa = n => String(n).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[d]);

  /* ---------- Data ---------- */
  const contacts = [
    { name: 'علی رضایی',     phone: '0912 123 4567', letter: 'A', color: 'c1', fav: true  },
    { name: 'مهدی کریمی',    phone: '0913 987 6543', letter: 'M', color: 'c2', fav: false },
    { name: 'سارا محمدی',    phone: '0919 111 2233', letter: 'S', color: 'c3', fav: true  },
    { name: 'حسین احمدی',    phone: '0918 222 3344', letter: 'H', color: 'c4', fav: false },
    { name: 'شرکت پارسیان',  phone: '021 8888 9999', company: true, color: 'c1', fav: false }
  ];
  const history = [
    { who: contacts[0], type: 'in',   time: 'امروز ۱۰:۲۴' },
    { who: contacts[2], type: 'out',  time: 'امروز ۰۹:۱۰' },
    { who: contacts[1], type: 'miss', time: 'دیروز ۲۱:۳۵' },
    { who: contacts[4], type: 'out',  time: 'دیروز ۱۴:۰۲' },
    { who: contacts[3], type: 'in',   time: 'سه‌شنبه ۱۷:۴۸' }
  ];

  /* ---------- Helpers ---------- */
  let toastTimer;
  function toast(msg) {
    const t = $('#toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 1800);
  }

  const avatar = c => `<div class="avatar ${c.color}">${
    c.company ? '<svg><use href="#i-building"/></svg>' : c.letter}</div>`;

  /* ---------- Contacts list ---------- */
  const state = { query: '', favs: false };

  function renderContacts() {
    const q = state.query.trim().toLowerCase().replace(/\s/g, '');
    const list = contacts.filter(c =>
      (!state.favs || c.fav) &&
      (!q || c.name.includes(state.query.trim()) || c.phone.replace(/\s/g, '').includes(q)));

    $('#listTitle').textContent = state.favs ? 'علاقه‌مندی‌ها' : 'همه مخاطبین';
    $('#listCount').textContent = `(${fa(state.favs || q ? list.length : 248)})`;

    $('#contacts').innerHTML = list.length ? list.map((c, i) => `
      <li class="contact" data-phone="${c.phone}" data-name="${c.name}">
        ${avatar(c)}
        <div class="info"><b>${c.name}</b><span>${c.phone}</span></div>
        <button class="act call-b" data-act="call" aria-label="تماس با ${c.name}"><svg><use href="#i-phone"/></svg></button>
        <button class="act msg-b"  data-act="msg"  aria-label="پیام به ${c.name}"><svg><use href="#i-chat"/></svg></button>
        <span class="more" aria-hidden="true"><i></i><i></i><i></i></span>
      </li>`).join('') : '<li class="empty">مخاطبی پیدا نشد</li>';
  }

  $('#contacts').addEventListener('click', e => {
    const btn = e.target.closest('[data-act]');
    if (!btn) return;
    const li = btn.closest('.contact');
    toast(btn.dataset.act === 'call' ? `در حال تماس با ${li.dataset.name}…` : `پیام به ${li.dataset.name}`);
  });

  $('#search').addEventListener('input', e => { state.query = e.target.value; renderContacts(); });
  $('#filterBtn').addEventListener('click', e => {
    state.favs = !state.favs;
    e.currentTarget.classList.toggle('on', state.favs);
    renderContacts();
  });

  /* ---------- History ---------- */
  const icon = { in: 'i-in', out: 'i-out', miss: 'i-in' };
  const label = { in: 'ورودی', out: 'خروجی', miss: 'بی‌پاسخ' };

  $('#history').innerHTML = history.map((h, i) => `
    <li class="contact ${h.type === 'miss' ? 'miss' : ''}">
      ${avatar(h.who)}
      <div class="info"><b>${h.who.name}</b><span class="badge">${label[h.type]} · ${h.time}</span></div>
      <button class="act call-b" aria-label="تماس مجدد" data-name="${h.who.name}"><svg><use href="#${icon[h.type]}"/></svg></button>
    </li>`).join('');
  $('#history').addEventListener('click', e => {
    const b = e.target.closest('[data-name]');
    if (b) toast(`در حال تماس با ${b.dataset.name}…`);
  });

  /* ---------- Recorded calls ---------- */
  const records = [
    { who: contacts[0], date: 'امروز ۱۰:۲۴',  sec: 154 },
    { who: contacts[2], date: 'امروز ۰۹:۱۰',  sec: 47  },
    { who: contacts[4], date: 'دیروز ۱۴:۰۲',  sec: 312 },
    { who: contacts[1], date: 'دوشنبه ۱۱:۳۰', sec: 88  },
    { who: contacts[3], date: 'یکشنبه ۱۸:۱۵', sec: 205 }
  ];
  const mmss = s => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  $('#recCount').textContent = `(${fa(records.length)})`;
  $('#records').innerHTML = records.map((r, i) => `
    <li class="contact rec" data-i="${i}">
      ${avatar(r.who)}
      <div class="info"><b>${r.who.name}</b><span class="badge">${r.date}</span></div>
      <span class="dur">${mmss(r.sec)}</span>
      <button class="play" aria-label="پخش" ><svg><use href="#i-play"/></svg></button>
      <div class="bar"><i></i></div>
    </li>`).join('');

  let player = null;
  function stopPlayer() {
    if (!player) return;
    clearInterval(player.timer);
    player.li.classList.remove('playing');
    $('use', player.li.querySelector('.play')).setAttribute('href', '#i-play');
    $('.dur', player.li).textContent = mmss(records[player.li.dataset.i].sec);
    $('.bar i', player.li).style.width = '0';
    player = null;
  }
  $('#records').addEventListener('click', e => {
    const btn = e.target.closest('.play');
    if (!btn) return;
    const li = btn.closest('.rec');
    if (player && player.li === li) { stopPlayer(); return; }
    stopPlayer();
    const total = records[li.dataset.i].sec;
    let t = 0;
    li.classList.add('playing');
    $('use', btn).setAttribute('href', '#i-pause');
    player = { li, timer: setInterval(() => {
      t++;
      $('.dur', li).textContent = mmss(t);
      $('.bar i', li).style.width = (t / total * 100) + '%';
      if (t >= total) stopPlayer();
    }, 1000) };
  });

  /* ---------- Dialer ---------- */
  const keyDefs = [['1',''],['2','ABC'],['3','DEF'],['4','GHI'],['5','JKL'],['6','MNO'],
                   ['7','PQRS'],['8','TUV'],['9','WXYZ'],['*',''],['0','+'],['#','']];
  $('#keys').innerHTML = keyDefs.map(([k, s]) =>
    `<button class="key" data-k="${k}">${k}${s ? `<small>${s}</small>` : ''}</button>`).join('');

  let dial = '';
  const out = $('#dialOut');
  const showDial = () => { out.innerHTML = dial || '&nbsp;'; };
  $('#keys').addEventListener('click', e => {
    const k = e.target.closest('[data-k]');
    if (k && dial.length < 15) { dial += k.dataset.k; showDial(); }
  });
  $('#dialDel').addEventListener('click', () => { dial = dial.slice(0, -1); showDial(); });
  $('#dialCall').addEventListener('click', () => toast(dial ? `در حال تماس با ${dial}…` : 'شماره را وارد کنید'));

  /* ---------- Tabs (bottom nav) ---------- */
  const tabs  = $$('.nav-item');
  const views = { contacts: $('#view-contacts'), history: $('#view-history'), records: $('#view-records'), dialer: $('#view-dialer') };
  const fab   = $('#fab');

  // The bar is really cut out under the active circle (CSS mask driven by --cx)
  const nav = $('#nav');
  function placeHole() {
    const act = [...tabs, fab].find(el => el.classList.contains('active'));
    if (!act) return;
    const a = act.getBoundingClientRect(), n = nav.getBoundingClientRect();
    nav.style.setProperty('--cx', (a.left + a.width / 2 - n.left) + 'px');
  }

  // Exactly one active item at a time: a nav tab, or the dialer button (never both).
  function go(name) {
    if (!views[name]) return;
    if (name !== 'records') stopPlayer();
    tabs.forEach(t => {
      const on = t.dataset.tab === name;
      t.classList.toggle('active', on);
      on ? t.setAttribute('aria-current', 'page') : t.removeAttribute('aria-current');
    });
    Object.entries(views).forEach(([k, v]) => v.classList.toggle('active', k === name));
    fab.classList.toggle('active', name === 'dialer');
    name === 'dialer' ? fab.setAttribute('aria-current', 'page') : fab.removeAttribute('aria-current');
    placeHole();
    window.scrollTo(0, 0);
  }

  tabs.forEach(t => t.addEventListener('click', () => go(t.dataset.tab)));
  fab.addEventListener('click', () => go('dialer'));
  $$('[data-go]').forEach(b => b.addEventListener('click', () => go(b.dataset.go)));

  /* ---------- Side rail ---------- */
  $$('.rail-btn').forEach(b => b.addEventListener('click', () => {
    const r = b.dataset.rail;
    if (r === 'settings') { toast('تنظیمات به‌زودی'); return; }
    if (r === 'favs') { go('contacts'); state.favs = true; $('#filterBtn').classList.add('on'); renderContacts(); }
    else if (r === 'contacts') { go('contacts'); state.favs = false; $('#filterBtn').classList.remove('on'); renderContacts(); }
    else go(r);
  }));

  /* ---------- Tiles ---------- */
  $('[data-tile="favs"]').addEventListener('click', () => {
    state.favs = true; $('#filterBtn').classList.add('on'); renderContacts();
    $('#listTitle').scrollIntoView({ behavior: 'smooth', block: 'center' });
  });
  $('[data-tile="groups"]').addEventListener('click', () => toast('مدیریت گروه‌ها به‌زودی'));

  renderContacts();
  placeHole();
  requestAnimationFrame(() => requestAnimationFrame(() => nav.classList.add('ready')));
  window.addEventListener('resize', placeHole);
  if (document.fonts) document.fonts.ready.then(placeHole);
})();
