import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_sms/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const channel = MethodChannel('ir.abtin.sms/native');

  setUp(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
      switch (call.method) {
        case 'getContacts':
        case 'getScheduledSms':
          return <dynamic>[];
        case 'isDefaultSmsApp':
          return false;
        default:
          return true;
      }
    });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null);
  });

  testWidgets('home renders main actions', (tester) async {
    await tester.pumpWidget(const AbtinApp());
    await tester.pumpAndSettle();
    await tester.pump(const Duration(seconds: 1));
    await tester.pumpAndSettle();
    expect(find.text('Abtin SMS'), findsOneWidget);
    expect(find.text('ارسال گروهی'), findsOneWidget);
    expect(find.text('پیام جدید'), findsOneWidget);
  });

  testWidgets('bottom navigation opens scheduled messages', (tester) async {
    await tester.pumpWidget(const AbtinApp());
    await tester.pumpAndSettle();
    await tester.pump(const Duration(seconds: 1));
    await tester.pumpAndSettle();
    await tester.tap(find.byTooltip('زمان‌بندی'));
    await tester.pumpAndSettle();
    expect(find.text('ارسال زمان‌بندی‌شده'), findsOneWidget);
    expect(find.text('پیامی زمان‌بندی نشده است'), findsOneWidget);
  });
}
