import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

class Native {
  static const _sys = MethodChannel('abtin/sys');
  static const _arc = MethodChannel('abtin/archive');
  static const _thumb = MethodChannel('abtin/thumb');

  /// true while the activity is in Picture-in-Picture mode.
  static final ValueNotifier<bool> inPip = ValueNotifier(false);

  /// Path of a file another app asked us to open ("Open with"); consumers reset it to null.
  static final ValueNotifier<String?> incoming = ValueNotifier(null);

  /// Bumped when a SD card / USB drive is mounted or removed.
  static final ValueNotifier<int> volumesChanged = ValueNotifier(0);

  /// Mounted non-primary volumes: [{path, uuid, label, removable}].
  static Future<List<Map<String, dynamic>>> storageVolumes() async {
    try {
      final r = await _sys.invokeMethod<List<dynamic>>('storageVolumes');
      return (r ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {
      return const [];
    }
  }

  /// Battery temperature in °C (null when the device doesn't report it).
  static Future<double?> batteryTemp() async {
    try {
      return await _sys.invokeMethod<double>('batteryTemp');
    } catch (_) {
      return null;
    }
  }

  static int _jobId = 0;
  static final Map<int, void Function(double)> _progress = {};

  /// Last PackageInstaller result: {status, msg}. status 0 = success.
  static final installResult = ValueNotifier<Map<String, dynamic>?>(null);

  static void init() {
    _sys.setMethodCallHandler((c) async {
      if (c.method == 'pipChanged') inPip.value = c.arguments == true;
      if (c.method == 'volumesChanged') volumesChanged.value++;
      if (c.method == 'openFile') incoming.value = c.arguments as String?;
      if (c.method == 'installResult') installResult.value = Map<String, dynamic>.from(c.arguments as Map);
      return null;
    });
    _sys.invokeMethod<String>('initialFile').then((p) {
      if (p != null) incoming.value = p;
    }).catchError((_) {});
    // progress callbacks of native archive jobs: {id, done, total}
    _arc.setMethodCallHandler((c) async {
      if (c.method == 'progress') {
        final a = Map<String, dynamic>.from(c.arguments as Map);
        final total = (a['total'] as num).toInt();
        if (total > 0) _progress[(a['id'] as num).toInt()]?.call((a['done'] as num).toInt() / total);
      }
      return null;
    });
  }

  static Future<T> _withProgress<T>(void Function(double)? onProgress, Future<T> Function(int id) call) async {
    final id = ++_jobId;
    if (onProgress != null) _progress[id] = onProgress;
    try {
      return await call(id);
    } finally {
      _progress.remove(id);
    }
  }

  /// Opens [url] in the user's browser. false when no app could handle it.
  static Future<bool> openUrl(String url) async {
    try {
      return (await _sys.invokeMethod<bool>('openUrl', {'url': url})) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Opens a folder in the device's system file manager (no SAF selection flow).
  static Future<bool> openSystemFolder(String path) async {
    try {
      return (await _sys.invokeMethod<bool>('openSystemFolder', {'path': path})) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// "Open with": shows the system app chooser for [path] (always asks, even when a default app exists).
  static Future<bool> openWith(String path, {String title = ''}) async {
    try {
      return (await _sys.invokeMethod<bool>('openWith', {'path': path, 'title': title})) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// returns [total, free] bytes
  static Future<List<int>> storage(String path) async {
    try {
      final r = await _sys.invokeMethod<List>('storage', {'path': path});
      return [(r![0] as num).toInt(), (r[1] as num).toInt()];
    } catch (_) {
      return [0, 0];
    }
  }

  static Future<double> brightness() async {
    try {
      return ((await _sys.invokeMethod<num>('brightness')) ?? .5).toDouble();
    } catch (_) {
      return .5;
    }
  }

  /// 0..1, or -1 to give control back to the system.
  static Future<void> setBrightness(double v) async {
    try { await _sys.invokeMethod('setBrightness', {'v': v}); } catch (_) {}
  }

  /// System media volume 0..1 (what the volume buttons change).
  static Future<double> sysVolume() async {
    try {
      return ((await _sys.invokeMethod<num>('sysVolume')) ?? .5).toDouble();
    } catch (_) {
      return .5;
    }
  }

  static Future<void> setSysVolume(double v) async {
    try { await _sys.invokeMethod('setSysVolume', {'v': v}); } catch (_) {}
  }

  static Future<void> keepOn(bool on) async {
    try { await _sys.invokeMethod('keepOn', {'on': on}); } catch (_) {}
  }

  static (int, int) _ratio(double r) {
    final c = r.clamp(0.45, 2.3).toDouble();
    return ((c * 100).round(), 100);
  }

  static Future<bool> pip(double aspect) async {
    try {
      final r = _ratio(aspect);
      return (await _sys.invokeMethod<bool>('pip', {'w': r.$1, 'h': r.$2})) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> pipAuto(bool on, [double aspect = 16 / 9]) async {
    try {
      final r = _ratio(aspect);
      await _sys.invokeMethod('pipAuto', {'on': on, 'w': r.$1, 'h': r.$2});
    } catch (_) {}
  }

  static Future<void> scan(String path) async {
    try { await _sys.invokeMethod('scan', {'path': path}); } catch (_) {}
  }

  static Future<void> scanMany(List<String> paths) async {
    try { await _sys.invokeMethod('scanMany', {'paths': paths}); } catch (_) {}
  }

  /// PNG bytes of the icon of an (uninstalled) APK file, or null.
  static Future<Uint8List?> apkIcon(String path) async {
    try {
      return await _sys.invokeMethod<Uint8List>('apkIcon', {'path': path});
    } catch (_) {
      return null;
    }
  }

  /// Square JPEG/PNG thumbnail (about [px] pixels) of an image, made natively with a disk cache; null when it can not be decoded.
  static Future<Uint8List?> imageThumb(String path, int px) async {
    try {
      return await _thumb.invokeMethod<Uint8List>('image', {'path': path, 'px': px});
    } catch (_) {
      return null;
    }
  }

  static Future<Map<String, dynamic>?> apkInfo(String path) async {
    final r = await _sys.invokeMethod<Map>('apkInfo', {'path': path});
    return r?.map((k, v) => MapEntry('$k', v));
  }

  /// This app's own {versionName, versionCode, lastUpdate (ms since epoch)}.
  static Future<Map<String, dynamic>?> selfInfo() async {
    try {
      final r = await _sys.invokeMethod<Map>('selfInfo');
      return r == null ? null : Map<String, dynamic>.from(r);
    } catch (_) {
      return null;
    }
  }

  static Future<bool> canInstall() async {
    try { return (await _sys.invokeMethod<bool>('canInstall')) ?? true; } catch (_) { return true; }
  }

  static Future<void> installSettings() async {
    try { await _sys.invokeMethod('installSettings'); } catch (_) {}
  }

  static Future<void> uninstall(String pkg) async {
    try { await _sys.invokeMethod('uninstall', {'pkg': pkg}); } catch (_) {}
  }

  /// Installs base + split APKs in one PackageInstaller session; returns an error text or null.
  static Future<String?> installSplits(List<String> paths) async {
    try { return await _sys.invokeMethod<String>('installSplits', {'paths': paths}); } catch (e) { return '$e'; }
  }

  /// Installed apps: {pkg,label,version,code,system,size,updated}.
  static Future<List<Map<String, dynamic>>> apps() async {
    final r = await _sys.invokeMethod<List>('apps');
    return [for (final e in r ?? const []) Map<String, dynamic>.from(e as Map)];
  }

  static Future<Uint8List?> appIcon(String pkg) async {
    try { return await _sys.invokeMethod<Uint8List>('appIcon', {'pkg': pkg}); } catch (_) { return null; }
  }

  /// Copies the app's APK (or a folder with base + split APKs) into [dir]; returns the path or null.
  static Future<String?> backupApp(String pkg, String dir) async {
    try { return await _sys.invokeMethod<String>('backupApp', {'pkg': pkg, 'dir': dir}); } catch (_) { return null; }
  }

  /// Entries of a 7z / rar / zip: {name, size, dir, enc}. Folder names end with '/'.
  /// Errors: PlatformException codes RAR5 (unsupported RAR 5) and PASSWORD.
  static Future<List<Map<String, dynamic>>> archList(String src, String? pw) async {
    final r = await _arc.invokeMethod<List>('list', {'src': src, 'password': pw});
    return [for (final e in r ?? const []) Map<String, dynamic>.from(e as Map)];
  }

  /// Extracts a 7z / rar / zip (kind is sniffed natively). [only]: entry names, folders end with '/'.
  static Future<void> archExtract(String src, String dst, String? pw, {List<String>? only, void Function(double)? onProgress}) =>
      _withProgress(onProgress, (id) => _arc.invokeMethod('extract', {'src': src, 'dst': dst, 'password': pw, 'only': only, 'id': id}));

  /// Creates a zip (AES-256 with [pw], optional split into [volumeBytes] volumes .z01 …), tar.gz or 7z natively
  /// (streaming, so big folders are fine). [format] is 'zip', 'targz' or '7z'.
  static Future<void> compress(List<String> paths, String dst, String format, String? pw,
          {int volumeBytes = 0, void Function(double)? onProgress}) =>
      _withProgress(onProgress, (id) => _arc.invokeMethod('compress', {'paths': paths, 'dst': dst, 'format': format, 'password': pw, 'volume': volumeBytes, 'id': id}));
}
