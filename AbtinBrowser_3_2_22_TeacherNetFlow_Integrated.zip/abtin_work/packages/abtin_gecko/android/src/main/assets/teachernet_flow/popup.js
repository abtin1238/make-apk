document.getElementById('open').addEventListener('click', () => {
  browser.tabs.create({ url: 'https://flow.google.com/' });
});
