(() => {
  'use strict';

  const DIAGNOSTIC_ATTRIBUTE = 'data-flow-local-diagnostic';
  const SPEC_MESSAGE = 'cfc-flow-spec';
  const DEFAULT_SPEC = {
    v: 1,
    origin: 'https://flow.google.com',
    path: '/_/AiSandboxAngularFrontend/data/batchexecute',
    rpcids: 'cPZSdc',
    tag: 'wrb.fr',
    flagIndex: 30,
    minLength: 32
  };

  let spec = DEFAULT_SPEC;
  const nativeFetch = window.fetch.bind(window);
  const patchedResponses = new WeakMap();
  const nativeResponseText = Response.prototype.text;
  const nativeResponseJson = Response.prototype.json;
  const nativeResponseArrayBuffer = Response.prototype.arrayBuffer;
  const nativeResponseBlob = Response.prototype.blob;
  const nativeResponseClone = Response.prototype.clone;

  // Keep the exact native Response returned by Google. The Flow transport now
  // reads response.body as a stream, so the matching response receives a
  // patched native body while its URL, status, type and headers stay intact.
  function decorateResponse(response, body) {
    const contentType = response.headers.get('content-type') || 'text/plain;charset=UTF-8';
    const patchedResponse = new Response(body, {
      status: 200,
      headers: { 'content-type': contentType }
    });
    const record = { body, patchedResponse };
    patchedResponses.set(response, record);

    Object.defineProperties(response, {
      body: {
        configurable: true,
        get() {
          return patchedResponses.get(this).patchedResponse.body;
        }
      },
      bodyUsed: {
        configurable: true,
        get() {
          return patchedResponses.get(this).patchedResponse.bodyUsed;
        }
      },
      text: {
        configurable: true,
        value: function teacherNetResponseText() {
          return nativeResponseText.call(patchedResponses.get(this).patchedResponse);
        }
      },
      json: {
        configurable: true,
        value: function teacherNetResponseJson() {
          return nativeResponseJson.call(patchedResponses.get(this).patchedResponse);
        }
      },
      arrayBuffer: {
        configurable: true,
        value: function teacherNetResponseArrayBuffer() {
          return nativeResponseArrayBuffer.call(patchedResponses.get(this).patchedResponse);
        }
      },
      blob: {
        configurable: true,
        value: function teacherNetResponseBlob() {
          return nativeResponseBlob.call(patchedResponses.get(this).patchedResponse);
        }
      },
      clone: {
        configurable: true,
        value: function teacherNetResponseClone() {
          const current = patchedResponses.get(this);
          if (current.patchedResponse.bodyUsed) {
            throw new TypeError('Body has already been consumed.');
          }
          const cloned = nativeResponseClone.call(this);
          return decorateResponse(cloned, current.body);
        }
      }
    });

    return response;
  }

  function readDiagnostic() {
    try {
      return JSON.parse(document.documentElement.getAttribute(DIAGNOSTIC_ATTRIBUTE) || '{}');
    } catch {
      return {};
    }
  }

  function writeDiagnostic(state, details = {}) {
    const previous = readDiagnostic();
    const next = {
      ...previous,
      ...details,
      state,
      applied: Number(details.applied ?? previous.applied ?? 0)
    };
    document.documentElement.setAttribute(DIAGNOSTIC_ATTRIBUTE, JSON.stringify(next));
  }

  function isValidSpec(candidate) {
    return Boolean(
      candidate &&
      typeof candidate.origin === 'string' &&
      typeof candidate.path === 'string' &&
      typeof candidate.rpcids === 'string' &&
      typeof candidate.tag === 'string' &&
      Number.isInteger(candidate.flagIndex) &&
      Number.isInteger(candidate.minLength)
    );
  }

  function resolveRequestUrl(input) {
    if (typeof input === 'string' || input instanceof URL) {
      return new URL(String(input), location.href);
    }
    if (input && typeof input.url === 'string') {
      return new URL(input.url, location.href);
    }
    return null;
  }

  function isTargetRequest(input) {
    let url;
    try {
      url = resolveRequestUrl(input);
    } catch {
      return false;
    }

    if (!url || url.origin !== spec.origin) return false;

    const isBatchEndpoint =
      url.pathname === spec.path ||
      url.pathname.endsWith('/data/batchexecute');
    if (!isBatchEndpoint) return false;

    const rpcids = url.searchParams.get('rpcids') || '';
    return rpcids.split(',').includes(spec.rpcids);
  }

  function patchBatchResponse(body) {
    const lines = body.split('\n');
    let changed = false;
    let before = null;

    for (let index = 0; index < lines.length; index += 1) {
      const trimmed = lines[index].trimStart();
      if (!trimmed.startsWith('[[')) continue;

      let batch;
      try {
        batch = JSON.parse(lines[index]);
      } catch {
        continue;
      }
      if (!Array.isArray(batch)) continue;

      let lineChanged = false;
      for (const entry of batch) {
        if (!Array.isArray(entry)) continue;
        if (entry[0] !== spec.tag || entry[1] !== spec.rpcids || typeof entry[2] !== 'string') continue;

        let payload;
        try {
          payload = JSON.parse(entry[2]);
        } catch {
          continue;
        }

        if (!Array.isArray(payload) || payload.length < spec.minLength) continue;
        const current = payload[spec.flagIndex];
        if (current !== true && current !== false && current !== null) continue;

        before = current;
        if (current !== true) {
          payload[spec.flagIndex] = true;
          entry[2] = JSON.stringify(payload);
          lineChanged = true;
          changed = true;
        }
      }

      if (lineChanged) {
        const originalLine = lines[index].replace(/\r$/, '');
        const updatedLine = JSON.stringify(batch);

        if (index > 0 && /^\d+$/.test(lines[index - 1].trim())) {
          const declaredLength = Number(lines[index - 1]);
          const utf8Length = value => new TextEncoder().encode(value).byteLength;
          const lengthMetric = [utf8Length, value => value.length].find(metric => {
            const framingOffset = declaredLength - metric(originalLine);
            return framingOffset >= 0 && framingOffset <= 2;
          });

          if (!lengthMetric) {
            throw new Error('Unexpected batch framing');
          }

          // Google's framing length can include one or two delimiter bytes.
          // Preserve that offset and only add the exact payload-length delta.
          lines[index - 1] = String(
            declaredLength + lengthMetric(updatedLine) - lengthMetric(originalLine)
          );
        }

        lines[index] = updatedLine;
      }
    }

    return { body: changed ? lines.join('\n') : body, changed, before };
  }

  window.addEventListener('message', event => {
    if (event.source !== window || event.data?.type !== SPEC_MESSAGE) return;
    if (!isValidSpec(event.data.spec)) return;
    spec = event.data.spec;
  });

  window.fetch = async function teacherNetFlowFetch(input, init) {
    const targeted = isTargetRequest(input);
    const response = await nativeFetch(input, init);
    if (!targeted) return response;

    writeDiagnostic('fetch-intercepted');

    try {
      const originalBody = await response.clone().text();
      const patched = patchBatchResponse(originalBody);
      if (!patched.changed) {
        writeDiagnostic('schema mismatch — fetch');
        return response;
      }

      const diagnostic = readDiagnostic();
      writeDiagnostic('applied-fetch', {
        applied: Number(diagnostic.applied || 0) + 1,
        before: patched.before,
        transport: 'fetch'
      });
      return decorateResponse(response, patched.body);
    } catch (error) {
      writeDiagnostic('fetch read failed', { error: String(error?.message || error).slice(0, 120) });
      return response;
    }
  };

  writeDiagnostic('armed-fetch');
})();
