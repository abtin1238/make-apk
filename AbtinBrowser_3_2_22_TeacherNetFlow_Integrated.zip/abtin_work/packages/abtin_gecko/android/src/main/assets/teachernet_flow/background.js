'use strict';

const SPEC_URL = 'https://flow.cfcnode.com/v1/flow-spec';
const SPEC_TTL_MS = 6 * 60 * 60 * 1000;
let specCache = null;
let specFetchedAt = 0;
let specInFlight = null;

async function fetchSpec() {
  const now = Date.now();
  if (specCache && now - specFetchedAt < SPEC_TTL_MS) return specCache;
  if (specInFlight) return specInFlight;
  specInFlight = (async () => {
    try {
      const response = await fetch(SPEC_URL, { cache: 'no-store' });
      if (!response.ok) throw new Error(`spec HTTP ${response.status}`);
      specCache = await response.json();
      specFetchedAt = Date.now();
      return specCache;
    } catch (error) {
      console.warn('TeacherNet Flow spec fetch failed:', error);
      return specCache;
    } finally {
      specInFlight = null;
    }
  })();
  return specInFlight;
}

browser.runtime.onInstalled.addListener(async () => {
  const saved = await browser.storage.local.get('helperEnabled');
  if (saved.helperEnabled === undefined) {
    await browser.storage.local.set({ helperEnabled: true });
  }
});

browser.runtime.onMessage.addListener(async (message, sender) => {
  if (!message || sender.id !== browser.runtime.id) return undefined;
  if (message.type === 'getSpec') {
    const spec = await fetchSpec();
    return { ok: Boolean(spec), spec };
  }
  if (message.type === 'getEnabled') {
    const saved = await browser.storage.local.get('helperEnabled');
    return { ok: true, enabled: saved.helperEnabled !== false };
  }
  return undefined;
});
