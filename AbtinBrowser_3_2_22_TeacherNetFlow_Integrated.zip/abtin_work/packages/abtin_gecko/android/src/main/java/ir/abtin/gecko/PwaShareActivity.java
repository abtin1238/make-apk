package ir.abtin.gecko;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Receiver of Android's share sheet for installed web apps (Web Share Target).
 * - Opened from a sharing shortcut (EXTRA_SHORTCUT_ID = "abtin_share_<app id>"): goes straight to that web app.
 * - Opened from the generic entry: shows a small list of the installed web apps that can receive shares.
 * The shared text / link / files are packed into a JSON extra and handed to {@link PwaActivity}.
 */
public class PwaShareActivity extends Activity {
    private static final String TAG = "AbtinShare";
    /** Extra of the launch intent for PwaActivity: JSON {target:{...share_target}, data:{title,text,url}, files:[{path,name,type}]}. */
    static final String EXTRA = "abtin_share_payload";
    private static final long MAX_FILES_BYTES = 24L * 1024 * 1024; // files travel to the page as base64 through the extension port

    private Engine e;
    private String subject = "", text = "";
    private final List<Uri> uris = new ArrayList<>();
    private boolean done;

    private boolean fa() { return e != null && "fa".equals(e.lang); }
    private String tr(String f, String en) { return fa() ? f : en; }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        e = Engine.get(this);
        final Intent in = getIntent();
        final String act = in == null ? null : in.getAction();
        if (!Intent.ACTION_SEND.equals(act) && !Intent.ACTION_SEND_MULTIPLE.equals(act)) { finish(); return; }
        try {
            final CharSequence t = in.getCharSequenceExtra(Intent.EXTRA_TEXT);
            if (t != null) text = t.toString();
            CharSequence sub = in.getCharSequenceExtra(Intent.EXTRA_SUBJECT);
            if (sub == null) sub = in.getCharSequenceExtra(Intent.EXTRA_TITLE);
            if (sub != null) subject = sub.toString();
            if (Intent.ACTION_SEND.equals(act)) {
                final Uri u = in.getParcelableExtra(Intent.EXTRA_STREAM);
                if (u != null) uris.add(u);
            } else {
                final ArrayList<Uri> l = in.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                if (l != null) uris.addAll(l);
            }
            final ClipData cd = in.getClipData();
            if (cd != null) for (int i = 0; i < cd.getItemCount(); i++) {
                final Uri u = cd.getItemAt(i).getUri();
                if (u != null && !uris.contains(u)) uris.add(u);
            }
        } catch (Throwable t) { Log.w(TAG, "read intent", t); }

        final String sid = in.getStringExtra(Intent.EXTRA_SHORTCUT_ID);
        if (sid != null && sid.startsWith(WebApps.SHARE_PREFIX)) {
            final JSONObject app = e.webApps.shareApp(sid.substring(WebApps.SHARE_PREFIX.length()));
            if (app != null) { deliver(app); return; }
        }
        chooser();
    }

    private void chooser() {
        final List<JSONObject> apps = e.webApps.shareApps();
        if (apps.isEmpty()) {
            Toast.makeText(this, tr("هیچ وب‌اپ نصب‌شده‌ای اشتراک‌گذاری را پشتیبانی نمی‌کند", "No installed web app can receive shares"), Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        if (apps.size() == 1) { deliver(apps.get(0)); return; }
        final float d = getResources().getDisplayMetrics().density;
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return apps.size(); }
            @Override public Object getItem(int i) { return apps.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View v, ViewGroup p) {
                final JSONObject o = apps.get(i);
                final LinearLayout row = new LinearLayout(PwaShareActivity.this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding((int) (20 * d), (int) (10 * d), (int) (20 * d), (int) (10 * d));
                final ImageView iv = new ImageView(PwaShareActivity.this);
                final Bitmap bm = e.webApps.iconBitmap(o.optString("id"));
                if (bm != null) iv.setImageBitmap(bm);
                row.addView(iv, new LinearLayout.LayoutParams((int) (40 * d), (int) (40 * d)));
                final TextView tv = new TextView(PwaShareActivity.this);
                tv.setText(o.optString("title"));
                tv.setTextSize(16);
                tv.setPadding((int) (16 * d), 0, 0, 0);
                row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                return row;
            }
        };
        new AlertDialog.Builder(this)
                .setTitle(tr("ارسال به وب‌اپ", "Share to web app"))
                .setAdapter(ad, (dlg, which) -> deliver(apps.get(which)))
                .setOnCancelListener(dlg -> finish())
                .show();
    }

    private static String val(JSONObject o, String k) { return o.isNull(k) ? "" : o.optString(k, ""); }

    private static boolean isUrl(String s) {
        final String t = s.trim();
        if (t.contains(" ") || t.contains("\n")) return false;
        final String l = t.toLowerCase(Locale.ROOT);
        return l.startsWith("http://") || l.startsWith("https://");
    }

    /** Packs the shared content for the chosen web app and opens it. */
    private void deliver(final JSONObject app) {
        if (done) return;
        done = true;
        new Thread(() -> {
            try {
                final JSONObject target = new JSONObject(app.optString("share"));
                final JSONObject data = new JSONObject();
                String t = text, u = "";
                // Like Chrome: a shared link goes to "url" when the app declares that parameter.
                if (!t.isEmpty() && isUrl(t) && !val(target, "url").isEmpty()) { u = t.trim(); t = ""; }
                data.put("title", subject).put("text", t).put("url", u);
                final JSONArray files = new JSONArray();
                final boolean wantsFiles = target.optJSONArray("files") != null && target.optJSONArray("files").length() > 0;
                if (wantsFiles && !uris.isEmpty()) copyFiles(files);
                final JSONObject payload = new JSONObject().put("target", target).put("data", data).put("files", files);
                runOnUiThread(() -> {
                    try {
                        final Intent it = e.webApps.intentFor(app.optString("url"), app.optString("title"), true);
                        it.putExtra(EXTRA, payload.toString());
                        // Safety net: not every web app handles its share_target well (many only fill the message box after a chat is
                        // picked, or ignore the data). The shared text is also on the clipboard, so long-press > paste always works.
                        final String clip = (!text.isEmpty() ? text : (!subject.isEmpty() ? subject : ""));
                        if (!clip.isEmpty()) {
                            try {
                                final android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                                if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("shared", clip));
                                Toast.makeText(getApplicationContext(), tr("متن کپی شد؛ اگر وارد پیام نشد، در کادر پیام «چسباندن» بزنید", "Text copied. If it does not appear, paste it in the message box"), Toast.LENGTH_LONG).show();
                            } catch (Throwable ignored) { }
                        }
                        startActivity(it);
                    } catch (Throwable ex) { Log.w(TAG, "start", ex); }
                    finish();
                });
            } catch (Throwable ex) {
                Log.w(TAG, "deliver", ex);
                runOnUiThread(() -> { Toast.makeText(this, tr("اشتراک‌گذاری ناموفق بود", "Sharing failed"), Toast.LENGTH_SHORT).show(); finish(); });
            }
        }, "abtin-share").start();
    }

    private void copyFiles(JSONArray out) {
        final File dir = new File(getCacheDir(), "abtin_share");
        sweep(dir);
        final File mine = new File(dir, String.valueOf(System.currentTimeMillis()));
        mine.mkdirs();
        final ContentResolver cr = getContentResolver();
        long total = 0;
        int n = 0;
        for (Uri u : uris) {
            try {
                String name = null;
                try (android.database.Cursor c = cr.query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                    if (c != null && c.moveToFirst()) name = c.getString(0);
                } catch (Throwable ignored) { }
                if (name == null || name.isEmpty()) name = u.getLastPathSegment() == null ? "file" : u.getLastPathSegment();
                name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                String type = cr.getType(u);
                if (type == null) type = "application/octet-stream";
                final File f = new File(mine, (n++) + "_" + name);
                try (InputStream is = cr.openInputStream(u); OutputStream os = new FileOutputStream(f)) {
                    if (is == null) continue;
                    final byte[] buf = new byte[64 * 1024];
                    int r;
                    while ((r = is.read(buf)) > 0) { os.write(buf, 0, r); total += r; if (total > MAX_FILES_BYTES) break; }
                }
                if (total > MAX_FILES_BYTES) { f.delete(); runOnUiThread(() -> Toast.makeText(this, tr("فایل برای اشتراک‌گذاری خیلی بزرگ است", "The file is too large to share"), Toast.LENGTH_LONG).show()); break; }
                out.put(new JSONObject().put("path", f.getPath()).put("name", name).put("type", type));
            } catch (Throwable t) { Log.w(TAG, "copy " + u, t); }
        }
    }

    private static void sweep(File dir) {
        try {
            final File[] l = dir.listFiles();
            if (l == null) return;
            final long old = System.currentTimeMillis() - 3600_000L;
            for (File d : l) {
                if (d.lastModified() > old) continue;
                final File[] fs = d.listFiles();
                if (fs != null) for (File f : fs) f.delete();
                d.delete();
            }
        } catch (Throwable ignored) { }
    }
}
