# ادغام Google Flow تیچرنت در ابتین براوزر

در این نسخه، افزونه Chrome MV3 مستقیماً اجرا نمی‌شود؛ فایل‌های آن به یک WebExtension مبتنی بر Manifest V2 برای GeckoView تبدیل و داخل assets خود برنامه قرار گرفته‌اند.

## تغییرات
- افزودن افزونه داخلی `teachernet-flow@abtin.ir` در مسیر `packages/abtin_gecko/android/src/main/assets/teachernet_flow/`
- بارگذاری خودکار افزونه با `WebExtensionController.ensureBuiltIn` هنگام راه‌اندازی موتور
- حفظ فایل‌های اصلی منطق Flow شامل `engine.js` و `fetch-bridge.js`
- تبدیل background service worker به background script پایدار Gecko و حذف وابستگی به `chrome.scripting` برای ثبت پویای اسکریپت‌ها
- افزودن Popup ساده برای بازکردن Google Flow
- تنظیم دسترسی‌های میزبانی Flow و سرور تنظیمات TeacherNet

## نکته‌های آزمون
- JSON مانیفست و وجود تمام فایل‌های ارجاع‌شده بررسی شده‌اند.
- دستور `node --check` برای فایل‌های JavaScript افزونه بدون خطا اجرا شده است.
- ساخت APK در این محیط کامل نشد: Flutter SDK نصب نیست و Gradle Wrapper برای دریافت Gradle به اینترنت نیاز داشت؛ دسترسی شبکه در محیط ساخت برقرار نبود.
- بنابراین این خروجی سورس اصلاح‌شده است، نه APK تأییدشده. نصب واقعی و بررسی عملکرد روی دستگاه هنوز باید انجام شود.
