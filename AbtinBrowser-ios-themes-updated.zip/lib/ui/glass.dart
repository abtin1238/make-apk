import 'dart:async';
import 'package:flutter/material.dart';
import '../app_state.dart';
import '../palettes.dart';
import '../services.dart';

/// Alpha helper that works on every Flutter version (no withOpacity / .value).
Color alpha(Color c, double o) => c.withAlpha((o.clamp(0.0, 1.0) * 255).round());

/// Background colour of the current palette (kept for older call sites).
Color solidBackground(AbtinPalette p) => p.pageColor(app.styleId);

/// Opaque card colour; comes from the palette in every interface style.
Color solidSurface(AbtinPalette p, bool dark, bool strong, String style) => p.surfaceColor(style, strong: strong);

// ───────────────────────── frosted glass panel ─────────────────────────
class Glass extends StatelessWidget {
  const Glass({
    super.key, required this.child, this.radius = 22, this.padding, this.margin,
    this.strong = false, this.tint, this.borderColor, this.borderWidth = 1, this.blur,
  });
  final Widget child;
  final double radius, borderWidth;
  final EdgeInsetsGeometry? padding, margin;
  final bool strong;
  final Color? tint, borderColor;
  final double? blur; // null = user setting, 0 = no backdrop filter (use inside another glass)

  Widget _flat(BuildContext context, bool dark, String style) {
    final r = style == 'ios' ? radius.clamp(10.0, 14.0).toDouble() : radius.clamp(style == 'minimal' ? 8.0 : 12.0, style == 'uc' ? 22.0 : 26.0).toDouble();
    final br = BorderRadius.circular(r);
    final p = app.palette;
    var surface = solidSurface(p, dark, strong, style);
    if (tint != null) surface = Color.alphaBlend(alpha(tint!, dark ? .26 : .20), surface);
    final inner = Material(type: MaterialType.transparency, child: padding == null ? child : Padding(padding: padding!, child: child));
    final BoxDecoration dec;
    if (style == 'ios') {
      dec = BoxDecoration(color: surface, borderRadius: br, border: borderColor != null ? Border.all(color: borderColor!, width: borderWidth) : null);
    } else if (style == 'neu') {
      final hi = dark ? alpha(Colors.white, .07) : Colors.white;
      final lo = dark ? alpha(Colors.black, .60) : alpha(const Color(0xFF8A96A8), .42);
      dec = BoxDecoration(color: surface, borderRadius: br, boxShadow: [
        BoxShadow(color: lo, blurRadius: 9, offset: const Offset(3.5, 3.5)),
        BoxShadow(color: hi, blurRadius: 9, offset: const Offset(-3.5, -3.5)),
      ]);
    } else if (style == 'uc') {
      dec = BoxDecoration(color: surface, borderRadius: BorderRadius.circular(r), border: Border.all(color: Color(app.accentInt).withAlpha(70), width: 1.2), boxShadow: app.perf ? null : [BoxShadow(color: Colors.black.withAlpha(dark ? 55 : 18), blurRadius: 8, offset: const Offset(0, 3))]);
    } else if (style == 'samsung') {
      dec = BoxDecoration(color: surface, borderRadius: BorderRadius.circular(r), border: Border.all(color: dark ? const Color(0xFF343A44) : const Color(0xFFE6E9EF), width: 1));
    } else {
      dec = BoxDecoration(color: surface, borderRadius: BorderRadius.circular(r), border: Border.all(color: borderColor ?? alpha(dark ? Colors.white : Colors.black, style == 'minimal' ? .06 : .10), width: borderWidth));
    }
    Widget w = DecoratedBox(decoration: dec, child: ClipRRect(borderRadius: br, child: inner));
    if (margin != null) w = Padding(padding: margin!, child: w);
    return w;
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return _flat(context, dark, app.styleId);
  }
}

class GlassCard extends StatelessWidget {
  const GlassCard({super.key, required this.child, this.margin = const EdgeInsets.symmetric(vertical: 4)});
  final Widget child;
  final EdgeInsetsGeometry margin;
  @override
  Widget build(BuildContext context) => Glass(radius: 20, blur: 0, margin: margin, child: child);
}

/// A ListTile inside its own glass card (used by lists).
class GlassTile extends StatelessWidget {
  const GlassTile({super.key, this.leading, this.title, this.subtitle, this.trailing, this.onTap, this.onLongPress, this.dense = false});
  final Widget? leading, title, subtitle, trailing;
  final VoidCallback? onTap, onLongPress;
  final bool dense;
  @override
  Widget build(BuildContext context) => Glass(
        radius: 18, blur: 0, margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: ListTile(dense: dense, leading: leading, title: title, subtitle: subtitle, trailing: trailing, onTap: onTap, onLongPress: onLongPress),
      );
}

// ───────────────────────── colorful icon chip ─────────────────────────
class IconChip extends StatelessWidget {
  const IconChip(this.icon, this.color, {super.key, this.size = 44});
  final IconData icon;
  final Color color;
  final double size;
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(size * .32),
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color.lerp(color, Colors.white, .30)!, color]),
          boxShadow: app.perf ? null : [BoxShadow(color: alpha(color, .45), blurRadius: size * .38, offset: Offset(0, size * .1))],
        ),
        child: Icon(icon, color: Colors.white, size: size * .5),
      );
}

// ───────────────────────── animated / static background ─────────────────────────
/// Flat page background in the palette's colour (no gradients, glows or blur: the glass look is gone).
class GlassBackground extends StatefulWidget {
  const GlassBackground({super.key, required this.child});
  final Widget child;
  @override
  State<GlassBackground> createState() => _GlassBackgroundState();
}

class _GlassBackgroundState extends State<GlassBackground> {
  void _onApp() { if (mounted) setState(() {}); }

  @override
  void initState() { super.initState(); app.addListener(_onApp); }
  @override
  void dispose() { app.removeListener(_onApp); super.dispose(); }

  @override
  Widget build(BuildContext context) => ColoredBox(color: app.palette.pageColor(app.styleId), child: widget.child);
}

/// Drop-in Scaffold replacement: paints the glass background behind the page (opaque, so
/// page transitions never show the previous page through it).
class GlassScaffold extends StatelessWidget {
  const GlassScaffold({super.key, this.appBar, this.body, this.bottomNavigationBar, this.resizeToAvoidBottomInset = true});
  final PreferredSizeWidget? appBar;
  final Widget? body, bottomNavigationBar;
  final bool resizeToAvoidBottomInset;
  @override
  Widget build(BuildContext context) => GlassBackground(
        child: Scaffold(backgroundColor: Colors.transparent, resizeToAvoidBottomInset: resizeToAvoidBottomInset, appBar: appBar, body: body, bottomNavigationBar: bottomNavigationBar),
      );
}

/// Makes room for the soft keyboard in ONE step instead of once per animation frame.
/// The keyboard animates for ~250 ms and Flutter reports ~15 intermediate heights; resizing the web view for each of them
/// fires a storm of `resize` events in the page. Sites such as Telegram / Eitaa web react to that by blurring or re-focusing
/// the field (the keyboard flips between layouts and closes). Here the new height is applied once it has stopped changing.
/// [immediate] (a Flutter text field such as the find bar owns the keyboard) follows the keyboard live.
class SettledKeyboardInset extends StatefulWidget {
  const SettledKeyboardInset({super.key, required this.child, this.immediate = false, this.settle = const Duration(milliseconds: 110)});
  final Widget child;
  final bool immediate;
  final Duration settle;
  @override
  State<SettledKeyboardInset> createState() => _SettledKeyboardInsetState();
}

class _SettledKeyboardInsetState extends State<SettledKeyboardInset> {
  double _raw = 0, _applied = 0;
  Timer? _t;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final raw = MediaQuery.viewInsetsOf(context).bottom;
    if (raw == _raw) return;
    _raw = raw;
    _t?.cancel();
    if (widget.immediate) {
      _applied = raw;
      return;
    }
    _t = Timer(widget.settle, () {
      if (mounted && _applied != _raw) setState(() => _applied = _raw);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Padding(padding: EdgeInsets.only(bottom: _applied), child: widget.child);
}

// ───────────────────────── sheets & dialogs ─────────────────────────
Future<T?> showGlassSheet<T>({required BuildContext context, required WidgetBuilder builder, bool isScrollControlled = false, bool useSafeArea = false}) {
  return showModalBottomSheet<T>(
    context: context, isScrollControlled: isScrollControlled, useSafeArea: useSafeArea,
    backgroundColor: solidSurface(app.palette, app.dark, true, 'solid'), elevation: 0, barrierColor: Colors.black54,
    sheetAnimationStyle: app.flag('uiAnim') ? null : AnimationStyle.noAnimation,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
      child: Glass(radius: 30, strong: true, child: builder(ctx)),
    ),
  );
}

Future<T?> showGlassDialog<T>({required BuildContext context, required WidgetBuilder builder, bool barrierDismissible = true}) {
  return showGeneralDialog<T>(
    context: context, barrierDismissible: barrierDismissible, barrierLabel: 'dialog', barrierColor: Colors.black38,
    transitionDuration: app.flag('uiAnim') ? const Duration(milliseconds: 220) : Duration.zero,
    pageBuilder: (ctx, _, __) => SafeArea(child: Center(child: Builder(builder: builder))),
    transitionBuilder: (ctx, anim, _, child) {
      final c = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
      return FadeTransition(opacity: c, child: ScaleTransition(scale: Tween<double>(begin: .92, end: 1).animate(c), child: child));
    },
  );
}

// ───────────────────────── theme picker ─────────────────────────
class PalettePicker extends StatelessWidget {
  const PalettePicker({super.key});

  Widget _line(Color color, double width, {double height = 3}) => Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(height),
        ),
      );

  Widget _item(BuildContext context, String id, String name, AbtinPalette p, bool selected) {
    final dark = p.dark;
    final accent = Color(p.accent);
    final ink = dark ? const Color(0xFFF4F6FA) : const Color(0xFF182235);
    final subInk = dark ? const Color(0xFFB6C0CF) : const Color(0xFF596579);
    final page = Color(p.bg.first);
    final bar = dark ? const Color(0xFF171F2D) : const Color(0xFFF9FAFC);
    final surface = p.surfaceColor('minimal', strong: true);

    return GestureDetector(
      onTap: () => app.setPalette(id),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 164,
        height: 132,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: surface,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: selected ? accent : alpha(ink, .16), width: selected ? 2 : 1),
          boxShadow: selected ? [BoxShadow(color: alpha(accent, .24), blurRadius: 8)] : null,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(11),
          child: Column(
            children: [
              Expanded(
                child: Stack(
                  children: [
                    Column(
                      children: [
                        Container(
                          height: 16,
                          color: bar,
                          padding: const EdgeInsets.symmetric(horizontal: 5),
                          child: Row(children: [
                            for (final c in const [0xFFF05D58, 0xFFF6C344, 0xFF42B66A])
                              Container(width: 4, height: 4, margin: const EdgeInsets.only(right: 3), decoration: BoxDecoration(color: Color(c), shape: BoxShape.circle)),
                            const SizedBox(width: 3),
                            Expanded(child: Container(
                              height: 11,
                              padding: const EdgeInsets.symmetric(horizontal: 5),
                              decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(5)),
                              child: Align(alignment: Alignment.centerLeft, child: _line(subInk, 31, height: 2)),
                            )),
                            const SizedBox(width: 4),
                            Icon(Icons.add, size: 9, color: subInk),
                          ]),
                        ),
                        Container(
                          height: 17,
                          color: surface,
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                          child: Row(children: [
                            Icon(Icons.arrow_back, size: 9, color: ink),
                            const SizedBox(width: 5),
                            Icon(Icons.refresh, size: 9, color: ink),
                            const SizedBox(width: 5),
                            Expanded(child: Container(
                              height: 10,
                              padding: const EdgeInsets.symmetric(horizontal: 4),
                              decoration: BoxDecoration(color: alpha(ink, .07), borderRadius: BorderRadius.circular(6)),
                              child: Align(alignment: Alignment.centerLeft, child: _line(subInk, 38, height: 2)),
                            )),
                            const SizedBox(width: 5),
                            Icon(Icons.star_border, size: 9, color: ink),
                            const SizedBox(width: 4),
                            Icon(Icons.download_outlined, size: 9, color: ink),
                          ]),
                        ),
                        Expanded(child: Container(
                          color: page,
                          width: double.infinity,
                          child: Stack(children: [
                            Positioned(left: 8, right: 68, top: 9, child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(height: 25, decoration: BoxDecoration(borderRadius: BorderRadius.circular(5), gradient: LinearGradient(colors: [accent, Color(p.blobs.first)]))),
                                const SizedBox(height: 5),
                                _line(ink, 44, height: 4),
                                const SizedBox(height: 3),
                                _line(subInk, 35, height: 2),
                                const SizedBox(height: 5),
                                Container(width: 34, height: 9, decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(8))),
                              ],
                            )),
                            Positioned(right: 4, top: 4, bottom: 4, width: 61, child: DecoratedBox(
                              decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(7), border: Border.all(color: alpha(ink, .14)), boxShadow: [BoxShadow(color: alpha(Colors.black, dark ? .28 : .13), blurRadius: 4, offset: const Offset(0, 1))]),
                              child: Padding(
                                padding: const EdgeInsets.all(4),
                                child: Column(children: [
                                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                                    Icon(Icons.refresh, size: 8, color: ink),
                                    Icon(Icons.share, size: 8, color: ink),
                                    Icon(Icons.arrow_back, size: 8, color: accent),
                                    Icon(Icons.arrow_forward, size: 8, color: accent),
                                  ]),
                                  const SizedBox(height: 4),
                                  for (var i = 0; i < 3; i++) ...[
                                    if (i > 0) Divider(height: 4, thickness: .5, color: alpha(ink, .12)),
                                    Row(children: [
                                      Icon([Icons.desktop_windows_outlined, Icons.star_border, Icons.search][i], size: 7, color: i == 1 ? accent : ink),
                                      const SizedBox(width: 4),
                                      Expanded(child: _line(subInk, 26, height: 2)),
                                    ]),
                                  ],
                                  const Spacer(),
                                  Container(height: 11, decoration: BoxDecoration(color: alpha(accent, .12), borderRadius: BorderRadius.circular(3))),
                                ]),
                              ),
                            )),
                          ]),
                        )),
                        Container(
                          height: 13,
                          color: bar,
                          padding: const EdgeInsets.symmetric(horizontal: 6),
                          child: Row(children: [
                            Container(width: 9, height: 7, decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(2))),
                            const SizedBox(width: 4),
                            _line(subInk, 39, height: 2),
                            const Spacer(),
                            Icon(Icons.keyboard_arrow_down, size: 9, color: subInk),
                          ]),
                        ),
                      ],
                    ),
                    if (selected) Positioned(top: 3, right: 4, child: Container(
                      width: 14,
                      height: 14,
                      decoration: BoxDecoration(color: accent, shape: BoxShape.circle),
                      child: const Icon(Icons.check, color: Colors.white, size: 10),
                    )),
                  ],
                ),
              ),
              Container(
                height: 26,
                width: double.infinity,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                color: surface,
                alignment: Alignment.center,
                child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: ink, fontSize: 11.5, fontWeight: selected ? FontWeight.w700 : FontWeight.w500)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cur = app.str('palette');
    final bd = palettes.firstWhere((p) => p.id == 'browser-dark');
    final bl = palettes.firstWhere((p) => p.id == 'browser-light');
    final auto = AbtinPalette('auto', 'خودکار', 'Auto', true, [...bd.bg], [...bl.blobs], bd.accent);
    return SizedBox(
      height: 158,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        children: [
          _item(context, 'auto', tr('خودکار', 'Auto'), auto, cur == 'auto'),
          for (final p in palettes) _item(context, p.id, tr(p.fa, p.en), p, cur == p.id),
        ],
      ),
    );
  }
}

/// Height of the top bar (tabs + address bar) of the browser page, set by it: message bars start BELOW it instead of covering the address bar.
double snackTopInset = 0;

/// Message bar (toast) at the TOP of the screen instead of the bottom (just under the browser's address bar).
void snackTop(BuildContext context, String msg) {
  final mq = MediaQuery.of(context);
  final m = ScaffoldMessenger.of(context);
  final bottom = (mq.size.height - mq.viewInsets.bottom - mq.padding.top - snackTopInset - 84).clamp(0.0, double.infinity);
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(
    content: Text(msg),
    behavior: SnackBarBehavior.floating,
    dismissDirection: DismissDirection.up,
    margin: EdgeInsets.fromLTRB(12, 0, 12, bottom),
  ));
}
