import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart' show FocusNode;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:xterm/xterm.dart';

import '../core/layouts.dart' show tr2;
import 'native.dart';
import 'terminal_native.dart';

/// VS Code style terminal profiles. The default one is stored in SharedPreferences.
class TermProfile {
  const TermProfile(this.id, this.fa, this.en, this.descFa, this.descEn);
  final String id;
  final String fa, en, descFa, descEn;
  String get title => tr2(fa, en);
  String get desc => tr2(descFa, descEn);
}

class TermProfiles {
  static const all = <TermProfile>[
    TermProfile('termux', 'Termux', 'Termux', 'پیش‌فرض: bash + pkg رسمی ترموکس', 'Default: Termux bash + official pkg'),
    TermProfile('alpine', 'Alpine bash', 'Alpine bash', 'لینوکس Alpine (apk)', 'Alpine Linux (apk)'),
    TermProfile('sh', 'پوستهٔ اندروید (sh)', 'Android shell (sh)', 'بدون ورود خودکار به bash', 'No automatic bash'),
  ];
  static const _key = 'terminal_default_profile';
  static String current = 'termux';
  static bool _loaded = false;

  static Future<void> load() async {
    if (_loaded) return;
    try {
      final v = (await SharedPreferences.getInstance()).getString(_key);
      if (v != null && all.any((e) => e.id == v)) current = v;
    } catch (_) {}
    _loaded = true;
  }

  static Future<void> setDefault(String id) async {
    if (!all.any((e) => e.id == id)) return;
    current = id;
    _loaded = true;
    try {
      await (await SharedPreferences.getInstance()).setString(_key, id);
    } catch (_) {}
  }

  static TermProfile byId(String id) => all.firstWhere((e) => e.id == id, orElse: () => all.first);
}

/// One terminal tab: its own emulator, its own native PTY session and history.
/// Notifies listeners only when the status/title changes (not on every output chunk;
/// the [Terminal] itself notifies the view about output).
class TermTab extends ChangeNotifier {
  static const _maxHistory = 100;

  TermTab({required this.cwd, required this.number}) {
    terminal.onOutput = _sendToPty;
    terminal.onResize = (columns, rows, _, __) {
      _cols = columns.clamp(20, 500).toInt();
      _rows = rows.clamp(5, 300).toInt();
      final id = _id;
      if (id != null) unawaited(_native.resize(id, _cols, _rows).catchError((_) {}));
    };
    terminal.onTitleChange = (t) {
      final v = t.trim();
      if (v == _oscTitle) return;
      _oscTitle = v.isEmpty ? null : v;
      _notify();
    };
    _sub = _native.events.listen(
      _onEvent,
      onError: (Object e) => terminal.write('\r\n[stream error: $e]\r\n'),
    );
  }

  final String cwd;
  final int number;
  final Terminal terminal = Terminal(maxLines: 10000);
  final TerminalController controller = TerminalController();
  final FocusNode focus = FocusNode();
  final List<String> history = <String>[];

  final TerminalNative _native = TerminalNative();
  final StringBuffer _line = StringBuffer();
  final List<Map<String, dynamic>> _pending = <Map<String, dynamic>>[];
  StreamSubscription<Map<String, dynamic>>? _sub;
  String? _id;
  String? _oscTitle;
  String? customTitle;

  /// The shell installs Termux + Node + Claude Code by itself and starts it (editor Claude Code tab).
  bool claudeMode = false;
  Timer? _urlWatch;

  /// Profile id for this tab (null = the saved default profile).
  String? profile;
  int _escState = 0;
  int _cols = 80, _rows = 24;
  bool _disposed = false;

  bool starting = false;
  bool ended = false;
  int? exitCode;
  String sessionCwd = '';
  String status = '';

  bool get running => _id != null;

  /// Title shown on the tab: user's name, then the title the shell set (OSC), then "Terminal N".
  String get title {
    final c = customTitle;
    if (c != null && c.isNotEmpty) return c;
    final o = _oscTitle;
    if (o != null && o.isNotEmpty) return o.length > 24 ? '${o.substring(0, 24)}…' : o;
    return tr2('ترمینال $number', 'Terminal $number');
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  Future<void> start() async {
    if (starting || running) return;
    starting = true;
    ended = false;
    exitCode = null;
    status = tr2('در حال اتصال PTY…', 'Connecting PTY…');
    _pending.clear();
    _notify();
    try {
      await TermProfiles.load();
      final s = await _native.start(cwd, columns: _cols, rows: _rows, bash: true, claude: claudeMode, profile: profile ?? TermProfiles.current);
      if (_disposed) {
        unawaited(_native.close(s.id).catchError((_) {}));
        return;
      }
      _id = s.id;
      sessionCwd = s.cwd;
      starting = false;
      status = tr2('PTY متصل', 'PTY connected');
      // Output that arrived before the start result reached Dart.
      final early = List<Map<String, dynamic>>.from(_pending);
      _pending.clear();
      for (final e in early) {
        if (e['sessionId'] == s.id) _onEvent(e);
      }
      unawaited(_native.resize(s.id, _cols, _rows).catchError((_) {}));
      if (claudeMode) _watchOpenUrl();
      final w = s.warning;
      if (w != null && w.isNotEmpty) {
        terminal.write('\x1b[31m[environment setup failed: $w]\x1b[0m\r\n'
            '\x1b[31m[pkg / termux / alpine / bash are unavailable in this session]\x1b[0m\r\n');
      }
      _notify();
    } catch (e) {
      if (_disposed) return;
      starting = false;
      status = tr2('اتصال ناموفق', 'Connection failed');
      terminal.write('\r\n[PTY error] $e\r\n');
      _notify();
    }
  }

  /// Claude Code's login link: `$BROWSER` (abtin-open, see PkgEnv) writes the url to a file; open it in the phone browser.
  Future<void> _watchOpenUrl() async {
    if (_urlWatch != null) return;
    File? f;
    try {
      final dir = await getApplicationSupportDirectory();
      f = File('${dir.path}/usr/termux/files/home/.abtin-open-url');
      if (f.existsSync()) f.deleteSync();
    } catch (_) {
      return;
    }
    final file = f;
    _urlWatch = Timer.periodic(const Duration(milliseconds: 800), (_) async {
      if (_disposed) return;
      try {
        if (!file.existsSync()) return;
        final u = file.readAsStringSync().trim();
        file.deleteSync();
        if (!u.startsWith('http://') && !u.startsWith('https://')) return;
        final ok = await Native.openUrl(u);
        terminal.write(ok
            ? '\r\n\x1b[32m[${tr2('مرورگر باز شد؛ بعد از ورود، کد را اینجا paste کنید', 'Browser opened; after signing in paste the code here')}]\x1b[0m\r\n'
            : '\r\n\x1b[33m[${tr2('مرورگر باز نشد؛ لینک را کپی کنید', 'Could not open the browser; copy the link')}]\x1b[0m\r\n');
      } catch (_) {}
    });
  }

  // Android's linker prints "WARNING: linker: Warning: failed to find generated linker configuration
  // from /linkerconfig/ld.config.txt" for every process started inside the sandbox. It is harmless,
  // so those lines are dropped before they reach the screen. Output may arrive split in the middle
  // of a line, so a possible start of such a line is held back until it is complete.
  static const _linkerTag = 'WARNING: linker:';
  String _held = '';
  Timer? _heldTimer;

  bool _isLinkerNoise(String line) =>
      line.startsWith(_linkerTag) && line.contains('linkerconfig');

  void _writeFiltered(String chunk) {
    _heldTimer?.cancel();
    final text = _held + chunk;
    _held = '';
    final out = StringBuffer();
    var start = 0;
    while (true) {
      final nl = text.indexOf('\n', start);
      if (nl < 0) break;
      final line = text.substring(start, nl + 1);
      if (!_isLinkerNoise(line.trimRight())) out.write(line);
      start = nl + 1;
    }
    final tail = text.substring(start);
    if (tail.isNotEmpty &&
        (_linkerTag.startsWith(tail) || tail.startsWith(_linkerTag))) {
      _held = tail;
      _heldTimer = Timer(const Duration(milliseconds: 250), () {
        final h = _held;
        _held = '';
        if (h.isNotEmpty && !_disposed && !_isLinkerNoise(h)) terminal.write(h);
      });
    } else {
      out.write(tail);
    }
    if (out.isNotEmpty) terminal.write(out.toString());
  }

  void _onEvent(Map<String, dynamic> e) {
    if (_disposed) return;
    final id = _id;
    if (id == null) {
      if (starting && _pending.length < 400) _pending.add(e);
      return;
    }
    if (e['sessionId'] != id) return;
    switch (e['type']) {
      case 'output':
        final t = e['text'];
        if (t is String) _writeFiltered(t);
        break;
      case 'exit':
        final code = e['exitCode'];
        _id = null;
        ended = true;
        exitCode = code is int ? code : null;
        status = tr2('پایان نشست', 'Session ended') + (code == null ? '' : ' ($code)');
        terminal.write('\r\n[PTY session ended${code == null ? '' : '; exit code: $code'}]\r\n');
        _notify();
        break;
    }
  }

  Future<void> _sendToPty(String data) async {
    final id = _id;
    if (id == null || data.isEmpty) return;
    _track(data);
    try {
      await _native.writeRaw(id, data);
    } catch (e) {
      terminal.write('\r\n[input error] $e\r\n');
    }
  }

  void _track(String data) {
    for (final r in data.runes) {
      if (_escState == 1) {
        _escState = r == 0x5b ? 2 : (r == 0x5d ? 3 : 0);
        continue;
      } else if (_escState == 2) {
        if (r >= 0x40 && r <= 0x7e) _escState = 0;
        continue;
      } else if (_escState == 3) {
        if (r == 0x07) {
          _escState = 0;
        } else if (r == 0x1b) {
          _escState = 4;
        }
        continue;
      } else if (_escState == 4) {
        _escState = r == 0x5c ? 0 : 3;
        continue;
      }
      if (r == 0x1b) {
        _escState = 1;
      } else if (r == 0x0d || r == 0x0a) {
        final c = _line.toString().trim();
        if (c.isNotEmpty && (history.isEmpty || history.last != c)) {
          history.add(c);
          if (history.length > _maxHistory) history.removeAt(0);
        }
        _line.clear();
      } else if (r == 0x08 || r == 0x7f) {
        final t = _line.toString();
        if (t.isNotEmpty) {
          _line
            ..clear()
            ..write(String.fromCharCodes(t.runes.take(t.runes.length - 1)));
        }
      } else if (r >= 0x20) {
        _line.writeCharCode(r);
      }
    }
  }

  Future<void> sendRaw(String v) async {
    final id = _id;
    if (id == null) return;
    try {
      await _native.writeRaw(id, v);
    } catch (e) {
      terminal.write('\r\n[input error] $e\r\n');
    }
  }

  Future<void> control(String k) async {
    final id = _id;
    if (id == null) return;
    try {
      switch (k) {
        case 'C':
          await _native.interrupt(id);
          break;
        case 'D':
          await _native.eof(id);
          break;
        case 'L':
          await sendRaw('\u000c');
          break;
        case 'A':
          await sendRaw('\u0001');
          break;
        case 'U':
          await sendRaw('\u0015');
          break;
        case 'W':
          await sendRaw('\u0017');
          break;
      }
    } catch (e) {
      terminal.write('\r\n[input error] $e\r\n');
    }
  }

  /// Closes the PTY session (the tab stays; [start] restarts it).
  Future<void> stop() async {
    final id = _id;
    if (id == null) return;
    status = tr2('در حال بستن PTY…', 'Closing PTY…');
    _notify();
    try {
      await _native.close(id);
    } catch (e) {
      terminal.write('\r\n[close error] $e\r\n');
    }
  }

  void rename(String? name) {
    customTitle = (name == null || name.trim().isEmpty) ? null : name.trim();
    _notify();
  }

  void clearScreen() => terminal.write('\u001b[2J\u001b[H');

  @override
  void dispose() {
    _disposed = true;
    _heldTimer?.cancel();
    _urlWatch?.cancel();
    _sub?.cancel();
    final id = _id;
    _id = null;
    if (id != null) unawaited(_native.close(id).catchError((_) {}));
    focus.dispose();
    super.dispose();
  }
}

/// The set of tabs of one terminal view (full screen or the editor's bottom panel).
class TermTabs extends ChangeNotifier {
  TermTabs({required this.cwd, this.onEmpty});

  final String cwd;

  /// Called after the last tab was closed.
  final VoidCallback? onEmpty;

  final List<TermTab> tabs = <TermTab>[];
  int active = 0;
  int _counter = 0;
  bool _disposed = false;

  TermTab? get current => tabs.isEmpty ? null : tabs[active.clamp(0, tabs.length - 1)];

  TermTab add({String? cwd, bool claude = false, String? profile}) {
    final t = TermTab(cwd: cwd ?? this.cwd, number: ++_counter);
    t.claudeMode = claude;
    t.profile = profile;
    t.addListener(_onTab);
    tabs.add(t);
    active = tabs.length - 1;
    notifyListeners();
    unawaited(t.start());
    return t;
  }

  void _onTab() {
    if (!_disposed) notifyListeners();
  }

  void select(int i) {
    if (i < 0 || i >= tabs.length) return;
    active = i;
    notifyListeners();
    tabs[i].focus.requestFocus();
  }

  void close(int i) {
    if (i < 0 || i >= tabs.length) return;
    final t = tabs.removeAt(i);
    t.removeListener(_onTab);
    t.dispose();
    if (active >= tabs.length) active = tabs.length - 1;
    if (active < 0) active = 0;
    notifyListeners();
    if (tabs.isEmpty) {
      onEmpty?.call();
    } else {
      tabs[active].focus.requestFocus();
    }
  }

  void closeAll() {
    for (final t in tabs) {
      t.removeListener(_onTab);
      t.dispose();
    }
    tabs.clear();
    active = 0;
    notifyListeners();
    onEmpty?.call();
  }

  @override
  void dispose() {
    _disposed = true;
    for (final t in tabs) {
      t.removeListener(_onTab);
      t.dispose();
    }
    tabs.clear();
    super.dispose();
  }
}
