import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xFF070B1A);
  static const card = Color(0xFF111A33);
  static const blue = Color(0xFF2F6BFF);
  static const purple = Color(0xFF8B5CF6);
  static const gold = Color(0xFFF5A623);
  static const grad = LinearGradient(colors: [blue, purple], begin: Alignment.topLeft, end: Alignment.bottomRight);
}

/// A selectable colour theme. Works in both light and dark mode.
class AppPalette {
  final String fa, en;
  final Color primary, secondary;
  final Color darkBg, darkCard, darkNav;
  final Color lightBg;
  const AppPalette(this.fa, this.en, this.primary, this.secondary, this.darkBg, this.darkCard, this.darkNav, this.lightBg);
}

const List<AppPalette> appPalettes = [
  AppPalette('ابتین', 'Abtin', Color(0xFF2F6BFF), Color(0xFF8B5CF6), Color(0xFF070B1A), Color(0xFF111A33), Color(0xFF0B1226), Color(0xFFF3F5FB)),
  AppPalette('اقیانوس', 'Ocean', Color(0xFF0097A7), Color(0xFF26C6DA), Color(0xFF06141A), Color(0xFF0E2530), Color(0xFF091C24), Color(0xFFF0F8FA)),
  AppPalette('جنگل', 'Forest', Color(0xFF2E9E5B), Color(0xFF9CCC65), Color(0xFF07140D), Color(0xFF10261A), Color(0xFF0A1D13), Color(0xFFF1F8F3)),
  AppPalette('غروب', 'Sunset', Color(0xFFF4511E), Color(0xFFFFA000), Color(0xFF180B07), Color(0xFF2B1810), Color(0xFF200F09), Color(0xFFFFF4EF)),
  AppPalette('رز', 'Rose', Color(0xFFE91E63), Color(0xFFFF7597), Color(0xFF170810), Color(0xFF2A1220), Color(0xFF200B18), Color(0xFFFFF1F5)),
  AppPalette('بنفش', 'Violet', Color(0xFF7C4DFF), Color(0xFFE040FB), Color(0xFF0E0820), Color(0xFF1B1238), Color(0xFF140C2C), Color(0xFFF6F2FF)),
  AppPalette('آمولد', 'AMOLED', Color(0xFF4C8DFF), Color(0xFF8B5CF6), Color(0xFF000000), Color(0xFF0D0D0D), Color(0xFF000000), Color(0xFFF3F5FB)),
  AppPalette('خاکستری', 'Slate', Color(0xFF607D8B), Color(0xFF90A4AE), Color(0xFF0F1214), Color(0xFF1C2226), Color(0xFF14191C), Color(0xFFF1F3F4)),
];

ThemeData buildTheme(bool dark, [int id = 0]) {
  final p = appPalettes[(id >= 0 && id < appPalettes.length) ? id : 0];
  final scheme = ColorScheme.fromSeed(seedColor: p.primary, brightness: dark ? Brightness.dark : Brightness.light, primary: p.primary, secondary: p.secondary);
  final bg = dark ? p.darkBg : p.lightBg;
  final surf = dark ? p.darkCard : Colors.white;
  // Every button in the app is a rounded, coloured pill (text buttons are tinted, filled ones solid).
  final shape = RoundedRectangleBorder(borderRadius: BorderRadius.circular(14));
  const pad = EdgeInsets.symmetric(horizontal: 16, vertical: 10);
  const label = TextStyle(fontWeight: FontWeight.w600);
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: bg,
    cardColor: surf,
    appBarTheme: AppBarTheme(backgroundColor: bg, elevation: 0, scrolledUnderElevation: 0),
    navigationBarTheme: NavigationBarThemeData(backgroundColor: dark ? p.darkNav : Colors.white, indicatorColor: p.primary.withOpacity(.25)),
    dialogTheme: DialogThemeData(backgroundColor: surf),
    bottomSheetTheme: BottomSheetThemeData(backgroundColor: surf),
    textButtonTheme: TextButtonThemeData(
      style: TextButton.styleFrom(
        foregroundColor: dark ? Color.lerp(p.primary, Colors.white, .25) : p.primary,
        backgroundColor: p.primary.withOpacity(dark ? .20 : .12),
        shape: shape,
        padding: pad,
        textStyle: label,
      ),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(backgroundColor: p.primary, foregroundColor: Colors.white, elevation: 0, shape: shape, padding: pad, textStyle: label),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(backgroundColor: p.primary, foregroundColor: Colors.white, shape: shape, padding: pad, textStyle: label),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: dark ? Color.lerp(p.secondary, Colors.white, .2) : p.primary,
        backgroundColor: p.secondary.withOpacity(dark ? .12 : .08),
        side: BorderSide(color: p.secondary.withOpacity(.8), width: 1.2),
        shape: shape,
        padding: pad,
        textStyle: label,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(filled: true, fillColor: dark ? p.darkNav : const Color(0xFFEAEEF8), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none)),
  );
}
