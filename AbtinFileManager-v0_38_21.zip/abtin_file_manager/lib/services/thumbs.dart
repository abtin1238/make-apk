import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'file_ops.dart';
import 'native.dart';

/// Video thumbnails and APK icons with an in-memory LRU and a disk cache.
class Thumbs {
  static final _mem = <String, Uint8List>{};
  static final _failed = <String>{};
  static final _inflight = <String, Future<Uint8List?>>{};
  static final _keysByPath = <String, Set<String>>{};
  static Directory? _dir;
  static int _running = 0;
  static final _waiters = <Completer<void>>[];

  static String _hash(String s) {
    var h = 0xcbf29ce484222325;
    for (final c in s.codeUnits) {
      h = (h ^ c) * 0x100000001b3;
    }
    return h.toUnsigned(64).toRadixString(16);
  }

  static Future<void> _acquire() async {
    if (_running < 3) {
      _running++;
      return;
    }
    final c = Completer<void>();
    _waiters.add(c);
    await c.future;
  }

  static void _release() {
    if (_waiters.isNotEmpty) {
      _waiters.removeAt(0).complete();
    } else {
      _running--;
    }
  }

  static Directory _cacheDir() {
    final d = _dir ??= Directory('${Directory.systemTemp.path}/abtin_thumbs');
    if (!d.existsSync()) d.createSync(recursive: true);
    return d;
  }

  static Future<Uint8List?> _cached(FItem it, String kind, Future<Uint8List?> Function() make) {
    final key = '$kind|${it.path}|${it.size}|${it.modified.millisecondsSinceEpoch}';
    (_keysByPath[it.path] ??= <String>{}).add(key);
    final hit = _mem.remove(key);
    if (hit != null) {
      _mem[key] = hit;
      return Future.value(hit);
    }
    if (_failed.contains(key)) return Future.value(null);
    return _inflight.putIfAbsent(key, () async {
      try {
        final file = File('${_cacheDir().path}/${_hash(key)}.img');
        Uint8List? data;
        if (file.existsSync()) {
          try { data = await file.readAsBytes(); } catch (_) {}
        }
        if (data == null || data.isEmpty) {
          await _acquire();
          try {
            data = await make();
          } finally {
            _release();
          }
          if (data != null && data.isNotEmpty) {
            try { await file.writeAsBytes(data); } catch (_) {}
          }
        }
        if (data == null || data.isEmpty) {
          _failed.add(key);
          return null;
        }
        _mem[key] = data;
        if (_mem.length > 400) _mem.remove(_mem.keys.first);
        return data;
      } catch (_) {
        _failed.add(key);
        return null;
      } finally {
        _inflight.remove(key);
      }
    });
  }

  /// Drops every cached preview (memory + disk) of a deleted file.
  static void evict(String path) {
    final keys = _keysByPath.remove(path);
    if (keys == null) return;
    for (final k in keys) {
      _mem.remove(k);
      _failed.remove(k);
      _inflight.remove(k);
      try { File('${_cacheDir().path}/${_hash(k)}.img').deleteSync(); } catch (_) {}
    }
  }

  static Future<Uint8List?> video(FItem it) => _cached(it, 'v', () async {
        try {
          return await VideoThumbnail.thumbnailData(video: it.path, imageFormat: ImageFormat.JPEG, maxWidth: 256, quality: 60);
        } catch (_) {
          return null;
        }
      });

  static Future<Uint8List?> apkIcon(FItem it) => _cached(it, 'a', () => Native.apkIcon(it.path));
}
