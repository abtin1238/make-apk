import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../widgets/ui.dart';

/// Full-screen folder chooser (internal storage + SD cards). Returns the chosen folder path, or null.
Future<String?> pickFolder(BuildContext c, {String? start, String? title}) {
  return Navigator.push<String>(c, MaterialPageRoute(builder: (_) => FolderPickerScreen(start: start, title: title)));
}

class FolderPickerScreen extends StatefulWidget {
  final String? start;
  final String? title;
  const FolderPickerScreen({super.key, this.start, this.title});
  @override
  State<FolderPickerScreen> createState() => _FolderPickerScreenState();
}

class _FolderPickerScreenState extends State<FolderPickerScreen> {
  late String _cwd;
  late List<StorageRoot> _roots;
  List<FItem> _dirs = const [];
  bool _loading = true;
  String? _err;

  @override
  void initState() {
    super.initState();
    _roots = FileOps.roots();
    var s = widget.start ?? FileOps.root;
    // walk up to the nearest folder that exists
    while (s.length > 1 && !Directory(s).existsSync()) {
      s = p.dirname(s);
    }
    _cwd = Directory(s).existsSync() ? s : FileOps.root;
    _load();
  }

  StorageRoot? get _rootOfCwd {
    StorageRoot? best;
    for (final r in _roots) {
      if (_cwd == r.path || p.isWithin(r.path, _cwd)) {
        if (best == null || r.path.length > best.path.length) best = r;
      }
    }
    return best;
  }

  bool get _atRoot => _roots.any((r) => r.path == _cwd);

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _err = null;
    });
    try {
      final all = await FileOps.list(_cwd);
      if (!mounted) return;
      setState(() {
        _dirs = all.where((e) => e.isDir).toList();
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _dirs = const [];
        _err = '${L.t('error')}: $e';
        _loading = false;
      });
    }
  }

  void _go(String path) {
    _cwd = path;
    _load();
  }

  Future<void> _newFolder() async {
    final n = await promptText(context, L.t('newFolder'));
    if (n == null || n.isEmpty || !mounted) return;
    try {
      await FileOps.mkdir(_cwd, n);
      _load();
    } catch (e) {
      if (mounted) snack(context, e is OpError ? L.t(e.key) : '${L.t('error')}: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return PopScope(
      canPop: _atRoot,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _go(p.dirname(_cwd));
      },
      child: Scaffold(
        appBar: AppBar(
          title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(widget.title ?? L.t('chooseFolder'), style: const TextStyle(fontSize: 16)),
            Text(_cwd, maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 11)),
          ]),
        ),
        body: Column(children: [
          if (_roots.length > 1)
            SizedBox(
              height: 52,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                children: [
                  for (final r in _roots)
                    Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: ChoiceChip(
                        avatar: Icon(r.sd ? Icons.sd_card_rounded : Icons.phone_android_rounded, size: 18),
                        label: Text(r.sd ? r.name : L.t('internal')),
                        selected: _rootOfCwd?.path == r.path,
                        onSelected: (_) => _go(r.path),
                      ),
                    ),
                ],
              ),
            ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : _err != null
                    ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_err!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.redAccent))))
                    : ListView.builder(
                        itemCount: _dirs.length + (_atRoot ? 0 : 1),
                        itemBuilder: (_, i) {
                          if (!_atRoot) {
                            if (i == 0) {
                              return ListTile(
                                leading: Icon(Icons.drive_folder_upload_rounded, color: cs.primary),
                                title: const Text('..'),
                                onTap: () => _go(p.dirname(_cwd)),
                              );
                            }
                            i--;
                          }
                          final d = _dirs[i];
                          return ListTile(
                            leading: Icon(Icons.folder_rounded, color: cs.secondary),
                            title: Text(d.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                            onTap: () => _go(d.path),
                          );
                        },
                      ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(children: [
                Expanded(child: OutlinedButton.icon(onPressed: _newFolder, icon: const Icon(Icons.create_new_folder_rounded), label: Text(L.t('newFolder')))),
                const SizedBox(width: 10),
                Expanded(child: FilledButton.icon(onPressed: () => Navigator.pop(context, _cwd), icon: const Icon(Icons.check_rounded), label: Text(L.t('selectThisFolder')))),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}
