import 'package:flutter/material.dart';

/// Tells the screens inside the Shell which layout is active and how to open the side menu (drawer layout only).
class LayoutScope extends InheritedWidget {
  final String layout;
  final VoidCallback? openMenu;
  const LayoutScope({super.key, required this.layout, this.openMenu, required super.child});

  static LayoutScope? maybeOf(BuildContext c) => c.dependOnInheritedWidgetOfExactType<LayoutScope>();

  @override
  bool updateShouldNotify(LayoutScope old) => layout != old.layout || (openMenu == null) != (old.openMenu == null);
}

/// Hamburger button for an AppBar's `leading` (null unless the drawer layout is active).
Widget? menuLeading(BuildContext c) {
  final open = LayoutScope.maybeOf(c)?.openMenu;
  if (open == null) return null;
  return IconButton(icon: const Icon(Icons.menu_rounded), onPressed: open);
}
