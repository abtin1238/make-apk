import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import 'viewer_delete.dart';
import '../widgets/ui.dart';

class HexViewerScreen extends StatefulWidget {
  final String path;
  const HexViewerScreen({super.key, required this.path});
  @override
  State<HexViewerScreen> createState() => _HexViewerScreenState();
}

class _HexViewerScreenState extends State<HexViewerScreen> {
  static const perRow = 16, pageRows = 256, pageSize = perRow * pageRows;
  RandomAccessFile? raf;
  int len = 0;
  final cache = <int, Uint8List>{};
  final loading = <int>{};
  final sc = ScrollController();
  final curOff = ValueNotifier<int>(0);
  Future<void> _chain = Future.value();
  double rowH = 18;
  int matchStart = -1, matchLen = 0;
  List<int>? lastPat;

  @override
  void initState() {
    super.initState();
    sc.addListener(() => curOff.value = (sc.offset / rowH).floor().clamp(0, 1 << 40) * perRow);
    _open();
  }

  Future<void> _open() async {
    try {
      raf = await File(widget.path).open();
      len = await raf!.length();
      if (mounted) setState(() {});
    } catch (e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    }
  }

  @override
  void dispose() {
    raf?.close();
    sc.dispose();
    super.dispose();
  }

  /// Serialised reads: one RandomAccessFile, many async callers.
  Future<Uint8List> _read(int off, int n) {
    final c = Completer<Uint8List>();
    _chain = _chain.then((_) async {
      try {
        await raf!.setPosition(off);
        c.complete(await raf!.read(n));
      } catch (e) {
        if (!c.isCompleted) c.completeError(e);
      }
    });
    return c.future;
  }

  Uint8List? _page(int pi) {
    final c = cache[pi];
    if (c != null) return c;
    if (raf != null && loading.add(pi)) _load(pi);
    return null;
  }

  Future<void> _load(int pi) async {
    try {
      final b = await _read(pi * pageSize, pageSize);
      cache[pi] = b;
      if (cache.length > 64) {
        final far = cache.keys.reduce((a, b) => (a - pi).abs() > (b - pi).abs() ? a : b);
        cache.remove(far);
      }
    } catch (_) {}
    loading.remove(pi);
    if (mounted) setState(() {});
  }

  static String _h(int v, int w) => v.toRadixString(16).padLeft(w, '0');

  Widget _row(int r, TextStyle mono, Color dim, Color accent) {
    final off = r * perRow;
    final data = _page(off ~/ pageSize);
    final hex = StringBuffer(), asc = StringBuffer();
    final n = (len - off).clamp(0, perRow);
    for (var i = 0; i < perRow; i++) {
      final bi = off % pageSize + i;
      if (data != null && i < n && bi < data.length) {
        final b = data[bi];
        hex.write('${_h(b, 2)} ');
        asc.write(b >= 32 && b < 127 ? String.fromCharCode(b) : '·');
      } else {
        hex.write(data == null && i < n ? '·· ' : '   ');
      }
      if (i == 7) hex.write(' ');
    }
    final hit = matchStart >= 0 && off < matchStart + matchLen && off + perRow > matchStart;
    return Container(
      color: hit ? Colors.amber.withOpacity(.22) : null,
      alignment: Alignment.centerLeft,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Text.rich(
        TextSpan(style: mono, children: [
          TextSpan(text: '${_h(off, 8)}  ', style: TextStyle(color: dim)),
          TextSpan(text: '$hex '),
          TextSpan(text: asc.toString(), style: TextStyle(color: accent)),
        ]),
        maxLines: 1,
        softWrap: false,
      ),
    );
  }

  int? _parseOffset(String s) {
    s = s.trim().toLowerCase();
    if (s.isEmpty) return null;
    if (s.startsWith('0x')) return int.tryParse(s.substring(2), radix: 16);
    return int.tryParse(s) ?? int.tryParse(s, radix: 16);
  }

  void _jump(int off) {
    off = off.clamp(0, len == 0 ? 0 : len - 1);
    if (!sc.hasClients) return;
    sc.jumpTo((off ~/ perRow * rowH).clamp(0, sc.position.maxScrollExtent).toDouble());
  }

  Future<void> _goto() async {
    final s = await promptText(context, '${L.t('goTo')} (0x… / ${L.t('decimal')})');
    if (s == null) return;
    final o = _parseOffset(s);
    if (o == null || o < 0) { if (mounted) snack(context, L.t('invalidInput')); return; }
    _jump(o);
  }

  List<int>? _parsePattern(String s, bool hex) {
    if (s.isEmpty) return null;
    if (!hex) return utf8.encode(s);
    final h = s.replaceAll(RegExp(r'(0x|\s|,)', caseSensitive: false), '');
    if (h.isEmpty || h.length.isOdd || !RegExp(r'^[0-9a-fA-F]+$').hasMatch(h)) return null;
    return [for (var i = 0; i < h.length; i += 2) int.parse(h.substring(i, i + 2), radix: 16)];
  }

  Future<void> _search() async {
    final ctl = TextEditingController();
    var hexMode = false;
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text(L.t('find')),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: ctl, autofocus: true, decoration: InputDecoration(hintText: hexMode ? 'DE AD BE EF' : L.t('find'))),
            const SizedBox(height: 10),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              ChoiceChip(label: Text(L.t('hexText')), selected: !hexMode, onSelected: (_) => set(() => hexMode = false)),
              const SizedBox(width: 8),
              ChoiceChip(label: Text(L.t('hexBytes')), selected: hexMode, onSelected: (_) => set(() => hexMode = true)),
            ]),
          ]),
          actions: [
            CancelButton(onPressed: () => Navigator.pop(c, false)),
            FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(L.t('ok'))),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final pat = _parsePattern(ctl.text, hexMode);
    if (pat == null) { if (mounted) snack(context, L.t('invalidInput')); return; }
    lastPat = pat;
    matchStart = -1;
    await _next(fromTop: false);
  }

  static int _indexOf(Uint8List b, List<int> pat) {
    final first = pat[0];
    for (var i = 0; i + pat.length <= b.length; i++) {
      if (b[i] != first) continue;
      var j = 1;
      while (j < pat.length && b[i + j] == pat[j]) { j++; }
      if (j == pat.length) return i;
    }
    return -1;
  }

  Future<int> _findFrom(List<int> pat, int from, int to) async {
    const chunk = 1 << 16;
    var pos = from;
    while (pos < to) {
      final b = await _read(pos, chunk + pat.length - 1);
      if (b.length < pat.length) break;
      final i = _indexOf(b, pat);
      if (i >= 0) return pos + i;
      pos += chunk;
    }
    return -1;
  }

  Future<void> _next({bool fromTop = false}) async {
    final pat = lastPat;
    if (pat == null || raf == null) return;
    var start = matchStart >= 0 ? matchStart + 1 : curOff.value;
    if (fromTop) start = 0;
    var hit = -1;
    await busy(context, () async {
      hit = await _findFrom(pat, start, len);
      if (hit < 0 && start > 0) hit = await _findFrom(pat, 0, start);
    });
    if (!mounted) return;
    if (hit < 0) { snack(context, L.t('notFound')); return; }
    setState(() { matchStart = hit; matchLen = pat.length; });
    _jump(hit);
  }

  @override
  Widget build(BuildContext context) {
    final th = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 16)),
        actions: [
          IconButton(icon: const Icon(Icons.search_rounded), tooltip: L.t('find'), onPressed: raf == null ? null : _search),
          if (lastPat != null) IconButton(icon: const Icon(Icons.navigate_next_rounded), tooltip: L.t('findNext'), onPressed: _next),
          IconButton(icon: const Icon(Icons.pin_drop_outlined), tooltip: L.t('goTo'), onPressed: raf == null ? null : _goto),
          IconButton(icon: const Icon(Icons.delete_outline_rounded), tooltip: L.t('delete'), onPressed: () async { if (await deleteFromViewer(context, widget.path) && mounted) Navigator.pop(context); }),
        ],
      ),
      body: raf == null
          ? const Center(child: CircularProgressIndicator())
          : len == 0
              ? Center(child: Text(L.t('empty')))
              : Column(children: [
                  Expanded(
                    child: LayoutBuilder(builder: (c, box) {
                      final fs = ((box.maxWidth - 16) / (77 * .6)).clamp(7.0, 15.0);
                      rowH = fs * 1.5;
                      final mono = TextStyle(fontFamily: 'monospace', fontSize: fs, height: 1.0, color: th.textTheme.bodyMedium?.color);
                      return ListView.builder(
                        controller: sc,
                        itemExtent: rowH,
                        itemCount: (len + perRow - 1) ~/ perRow,
                        itemBuilder: (_, r) => _row(r, mono, th.hintColor, th.colorScheme.primary),
                      );
                    }),
                  ),
                  Container(
                    width: double.infinity,
                    color: th.cardColor,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    child: ValueListenableBuilder<int>(
                      valueListenable: curOff,
                      builder: (_, o, __) => Text(
                        '0x${o.toRadixString(16).toUpperCase()}  /  $o  •  ${FileOps.fmt(len)} ($len B)',
                        style: const TextStyle(fontFamily: 'monospace', fontSize: 11),
                      ),
                    ),
                  ),
                ]),
    );
  }
}
