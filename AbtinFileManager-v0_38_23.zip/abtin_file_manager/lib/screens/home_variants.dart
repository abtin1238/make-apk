import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/layout_scope.dart';
import '../core/layouts.dart';
import '../core/settings.dart';
import '../core/theme.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../widgets/adaptive_nav.dart';
import '../widgets/file_thumb.dart';
import '../widgets/ui.dart';
import 'analyzer_screen.dart';
import 'browser_screen.dart';
import 'home_cats.dart';
import 'opener.dart';
import 'search_screen.dart';

// ------------------------------------------------------------------ shared helpers

void _go(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));

String _rootName(StorageRoot r) => r.sd ? '${L.t('sdcard')} (${r.name})' : L.t('internal');

IconData _chev(BuildContext c) => Directionality.of(c) == TextDirection.rtl ? Icons.chevron_left_rounded : Icons.chevron_right_rounded;

/// Gives [builder] the total / used bytes of a storage volume (0 while loading).
class StorageBuilder extends StatelessWidget {
  final StorageRoot root;
  final Widget Function(int total, int used) builder;
  const StorageBuilder({super.key, required this.root, required this.builder});
  @override
  Widget build(BuildContext context) => FutureBuilder<List<int>>(
        future: Native.storage(root.path),
        builder: (c, snap) {
          final t = snap.data?[0] ?? 0, f = snap.data?[1] ?? 0;
          return builder(t, t - f);
        },
      );
}

List<FItem> _recentItems(AppSettings s, int max) {
  final out = <FItem>[];
  for (final p in s.recents) {
    if (out.length >= max) break;
    try {
      final f = File(p);
      if (!f.existsSync()) continue;
      final st = f.statSync();
      out.add(FItem(f, false, st.size, st.modified));
    } catch (_) {}
  }
  return out;
}

Widget _section(String text) => Padding(
      padding: const EdgeInsets.only(top: 18, bottom: 8),
      child: Text(text, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
    );

Widget _colorBadge(HomeCat c, {double size = 40, double radius = 12}) => Container(
      width: size, height: size,
      decoration: BoxDecoration(color: c.color.withOpacity(.16), borderRadius: BorderRadius.circular(radius)),
      child: Icon(c.icon, color: c.color, size: size * .55),
    );

// ------------------------------------------------------------------ DASHBOARD

/// Big storage card, quick chips, recent files carousel, 2-column category tiles.
class DashboardHome extends StatelessWidget {
  const DashboardHome({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final cs = Theme.of(context).colorScheme;
    final cats = homeCats();
    final roots = FileOps.roots();
    final quick = [for (final k in const ['images', 'videos', 'music', 'docs', 'downloads', 'apps']) homeCat(cats, k)].whereType<HomeCat>().toList();
    final recents = _recentItems(s, 14);
    final wide = MediaQuery.of(context).size.width >= 600;
    return SafeArea(
      child: MaxWidth(
        width: 960,
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 24), children: [
          Row(children: [
            const Expanded(child: Text('Abtin File Manager', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
            IconButton(icon: const Icon(Icons.search_rounded), onPressed: () => _go(context, const SearchScreen())),
          ]),
          const SizedBox(height: 10),
          if (roots.isNotEmpty)
            Material(
              borderRadius: BorderRadius.circular(28),
              clipBehavior: Clip.antiAlias,
              child: Ink(
                decoration: BoxDecoration(gradient: LinearGradient(colors: [cs.primary, cs.secondary], begin: Alignment.topLeft, end: Alignment.bottomRight)),
                child: InkWell(
                  onTap: () => _go(context, BrowserScreen(initialPath: roots.first.path, root: true)),
                  child: Padding(
                    padding: const EdgeInsets.all(18),
                    child: Column(children: [
                      StorageBuilder(
                        root: roots.first,
                        builder: (t, used) {
                          final ratio = t == 0 ? 0.0 : (used / t).clamp(0.0, 1.0).toDouble();
                          return Row(children: [
                            SizedBox(
                              width: 104, height: 104,
                              child: Stack(fit: StackFit.expand, children: [
                                CircularProgressIndicator(value: ratio, strokeWidth: 10, backgroundColor: Colors.white24, color: Colors.white),
                                Center(child: Text('${(ratio * 100).round()}%', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold))),
                              ]),
                            ),
                            const SizedBox(width: 18),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(_rootName(roots.first), style: const TextStyle(color: Colors.white70, fontSize: 13)),
                                const SizedBox(height: 4),
                                Text(t == 0 ? '…' : FileOps.fmt(used), style: const TextStyle(color: Colors.white, fontSize: 26, fontWeight: FontWeight.bold)),
                                const SizedBox(height: 4),
                                Text(t == 0 ? '' : '${tr2('از', 'of')} ${FileOps.fmt(t)} • ${tr2('آزاد', 'free')} ${FileOps.fmt(t - used)}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                              ]),
                            ),
                          ]);
                        },
                      ),
                      for (final r in roots.skip(1))
                        Padding(
                          padding: const EdgeInsets.only(top: 14),
                          child: InkWell(
                            onTap: () => _go(context, BrowserScreen(initialPath: r.path, root: true)),
                            child: StorageBuilder(
                              root: r,
                              builder: (t, used) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Row(children: [
                                  const Icon(Icons.sd_card_rounded, color: Colors.white, size: 18),
                                  const SizedBox(width: 8),
                                  Expanded(child: Text(_rootName(r), style: const TextStyle(color: Colors.white, fontSize: 13))),
                                  Text(t == 0 ? '' : '${FileOps.fmt(used)} / ${FileOps.fmt(t)}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
                                ]),
                                const SizedBox(height: 6),
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(6),
                                  child: LinearProgressIndicator(value: t == 0 ? 0 : used / t, minHeight: 6, backgroundColor: Colors.white24, color: Colors.white),
                                ),
                              ]),
                            ),
                          ),
                        ),
                    ]),
                  ),
                ),
              ),
            ),
          const SizedBox(height: 14),
          SizedBox(
            height: 42,
            child: ListView(scrollDirection: Axis.horizontal, children: [
              for (final c in quick)
                Padding(
                  padding: const EdgeInsetsDirectional.only(end: 8),
                  child: ActionChip(
                    avatar: Icon(c.icon, color: c.color, size: 18),
                    label: Text(L.t(c.key)),
                    onPressed: () => _go(context, c.page),
                  ),
                ),
            ]),
          ),
          if (recents.isNotEmpty) ...[
            _section(tr2('اخیراً باز شده', 'Recently opened')),
            SizedBox(
              height: 112,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: recents.length,
                itemBuilder: (c, i) {
                  final it = recents[i];
                  return GestureDetector(
                    onTap: () => Opener.open(context, it.path, siblings: [for (final r in recents) r.path]),
                    child: Container(
                      width: 84,
                      margin: const EdgeInsetsDirectional.only(end: 10),
                      child: Column(children: [
                        ClipRRect(borderRadius: BorderRadius.circular(14), child: FileThumb(item: it, size: 80)),
                        const SizedBox(height: 6),
                        Text(it.name, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5, height: 1.15)),
                      ]),
                    ),
                  );
                },
              ),
            ),
          ],
          _section(tr2('دسته‌ها', 'Categories')),
          GridView.count(
            crossAxisCount: wide ? 3 : 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: 2.7,
            children: [
              for (final c in cats)
                GradCard(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  onTap: () => _go(context, c.page),
                  child: Row(children: [
                    _colorBadge(c, size: 38),
                    const SizedBox(width: 10),
                    Expanded(child: Text(L.t(c.key), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600))),
                  ]),
                ),
            ],
          ),
          const SizedBox(height: 10),
          GradCard(
            onTap: () => _go(context, const AnalyzerScreen()),
            child: Row(children: [
              const Icon(Icons.pie_chart_rounded, color: AppColors.blue),
              const SizedBox(width: 12),
              Text(L.t('analyzer')),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ------------------------------------------------------------------ LIST (drawer layout)

/// Plain vertical list: storage rows on top, then one row per category.
class ListHome extends StatelessWidget {
  const ListHome({super.key});

  @override
  Widget build(BuildContext context) {
    final cats = homeCats();
    return SafeArea(
      child: MaxWidth(
        width: 720,
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 6, 4, 0),
            child: Row(children: [
              menuLeading(context) ?? const SizedBox(width: 12),
              const Expanded(child: Text('Abtin File Manager', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
              IconButton(icon: const Icon(Icons.search_rounded), onPressed: () => _go(context, const SearchScreen())),
            ]),
          ),
          Expanded(
            child: ListView(padding: const EdgeInsets.only(bottom: 24), children: [
              for (final r in FileOps.roots())
                StorageBuilder(
                  root: r,
                  builder: (t, used) => ListTile(
                    leading: Icon(r.sd ? Icons.sd_card_rounded : Icons.smartphone_rounded, color: AppColors.blue),
                    title: Text(_rootName(r), style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: t == 0 ? 0 : used / t, minHeight: 6)),
                        const SizedBox(height: 4),
                        Text(t == 0 ? '' : '${FileOps.fmt(used)} / ${FileOps.fmt(t)}', style: const TextStyle(fontSize: 11)),
                      ]),
                    ),
                    trailing: Icon(_chev(context)),
                    onTap: () => _go(context, BrowserScreen(initialPath: r.path, root: true)),
                  ),
                ),
              const Divider(height: 24),
              for (final c in cats)
                ListTile(
                  leading: _colorBadge(c, size: 38, radius: 10),
                  title: Text(L.t(c.key)),
                  trailing: Icon(_chev(context)),
                  onTap: () => _go(context, c.page),
                ),
              ListTile(
                leading: Container(
                  width: 38, height: 38,
                  decoration: BoxDecoration(color: AppColors.blue.withOpacity(.16), borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.pie_chart_rounded, color: AppColors.blue, size: 21),
                ),
                title: Text(L.t('analyzer')),
                trailing: Icon(_chev(context)),
                onTap: () => _go(context, const AnalyzerScreen()),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ------------------------------------------------------------------ SECTIONS (rail layout)

/// Dense explorer-style home: collapsible sections with small rows.
class SectionsHome extends StatelessWidget {
  const SectionsHome({super.key});

  Widget _row(BuildContext context, HomeCat c) => ListTile(
        dense: true,
        visualDensity: VisualDensity.compact,
        leading: Icon(c.icon, color: c.color, size: 20),
        title: Text(L.t(c.key), style: const TextStyle(fontSize: 13)),
        trailing: Icon(_chev(context), size: 18),
        onTap: () => _go(context, c.page),
      );

  Widget _group(BuildContext context, String title, List<Widget> kids) => ExpansionTile(
        initiallyExpanded: true,
        shape: const Border(),
        collapsedShape: const Border(),
        tilePadding: const EdgeInsets.symmetric(horizontal: 16),
        title: Text(title, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)),
        children: kids,
      );

  @override
  Widget build(BuildContext context) {
    final cats = homeCats();
    List<Widget> rows(List<String> keys) => [for (final k in keys) if (homeCat(cats, k) != null) _row(context, homeCat(cats, k)!)];
    return SafeArea(
      child: MaxWidth(
        width: 720,
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 4, 0),
            child: Row(children: [
              const Expanded(child: Text('Abtin File Manager', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold))),
              IconButton(icon: const Icon(Icons.search_rounded), onPressed: () => _go(context, const SearchScreen())),
            ]),
          ),
          Expanded(
            child: ListView(padding: const EdgeInsets.only(bottom: 24), children: [
              _group(context, tr2('حافظه', 'Storage'), [
                for (final r in FileOps.roots())
                  StorageBuilder(
                    root: r,
                    builder: (t, used) => ListTile(
                      dense: true,
                      visualDensity: VisualDensity.compact,
                      leading: Icon(r.sd ? Icons.sd_card_rounded : Icons.smartphone_rounded, color: AppColors.blue, size: 20),
                      title: Text(_rootName(r), style: const TextStyle(fontSize: 13)),
                      subtitle: Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: ClipRRect(borderRadius: BorderRadius.circular(4), child: LinearProgressIndicator(value: t == 0 ? 0 : used / t, minHeight: 4)),
                      ),
                      trailing: Text(t == 0 ? '' : '${(used * 100 / t).round()}%', style: const TextStyle(fontSize: 12)),
                      onTap: () => _go(context, BrowserScreen(initialPath: r.path, root: true)),
                    ),
                  ),
              ]),
              _group(context, tr2('کتابخانه', 'Library'), rows(const ['images', 'videos', 'music', 'docs', 'apps', 'archives'])),
              _group(context, tr2('اسناد', 'Documents'), rows(const ['word', 'pdf', 'text', 'media'])),
              _group(context, tr2('مکان‌ها', 'Places'), rows(const ['downloads', 'favorites', 'recents', 'trash'])),
              ListTile(
                dense: true,
                visualDensity: VisualDensity.compact,
                leading: const Icon(Icons.pie_chart_rounded, color: AppColors.blue, size: 20),
                title: Text(L.t('analyzer'), style: const TextStyle(fontSize: 13)),
                trailing: Icon(_chev(context), size: 18),
                onTap: () => _go(context, const AnalyzerScreen()),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ------------------------------------------------------------------ LAUNCHER (top tabs layout)

/// Phone-launcher look: search pill, slim storage lines, big round icons without cards.
class LauncherHome extends StatelessWidget {
  const LauncherHome({super.key});

  @override
  Widget build(BuildContext context) {
    final cats = [...homeCats(), const HomeCat(Icons.pie_chart_rounded, 'analyzer', AppColors.blue, AnalyzerScreen())];
    final cols = (MediaQuery.of(context).size.width ~/ 92).clamp(4, 8);
    final card = Theme.of(context).cardColor;
    return SafeArea(
      child: MaxWidth(
        width: 720,
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 10, 16, 24), children: [
          InkWell(
            borderRadius: BorderRadius.circular(28),
            onTap: () => _go(context, const SearchScreen()),
            child: Container(
              height: 52,
              padding: const EdgeInsets.symmetric(horizontal: 18),
              decoration: BoxDecoration(color: card, borderRadius: BorderRadius.circular(28)),
              child: Row(children: [
                const Icon(Icons.search_rounded),
                const SizedBox(width: 10),
                Expanded(child: Text(tr2('جستجو در فایل‌ها', 'Search files'), style: TextStyle(color: Theme.of(context).hintColor))),
              ]),
            ),
          ),
          const SizedBox(height: 16),
          for (final r in FileOps.roots())
            InkWell(
              onTap: () => _go(context, BrowserScreen(initialPath: r.path, root: true)),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: StorageBuilder(
                  root: r,
                  builder: (t, used) => Row(children: [
                    Icon(r.sd ? Icons.sd_card_rounded : Icons.smartphone_rounded, size: 18),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(_rootName(r), style: const TextStyle(fontSize: 12)),
                        const SizedBox(height: 4),
                        ClipRRect(borderRadius: BorderRadius.circular(4), child: LinearProgressIndicator(value: t == 0 ? 0 : used / t, minHeight: 5)),
                      ]),
                    ),
                    const SizedBox(width: 10),
                    Text(t == 0 ? '' : '${(used * 100 / t).round()}%', style: const TextStyle(fontSize: 12)),
                  ]),
                ),
              ),
            ),
          const SizedBox(height: 18),
          GridView.count(
            crossAxisCount: cols,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 14,
            crossAxisSpacing: 6,
            childAspectRatio: .82,
            children: [
              for (final c in cats)
                InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => _go(context, c.page),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Container(
                      width: 58, height: 58,
                      decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [c.color.withOpacity(.30), c.color.withOpacity(.12)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
                      child: Icon(c.icon, color: c.color, size: 28),
                    ),
                    const SizedBox(height: 6),
                    Text(L.t(c.key), maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, height: 1.15)),
                  ]),
                ),
            ],
          ),
        ]),
      ),
    );
  }
}
