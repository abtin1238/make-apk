import 'package:flutter/material.dart';
import '../widgets/adaptive_nav.dart';
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/layout_scope.dart';
import '../core/layouts.dart';
import '../core/settings.dart';
import '../core/theme.dart';
import 'analyzer_screen.dart';
import 'duplicates_screen.dart';
import 'button_style_screen.dart';
import 'icon_style_screen.dart';
import 'layout_style_screen.dart';
import 'path_list_screen.dart';
import 'trash_screen.dart';
import 'saf_prompt.dart';
import 'security_screen.dart';
import '../services/file_ops.dart';
import '../services/saf.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return Scaffold(
      appBar: AppBar(leading: menuLeading(context), title: Text(L.t('settings'))),
      body: MaxWidth(child: ListView(children: [
        SwitchListTile(secondary: const Icon(Icons.dark_mode_rounded), title: Text(L.t('dark')), value: s.dark, onChanged: s.setDark),
        ListTile(
          leading: const Icon(Icons.color_lens_rounded),
          title: Text(L.t('themeStyle')),
          subtitle: Text(L.lang == 'fa' ? appPalettes[s.themeId.clamp(0, appPalettes.length - 1)].fa : appPalettes[s.themeId.clamp(0, appPalettes.length - 1)].en),
          trailing: Container(width: 22, height: 22, decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [appPalettes[s.themeId.clamp(0, appPalettes.length - 1)].primary, appPalettes[s.themeId.clamp(0, appPalettes.length - 1)].secondary]))),
          onTap: () => _pickTheme(context, s),
        ),
        ListTile(
          leading: const Icon(Icons.dashboard_customize_rounded),
          title: Text(tr2('چیدمان و ساختار برنامه', 'App layout')),
          subtitle: Text('${layoutById(s.layoutId).name} — ${layoutById(s.layoutId).desc}', maxLines: 2, overflow: TextOverflow.ellipsis),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LayoutStyleScreen())),
        ),
        ListTile(
          leading: const Icon(Icons.smart_button_rounded),
          title: Text(L.t('buttonStyle')),
          subtitle: Text(L.t('buttonStyleSub')),
          trailing: Container(width: 22, height: 22, decoration: BoxDecoration(shape: BoxShape.circle, color: s.btnColor != 0 ? Color(s.btnColor) : Theme.of(context).colorScheme.primary)),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ButtonStyleScreen())),
        ),
        ListTile(
          leading: const Icon(Icons.language_rounded),
          title: Text(L.t('language')),
          trailing: DropdownButton<String>(
            value: L.lang,
            underline: const SizedBox(),
            items: [for (final c in L.langs) DropdownMenuItem(value: c, child: Text(L.nameOf(c)))],
            onChanged: (v) => s.setLang(v!),
          ),
        ),
        SwitchListTile(secondary: const Icon(Icons.splitscreen_rounded), title: Text(L.t('dual')), subtitle: Text(L.t('dualSub')), value: s.dual, onChanged: s.setDual),
        ListTile(leading: const Icon(Icons.palette_rounded), title: Text(L.t('iconStyle')), subtitle: Text(L.t('iconStyleSub')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const IconStyleScreen()))),
        SwitchListTile(secondary: const Icon(Icons.visibility_rounded), title: Text(L.t('hidden')), value: s.showHidden, onChanged: s.setHidden),
        SwitchListTile(secondary: const Icon(Icons.warning_amber_rounded), title: Text(L.t('confirmDelete')), value: s.confirmDelete, onChanged: s.setConfirm),
        SwitchListTile(secondary: const Icon(Icons.sync_rounded), title: Text(L.t('bgCopy')), subtitle: Text(L.t('bgCopySub')), value: s.bgCopy, onChanged: s.setBgCopy),
        SwitchListTile(secondary: const Icon(Icons.folder_special_rounded), title: Text(L.t('folderSizes')), subtitle: Text(L.t('folderSizesSub')), value: s.folderSizes, onChanged: s.setFolderSizes),
        SwitchListTile(secondary: const Icon(Icons.delete_outline_rounded), title: Text(L.t('trash')), subtitle: Text(L.t('trashSub')), value: s.trashEnabled, onChanged: s.setTrash),
        ListTile(leading: const Icon(Icons.restore_from_trash_rounded), title: Text(L.t('trash')), subtitle: Text(L.t('trashOpen')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TrashScreen()))),
        ListTile(leading: const Icon(Icons.shield_rounded), title: Text(L.t('security')), subtitle: Text(L.t('securitySub')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SecurityScreen()))),
        for (final r in FileOps.roots().where((r) => r.sd)) _SdTile(root: r),
        const Divider(),
        ListTile(leading: const Icon(Icons.pie_chart_rounded), title: Text(L.t('analyzer')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AnalyzerScreen()))),
        ListTile(leading: const Icon(Icons.content_copy_rounded), title: Text(L.t('dupFinder')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DuplicatesScreen()))),
        ListTile(leading: const Icon(Icons.star_rounded), title: Text(L.t('favorites')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PathListScreen(title: L.t('favorites'), fav: true)))),
        ListTile(leading: const Icon(Icons.history_rounded), title: Text(L.t('recents')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PathListScreen(title: L.t('recents'), fav: false)))),
        const Divider(),
        ListTile(leading: const Icon(Icons.info_outline_rounded), title: Text(L.t('about')), subtitle: const Text('Abtin File Manager 0.30.0')),
      ])),
    );
  }
}

void _pickTheme(BuildContext context, AppSettings s) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(L.t('themeStyle'), style: Theme.of(ctx).textTheme.titleMedium),
          const SizedBox(height: 14),
          Wrap(spacing: 12, runSpacing: 14, children: [
            for (var i = 0; i < appPalettes.length; i++)
              GestureDetector(
                onTap: () { s.setThemeId(i); Navigator.pop(ctx); },
                child: SizedBox(
                  width: 76,
                  child: Column(children: [
                    Container(
                      width: 56, height: 56,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(colors: [appPalettes[i].primary, appPalettes[i].secondary], begin: Alignment.topLeft, end: Alignment.bottomRight),
                        border: Border.all(color: i == s.themeId ? Theme.of(ctx).colorScheme.onSurface : Colors.transparent, width: 3),
                      ),
                      child: i == s.themeId ? const Icon(Icons.check_rounded, color: Colors.white) : null,
                    ),
                    const SizedBox(height: 6),
                    Text(L.lang == 'fa' ? appPalettes[i].fa : appPalettes[i].en, style: const TextStyle(fontSize: 12), maxLines: 1, overflow: TextOverflow.ellipsis),
                  ]),
                ),
              ),
          ]),
        ]),
      ),
    ),
  );
}

class _SdTile extends StatefulWidget {
  final StorageRoot root;
  const _SdTile({required this.root});
  @override
  State<_SdTile> createState() => _SdTileState();
}

class _SdTileState extends State<_SdTile> {
  Future<int> _state() async {
    // 0 = not needed, 1 = granted, 2 = needs access
    if (!await Saf.needsSaf(widget.root.path)) return 0;
    return await Saf.has(Saf.volumeOf(widget.root.path)!) ? 1 : 2;
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<int>(
        future: _state(),
        builder: (c, snap) => ListTile(
          leading: const Icon(Icons.sd_card_rounded),
          title: Text('${L.t('sdAccess')} (${widget.root.name})'),
          subtitle: Text(snap.data == 1 ? L.t('sdGranted') : snap.data == 2 ? L.t('sdNotGranted') : L.t('sdDirect')),
          onTap: snap.data == 0 || snap.data == null
              ? null
              : () async {
                  await manageSdAccess(context, widget.root.path);
                  if (mounted) setState(() {});
                },
        ),
      );
}
