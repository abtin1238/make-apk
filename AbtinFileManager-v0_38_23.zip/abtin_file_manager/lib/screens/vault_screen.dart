import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/vault_service.dart';
import '../widgets/ui.dart';
import 'opener.dart';

class VaultScreen extends StatefulWidget {
  /// Close the screen as soon as the vault is open (used by "Move to vault" in the file browser).
  final bool popOnUnlock;
  const VaultScreen({super.key, this.popOnUnlock = false});
  @override
  State<VaultScreen> createState() => _VaultScreenState();
}

class _VaultScreenState extends State<VaultScreen> {
  final pw = TextEditingController(), pw2 = TextEditingController();
  bool hide = true, working = false;
  String? err;

  @override
  void initState() {
    super.initState();
    if (VaultService.unlocked && widget.popOnUnlock) {
      WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) Navigator.pop(context); });
    }
  }

  @override
  void dispose() {
    pw.dispose();
    pw2.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final creating = !VaultService.exists;
    if (creating) {
      if (pw.text.length < 6) return setState(() => err = L.t('vaultPwShort'));
      if (pw.text != pw2.text) return setState(() => err = L.t('vaultPwMismatch'));
    } else if (pw.text.isEmpty) {
      return;
    }
    setState(() { working = true; err = null; });
    try {
      if (creating) {
        await VaultService.create(pw.text);
      } else if (!await VaultService.unlock(pw.text)) {
        if (mounted) setState(() => err = L.t('vaultWrongPw'));
        return;
      }
      pw.clear();
      pw2.clear();
      if (!mounted) return;
      if (widget.popOnUnlock) {
        Navigator.pop(context);
      } else {
        setState(() {});
      }
    } catch (e) {
      if (mounted) setState(() => err = '${L.t('error')}: $e');
    } finally {
      if (mounted) setState(() => working = false);
    }
  }

  Future<void> _changePw() async {
    final o = TextEditingController(), n = TextEditingController();
    final go = await showDialog<bool>(
      context: context,
      builder: (dc) => AlertDialog(
        title: Text(L.t('changePassword')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: o, obscureText: true, decoration: InputDecoration(labelText: L.t('oldPassword'))),
          const SizedBox(height: 10),
          TextField(controller: n, obscureText: true, decoration: InputDecoration(labelText: L.t('newPassword'))),
        ]),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(dc, false)),
          FilledButton(onPressed: () => Navigator.pop(dc, true), child: Text(L.t('ok'))),
        ],
      ),
    );
    final oldPw = o.text, newPw = n.text;
    o.dispose();
    n.dispose();
    if (go != true || !mounted) return;
    if (newPw.length < 6) return snack(context, L.t('vaultPwShort'));
    try {
      final ok = await VaultService.changePassword(oldPw, newPw);
      if (mounted) snack(context, ok ? L.t('vaultChanged') : L.t('vaultWrongPw'));
    } catch (e) {
      if (mounted) snack(context, '${L.t('error')}: $e');
    }
  }

  Future<void> _lock() async {
    await VaultService.lock();
    if (mounted) setState(() {});
  }

  Future<void> _open(VaultEntry e) async {
    String? tmp;
    final ok = await busy(context, () async { tmp = await VaultService.openTemp(e); });
    if (!ok || tmp == null || !mounted) return;
    final path = tmp!;
    final before = File(path).lastModifiedSync();
    await Opener.open(context, path, onChanged: () async {
      // runs when the viewer / editor is closed: offer to keep edits
      try {
        if (!VaultService.unlocked || !File(path).existsSync()) return;
        if (!File(path).lastModifiedSync().isAfter(before)) return;
        if (!mounted) return;
        if (await confirm(context, L.t('vaultSaveChanges'))) {
          if (mounted) await busy(context, () => VaultService.updateFrom(e, path));
          if (mounted) setState(() {});
        }
      } catch (_) {}
    });
  }

  Future<void> _restore(List<VaultEntry> l) async {
    final ok = await busy(context, () async {
      for (final e in List.of(l)) {
        await VaultService.restore(e);
      }
    });
    if (!mounted) return;
    setState(() {});
    if (ok) snack(context, L.t('restored'));
  }

  Future<void> _delete(VaultEntry e) async {
    if (!await confirm(context, '${L.t('vaultDeleteAsk')}\n${e.name}')) return;
    if (!mounted) return;
    await busy(context, () => VaultService.remove(e));
    if (mounted) setState(() {});
  }

  Widget _form() {
    final creating = !VaultService.exists;
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.enhanced_encryption_rounded, size: 72),
          const SizedBox(height: 16),
          if (creating) ...[
            Card(
              color: Theme.of(context).colorScheme.errorContainer,
              child: Padding(padding: const EdgeInsets.all(12), child: Text(L.t('vaultWarn'), style: TextStyle(color: Theme.of(context).colorScheme.onErrorContainer))),
            ),
            const SizedBox(height: 16),
          ],
          TextField(
            controller: pw, obscureText: hide, autofocus: true,
            decoration: InputDecoration(
              labelText: L.t('vaultPw'),
              suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility_rounded : Icons.visibility_off_rounded), onPressed: () => setState(() => hide = !hide)),
            ),
            onSubmitted: (_) => creating ? null : _submit(),
          ),
          if (creating) ...[
            const SizedBox(height: 12),
            TextField(controller: pw2, obscureText: hide, decoration: InputDecoration(labelText: L.t('vaultPwConfirm')), onSubmitted: (_) => _submit()),
          ],
          SizedBox(height: 28, child: err == null ? null : Padding(padding: const EdgeInsets.only(top: 8), child: Text(err!, style: TextStyle(color: Theme.of(context).colorScheme.error)))),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: working ? null : _submit,
            child: working
                ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : Text(creating ? L.t('vaultCreate') : L.t('vaultUnlock')),
          ),
        ]),
      ),
    );
  }

  Widget _list() {
    final l = VaultService.entries;
    if (l.isEmpty) {
      return Center(child: Padding(padding: const EdgeInsets.all(32), child: Text(L.t('vaultEmpty'), textAlign: TextAlign.center)));
    }
    return ListView.builder(
      itemCount: l.length,
      itemBuilder: (c, i) {
        final e = l[i];
        return ListTile(
          leading: Icon(iconFor(e.name, false), color: colorFor(e.name, false)),
          title: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text('${FileOps.fmt(e.size)} • ${p.dirname(e.orig)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
          onTap: () => _open(e),
          trailing: PopupMenuButton<int>(
            onSelected: (v) => v == 0 ? _restore([e]) : _delete(e),
            itemBuilder: (_) => [
              PopupMenuItem(value: 0, child: Text(L.t('vaultRestore'))),
              PopupMenuItem(value: 1, child: Text(L.t('vaultDelete'))),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final open = VaultService.unlocked;
    return Scaffold(
      appBar: AppBar(
        title: Text(L.t('vault')),
        actions: [
          if (open) ...[
            IconButton(icon: const Icon(Icons.restore_rounded), tooltip: L.t('vaultRestoreAll'), onPressed: VaultService.entries.isEmpty ? null : () => _restore(VaultService.entries)),
            IconButton(icon: const Icon(Icons.password_rounded), tooltip: L.t('changePassword'), onPressed: _changePw),
            IconButton(icon: const Icon(Icons.lock_rounded), tooltip: L.t('vaultLock'), onPressed: _lock),
          ],
        ],
      ),
      body: open ? _list() : _form(),
    );
  }
}
