import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/app_lock.dart';
import '../core/l10n.dart';
import '../services/sec_native.dart';
import '../widgets/pin_pad.dart';
import '../widgets/ui.dart';
import 'vault_screen.dart';

/// Asks for the current PIN; true when it was entered correctly.
Future<bool> verifyPinDialog(BuildContext context, {String? title}) async {
  final lock = context.read<AppLock>();
  final r = await showDialog<bool>(
    context: context,
    builder: (dc) {
      String? err;
      return StatefulBuilder(
        builder: (dc, set) => AlertDialog(
          title: Text(title ?? L.t('currentPin')),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            SizedBox(height: 20, child: err == null ? null : Text(err!, style: TextStyle(color: Theme.of(dc).colorScheme.error))),
            const SizedBox(height: 8),
            PinEntry(
              length: lock.pinLength,
              onComplete: (pin) async {
                final res = await lock.verify(pin);
                if (res == PinResult.ok) {
                  if (dc.mounted) Navigator.pop(dc, true);
                } else if (dc.mounted) {
                  set(() => err = res == PinResult.lockedOut ? '${L.t('tooMany')} ${lock.lockoutLeft} ${L.t('sec')}' : L.t('wrongPin'));
                }
              },
            ),
          ]),
          actions: [CancelButton(onPressed: () => Navigator.pop(dc, false))],
        ),
      );
    },
  );
  return r ?? false;
}

/// Pick a PIN length, type it, type it again. Pops the PIN (or null when cancelled).
class PinSetupScreen extends StatefulWidget {
  const PinSetupScreen({super.key});
  @override
  State<PinSetupScreen> createState() => _PinSetupScreenState();
}

class _PinSetupScreenState extends State<PinSetupScreen> {
  int len = 4;
  String? first;
  String? err;
  int round = 0; // forces the keypad to reset when the length changes

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(L.t('setPin'))),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                if (first == null) ...[
                  Text(L.t('pinLength')),
                  const SizedBox(height: 8),
                  Wrap(spacing: 8, children: [
                    for (final n in const [4, 5, 6, 8])
                      ChoiceChip(label: Text('$n'), selected: len == n, onSelected: (_) => setState(() { len = n; round++; })),
                  ]),
                  const SizedBox(height: 16),
                ],
                Text(first == null ? L.t('enterNewPin') : L.t('confirmPin'), style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 8),
                SizedBox(height: 20, child: err == null ? null : Text(err!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
                const SizedBox(height: 12),
                PinEntry(
                  key: ValueKey('$round-$len-${first != null}'),
                  length: len,
                  onComplete: (pin) async {
                    if (first == null) {
                      setState(() { first = pin; err = null; });
                    } else if (pin == first) {
                      Navigator.pop(context, pin);
                    } else {
                      setState(() { first = null; err = L.t('pinMismatch'); round++; });
                    }
                  },
                ),
              ]),
            ),
          ),
        ),
      );
}

class SecurityScreen extends StatefulWidget {
  const SecurityScreen({super.key});
  @override
  State<SecurityScreen> createState() => _SecurityScreenState();
}

class _SecurityScreenState extends State<SecurityScreen> {
  int bioState = 0;

  @override
  void initState() {
    super.initState();
    Sec.bioStatus().then((v) { if (mounted) setState(() => bioState = v); });
  }

  Future<void> _toggle(AppLock l, bool on) async {
    if (on) {
      final pin = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const PinSetupScreen()));
      if (pin == null || !mounted) return;
      await l.setPin(pin);
    } else {
      if (!await verifyPinDialog(context)) return;
      await l.disable();
    }
  }

  Future<void> _change(AppLock l) async {
    if (!await verifyPinDialog(context)) return;
    if (!mounted) return;
    final pin = await Navigator.push<String>(context, MaterialPageRoute(builder: (_) => const PinSetupScreen()));
    if (pin == null) return;
    await l.setPin(pin);
    if (mounted) snack(context, L.t('saved'));
  }

  Future<void> _bio(AppLock l, bool on) async {
    if (on) {
      // make sure it really works before relying on it
      if (!await Sec.bioAuth(L.t('bioTitle'), L.t('cancel'))) return;
    }
    l.setBio(on);
  }

  String _to(int s) => s == 0 ? L.t('immediately') : s < 60 ? '$s ${L.t('sec')}' : '${s ~/ 60} ${L.t('minutes')}';

  @override
  Widget build(BuildContext context) {
    final l = context.watch<AppLock>();
    return Scaffold(
      appBar: AppBar(title: Text(L.t('security'))),
      body: ListView(children: [
        SwitchListTile(
          secondary: const Icon(Icons.lock_rounded),
          title: Text(L.t('appLock')),
          subtitle: Text(L.t('appLockSub')),
          value: l.enabled,
          onChanged: (v) => _toggle(l, v),
        ),
        if (l.enabled) ...[
          ListTile(leading: const Icon(Icons.pin_rounded), title: Text(L.t('changePin')), onTap: () => _change(l)),
          SwitchListTile(
            secondary: const Icon(Icons.fingerprint_rounded),
            title: Text(L.t('fingerprint')),
            subtitle: bioState == 1 ? null : Text(bioState == 2 ? L.t('bioNotEnrolled') : L.t('bioNone')),
            value: l.bio,
            onChanged: bioState == 1 ? (v) => _bio(l, v) : null,
          ),
          ListTile(
            leading: const Icon(Icons.timer_outlined),
            title: Text(L.t('lockAfter')),
            trailing: DropdownButton<int>(
              value: AppLock.timeouts.contains(l.timeout) ? l.timeout : 60,
              underline: const SizedBox(),
              items: [for (final s in AppLock.timeouts) DropdownMenuItem(value: s, child: Text(_to(s)))],
              onChanged: (v) => l.setTimeout(v!),
            ),
          ),
        ],
        SwitchListTile(
          secondary: const Icon(Icons.visibility_off_rounded),
          title: Text(L.t('hideRecents')),
          subtitle: Text(L.t('hideRecentsSub')),
          value: l.hideRecents,
          onChanged: l.setHideRecents,
        ),
        if (l.enabled) Padding(padding: const EdgeInsets.fromLTRB(16, 4, 16, 8), child: Text(L.t('noRecoverPin'), style: Theme.of(context).textTheme.bodySmall)),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.enhanced_encryption_rounded),
          title: Text(L.t('vault')),
          subtitle: Text(L.t('vaultSub')),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const VaultScreen())),
        ),
      ]),
    );
  }
}
