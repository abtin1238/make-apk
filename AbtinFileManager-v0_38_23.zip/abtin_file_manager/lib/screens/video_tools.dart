import 'dart:async';
import 'package:flutter/material.dart';
import 'package:media_kit/media_kit.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/cast_service.dart';
import '../services/subtitle_service.dart';
import '../widgets/ui.dart';

String _fmt(Duration d) {
  final h = d.inHours, m = d.inMinutes.remainder(60).toString().padLeft(2, '0'), s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return h > 0 ? '$h:$m:$s' : '$m:$s';
}

/// Chapter list (from mpv `chapter-list`): tap to jump.
Future<void> showChapters(BuildContext context, Player player, List<(Duration, String)> chapters) {
  final pos = player.state.position;
  var current = chapters.lastIndexWhere((c) => c.$1 <= pos);
  if (current < 0) current = 0;
  return showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    builder: (c) => SizedBox(
      height: MediaQuery.of(c).size.height * .6,
      child: Column(children: [
        ListTile(title: Text(L.t('chapters'), style: const TextStyle(fontWeight: FontWeight.bold))),
        Expanded(
          child: ListView.builder(
            itemCount: chapters.length,
            itemBuilder: (_, i) => ListTile(
              selected: i == current,
              leading: Text('${i + 1}'),
              title: Text(chapters[i].$2, maxLines: 1, overflow: TextOverflow.ellipsis),
              trailing: Text(_fmt(chapters[i].$1), style: const TextStyle(fontSize: 12)),
              onTap: () { player.seek(chapters[i].$1); Navigator.pop(c); },
            ),
          ),
        ),
      ]),
    ),
  );
}

// ---------------------------------------------------------------- subtitle download
Future<void> showSubtitleSearch(BuildContext context, Player player, String videoPath, {void Function(String msg)? onInfo}) =>
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: _SubSheet(player: player, path: videoPath, onInfo: onInfo),
      ),
    );

class _SubSheet extends StatefulWidget {
  final Player player;
  final String path;
  final void Function(String)? onInfo;
  const _SubSheet({required this.player, required this.path, this.onInfo});
  @override
  State<_SubSheet> createState() => _SubSheetState();
}

class _SubSheetState extends State<_SubSheet> {
  late final q = TextEditingController(text: SubtitleService.cleanTitle(widget.path));
  String langs = 'fa,en';
  bool busy = false;
  String? msg;
  List<SubResult> res = [];
  static const _langs = {'fa,en': 'فارسی + English', 'fa': 'فارسی', 'en': 'English', 'ar': 'العربية', 'tr': 'Türkçe', 'fr': 'Français', 'de': 'Deutsch', 'es': 'Español', 'ru': 'Русский'};

  @override
  void initState() {
    super.initState();
    SubtitleService.settings().then((s) {
      if (mounted) setState(() => langs = _langs.containsKey(s.lang) ? s.lang : 'fa,en');
    });
  }

  String _err(Object e) {
    final t = '$e';
    if (t.contains('NO_KEY')) return L.t('subNoKey');
    if (t.contains('NO_LOGIN')) return L.t('subNoLogin');
    return t;
  }

  Future<void> _search() async {
    setState(() { busy = true; msg = null; res = []; });
    try {
      final isUrl = RegExp(r'^[a-z]+://', caseSensitive: false).hasMatch(widget.path);
      final hash = isUrl ? null : await SubtitleService.movieHash(widget.path);
      var r = await SubtitleService.search(query: q.text, langs: langs, hash: hash);
      if (r.isEmpty && hash != null) r = await SubtitleService.search(query: q.text, langs: langs);
      if (mounted) setState(() { res = r; msg = r.isEmpty ? L.t('noMatches') : null; });
    } catch (e) {
      if (mounted) setState(() => msg = _err(e));
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _get(SubResult r) async {
    setState(() { busy = true; msg = null; });
    try {
      final f = await SubtitleService.download(r, widget.path);
      await widget.player.setSubtitleTrack(SubtitleTrack.uri(f, title: p.basename(f)));
      widget.onInfo?.call('${L.t('saved')}: ${p.basename(f)}');
      if (mounted) Navigator.pop(context);
      return;
    } catch (e) {
      if (mounted) setState(() => msg = _err(e));
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _account() async {
    final s = await SubtitleService.settings();
    final k = TextEditingController(text: s.key), u = TextEditingController(text: s.user), pw = TextEditingController(text: s.pass);
    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (dc) => AlertDialog(
        title: const Text('OpenSubtitles'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(L.t('subAccountHint'), style: const TextStyle(fontSize: 12)),
            const SizedBox(height: 8),
            TextField(controller: k, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'API key')),
            TextField(controller: u, textDirection: TextDirection.ltr, decoration: InputDecoration(labelText: L.t('user'))),
            TextField(controller: pw, obscureText: true, textDirection: TextDirection.ltr, decoration: InputDecoration(labelText: L.t('password'))),
          ]),
        ),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(dc, false)),
          FilledButton(onPressed: () => Navigator.pop(dc, true), child: Text(L.t('ok'))),
        ],
      ),
    );
    if (ok == true) {
      await SubtitleService.saveSettings(key: k.text, user: u.text, pass: pw.text, lang: langs);
      if (mounted) setState(() => msg = null);
    }
  }

  @override
  Widget build(BuildContext context) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(context).size.height * .7,
          child: Column(children: [
            ListTile(
              title: Text(L.t('subDownload'), style: const TextStyle(fontWeight: FontWeight.bold)),
              trailing: IconButton(icon: const Icon(Icons.manage_accounts_rounded), tooltip: 'OpenSubtitles', onPressed: _account),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(children: [
                Expanded(child: TextField(controller: q, onSubmitted: (_) => _search(), decoration: InputDecoration(labelText: L.t('search'), isDense: true))),
                const SizedBox(width: 8),
                DropdownButton<String>(
                  value: langs,
                  underline: const SizedBox(),
                  items: [for (final e in _langs.entries) DropdownMenuItem(value: e.key, child: Text(e.value, style: const TextStyle(fontSize: 13)))],
                  onChanged: (v) { if (v == null) return; setState(() => langs = v); SubtitleService.saveSettings(lang: v); },
                ),
                IconButton(icon: const Icon(Icons.search_rounded), onPressed: busy ? null : _search),
              ]),
            ),
            if (busy) const LinearProgressIndicator(),
            if (msg != null) Padding(padding: const EdgeInsets.all(12), child: Text(msg!, style: const TextStyle(color: Colors.orange))),
            Expanded(
              child: ListView.builder(
                itemCount: res.length,
                itemBuilder: (_, i) => ListTile(
                  dense: true,
                  leading: CircleAvatar(radius: 16, child: Text(res[i].lang.toUpperCase(), style: const TextStyle(fontSize: 10))),
                  title: Text(res[i].name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
                  subtitle: Text('${res[i].hashMatch ? '★ ${L.t('exactMatch')}  ' : ''}↓ ${res[i].downloads}', style: const TextStyle(fontSize: 11)),
                  trailing: const Icon(Icons.download_rounded),
                  onTap: busy ? null : () => _get(res[i]),
                ),
              ),
            ),
          ]),
        ),
      );
}

// ---------------------------------------------------------------- cast
/// Pick a TV / Chromecast and start casting the current file from the current position.
/// Returns true when casting started (the local player should then be paused).
Future<bool> showCastSheet(BuildContext context, Player player, String path, String title) async {
  final cs = CastService.I;
  cs.discover();
  final started = await showModalBottomSheet<bool>(
    context: context,
    builder: (c) => ListenableBuilder(
      listenable: cs,
      builder: (_, __) => SafeArea(
        child: SizedBox(
          height: MediaQuery.of(c).size.height * .55,
          child: Column(children: [
            ListTile(
              title: Text(L.t('cast'), style: const TextStyle(fontWeight: FontWeight.bold)),
              trailing: cs.scanning ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: cs.discover),
            ),
            if (cs.error != null) Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Text(cs.error!, style: const TextStyle(color: Colors.orange, fontSize: 12))),
            Expanded(
              child: cs.devices.isEmpty
                  ? Center(child: Text(cs.scanning ? L.t('scanning') : L.t('castNone'), textAlign: TextAlign.center))
                  : ListView(children: [
                      for (final d in cs.devices)
                        ListTile(
                          leading: Icon(d.chromecast ? Icons.cast_rounded : Icons.tv_rounded),
                          title: Text(d.name),
                          subtitle: Text('${d.chromecast ? 'Chromecast' : 'DLNA'} • ${d.host}', style: const TextStyle(fontSize: 11)),
                          onTap: () async {
                            await cs.cast(d, path, title, player.state.position);
                            if (cs.active != null && c.mounted) Navigator.pop(c, true);
                          },
                        ),
                    ]),
            ),
          ]),
        ),
      ),
    ),
  );
  return started == true;
}

/// Remote-control bar shown while casting.
class CastBar extends StatelessWidget {
  final VoidCallback onStop;
  const CastBar({super.key, required this.onStop});
  @override
  Widget build(BuildContext context) {
    final cs = CastService.I;
    return ListenableBuilder(
      listenable: cs,
      builder: (_, __) {
        final d = cs.active;
        if (d == null) return const SizedBox.shrink();
        final max = cs.duration.inMilliseconds.toDouble().clamp(1, double.infinity).toDouble();
        return Container(
          color: Colors.black87,
          padding: const EdgeInsets.fromLTRB(12, 6, 12, 6),
          child: SafeArea(
            top: false,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Row(children: [
                const Icon(Icons.cast_connected_rounded, size: 18),
                const SizedBox(width: 8),
                Expanded(child: Text('${L.t('castingTo')} ${d.name}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13))),
                IconButton(icon: const Icon(Icons.close_rounded), onPressed: onStop),
              ]),
              Row(children: [
                Text(_fmt(cs.position), style: const TextStyle(fontSize: 11)),
                Expanded(
                  child: Slider(
                    value: cs.position.inMilliseconds.toDouble().clamp(0, max).toDouble(),
                    max: max,
                    onChangeEnd: (v) => cs.seek(Duration(milliseconds: v.round())),
                    onChanged: (_) {},
                  ),
                ),
                Text(_fmt(cs.duration), style: const TextStyle(fontSize: 11)),
              ]),
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                IconButton(icon: const Icon(Icons.replay_10_rounded), onPressed: () => cs.seek(cs.position - const Duration(seconds: 10))),
                IconButton(iconSize: 40, icon: Icon(cs.playing ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded), onPressed: cs.playing ? cs.pause : cs.play),
                IconButton(icon: const Icon(Icons.forward_10_rounded), onPressed: () => cs.seek(cs.position + const Duration(seconds: 10))),
              ]),
            ]),
          ),
        );
      },
    );
  }
}
