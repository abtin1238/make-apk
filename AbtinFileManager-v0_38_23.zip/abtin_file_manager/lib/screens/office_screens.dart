import 'dart:io';
import 'package:flutter/material.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/doc_legacy.dart' show DocPara, DocRun;
import '../services/file_ops.dart';
import '../services/legacy_office.dart';
import '../services/odf_service.dart';
import '../services/rtf_doc.dart';
import '../services/native.dart';
import '../services/office_service.dart';
import '../widgets/ui.dart';

Future<String?> _editDialog(BuildContext c, String initial, {String? title}) {
  final ctl = TextEditingController(text: initial);
  return showDialog<String>(
    context: c,
    builder: (_) => AlertDialog(
      title: title == null ? null : Text(title),
      content: TextField(controller: ctl, autofocus: true, minLines: 1, maxLines: 10),
      actions: [
        CancelButton(onPressed: () => Navigator.pop(c)),
        FilledButton(onPressed: () => Navigator.pop(c, ctl.text), child: Text(L.t('ok'))),
      ],
    ),
  );
}

Future<void> _saved(BuildContext c, String target) async {
  Native.scan(target);
  if (c.mounted) snack(c, '${L.t('saved')}: ${p.basename(target)}');
}

/// .xlsx / .xlsm: sheet tabs, grid, tap a cell to edit; saving creates "<name> (edited).xlsx".
class XlsxScreen extends StatefulWidget {
  final String path;
  const XlsxScreen({super.key, required this.path});
  @override
  State<XlsxScreen> createState() => _XlsxScreenState();
}

class _XlsxScreenState extends State<XlsxScreen> {
  XlsxFile? x;
  int cur = 0;
  static const cw = 110.0, rh = 36.0, hw = 46.0;

  @override
  void initState() {
    super.initState();
    XlsxFile.open(widget.path).then((v) { if (mounted) setState(() => x = v); }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  Future<void> _edit(XSheet sh, String ref) async {
    final r = await _editDialog(context, sh.formulas.containsKey(ref) ? '=${sh.formulas[ref]}' : (sh.cells[ref] ?? ''), title: ref);
    if (r != null) setState(() => x!.setCell(sh, ref, r));
  }

  static const _fills = [0xFFF176, 0xA5D6A7, 0x90CAF9, 0xEF9A9A, 0xCE93D8, 0xFFCC80];

  Future<void> _cellMenu(XSheet sh, int c, int r) async {
    final ref = '${colName(c)}$r';
    final st = sh.styles[ref];
    Widget item(IconData ic, String t, VoidCallback f) => ListTile(dense: true, leading: Icon(ic), title: Text(t), onTap: () { Navigator.pop(context); setState(f); });
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (_) => SafeArea(
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Padding(padding: const EdgeInsets.all(12), child: Text(ref, style: const TextStyle(fontWeight: FontWeight.bold))),
            item(Icons.format_bold_rounded, L.t('bold'), () => x!.setStyle(sh, ref, bold: !(st?.bold ?? false))),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
              child: Wrap(spacing: 10, children: [
                for (final col in _fills)
                  GestureDetector(
                    onTap: () { Navigator.pop(context); setState(() => x!.setStyle(sh, ref, fill: col)); },
                    child: CircleAvatar(radius: 14, backgroundColor: Color(0xFF000000 | col)),
                  ),
                GestureDetector(
                  onTap: () { Navigator.pop(context); setState(() => x!.setStyle(sh, ref, fill: -1)); },
                  child: const CircleAvatar(radius: 14, backgroundColor: Colors.black26, child: Icon(Icons.format_color_reset_rounded, size: 16)),
                ),
              ]),
            ),
            item(Icons.table_rows_rounded, L.t('rowAbove'), () => x!.shiftRows(sh, r, insert: true)),
            item(Icons.table_rows_rounded, L.t('rowBelow'), () => x!.shiftRows(sh, r + 1, insert: true)),
            item(Icons.delete_outline_rounded, L.t('delRow'), () => x!.shiftRows(sh, r, insert: false)),
            item(Icons.view_column_rounded, L.t('colLeft'), () => x!.shiftCols(sh, c, insert: true)),
            item(Icons.view_column_rounded, L.t('colRight'), () => x!.shiftCols(sh, c + 1, insert: true)),
            item(Icons.delete_outline_rounded, L.t('delCol'), () => x!.shiftCols(sh, c, insert: false)),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
        IconButton(
          icon: const Icon(Icons.save_rounded),
          tooltip: L.t('saveCopy'),
          onPressed: f == null || !f.z.changed ? null : () async {
            if (!await ensureSdAll(context, [widget.path])) return;
            final t = await f.saveCopy();
            if (mounted) await _saved(context, t);
          },
        ),
      ]),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : f.sheets.isEmpty
              ? Center(child: Text(L.t('empty')))
              : Column(children: [
                  SizedBox(
                    height: 44,
                    child: ListView(scrollDirection: Axis.horizontal, children: [
                      for (var i = 0; i < f.sheets.length; i++)
                        Padding(
                          padding: const EdgeInsets.all(4),
                          child: ChoiceChip(label: Text(f.sheets[i].name), selected: i == cur, onSelected: (_) => setState(() => cur = i)),
                        ),
                    ]),
                  ),
                  Expanded(child: _grid(f.sheets[cur])),
                ]),
    );
  }

  Widget _grid(XSheet sh) {
    final rows = (sh.rows + 20).clamp(40, 5000);
    final cols = (sh.cols + 3).clamp(8, 200);
    final line = Theme.of(context).dividerColor;
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: hw + cols * cw,
        child: ListView.builder(
          itemCount: rows + 1,
          itemExtent: rh,
          itemBuilder: (_, r) {
            if (r == 0) {
              return Row(children: [
                SizedBox(width: hw),
                for (var c = 0; c < cols; c++)
                  Container(width: cw, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.black26, border: Border.all(color: line, width: .5)), child: Text(colName(c), style: const TextStyle(fontWeight: FontWeight.bold))),
              ]);
            }
            return Row(children: [
              Container(width: hw, height: rh, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.black26, border: Border.all(color: line, width: .5)), child: Text('$r', style: const TextStyle(fontSize: 11))),
              for (var c = 0; c < cols; c++)
                InkWell(
                  onTap: () => _edit(sh, '${colName(c)}$r'),
                  onLongPress: () => _cellMenu(sh, c, r),
                  child: Builder(builder: (_) {
                    final ref = '${colName(c)}$r';
                    final st = sh.styles[ref];
                    return Container(
                      width: cw,
                      height: rh,
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      alignment: AlignmentDirectional.centerStart,
                      decoration: BoxDecoration(color: st?.fill != null ? Color(0xFF000000 | st!.fill!) : null, border: Border.all(color: line, width: .5)),
                      child: Text(sh.cells[ref] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, fontWeight: (st?.bold ?? false) ? FontWeight.bold : null, color: st?.fill != null ? Colors.black87 : null)),
                    );
                  }),
                ),
            ]);
          },
        ),
      ),
    );
  }
}

/// .pptx: slide cards with images and text; tap a paragraph to edit its text.
class PptxScreen extends StatefulWidget {
  final String path;
  const PptxScreen({super.key, required this.path});
  @override
  State<PptxScreen> createState() => _PptxScreenState();
}

class _PptxScreenState extends State<PptxScreen> {
  PptxFile? x;

  @override
  void initState() {
    super.initState();
    PptxFile.open(widget.path).then((v) { if (mounted) setState(() => x = v); }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
        IconButton(
          icon: const Icon(Icons.save_rounded),
          tooltip: L.t('saveCopy'),
          onPressed: f == null || !f.z.changed ? null : () async {
            if (!await ensureSdAll(context, [f.z.path])) return;
            final t = await f.z.saveCopy();
            if (mounted) await _saved(context, t);
          },
        ),
      ]),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: f.slides.length,
              itemBuilder: (_, i) {
                final s = f.slides[i];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Expanded(child: Text('${i + 1} / ${f.slides.length}', style: const TextStyle(fontSize: 11, color: Colors.grey))),
                        PopupMenuButton<String>(
                          icon: const Icon(Icons.more_vert_rounded, size: 20),
                          onSelected: (a) async {
                            if (a == 'up') {
                              setState(() => f.move(i, -1));
                            } else if (a == 'down') {
                              setState(() => f.move(i, 1));
                            } else if (a == 'dup') {
                              setState(() => f.duplicate(i));
                            } else if (a == 'blank') {
                              setState(() => f.duplicate(i, blank: true));
                            } else if (a == 'del') {
                              if (f.slides.length > 1 && await confirm(context, '${L.t('delete')}?')) setState(() => f.delete(i));
                            }
                          },
                          itemBuilder: (_) => [
                            PopupMenuItem(value: 'up', child: Text(L.t('moveUp'))),
                            PopupMenuItem(value: 'down', child: Text(L.t('moveDown'))),
                            PopupMenuItem(value: 'dup', child: Text(L.t('dupSlide'))),
                            PopupMenuItem(value: 'blank', child: Text(L.t('newSlide'))),
                            PopupMenuItem(value: 'del', child: Text(L.t('delete'))),
                          ],
                        ),
                      ]),
                      for (final im in s.images)
                        Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Image.memory(im, height: 180, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const SizedBox())),
                      for (final para in s.paras)
                        InkWell(
                          onTap: () async {
                            final r = await _editDialog(context, f.text(para));
                            if (r != null) setState(() => f.setText(s, para, r));
                          },
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Text(f.text(para).isEmpty ? '…' : f.text(para)),
                          ),
                        ),
                    ]),
                  ),
                );
              },
            ),
    );
  }
}

/// .odt: paragraphs and headings; tap to edit (the edited paragraph loses inline formatting).
class OdtScreen extends StatefulWidget {
  final String path;
  const OdtScreen({super.key, required this.path});
  @override
  State<OdtScreen> createState() => _OdtScreenState();
}

class _OdtScreenState extends State<OdtScreen> {
  OdtFile? x;

  @override
  void initState() {
    super.initState();
    OdtFile.open(widget.path).then((v) { if (mounted) setState(() => x = v); }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
        IconButton(
          icon: const Icon(Icons.save_rounded),
          tooltip: L.t('saveCopy'),
          onPressed: f == null || !f.z.changed ? null : () async {
            if (!await ensureSdAll(context, [f.z.path])) return;
            final t = await f.z.saveCopy();
            if (mounted) await _saved(context, t);
          },
        ),
      ]),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(14),
              itemCount: f.blocks.length,
              itemBuilder: (_, i) {
                final bl = f.blocks[i];
                if (bl.image != null) {
                  return Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Image.memory(bl.image!, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const SizedBox()));
                }
                if (bl.table != null) {
                  final line = Theme.of(context).dividerColor;
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Table(
                      border: TableBorder.all(color: line, width: .5),
                      defaultColumnWidth: const IntrinsicColumnWidth(flex: 1),
                      children: [
                        for (final row in bl.table!)
                          TableRow(children: [
                            for (final cell in row)
                              InkWell(
                                onTap: cell.isEmpty ? null : () async {
                                  final t = cell.map(paraText).join('\n');
                                  final r = await _editDialog(context, t);
                                  if (r != null) {
                                    setState(() {
                                      f.setText(cell.first, r);
                                      for (final extra in cell.skip(1)) {
                                        f.setText(extra, '');
                                      }
                                    });
                                  }
                                },
                                child: Padding(padding: const EdgeInsets.all(6), child: Text(cell.map(paraText).join('\n'), style: const TextStyle(fontSize: 13))),
                              ),
                          ]),
                      ],
                    ),
                  );
                }
                final para = bl.para!;
                final t = paraText(para);
                final h = f.isHeading(para);
                return InkWell(
                  onTap: () async {
                    final r = await _editDialog(context, t);
                    if (r != null) setState(() => f.setText(para, r));
                  },
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: h ? 10 : 4),
                    child: Text(t.isEmpty ? ' ' : t, style: TextStyle(fontSize: h ? 20 : 15, fontWeight: h ? FontWeight.bold : FontWeight.normal)),
                  ),
                );
              },
            ),
    );
  }
}

/// .rtf: formatted view (bold / italic / underline / size / colour / alignment / RTL); tap a paragraph to edit
/// its text (edited paragraph keeps the format of its first run). Saving writes "<name> (edited).rtf".
class RtfScreen extends StatefulWidget {
  final String path;
  const RtfScreen({super.key, required this.path});
  @override
  State<RtfScreen> createState() => _RtfScreenState();
}

class _RtfScreenState extends State<RtfScreen> {
  List<DocPara> paras = [];
  bool loaded = false, dirty = false;
  double font = 16;

  @override
  void initState() {
    super.initState();
    File(widget.path).readAsBytes().then((b) {
      final ps = RtfDoc.parse(String.fromCharCodes(b));
      if (mounted) setState(() { paras = ps; loaded = true; });
    }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  Future<void> _edit(DocPara p) async {
    final r = await _editDialog(context, p.text);
    if (r == null) return;
    final first = p.runs.isEmpty ? DocRun('') : p.runs.first;
    setState(() {
      p.runs
        ..clear()
        ..add(DocRun(r, b: first.b, i: first.i, u: first.u, sz: first.sz, color: first.color));
      if (RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(r) && !RegExp(r'[A-Za-z]').hasMatch(r)) p.rtl = true;
      dirty = true;
    });
  }

  Future<void> _menu(int i) async {
    final a = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.add_rounded), title: Text(L.t('addParaAfter')), onTap: () => Navigator.pop(context, 'add')),
          ListTile(leading: const Icon(Icons.delete_outline_rounded), title: Text(L.t('delete')), onTap: () => Navigator.pop(context, 'del')),
        ]),
      ),
    );
    if (a == 'add') {
      final src = paras[i];
      final np = DocPara(rtl: src.rtl)..jc = src.jc;
      final f = src.runs.isEmpty ? DocRun('') : src.runs.last;
      np.runs.add(DocRun(' ', b: f.b, i: f.i, u: f.u, sz: f.sz, color: f.color));
      setState(() { paras.insert(i + 1, np); dirty = true; });
    } else if (a == 'del') {
      setState(() { paras.removeAt(i); dirty = true; });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
          IconButton(icon: const Icon(Icons.text_decrease_rounded), onPressed: () => setState(() => font = (font - 1).clamp(10, 36))),
          IconButton(icon: const Icon(Icons.text_increase_rounded), onPressed: () => setState(() => font = (font + 1).clamp(10, 36))),
          IconButton(
            icon: const Icon(Icons.save_rounded),
            tooltip: L.t('saveCopy'),
            onPressed: !dirty ? null : () async {
              if (!await ensureSdAll(context, [widget.path])) return;
              final t = FileOps.unique(p.dirname(widget.path), '${p.basenameWithoutExtension(widget.path)} (edited).rtf');
              await Saf.writeString(t, RtfDoc.write(paras));
              if (mounted) { setState(() => dirty = false); await _saved(context, t); }
            },
          ),
        ]),
        body: !loaded
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                padding: const EdgeInsets.all(14),
                itemCount: paras.length,
                itemBuilder: (_, i) {
                  final pa = paras[i];
                  final align = switch (pa.jc) { 1 => TextAlign.center, 2 => TextAlign.end, 3 => TextAlign.justify, _ => TextAlign.start };
                  return Directionality(
                    textDirection: pa.rtl ? TextDirection.rtl : TextDirection.ltr,
                    child: InkWell(
                      onTap: () => _edit(pa),
                      onLongPress: () => _menu(i),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: SizedBox(
                          width: double.infinity,
                          child: Text.rich(
                            TextSpan(children: [
                              for (final r in pa.runs)
                                TextSpan(
                                  text: r.text,
                                  style: TextStyle(
                                    fontWeight: r.b ? FontWeight.bold : null,
                                    fontStyle: r.i ? FontStyle.italic : null,
                                    decoration: r.u ? TextDecoration.underline : null,
                                    fontSize: r.sz > 0 ? r.sz / 2 * (font / 12) : font,
                                    color: r.color != null ? Color(0xFF000000 | r.color!) : null,
                                  ),
                                ),
                              if (pa.runs.isEmpty) const TextSpan(text: ' '),
                            ], style: TextStyle(fontSize: font)),
                            textAlign: align,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
      );
}

// ====================================================================== legacy / ODF screens

/// .xls (Excel 97-2003): read-only grid; "convert" writes a .xlsx next to it and opens the editor.
class XlsScreen extends StatefulWidget {
  final String path;
  const XlsScreen({super.key, required this.path});
  @override
  State<XlsScreen> createState() => _XlsScreenState();
}

class _XlsScreenState extends State<XlsScreen> {
  List<XlsSheet>? sheets;
  int cur = 0;
  static const cw = 110.0, rh = 36.0, hw = 46.0;

  @override
  void initState() {
    super.initState();
    File(widget.path).readAsBytes().then((b) {
      try {
        final s = XlsLegacy.parse(b);
        if (mounted) setState(() => sheets = s);
      } catch (e) {
        if (mounted) { snack(context, '$e'); Navigator.pop(context); }
      }
    });
  }

  Future<void> _convert() async {
    if (!await ensureSdAll(context, [widget.path])) return;
    final t = FileOps.unique(p.dirname(widget.path), '${p.basenameWithoutExtension(widget.path)}.xlsx');
    await Saf.writeBytes(t, XlsLegacy.toXlsx(sheets!));
    Native.scan(t);
    if (!mounted) return;
    snack(context, '${L.t('saved')}: ${p.basename(t)}');
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => XlsxScreen(path: t)));
  }

  @override
  Widget build(BuildContext context) {
    final f = sheets;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
        if (f != null) IconButton(icon: const Icon(Icons.edit_note_rounded), tooltip: L.t('convertEdit'), onPressed: _convert),
      ]),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : f.isEmpty
              ? Center(child: Text(L.t('empty')))
              : Column(children: [
                  Container(width: double.infinity, color: Colors.amber.withOpacity(.15), padding: const EdgeInsets.all(8), child: Text(L.t('legacyXlsNote'), style: const TextStyle(fontSize: 12))),
                  SizedBox(
                    height: 44,
                    child: ListView(scrollDirection: Axis.horizontal, children: [
                      for (var i = 0; i < f.length; i++) Padding(padding: const EdgeInsets.all(4), child: ChoiceChip(label: Text(f[i].name), selected: i == cur, onSelected: (_) => setState(() => cur = i))),
                    ]),
                  ),
                  Expanded(child: _grid(f[cur])),
                ]),
    );
  }

  Widget _grid(XlsSheet sh) {
    final rows = (sh.rows + 5).clamp(20, 5000);
    final cols = (sh.cols + 1).clamp(6, 200);
    final line = Theme.of(context).dividerColor;
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: hw + cols * cw,
        child: ListView.builder(
          itemCount: rows + 1,
          itemExtent: rh,
          itemBuilder: (_, r) {
            if (r == 0) {
              return Row(children: [
                SizedBox(width: hw),
                for (var c = 0; c < cols; c++) Container(width: cw, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.black26, border: Border.all(color: line, width: .5)), child: Text(colName(c), style: const TextStyle(fontWeight: FontWeight.bold))),
              ]);
            }
            return Row(children: [
              Container(width: hw, height: rh, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.black26, border: Border.all(color: line, width: .5)), child: Text('$r', style: const TextStyle(fontSize: 11))),
              for (var c = 0; c < cols; c++)
                Container(
                  width: cw,
                  height: rh,
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  alignment: AlignmentDirectional.centerStart,
                  decoration: BoxDecoration(border: Border.all(color: line, width: .5)),
                  child: Text(sh.at(r - 1, c), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                ),
            ]);
          },
        ),
      ),
    );
  }
}

/// .ppt (PowerPoint 97-2003): read-only text per slide, copy-all.
class PptScreen extends StatefulWidget {
  final String path;
  const PptScreen({super.key, required this.path});
  @override
  State<PptScreen> createState() => _PptScreenState();
}

class _PptScreenState extends State<PptScreen> {
  List<List<String>>? slides;

  @override
  void initState() {
    super.initState();
    File(widget.path).readAsBytes().then((b) {
      try {
        final s = PptLegacy.parse(b);
        if (mounted) setState(() => slides = s);
      } catch (e) {
        if (mounted) { snack(context, '$e'); Navigator.pop(context); }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final f = slides;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
        if (f != null)
          IconButton(
            icon: const Icon(Icons.copy_rounded),
            tooltip: L.t('copy'),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: [for (var i = 0; i < f.length; i++) '— ${i + 1} —\n${f[i].join('\n')}'].join('\n\n')));
              snack(context, L.t('copied'));
            },
          ),
      ]),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: f.length + 1,
              itemBuilder: (_, i) {
                if (i == 0) return Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(L.t('legacyPptNote'), style: const TextStyle(fontSize: 12, color: Colors.amber)));
                final s = f[i - 1];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('$i / ${f.length}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                      for (final t in s) Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: SelectableText(t)),
                      if (s.isEmpty) const Text('…'),
                    ]),
                  ),
                );
              },
            ),
    );
  }
}

/// .ods: sheet tabs and grid, tap a cell to edit (values; formulas are replaced by the typed value).
class OdsScreen extends StatefulWidget {
  final String path;
  const OdsScreen({super.key, required this.path});
  @override
  State<OdsScreen> createState() => _OdsScreenState();
}

class _OdsScreenState extends State<OdsScreen> {
  OdsFile? x;
  int cur = 0;
  static const cw = 110.0, rh = 36.0, hw = 46.0;

  @override
  void initState() {
    super.initState();
    OdsFile.open(widget.path).then((v) { if (mounted) setState(() => x = v); }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
        IconButton(
          icon: const Icon(Icons.save_rounded),
          tooltip: L.t('saveCopy'),
          onPressed: f == null || !f.z.changed ? null : () async {
            if (!await ensureSdAll(context, [f.z.path])) return;
            final t = await f.z.saveCopy();
            if (mounted) await _saved(context, t);
          },
        ),
      ]),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : f.sheets.isEmpty
              ? Center(child: Text(L.t('empty')))
              : Column(children: [
                  SizedBox(
                    height: 44,
                    child: ListView(scrollDirection: Axis.horizontal, children: [
                      for (var i = 0; i < f.sheets.length; i++) Padding(padding: const EdgeInsets.all(4), child: ChoiceChip(label: Text(f.sheets[i].name), selected: i == cur, onSelected: (_) => setState(() => cur = i))),
                    ]),
                  ),
                  Expanded(child: _grid(f, f.sheets[cur])),
                ]),
    );
  }

  Widget _grid(OdsFile f, OSheet sh) {
    final rows = (sh.rows + 20).clamp(40, 5000);
    final cols = (sh.cols + 3).clamp(8, 200);
    final line = Theme.of(context).dividerColor;
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: hw + cols * cw,
        child: ListView.builder(
          itemCount: rows + 1,
          itemExtent: rh,
          itemBuilder: (_, r) {
            if (r == 0) {
              return Row(children: [
                SizedBox(width: hw),
                for (var c = 0; c < cols; c++) Container(width: cw, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.black26, border: Border.all(color: line, width: .5)), child: Text(colName(c), style: const TextStyle(fontWeight: FontWeight.bold))),
              ]);
            }
            return Row(children: [
              Container(width: hw, height: rh, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.black26, border: Border.all(color: line, width: .5)), child: Text('$r', style: const TextStyle(fontSize: 11))),
              for (var c = 0; c < cols; c++)
                InkWell(
                  onTap: () async {
                    final ref = '${colName(c)}$r';
                    final v = await _editDialog(context, sh.cells[ref] ?? '', title: ref);
                    if (v != null) setState(() => f.setCell(sh, ref, v));
                  },
                  child: Container(
                    width: cw,
                    height: rh,
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    alignment: AlignmentDirectional.centerStart,
                    decoration: BoxDecoration(border: Border.all(color: line, width: .5)),
                    child: Text(sh.cells['${colName(c)}$r'] ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                  ),
                ),
            ]);
          },
        ),
      ),
    );
  }
}

/// .odp: pages with images and text; tap a paragraph to edit.
class OdpScreen extends StatefulWidget {
  final String path;
  const OdpScreen({super.key, required this.path});
  @override
  State<OdpScreen> createState() => _OdpScreenState();
}

class _OdpScreenState extends State<OdpScreen> {
  OdpFile? x;

  @override
  void initState() {
    super.initState();
    OdpFile.open(widget.path).then((v) { if (mounted) setState(() => x = v); }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)), actions: [
        IconButton(
          icon: const Icon(Icons.save_rounded),
          tooltip: L.t('saveCopy'),
          onPressed: f == null || !f.z.changed ? null : () async {
            if (!await ensureSdAll(context, [f.z.path])) return;
            final t = await f.z.saveCopy();
            if (mounted) await _saved(context, t);
          },
        ),
      ]),
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: f.pages.length,
              itemBuilder: (_, i) {
                final pg = f.pages[i];
                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${i + 1} / ${f.pages.length}', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                      for (final im in pg.images) Padding(padding: const EdgeInsets.symmetric(vertical: 6), child: Image.memory(im, height: 180, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const SizedBox())),
                      for (final para in pg.paras)
                        InkWell(
                          onTap: () async {
                            final r = await _editDialog(context, paraText(para));
                            if (r != null) setState(() => f.setText(para, r));
                          },
                          child: Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Text(paraText(para).isEmpty ? '…' : paraText(para))),
                        ),
                    ]),
                  ),
                );
              },
            ),
    );
  }
}
