package ir.abtin.sms

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

fun msgKey(m: Msg) = (if (m.mms) "m" else "s") + m.id

private val linkRx = Regex("(https?://[^\\s]+|www\\.[^\\s]+|\\+?\\d[\\d\\s-]{6,}\\d)")
fun findLinks(t: String): List<IntRange> = linkRx.findAll(t).map { it.range }.toList()

@Composable
fun LinkText(t: String, color: Color, linkColor: Color, onTap: () -> Unit, onLong: () -> Unit) {
    val ctx = LocalContext.current
    val links = remember(t, Prefs.smartLinks.value) { if (Prefs.smartLinks.value) findLinks(t) else emptyList() }
    val ann = remember(t, links, linkColor) {
        buildAnnotatedString { append(t); links.forEach { addStyle(androidx.compose.ui.text.SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline), it.first, it.last + 1) } }
    }
    var lay by remember { mutableStateOf<TextLayoutResult?>(null) }
    Text(ann, color = color, fontSize = 17.sp, lineHeight = 25.sp, style = TextStyle(textDirection = TextDirection.Content), onTextLayout = { lay = it },
        modifier = Modifier.pointerInput(links) {
            detectTapGestures(onLongPress = { onLong() }, onTap = { pos ->
                val o = lay?.getOffsetForPosition(pos)
                val hit = if (o == null) null else links.firstOrNull { o in it }
                if (hit == null) onTap() else {
                    val s = t.substring(hit.first, hit.last + 1).trim()
                    val i = if (s.startsWith("http", true) || s.startsWith("www", true)) Intent(Intent.ACTION_VIEW, Uri.parse(if (s.startsWith("www", true)) "https://$s" else s))
                    else Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + s.filter { it.isDigit() || it == '+' }))
                    runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                }
            })
        })
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Bubble(m: Msg, p: Pal, repo: SmsRepo, label: String?, selected: Boolean, starred: Boolean, onClick: () -> Unit, onLong: () -> Unit, onCode: (String) -> Unit) {
    val out = m.type != 1
    val failed = m.type == 5
    val style = Prefs.bubbleShape.value
    val tw = if (style == "tail") TAIL_DP.dp else 0.dp
    val fg = p.text
    val ticks: @Composable () -> Unit = {
        if (out) when {
            failed -> Text("! ", color = p.danger, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            m.type == 4 || m.type == 6 -> Text("… ", color = fg.copy(alpha = .7f), fontSize = 13.sp)
            m.status == 64 -> Text("✗ ", color = p.danger, fontSize = 13.sp)
            m.status == 0 -> Icon(Icons.Default.DoneAll, null, tint = p.tick, modifier = Modifier.size(17.dp).padding(end = 3.dp))
            else -> Icon(Icons.Default.Done, null, tint = Color(0xFF9DB8E8), modifier = Modifier.size(17.dp).padding(end = 3.dp))
        }
    }
    val meta: @Composable () -> Unit = {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (starred) Icon(Icons.Default.Star, null, tint = Color(0xFFFFC53D), modifier = Modifier.size(13.dp).padding(end = 2.dp))
            ticks()
            Text(fmtClock(m.date), color = if (out) Color(0xFF9DB8E8) else p.sub, fontSize = 13.sp)
        }
    }
    Row(Modifier.fillMaxWidth().background(if (selected) p.primary.copy(alpha = .16f) else Color.Transparent).padding(horizontal = 14.dp, vertical = 2.dp),
        horizontalArrangement = if (out) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.CenterVertically) {
        if (selected && !out) { Icon(Icons.Default.CheckCircle, null, tint = p.primary, modifier = Modifier.size(22.dp)); Spacer(Modifier.width(8.dp)) }
        Column(Modifier.widthIn(max = 310.dp).width(IntrinsicSize.Max)
            .background(if (out) Brush.linearGradient(listOf(p.out1, p.out2)) else SolidColor(p.inBubble), BubbleShape(out, style))
            .combinedClickable(onClick = { if (failed) onClick() else onClick() }, onLongClick = onLong)
            .padding(start = 13.dp + (if (!out) tw else 0.dp), end = 13.dp + (if (out) tw else 0.dp), top = 9.dp, bottom = 8.dp)) {
            if (label != null) Text(label, color = p.badge, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            m.atts.forEach { at -> AttView(repo, at, fg, p) }
            if (m.body.isNotEmpty()) {
                val rtl = isRtlText(m.body)
                val txt: @Composable () -> Unit = { Box(Modifier, contentAlignment = Alignment.CenterStart) { LinkText(m.body, fg, Color(0xFF8CC4FF), onClick, onLong) } }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                    if (rtl) {
                        Box(Modifier.padding(bottom = 1.dp)) { meta() }
                        Spacer(Modifier.width(22.dp)); Spacer(Modifier.weight(1f))
                        txt()
                    } else {
                        txt(); Spacer(Modifier.width(22.dp)); Spacer(Modifier.weight(1f))
                        Box(Modifier.padding(bottom = 1.dp)) { meta() }
                    }
                }
            } else Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { meta() }
            if (failed) Text(tr("ارسال ناموفق — لمس برای تلاش مجدد", "Failed — tap to retry"), color = p.danger, fontSize = 12.sp)
            if (!out && Prefs.codeChip.value) findCode(m.body)?.let { code ->
                Text(tr("کپی کد ", "Copy code ") + code, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 6.dp).clip(RoundedCornerShape(50)).background(p.primary).clickable { onCode(code) }.padding(horizontal = 12.dp, vertical = 5.dp))
            }
        }
        if (selected && out) { Spacer(Modifier.width(8.dp)); Icon(Icons.Default.CheckCircle, null, tint = p.primary, modifier = Modifier.size(22.dp)) }
    }
}

@Composable
fun AttThumb(a: Attach) {
    val p = LocalPal.current
    val bmp = remember(a) {
        if (a.mime.startsWith("image/")) BitmapFactory.decodeByteArray(a.bytes, 0, a.bytes.size, BitmapFactory.Options().apply { inSampleSize = 4 }) else null
    }
    if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
    else Box(Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)).background(p.surface), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(attIcon(a.mime), null, tint = p.primary, modifier = Modifier.size(28.dp))
            Text(a.name.take(10), color = p.text, fontSize = 10.sp, maxLines = 1, modifier = Modifier.padding(top = 3.dp, start = 3.dp, end = 3.dp))
        }
    }
}

@Composable
fun AttView(repo: SmsRepo, a: Att, fg: Color, p: Pal) {
    val ctx = LocalContext.current
    var big by remember { mutableStateOf(false) }
    if (a.mime.startsWith("image/")) {
        val bmp by produceState<Bitmap?>(null, a.partId) { value = withContext(Dispatchers.IO) { repo.thumb(a.partId, 640) } }
        val b0 = bmp
        if (b0 != null) Image(b0.asImageBitmap(), null, Modifier.widthIn(max = 240.dp).heightIn(max = 320.dp).padding(bottom = 4.dp).clip(RoundedCornerShape(12.dp)).clickable { big = true }, contentScale = ContentScale.Fit)
        else Text("🖼 …", color = fg)
        if (big) {
            val full by produceState<Bitmap?>(null, a.partId) { value = withContext(Dispatchers.IO) { repo.thumb(a.partId, 2048) } }
            Dialog({ big = false }) {
                val f0 = full
                if (f0 != null) Image(f0.asImageBitmap(), null, Modifier.fillMaxWidth().clickable { big = false }, contentScale = ContentScale.Fit)
            }
        }
    } else {
        val size by produceState(-1L, a.partId) { value = withContext(Dispatchers.IO) { repo.partSize(a.partId) } }
        val ext = a.name.substringAfterLast('.', a.mime.substringAfter('/')).uppercase().take(5)
        Row(Modifier.clip(RoundedCornerShape(14.dp)).clickable { repo.openAtt(ctx, a) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(50.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .08f)), contentAlignment = Alignment.Center) {
                Icon(attIcon(a.mime), null, tint = p.tick, modifier = Modifier.size(28.dp))
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text(a.name.ifEmpty { a.mime }, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 190.dp), style = TextStyle(textDirection = TextDirection.Content))
                Text((if (size >= 0) fmtSize(size) + " • " else "") + ext, color = p.sub, fontSize = 14.sp)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalLayoutApi::class)
@Composable
fun ChatScreen(repo: SmsRepo, act: ComponentActivity, s: Screen.Chat, nav: MutableState<Screen>, askDefault: () -> Unit) {
    val p = LocalPal.current
    val fa = isFa()
    val scope = rememberCoroutineScope()
    val tick = Bus.tick.intValue
    val addrs = remember(s.address) { s.address.split(',', ';').map { it.trim() }.filter { it.isNotEmpty() } }
    val group = addrs.size > 1
    var tid by remember { mutableLongStateOf(s.threadId) }
    var msgs by remember { mutableStateOf<List<Msg>>(emptyList()) }
    var title by remember { mutableStateOf(s.address) }
    var text by remember { mutableStateOf(s.draft ?: "") }
    val atts = remember { mutableStateListOf<Attach>() }
    val sims = remember { repo.sims() }
    var simSel by remember { mutableIntStateOf(Prefs.sim.value.takeIf { v -> sims.any { it.subId == v } } ?: -1) }
    var simMenu by remember { mutableStateOf(false) }
    var attPanel by remember { mutableStateOf(false) }
    var showContactPicker by remember { mutableStateOf(false) }
    var contactQuery by remember { mutableStateOf("") }
    var contactChoices by remember { mutableStateOf<List<ContactItem>>(emptyList()) }
    var loadingContacts by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Set<String>>(emptySet()) }
    var confirmDel by remember { mutableStateOf(false) }
    var details by remember { mutableStateOf<Msg?>(null) }
    var searching by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    val selMode = selected.isNotEmpty()
    val stars = csv(Prefs.starred)
    LaunchedEffect(s.address) { withContext(Dispatchers.IO) { if (tid == 0L) tid = repo.threadIdFor(s.address); title = repo.displayName(addrs) } }
    DisposableEffect(tid) { Notifier.activeThread = tid; onDispose { Notifier.activeThread = -1 } }
    LaunchedEffect(tick, tid) {
        if (tid == 0L) return@LaunchedEffect
        msgs = withContext(Dispatchers.IO) { runCatching { repo.markRead(tid) }; runCatching { repo.messages(tid) }.getOrDefault(emptyList()) }
    }
    val shownMsgs = if (q.isBlank()) msgs else msgs.filter { it.body.contains(q, true) }
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.scrollToItem(msgs.lastIndex) }
    val ime = WindowInsets.ime
    val imeOpen = ime.getBottom(LocalDensity.current) > 0
    val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val selMsgs = msgs.filter { msgKey(it) in selected }

    fun add(u: Uri?, hint: String? = null) {
        if (u == null) return
        scope.launch(Dispatchers.IO) {
            val a = repo.prepare(u, hint)
            withContext(Dispatchers.Main) {
                if (a != null) atts.add(a)
                else Toast.makeText(act, tr("فایل پشتیبانی نمی‌شود یا خیلی بزرگ است", "Unsupported or too large"), Toast.LENGTH_LONG).show()
            }
        }
    }
    val pickImgs = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { l -> l.forEach { add(it) } }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> add(u) }
    val camUri = remember { mutableStateOf<Uri?>(null) }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r -> if (r.resultCode == Activity.RESULT_OK) add(camUri.value, "image/jpeg") }
    val rec = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r -> if (r.resultCode == Activity.RESULT_OK) add(r.data?.data) }
    val contactPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            loadingContacts = true
            scope.launch(Dispatchers.IO) {
                val result = runCatching { repo.contacts().distinctBy { it.id }.sortedBy { it.name.lowercase() } }.getOrDefault(emptyList())
                withContext(Dispatchers.Main) { contactChoices = result; loadingContacts = false; showContactPicker = true }
            }
        } else Toast.makeText(act, tr("برای انتخاب مخاطب، دسترسی مخاطبین لازم است", "Contacts permission is required"), Toast.LENGTH_LONG).show()
    }
    fun openContactPicker() {
        contactQuery = ""
        if (act.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            contactPermission.launch(android.Manifest.permission.READ_CONTACTS)
            return
        }
        loadingContacts = true
        scope.launch(Dispatchers.IO) {
            val result = runCatching { repo.contacts().distinctBy { it.id }.sortedBy { it.name.lowercase() } }.getOrDefault(emptyList())
            withContext(Dispatchers.Main) { contactChoices = result; loadingContacts = false; showContactPicker = true }
        }
    }
    fun attachContact(contact: ContactItem) {
        showContactPicker = false
        scope.launch(Dispatchers.IO) {
            val card = runCatching { repo.contactFull(contact.id)?.toVCard() }.getOrNull()
            val vcard = card ?: "BEGIN:VCARD\r\nVERSION:3.0\r\nFN:${contact.name.replace("\n", " ")}\r\nTEL:${contact.number}\r\nEND:VCARD\r\n"
            val base = contact.name.replace(Regex("[^A-Za-z0-9_-]"), "").take(30).ifBlank { "contact" }
            val attachment = Attach(vcard.toByteArray(Charsets.UTF_8), "text/x-vcard", "$base.vcf")
            withContext(Dispatchers.Main) { atts.add(attachment) }
        }
    }
    var voice by remember { mutableStateOf(false) }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) voice = true }
    fun askMic() {
        if (act.checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED) voice = true
        else micPerm.launch(android.Manifest.permission.RECORD_AUDIO)
    }
    fun insertLoc() {
        scope.launch(Dispatchers.IO) {
            val l = repo.lastLocation()
            withContext(Dispatchers.Main) {
                if (l != null) text = (text + " " + l).trim() else Toast.makeText(act, tr("موقعیت در دسترس نیست", "Location unavailable"), Toast.LENGTH_LONG).show()
            }
        }
    }
    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) insertLoc() }
    fun askLoc() {
        if (act.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) insertLoc()
        else locPerm.launch(android.Manifest.permission.ACCESS_FINE_LOCATION)
    }
    fun launchCamera() {
        val f = File(File(act.cacheDir, "mms").apply { mkdirs() }, "cam_${System.currentTimeMillis()}.jpg")
        val u = FileProvider.getUriForFile(act, act.packageName + ".files", f)
        camUri.value = u
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, u).addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = ClipData.newRawUri("", u)
        runCatching { cam.launch(i) }
    }
    fun doSend() {
        val t = text.trim()
        if (t.isEmpty() && atts.isEmpty()) return
        val a = atts.toList(); val sub = simSel
        text = ""; atts.clear()
        if (Prefs.sendSound.value) runCatching { android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 60).startTone(android.media.ToneGenerator.TONE_PROP_ACK, 120) }
        scope.launch(Dispatchers.IO) {
            try { repo.sendAny(s.address, t, a, sub) } catch (e: Exception) {
                withContext(Dispatchers.Main) { Toast.makeText(act, tr("ابتدا آبتین SMS را برنامه پیش‌فرض کنید", "Set Abtin SMS as default first"), Toast.LENGTH_LONG).show() }
            }
        }
    }
    val key0 = addrs.firstOrNull() ?: ""
    val threadKey = tid.toString()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            // ---- header ----
            if (selMode) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircleBtn(Icons.Default.Close, { selected = emptySet() })
                    Text(listNum("${selected.size}") + " " + tr("انتخاب شد", "selected"), color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f).padding(horizontal = 12.dp))
                    val allStarred = selMsgs.isNotEmpty() && selMsgs.all { msgKey(it) in stars }
                    CircleBtn(if (allStarred) Icons.Default.Star else Icons.Default.StarBorder, {
                        selMsgs.forEach { k -> val kk = msgKey(k); val cur = csv(Prefs.starred); if (allStarred) removeFrom(Prefs.starred, kk) else if (kk !in cur) addTo(Prefs.starred, kk) }; selected = emptySet()
                    }, tint = Color(0xFFFFC53D)); Spacer(Modifier.width(8.dp))
                    CircleBtn(Icons.Default.ContentCopy, { cm.setPrimaryClip(ClipData.newPlainText("sms", selMsgs.joinToString("\n") { it.body })); selected = emptySet() }); Spacer(Modifier.width(8.dp))
                    CircleBtn(Icons.Default.Share, {
                        act.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, selMsgs.joinToString("\n") { it.body }), null)); selected = emptySet()
                    }); Spacer(Modifier.width(8.dp))
                    if (selMsgs.size == 1) { CircleBtn(Icons.Default.Info, { details = selMsgs[0]; selected = emptySet() }); Spacer(Modifier.width(8.dp)) }
                    CircleBtn(Icons.Default.Delete, { confirmDel = true }, tint = p.danger)
                }
            } else {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, { nav.value = Screen.Home })
                    Spacer(Modifier.width(14.dp))
                    if (Prefs.showAvatars.value) { Avatar(repo, key0, title, 54.dp, group); Spacer(Modifier.width(12.dp)) }
                    Column(Modifier.weight(1f)) {
                        Text(title, color = p.text, fontWeight = FontWeight.Bold, fontSize = 22.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content))
                        if (!group && title != s.address) Text(s.address, color = p.sub, fontSize = 15.sp, maxLines = 1)
                        if (group) Text(tr("گروه · ${addrs.size} نفر", "Group · ${addrs.size} people"), color = p.sub, fontSize = 14.sp)
                    }
                    if (!group) { CircleBtn(Icons.Default.Call, { dial(act, key0) }); Spacer(Modifier.width(12.dp)) }
                    Box {
                        CircleBtn(Icons.Default.MoreVert, { moreMenu = true })
                        DropdownMenu(moreMenu, { moreMenu = false }) {
                            DropdownMenuItem(text = { Text(tr("جستجو در گفتگو", "Search in conversation")) }, onClick = { moreMenu = false; searching = !searching; if (!searching) q = "" })
                            if (!group) DropdownMenuItem(text = { Text(tr("افزودن به مخاطبین", "Add to contacts")) }, onClick = {
                                moreMenu = false
                                runCatching { act.startActivity(Intent(Intent.ACTION_INSERT_OR_EDIT).setType(ContactsContract.Contacts.CONTENT_ITEM_TYPE).putExtra(ContactsContract.Intents.Insert.PHONE, key0)) }
                            })
                            DropdownMenuItem(text = { Text(if (threadKey in csv(Prefs.muted)) tr("فعال کردن اعلان", "Unmute") else tr("بی‌صدا کردن اعلان", "Mute notifications")) }, onClick = { moreMenu = false; toggle(Prefs.muted, threadKey) })
                            DropdownMenuItem(text = { Text(if (threadKey in csv(Prefs.pinned)) tr("برداشتن سنجاق", "Unpin") else tr("سنجاق کردن", "Pin")) }, onClick = { moreMenu = false; toggle(Prefs.pinned, threadKey) })
                            DropdownMenuItem(text = { Text(if (threadKey in csv(Prefs.archived)) tr("خروج از بایگانی", "Unarchive") else tr("بایگانی", "Archive")) }, onClick = { moreMenu = false; toggle(Prefs.archived, threadKey); nav.value = Screen.Home })
                            DropdownMenuItem(text = { Text(tr("مسدود کردن", "Block")) }, onClick = { moreMenu = false; toggle(Prefs.blocked, norm(key0)); nav.value = Screen.Home })
                            DropdownMenuItem(text = { Text(tr("علامت اسپم", "Report spam")) }, onClick = { moreMenu = false; markSpam(norm(key0), true); nav.value = Screen.Home })
                            DropdownMenuItem(text = { Text(tr("حذف گفتگو", "Delete conversation"), color = p.danger) }, onClick = {
                                moreMenu = false; scope.launch(Dispatchers.IO) { runCatching { repo.deleteThread(tid) }; withContext(Dispatchers.Main) { nav.value = Screen.Home } }
                            })
                        }
                    }
                }
            }
            HorizontalDivider(color = p.line)
            if (searching) PillField(q, { q = it }, tr("جستجو در گفتگو…", "Search in conversation…"), Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), Icons.Default.Search)
            if (!isDefaultSms(act)) DefaultBanner(askDefault)
            // ---- messages ----
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, contentPadding = PaddingValues(vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(shownMsgs.size, key = { msgKey(shownMsgs[it]) }) { i ->
                    val m = shownMsgs[i]
                    if (i == 0 || !sameDay(shownMsgs[i - 1].date, m.date)) Box(Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
                        Text(fmtChatDay(m.date), color = p.sub, fontSize = 14.sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(p.surface).border(1.dp, p.line, RoundedCornerShape(50)).padding(horizontal = 20.dp, vertical = 5.dp))
                    }
                    val k = msgKey(m)
                    Bubble(m, p, repo, if (group && m.type == 1) (repo.name(m.address) ?: m.address) else null, k in selected, k in stars,
                        onClick = {
                            if (selMode) selected = if (k in selected) selected - k else selected + k
                            else if (m.type == 5) scope.launch(Dispatchers.IO) { runCatching { repo.retry(m) } }
                        },
                        onLong = { selected = if (k in selected) selected - k else selected + k },
                        onCode = { code -> cm.setPrimaryClip(ClipData.newPlainText("code", code)); Toast.makeText(act, tr("کد کپی شد", "Code copied"), Toast.LENGTH_SHORT).show() })
                }
            }
            // ---- composer ----
            val sheet = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
            Column(Modifier.fillMaxWidth().clip(sheet).background(p.nav).border(1.dp, p.line, sheet).padding(top = 14.dp, bottom = 10.dp)) {
                if (atts.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    atts.toList().forEachIndexed { i, a ->
                        Box {
                            AttThumb(a)
                            Box(Modifier.align(Alignment.TopEnd).size(22.dp).clip(CircleShape).background(p.primary).clickable { atts.removeAt(i) }, contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Close, null, tint = p.onPrimary, modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
                if (Prefs.showQuickReplies.value) Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    templates().forEach { tp -> Text(tp, color = p.text, fontSize = 14.sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(p.surface).border(1.dp, p.line, RoundedCornerShape(50)).clickable { text = tp }.padding(horizontal = 14.dp, vertical = 7.dp)) }
                }
                if (attPanel) {
                    val ps = RoundedCornerShape(24.dp)
                    Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(bottom = 10.dp).clip(ps).background(p.surface).border(1.dp, p.line, ps).padding(vertical = 10.dp, horizontal = 6.dp)) {
                        Row(Modifier.fillMaxWidth()) {
                            AttItem(Icons.Default.CameraAlt, Color(0xFFFF5C7A), tr("دوربین", "Camera")) { attPanel = false; launchCamera() }
                            AttItem(Icons.Default.Image, Color(0xFF9B7BFF), tr("گالری", "Gallery")) { attPanel = false; pickImgs.launch("image/*") }
                            AttItem(Icons.Default.Videocam, Color(0xFFFF8A3D), tr("ویدیو", "Video")) { attPanel = false; pickFile.launch("video/*") }
                            AttItem(Icons.Default.Mic, Color(0xFF1FB6A6), tr("ویس", "Voice")) { attPanel = false; askMic() }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(Modifier.fillMaxWidth()) {
                            AttItem(Icons.Default.AudioFile, Color(0xFF3D8BFF), tr("فایل صوتی", "Audio")) { attPanel = false; pickFile.launch("audio/*") }
                            AttItem(Icons.Default.LocationOn, Color(0xFF34C77B), tr("موقعیت", "Location")) { attPanel = false; askLoc() }
                            AttItem(Icons.Default.Person, Color(0xFF4FA3FF), tr("مخاطب", "Contact")) { attPanel = false; openContactPicker() }
                            AttItem(Icons.Default.Description, Color(0xFF8A94A8), tr("فایل", "File")) { attPanel = false; pickFile.launch("*/*") }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.Bottom) {
                    CircleBtn(if (attPanel) Icons.Default.Close else Icons.Default.AttachFile, { attPanel = !attPanel }, size = 46.dp, tint = if (attPanel) p.primary else null)
                    Spacer(Modifier.width(10.dp))
                    CompositionLocalProvider(LocalLayoutDirection provides if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr) {
                        PillField(text, { text = it }, tr("پیام…", "Message…"), Modifier.weight(1f), null,
                            KeyboardOptions(imeAction = if (Prefs.enterSends.value) ImeAction.Send else ImeAction.Default), KeyboardActions(onSend = { doSend() }), maxLines = 5)
                    }
                    Spacer(Modifier.width(10.dp))
                    if (sims.size > 1) {
                        val eff = if (simSel >= 0) simSel else repo.defaultSub()
                        val sl = sims.firstOrNull { it.subId == eff }?.slot ?: 1
                        Box(Modifier.padding(bottom = 4.dp).size(42.dp).clip(CircleShape).background(p.surface).border(1.dp, p.line, CircleShape)
                            .clickable { val idx = sims.indexOfFirst { it.subId == eff }; simSel = sims[(idx + 1) % sims.size].subId },
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.SimCard, null, tint = p.primary, modifier = Modifier.size(30.dp))
                            Text(listNum(sl.toString()), color = p.onPrimary, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 7.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                    }
                    val hasContent = text.isNotBlank() || atts.isNotEmpty()
                    Box {
                        Box(Modifier.size(48.dp).shadow(14.dp, CircleShape, ambientColor = p.primary, spotColor = p.primary).clip(CircleShape)
                            .background(Brush.linearGradient(listOf(p.primary.copy(alpha = .95f), p.primary2)))
                            .combinedClickable(onClick = { if (hasContent) doSend() }, onLongClick = { if (sims.size > 1) simMenu = true }),
                            contentAlignment = Alignment.Center) {
                            Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.White.copy(alpha = if (hasContent) 1f else .5f), modifier = Modifier.size(22.dp))
                        }
                        DropdownMenu(simMenu, { simMenu = false }) {
                            sims.forEach { sim -> DropdownMenuItem(text = { Text(tr("سیم ", "SIM ") + listNum(sim.slot.toString()) + " · ${sim.name}") }, onClick = { simSel = sim.subId; simMenu = false }) }
                        }
                    }
                }
            }
        }
    }
    if (showContactPicker) {
        val filteredContacts = contactChoices.filter { contactQuery.isBlank() || it.name.contains(contactQuery, true) || it.number.contains(contactQuery) }
        AlertDialog(
            onDismissRequest = { showContactPicker = false },
            containerColor = p.surface,
            titleContentColor = p.text,
            textContentColor = p.sub,
            title = { Text(tr("انتخاب مخاطب", "Select contact")) },
            text = {
                Column(Modifier.heightIn(max = 440.dp)) {
                    PillField(contactQuery, { contactQuery = it }, tr("جستجوی مخاطب…", "Search contacts…"), Modifier.fillMaxWidth(), Icons.Default.Search)
                    Spacer(Modifier.height(8.dp))
                    when {
                        loadingContacts -> Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = p.primary) }
                        filteredContacts.isEmpty() -> Text(tr("مخاطبی پیدا نشد", "No contacts found"), color = p.sub, modifier = Modifier.padding(18.dp))
                        else -> LazyColumn(Modifier.heightIn(max = 340.dp)) {
                            items(filteredContacts, key = { "pick-${it.id}-${it.number}" }) { contact ->
                                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { attachContact(contact) }.padding(horizontal = 8.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Avatar(repo, contact.number, contact.name, 42.dp)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(contact.name.ifBlank { contact.number }, color = p.text, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        Text(contact.number, color = p.sub, fontSize = 13.sp)
                                    }
                                    Icon(Icons.Default.Add, null, tint = p.primary)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showContactPicker = false }) { Text(tr("بستن", "Close"), color = p.primary) } }
        )
    }
    if (voice) VoiceRecorderDialog(act, { a -> atts.add(a); voice = false }, { voice = false })
    if (confirmDel) AlertDialog(onDismissRequest = { confirmDel = false }, containerColor = p.surface, titleContentColor = p.text, textContentColor = p.sub,
        title = { Text(tr("حذف پیام", "Delete messages")) }, text = { Text(tr("${listNum(selMsgs.size.toString())} پیام حذف شود؟", "Delete ${selMsgs.size} message(s)?")) },
        confirmButton = {
            TextButton({
                val l = selMsgs; confirmDel = false; selected = emptySet()
                l.forEach { removeFrom(Prefs.starred, msgKey(it)) }
                scope.launch(Dispatchers.IO) { repo.deleteMessages(l); withContext(Dispatchers.Main) { Bus.tick.intValue++ } }
            }) { Text(tr("حذف", "Delete"), color = p.danger) }
        }, dismissButton = { TextButton({ confirmDel = false }) { Text(tr("لغو", "Cancel"), color = p.text) } })
    details?.let { m ->
        AlertDialog(onDismissRequest = { details = null }, containerColor = p.surface, titleContentColor = p.text, textContentColor = p.sub,
            title = { Text(tr("جزئیات پیام", "Message details")) },
            text = {
                Column {
                    Text((if (m.type == 1) tr("دریافتی از: ", "From: ") else tr("ارسالی به: ", "To: ")) + m.address.replace(",", ", "))
                    Text((if (m.type == 1) tr("دریافت: ", "Received: ") else tr("ارسال: ", "Sent: ")) + fmtDay(m.date) + " " + fmtClock(m.date))
                    Text(tr("نوع: ", "Type: ") + (if (m.mms) "MMS" else "SMS"))
                    Text(tr("طول: ", "Length: ") + m.body.length)
                }
            }, confirmButton = { TextButton({ details = null }) { Text(tr("باشه", "OK"), color = p.primary) } })
    }
}

fun attIcon(m: String): androidx.compose.ui.graphics.vector.ImageVector = when {
    m.contains("vcard", true) -> Icons.Default.Person
    m.startsWith("audio/") -> Icons.Default.AudioFile
    m.startsWith("video/") -> Icons.Default.Videocam
    else -> Icons.Default.Description
}

@Composable
private fun RowScope.AttItem(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, label: String, onClick: () -> Unit) {
    val p = LocalPal.current
    Column(Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(54.dp).shadow(8.dp, CircleShape, ambientColor = tint, spotColor = tint).clip(CircleShape)
            .background(Brush.linearGradient(listOf(tint, tint.copy(alpha = .6f)))), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp))
        }
        Text(label, color = p.sub, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(top = 6.dp))
    }
}
