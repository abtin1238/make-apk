import 'dart:async';
import 'package:flutter/material.dart';
import '../app_state.dart';
import '../palettes.dart';
import '../services.dart';

/// Alpha helper that works on every Flutter version (no withOpacity / .value).
Color alpha(Color c, double o) => c.withAlpha((o.clamp(0.0, 1.0) * 255).round());

/// Background colour of the current palette (kept for older call sites).
Color solidBackground(AbtinPalette p) => p.pageColor(app.styleId);

/// Opaque card colour; comes from the palette in every interface style.
Color solidSurface(AbtinPalette p, bool dark, bool strong, String style) => p.surfaceColor(style, strong: strong);

// ───────────────────────── frosted glass panel ─────────────────────────
class Glass extends StatelessWidget {
  const Glass({
    super.key, required this.child, this.radius = 22, this.padding, this.margin,
    this.strong = false, this.tint, this.borderColor, this.borderWidth = 1, this.blur,
  });
  final Widget child;
  final double radius, borderWidth;
  final EdgeInsetsGeometry? padding, margin;
  final bool strong;
  final Color? tint, borderColor;
  final double? blur; // null = user setting, 0 = no backdrop filter (use inside another glass)

  Widget _flat(BuildContext context, bool dark, String style) {
    final r = style == 'ios' ? radius.clamp(10.0, 14.0).toDouble() : radius.clamp(style == 'minimal' ? 8.0 : 12.0, style == 'uc' ? 22.0 : 26.0).toDouble();
    final br = BorderRadius.circular(r);
    final p = app.palette;
    var surface = solidSurface(p, dark, strong, style);
    if (tint != null) surface = Color.alphaBlend(alpha(tint!, dark ? .26 : .20), surface);
    final inner = Material(type: MaterialType.transparency, child: padding == null ? child : Padding(padding: padding!, child: child));
    final BoxDecoration dec;
    if (style == 'ios') {
      dec = BoxDecoration(color: surface, borderRadius: br, border: borderColor != null ? Border.all(color: borderColor!, width: borderWidth) : null);
    } else if (style == 'neu') {
      final hi = dark ? alpha(Colors.white, .07) : Colors.white;
      final lo = dark ? alpha(Colors.black, .60) : alpha(const Color(0xFF8A96A8), .42);
      dec = BoxDecoration(color: surface, borderRadius: br, boxShadow: [
        BoxShadow(color: lo, blurRadius: 9, offset: const Offset(3.5, 3.5)),
        BoxShadow(color: hi, blurRadius: 9, offset: const Offset(-3.5, -3.5)),
      ]);
    } else if (style == 'uc') {
      dec = BoxDecoration(color: surface, borderRadius: BorderRadius.circular(r), border: Border.all(color: Color(app.accentInt).withAlpha(70), width: 1.2), boxShadow: app.perf ? null : [BoxShadow(color: Colors.black.withAlpha(dark ? 55 : 18), blurRadius: 8, offset: const Offset(0, 3))]);
    } else if (style == 'samsung') {
      dec = BoxDecoration(color: surface, borderRadius: BorderRadius.circular(r), border: Border.all(color: dark ? const Color(0xFF343A44) : const Color(0xFFE6E9EF), width: 1));
    } else {
      dec = BoxDecoration(color: surface, borderRadius: BorderRadius.circular(r), border: Border.all(color: borderColor ?? alpha(dark ? Colors.white : Colors.black, style == 'minimal' ? .06 : .10), width: borderWidth));
    }
    Widget w = DecoratedBox(decoration: dec, child: ClipRRect(borderRadius: br, child: inner));
    if (margin != null) w = Padding(padding: margin!, child: w);
    return w;
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return _flat(context, dark, app.styleId);
  }
}

class GlassCard extends StatelessWidget {
  const GlassCard({super.key, required this.child, this.margin = const EdgeInsets.symmetric(vertical: 4)});
  final Widget child;
  final EdgeInsetsGeometry margin;
  @override
  Widget build(BuildContext context) => Glass(radius: 20, blur: 0, margin: margin, child: child);
}

/// A ListTile inside its own glass card (used by lists).
class GlassTile extends StatelessWidget {
  const GlassTile({super.key, this.leading, this.title, this.subtitle, this.trailing, this.onTap, this.onLongPress, this.dense = false});
  final Widget? leading, title, subtitle, trailing;
  final VoidCallback? onTap, onLongPress;
  final bool dense;
  @override
  Widget build(BuildContext context) => Glass(
        radius: 18, blur: 0, margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: ListTile(dense: dense, leading: leading, title: title, subtitle: subtitle, trailing: trailing, onTap: onTap, onLongPress: onLongPress),
      );
}

// ───────────────────────── colorful icon chip ─────────────────────────
class IconChip extends StatelessWidget {
  const IconChip(this.icon, this.color, {super.key, this.size = 44});
  final IconData icon;
  final Color color;
  final double size;
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(size * .32),
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color.lerp(color, Colors.white, .30)!, color]),
          boxShadow: app.perf ? null : [BoxShadow(color: alpha(color, .45), blurRadius: size * .38, offset: Offset(0, size * .1))],
        ),
        child: Icon(icon, color: Colors.white, size: size * .5),
      );
}

// ───────────────────────── animated / static background ─────────────────────────
/// Flat page background in the palette's colour (no gradients, glows or blur: the glass look is gone).
class GlassBackground extends StatefulWidget {
  const GlassBackground({super.key, required this.child});
  final Widget child;
  @override
  State<GlassBackground> createState() => _GlassBackgroundState();
}

class _GlassBackgroundState extends State<GlassBackground> {
  void _onApp() { if (mounted) setState(() {}); }

  @override
  void initState() { super.initState(); app.addListener(_onApp); }
  @override
  void dispose() { app.removeListener(_onApp); super.dispose(); }

  @override
  Widget build(BuildContext context) => ColoredBox(color: app.palette.pageColor(app.styleId), child: widget.child);
}

/// Drop-in Scaffold replacement: paints the glass background behind the page (opaque, so
/// page transitions never show the previous page through it).
class GlassScaffold extends StatelessWidget {
  const GlassScaffold({super.key, this.appBar, this.body, this.bottomNavigationBar, this.resizeToAvoidBottomInset = true});
  final PreferredSizeWidget? appBar;
  final Widget? body, bottomNavigationBar;
  final bool resizeToAvoidBottomInset;
  @override
  Widget build(BuildContext context) => GlassBackground(
        child: Scaffold(backgroundColor: Colors.transparent, resizeToAvoidBottomInset: resizeToAvoidBottomInset, appBar: appBar, body: body, bottomNavigationBar: bottomNavigationBar),
      );
}

/// Makes room for the soft keyboard in ONE step instead of once per animation frame.
/// The keyboard animates for ~250 ms and Flutter reports ~15 intermediate heights; resizing the web view for each of them
/// fires a storm of `resize` events in the page. Sites such as Telegram / Eitaa web react to that by blurring or re-focusing
/// the field (the keyboard flips between layouts and closes). Here the new height is applied once it has stopped changing.
/// [immediate] (a Flutter text field such as the find bar owns the keyboard) follows the keyboard live.
class SettledKeyboardInset extends StatefulWidget {
  const SettledKeyboardInset({super.key, required this.child, this.immediate = false, this.settle = const Duration(milliseconds: 110)});
  final Widget child;
  final bool immediate;
  final Duration settle;
  @override
  State<SettledKeyboardInset> createState() => _SettledKeyboardInsetState();
}

class _SettledKeyboardInsetState extends State<SettledKeyboardInset> {
  double _raw = 0, _applied = 0;
  Timer? _t;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final raw = MediaQuery.viewInsetsOf(context).bottom;
    if (raw == _raw) return;
    _raw = raw;
    _t?.cancel();
    if (widget.immediate) {
      _applied = raw;
      return;
    }
    _t = Timer(widget.settle, () {
      if (mounted && _applied != _raw) setState(() => _applied = _raw);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Padding(padding: EdgeInsets.only(bottom: _applied), child: widget.child);
}

// ───────────────────────── sheets & dialogs ─────────────────────────
Future<T?> showGlassSheet<T>({required BuildContext context, required WidgetBuilder builder, bool isScrollControlled = false, bool useSafeArea = false}) {
  return showModalBottomSheet<T>(
    context: context, isScrollControlled: isScrollControlled, useSafeArea: useSafeArea,
    backgroundColor: solidSurface(app.palette, app.dark, true, 'solid'), elevation: 0, barrierColor: Colors.black54,
    sheetAnimationStyle: app.flag('uiAnim') ? null : AnimationStyle.noAnimation,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
      child: Glass(radius: 30, strong: true, child: builder(ctx)),
    ),
  );
}

Future<T?> showGlassDialog<T>({required BuildContext context, required WidgetBuilder builder, bool barrierDismissible = true}) {
  return showGeneralDialog<T>(
    context: context, barrierDismissible: barrierDismissible, barrierLabel: 'dialog', barrierColor: Colors.black38,
    transitionDuration: app.flag('uiAnim') ? const Duration(milliseconds: 220) : Duration.zero,
    pageBuilder: (ctx, _, __) => SafeArea(child: Center(child: Builder(builder: builder))),
    transitionBuilder: (ctx, anim, _, child) {
      final c = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
      return FadeTransition(opacity: c, child: ScaleTransition(scale: Tween<double>(begin: .92, end: 1).animate(c), child: child));
    },
  );
}

// ───────────────────────── theme picker ─────────────────────────
class PalettePicker extends StatelessWidget {
  const PalettePicker({super.key});

  Widget _blob(int c, double d) => Container(width: d, height: d, decoration: BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [alpha(Color(c), .85), alpha(Color(c), 0)])));

  Widget _mini(bool dark, double r) => DecoratedBox(decoration: BoxDecoration(color: alpha(Colors.white, dark ? .16 : .70), borderRadius: BorderRadius.circular(r), border: Border.all(color: alpha(Colors.white, .35))));

  Widget _item(BuildContext context, String id, String name, AbtinPalette p, bool sel) {
    final cs = Theme.of(context).colorScheme;
    return GestureDetector(
      onTap: () => app.setPalette(id),
      child: SizedBox(
        width: 88,
        child: Column(children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 200), width: 78, height: 106,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(22),
              color: p.pageColor(app.styleId),
              border: Border.all(color: sel ? Color(p.accent) : alpha(Colors.white, .25), width: sel ? 3 : 1),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(19),
              child: Stack(children: [
                Positioned(left: 8, right: 8, top: 10, height: 14, child: _mini(p.dark, 7)),
                Positioned(left: 8, width: 30, bottom: 54, height: 6, child: DecoratedBox(decoration: BoxDecoration(color: Color(p.accent), borderRadius: BorderRadius.circular(3)))),
                Positioned(left: 8, right: 8, bottom: 10, height: 36, child: _mini(p.dark, 11)),
                if (sel) Center(child: Container(width: 26, height: 26, decoration: BoxDecoration(shape: BoxShape.circle, color: Color(p.accent)), child: const Icon(Icons.check, size: 17, color: Colors.white))),
              ]),
            ),
          ),
          const SizedBox(height: 7),
          Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, fontWeight: sel ? FontWeight.bold : FontWeight.normal, color: sel ? cs.primary : null)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cur = app.str('palette');
    final bd = palettes.firstWhere((p) => p.id == 'browser-dark'), bl = palettes.firstWhere((p) => p.id == 'browser-light');
    final auto = AbtinPalette('auto', 'خودکار', 'Auto', true, [...bd.bg], [...bl.blobs], bd.accent);
    return SizedBox(
      height: 160,
      child: ListView(
        scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        children: [
          _item(context, 'auto', tr('خودکار', 'Auto'), auto, cur == 'auto'),
          for (final p in palettes) _item(context, p.id, tr(p.fa, p.en), p, cur == p.id),
        ],
      ),
    );
  }
}

/// Height of the top bar (tabs + address bar) of the browser page, set by it: message bars start BELOW it instead of covering the address bar.
double snackTopInset = 0;

/// Message bar (toast) at the TOP of the screen instead of the bottom (just under the browser's address bar).
void snackTop(BuildContext context, String msg) {
  final mq = MediaQuery.of(context);
  final m = ScaffoldMessenger.of(context);
  final bottom = (mq.size.height - mq.viewInsets.bottom - mq.padding.top - snackTopInset - 84).clamp(0.0, double.infinity);
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(
    content: Text(msg),
    behavior: SnackBarBehavior.floating,
    dismissDirection: DismissDirection.up,
    margin: EdgeInsets.fromLTRB(12, 0, 12, bottom),
  ));
}
