import 'package:flutter/widgets.dart';

// The receiver UI is native (ir.abtin.remote.receiver.MainActivity).
// This entrypoint only exists so the project builds as a Flutter app.
void main() => runApp(const SizedBox.shrink());
