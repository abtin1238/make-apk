package ir.abtin.remote.receiver

import android.content.Context
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.bluetooth.BluetoothManager
import android.os.Build
import android.util.Log
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors
import kotlin.concurrent.thread
import kotlin.random.Random

/**
 * سرور TCP (پورت 39877) برای دریافت دستورها + پاسخ‌دهی UDP (پورت 39878) برای پیدا کردن خودکار باکس.
 * هر خط یک بسته‌ی JSON است. قبل از هر دستور باید بسته‌ی hello با PIN درست ارسال شود.
 */
object RemoteServer {
    const val PORT = 39877
    const val DISCOVERY_PORT = 39878
    private const val TAG = "AbtinRemote"

    @Volatile private var server: ServerSocket? = null
    @Volatile private var nativeHidden = false
    @Volatile private var udp: DatagramSocket? = null
    @Volatile private var btServer: BluetoothServerSocket? = null
    @Volatile private var btRunning = false
    // UUID اختصاصی Abtin: UUID استاندارد SPP (0x1101) را بعضی تلویزیون‌ها خودشان ثبت کرده‌اند و گوشی به‌جای اپ ما به سرویس آن وصل و بعد از چند ثانیه قطع می‌شد.
    val appUuid: UUID = UUID.fromString("6f2a9c1e-5b7d-4e83-9a14-3c8d2e7b0a51")
    private val clients = Executors.newCachedThreadPool()

    fun isRunning(): Boolean = server?.isClosed == false
    fun isBluetoothRunning(): Boolean = btRunning

    fun pin(context: Context): String {
        val sp = context.applicationContext.getSharedPreferences("abtin_remote", Context.MODE_PRIVATE)
        var p = sp.getString("pin", null)
        if (p == null || p.length != 4) {
            p = Random.nextInt(1000, 10000).toString()
            sp.edit().putString("pin", p).apply()
        }
        return p
    }

    fun regeneratePin(context: Context): String {
        val sp = context.applicationContext.getSharedPreferences("abtin_remote", Context.MODE_PRIVATE)
        sp.edit().remove("pin").apply()
        return pin(context)
    }

    @Synchronized
    fun start(context: Context) {
        val app = context.applicationContext
        if (server?.isClosed == false) return
        try {
            val s = ServerSocket()
            s.reuseAddress = true
            s.bind(InetSocketAddress(PORT))
            server = s
        } catch (e: Exception) {
            Log.e(TAG, "cannot bind tcp", e)
            return
        }
        thread(name = "AbtinRemoteServer", isDaemon = true) {
            val s = server
            try {
                while (s != null && !s.isClosed) {
                    val client = s.accept()
                    clients.execute { handle(app, client) }
                }
            } catch (e: Exception) {
                if (s?.isClosed != true) Log.e(TAG, "server", e)
            }
        }
        startDiscovery()
    }


    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences("abtin_remote", Context.MODE_PRIVATE)

    fun bluetoothWanted(context: Context): Boolean = prefs(context).getBoolean("bt_wanted", false)
    fun setBluetoothWanted(context: Context, v: Boolean) { prefs(context).edit().putBoolean("bt_wanted", v).apply() }

    /** بعد از ری‌استارت سرویس/باکس، اگر کاربر قبلاً بلوتوث گیرنده را روشن کرده بود دوباره باز می‌شود. */
    fun restoreBluetooth(context: Context) {
        if (btRunning || !bluetoothWanted(context)) return
        if (Build.VERSION.SDK_INT >= 31 &&
            context.checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != android.content.pm.PackageManager.PERMISSION_GRANTED) return
        startBluetooth(context)
    }

    /** Bluetooth Classic RFCOMM/SPP server. Uses the same newline-delimited JSON and PIN protocol as TCP. */
    @Synchronized
    fun startBluetooth(context: Context): Boolean {
        if (btRunning) return true
        return try {
            val manager = context.applicationContext.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
            val adapter = manager.adapter
            if (adapter == null) { BtDebug.log("❌ این دستگاه آداپتر بلوتوث ندارد"); return false }
            if (!adapter.isEnabled) { BtDebug.log("❌ بلوتوث خاموش است"); return false }
            val listener = adapter.listenUsingRfcommWithServiceRecord("Abtin Remote Receiver", appUuid)
            btServer = listener
            btRunning = true
            BtDebug.log("✅ سرور RFCOMM شروع شد و منتظر اتصال گوشی است (UUID اختصاصی Abtin)")
            val app = context.applicationContext
            thread(name = "AbtinRemoteBluetooth", isDaemon = true) {
                try {
                    while (btRunning && btServer === listener) {
                        val client = listener.accept()
                        BtDebug.log("📲 اتصال از ${try { client.remoteDevice?.name } catch (_: Throwable) { "?" }} ${try { client.remoteDevice?.address } catch (_: Throwable) { "" }}")
                        clients.execute { handleBluetooth(app, client) }
                    }
                } catch (e: Exception) {
                    if (btRunning && btServer === listener) { Log.e(TAG, "Bluetooth RFCOMM server", e); BtDebug.err("accept() شکست خورد", e) }
                } finally {
                    // فقط اگر هنوز همین listener فعال است وضعیت را خاموش کن (نه وقتی stop/start سریع رخ داده)
                    synchronized(this@RemoteServer) {
                        if (btServer === listener) { btRunning = false; btServer = null }
                    }
                    try { listener.close() } catch (_: Exception) {}
                }
            }
            true
        } catch (e: Exception) {
            btRunning = false
            Log.e(TAG, "cannot start Bluetooth RFCOMM", e)
            BtDebug.err("شروع سرور RFCOMM ناموفق (احتمالاً مجوز BLUETOOTH_CONNECT/ADVERTISE)", e)
            false
        }
    }

    @Synchronized
    fun stopBluetooth() {
        btRunning = false
        try { btServer?.close() } catch (_: Exception) {}
        btServer = null
    }

    private fun handleBluetooth(context: Context, socket: BluetoothSocket) {
        socket.use { s ->
            try {
                val input = BufferedReader(InputStreamReader(s.inputStream, Charsets.UTF_8))
                val output = s.outputStream
                val expected = pin(context)
                var authed = false
                while (true) {
                    val line = input.readLine() ?: break
                    if (line.length > 16_384) continue
                    val j = try { JSONObject(line) } catch (_: Exception) { continue }
                    if (j.optString("type") == "hello") {
                        if (j.optString("pin") == expected) {
                            authed = true
                            BtDebug.log("✅ hello با PIN درست؛ احراز هویت شد")
                            writeBluetooth(output, JSONObject().put("type", "hello").put("ok", true)
                                .put("name", Build.MODEL ?: "Android Box")
                                .put("accessibility", RemoteAccessibilityService.instance != null))
                        } else {
                            BtDebug.log("⛔ hello با PIN اشتباه رد شد")
                            writeBluetooth(output, JSONObject().put("type", "hello").put("ok", false).put("reason", "pin"))
                            break
                        }
                        continue
                    }
                    if (authed) try { dispatch(j) } catch (e: Throwable) { Log.w(TAG, "bad Bluetooth packet", e) }
                }
            } catch (e: Throwable) {
                Log.i(TAG, "Bluetooth client disconnected")
                BtDebug.log("🔌 اتصال بلوتوث قطع شد (${e.javaClass.simpleName})")
            }
        }
    }

    private fun writeBluetooth(output: OutputStream, json: JSONObject) {
        synchronized(output) {
            output.write((json.toString() + "\n").toByteArray(Charsets.UTF_8))
            output.flush()
        }
    }

    @Synchronized
    fun stopWifi() {
        try { server?.close() } catch (_: Exception) {}
        try { udp?.close() } catch (_: Exception) {}
        server = null
        udp = null
        RemoteAccessibilityService.post { hideCursor() }
    }

    @Synchronized
    fun stop() {
        stopWifi()
        stopBluetooth()
    }

    private fun startDiscovery() {
        thread(name = "AbtinRemoteDiscovery", isDaemon = true) {
            try {
                val sock = DatagramSocket(null)
                sock.reuseAddress = true
                sock.broadcast = true
                sock.bind(InetSocketAddress(DISCOVERY_PORT))
                udp = sock
                val buf = ByteArray(256)
                while (!sock.isClosed) {
                    val p = DatagramPacket(buf, buf.size)
                    sock.receive(p)
                    val msg = String(p.data, 0, p.length)
                    if (msg.startsWith("ABTIN_DISCOVER")) {
                        val name = (Build.MODEL ?: "Android Box").replace(';', ' ')
                        val reply = "ABTIN_RECEIVER;$name;$PORT".toByteArray()
                        sock.send(DatagramPacket(reply, reply.size, p.address, p.port))
                    }
                }
            } catch (e: Exception) {
                if (udp?.isClosed != true) Log.w(TAG, "discovery stopped", e)
            }
        }
    }

    private fun reply(socket: Socket, json: JSONObject) {
        synchronized(socket) {
            try {
                val out = socket.getOutputStream()
                out.write((json.toString() + "\n").toByteArray())
                out.flush()
            } catch (_: Exception) {}
        }
    }

    private fun handle(context: Context, socket: Socket) {
        socket.use { s ->
            try {
                s.soTimeout = 120_000
                s.tcpNoDelay = true
                s.keepAlive = true
                val input = s.getInputStream().bufferedReader()
                val expected = pin(context)
                var authed = false
                while (true) {
                    val line = input.readLine() ?: break
                    if (line.length > 16_384) continue
                    val j = try { JSONObject(line) } catch (e: Exception) { continue }
                    val type = j.optString("type")
                    if (type == "hello") {
                        if (j.optString("pin") == expected) {
                            authed = true
                            reply(s, JSONObject()
                                .put("type", "hello").put("ok", true)
                                .put("name", Build.MODEL ?: "Android Box")
                                .put("accessibility", RemoteAccessibilityService.instance != null))
                        } else {
                            reply(s, JSONObject().put("type", "hello").put("ok", false).put("reason", "pin"))
                            break
                        }
                        continue
                    }
                    if (!authed) continue
                    try { dispatch(j) } catch (e: Throwable) { Log.w(TAG, "bad packet", e) }
                }
            } catch (e: Throwable) {
                Log.i(TAG, "client disconnected")
            }
        }
    }

    private fun num(j: JSONObject, key: String): Float {
        val v = j.optDouble(key, 0.0)
        return if (v.isNaN() || v.isInfinite()) 0f else v.toFloat()
    }

    private fun dispatch(j: JSONObject) {
        when (j.optString("type")) {
            "ping" -> {}
            "move", "pointer" -> { val dx = num(j, "dx"); val dy = num(j, "dy"); if (InjectorClient.move(dx, dy)) { if (!nativeHidden) { nativeHidden = true; RemoteAccessibilityService.post { hideCursor() } } } else { nativeHidden = false; RemoteAccessibilityService.post { movePointer(dx, dy) } } }
            "mouse" -> { val b = j.optString("button", "left"); val d = j.optBoolean("down", true); if (!InjectorClient.button(b, d)) RemoteAccessibilityService.post { mouseButton(b, d) } }
            "click" -> { val b = j.optString("button", "left"); if (!InjectorClient.click(b)) RemoteAccessibilityService.post { click(b) } }
            "scroll" -> { val dx = num(j, "dx"); val dy = num(j, "dy"); if (!InjectorClient.scroll(dx, dy)) RemoteAccessibilityService.post { scrollBy(dx, dy) } }
            "text" -> { val t = j.optString("text").take(1000); RemoteAccessibilityService.post { typeText(t) } }
            "stick" -> { val side = j.optString("side", "left"); val x = num(j, "x"); val y = num(j, "y"); RemoteAccessibilityService.post { stick(side, x, y) } }
            "pad" -> { val b = j.optString("button"); val d = j.optBoolean("down", true); RemoteAccessibilityService.post { padButton(b, d) } }
            "key" -> { val k = j.optString("key"); if (!InjectorClient.key(k)) RemoteAccessibilityService.post { key(k) } }
        }
    }
}
