package ir.abtin.remote.receiver

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** گزارش دیباگ بلوتوث: هر مرحله‌ی RFCOMM (مجوز، روشن بودن، listen، accept، PIN، قطع) اینجا ثبت و روی صفحه نشان داده می‌شود. */
object BtDebug {
    private val lines = ArrayDeque<String>()
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun log(msg: String) {
        lines.addLast("${fmt.format(Date())}  $msg")
        while (lines.size > 40) lines.removeFirst()
    }

    fun err(msg: String, e: Throwable) = log("❌ $msg: ${e.javaClass.simpleName}: ${e.message}")

    @Synchronized
    fun history(): String = if (lines.isEmpty()) "(هنوز رویدادی ثبت نشده)" else lines.joinToString("\n")

    private fun granted(c: Context, p: String): String =
        if (Build.VERSION.SDK_INT < 31) "نیاز ندارد (Android ${Build.VERSION.RELEASE})"
        else if (c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED) "✅ داده شده" else "❌ داده نشده"

    private fun resolves(c: Context, action: String): String =
        if (c.packageManager.resolveActivity(Intent(action), 0) != null) "✅ هست" else "❌ روی این تلویزیون وجود ندارد"

    /** وضعیت فعلی بلوتوث + تاریخچه‌ی رویدادها (کل متن را برای دیباگ بفرستید). */
    fun report(c: Context): String {
        val sb = StringBuilder()
        sb.append("مدل: ${Build.MANUFACTURER} ${Build.MODEL} | Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\n")
        try {
            val adapter = (c.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
            sb.append("سخت‌افزار بلوتوث: ${if (adapter == null) "❌ ندارد" else "✅ دارد"}\n")
            sb.append("پکیج بلوتوث کلاسیک: ${if (c.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)) "✅" else "❌ FEATURE_BLUETOOTH ندارد"}\n")
            if (adapter != null) {
                sb.append("روشن است: ${if (adapter.isEnabled) "✅" else "❌ خاموش"}\n")
                sb.append("مجوز BLUETOOTH_CONNECT: ${granted(c, "android.permission.BLUETOOTH_CONNECT")}\n")
                sb.append("مجوز BLUETOOTH_ADVERTISE: ${granted(c, "android.permission.BLUETOOTH_ADVERTISE")}\n")
                try {
                    val mode = adapter.scanMode
                    sb.append("قابل‌مشاهده: " + when (mode) {
                        BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE -> "✅ بله"
                        BluetoothAdapter.SCAN_MODE_CONNECTABLE -> "⛔ نه (فقط قابل اتصال)"
                        else -> "⛔ نه (خاموش/غیرقابل اتصال)"
                    } + "\n")
                } catch (e: Throwable) { sb.append("قابل‌مشاهده: نامشخص (${e.javaClass.simpleName})\n") }
                try {
                    val bonded = adapter.bondedDevices
                    sb.append("دستگاه‌های Pair شده: ${bonded.size}\n")
                    bonded.take(8).forEach { sb.append("  • ${it.name ?: "?"}  ${it.address}\n") }
                } catch (e: Throwable) { sb.append("لیست Pair شده‌ها: خوانده نشد (${e.javaClass.simpleName})\n") }
            }
        } catch (e: Throwable) {
            sb.append("خطا در خواندن وضعیت: ${e.javaClass.simpleName}: ${e.message}\n")
        }
        sb.append("صفحه‌ی «درخواست روشن‌کردن بلوتوث»: ${resolves(c, BluetoothAdapter.ACTION_REQUEST_ENABLE)}\n")
        sb.append("صفحه‌ی «قابل‌مشاهده کردن»: ${resolves(c, BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)}\n")
        sb.append("صفحه‌ی تنظیمات بلوتوث: ${resolves(c, Settings.ACTION_BLUETOOTH_SETTINGS)}\n")
        sb.append("سرور RFCOMM: ${if (RemoteServer.isBluetoothRunning()) "✅ در حال گوش دادن" else "⛔ متوقف"}\n")
        sb.append("\nرویدادها:\n").append(history())
        return sb.toString()
    }
}
