package ir.abtin.remote.receiver

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var serverBtn: Button
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 2000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(32, 40, 32, 32)

        info = TextView(this)
        info.textSize = 17f
        box.addView(info)

        val accBtn = Button(this)
        accBtn.text = "فعال‌سازی سرویس دسترس‌پذیری (ضروری)"
        accBtn.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        box.addView(accBtn)

        serverBtn = Button(this)
        serverBtn.setOnClickListener {
            if (RemoteServer.isRunning()) ServerService.stop(this) else ServerService.start(this)
            handler.postDelayed({ refresh() }, 400)
        }
        box.addView(serverBtn)

        val pinBtn = Button(this)
        pinBtn.text = "ساخت PIN جدید"
        pinBtn.setOnClickListener { RemoteServer.regeneratePin(this); refresh() }
        box.addView(pinBtn)

        val scroll = ScrollView(this)
        scroll.addView(box)
        setContentView(scroll)

        ServerService.start(this)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun accessibilityEnabled(): Boolean {
        if (RemoteAccessibilityService.instance != null) return true
        return try {
            val flat = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val me = ComponentName(this, RemoteAccessibilityService::class.java).flattenToString()
            flat.split(':').any { it.equals(me, ignoreCase = true) }
        } catch (_: Exception) { false }
    }

    private fun ips(): String = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { ni ->
                ni.inetAddresses.toList()
                    .filter { it is Inet4Address && !it.isLoopbackAddress }
                    .map { "${it.hostAddress}  (${ni.name})" }
            }
            .joinToString("\n")
            .ifEmpty { "IP نامشخص" }
    } catch (_: Exception) { "IP نامشخص" }

    private fun refresh() {
        val running = RemoteServer.isRunning()
        serverBtn.text = if (running) "توقف سرور شبکه" else "شروع سرور شبکه"
        val acc = if (accessibilityEnabled()) "✅ فعال" else "❌ غیرفعال (دکمه‌ی بالا را بزنید و Abtin Remote Receiver را روشن کنید)"
        info.text = "Abtin Remote Receiver\n\n" +
            "وضعیت سرور: " + (if (running) "✅ فعال" else "⛔ متوقف") + "\n" +
            "سرویس دسترس‌پذیری: " + acc + "\n\n" +
            "آدرس IP باکس:\n" + ips() + "\n\n" +
            "پورت: " + RemoteServer.PORT + "\n" +
            "PIN اتصال: " + RemoteServer.pin(this) + "\n\n" +
            "گوشی و باکس باید روی یک شبکه (یا هات‌اسپات گوشی) باشند. در اپ گوشی «جستجوی خودکار» را بزنید یا IP و PIN را وارد کنید.\n\n" +
            "برای موس و کیبورد از Wi-Fi یا Bluetooth استفاده کنید. برای دسته‌ی بازی در اپ گوشی Bluetooth HID را فعال کنید و از تنظیمات بلوتوث همین باکس گوشی را Pair کنید."
        info.layoutDirection = View.LAYOUT_DIRECTION_RTL
    }
}
