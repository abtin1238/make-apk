package ir.abtin.remote.receiver

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import kotlin.concurrent.thread
import kotlin.math.hypot

/**
 * اجرای فرمان‌های دریافتی: نشانگر موس (overlay)، کلیک/درگ/اسکرول، کیبورد و کلیدهای سیستمی.
 * همه‌ی فراخوانی‌ها از طریق post() روی Main thread و به ترتیب اجرا می‌شوند.
 */
class RemoteAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: RemoteAccessibilityService? = null
        private val ui = Handler(Looper.getMainLooper())

        fun post(block: RemoteAccessibilityService.() -> Unit) {
            val s = instance ?: return
            ui.post { s.block() }
        }
    }

    // ---------- نشانگر ----------
    private class CursorView(ctx: Context, val sizePx: Int) : View(ctx) {
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }
        private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK; style = Paint.Style.STROKE
            strokeWidth = sizePx * 0.07f; strokeJoin = Paint.Join.ROUND
        }
        private val path = Path()
        override fun onDraw(canvas: Canvas) {
            val s = sizePx.toFloat()
            path.reset()
            path.moveTo(s * 0.08f, s * 0.04f)
            path.lineTo(s * 0.08f, s * 0.80f)
            path.lineTo(s * 0.30f, s * 0.60f)
            path.lineTo(s * 0.46f, s * 0.96f)
            path.lineTo(s * 0.60f, s * 0.89f)
            path.lineTo(s * 0.44f, s * 0.54f)
            path.lineTo(s * 0.74f, s * 0.54f)
            path.close()
            canvas.drawPath(path, fill)
            canvas.drawPath(path, edge)
        }
    }

    private var cursorView: CursorView? = null
    private var cursorParams: WindowManager.LayoutParams? = null
    private var cursorSize = 40
    private var cursorX = -1f
    private var cursorY = -1f

    // ---------- وضعیت کلیک و درگ ----------
    private var mouseDown = false
    private var downX = 0f
    private var downY = 0f
    private var downAt = 0L
    private var dragFallback = false
    private var dragActive = false
    private var dragEnding = false
    private var dragInFlight = false
    private var dragStroke: GestureDescription.StrokeDescription? = null
    private var dragX = 0f
    private var dragY = 0f

    override fun onServiceConnected() {
        instance = this
        cursorSize = (resources.displayMetrics.density * 28f).toInt().coerceAtLeast(24)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        removeCursor()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> {
        val dm = DisplayMetrics()
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private fun ensureCursor() {
        // نشانگر خود اندروید (Injector) فعال است: نشانگر ساختگی نمی‌خواهیم
        if (InjectorClient.active) {
            removeCursor()
            return
        }
        val (w, h) = screenSize()
        if (cursorX < 0f || cursorY < 0f) { cursorX = w / 2f; cursorY = h / 2f }
        if (cursorView != null) return
        try {
            val v = CursorView(this, cursorSize)
            val lp = WindowManager.LayoutParams(
                cursorSize, cursorSize,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = (cursorX - cursorSize * 0.08f).toInt()
            lp.y = (cursorY - cursorSize * 0.04f).toInt()
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(v, lp)
            cursorView = v
            cursorParams = lp
        } catch (_: Exception) {
        }
    }

    private fun updateCursor() {
        val v = cursorView ?: return
        val lp = cursorParams ?: return
        lp.x = (cursorX - cursorSize * 0.08f).toInt()
        lp.y = (cursorY - cursorSize * 0.04f).toInt()
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
    }

    private fun removeCursor() {
        val v = cursorView ?: return
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (_: Exception) {
        }
        cursorView = null
        cursorParams = null
    }

    // ---------- موس ----------
    fun movePointer(dx: Float, dy: Float) {
        ensureCursor()
        val (w, h) = screenSize()
        cursorX = (cursorX + dx).coerceIn(0f, (w - 1).toFloat())
        cursorY = (cursorY + dy).coerceIn(0f, (h - 1).toFloat())
        updateCursor()
        if (mouseDown && !dragActive && !dragFallback && hypot(cursorX - downX, cursorY - downY) > 10f) {
            beginDrag()
        } else if (dragActive) {
            pumpDrag()
        }
    }

    fun mouseButton(button: String, down: Boolean) {
        ensureCursor()
        when (button) {
            "left" -> {
                if (down) {
                    mouseDown = true
                    downX = cursorX; downY = cursorY
                    downAt = SystemClock.uptimeMillis()
                    dragFallback = false
                } else if (mouseDown) {
                    mouseDown = false
                    releaseLeft()
                }
            }
            "right" -> if (!down) { if (!clickAt(cursorX, cursorY, true)) tap(cursorX, cursorY, 650L) }
            "middle" -> if (!down) performGlobalAction(GLOBAL_ACTION_BACK)
        }
    }

    fun click(button: String) {
        mouseButton(button, true)
        mouseButton(button, false)
    }

    private fun releaseLeft() {
        when {
            dragActive -> { dragEnding = true; pumpDrag() }
            dragFallback -> { swipe(downX, downY, cursorX, cursorY, 300L); dragFallback = false }
            else -> {
                val held = SystemClock.uptimeMillis() - downAt
                val long = held > 500L
                val noTouch = !packageManager.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
                val done = clickAt(cursorX, cursorY, long) ||
                    (noTouch && focusClickAt(cursorX, cursorY)) ||
                    tap(cursorX, cursorY, if (long) 650L else 40L)
                // تی‌وی‌هایی که لمس را نمی‌پذیرند: فوکوس + Enter روی چیزی که زیر نشانگر است
                if (!done) focusClickAt(cursorX, cursorY)
            }
        }
    }

    private fun beginDrag() {
        if (Build.VERSION.SDK_INT >= 26) {
            dragActive = true
            dragEnding = false
            dragStroke = null
            dragX = downX
            dragY = downY
            pumpDrag()
        } else {
            dragFallback = true
        }
    }

    private fun pumpDrag() {
        if (Build.VERSION.SDK_INT < 26) return
        if (dragInFlight || !dragActive) return
        val tx = cursorX
        val ty = cursorY
        val ending = dragEnding
        val path = Path()
        path.moveTo(dragX, dragY)
        if (tx != dragX || ty != dragY) path.lineTo(tx, ty)
        val prev = dragStroke
        val stroke = if (prev == null) {
            GestureDescription.StrokeDescription(path, 0, 50L, !ending)
        } else {
            prev.continueStroke(path, 0, 20L, !ending)
        }
        dragStroke = stroke
        dragX = tx
        dragY = ty
        dragInFlight = true
        val ok = dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            object : AccessibilityService.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    dragInFlight = false
                    if (ending) {
                        dragActive = false
                        dragStroke = null
                    } else if (dragEnding || cursorX != dragX || cursorY != dragY) {
                        pumpDrag()
                    }
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    dragInFlight = false
                    dragActive = false
                    dragStroke = null
                }
            },
            null
        )
        if (!ok) {
            dragInFlight = false
            dragActive = false
            dragStroke = null
        }
    }

    // ---------- کلیک و اسکرول بدون gesture (برای باکس‌هایی که dispatchGesture را اجرا نمی‌کنند) ----------
    private fun nodeAt(root: AccessibilityNodeInfo, x: Int, y: Int, pred: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val r = Rect()
        var best: AccessibilityNodeInfo? = null
        fun walk(n: AccessibilityNodeInfo, depth: Int) {
            if (depth > 60) return
            n.getBoundsInScreen(r)
            if (!r.contains(x, y) || !n.isVisibleToUser) return
            if (pred(n)) best = n
            for (i in 0 until n.childCount) {
                val c = n.getChild(i) ?: continue
                walk(c, depth + 1)
            }
        }
        walk(root, 0)
        return best
    }

    private fun windowRoots(): List<AccessibilityNodeInfo> {
        val ws = try { windows } catch (_: Exception) { null }
        val roots = ws?.filter { it.type != AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY }
            ?.sortedByDescending { it.layer }
            ?.mapNotNull { it.root } ?: emptyList()
        return roots.ifEmpty { listOfNotNull(rootInActiveWindow) }
    }

    private fun clickAt(x: Float, y: Float, long: Boolean): Boolean {
        for (root in windowRoots()) {
            val n = nodeAt(root, x.toInt(), y.toInt()) { it.isEnabled && (if (long) it.isLongClickable else it.isClickable) } ?: continue
            val act = if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK
            if (n.performAction(act)) return true
        }
        return false
    }

    private fun scrollAt(dx: Float, dy: Float): Boolean {
        val actions = ArrayList<Int>()
        if (dy > 0f) actions.add(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN.id)
        if (dy < 0f) actions.add(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP.id)
        if (dx > 0f) actions.add(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT.id)
        if (dx < 0f) actions.add(AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT.id)
        if (dy != 0f || dx != 0f) actions.add(if (dy + dx > 0f) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
        for (root in windowRoots()) {
            val n = nodeAt(root, cursorX.toInt(), cursorY.toInt()) { it.isScrollable } ?: continue
            for (a in actions) if (n.performAction(a)) return true
        }
        return false
    }

    private fun tap(x: Float, y: Float, duration: Long): Boolean {
        val p = Path()
        p.moveTo(x, y)
        return try {
            dispatchGesture(
                GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(p, 0, duration))
                    .build(), null, null
            )
        } catch (_: Exception) {
            false
        }
    }

    /** عنصر زیر نشانگر را فوکوس می‌کند و کلیک می‌دهد؛ اگر کلیک‌پذیر نبود Enter واقعی/DPAD_CENTER می‌فرستد. */
    private fun focusClickAt(x: Float, y: Float): Boolean {
        for (root in windowRoots()) {
            val n = nodeAt(root, x.toInt(), y.toInt()) { it.isEnabled && (it.isFocusable || it.isClickable) } ?: continue
            val a = n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            val b = n.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS)
            if (clickNode(n)) return true
            if (a || b) {
                if (!InjectorClient.key("ENTER")) enterKey()
                return true
            }
        }
        return false
    }

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, duration: Long) {
        if (x1 == x2 && y1 == y2) return
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(p, 0, duration))
                .build(), null, null
        )
    }

    /** dy مثبت = اسکرول به پایین (دیدن محتوای پایین‌تر)، dx مثبت = اسکرول به راست */
    fun scrollBy(dx: Float, dy: Float) {
        ensureCursor()
        if (scrollAt(dx, dy)) return
        val (w, h) = screenSize()
        val sx = dx.coerceIn(-8f, 8f) * 120f
        val sy = dy.coerceIn(-8f, 8f) * 120f
        val x1 = cursorX.coerceIn(20f, w - 20f)
        val y1 = cursorY.coerceIn(20f, h - 20f)
        val x2 = (x1 - sx).coerceIn(1f, (w - 1).toFloat())
        val y2 = (y1 - sy).coerceIn(1f, (h - 1).toFloat())
        swipe(x1, y1, x2, y2, 160L)
    }

    // ---------- کیبورد ----------
    private fun findEditable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable && node.isVisibleToUser) return node
        for (i in 0 until node.childCount) {
            val f = findEditable(node.getChild(i))
            if (f != null) return f
        }
        return null
    }

    private fun inputNode(): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null && focused.isEditable) return focused
        return findEditable(root)
    }

    private fun currentText(n: AccessibilityNodeInfo): String {
        if (Build.VERSION.SDK_INT >= 26 && n.isShowingHintText) return ""
        return n.text?.toString() ?: ""
    }

    private fun selection(n: AccessibilityNodeInfo, len: Int): Pair<Int, Int> {
        var s = n.textSelectionStart
        var e = n.textSelectionEnd
        if (s < 0 || e < 0) { s = len; e = len }
        if (s > e) { val t = s; s = e; e = t }
        return s.coerceIn(0, len) to e.coerceIn(0, len)
    }

    private fun applyText(n: AccessibilityNodeInfo, value: String, caret: Int) {
        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, value)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        setCaret(n, caret)
    }

    private fun setCaret(n: AccessibilityNodeInfo, pos: Int) {
        val a = Bundle()
        a.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, pos)
        a.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, pos)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, a)
    }

    fun typeText(value: String) {
        if (value.isEmpty()) return
        val n = inputNode() ?: return
        val cur = currentText(n)
        val (s, e) = selection(n, cur.length)
        val out = cur.substring(0, s) + value + cur.substring(e)
        applyText(n, out, s + value.length)
    }

    private fun backspace() {
        val n = inputNode() ?: return
        val cur = currentText(n)
        val (s, e) = selection(n, cur.length)
        if (s != e) {
            applyText(n, cur.substring(0, s) + cur.substring(e), s)
        } else if (s > 0) {
            applyText(n, cur.substring(0, s - 1) + cur.substring(s), s - 1)
        }
    }

    private fun deleteForward() {
        val n = inputNode() ?: return
        val cur = currentText(n)
        val (s, e) = selection(n, cur.length)
        if (s != e) {
            applyText(n, cur.substring(0, s) + cur.substring(e), s)
        } else if (s < cur.length) {
            applyText(n, cur.substring(0, s) + cur.substring(s + 1), s)
        }
    }

    private fun moveCaret(delta: Int): Boolean {
        val root = rootInActiveWindow ?: return false
        val n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        if (!n.isEditable) return false
        val cur = currentText(n)
        val (s, e) = selection(n, cur.length)
        val base = if (delta < 0) s else e
        val target = base + delta
        if (target < 0 || target > cur.length) return false
        setCaret(n, target)
        return true
    }

    private fun caretTo(end: Boolean): Boolean {
        val n = inputNode() ?: return false
        val len = currentText(n).length
        setCaret(n, if (end) len else 0)
        return true
    }

    private fun enterKey() {
        val root = rootInActiveWindow
        val n = root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (n != null && n.isEditable) {
            if (n.isMultiLine) {
                typeText("\n")
            } else if (Build.VERSION.SDK_INT >= 30) {
                n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            } else {
                clickNode(n)
            }
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && performGlobalAction(GLOBAL_ACTION_DPAD_CENTER)) return
        val f = n ?: root?.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
        if (f != null && clickNode(f)) return
        ensureCursor()
        if (!clickAt(cursorX, cursorY, false)) tap(cursorX, cursorY, 40L)
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        var depth = 0
        while (n != null && depth < 6) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
            depth++
        }
        return false
    }

    private fun firstFocusable(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isFocusable && node.isVisibleToUser && node.isEnabled) return node
        for (i in 0 until node.childCount) {
            val f = firstFocusable(node.getChild(i))
            if (f != null) return f
        }
        return null
    }

    private fun moveFocus(direction: Int): Boolean {
        val root = rootInActiveWindow ?: return false
        val cur = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            ?: root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
        val next = if (cur != null) cur.focusSearch(direction) else firstFocusable(root)
        if (next == null) return false
        val a = next.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = next.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS)
        return a || b
    }

    private fun arrow(direction: Int) {
        when (direction) {
            View.FOCUS_LEFT -> if (moveCaret(-1)) return
            View.FOCUS_RIGHT -> if (moveCaret(1)) return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            val g = when (direction) {
                View.FOCUS_UP -> GLOBAL_ACTION_DPAD_UP
                View.FOCUS_DOWN -> GLOBAL_ACTION_DPAD_DOWN
                View.FOCUS_LEFT -> GLOBAL_ACTION_DPAD_LEFT
                else -> GLOBAL_ACTION_DPAD_RIGHT
            }
            if (performGlobalAction(g)) return
        }
        if (moveFocus(direction)) return
        when (direction) {
            View.FOCUS_UP -> scrollBy(0f, -2f)
            View.FOCUS_DOWN -> scrollBy(0f, 2f)
            View.FOCUS_LEFT -> scrollBy(-2f, 0f)
            View.FOCUS_RIGHT -> scrollBy(2f, 0f)
        }
    }

    private fun editAction(action: Int) {
        val n = inputNode() ?: return
        n.performAction(action)
    }

    private fun selectAll() {
        val n = inputNode() ?: return
        val len = currentText(n).length
        val a = Bundle()
        a.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
        a.putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, len)
        n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, a)
    }

    /** خاموش: Sleep واقعی (با Injector) یا قفل صفحه. روشن: بیدار کردن صفحه. */
    private fun togglePower() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val main = Handler(Looper.getMainLooper())
        if (!pm.isInteractive) {
            try {
                @Suppress("DEPRECATION")
                val wl = pm.newWakeLock(
                    PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                    "abtin:wake"
                )
                wl.acquire(4000L)
            } catch (_: Exception) { }
            main.postDelayed({
                if (!pm.isInteractive) thread { InjectorClient.systemKey(4) }
            }, 700L)
            return
        }
        thread {
            if (!InjectorClient.systemKey(2)) {
                main.post {
                    if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                    else performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
                }
            }
        }
    }

    private fun startVoice() {
        val tries = listOf(
            Intent(Intent.ACTION_VOICE_COMMAND),
            Intent(Intent.ACTION_ASSIST),
            Intent("android.speech.action.WEB_SEARCH")
        )
        for (i in tries) {
            try {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(i)
                return
            } catch (_: Exception) { }
        }
    }

    // ---------- کلیدها ----------
    private fun mediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun volume(direction: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }

    fun key(name: String) {
        when (name.uppercase()) {
            "BACK", "ESC" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "HOME" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "RECENTS" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "NOTIFICATIONS" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "QUICK_SETTINGS" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "POWER" -> togglePower()
            "POWER_MENU" -> performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
            "ENTER" -> enterKey()
            "BACKSPACE" -> backspace()
            "DELETE" -> deleteForward()
            "SPACE" -> {
                val n = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                if (n != null && n.isEditable) typeText(" ") else enterKey()
            }
            "TAB" -> moveFocus(View.FOCUS_FORWARD)
            "UP" -> arrow(View.FOCUS_UP)
            "DOWN" -> arrow(View.FOCUS_DOWN)
            "LEFT" -> arrow(View.FOCUS_LEFT)
            "RIGHT" -> arrow(View.FOCUS_RIGHT)
            "LINE_START" -> caretTo(false)
            "LINE_END" -> caretTo(true)
            "PAGEUP", "CH_UP" -> scrollBy(0f, -5f)
            "PAGEDOWN", "CH_DOWN" -> scrollBy(0f, 5f)
            "0", "1", "2", "3", "4", "5", "6", "7", "8", "9" -> {
                val n = inputNode()
                if (n != null) typeText(name)
            }
            "MIC" -> startVoice()
            "VOL_UP" -> volume(AudioManager.ADJUST_RAISE)
            "VOL_DOWN" -> volume(AudioManager.ADJUST_LOWER)
            "MUTE" -> volume(AudioManager.ADJUST_TOGGLE_MUTE)
            "PLAY_PAUSE" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            "NEXT" -> mediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
            "PREV" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            "COPY" -> editAction(AccessibilityNodeInfo.ACTION_COPY)
            "PASTE" -> editAction(AccessibilityNodeInfo.ACTION_PASTE)
            "CUT" -> editAction(AccessibilityNodeInfo.ACTION_CUT)
            "SELECT_ALL" -> selectAll()
        }
    }


    // ---------- دسته بازی روی Wi-Fi (کنترل رابط) ----------
    private var lx = 0f
    private var ly = 0f
    private var rx = 0f
    private var ry = 0f
    private var stickLoop = false
    private var scrollTick = 0
    private val stickRunner = object : Runnable {
        override fun run() {
            val moving = lx != 0f || ly != 0f
            val scrolling = rx != 0f || ry != 0f
            if (!moving && !scrolling) { stickLoop = false; return }
            if (moving) movePointer(lx * 14f, ly * 14f)
            scrollTick++
            if (scrolling && scrollTick % 10 == 0) scrollBy(rx * 1.5f, ry * 1.5f)
            ui.postDelayed(this, 16L)
        }
    }

    /** side: "left" یا "right"، مقدارها بین -1 و 1 */
    fun stick(side: String, x: Float, y: Float) {
        val dead = 0.12f
        val nx = if (kotlin.math.abs(x) < dead) 0f else x
        val ny = if (kotlin.math.abs(y) < dead) 0f else y
        if (side == "left") { lx = nx; ly = ny } else { rx = nx; ry = ny }
        if (!stickLoop && (nx != 0f || ny != 0f)) {
            stickLoop = true
            ui.post(stickRunner)
        }
    }

    fun padButton(name: String, down: Boolean) {
        when (name.uppercase()) {
            "CROSS" -> mouseButton("left", down)
            "SQUARE" -> if (down) mouseButton("right", false)
            "CIRCLE" -> if (down) key("BACK")
            "TRIANGLE" -> if (down) key("HOME")
            "UP" -> if (down) key("UP")
            "DOWN" -> if (down) key("DOWN")
            "LEFT" -> if (down) key("LEFT")
            "RIGHT" -> if (down) key("RIGHT")
            "L1" -> if (down) key("VOL_DOWN")
            "R1" -> if (down) key("VOL_UP")
            "L2" -> if (down) key("PAGEUP")
            "R2" -> if (down) key("PAGEDOWN")
            "SELECT" -> if (down) key("RECENTS")
            "START" -> if (down) key("PLAY_PAUSE")
            "MODE" -> if (down) key("HOME")
        }
    }

    fun hideCursor() = removeCursor()
}
