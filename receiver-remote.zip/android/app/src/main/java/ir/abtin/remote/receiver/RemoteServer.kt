package ir.abtin.remote.receiver

import android.content.Context
import android.os.Build
import android.util.Log
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.concurrent.thread
import kotlin.random.Random

/**
 * سرور TCP (پورت 39877) برای دریافت دستورها + پاسخ‌دهی UDP (پورت 39878) برای پیدا کردن خودکار باکس.
 * هر خط یک بسته‌ی JSON است. قبل از هر دستور باید بسته‌ی hello با PIN درست ارسال شود.
 */
object RemoteServer {
    const val PORT = 39877
    const val DISCOVERY_PORT = 39878
    private const val TAG = "AbtinRemote"

    @Volatile private var server: ServerSocket? = null
    @Volatile private var udp: DatagramSocket? = null
    private val clients = Executors.newCachedThreadPool()

    fun isRunning(): Boolean = server?.isClosed == false

    fun pin(context: Context): String {
        val sp = context.applicationContext.getSharedPreferences("abtin_remote", Context.MODE_PRIVATE)
        var p = sp.getString("pin", null)
        if (p == null || p.length != 4) {
            p = Random.nextInt(1000, 10000).toString()
            sp.edit().putString("pin", p).apply()
        }
        return p
    }

    fun regeneratePin(context: Context): String {
        val sp = context.applicationContext.getSharedPreferences("abtin_remote", Context.MODE_PRIVATE)
        sp.edit().remove("pin").apply()
        return pin(context)
    }

    @Synchronized
    fun start(context: Context) {
        val app = context.applicationContext
        if (server?.isClosed == false) return
        try {
            val s = ServerSocket()
            s.reuseAddress = true
            s.bind(InetSocketAddress(PORT))
            server = s
        } catch (e: Exception) {
            Log.e(TAG, "cannot bind tcp", e)
            return
        }
        thread(name = "AbtinRemoteServer", isDaemon = true) {
            val s = server
            try {
                while (s != null && !s.isClosed) {
                    val client = s.accept()
                    clients.execute { handle(app, client) }
                }
            } catch (e: Exception) {
                if (s?.isClosed != true) Log.e(TAG, "server", e)
            }
        }
        startDiscovery()
    }

    @Synchronized
    fun stop() {
        try { server?.close() } catch (_: Exception) {}
        try { udp?.close() } catch (_: Exception) {}
        server = null
        udp = null
        RemoteAccessibilityService.post { hideCursor() }
    }

    private fun startDiscovery() {
        thread(name = "AbtinRemoteDiscovery", isDaemon = true) {
            try {
                val sock = DatagramSocket(null)
                sock.reuseAddress = true
                sock.broadcast = true
                sock.bind(InetSocketAddress(DISCOVERY_PORT))
                udp = sock
                val buf = ByteArray(256)
                while (!sock.isClosed) {
                    val p = DatagramPacket(buf, buf.size)
                    sock.receive(p)
                    val msg = String(p.data, 0, p.length)
                    if (msg.startsWith("ABTIN_DISCOVER")) {
                        val name = (Build.MODEL ?: "Android Box").replace(';', ' ')
                        val reply = "ABTIN_RECEIVER;$name;$PORT".toByteArray()
                        sock.send(DatagramPacket(reply, reply.size, p.address, p.port))
                    }
                }
            } catch (e: Exception) {
                if (udp?.isClosed != true) Log.w(TAG, "discovery stopped", e)
            }
        }
    }

    private fun reply(socket: Socket, json: JSONObject) {
        synchronized(socket) {
            try {
                val out = socket.getOutputStream()
                out.write((json.toString() + "\n").toByteArray())
                out.flush()
            } catch (_: Exception) {}
        }
    }

    private fun handle(context: Context, socket: Socket) {
        socket.use { s ->
            try {
                s.soTimeout = 45_000
                s.tcpNoDelay = true
                val input = s.getInputStream().bufferedReader()
                val expected = pin(context)
                var authed = false
                while (true) {
                    val line = input.readLine() ?: break
                    if (line.length > 16_384) continue
                    val j = try { JSONObject(line) } catch (e: Exception) { continue }
                    val type = j.optString("type")
                    if (type == "hello") {
                        if (j.optString("pin") == expected) {
                            authed = true
                            reply(s, JSONObject()
                                .put("type", "hello").put("ok", true)
                                .put("name", Build.MODEL ?: "Android Box")
                                .put("accessibility", RemoteAccessibilityService.instance != null))
                        } else {
                            reply(s, JSONObject().put("type", "hello").put("ok", false).put("reason", "pin"))
                            break
                        }
                        continue
                    }
                    if (!authed) continue
                    try { dispatch(j) } catch (e: Exception) { Log.w(TAG, "bad packet", e) }
                }
            } catch (e: Exception) {
                Log.i(TAG, "client disconnected")
            }
        }
    }

    private fun num(j: JSONObject, key: String): Float {
        val v = j.optDouble(key, 0.0)
        return if (v.isNaN() || v.isInfinite()) 0f else v.toFloat()
    }

    private fun dispatch(j: JSONObject) {
        when (j.optString("type")) {
            "ping" -> {}
            "move", "pointer" -> { val dx = num(j, "dx"); val dy = num(j, "dy"); if (!InjectorClient.move(dx, dy)) RemoteAccessibilityService.post { movePointer(dx, dy) } }
            "mouse" -> { val b = j.optString("button", "left"); val d = j.optBoolean("down", true); if (!InjectorClient.button(b, d)) RemoteAccessibilityService.post { mouseButton(b, d) } }
            "click" -> { val b = j.optString("button", "left"); if (!InjectorClient.click(b)) RemoteAccessibilityService.post { click(b) } }
            "scroll" -> { val dx = num(j, "dx"); val dy = num(j, "dy"); if (!InjectorClient.scroll(dx, dy)) RemoteAccessibilityService.post { scrollBy(dx, dy) } }
            "text" -> { val t = j.optString("text").take(1000); RemoteAccessibilityService.post { typeText(t) } }
            "stick" -> { val side = j.optString("side", "left"); val x = num(j, "x"); val y = num(j, "y"); RemoteAccessibilityService.post { stick(side, x, y) } }
            "pad" -> { val b = j.optString("button"); val d = j.optBoolean("down", true); RemoteAccessibilityService.post { padButton(b, d) } }
            "key" -> { val k = j.optString("key"); if (!InjectorClient.key(k)) RemoteAccessibilityService.post { key(k) } }
        }
    }
}
