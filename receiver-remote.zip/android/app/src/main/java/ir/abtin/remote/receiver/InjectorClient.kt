package ir.abtin.remote.receiver

import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs

/** ارتباط اپ با Injector (که با دسترسی shell اجرا شده). اگر در دسترس نباشد، همه‌ی توابع false برمی‌گردانند و کد قبلی (Accessibility) جایگزین می‌شود. */
object InjectorClient {
    private const val MOUSE_SCALE = 1.0f

    private var sock: Socket? = null
    private var out: OutputStream? = null
    private var lastFail = 0L
    private var mask = 0
    private var remX = 0f
    private var remY = 0f

    @Synchronized
    private fun ensure(): Boolean {
        if (sock?.isClosed == false && out != null) return true
        val now = System.currentTimeMillis()
        if (now - lastFail < 2000L) return false
        return try {
            val s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress("127.0.0.1", Injector.PORT), 300)
            sock = s
            out = s.getOutputStream()
            true
        } catch (_: Exception) {
            lastFail = now
            sock = null; out = null
            false
        }
    }

    @Synchronized
    private fun write(s: String): Boolean {
        if (!ensure()) return false
        return try {
            out!!.write((s + "\n").toByteArray())
            out!!.flush()
            true
        } catch (_: Exception) {
            try { sock?.close() } catch (_: Exception) {}
            sock = null; out = null
            lastFail = System.currentTimeMillis()
            false
        }
    }

    fun available(): Boolean = write("ping")

    @Synchronized
    fun move(dx: Float, dy: Float): Boolean {
        if (!ensure()) return false
        remX += dx * MOUSE_SCALE
        remY += dy * MOUSE_SCALE
        var ok = true
        while (ok && (abs(remX) >= 1f || abs(remY) >= 1f)) {
            val ix = remX.toInt().coerceIn(-127, 127)
            val iy = remY.toInt().coerceIn(-127, 127)
            remX -= ix; remY -= iy
            ok = write("m $ix $iy")
        }
        return ok
    }

    private fun bit(name: String) = when (name) { "left" -> 1; "right" -> 2; "middle" -> 4; else -> 1 }

    @Synchronized
    fun button(name: String, down: Boolean): Boolean {
        val bit = bit(name)
        mask = if (down) mask or bit else mask and bit.inv()
        return write("b $mask")
    }

    @Synchronized
    fun click(name: String): Boolean = button(name, true) && button(name, false)

    /** dy مثبت = اسکرول به پایین؛ در HID چرخ مثبت یعنی بالا، پس علامت برعکس می‌شود. */
    fun scroll(dx: Float, dy: Float): Boolean {
        if (!ensure()) return false
        var v = (-dy).toInt()
        if (v == 0 && dy != 0f) v = if (dy > 0) -1 else 1
        return if (v != 0) write("w $v") else true
    }

    // مدیفایر: ۱ = Ctrl
    fun key(name: String): Boolean {
        val k = when (name.uppercase()) {
            "ENTER" -> "k 40"
            "SPACE" -> "k 44"
            "BACKSPACE" -> "k 42"
            "DELETE" -> "k 76"
            "TAB" -> "k 43"
            "UP" -> "k 82"
            "DOWN" -> "k 81"
            "LEFT" -> "k 80"
            "RIGHT" -> "k 79"
            "PAGEUP" -> "k 75"
            "PAGEDOWN" -> "k 78"
            "LINE_START" -> "k 74"
            "LINE_END" -> "k 77"
            "SELECT_ALL" -> "k 4 1"
            "COPY" -> "k 6 1"
            "PASTE" -> "k 25 1"
            "CUT" -> "k 27 1"
            "BACK", "ESC" -> "c 548"
            "HOME" -> "c 547"
            "VOL_UP" -> "c 233"
            "VOL_DOWN" -> "c 234"
            "MUTE" -> "c 226"
            "PLAY_PAUSE" -> "c 205"
            "NEXT" -> "c 181"
            "PREV" -> "c 182"
            "0" -> "k 39"
            "1" -> "k 30"
            "2" -> "k 31"
            "3" -> "k 32"
            "4" -> "k 33"
            "5" -> "k 34"
            "6" -> "k 35"
            "7" -> "k 36"
            "8" -> "k 37"
            "9" -> "k 38"
            "CH_UP" -> "c 156"
            "CH_DOWN" -> "c 157"
            "RED" -> "c 105"
            "GREEN" -> "c 106"
            "BLUE" -> "c 107"
            "YELLOW" -> "c 108"
            "INFO" -> "c 445"
            "EPG" -> "c 141"
            "TEXT" -> "c 97"
            "MIC" -> "c 545"
            else -> return false
        }
        return write(k)
    }
}
