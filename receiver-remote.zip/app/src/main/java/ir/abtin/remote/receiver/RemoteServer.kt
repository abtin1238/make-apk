package ir.abtin.remote.receiver

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import kotlin.concurrent.thread

object RemoteServer {
    const val PORT = 39877
    @Volatile private var server: ServerSocket? = null
    private val clients = Executors.newCachedThreadPool()
    @Synchronized fun start(context: Context) {
        if (server?.isClosed == false) return
        thread(name="AbtinRemoteServer", isDaemon=true) {
            try {
                ServerSocket(PORT).also { server = it }
                while (server?.isClosed == false) {
                    val client = server!!.accept()
                    clients.execute { handle(client) }
                }
            } catch (e: Exception) { if (server?.isClosed != true) Log.e("AbtinRemote", "server", e) }
            finally { server = null }
        }
    }
    private fun handle(socket: Socket) {
        socket.use { s ->
            try {
                s.soTimeout = 30_000
                val input = s.getInputStream().bufferedReader()
                while (true) {
                    val line = input.readLine() ?: break
                    if (line.length > 16_384) continue
                    try { dispatch(JSONObject(line)) } catch (e: Exception) { Log.w("AbtinRemote", "bad packet", e) }
                }
            } catch (e: Exception) { Log.i("AbtinRemote", "client disconnected") }
        }
    }
    private fun dispatch(j: JSONObject) {
        val svc = RemoteAccessibilityService.instance
        when (j.optString("type")) {
            "pointer" -> svc?.move(j.optDouble("dx").toFloat(), j.optDouble("dy").toFloat())
            "click" -> svc?.click(j.optString("button") == "right")
            "scroll" -> svc?.scroll(j.optDouble("dy").toFloat())
            "text" -> svc?.text(j.optString("text").take(1000))
            "key" -> {
                val key=j.optString("key").uppercase()
                when(key) {
                    "BACK" -> svc?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK)
                    "HOME" -> svc?.performGlobalAction(android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME)
                    "ENTER" -> svc?.activateFocused()
                    "UP" -> svc?.moveFocus(android.view.accessibility.AccessibilityNodeInfo.ACTION_FOCUS)
                    "DOWN" -> svc?.moveFocus(android.view.accessibility.AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS)
                }
            }
        }
    }
}
