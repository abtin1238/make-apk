package ir.abtin.remote.receiver

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.net.NetworkInterface

class MainActivity:Activity(){
 private lateinit var info:TextView
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(32,40,32,32)}
  info=TextView(this).apply{textSize=17}
  box.addView(info)
  box.addView(Button(this).apply{text="فعال‌سازی سرویس کنترل";setOnClickListener{startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))}})
  box.addView(Button(this).apply{text="شروع سرور شبکه";setOnClickListener{startServer();refresh();this.text="سرور فعال است"}})
  setContentView(box);startServer();refresh()
 }
 private fun startServer(){startService(Intent(this,ServerService::class.java))}
 private fun refresh(){info.text="Abtin Remote Receiver

گوشی و باکس باید روی یک شبکه باشند.
آدرس IP باکس: ${localIp()}
پورت: 39877

برای لمس، متن و ناوبری، سرویس دسترس‌پذیری را فعال کنید.
برای دسته بازی، در گوشی Bluetooth HID را فعال و از تنظیمات باکس Pair کنید."}
 private fun localIp():String = try { NetworkInterface.getNetworkInterfaces().toList().flatMap{it.inetAddresses.toList()}.firstOrNull{!it.isLoopbackAddress && it.hostAddress?.contains(':')==false}?.hostAddress ?: "IP نامشخص" } catch(_:Exception){"IP نامشخص"}
}
