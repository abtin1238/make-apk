package ir.abtin.remote.receiver

import android.app.Service
import android.content.Intent
import android.os.IBinder

class ServerService : Service() {
    override fun onCreate() { super.onCreate(); RemoteServer.start(applicationContext) }
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int { RemoteServer.start(applicationContext); return START_STICKY }
    override fun onBind(intent:Intent?):IBinder?=null
}
