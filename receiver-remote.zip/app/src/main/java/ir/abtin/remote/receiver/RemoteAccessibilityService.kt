package ir.abtin.remote.receiver

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RemoteAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: RemoteAccessibilityService? = null }
    override fun onServiceConnected() { instance=this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance=null; super.onDestroy() }
    private fun center(): Pair<Float,Float> {
        val m=resources.displayMetrics
        return m.widthPixels/2f to m.heightPixels/2f
    }
    fun move(dx:Float,dy:Float) {
        val (x,y)=center(); val path=Path().apply { moveTo(x,y); lineTo((x+dx*2).coerceIn(0f,resources.displayMetrics.widthPixels.toFloat()),(y+dy*2).coerceIn(0f,resources.displayMetrics.heightPixels.toFloat())) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,120)).build(),null,null)
    }
    fun click(right:Boolean=false) {
        val (x,y)=center(); val path=Path().apply { moveTo(x,y); lineTo(x+1,y+1) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,if(right)700 else 80)).build(),null,null)
    }
    fun scroll(amount:Float) {
        val (x,y)=center(); val path=Path().apply { moveTo(x,y); lineTo(x,y-amount.coerceIn(-8f,8f)*45f) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,250)).build(),null,null)
    }
    fun activateFocused() { rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: click() }
    fun moveFocus(action:Int) { rootInActiveWindow?.performAction(action) }
    fun text(value:String) {
        val root=rootInActiveWindow ?: return
        val node=findEditable(root) ?: return
        val args=Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,value) }
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,args)
    }
    private fun findEditable(node:AccessibilityNodeInfo):AccessibilityNodeInfo? {
        if(node.isEditable) return node
        for(i in 0 until node.childCount) { val found=node.getChild(i)?.let(::findEditable); if(found!=null)return found }
        return null
    }
}
