# Abtin Remote Receiver (Android Box)
1. اپ را نصب و باز کنید (سرور خودکار شروع می‌شود، IP و PIN روی صفحه است).
2. «فعال‌سازی سرویس دسترس‌پذیری» را بزنید و Abtin Remote Receiver را روشن کنید (ضروری).
3. در اپ گوشی جستجوی خودکار یا IP + PIN را وارد کنید.
بیلد: JDK 17 و `./gradlew assembleRelease` (خروجی: app/build/outputs/apk/release)
