# Abtin Remote Receiver (Android Box)
1. اپ را نصب و باز کنید (سرور خودکار شروع می‌شود، IP و PIN روی صفحه است).
2. «فعال‌سازی سرویس دسترس‌پذیری» را بزنید و Abtin Remote Receiver را روشن کنید (ضروری).
3. در اپ گوشی جستجوی خودکار یا IP + PIN را وارد کنید.
بیلد: JDK 17 و `./gradlew assembleRelease` (خروجی: app/build/outputs/apk/release)

## اگر سوییچ سرویس دسترس‌پذیری روشن نمی‌شود
در Android 13+ برای برنامه‌های نصب‌شده بیرون از فروشگاه، تنظیمات محدود (Restricted settings) سوییچ را غیرفعال می‌کند:
- Settings ← Apps ← Abtin Remote Receiver ← منوی ⋮ ← Allow restricted settings، سپس سرویس را روشن کنید.
- یا با adb:
  `adb shell pm grant ir.abtin.remote.receiver android.permission.WRITE_SECURE_SETTINGS`
  `adb shell appops set ir.abtin.remote.receiver ACCESS_RESTRICTED_SETTINGS allow`
  و برنامه را دوباره باز کنید (خودش سرویس را روشن می‌کند).
