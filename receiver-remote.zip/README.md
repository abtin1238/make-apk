# Abtin Remote Receiver (Android Box)
1. اپ را نصب و باز کنید (سرور خودکار شروع می‌شود، IP و PIN روی صفحه است).
2. «فعال‌سازی سرویس دسترس‌پذیری» را بزنید و Abtin Remote Receiver را روشن کنید (ضروری).
3. در اپ گوشی جستجوی خودکار یا IP + PIN را وارد کنید.
بیلد: JDK 17 و `./gradlew assembleRelease` (خروجی: app/build/outputs/apk/release)

## اگر سوییچ سرویس دسترس‌پذیری روشن نمی‌شود
در Android 13+ برای برنامه‌های نصب‌شده بیرون از فروشگاه، تنظیمات محدود (Restricted settings) سوییچ را غیرفعال می‌کند:
- Settings ← Apps ← Abtin Remote Receiver ← منوی ⋮ ← Allow restricted settings، سپس سرویس را روشن کنید.
- یا با adb:
  `adb shell pm grant ir.abtin.remote.receiver android.permission.WRITE_SECURE_SETTINGS`
  `adb shell appops set ir.abtin.remote.receiver ACCESS_RESTRICTED_SETTINGS allow`
  و برنامه را دوباره باز کنید (خودش سرویس را روشن می‌کند).

## نشانگر و کلیک واقعیِ خود اندروید (Injector) — از نسخه ۲.۵.۰
سرویس Accessibility روی بعضی باکس‌ها کلیک (dispatchGesture) و Enter را اجرا نمی‌کند و فقط یک نشانگر جداگانه می‌کشد.
Injector با دسترسی shell سه دستگاه HID مجازی (موس، کیبورد، کلیدهای رسانه) از طریق /dev/uhid می‌سازد، پس اندروید نشانگر خودش را نشان می‌دهد و کلیک/Enter/جهت‌ها واقعی‌اند.
بعد از هر ری‌استارت باکس یک بار از adb اجرا کنید:
`adb shell 'CLASSPATH=$(pm path ir.abtin.remote.receiver | cut -d: -f2) nohup app_process /system/bin ir.abtin.remote.receiver.Injector >/data/local/tmp/abtin.log 2>&1 &'`
اگر کار نکرد، لاگ: `adb shell cat /data/local/tmp/abtin.log`
تا وقتی Injector اجرا نباشد، برنامه به روش قبلی (Accessibility) برمی‌گردد. متن (تایپ فارسی) همچنان از Accessibility می‌آید.

## نسخه ۲.۵.۱ — کلیک و اسکرول بدون gesture
اگر باکس dispatchGesture را اجرا نمی‌کند، کلیک (چپ/راست/نگه‌داشتن)، Enter و اسکرول حالا اول با پیدا کردن عنصر زیر نشانگر و اجرای ACTION_CLICK / ACTION_SCROLL انجام می‌شود و فقط در صورت شکست به gesture برمی‌گردد. این روش adb نمی‌خواهد؛ در WebView و بازی‌ها ممکن است عنصر قابل‌کلیک پیدا نشود.

## نسخه ۲.۶.۰ — ریموت کامل
- ظاهر صفحه‌ی ریموت اپ گوشی مطابق طراحی Abtin (دکمه‌های قرصی، نور نئونی، لوگو).
- همه‌ی دکمه‌ها فرمان دارند: اعداد ۰–۹، کانال (CH)، رنگی‌ها، INFO، TEXT (زیرنویس)، EPG (راهنمای برنامه) و میکروفون (جستجوی صوتی).
- OK و جهت‌ها در Android 13+ با GLOBAL_ACTION_DPAD_* کلید واقعی‌اند و نیاز به Injector ندارند.
- اعداد، کانال، رنگی‌ها، INFO، TEXT و EPG کلید واقعی لازم دارند، پس Injector (بخش بالا) را اجرا کنید. بدون Injector فقط اعداد داخل فیلد متن تایپ می‌شوند.

## نسخه ۲.۶.۱ — روشن/خاموش با ریموت
- ضربه‌ی کوتاه روی Power: اگر صفحه روشن است خاموش می‌شود (با Injector کلید واقعی Sleep، وگرنه قفل صفحه)؛ اگر خاموش است روشن می‌شود.
- نگه‌داشتن Power (حدود ۰٫۶ ثانیه): منوی خاموش/ری‌استارت خود اندروید (POWER_MENU).
- سرور با WakeLock و WifiLock کار می‌کند تا بعد از خاموش شدن صفحه هم در دسترس باشد. اگر باکس به Deep Sleep برود و Wi-Fi را قطع کند، با Wi-Fi نمی‌شود روشنش کرد.
