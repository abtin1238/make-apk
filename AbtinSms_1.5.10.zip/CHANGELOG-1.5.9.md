# Abtin SMS 1.5.9

- Lock screen: incoming-call notification now uses the real system CallStyle whenever the phone is locked (Auto mode), so Answer/Decline always show on the lock screen. Themed card stays for the unlocked heads-up. New setting: Call appearance > Call notification card > notification type (Auto / Always system / Themed card).
- Missed-call notification is public on the lock screen (plain style with a Call back action when locked).
- Ring/ongoing channels re-created (new ids) so old channel settings no longer hide notifications.
- Original theme restored ("اصلی" / Original): app palette backdrop, halo avatar, swipe answer/decline. It is the default again; the 6 themes of 1.5.8 remain.
- Call background images: 6 built-in images (Aurora, Sunset, Ocean, Forest, City, Waves) + pick any photo from the gallery (copied into app storage, rotation fixed), with an image-dimming slider. Applies to incoming, in-call, ended and missed-call screens.
- Incoming call while locked / screen off: the screen is now woken (wake lock) and the call screen opens directly over the lock screen, in addition to the full-screen notification, so it no longer depends on that notification alone.
- New access checklist in Call notifications settings (notifications, full-screen notifications, display over other apps, unrestricted battery) with status and one-tap shortcuts. The phone screen also asks once for "Display over other apps".
- First-run guided setup (like an install prompt): when Abtin is the default phone app, a dialog lists the accesses the call screen needs (notifications, full-screen notifications, display over other apps, unrestricted battery, and on Xiaomi the Other-permissions page) and opens each system page in turn after tapping Allow. It can be reopened from Call notifications settings > Guided access setup. Android does not allow apps to grant these silently.
