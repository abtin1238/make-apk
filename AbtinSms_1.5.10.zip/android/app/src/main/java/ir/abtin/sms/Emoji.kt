package ir.abtin.sms

import android.graphics.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import java.io.ByteArrayOutputStream
import kotlin.math.cos
import kotlin.math.sin

/** Abtin neon-glass emoji set, drawn in code and sent as PNG (MMS). */
object AbtinEmoji {
    class E(val id: String, val c1: Int, val c2: Int, val glow: Int, val shape: Boolean = false)

    private const val S = 256
    private val INK = 0xFF101733.toInt()
    val all = listOf(
        E("smile", 0xFFFFE27A.toInt(), 0xFFFF9F43.toInt(), 0xFFFFC145.toInt()),
        E("laugh", 0xFFFFE27A.toInt(), 0xFFFF9F43.toInt(), 0xFFFFC145.toInt()),
        E("wink", 0xFFFFE27A.toInt(), 0xFFFF9F43.toInt(), 0xFFFFC145.toInt()),
        E("love", 0xFFFFB3D1.toInt(), 0xFFFF4F9A.toInt(), 0xFFFF4F9A.toInt()),
        E("cool", 0xFF8EE9FF.toInt(), 0xFF2E7BFF.toInt(), 0xFF3DD6FF.toInt()),
        E("wow", 0xFFD6B8FF.toInt(), 0xFF7A4DFF.toInt(), 0xFF9B7BFF.toInt()),
        E("sad", 0xFFB9D4FF.toInt(), 0xFF4F78D6.toInt(), 0xFF5C8DFF.toInt()),
        E("cry", 0xFFB9D4FF.toInt(), 0xFF4F78D6.toInt(), 0xFF5C8DFF.toInt()),
        E("angry", 0xFFFF9A8A.toInt(), 0xFFD6203A.toInt(), 0xFFFF3B52.toInt()),
        E("sleepy", 0xFFC9C2FF.toInt(), 0xFF5B52C9.toInt(), 0xFF7F76FF.toInt()),
        E("heart", 0xFFFF8FB8.toInt(), 0xFFE0145B.toInt(), 0xFFFF2E7E.toInt(), true),
        E("star", 0xFFFFF29A.toInt(), 0xFFFFA800.toInt(), 0xFFFFD43B.toInt(), true),
        E("fire", 0xFFFFD05A.toInt(), 0xFFFF3D1F.toInt(), 0xFFFF7A1A.toInt(), true),
        E("bolt", 0xFFFFFA9E.toInt(), 0xFF35D0FF.toInt(), 0xFF3DD6FF.toInt(), true),
    )

    private val cache = HashMap<String, Bitmap>()
    fun bitmap(e: E): Bitmap = cache.getOrPut(e.id) { render(e) }
    fun attach(e: E) = Attach(ByteArrayOutputStream().also { bitmap(e).compress(Bitmap.CompressFormat.PNG, 100, it) }.toByteArray(), "image/png", "abtin_${e.id}.png")

    private fun fill(c: Int = INK) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c; style = Paint.Style.FILL }
    private fun line(w: Float = 10f, c: Int = INK) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c; style = Paint.Style.STROKE; strokeWidth = w; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private fun grad(e: E, top: Float = 0f, bot: Float = S.toFloat()) = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = LinearGradient(0f, top, 0f, bot, e.c1, e.c2, Shader.TileMode.CLAMP) }

    private fun glow(c: Canvas, p: Path, e: E) {
        c.drawPath(p, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = e.glow; alpha = 140; style = Paint.Style.STROKE; strokeWidth = 12f; maskFilter = BlurMaskFilter(16f, BlurMaskFilter.Blur.NORMAL) })
        c.drawPath(p, grad(e))
        c.drawPath(p, line(4f, 0x80FFFFFF.toInt()))
    }

    private fun gloss(c: Canvas, r: RectF) {
        c.drawOval(r, Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = LinearGradient(0f, r.top, 0f, r.bottom, 0xA0FFFFFF.toInt(), 0x00FFFFFF, Shader.TileMode.CLAMP) })
    }

    private fun heart(cx: Float, cy: Float, s: Float) = Path().apply {
        moveTo(cx, cy + s * .9f)
        cubicTo(cx - s * 1.4f, cy, cx - s * .9f, cy - s, cx, cy - s * .4f)
        cubicTo(cx + s * .9f, cy - s, cx + s * 1.4f, cy, cx, cy + s * .9f); close()
    }

    private fun starPath() = Path().apply {
        for (i in 0 until 10) {
            val r = if (i % 2 == 0) 112f else 50f
            val a = Math.toRadians(-90.0 + i * 36)
            val x = 128f + r * cos(a).toFloat(); val y = 134f + r * sin(a).toFloat()
            if (i == 0) moveTo(x, y) else lineTo(x, y)
        }
        close()
    }

    private fun firePath() = Path().apply {
        moveTo(128f, 20f); cubicTo(150f, 70f, 208f, 100f, 200f, 170f); cubicTo(194f, 224f, 162f, 242f, 128f, 242f)
        cubicTo(94f, 242f, 58f, 224f, 56f, 172f); cubicTo(54f, 140f, 78f, 120f, 92f, 92f)
        cubicTo(100f, 114f, 108f, 120f, 114f, 118f); cubicTo(104f, 84f, 112f, 50f, 128f, 20f); close()
    }

    private fun boltPath() = Path().apply {
        moveTo(152f, 12f); lineTo(70f, 142f); lineTo(122f, 142f); lineTo(102f, 244f)
        lineTo(190f, 106f); lineTo(138f, 106f); lineTo(174f, 12f); close()
    }

    private fun render(e: E): Bitmap {
        val bmp = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (e.shape) {
            when (e.id) {
                "heart" -> { val p = heart(128f, 112f, 100f); glow(c, p, e); gloss(c, RectF(52f, 40f, 140f, 100f)) }
                "star" -> { val p = starPath(); glow(c, p, e); gloss(c, RectF(80f, 50f, 170f, 110f)) }
                "fire" -> {
                    val p = firePath(); glow(c, p, e)
                    c.save(); c.scale(.55f, .55f, 128f, 240f); c.drawPath(firePath(), Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = LinearGradient(0f, 20f, 0f, 242f, 0xFFFFFFC0.toInt(), 0xFFFFC145.toInt(), Shader.TileMode.CLAMP) }); c.restore()
                }
                else -> { val p = boltPath(); glow(c, p, e); gloss(c, RectF(78f, 20f, 150f, 80f)) }
            }
            return bmp
        }
        val orb = Path().apply { addCircle(128f, 128f, 108f, Path.Direction.CW) }
        c.drawPath(orb, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = e.glow; alpha = 150; style = Paint.Style.STROKE; strokeWidth = 14f; maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL) })
        c.drawPath(orb, Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = RadialGradient(100f, 88f, 160f, e.c1, e.c2, Shader.TileMode.CLAMP) })
        c.drawPath(orb, line(4f, 0x90FFFFFF.toInt()))
        gloss(c, RectF(62f, 22f, 194f, 100f))
        val eye = { x: Float, y: Float, r: Float -> c.drawCircle(x, y, r, fill()) ; c.drawCircle(x - r * .3f, y - r * .35f, r * .3f, fill(0xFFFFFFFF.toInt())) }
        val smile = Path().apply { moveTo(80f, 150f); quadTo(128f, 208f, 176f, 150f) }
        val frown = Path().apply { moveTo(88f, 190f); quadTo(128f, 150f, 168f, 190f) }
        val happyEye = { x: Float -> c.drawPath(Path().apply { moveTo(x - 16f, 120f); quadTo(x, 92f, x + 16f, 120f) }, line(9f)) }
        when (e.id) {
            "smile" -> { eye(92f, 108f, 14f); eye(164f, 108f, 14f); c.drawPath(smile, line()) }
            "laugh" -> {
                happyEye(92f); happyEye(164f)
                val m = Path().apply { moveTo(72f, 144f); lineTo(184f, 144f); quadTo(128f, 238f, 72f, 144f); close() }
                c.drawPath(m, fill())
                c.save(); c.clipPath(m); c.drawOval(RectF(98f, 186f, 158f, 232f), fill(0xFFFF6B8A.toInt())); c.restore()
            }
            "wink" -> { eye(92f, 108f, 14f); c.drawPath(Path().apply { moveTo(146f, 110f); lineTo(182f, 104f) }, line(9f)); c.drawPath(smile, line()) }
            "love" -> {
                for (x in floatArrayOf(92f, 164f)) c.drawPath(heart(x, 108f, 22f), fill(0xFFFF1F6B.toInt()))
                c.drawPath(smile, line())
            }
            "cool" -> {
                val g = fill(); c.drawRoundRect(RectF(58f, 92f, 120f, 134f), 14f, 14f, g); c.drawRoundRect(RectF(136f, 92f, 198f, 134f), 14f, 14f, g)
                c.drawLine(120f, 104f, 136f, 104f, line(8f)); c.drawLine(66f, 100f, 90f, 100f, line(5f, 0x70FFFFFF.toInt()))
                c.drawPath(Path().apply { moveTo(88f, 160f); quadTo(128f, 196f, 168f, 160f) }, line())
            }
            "wow" -> { eye(92f, 106f, 17f); eye(164f, 106f, 17f); c.drawOval(RectF(106f, 148f, 150f, 206f), fill()) }
            "sad" -> {
                eye(92f, 118f, 13f); eye(164f, 118f, 13f); c.drawPath(frown, line())
                c.drawLine(70f, 84f, 108f, 96f, line(7f)); c.drawLine(186f, 84f, 148f, 96f, line(7f))
            }
            "cry" -> {
                eye(92f, 116f, 13f); eye(164f, 116f, 13f); c.drawPath(frown, line())
                for (x in floatArrayOf(86f, 170f)) c.drawPath(Path().apply { moveTo(x, 140f); quadTo(x - 16f, 170f, x, 184f); quadTo(x + 16f, 170f, x, 140f) }, fill(0xFF59D2FF.toInt()))
            }
            "angry" -> {
                eye(92f, 118f, 12f); eye(164f, 118f, 12f); c.drawPath(frown, line())
                c.drawLine(66f, 84f, 110f, 102f, line(10f)); c.drawLine(190f, 84f, 146f, 102f, line(10f))
            }
            else -> {
                c.drawLine(76f, 116f, 108f, 116f, line(9f)); c.drawLine(148f, 116f, 180f, 116f, line(9f))
                c.drawCircle(128f, 170f, 14f, fill())
                val t = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = INK; textSize = 44f; typeface = Typeface.DEFAULT_BOLD }
                c.drawText("z", 178f, 80f, t); t.textSize = 30f; c.drawText("z", 206f, 52f, t)
            }
        }
        return bmp
    }
}

@Composable
fun AbtinEmojiDialog(surface: Color, text: Color, primary: Color, title: String, close: String, onPick: (Attach) -> Unit, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose, containerColor = surface, titleContentColor = text,
        title = { Text(title) },
        text = {
            LazyVerticalGrid(GridCells.Fixed(4), Modifier.heightIn(max = 360.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(AbtinEmoji.all) { e ->
                    val img = remember(e.id) { AbtinEmoji.bitmap(e).asImageBitmap() }
                    Image(img, e.id, Modifier.aspectRatio(1f).clickable { onPick(AbtinEmoji.attach(e)) })
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text(close, color = primary) } }
    )
}
