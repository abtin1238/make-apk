# Abtin SMS 1.5.10

- Incoming call can no longer "disappear": pressing Home, Back, the back-swipe gesture or switching apps while the phone is ringing brings the call screen (and its heads-up notification) straight back, so you no longer have to pull down the shade to answer.
- Back / back-swipe is ignored on the ringing screen.
- While the phone is unlocked and in use, an incoming call now opens the call screen directly instead of only a short heads-up that collapses into the shade.
- Turning the screen off with the power button is left alone so the ring can still be silenced.
- New setting: Call appearance > Call alerts > "Keep call screen up while ringing" (on by default).
- Sending: a message that fits in a single SMS is now sent as a plain single SMS (sendTextMessage), like Google Messages, instead of always going through the multipart path. Longer messages still use multipart.
- Delivery reports kept on: if the carrier rejects a message that asked for a delivery report, the app automatically resends it once without the report request, so the message goes out instead of showing "failed". Messages the carrier accepts still get delivery reports.
