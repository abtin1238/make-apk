import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../core/l10n/app_strings.dart';
import '../design_system/app_theme.dart';
import '../features/settings/settings_controller.dart';
import 'auto_lock.dart';
import 'router.dart';

class AbtinApp extends ConsumerWidget {
  const AbtinApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    return MaterialApp.router(
      routerConfig: ref.watch(routerProvider),
      builder: (context, child) => AutoLock(child: child ?? const SizedBox.shrink()),
      onGenerateTitle: (c) => AppStrings.of(c).appName,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: settings.themeMode,
      locale: settings.locale,
      supportedLocales: AppStrings.supportedLocales,
      localizationsDelegates: const [
        AppStrings.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
    );
  }
}
