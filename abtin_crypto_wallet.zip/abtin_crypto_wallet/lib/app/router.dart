import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../features/home/home_page.dart';
import '../features/markets/markets_page.dart';
import '../features/profile/profile_page.dart';
import '../features/splash/splash_page.dart';
import '../features/trade/trade_page.dart';
import '../features/wallet/application/wallet_providers.dart';
import '../features/wallet/presentation/backup_phrase_page.dart';
import '../features/wallet/presentation/create_wallet_page.dart';
import '../features/wallet/presentation/import_wallet_page.dart';
import '../features/wallet/presentation/onboarding_page.dart';
import '../features/wallet/presentation/pin_setup_page.dart';
import '../features/wallet/presentation/unlock_page.dart';
import '../features/wallet/presentation/verify_phrase_page.dart';
import '../features/wallets/wallets_page.dart';
import 'shell_scaffold.dart';

class _RouterRefresh extends ChangeNotifier {
  void ping() => notifyListeners();
}

const _flowPrefixes = ['/onboarding', '/set-pin', '/create', '/import', '/backup', '/verify'];

StatefulShellBranch _branch(String path, Widget Function() page) => StatefulShellBranch(
      routes: [GoRoute(path: path, builder: (c, s) => page())],
    );

final routerProvider = Provider<GoRouter>((ref) {
  final refresh = _RouterRefresh();
  ref.listen(vaultProvider, (_, __) => refresh.ping());
  ref.listen(walletsProvider, (_, __) => refresh.ping());
  ref.onDispose(refresh.dispose);

  final router = GoRouter(
    initialLocation: '/splash',
    refreshListenable: refresh,
    redirect: (context, state) {
      final loc = state.matchedLocation;
      switch (ref.read(vaultProvider)) {
        case VaultStatus.loading:
          return loc == '/splash' ? null : '/splash';
        case VaultStatus.noPin:
          return (loc == '/onboarding' || loc == '/set-pin') ? null : '/onboarding';
        case VaultStatus.locked:
          return loc == '/unlock' ? null : '/unlock';
        case VaultStatus.unlocked:
          final w = ref.read(walletsProvider).valueOrNull;
          if (w == null) return loc == '/unlock' ? '/splash' : null;
          final empty = w.wallets.isEmpty;
          if (loc == '/splash' || loc == '/unlock') return empty ? '/onboarding' : '/home';
          if (empty && !_flowPrefixes.any(loc.startsWith)) return '/onboarding';
          return null;
      }
    },
    routes: [
      GoRoute(path: '/splash', builder: (c, s) => const SplashPage()),
      GoRoute(path: '/onboarding', builder: (c, s) => const OnboardingPage()),
      GoRoute(
        path: '/set-pin',
        builder: (c, s) => PinSetupPage(next: s.extra as String? ?? '/create'),
      ),
      GoRoute(path: '/unlock', builder: (c, s) => const UnlockPage()),
      GoRoute(path: '/create', builder: (c, s) => const CreateWalletPage()),
      GoRoute(path: '/import', builder: (c, s) => const ImportWalletPage()),
      GoRoute(
        path: '/backup/:id',
        builder: (c, s) => BackupPhrasePage(
          walletId: s.pathParameters['id']!,
          reveal: s.uri.queryParameters['reveal'] == '1',
        ),
      ),
      GoRoute(
        path: '/verify/:id',
        builder: (c, s) => VerifyPhrasePage(walletId: s.pathParameters['id']!),
      ),
      StatefulShellRoute.indexedStack(
        builder: (c, s, shell) => ShellScaffold(shell: shell),
        branches: [
          _branch('/home', () => const HomePage()),
          _branch('/markets', () => const MarketsPage()),
          _branch('/trade', () => const TradePage()),
          _branch('/wallets', () => const WalletsPage()),
          _branch('/profile', () => const ProfilePage()),
        ],
      ),
    ],
  );
  ref.onDispose(router.dispose);
  return router;
});
