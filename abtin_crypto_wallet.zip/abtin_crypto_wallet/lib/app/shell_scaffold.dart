import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../core/l10n/app_strings.dart';

class ShellScaffold extends StatelessWidget {
  const ShellScaffold({super.key, required this.shell});
  final StatefulNavigationShell shell;

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Scaffold(
      body: shell,
      bottomNavigationBar: NavigationBar(
        selectedIndex: shell.currentIndex,
        onDestinationSelected: (i) => shell.goBranch(i, initialLocation: i == shell.currentIndex),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.home_outlined), label: s.home),
          NavigationDestination(icon: const Icon(Icons.candlestick_chart_outlined), label: s.markets),
          NavigationDestination(icon: const Icon(Icons.swap_horiz_rounded), label: s.trade),
          NavigationDestination(icon: const Icon(Icons.account_balance_wallet_outlined), label: s.wallets),
          NavigationDestination(icon: const Icon(Icons.person_outline_rounded), label: s.profile),
        ],
      ),
    );
  }
}
