import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../features/settings/settings_controller.dart';
import '../features/wallet/application/wallet_providers.dart';

/// Locks the vault when the app stays in the background longer than the user's setting.
class AutoLock extends ConsumerStatefulWidget {
  const AutoLock({super.key, required this.child});
  final Widget child;

  @override
  ConsumerState<AutoLock> createState() => _AutoLockState();
}

class _AutoLockState extends ConsumerState<AutoLock> with WidgetsBindingObserver {
  DateTime? _pausedAt;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    _timer?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  void _lock() => ref.read(vaultProvider.notifier).lock();

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final limit = ref.read(settingsProvider).autoLockSeconds;
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
      _timer?.cancel();
      if (limit == 0) {
        _lock();
      } else {
        _timer = Timer(Duration(seconds: limit), _lock);
      }
    } else if (state == AppLifecycleState.resumed) {
      _timer?.cancel();
      final p = _pausedAt;
      _pausedAt = null;
      // Timers can be suspended in the background, so also compare wall-clock time.
      if (p != null && DateTime.now().difference(p).inSeconds >= limit) _lock();
    }
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
