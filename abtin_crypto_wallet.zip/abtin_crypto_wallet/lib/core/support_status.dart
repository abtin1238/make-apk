/// Honest support level per network/feature. Nothing is shown as operational
/// unless it is actually implemented AND verified.
enum SupportStatus {
  fullySupported,
  readOnly,
  sendSupported,
  receiveSupported,
  swapSupported,
  nftSupported,
  defiSupported,
  testnetOnly,
  notYetSupported,
}

class NetworkInfo {
  final String id;
  final String name;
  final String family;
  final SupportStatus status;
  const NetworkInfo(this.id, this.name, this.family, this.status);
}

/// Phase 1: no adapter exists yet, so every network is "not yet supported".
class NetworkRegistry {
  static const List<NetworkInfo> all = [
    NetworkInfo('bitcoin', 'Bitcoin', 'UTXO', SupportStatus.notYetSupported),
    NetworkInfo('ethereum', 'Ethereum', 'EVM', SupportStatus.notYetSupported),
    NetworkInfo('bsc', 'BNB Smart Chain', 'EVM', SupportStatus.notYetSupported),
    NetworkInfo('polygon', 'Polygon', 'EVM', SupportStatus.notYetSupported),
    NetworkInfo('tron', 'TRON', 'TRON', SupportStatus.notYetSupported),
    NetworkInfo('solana', 'Solana', 'Solana', SupportStatus.notYetSupported),
    NetworkInfo('ton', 'TON', 'TON', SupportStatus.notYetSupported),
    NetworkInfo('xrp', 'XRP Ledger', 'XRPL', SupportStatus.notYetSupported),
  ];
}
