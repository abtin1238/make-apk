import 'package:flutter/services.dart';

/// Android FLAG_SECURE (blocks screenshots / recents thumbnail) via a native channel.
/// The Kotlin side is installed by scripts/bootstrap.sh. iOS: not implemented yet (see TODO.md).
class ScreenSecure {
  ScreenSecure._();
  static const _channel = MethodChannel('abtin/secure_screen');

  static Future<void> set(bool enabled) async {
    try {
      await _channel.invokeMethod<void>('set', enabled);
    } on MissingPluginException {
      // Platform without an implementation (iOS today, tests).
    } on PlatformException {
      // Ignore: protection is best effort and must never crash a sensitive screen.
    }
  }
}
