import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Abstraction over hardware-backed storage (Android Keystore / iOS Keychain).
abstract class SecureStore {
  Future<String?> read(String key);
  Future<void> write(String key, String value);
  Future<void> delete(String key);
  Future<void> deleteAll();
}

class PlatformSecureStore implements SecureStore {
  PlatformSecureStore()
      : _s = const FlutterSecureStorage(
          aOptions: AndroidOptions(encryptedSharedPreferences: true),
          iOptions: IOSOptions(accessibility: KeychainAccessibility.unlocked_this_device),
        );
  final FlutterSecureStorage _s;

  @override
  Future<String?> read(String key) => _s.read(key: key);
  @override
  Future<void> write(String key, String value) => _s.write(key: key, value: value);
  @override
  Future<void> delete(String key) => _s.delete(key: key);
  @override
  Future<void> deleteAll() => _s.deleteAll();
}

/// TEST ONLY. Never use in production code paths.
class InMemorySecureStoreForTests implements SecureStore {
  final Map<String, String> _m = {};
  Map<String, String> get dump => Map.unmodifiable(_m);
  @override
  Future<String?> read(String key) async => _m[key];
  @override
  Future<void> write(String key, String value) async => _m[key] = value;
  @override
  Future<void> delete(String key) async => _m.remove(key);
  @override
  Future<void> deleteAll() async => _m.clear();
}
