import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';

import '../support_status.dart';
import 'app_strings_p2.dart';

/// Lightweight localization (fa, en). More languages are added in later phases.
class AppStrings {
  AppStrings(this.locale)
      : _m = locale.languageCode == 'fa' ? {..._fa, ...faP2} : {..._en, ...enP2};

  final Locale locale;
  final Map<String, String> _m;

  static const supportedLocales = [Locale('fa'), Locale('en')];
  static const LocalizationsDelegate<AppStrings> delegate = _Delegate();

  static AppStrings of(BuildContext context) =>
      Localizations.of<AppStrings>(context, AppStrings)!;

  String _t(String k) => _m[k] ?? k;

  /// Generic lookup for keys without a dedicated getter.
  String tr(String key) => _t(key);

  /// Lookup with a `{n}` placeholder.
  String fmt(String key, int n) => _t(key).replaceAll('{n}', '$n');

  static Set<String> get enKeys => {..._en.keys, ...enP2.keys};
  static Set<String> get faKeys => {..._fa.keys, ...faP2.keys};

  String get appName => _t('appName');
  String get tagline => _t('tagline');
  String get home => _t('home');
  String get markets => _t('markets');
  String get trade => _t('trade');
  String get wallets => _t('wallets');
  String get profile => _t('profile');
  String get totalBalance => _t('totalBalance');
  String get noWalletYet => _t('noWalletYet');
  String get createFirstWallet => _t('createFirstWallet');
  String get createWalletDesc => _t('createWalletDesc');
  String get createWallet => _t('createWallet');
  String get importWallet => _t('importWallet');
  String get send => _t('send');
  String get receive => _t('receive');
  String get buy => _t('buy');
  String get swap => _t('swap');
  String get notReadyTitle => _t('notReadyTitle');
  String plannedInPhase(int n) => _t('plannedInPhase').replaceAll('{n}', '$n');
  String get networks => _t('networks');
  String get language => _t('language');
  String get appearance => _t('appearance');
  String get themeSystem => _t('themeSystem');
  String get themeDark => _t('themeDark');
  String get themeLight => _t('themeLight');
  String get security => _t('security');
  String get networkSettings => _t('networkSettings');
  String get notifications => _t('notifications');
  String get backup => _t('backup');
  String get about => _t('about');
  String get version => _t('version');
  String get marketsBody => _t('marketsBody');
  String get tradeBody => _t('tradeBody');
  String get walletsBody => _t('walletsBody');

  String status(SupportStatus s) => _t('status_${s.name}');

  static const _en = <String, String>{
    'appName': 'Abtin Crypto Wallet',
    'tagline': 'Your gateway to Web3',
    'home': 'Home',
    'markets': 'Markets',
    'trade': 'Trade',
    'wallets': 'Wallets',
    'profile': 'Profile',
    'totalBalance': 'Total balance',
    'noWalletYet':
        'No wallet yet. Balances appear only after you create or import a wallet.',
    'createFirstWallet': 'Create your first wallet',
    'createWalletDesc': 'Self-custodial: your keys never leave your device.',
    'createWallet': 'Create wallet',
    'importWallet': 'Import wallet',
    'send': 'Send',
    'receive': 'Receive',
    'buy': 'Buy',
    'swap': 'Swap',
    'notReadyTitle': 'Not available yet',
    'plannedInPhase': 'This feature is not active yet. Planned for phase {n}.',
    'networks': 'Networks',
    'language': 'Language',
    'appearance': 'Appearance',
    'themeSystem': 'System',
    'themeDark': 'Dark',
    'themeLight': 'Light',
    'security': 'Security',
    'networkSettings': 'Network settings',
    'notifications': 'Notifications',
    'backup': 'Backup & recovery',
    'about': 'About',
    'version': 'Version',
    'marketsBody':
        'Live market data is not connected yet. No prices are shown until a real data provider is connected.',
    'tradeBody': 'Trading and charts are not connected yet.',
    'walletsBody': 'Wallet creation is not active yet.',
    'status_fullySupported': 'Fully supported',
    'status_readOnly': 'Read only',
    'status_sendSupported': 'Send supported',
    'status_receiveSupported': 'Receive supported',
    'status_swapSupported': 'Swap supported',
    'status_nftSupported': 'NFT supported',
    'status_defiSupported': 'DeFi supported',
    'status_testnetOnly': 'Testnet only',
    'status_notYetSupported': 'Not yet supported',
  };

  static const _fa = <String, String>{
    'appName': 'کیف پول رمزارز آبتین',
    'tagline': 'دروازه شما به وب۳',
    'home': 'خانه',
    'markets': 'بازارها',
    'trade': 'معاملات',
    'wallets': 'کیف پول‌ها',
    'profile': 'پروفایل',
    'totalBalance': 'موجودی کل',
    'noWalletYet':
        'هنوز کیف پولی وجود ندارد. موجودی‌ها فقط پس از ساخت یا وارد کردن کیف پول نمایش داده می‌شوند.',
    'createFirstWallet': 'اولین کیف پول خود را بسازید',
    'createWalletDesc': 'کیف پول غیرمتمرکز: کلیدهای شما هرگز دستگاهتان را ترک نمی‌کنند.',
    'createWallet': 'ساخت کیف پول',
    'importWallet': 'وارد کردن کیف پول',
    'send': 'ارسال',
    'receive': 'دریافت',
    'buy': 'خرید',
    'swap': 'تبدیل',
    'notReadyTitle': 'هنوز در دسترس نیست',
    'plannedInPhase': 'این قابلیت هنوز فعال نیست. برنامه‌ریزی‌شده برای مرحله {n}.',
    'networks': 'شبکه‌ها',
    'language': 'زبان',
    'appearance': 'ظاهر',
    'themeSystem': 'سیستم',
    'themeDark': 'تیره',
    'themeLight': 'روشن',
    'security': 'امنیت',
    'networkSettings': 'تنظیمات شبکه',
    'notifications': 'اعلان‌ها',
    'backup': 'پشتیبان‌گیری و بازیابی',
    'about': 'درباره',
    'version': 'نسخه',
    'marketsBody':
        'داده‌های زنده بازار هنوز متصل نیست. تا اتصال یک منبع داده واقعی، هیچ قیمتی نمایش داده نمی‌شود.',
    'tradeBody': 'معاملات و نمودارها هنوز متصل نیستند.',
    'walletsBody': 'ساخت کیف پول هنوز فعال نیست.',
    'status_fullySupported': 'پشتیبانی کامل',
    'status_readOnly': 'فقط مشاهده',
    'status_sendSupported': 'ارسال پشتیبانی می‌شود',
    'status_receiveSupported': 'دریافت پشتیبانی می‌شود',
    'status_swapSupported': 'تبدیل پشتیبانی می‌شود',
    'status_nftSupported': 'NFT پشتیبانی می‌شود',
    'status_defiSupported': 'DeFi پشتیبانی می‌شود',
    'status_testnetOnly': 'فقط تست‌نت',
    'status_notYetSupported': 'هنوز پشتیبانی نمی‌شود',
  };
}

class _Delegate extends LocalizationsDelegate<AppStrings> {
  const _Delegate();

  @override
  bool isSupported(Locale locale) =>
      AppStrings.supportedLocales.any((l) => l.languageCode == locale.languageCode);

  @override
  Future<AppStrings> load(Locale locale) => SynchronousFuture(AppStrings(locale));

  @override
  bool shouldReload(covariant LocalizationsDelegate<AppStrings> old) => false;
}
