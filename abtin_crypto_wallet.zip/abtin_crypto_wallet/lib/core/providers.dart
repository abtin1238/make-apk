import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'security/secure_store.dart';

/// Must be overridden in main() / tests.
final sharedPrefsProvider = Provider<SharedPreferences>(
  (ref) => throw UnimplementedError('sharedPrefsProvider must be overridden'),
);

final secureStoreProvider = Provider<SecureStore>((ref) => PlatformSecureStore());
