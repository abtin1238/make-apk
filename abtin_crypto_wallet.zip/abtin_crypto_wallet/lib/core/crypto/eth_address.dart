import 'dart:convert';
import 'dart:typed_data';

import 'package:pointycastle/export.dart';

import 'hex.dart';

Uint8List keccak256(Uint8List data) {
  final d = KeccakDigest(256);
  d.update(data, 0, data.length);
  final out = Uint8List(32);
  d.doFinal(out, 0);
  return out;
}

/// EIP-55 checksummed address from a SEC1 compressed secp256k1 public key.
String ethAddressFromCompressedPubKey(Uint8List compressed) {
  final params = ECCurve_secp256k1();
  final point = params.curve.decodePoint(compressed);
  if (point == null) throw const FormatException('Invalid public key');
  final uncompressed = point.getEncoded(false); // 0x04 || X || Y
  final hash = keccak256(Uint8List.fromList(uncompressed.sublist(1)));
  final addr = toHex(hash.sublist(12));
  return toChecksumAddress(addr);
}

String toChecksumAddress(String address) {
  final lower = (address.startsWith('0x') ? address.substring(2) : address).toLowerCase();
  final hash = toHex(keccak256(Uint8List.fromList(ascii.encode(lower))));
  final sb = StringBuffer('0x');
  for (var i = 0; i < lower.length; i++) {
    final c = lower[i];
    if (RegExp(r'[a-f]').hasMatch(c) && int.parse(hash[i], radix: 16) >= 8) {
      sb.write(c.toUpperCase());
    } else {
      sb.write(c);
    }
  }
  return sb.toString();
}

/// Valid format; if the address is mixed-case, the EIP-55 checksum must match.
bool isValidEthAddress(String address) {
  if (!RegExp(r'^0x[0-9a-fA-F]{40}$').hasMatch(address)) return false;
  final body = address.substring(2);
  if (body == body.toLowerCase() || body == body.toUpperCase()) return true;
  return toChecksumAddress(address) == address;
}
