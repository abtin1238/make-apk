import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:pointycastle/export.dart';

class VaultAuthException implements Exception {
  const VaultAuthException([this.message = 'Authentication failed']);
  final String message;
  @override
  String toString() => 'VaultAuthException: $message';
}

/// AES-256-GCM with a 96-bit random nonce, and PBKDF2-HMAC-SHA256 key derivation.
/// Blob format (base64): nonce(12) || ciphertext || tag(16).
class VaultCipher {
  VaultCipher._();

  static Uint8List randomBytes(int n) {
    final r = Random.secure();
    return Uint8List.fromList(List<int>.generate(n, (_) => r.nextInt(256)));
  }

  static Uint8List deriveKey(String secret, Uint8List salt, int iterations) {
    final kdf = PBKDF2KeyDerivator(HMac(SHA256Digest(), 64))
      ..init(Pbkdf2Parameters(salt, iterations, 32));
    return kdf.process(Uint8List.fromList(utf8.encode(secret)));
  }

  static String encrypt(Uint8List key, Uint8List plaintext, {Uint8List? aad}) {
    final nonce = randomBytes(12);
    final cipher = GCMBlockCipher(AESEngine())
      ..init(true, AEADParameters(KeyParameter(key), 128, nonce, aad ?? Uint8List(0)));
    final ct = cipher.process(plaintext);
    return base64Encode([...nonce, ...ct]);
  }

  static Uint8List decrypt(Uint8List key, String blob, {Uint8List? aad}) {
    try {
      final data = base64Decode(blob);
      if (data.length < 12 + 16) throw const VaultAuthException('Blob too short');
      final nonce = Uint8List.fromList(data.sublist(0, 12));
      final ct = Uint8List.fromList(data.sublist(12));
      final cipher = GCMBlockCipher(AESEngine())
        ..init(false, AEADParameters(KeyParameter(key), 128, nonce, aad ?? Uint8List(0)));
      return cipher.process(ct);
    } on InvalidCipherTextException {
      throw const VaultAuthException();
    } on FormatException {
      throw const VaultAuthException('Corrupted blob');
    }
  }
}
