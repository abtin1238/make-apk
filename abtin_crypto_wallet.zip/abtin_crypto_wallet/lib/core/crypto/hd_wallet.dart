import 'dart:typed_data';

import 'package:bip32/bip32.dart' as bip32;

import 'eth_address.dart';
import 'hex.dart';
import 'mnemonic_service.dart';

class DerivedAccount {
  const DerivedAccount({required this.path, required this.address});
  final String path;
  final String address;
}

/// HD derivation (BIP-32 / BIP-44). Only the EVM family (coin type 60) exists in phase 2.
/// Other chains get their own paths/curves in phase 3 and must never reuse this path.
class HdWallet {
  HdWallet._();

  static String evmPath({int account = 0, int index = 0}) => "m/44'/60'/$account'/0/$index";

  static DerivedAccount deriveEvm(String mnemonic, {int account = 0, int index = 0}) {
    final seed = MnemonicService.toSeed(mnemonic);
    try {
      final path = evmPath(account: account, index: index);
      final child = bip32.BIP32.fromSeed(seed).derivePath(path);
      return DerivedAccount(path: path, address: ethAddressFromCompressedPubKey(child.publicKey));
    } finally {
      zeroize(seed);
    }
  }

  /// SENSITIVE: raw private key bytes. For signing (phase 3) and tests only. Zeroize after use.
  static Uint8List evmPrivateKey(String mnemonic, {int account = 0, int index = 0}) {
    final seed = MnemonicService.toSeed(mnemonic);
    try {
      final child = bip32.BIP32.fromSeed(seed).derivePath(evmPath(account: account, index: index));
      return Uint8List.fromList(child.privateKey!);
    } finally {
      zeroize(seed);
    }
  }
}
