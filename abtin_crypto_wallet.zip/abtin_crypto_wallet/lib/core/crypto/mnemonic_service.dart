import 'dart:typed_data';

import 'package:bip39/bip39.dart' as bip39;

/// BIP-39 mnemonic handling. Entropy comes from the platform CSPRNG (Random.secure).
class MnemonicService {
  MnemonicService._();

  /// Lengths the app can generate.
  static const generatableWordCounts = [12, 24];

  /// Lengths accepted on import (BIP-39 allows all of these).
  static const importableWordCounts = [12, 15, 18, 21, 24];

  static String generate({int words = 12}) {
    if (!generatableWordCounts.contains(words)) {
      throw ArgumentError.value(words, 'words', 'must be 12 or 24');
    }
    return bip39.generateMnemonic(strength: words == 12 ? 128 : 256);
  }

  static String normalize(String input) =>
      input.trim().toLowerCase().split(RegExp(r'\s+')).join(' ');

  static bool isValid(String input) {
    final n = normalize(input);
    if (n.isEmpty) return false;
    if (!importableWordCounts.contains(n.split(' ').length)) return false;
    return bip39.validateMnemonic(n);
  }

  /// 64-byte BIP-39 seed. Caller should [zeroize] it after use.
  static Uint8List toSeed(String mnemonic, {String passphrase = ''}) =>
      bip39.mnemonicToSeed(normalize(mnemonic), passphrase: passphrase);
}
