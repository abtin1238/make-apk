/// Exact fixed-point amount. Floating point is never used for money.
/// [raw] is the smallest unit (e.g. wei, satoshi); [decimals] is the token's decimals.
class Amount implements Comparable<Amount> {
  final BigInt raw;
  final int decimals;

  const Amount(this.raw, this.decimals) : assert(decimals >= 0);

  static final RegExp _fmt = RegExp(r'^-?\d+(\.\d+)?$');

  factory Amount.parse(String input, {required int decimals}) {
    final s = input.trim();
    if (!_fmt.hasMatch(s)) {
      throw FormatException('Invalid amount', input);
    }
    final negative = s.startsWith('-');
    final body = negative ? s.substring(1) : s;
    final parts = body.split('.');
    final frac = parts.length == 2 ? parts[1] : '';
    if (frac.length > decimals) {
      throw FormatException('Too many decimal places (max $decimals)', input);
    }
    final digits = parts[0] + frac.padRight(decimals, '0');
    final value = BigInt.parse(digits);
    return Amount(negative ? -value : value, decimals);
  }

  bool get isNegative => raw.isNegative;
  bool get isZero => raw == BigInt.zero;

  void _same(Amount o) {
    if (decimals != o.decimals) {
      throw ArgumentError('Decimals mismatch: $decimals vs ${o.decimals}');
    }
  }

  Amount operator +(Amount o) {
    _same(o);
    return Amount(raw + o.raw, decimals);
  }

  Amount operator -(Amount o) {
    _same(o);
    return Amount(raw - o.raw, decimals);
  }

  @override
  int compareTo(Amount other) {
    _same(other);
    return raw.compareTo(other.raw);
  }

  @override
  bool operator ==(Object other) =>
      other is Amount && other.raw == raw && other.decimals == decimals;

  @override
  int get hashCode => Object.hash(raw, decimals);

  String toPlainString() {
    final abs = raw.abs().toString().padLeft(decimals + 1, '0');
    final intPart = abs.substring(0, abs.length - decimals);
    final frac = abs.substring(abs.length - decimals).replaceFirst(RegExp(r'0+$'), '');
    final sign = raw.isNegative ? '-' : '';
    return frac.isEmpty ? '$sign$intPart' : '$sign$intPart.$frac';
  }

  @override
  String toString() => toPlainString();
}
