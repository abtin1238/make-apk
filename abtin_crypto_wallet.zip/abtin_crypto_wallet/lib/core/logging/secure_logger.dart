import 'package:flutter/foundation.dart';

/// Logger that redacts anything that looks like secret material.
///
/// Redaction is a last line of defence. The primary rule remains:
/// never pass seeds, private keys or passwords to any logger.
class SecureLogger {
  SecureLogger._();

  /// Overridable sink (used by tests).
  static void Function(String line) sink = (line) => debugPrint(line);

  static final RegExp _hexKey = RegExp(r'\b(?:0x)?[0-9a-fA-F]{64}\b');
  // 12-24 lowercase words in a row: looks like a BIP-39 phrase.
  static final RegExp _phrase = RegExp(r'\b(?:[a-z]{3,8}\s+){11,23}[a-z]{3,8}\b');
  static final RegExp _keyValue = RegExp(
    r'(seed|mnemonic|private[_ ]?key|secret|password|passphrase|pin)\s*[:=]\s*\S+',
    caseSensitive: false,
  );

  static String redact(String input) {
    var out = input.replaceAllMapped(_keyValue, (m) => '${m.group(1)}: [REDACTED]');
    out = out.replaceAll(_phrase, '[REDACTED_PHRASE]');
    out = out.replaceAll(_hexKey, '[REDACTED_HEX]');
    return out;
  }

  static void log(String tag, String message) {
    sink('[$tag] ${redact(message)}');
  }
}
