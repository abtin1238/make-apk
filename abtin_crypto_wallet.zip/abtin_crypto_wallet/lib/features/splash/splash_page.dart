import 'package:flutter/material.dart';

import '../../core/l10n/app_strings.dart';
import '../../design_system/app_colors.dart';

/// Shown while the vault state loads. The router redirects away automatically.
class SplashPage extends StatelessWidget {
  const SplashPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.change_history_rounded, size: 96, color: AppColors.primary),
            const SizedBox(height: 16),
            Text(s.appName,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            Text(s.tagline),
          ],
        ),
      ),
    );
  }
}
