import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../design_system/app_colors.dart';
import '../../design_system/widgets/app_card.dart';
import '../../design_system/widgets/gradient_button.dart';
import '../../design_system/widgets/not_ready_card.dart';
import '../wallet/application/wallet_providers.dart';
import '../wallet/data/wallet_models.dart';

class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = AppStrings.of(context);
    final t = Theme.of(context).textTheme;
    final wallets = ref.watch(walletsProvider);
    final active = wallets.valueOrNull?.active;

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(active?.name ?? s.appName,
                style: t.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 16),
            AppCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(s.totalBalance, style: t.bodyMedium?.copyWith(color: AppColors.mutedDark)),
                  const SizedBox(height: 4),
                  Text('—', style: t.displaySmall?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(active == null ? s.noWalletYet : s.tr('balanceNotConnected'), style: t.bodySmall),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (active != null) ...[
              if (!active.backedUp) _BackupBanner(wallet: active),
              _AddressCard(wallet: active),
              const SizedBox(height: 16),
            ],
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _Action(Icons.arrow_upward_rounded, s.send),
                _Action(Icons.arrow_downward_rounded, s.receive),
                _Action(Icons.credit_card_rounded, s.buy),
                _Action(Icons.swap_horiz_rounded, s.swap),
              ],
            ),
            if (wallets.hasValue && active == null) ...[
              const SizedBox(height: 16),
              AppCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(s.createFirstWallet, style: t.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 6),
                    Text(s.createWalletDesc),
                    const SizedBox(height: 16),
                    GradientButton(label: s.createWallet, onPressed: () => context.go('/onboarding')),
                    const SizedBox(height: 8),
                    SizedBox(
                      width: double.infinity,
                      height: 48,
                      child: OutlinedButton(
                        onPressed: () => context.go('/onboarding'),
                        child: Text(s.importWallet),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _BackupBanner extends StatelessWidget {
  const _BackupBanner({required this.wallet});
  final WalletMeta wallet;

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.warning.withAlpha(30),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.warning.withAlpha(120)),
      ),
      child: Row(
        children: [
          const Icon(Icons.warning_amber_rounded, color: AppColors.warning),
          const SizedBox(width: 8),
          Expanded(child: Text(s.tr('backupNeeded'))),
          TextButton(
            onPressed: () => context.go('/backup/${wallet.id}'),
            child: Text(s.tr('backUpNow')),
          ),
        ],
      ),
    );
  }
}

class _AddressCard extends StatelessWidget {
  const _AddressCard({required this.wallet});
  final WalletMeta wallet;

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(s.tr('yourAddress'), style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 6),
          Directionality(
            textDirection: TextDirection.ltr,
            child: SelectableText(wallet.evmAddress),
          ),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: () async {
              final messenger = ScaffoldMessenger.of(context);
              await Clipboard.setData(ClipboardData(text: wallet.evmAddress));
              messenger.showSnackBar(SnackBar(content: Text(s.tr('copied'))));
            },
            icon: const Icon(Icons.copy_rounded, size: 18),
            label: Text(s.tr('copyAddress')),
          ),
        ],
      ),
    );
  }
}

class _Action extends StatelessWidget {
  const _Action(this.icon, this.label);
  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: 0.5,
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () => showNotReady(context, phase: 3),
        child: Padding(
          padding: const EdgeInsets.all(8),
          child: Column(
            children: [
              CircleAvatar(
                radius: 26,
                backgroundColor: AppColors.primary.withAlpha(60),
                child: Icon(icon),
              ),
              const SizedBox(height: 6),
              Text(label, style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
        ),
      ),
    );
  }
}
