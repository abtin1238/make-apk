import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/providers.dart';

class SettingsState {
  const SettingsState({
    required this.locale,
    required this.themeMode,
    required this.autoLockSeconds,
  });
  final Locale locale;
  final ThemeMode themeMode;
  final int autoLockSeconds;

  SettingsState copyWith({Locale? locale, ThemeMode? themeMode, int? autoLockSeconds}) =>
      SettingsState(
        locale: locale ?? this.locale,
        themeMode: themeMode ?? this.themeMode,
        autoLockSeconds: autoLockSeconds ?? this.autoLockSeconds,
      );
}

class SettingsController extends Notifier<SettingsState> {
  static const _langKey = 'settings.lang';
  static const _themeKey = 'settings.theme';
  static const _lockKey = 'settings.autolock';
  static const autoLockOptions = [0, 30, 60, 300];

  @override
  SettingsState build() {
    final p = ref.read(sharedPrefsProvider);
    final lang = p.getString(_langKey) ?? 'fa';
    final theme = p.getString(_themeKey) ?? 'dark';
    final lock = p.getInt(_lockKey) ?? 30;
    return SettingsState(
      locale: Locale(lang == 'en' ? 'en' : 'fa'),
      themeMode: ThemeMode.values.firstWhere((m) => m.name == theme, orElse: () => ThemeMode.dark),
      autoLockSeconds: autoLockOptions.contains(lock) ? lock : 30,
    );
  }

  Future<void> setLanguage(String code) async {
    await ref.read(sharedPrefsProvider).setString(_langKey, code);
    state = state.copyWith(locale: Locale(code));
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    await ref.read(sharedPrefsProvider).setString(_themeKey, mode.name);
    state = state.copyWith(themeMode: mode);
  }

  Future<void> setAutoLock(int seconds) async {
    await ref.read(sharedPrefsProvider).setInt(_lockKey, seconds);
    state = state.copyWith(autoLockSeconds: seconds);
  }
}

final settingsProvider =
    NotifierProvider<SettingsController, SettingsState>(SettingsController.new);
