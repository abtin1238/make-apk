import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/app_strings.dart';
import '../../design_system/widgets/not_ready_card.dart';
import '../settings/settings_controller.dart';
import '../wallet/application/wallet_providers.dart';
import '../wallet/data/vault_service.dart';
import '../wallet/presentation/wallet_widgets.dart';

class ProfilePage extends ConsumerWidget {
  const ProfilePage({super.key});

  Future<void> _toggleBio(BuildContext context, WidgetRef ref, bool on) async {
    final s = AppStrings.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final svc = ref.read(vaultServiceProvider);
    try {
      if (on) {
        await svc.enableBiometric();
      } else {
        await svc.disableBiometric();
      }
    } on BiometricUnavailableException {
      messenger.showSnackBar(SnackBar(content: Text(s.tr('biometricUnavailable'))));
    } catch (_) {
      messenger.showSnackBar(SnackBar(content: Text(s.tr('genericError'))));
    }
    ref.invalidate(biometricEnabledProvider);
  }

  Future<void> _changePin(BuildContext context, WidgetRef ref) async {
    final s = AppStrings.of(context);
    final messenger = ScaffoldMessenger.of(context);
    final oldC = TextEditingController();
    final newC = TextEditingController();
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.tr('changePin')),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            PinTextField(controller: oldC, label: s.tr('oldPin'), autofocus: true),
            const SizedBox(height: 8),
            PinTextField(controller: newC, label: s.tr('newPin')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.tr('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(s.tr('confirm'))),
        ],
      ),
    );
    final oldPin = oldC.text;
    final newPin = newC.text;
    oldC.clear();
    newC.clear();
    if (go != true) return;
    final check = PinPolicy.check(newPin);
    if (check != PinCheck.ok) {
      messenger.showSnackBar(SnackBar(
        content: Text(check == PinCheck.weak ? s.tr('pinTooWeak') : s.tr('pinInvalid')),
      ));
      return;
    }
    try {
      await ref.read(vaultServiceProvider).changePin(oldPin, newPin);
      messenger.showSnackBar(SnackBar(content: Text(s.tr('pinChanged'))));
    } catch (e) {
      messenger.showSnackBar(SnackBar(content: Text(vaultErrorMessage(s, e))));
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = AppStrings.of(context);
    final settings = ref.watch(settingsProvider);
    final ctrl = ref.read(settingsProvider.notifier);
    final bio = ref.watch(biometricEnabledProvider).valueOrNull ?? false;
    final t = Theme.of(context).textTheme;

    Widget pending(IconData icon, String label, int phase) => ListTile(
          leading: Icon(icon),
          title: Text(label),
          trailing: const Icon(Icons.chevron_right_rounded),
          onTap: () => showNotReady(context, phase: phase),
        );

    final lockLabels = {
      0: s.tr('immediately'),
      30: s.tr('seconds30'),
      60: s.tr('minute1'),
      300: s.tr('minutes5'),
    };

    return Scaffold(
      appBar: AppBar(title: Text(s.profile)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(s.language, style: t.titleSmall),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'fa', label: Text('فارسی')),
              ButtonSegment(value: 'en', label: Text('English')),
            ],
            selected: {settings.locale.languageCode},
            onSelectionChanged: (v) => ctrl.setLanguage(v.first),
          ),
          const SizedBox(height: 16),
          Text(s.appearance, style: t.titleSmall),
          const SizedBox(height: 8),
          SegmentedButton<ThemeMode>(
            segments: [
              ButtonSegment(value: ThemeMode.system, label: Text(s.themeSystem)),
              ButtonSegment(value: ThemeMode.dark, label: Text(s.themeDark)),
              ButtonSegment(value: ThemeMode.light, label: Text(s.themeLight)),
            ],
            selected: {settings.themeMode},
            onSelectionChanged: (v) => ctrl.setThemeMode(v.first),
          ),
          const Divider(height: 32),
          Text(s.security, style: t.titleSmall),
          const SizedBox(height: 8),
          Text(s.tr('autoLock')),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              for (final secs in SettingsController.autoLockOptions)
                ChoiceChip(
                  label: Text(lockLabels[secs]!),
                  selected: settings.autoLockSeconds == secs,
                  onSelected: (_) => ctrl.setAutoLock(secs),
                ),
            ],
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: Text(s.tr('biometricUnlock')),
            value: bio,
            onChanged: (v) => _toggleBio(context, ref, v),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.password_rounded),
            title: Text(s.tr('changePin')),
            onTap: () => _changePin(context, ref),
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.lock_outline_rounded),
            title: Text(s.tr('lockNow')),
            onTap: () => ref.read(vaultProvider.notifier).lock(),
          ),
          const Divider(height: 32),
          pending(Icons.lan_outlined, s.networkSettings, 3),
          pending(Icons.notifications_outlined, s.notifications, 7),
          ListTile(
            leading: const Icon(Icons.info_outline_rounded),
            title: Text(s.about),
            subtitle: Text('${s.version} 0.2.0 (phase 2)'),
          ),
        ],
      ),
    );
  }
}
