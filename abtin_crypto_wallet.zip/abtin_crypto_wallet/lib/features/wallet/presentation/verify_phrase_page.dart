import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/l10n/app_strings.dart';
import '../../../core/security/screen_secure.dart';
import '../../../design_system/widgets/gradient_button.dart';
import '../application/wallet_providers.dart';

class VerifyPhrasePage extends ConsumerStatefulWidget {
  const VerifyPhrasePage({super.key, required this.walletId});
  final String walletId;

  @override
  ConsumerState<VerifyPhrasePage> createState() => _VerifyPhrasePageState();
}

class _VerifyPhrasePageState extends ConsumerState<VerifyPhrasePage> {
  List<String>? _words;
  List<int> _indexes = const [];
  final List<TextEditingController> _controllers = [];
  String? _error;

  @override
  void initState() {
    super.initState();
    ScreenSecure.set(true);
    _load();
  }

  Future<void> _load() async {
    final m = await ref.read(vaultServiceProvider).readMnemonic(widget.walletId);
    final words = m.split(' ');
    final rnd = Random.secure();
    final picked = <int>{};
    while (picked.length < 3) {
      picked.add(rnd.nextInt(words.length));
    }
    if (!mounted) return;
    setState(() {
      _words = words;
      _indexes = picked.toList()..sort();
      _controllers.addAll(List.generate(3, (_) => TextEditingController()));
    });
  }

  @override
  void dispose() {
    for (final c in _controllers) {
      c.dispose();
    }
    _words = null;
    ScreenSecure.set(false);
    super.dispose();
  }

  Future<void> _verify() async {
    final words = _words!;
    var ok = true;
    for (var i = 0; i < 3; i++) {
      if (_controllers[i].text.trim().toLowerCase() != words[_indexes[i]]) ok = false;
    }
    if (!ok) {
      setState(() => _error = AppStrings.of(context).tr('verifyWrong'));
      return;
    }
    await ref.read(walletsProvider.notifier).markBackedUp(widget.walletId);
    if (!mounted) return;
    context.go('/home');
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.tr('verifyTitle'))),
      body: _words == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(24),
              children: [
                Text(s.tr('verifyDesc')),
                const SizedBox(height: 16),
                for (var i = 0; i < 3; i++) ...[
                  Directionality(
                    textDirection: TextDirection.ltr,
                    child: TextField(
                      controller: _controllers[i],
                      autocorrect: false,
                      enableSuggestions: false,
                      keyboardType: TextInputType.visiblePassword,
                      decoration: InputDecoration(
                        labelText: s.fmt('wordNumber', _indexes[i] + 1),
                        border: const OutlineInputBorder(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                ],
                if (_error != null)
                  Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
                const SizedBox(height: 12),
                GradientButton(label: s.tr('verify'), onPressed: _verify),
                TextButton(
                  onPressed: () => context.go('/backup/${widget.walletId}'),
                  child: Text(s.tr('backupTitle')),
                ),
              ],
            ),
    );
  }
}
