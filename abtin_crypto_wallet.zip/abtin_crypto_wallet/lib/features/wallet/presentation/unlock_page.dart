import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/app_strings.dart';
import '../../../design_system/app_colors.dart';
import '../../../design_system/widgets/gradient_button.dart';
import '../application/wallet_providers.dart';
import 'wallet_widgets.dart';

class UnlockPage extends ConsumerStatefulWidget {
  const UnlockPage({super.key});
  @override
  ConsumerState<UnlockPage> createState() => _UnlockPageState();
}

class _UnlockPageState extends ConsumerState<UnlockPage> {
  final _pin = TextEditingController();
  String? _error;
  bool _busy = false;
  bool _bio = false;

  @override
  void initState() {
    super.initState();
    _initBio();
  }

  Future<void> _initBio() async {
    final enabled = await ref.read(vaultServiceProvider).isBiometricEnabled();
    if (!mounted) return;
    setState(() => _bio = enabled);
    if (enabled) _bioUnlock();
  }

  @override
  void dispose() {
    _pin.dispose();
    super.dispose();
  }

  Future<void> _bioUnlock() async {
    await ref.read(vaultProvider.notifier).unlockWithBiometric();
  }

  Future<void> _unlock() async {
    final s = AppStrings.of(context);
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(vaultProvider.notifier).unlockWithPin(_pin.text);
    } catch (e) {
      if (mounted) setState(() => _error = vaultErrorMessage(s, e));
    } finally {
      _pin.clear();
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const SizedBox(height: 48),
            const Icon(Icons.lock_outline_rounded, size: 72, color: AppColors.primary),
            const SizedBox(height: 16),
            Text(s.tr('enterPin'), textAlign: TextAlign.center, style: Theme.of(context).textTheme.titleLarge),
            const SizedBox(height: 24),
            PinTextField(
              controller: _pin,
              label: s.tr('pin'),
              autofocus: true,
              onSubmitted: (_) => _unlock(),
            ),
            if (_error != null) ...[
              const SizedBox(height: 8),
              Text(_error!, textAlign: TextAlign.center, style: TextStyle(color: Theme.of(context).colorScheme.error)),
            ],
            const SizedBox(height: 16),
            _busy
                ? const Center(child: CircularProgressIndicator())
                : GradientButton(label: s.tr('unlock'), onPressed: _unlock),
            if (_bio) ...[
              const SizedBox(height: 12),
              TextButton.icon(
                onPressed: _bioUnlock,
                icon: const Icon(Icons.fingerprint_rounded),
                label: Text(s.tr('useBiometric')),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
