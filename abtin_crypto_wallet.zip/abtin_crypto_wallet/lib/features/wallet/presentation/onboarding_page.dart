import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/l10n/app_strings.dart';
import '../../../design_system/app_colors.dart';
import '../../../design_system/widgets/gradient_button.dart';
import '../application/wallet_providers.dart';

class OnboardingPage extends ConsumerWidget {
  const OnboardingPage({super.key});

  void _go(BuildContext context, WidgetRef ref, String target) {
    if (ref.read(vaultProvider) == VaultStatus.noPin) {
      context.go('/set-pin', extra: target);
    } else {
      context.go(target);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = AppStrings.of(context);
    return Scaffold(
      appBar: context.canPop() ? AppBar() : null,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const Spacer(),
              const Icon(Icons.change_history_rounded, size: 96, color: AppColors.primary),
              const SizedBox(height: 16),
              Text(s.appName,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text(s.createWalletDesc, textAlign: TextAlign.center),
              const Spacer(),
              GradientButton(label: s.createWallet, onPressed: () => _go(context, ref, '/create')),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                height: 52,
                child: OutlinedButton(
                  onPressed: () => _go(context, ref, '/import'),
                  child: Text(s.importWallet),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
