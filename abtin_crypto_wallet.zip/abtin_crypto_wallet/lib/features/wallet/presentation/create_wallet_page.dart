import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/l10n/app_strings.dart';
import '../../../design_system/widgets/gradient_button.dart';
import '../application/wallet_providers.dart';
import 'wallet_widgets.dart';

class CreateWalletPage extends ConsumerStatefulWidget {
  const CreateWalletPage({super.key});
  @override
  ConsumerState<CreateWalletPage> createState() => _CreateWalletPageState();
}

class _CreateWalletPageState extends ConsumerState<CreateWalletPage> {
  final _name = TextEditingController();
  int _words = 12;
  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  Future<void> _create() async {
    final s = AppStrings.of(context);
    final count = ref.read(walletsProvider).valueOrNull?.wallets.length ?? 0;
    final name = _name.text.trim().isEmpty ? s.fmt('defaultWalletName', count + 1) : _name.text.trim();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      final meta = await ref.read(walletsProvider.notifier).create(name, _words);
      if (!mounted) return;
      context.go('/backup/${meta.id}');
    } catch (e) {
      if (mounted) setState(() => _error = vaultErrorMessage(s, e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.createWallet)),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          TextField(
            controller: _name,
            decoration: InputDecoration(labelText: s.tr('walletName'), border: const OutlineInputBorder()),
          ),
          const SizedBox(height: 24),
          Text(s.tr('phraseLength')),
          const SizedBox(height: 8),
          SegmentedButton<int>(
            segments: [
              ButtonSegment(value: 12, label: Text(s.tr('words12'))),
              ButtonSegment(value: 24, label: Text(s.tr('words24'))),
            ],
            selected: {_words},
            onSelectionChanged: (v) => setState(() => _words = v.first),
          ),
          if (_error != null) ...[
            const SizedBox(height: 8),
            Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
          const SizedBox(height: 24),
          _busy
              ? const Center(child: CircularProgressIndicator())
              : GradientButton(label: s.tr('createNow'), onPressed: _create),
        ],
      ),
    );
  }
}
