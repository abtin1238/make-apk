import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/l10n/app_strings.dart';
import '../../../core/security/screen_secure.dart';
import '../../../design_system/app_colors.dart';
import '../../../design_system/widgets/gradient_button.dart';
import '../application/wallet_providers.dart';

/// Shows the recovery phrase. Screenshots are blocked on Android while visible.
/// There is intentionally no "copy" button (clipboard is readable by other apps).
class BackupPhrasePage extends ConsumerStatefulWidget {
  const BackupPhrasePage({super.key, required this.walletId, this.reveal = false});
  final String walletId;
  final bool reveal;

  @override
  ConsumerState<BackupPhrasePage> createState() => _BackupPhrasePageState();
}

class _BackupPhrasePageState extends ConsumerState<BackupPhrasePage> {
  List<String>? _words;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    ScreenSecure.set(true);
    _load();
  }

  Future<void> _load() async {
    try {
      final m = await ref.read(vaultServiceProvider).readMnemonic(widget.walletId);
      if (mounted) setState(() => _words = m.split(' '));
    } catch (_) {
      if (mounted) setState(() => _failed = true);
    }
  }

  @override
  void dispose() {
    _words = null;
    ScreenSecure.set(false);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    final words = _words;
    return Scaffold(
      appBar: AppBar(title: Text(s.tr('backupTitle'))),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.negative.withAlpha(30),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.negative.withAlpha(120)),
            ),
            child: Text(s.tr('backupWarning')),
          ),
          const SizedBox(height: 16),
          if (_failed)
            Text(s.tr('genericError'))
          else if (words == null)
            const Center(child: CircularProgressIndicator())
          else
            Directionality(
              textDirection: TextDirection.ltr,
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (var i = 0; i < words.length; i++)
                    Chip(label: Text('${i + 1}. ${words[i]}')),
                ],
              ),
            ),
          const SizedBox(height: 24),
          GradientButton(
            label: widget.reveal ? s.tr('done') : s.tr('iSavedIt'),
            onPressed: words == null
                ? null
                : () => widget.reveal
                    ? context.go('/wallets')
                    : context.go('/verify/${widget.walletId}'),
          ),
        ],
      ),
    );
  }
}
