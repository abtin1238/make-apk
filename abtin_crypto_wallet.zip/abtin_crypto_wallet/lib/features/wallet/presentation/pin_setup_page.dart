import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/l10n/app_strings.dart';
import '../../../design_system/widgets/gradient_button.dart';
import '../application/wallet_providers.dart';
import '../data/vault_service.dart';
import 'wallet_widgets.dart';

class PinSetupPage extends ConsumerStatefulWidget {
  const PinSetupPage({super.key, this.next = '/create'});
  final String next;

  @override
  ConsumerState<PinSetupPage> createState() => _PinSetupPageState();
}

class _PinSetupPageState extends ConsumerState<PinSetupPage> {
  final _pin = TextEditingController();
  final _confirm = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  void dispose() {
    _pin.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final s = AppStrings.of(context);
    final check = PinPolicy.check(_pin.text);
    String? err;
    if (check == PinCheck.invalid) {
      err = s.tr('pinInvalid');
    } else if (check == PinCheck.weak) {
      err = s.tr('pinTooWeak');
    } else if (_pin.text != _confirm.text) {
      err = s.tr('pinMismatch');
    }
    if (err != null) {
      setState(() => _error = err);
      return;
    }
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(vaultProvider.notifier).setupPin(_pin.text);
      if (!mounted) return;
      context.go(widget.next);
    } catch (e) {
      if (mounted) setState(() => _error = s.tr('genericError'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.tr('setPinTitle'))),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text(s.tr('setPinDesc')),
          const SizedBox(height: 24),
          PinTextField(controller: _pin, label: s.tr('pin')),
          const SizedBox(height: 12),
          PinTextField(controller: _confirm, label: s.tr('confirmPin')),
          if (_error != null) ...[
            const SizedBox(height: 8),
            Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
          const SizedBox(height: 16),
          _busy
              ? const Center(child: CircularProgressIndicator())
              : GradientButton(label: s.tr('continueLabel'), onPressed: _submit),
        ],
      ),
    );
  }
}
