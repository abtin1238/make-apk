import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/app_strings.dart';
import '../application/wallet_providers.dart';
import '../data/vault_service.dart';

String shortAddress(String a) =>
    a.length < 12 ? a : '${a.substring(0, 6)}…${a.substring(a.length - 4)}';

String vaultErrorMessage(AppStrings s, Object e) {
  if (e is WrongPinException) return s.fmt('wrongPin', e.attemptsLeft);
  if (e is LockedOutException) return s.fmt('lockedOut', e.remaining.inSeconds + 1);
  if (e is DuplicateWalletException) return s.tr('duplicateWallet');
  return s.tr('genericError');
}

class PinTextField extends StatelessWidget {
  const PinTextField({
    super.key,
    required this.controller,
    required this.label,
    this.autofocus = false,
    this.onSubmitted,
  });
  final TextEditingController controller;
  final String label;
  final bool autofocus;
  final ValueChanged<String>? onSubmitted;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      autofocus: autofocus,
      obscureText: true,
      keyboardType: TextInputType.number,
      maxLength: 6,
      textAlign: TextAlign.center,
      enableSuggestions: false,
      autocorrect: false,
      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
      style: const TextStyle(fontSize: 22, letterSpacing: 8),
      onSubmitted: onSubmitted,
      decoration: InputDecoration(
        labelText: label,
        counterText: '',
        border: const OutlineInputBorder(),
      ),
    );
  }
}

Future<String?> askPin(BuildContext context) async {
  final s = AppStrings.of(context);
  final c = TextEditingController();
  final r = await showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(s.tr('enterPinToContinue')),
      content: PinTextField(controller: c, label: s.tr('pin'), autofocus: true),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.tr('cancel'))),
        FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: Text(s.tr('confirm'))),
      ],
    ),
  );
  c.clear();
  return r;
}

/// Asks for the PIN and verifies it. Shows an error snackbar and returns false on failure.
Future<bool> confirmWithPin(BuildContext context, WidgetRef ref) async {
  final s = AppStrings.of(context);
  final messenger = ScaffoldMessenger.of(context);
  final pin = await askPin(context);
  if (pin == null) return false;
  try {
    await ref.read(vaultServiceProvider).verifyPin(pin);
    return true;
  } catch (e) {
    messenger.showSnackBar(SnackBar(content: Text(vaultErrorMessage(s, e))));
    return false;
  }
}
