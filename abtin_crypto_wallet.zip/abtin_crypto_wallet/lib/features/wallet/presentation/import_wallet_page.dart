import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/crypto/mnemonic_service.dart';
import '../../../core/l10n/app_strings.dart';
import '../../../core/security/screen_secure.dart';
import '../../../design_system/widgets/gradient_button.dart';
import '../application/wallet_providers.dart';
import 'wallet_widgets.dart';

class ImportWalletPage extends ConsumerStatefulWidget {
  const ImportWalletPage({super.key});
  @override
  ConsumerState<ImportWalletPage> createState() => _ImportWalletPageState();
}

class _ImportWalletPageState extends ConsumerState<ImportWalletPage> {
  final _name = TextEditingController();
  final _phrase = TextEditingController();
  String? _error;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    ScreenSecure.set(true);
  }

  @override
  void dispose() {
    _phrase.clear();
    _phrase.dispose();
    _name.dispose();
    ScreenSecure.set(false);
    super.dispose();
  }

  Future<void> _import() async {
    final s = AppStrings.of(context);
    if (!MnemonicService.isValid(_phrase.text)) {
      setState(() => _error = s.tr('invalidPhrase'));
      return;
    }
    final count = ref.read(walletsProvider).valueOrNull?.wallets.length ?? 0;
    final name = _name.text.trim().isEmpty ? s.fmt('defaultWalletName', count + 1) : _name.text.trim();
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await ref.read(walletsProvider.notifier).importPhrase(name, _phrase.text);
      _phrase.clear();
      if (!mounted) return;
      context.go('/home');
    } catch (e) {
      if (mounted) setState(() => _error = vaultErrorMessage(s, e));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.tr('importTitle'))),
      body: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Text(s.tr('importDesc')),
          const SizedBox(height: 16),
          TextField(
            controller: _name,
            decoration: InputDecoration(labelText: s.tr('walletName'), border: const OutlineInputBorder()),
          ),
          const SizedBox(height: 12),
          Directionality(
            textDirection: TextDirection.ltr,
            child: TextField(
              controller: _phrase,
              minLines: 3,
              maxLines: 5,
              autocorrect: false,
              enableSuggestions: false,
              enableIMEPersonalizedLearning: false,
              keyboardType: TextInputType.visiblePassword,
              decoration: InputDecoration(hintText: s.tr('phraseHint'), border: const OutlineInputBorder()),
            ),
          ),
          if (_error != null) ...[
            const SizedBox(height: 8),
            Text(_error!, style: TextStyle(color: Theme.of(context).colorScheme.error)),
          ],
          const SizedBox(height: 16),
          _busy
              ? const Center(child: CircularProgressIndicator())
              : GradientButton(label: s.tr('importNow'), onPressed: _import),
        ],
      ),
    );
  }
}
