import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/crypto/mnemonic_service.dart';
import '../../../core/providers.dart';
import '../data/biometric_auth.dart';
import '../data/vault_service.dart';
import '../data/wallet_models.dart';

final vaultServiceProvider = Provider<VaultService>(
  (ref) => VaultService(store: ref.watch(secureStoreProvider), biometric: LocalAuthBiometric()),
);

enum VaultStatus { loading, noPin, locked, unlocked }

class VaultController extends Notifier<VaultStatus> {
  VaultService get _svc => ref.read(vaultServiceProvider);

  @override
  VaultStatus build() {
    Future.microtask(refresh);
    return VaultStatus.loading;
  }

  Future<void> refresh() async {
    final has = await _svc.hasPin();
    state = !has ? VaultStatus.noPin : (_svc.isUnlocked ? VaultStatus.unlocked : VaultStatus.locked);
  }

  Future<void> setupPin(String pin) async {
    await _svc.setupPin(pin);
    state = VaultStatus.unlocked;
  }

  Future<void> unlockWithPin(String pin) async {
    await _svc.unlockWithPin(pin);
    state = VaultStatus.unlocked;
  }

  Future<bool> unlockWithBiometric() async {
    final ok = await _svc.unlockWithBiometric();
    if (ok) state = VaultStatus.unlocked;
    return ok;
  }

  void lock() {
    if (state != VaultStatus.unlocked) return;
    _svc.lock();
    state = VaultStatus.locked;
  }
}

final vaultProvider = NotifierProvider<VaultController, VaultStatus>(VaultController.new);

final biometricEnabledProvider = FutureProvider.autoDispose<bool>(
  (ref) => ref.watch(vaultServiceProvider).isBiometricEnabled(),
);

class WalletsState {
  const WalletsState(this.wallets, this.activeId);
  final List<WalletMeta> wallets;
  final String? activeId;

  WalletMeta? get active {
    for (final w in wallets) {
      if (w.id == activeId) return w;
    }
    return wallets.isEmpty ? null : wallets.first;
  }
}

class WalletsController extends AsyncNotifier<WalletsState> {
  VaultService get _svc => ref.read(vaultServiceProvider);

  @override
  Future<WalletsState> build() => _load();

  Future<WalletsState> _load() async =>
      WalletsState(await _svc.listWallets(), await _svc.getActiveId());

  Future<void> _reload() async {
    state = AsyncData(await _load());
  }

  Future<WalletMeta> create(String name, int words) async {
    final meta = await _svc.addWallet(
      name: name,
      mnemonic: MnemonicService.generate(words: words),
      backedUp: false,
    );
    await _svc.setActiveId(meta.id);
    await _reload();
    return meta;
  }

  Future<WalletMeta> importPhrase(String name, String phrase) async {
    final meta = await _svc.addWallet(name: name, mnemonic: phrase, backedUp: true);
    await _svc.setActiveId(meta.id);
    await _reload();
    return meta;
  }

  Future<void> setActive(String id) async {
    await _svc.setActiveId(id);
    await _reload();
  }

  Future<void> rename(String id, String name) async {
    await _svc.renameWallet(id, name);
    await _reload();
  }

  Future<void> markBackedUp(String id) async {
    await _svc.markBackedUp(id);
    await _reload();
  }

  Future<void> delete(String id) async {
    await _svc.deleteWallet(id);
    await _reload();
  }
}

final walletsProvider =
    AsyncNotifierProvider<WalletsController, WalletsState>(WalletsController.new);
