import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';

import '../../../core/crypto/hd_wallet.dart';
import '../../../core/crypto/hex.dart';
import '../../../core/crypto/mnemonic_service.dart';
import '../../../core/crypto/vault_cipher.dart';
import '../../../core/security/secure_store.dart';
import 'biometric_auth.dart';
import 'wallet_models.dart';

class VaultLockedException implements Exception {
  const VaultLockedException();
}

class WrongPinException implements Exception {
  const WrongPinException(this.attemptsLeft);
  final int attemptsLeft;
}

class LockedOutException implements Exception {
  const LockedOutException(this.remaining);
  final Duration remaining;
}

class DuplicateWalletException implements Exception {
  const DuplicateWalletException();
}

class BiometricUnavailableException implements Exception {
  const BiometricUnavailableException();
}

enum PinCheck { ok, invalid, weak }

class PinPolicy {
  PinPolicy._();
  static const _weak = {'123456', '654321', '012345', '543210', '123123', '121212', '112233', '696969'};

  static PinCheck check(String pin) {
    if (!RegExp(r'^\d{6}$').hasMatch(pin)) return PinCheck.invalid;
    if (RegExp(r'^(\d)\1{5}$').hasMatch(pin) || _weak.contains(pin)) return PinCheck.weak;
    return PinCheck.ok;
  }
}

typedef Kdf = Future<Uint8List> Function(String secret, Uint8List salt, int iterations);

Uint8List _kdfEntry(List<Object> a) =>
    VaultCipher.deriveKey(a[0] as String, a[1] as Uint8List, a[2] as int);

/// Runs PBKDF2 in a background isolate so the UI does not freeze.
Future<Uint8List> defaultKdf(String secret, Uint8List salt, int iterations) =>
    compute(_kdfEntry, <Object>[secret, salt, iterations]);

/// Key hierarchy:
///   PIN --PBKDF2--> pinKey --AES-GCM--> wraps random 256-bit masterKey
///   masterKey --AES-GCM(aad = wallet id)--> encrypted recovery phrase of each wallet
/// All blobs additionally live in Android Keystore / iOS Keychain backed storage.
/// masterKey exists in memory only while unlocked and is zeroed on [lock].
class VaultService {
  VaultService({
    required this.store,
    required this.biometric,
    this.kdfIterations = 120000,
    Kdf? kdf,
    DateTime Function()? clock,
  })  : _kdf = kdf ?? defaultKdf,
        _now = clock ?? DateTime.now;

  final SecureStore store;
  final BiometricAuth biometric;
  final int kdfIterations;
  final Kdf _kdf;
  final DateTime Function() _now;

  static const maxFreeAttempts = 5;
  static const _kSalt = 'vault.kdf.salt';
  static const _kIter = 'vault.kdf.iter';
  static const _kWrap = 'vault.master.wrap';
  static const _kFails = 'vault.fails';
  static const _kLockUntil = 'vault.lockUntil';
  static const _kBioKey = 'vault.bio.key';
  static const _kBioWrap = 'vault.bio.wrap';
  static const _kWallets = 'vault.wallets';
  static const _kActive = 'vault.active';

  static final Uint8List _masterAad = Uint8List.fromList(utf8.encode('abtin.master.v1'));
  static Uint8List _seedAad(String id) => Uint8List.fromList(utf8.encode('abtin.seed.v1.$id'));

  Uint8List? _master;

  bool get isUnlocked => _master != null;

  Future<bool> hasPin() async => await store.read(_kWrap) != null;

  Uint8List _requireMaster() {
    final m = _master;
    if (m == null) throw const VaultLockedException();
    return m;
  }

  // ---------------- PIN ----------------

  Future<void> setupPin(String pin) async {
    if (PinPolicy.check(pin) != PinCheck.ok) throw ArgumentError('PIN rejected by policy');
    if (await hasPin()) throw StateError('PIN already set');
    final master = await _wrapNewMaster(pin, VaultCipher.randomBytes(32));
    await _resetFailures();
    zeroize(_master);
    _master = master;
  }

  Future<Uint8List> _wrapNewMaster(String pin, Uint8List master) async {
    final salt = VaultCipher.randomBytes(16);
    final key = await _kdf(pin, salt, kdfIterations);
    final wrap = VaultCipher.encrypt(key, master, aad: _masterAad);
    zeroize(key);
    await store.write(_kSalt, base64Encode(salt));
    await store.write(_kIter, '$kdfIterations');
    await store.write(_kWrap, wrap);
    return master;
  }

  Future<Uint8List> _unwrapWithPin(String pin) async {
    final nowMs = _now().millisecondsSinceEpoch;
    final lockUntil = int.tryParse(await store.read(_kLockUntil) ?? '') ?? 0;
    if (nowMs < lockUntil) throw LockedOutException(Duration(milliseconds: lockUntil - nowMs));

    final saltB64 = await store.read(_kSalt);
    final wrap = await store.read(_kWrap);
    final iter = int.tryParse(await store.read(_kIter) ?? '');
    if (saltB64 == null || wrap == null || iter == null) throw StateError('Vault not initialised');

    final key = await _kdf(pin, base64Decode(saltB64), iter);
    try {
      final master = VaultCipher.decrypt(key, wrap, aad: _masterAad);
      await _resetFailures();
      return master;
    } on VaultAuthException {
      final fails = (int.tryParse(await store.read(_kFails) ?? '') ?? 0) + 1;
      await store.write(_kFails, '$fails');
      if (fails >= maxFreeAttempts) {
        final secs = min(3600, 30 * pow(2, min(fails - maxFreeAttempts, 7)).toInt());
        await store.write(_kLockUntil, '${nowMs + secs * 1000}');
        throw LockedOutException(Duration(seconds: secs));
      }
      throw WrongPinException(maxFreeAttempts - fails);
    } finally {
      zeroize(key);
    }
  }

  Future<void> _resetFailures() async {
    await store.delete(_kFails);
    await store.delete(_kLockUntil);
  }

  Future<void> unlockWithPin(String pin) async {
    final master = await _unwrapWithPin(pin);
    zeroize(_master);
    _master = master;
  }

  /// Re-authenticate for sensitive actions without changing lock state.
  Future<void> verifyPin(String pin) async {
    final m = await _unwrapWithPin(pin);
    zeroize(m);
  }

  Future<void> changePin(String oldPin, String newPin) async {
    if (PinPolicy.check(newPin) != PinCheck.ok) throw ArgumentError('PIN rejected by policy');
    final master = await _unwrapWithPin(oldPin);
    await _wrapNewMaster(newPin, master);
    zeroize(_master);
    _master = master;
  }

  void lock() {
    zeroize(_master);
    _master = null;
  }

  // ---------------- Biometrics ----------------
  // The biometric prompt gates access to a wrapping key held in Keystore/Keychain-backed storage.
  // A key cryptographically bound to the biometric (native code) is on the TODO list.

  Future<bool> isBiometricEnabled() async => await store.read(_kBioWrap) != null;

  Future<void> enableBiometric() async {
    final master = _requireMaster();
    if (!await biometric.isAvailable()) throw const BiometricUnavailableException();
    if (!await biometric.authenticate('Enable biometric unlock')) {
      throw const BiometricUnavailableException();
    }
    final bioKey = VaultCipher.randomBytes(32);
    await store.write(_kBioKey, base64Encode(bioKey));
    await store.write(_kBioWrap, VaultCipher.encrypt(bioKey, master, aad: _masterAad));
    zeroize(bioKey);
  }

  Future<void> disableBiometric() async {
    await store.delete(_kBioKey);
    await store.delete(_kBioWrap);
  }

  Future<bool> unlockWithBiometric() async {
    if (!await isBiometricEnabled()) return false;
    if (!await biometric.authenticate('Unlock Abtin Crypto Wallet')) return false;
    final keyB64 = await store.read(_kBioKey);
    final wrap = await store.read(_kBioWrap);
    if (keyB64 == null || wrap == null) return false;
    final bioKey = base64Decode(keyB64);
    try {
      final master = VaultCipher.decrypt(Uint8List.fromList(bioKey), wrap, aad: _masterAad);
      zeroize(_master);
      _master = master;
      return true;
    } on VaultAuthException {
      return false;
    }
  }

  // ---------------- Wallets ----------------

  Future<List<WalletMeta>> listWallets() async {
    final raw = await store.read(_kWallets);
    if (raw == null) return [];
    return (jsonDecode(raw) as List)
        .map((e) => WalletMeta.fromJson(e as Map<String, dynamic>))
        .toList();
  }

  Future<void> _save(List<WalletMeta> l) =>
      store.write(_kWallets, jsonEncode(l.map((e) => e.toJson()).toList()));

  Future<WalletMeta> addWallet({
    required String name,
    required String mnemonic,
    required bool backedUp,
  }) async {
    final master = _requireMaster();
    final normalized = MnemonicService.normalize(mnemonic);
    if (!MnemonicService.isValid(normalized)) throw ArgumentError('Invalid mnemonic');
    final account = HdWallet.deriveEvm(normalized);
    final wallets = await listWallets();
    if (wallets.any((w) => w.evmAddress.toLowerCase() == account.address.toLowerCase())) {
      throw const DuplicateWalletException();
    }
    final id = toHex(VaultCipher.randomBytes(8));
    final plain = Uint8List.fromList(utf8.encode(normalized));
    final blob = VaultCipher.encrypt(master, plain, aad: _seedAad(id));
    zeroize(plain);
    await store.write('vault.seed.$id', blob);
    final meta = WalletMeta(
      id: id,
      name: name,
      createdAtMs: _now().millisecondsSinceEpoch,
      backedUp: backedUp,
      evmAddress: account.address,
    );
    await _save([...wallets, meta]);
    return meta;
  }

  Future<String> readMnemonic(String id) async {
    final master = _requireMaster();
    final blob = await store.read('vault.seed.$id');
    if (blob == null) throw StateError('Unknown wallet');
    final bytes = VaultCipher.decrypt(master, blob, aad: _seedAad(id));
    final phrase = utf8.decode(bytes);
    zeroize(bytes);
    return phrase;
  }

  Future<void> _update(String id, WalletMeta Function(WalletMeta) f) async {
    final list = await listWallets();
    await _save([for (final w in list) w.id == id ? f(w) : w]);
  }

  Future<void> markBackedUp(String id) => _update(id, (w) => w.copyWith(backedUp: true));
  Future<void> renameWallet(String id, String name) => _update(id, (w) => w.copyWith(name: name));

  Future<void> deleteWallet(String id) async {
    final list = await listWallets();
    await store.delete('vault.seed.$id');
    await _save(list.where((w) => w.id != id).toList());
    if (await getActiveId() == id) await store.delete(_kActive);
  }

  Future<String?> getActiveId() => store.read(_kActive);
  Future<void> setActiveId(String id) => store.write(_kActive, id);
}
