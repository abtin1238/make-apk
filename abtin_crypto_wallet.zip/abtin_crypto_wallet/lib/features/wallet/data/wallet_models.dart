/// Public wallet metadata. Never contains secrets.
class WalletMeta {
  const WalletMeta({
    required this.id,
    required this.name,
    required this.createdAtMs,
    required this.backedUp,
    required this.evmAddress,
  });

  final String id;
  final String name;
  final int createdAtMs;
  final bool backedUp;
  final String evmAddress;

  WalletMeta copyWith({String? name, bool? backedUp}) => WalletMeta(
        id: id,
        name: name ?? this.name,
        createdAtMs: createdAtMs,
        backedUp: backedUp ?? this.backedUp,
        evmAddress: evmAddress,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'createdAtMs': createdAtMs,
        'backedUp': backedUp,
        'evmAddress': evmAddress,
      };

  factory WalletMeta.fromJson(Map<String, dynamic> j) => WalletMeta(
        id: j['id'] as String,
        name: j['name'] as String,
        createdAtMs: j['createdAtMs'] as int,
        backedUp: j['backedUp'] as bool,
        evmAddress: j['evmAddress'] as String,
      );
}
