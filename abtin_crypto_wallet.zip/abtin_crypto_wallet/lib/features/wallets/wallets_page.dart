import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/l10n/app_strings.dart';
import '../../core/support_status.dart';
import '../../design_system/app_colors.dart';
import '../wallet/application/wallet_providers.dart';
import '../wallet/data/wallet_models.dart';
import '../wallet/presentation/wallet_widgets.dart';

class WalletsPage extends ConsumerWidget {
  const WalletsPage({super.key});

  Future<void> _rename(BuildContext context, WidgetRef ref, WalletMeta w) async {
    final s = AppStrings.of(context);
    final c = TextEditingController(text: w.name);
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.tr('rename')),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.tr('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: Text(s.tr('confirm'))),
        ],
      ),
    );
    c.dispose();
    if (name != null && name.isNotEmpty) {
      await ref.read(walletsProvider.notifier).rename(w.id, name);
    }
  }

  Future<void> _delete(BuildContext context, WidgetRef ref, WalletMeta w) async {
    final s = AppStrings.of(context);
    final sure = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(s.tr('delete')),
        content: Text(s.tr('deleteConfirm')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.tr('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(s.tr('delete'))),
        ],
      ),
    );
    if (sure != true || !context.mounted) return;
    if (await confirmWithPin(context, ref)) {
      await ref.read(walletsProvider.notifier).delete(w.id);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = AppStrings.of(context);
    final state = ref.watch(walletsProvider).valueOrNull;
    final t = Theme.of(context).textTheme;

    return Scaffold(
      appBar: AppBar(title: Text(s.wallets)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          for (final w in state?.wallets ?? const <WalletMeta>[])
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(
                w.id == state?.active?.id ? Icons.check_circle_rounded : Icons.circle_outlined,
                color: w.id == state?.active?.id ? AppColors.positive : null,
              ),
              title: Text(w.name),
              subtitle: Text(shortAddress(w.evmAddress)),
              onTap: () => ref.read(walletsProvider.notifier).setActive(w.id),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (!w.backedUp) const Icon(Icons.warning_amber_rounded, color: AppColors.warning),
                  PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'rename') {
                        await _rename(context, ref, w);
                      } else if (v == 'show') {
                        if (await confirmWithPin(context, ref) && context.mounted) {
                          context.go('/backup/${w.id}?reveal=1');
                        }
                      } else if (v == 'delete') {
                        await _delete(context, ref, w);
                      }
                    },
                    itemBuilder: (_) => [
                      PopupMenuItem(value: 'rename', child: Text(s.tr('rename'))),
                      PopupMenuItem(value: 'show', child: Text(s.tr('showPhrase'))),
                      PopupMenuItem(value: 'delete', child: Text(s.tr('delete'))),
                    ],
                  ),
                ],
              ),
            ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => context.push('/onboarding'),
            icon: const Icon(Icons.add_rounded),
            label: Text(s.tr('addWallet')),
          ),
          const SizedBox(height: 24),
          Text(s.networks, style: t.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          for (final n in NetworkRegistry.all)
            ListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(n.name),
              subtitle: Text(n.family),
              trailing: Text(
                s.status(n.status),
                style: TextStyle(
                  color: n.status == SupportStatus.notYetSupported ? AppColors.warning : AppColors.positive,
                  fontSize: 12,
                ),
              ),
            ),
        ],
      ),
    );
  }
}
