import 'package:flutter/material.dart';

import '../../core/l10n/app_strings.dart';
import '../../design_system/widgets/not_ready_card.dart';

class TradePage extends StatelessWidget {
  const TradePage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.trade)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [NotReadyCard(phase: 6, message: s.tradeBody)],
      ),
    );
  }
}
