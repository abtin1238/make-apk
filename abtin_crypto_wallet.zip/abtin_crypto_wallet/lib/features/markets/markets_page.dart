import 'package:flutter/material.dart';

import '../../core/l10n/app_strings.dart';
import '../../design_system/widgets/not_ready_card.dart';

class MarketsPage extends StatelessWidget {
  const MarketsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return Scaffold(
      appBar: AppBar(title: Text(s.markets)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [NotReadyCard(phase: 4, message: s.marketsBody)],
      ),
    );
  }
}
