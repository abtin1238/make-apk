import 'package:flutter/material.dart';

import '../../core/l10n/app_strings.dart';
import '../app_colors.dart';
import 'app_card.dart';

/// Honest placeholder for features that are not implemented yet.
class NotReadyCard extends StatelessWidget {
  const NotReadyCard({super.key, required this.phase, this.message});
  final int phase;
  final String? message;

  @override
  Widget build(BuildContext context) {
    final s = AppStrings.of(context);
    return AppCard(
      child: Column(
        children: [
          const Icon(Icons.construction_rounded, size: 36, color: AppColors.warning),
          const SizedBox(height: 12),
          Text(s.notReadyTitle,
              style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          if (message != null) ...[
            Text(message!, textAlign: TextAlign.center),
            const SizedBox(height: 8),
          ],
          Text(s.plannedInPhase(phase), textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

Future<void> showNotReady(BuildContext context, {required int phase}) {
  return showModalBottomSheet<void>(
    context: context,
    builder: (_) => Padding(
      padding: const EdgeInsets.all(16),
      child: NotReadyCard(phase: phase),
    ),
  );
}
