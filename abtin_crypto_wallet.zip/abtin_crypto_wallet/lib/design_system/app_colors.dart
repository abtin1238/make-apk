import 'package:flutter/material.dart';

class AppColors {
  AppColors._();
  static const bgDark = Color(0xFF0A0B1F);
  static const surfaceDark = Color(0xFF14162F);
  static const surfaceDark2 = Color(0xFF1C1F3D);
  static const bgLight = Color(0xFFF5F6FC);
  static const surfaceLight = Color(0xFFFFFFFF);
  static const primary = Color(0xFF6C4DFF);
  static const cyan = Color(0xFF22D3EE);
  static const pink = Color(0xFFFF4D9D);
  static const positive = Color(0xFF16C784);
  static const negative = Color(0xFFEA3943);
  static const warning = Color(0xFFF7931A);
  static const mutedDark = Color(0xFF9AA0C3);
  static const mutedLight = Color(0xFF6B7194);
}
