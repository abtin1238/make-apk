#!/usr/bin/env bash
# Generates android/ and ios/ (keeping lib/ and test/), then applies the security patches:
#  - Android: secure-screen MainActivity (FLAG_SECURE + FlutterFragmentActivity), allowBackup=false,
#    USE_BIOMETRIC permission, AppCompat launch theme (needed by local_auth)
#  - iOS: NSFaceIDUsageDescription
# Safe to run repeatedly. Needs bash, sed, python3 (Linux / macOS-with-GNU-sed / Git Bash).
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -d android ] || [ ! -d ios ]; then
  tmp="$(mktemp -d)"
  cp -r lib "$tmp/lib"; cp -r test "$tmp/test"
  flutter create . --platforms=android,ios --org com.abtin --project-name abtin_crypto_wallet
  rm -rf lib test
  cp -r "$tmp/lib" lib; cp -r "$tmp/test" test
fi

KT_DIR="android/app/src/main/kotlin/com/abtin/abtin_crypto_wallet"
MANIFEST="android/app/src/main/AndroidManifest.xml"
mkdir -p "$KT_DIR"
cp scripts/native/MainActivity.kt "$KT_DIR/MainActivity.kt"

grep -q 'android:allowBackup' "$MANIFEST" || \
  sed -i 's/<application/<application android:allowBackup="false"/' "$MANIFEST"
grep -q 'USE_BIOMETRIC' "$MANIFEST" || \
  sed -i 's#<application#<uses-permission android:name="android.permission.USE_BIOMETRIC"/>\n    <application#' "$MANIFEST"

for f in android/app/src/main/res/values/styles.xml android/app/src/main/res/values-night/styles.xml; do
  [ -f "$f" ] && sed -i -E 's#parent="@android:style/Theme\.(Light|Black)\.NoTitleBar"#parent="Theme.AppCompat.DayNight.NoActionBar"#' "$f"
done

PLIST="ios/Runner/Info.plist"
if [ -f "$PLIST" ] && ! grep -q NSFaceIDUsageDescription "$PLIST"; then
python3 - "$PLIST" <<'PY'
import sys
p = sys.argv[1]
s = open(p, encoding='utf-8').read()
add = "\t<key>NSFaceIDUsageDescription</key>\n\t<string>Unlock your wallet with Face ID.</string>\n"
i = s.rfind("</dict>")
open(p, 'w', encoding='utf-8').write(s[:i] + add + s[i:])
PY
fi

echo "Done. Now run: flutter pub get && flutter analyze && flutter test"
