import 'package:abtin_crypto_wallet/core/l10n/app_strings.dart';
import 'package:abtin_crypto_wallet/core/providers.dart';
import 'package:abtin_crypto_wallet/core/security/secure_store.dart';
import 'package:abtin_crypto_wallet/features/home/home_page.dart';
import 'package:abtin_crypto_wallet/features/wallets/wallets_page.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<Widget> _host(Widget child, {String lang = 'en'}) async {
  SharedPreferences.setMockInitialValues({});
  final prefs = await SharedPreferences.getInstance();
  return ProviderScope(
    overrides: [
      sharedPrefsProvider.overrideWithValue(prefs),
      secureStoreProvider.overrideWithValue(InMemorySecureStoreForTests()),
    ],
    child: MaterialApp(
      locale: Locale(lang),
      supportedLocales: AppStrings.supportedLocales,
      localizationsDelegates: const [
        AppStrings.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: child,
    ),
  );
}

void main() {
  testWidgets('home shows empty wallet state, no fake balance', (tester) async {
    await tester.pumpWidget(await _host(const HomePage()));
    await tester.pumpAndSettle();
    expect(find.text('Create wallet'), findsOneWidget);
    expect(find.text('—'), findsOneWidget);
    expect(find.textContaining(r'$'), findsNothing);
  });

  testWidgets('home works in Persian', (tester) async {
    await tester.pumpWidget(await _host(const HomePage(), lang: 'fa'));
    await tester.pumpAndSettle();
    expect(find.text('ساخت کیف پول'), findsOneWidget);
  });

  testWidgets('no network is shown as supported in phase 1', (tester) async {
    await tester.pumpWidget(await _host(const WalletsPage()));
    await tester.pumpAndSettle();
    expect(find.text('Not yet supported'), findsWidgets);
    expect(find.text('Fully supported'), findsNothing);
  });
}
