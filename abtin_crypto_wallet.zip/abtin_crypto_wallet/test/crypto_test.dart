import 'dart:typed_data';

import 'package:abtin_crypto_wallet/core/crypto/eth_address.dart';
import 'package:abtin_crypto_wallet/core/crypto/hd_wallet.dart';
import 'package:abtin_crypto_wallet/core/crypto/hex.dart';
import 'package:abtin_crypto_wallet/core/crypto/mnemonic_service.dart';
import 'package:abtin_crypto_wallet/core/crypto/vault_cipher.dart';
import 'package:flutter_test/flutter_test.dart';

const _abandon =
    'abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about';
const _junk = 'test test test test test test test test test test test junk';

void main() {
  group('BIP-39', () {
    test('official vector: seed with passphrase TREZOR', () {
      final seed = MnemonicService.toSeed(_abandon, passphrase: 'TREZOR');
      expect(
        toHex(seed),
        'c55257c360c07c72029aebc1b53c05ed0362ada38ead3e3e9efa3708e5349553'
        '1f09a6987599d18264c1e1c92f2cf141630c7a3c4ab7c81b2f001698e7463b04',
      );
    });

    test('generates valid 12 and 24 word phrases', () {
      final a = MnemonicService.generate(words: 12);
      final b = MnemonicService.generate(words: 24);
      expect(a.split(' ').length, 12);
      expect(b.split(' ').length, 24);
      expect(MnemonicService.isValid(a), isTrue);
      expect(MnemonicService.isValid(b), isTrue);
      expect(MnemonicService.generate(words: 12), isNot(a));
    });

    test('rejects bad checksum, bad length, unknown words', () {
      expect(MnemonicService.isValid('abandon ' * 11 + 'abandon'), isFalse);
      expect(MnemonicService.isValid('abandon abandon'), isFalse);
      expect(MnemonicService.isValid(''), isFalse);
      expect(MnemonicService.isValid('foo ' * 11 + 'bar'), isFalse);
    });

    test('normalizes whitespace and case', () {
      expect(MnemonicService.isValid('  ${_abandon.toUpperCase().replaceAll(' ', '   ')}  '), isTrue);
    });

    test('only 12 or 24 can be generated', () {
      expect(() => MnemonicService.generate(words: 15), throwsArgumentError);
    });
  });

  group('EVM derivation (m/44\'/60\'/0\'/0/n)', () {
    test('well-known test mnemonic gives known account 0', () {
      final acc = HdWallet.deriveEvm(_junk);
      expect(acc.address, '0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266');
      expect(acc.path, "m/44'/60'/0'/0/0");
      expect(
        toHex(HdWallet.evmPrivateKey(_junk)),
        'ac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80',
      );
    });

    test('account index 1', () {
      expect(HdWallet.deriveEvm(_junk, index: 1).address,
          '0x70997970C51812dc3A010C7d01b50e0d17dc79C8');
    });
  });

  group('Ethereum address helpers', () {
    test('keccak256 of empty input', () {
      expect(
        toHex(keccak256(Uint8List(0))),
        'c5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470',
      );
    });

    test('EIP-55 checksum validation', () {
      const good = '0x5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed';
      expect(isValidEthAddress(good), isTrue);
      expect(isValidEthAddress(good.toLowerCase()), isTrue);
      expect(isValidEthAddress('0x5AAeb6053F3E94C9b9A09f33669435E7Ef1BeAed'), isFalse);
      expect(isValidEthAddress('0x123'), isFalse);
      expect(isValidEthAddress('5aAeb6053F3E94C9b9A09f33669435E7Ef1BeAed'), isFalse);
    });
  });

  group('VaultCipher', () {
    final key = VaultCipher.randomBytes(32);

    test('round trip', () {
      final pt = Uint8List.fromList([1, 2, 3, 4, 5]);
      final blob = VaultCipher.encrypt(key, pt);
      expect(VaultCipher.decrypt(key, blob), pt);
    });

    test('nonce is random: same plaintext gives different blobs', () {
      final pt = Uint8List.fromList([9, 9, 9]);
      expect(VaultCipher.encrypt(key, pt), isNot(VaultCipher.encrypt(key, pt)));
    });

    test('wrong key, wrong aad and tampering are rejected', () {
      final aad = Uint8List.fromList([7]);
      final blob = VaultCipher.encrypt(key, Uint8List.fromList([1, 2, 3]), aad: aad);
      expect(() => VaultCipher.decrypt(VaultCipher.randomBytes(32), blob, aad: aad),
          throwsA(isA<VaultAuthException>()));
      expect(() => VaultCipher.decrypt(key, blob, aad: Uint8List.fromList([8])),
          throwsA(isA<VaultAuthException>()));
      final tampered = blob.substring(0, blob.length - 4) + (blob.endsWith('AAAA') ? 'BBBB' : 'AAAA');
      expect(() => VaultCipher.decrypt(key, tampered, aad: aad), throwsA(isA<VaultAuthException>()));
      expect(() => VaultCipher.decrypt(key, 'not base64!!'), throwsA(isA<VaultAuthException>()));
    });

    test('PBKDF2 is deterministic and salt dependent', () {
      final salt = Uint8List.fromList(List.generate(16, (i) => i));
      final a = VaultCipher.deriveKey('123456', salt, 1000);
      expect(a, VaultCipher.deriveKey('123456', salt, 1000));
      expect(a, isNot(VaultCipher.deriveKey('123457', salt, 1000)));
      expect(a, isNot(VaultCipher.deriveKey('123456', Uint8List(16), 1000)));
      expect(a.length, 32);
    });
  });
}
