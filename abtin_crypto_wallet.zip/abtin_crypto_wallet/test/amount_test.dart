import 'package:abtin_crypto_wallet/core/money/amount.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('parse and print', () {
    final a = Amount.parse('1.5', decimals: 8);
    expect(a.raw, BigInt.from(150000000));
    expect(a.toPlainString(), '1.5');
    expect(Amount.parse('100', decimals: 6).toPlainString(), '100');
    expect(Amount.parse('0.000001', decimals: 6).toPlainString(), '0.000001');
  });

  test('0.1 + 0.2 is exactly 0.3', () {
    final sum = Amount.parse('0.1', decimals: 18) + Amount.parse('0.2', decimals: 18);
    expect(sum, Amount.parse('0.3', decimals: 18));
  });

  test('negative values', () {
    final a = Amount.parse('1', decimals: 2) - Amount.parse('2.5', decimals: 2);
    expect(a.toPlainString(), '-1.5');
    expect(a.isNegative, isTrue);
  });

  test('rejects bad input', () {
    expect(() => Amount.parse('1.123', decimals: 2), throwsFormatException);
    expect(() => Amount.parse('abc', decimals: 2), throwsFormatException);
    expect(() => Amount.parse('1e5', decimals: 2), throwsFormatException);
    expect(() => Amount.parse('', decimals: 2), throwsFormatException);
  });

  test('decimals mismatch throws', () {
    expect(
      () => Amount.parse('1', decimals: 2) + Amount.parse('1', decimals: 3),
      throwsArgumentError,
    );
  });
}
