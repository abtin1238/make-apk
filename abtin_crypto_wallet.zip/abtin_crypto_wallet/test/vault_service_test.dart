import 'dart:typed_data';

import 'package:abtin_crypto_wallet/core/crypto/vault_cipher.dart';
import 'package:abtin_crypto_wallet/core/security/secure_store.dart';
import 'package:abtin_crypto_wallet/features/wallet/data/biometric_auth.dart';
import 'package:abtin_crypto_wallet/features/wallet/data/vault_service.dart';
import 'package:flutter_test/flutter_test.dart';

const _junk = 'test test test test test test test test test test test junk';
const _pin = '483915';

class FakeBiometric implements BiometricAuth {
  bool available = true;
  bool accept = true;
  @override
  Future<bool> isAvailable() async => available;
  @override
  Future<bool> authenticate(String reason) async => accept;
}

Future<Uint8List> _fastKdf(String s, Uint8List salt, int it) async =>
    VaultCipher.deriveKey(s, salt, it);

void main() {
  late InMemorySecureStoreForTests store;
  late FakeBiometric bio;
  late DateTime now;
  late VaultService svc;

  VaultService make() => VaultService(
        store: store,
        biometric: bio,
        kdfIterations: 1000,
        kdf: _fastKdf,
        clock: () => now,
      );

  setUp(() {
    store = InMemorySecureStoreForTests();
    bio = FakeBiometric();
    now = DateTime(2026, 1, 1);
    svc = make();
  });

  group('PIN policy', () {
    test('accepts and rejects', () {
      expect(PinPolicy.check(_pin), PinCheck.ok);
      expect(PinPolicy.check('12345'), PinCheck.invalid);
      expect(PinPolicy.check('12345a'), PinCheck.invalid);
      expect(PinPolicy.check('111111'), PinCheck.weak);
      expect(PinPolicy.check('123456'), PinCheck.weak);
    });
  });

  group('PIN and lock', () {
    test('setup unlocks, lock locks, correct PIN unlocks again', () async {
      expect(await svc.hasPin(), isFalse);
      await svc.setupPin(_pin);
      expect(await svc.hasPin(), isTrue);
      expect(svc.isUnlocked, isTrue);
      svc.lock();
      expect(svc.isUnlocked, isFalse);
      await svc.unlockWithPin(_pin);
      expect(svc.isUnlocked, isTrue);
    });

    test('weak PIN and second setup are refused', () async {
      expect(() => svc.setupPin('111111'), throwsArgumentError);
      await svc.setupPin(_pin);
      expect(() => svc.setupPin('582913'), throwsStateError);
    });

    test('wrong PIN counts attempts, then locks out with backoff', () async {
      await svc.setupPin(_pin);
      svc.lock();
      for (final left in [4, 3, 2, 1]) {
        await expectLater(
          svc.unlockWithPin('000001'),
          throwsA(isA<WrongPinException>().having((e) => e.attemptsLeft, 'left', left)),
        );
      }
      await expectLater(svc.unlockWithPin('000001'), throwsA(isA<LockedOutException>()));
      // Even the correct PIN is refused while locked out.
      await expectLater(svc.unlockWithPin(_pin), throwsA(isA<LockedOutException>()));
      expect(svc.isUnlocked, isFalse);
      now = now.add(const Duration(seconds: 31));
      await svc.unlockWithPin(_pin);
      expect(svc.isUnlocked, isTrue);
    });

    test('lockout survives a new service instance (persisted)', () async {
      await svc.setupPin(_pin);
      svc.lock();
      for (var i = 0; i < 5; i++) {
        try {
          await svc.unlockWithPin('000001');
        } catch (_) {}
      }
      final other = make();
      await expectLater(other.unlockWithPin(_pin), throwsA(isA<LockedOutException>()));
    });

    test('changePin', () async {
      await svc.setupPin(_pin);
      await svc.changePin(_pin, '908172');
      svc.lock();
      await expectLater(svc.unlockWithPin(_pin), throwsA(isA<WrongPinException>()));
      await svc.unlockWithPin('908172');
      expect(svc.isUnlocked, isTrue);
    });

    test('verifyPin does not change lock state', () async {
      await svc.setupPin(_pin);
      svc.lock();
      await svc.verifyPin(_pin);
      expect(svc.isUnlocked, isFalse);
    });
  });

  group('wallets', () {
    test('add, read back, persist across instances', () async {
      await svc.setupPin(_pin);
      final meta = await svc.addWallet(name: 'Main', mnemonic: _junk, backedUp: false);
      expect(meta.evmAddress, '0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266');
      expect(await svc.readMnemonic(meta.id), _junk);

      final other = make();
      expect((await other.listWallets()).single.name, 'Main');
      await other.unlockWithPin(_pin);
      expect(await other.readMnemonic(meta.id), _junk);
    });

    test('recovery phrase is never stored in plaintext', () async {
      await svc.setupPin(_pin);
      await svc.addWallet(name: 'Main', mnemonic: _junk, backedUp: false);
      expect(store.dump.values.any((v) => v.contains('test test')), isFalse);
      expect(store.dump.values.any((v) => v.contains('junk')), isFalse);
    });

    test('locked vault cannot add or read', () async {
      await svc.setupPin(_pin);
      final meta = await svc.addWallet(name: 'Main', mnemonic: _junk, backedUp: true);
      svc.lock();
      expect(() => svc.readMnemonic(meta.id), throwsA(isA<VaultLockedException>()));
      expect(() => svc.addWallet(name: 'x', mnemonic: _junk, backedUp: true),
          throwsA(isA<VaultLockedException>()));
    });

    test('duplicate and invalid mnemonics are refused', () async {
      await svc.setupPin(_pin);
      await svc.addWallet(name: 'A', mnemonic: _junk, backedUp: true);
      expect(() => svc.addWallet(name: 'B', mnemonic: _junk.toUpperCase(), backedUp: true),
          throwsA(isA<DuplicateWalletException>()));
      expect(() => svc.addWallet(name: 'C', mnemonic: 'abandon abandon', backedUp: true),
          throwsArgumentError);
    });

    test('rename, backup flag, active id, delete', () async {
      await svc.setupPin(_pin);
      final m = await svc.addWallet(name: 'A', mnemonic: _junk, backedUp: false);
      await svc.setActiveId(m.id);
      await svc.renameWallet(m.id, 'Renamed');
      await svc.markBackedUp(m.id);
      final w = (await svc.listWallets()).single;
      expect(w.name, 'Renamed');
      expect(w.backedUp, isTrue);
      expect(await svc.getActiveId(), m.id);

      await svc.deleteWallet(m.id);
      expect(await svc.listWallets(), isEmpty);
      expect(await svc.getActiveId(), isNull);
      expect(store.dump.keys.any((k) => k.startsWith('vault.seed.')), isFalse);
    });
  });

  group('biometrics', () {
    test('enable then unlock', () async {
      await svc.setupPin(_pin);
      await svc.enableBiometric();
      expect(await svc.isBiometricEnabled(), isTrue);
      svc.lock();
      expect(await svc.unlockWithBiometric(), isTrue);
      expect(svc.isUnlocked, isTrue);
    });

    test('rejected prompt does not unlock; unavailable cannot enable', () async {
      await svc.setupPin(_pin);
      await svc.enableBiometric();
      svc.lock();
      bio.accept = false;
      expect(await svc.unlockWithBiometric(), isFalse);
      expect(svc.isUnlocked, isFalse);

      await svc.disableBiometric();
      await svc.unlockWithPin(_pin);
      bio.available = false;
      await expectLater(svc.enableBiometric(), throwsA(isA<BiometricUnavailableException>()));
    });

    test('biometric still works after a PIN change', () async {
      await svc.setupPin(_pin);
      await svc.enableBiometric();
      await svc.changePin(_pin, '908172');
      svc.lock();
      expect(await svc.unlockWithBiometric(), isTrue);
    });
  });
}
