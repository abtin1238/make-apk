import 'package:abtin_crypto_wallet/core/l10n/app_strings.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('Persian and English have exactly the same keys', () {
    expect(AppStrings.faKeys, equals(AppStrings.enKeys));
  });
}
