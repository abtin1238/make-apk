import 'package:abtin_crypto_wallet/core/logging/secure_logger.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('redacts BIP-39 style phrase', () {
    const phrase =
        'abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon abandon about';
    final out = SecureLogger.redact('created wallet $phrase ok');
    expect(out.contains('abandon'), isFalse);
    expect(out.contains('[REDACTED_PHRASE]'), isTrue);
  });

  test('redacts 64 hex private keys', () {
    final key = 'a' * 64;
    expect(SecureLogger.redact('key $key').contains(key), isFalse);
    expect(SecureLogger.redact('key 0x$key').contains(key), isFalse);
  });

  test('redacts key=value secrets', () {
    final out = SecureLogger.redact('password: hunter2 and PIN=1234');
    expect(out.contains('hunter2'), isFalse);
    expect(out.contains('1234'), isFalse);
  });

  test('leaves normal text', () {
    expect(SecureLogger.redact('balance loaded'), 'balance loaded');
  });

  test('log goes through redaction', () {
    final lines = <String>[];
    SecureLogger.sink = lines.add;
    SecureLogger.log('wallet', 'seed: secretword');
    expect(lines.single.contains('secretword'), isFalse);
  });
}
