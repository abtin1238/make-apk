# Abtin Crypto Wallet — status and remaining work

## Verified in this handoff
- [x] Flutter Android/iOS platform folders generated from the stable Flutter template.
- [x] Android manifest hardening applied: backups disabled, biometric permission, secure-screen `MainActivity`, and AppCompat launch theme.
- [x] iOS Face ID usage description added by the bootstrap script.
- [x] Dependency resolution and `flutter analyze` completed. Analysis reports informational deprecation notices from the latest Flutter stable SDK, but no analyzer errors.
- [x] All 42 tests pass after fixing the test-only Persian locale configuration with the missing Cupertino localization delegate.
- [ ] Android APK build not verified: this environment has no Android SDK/NDK configured.
- [ ] Native iOS build not verified: requires macOS/Xcode.
- [ ] Biometric flows and secure-screen behavior need real-device verification.

## Current product boundary — not production-ready; do not use with real funds
- [x] BIP-39 wallet phrase generation/import and EVM address derivation.
- [x] PIN-protected encrypted local vault, multi-wallet metadata, phrase backup verification, and basic biometric prompt gating.
- [ ] Chain adapters: balances, token discovery, fee/gas estimation, transaction validation/signing/broadcast, confirmations and explorer links.
- [ ] Live market-data provider, portfolio pricing, charts and stale-data handling.
- [ ] Exchange connection: no exchange is selected and there is no account authorization, order execution or transfer flow.
- [ ] Swap, buy/sell/on-ramp, bridge, WalletConnect, DeFi, NFTs and dApp browser.
- [ ] Threat model, independent cryptographic review, recovery/backup review, production monitoring, compliance assessment and release hardening.

## Exchange integration prerequisites
1. Choose the exchange and specify read-only portfolio, trading, or deposit/withdrawal use cases.
2. Prefer OAuth or a backend-mediated connection; never ship exchange secrets or wallet seed/private keys in the mobile app.
3. Start with read-only scope. Do not enable withdrawals. Add explicit transaction/order review, rate limits, revocation, audit logging without secrets, and clear risk disclosures before any order capability.
4. Review the exchange terms, applicable jurisdiction/compliance, key storage, incident response, and threat model before production.

The app intentionally displays no invented prices/balances and reports every chain unsupported until a real adapter is implemented and verified.
