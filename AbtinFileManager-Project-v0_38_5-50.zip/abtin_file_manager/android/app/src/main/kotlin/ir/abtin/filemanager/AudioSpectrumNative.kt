package ir.abtin.filemanager

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Works on EVERY phone: instead of tapping the audio output (android.media.audiofx.Visualizer, which many
 * vendors block and which needs the microphone permission) the track file is decoded once with MediaCodec
 * and a spectrum (BANDS log-spaced bands, FPS frames per second, one byte each) is computed. Dart then simply
 * reads the frame that matches the player position. No audio is recorded, no permission is needed.
 */
class AudioSpectrumNative(messenger: BinaryMessenger) {
    private val main = Handler(Looper.getMainLooper())

    companion object {
        const val FPS = 30
        const val BANDS = 40
        private const val N = 2048
        private const val MAX_SECONDS = 60 * 60
    }

    init {
        MethodChannel(messenger, "abtin/audio_spec").setMethodCallHandler { call, result ->
            if (call.method != "analyze") {
                result.notImplemented()
                return@setMethodCallHandler
            }
            val path = call.argument<String>("path")
            if (path == null) {
                result.error("args", "path is required", null)
                return@setMethodCallHandler
            }
            Thread {
                try {
                    val data = analyze(path)
                    main.post { result.success(mapOf("fps" to FPS, "bands" to BANDS, "data" to data)) }
                } catch (e: Throwable) {
                    main.post { result.error("analyze", e.message ?: "analysis failed", null) }
                }
            }.start()
        }
    }

    private val window = FloatArray(N) { i -> (0.5 - 0.5 * cos(2.0 * PI * i / (N - 1))).toFloat() }
    private val cosT = FloatArray(N / 2) { i -> cos(2.0 * PI * i / N).toFloat() }
    private val sinT = FloatArray(N / 2) { i -> (-sin(2.0 * PI * i / N)).toFloat() }
    private val rev = IntArray(N).also { r ->
        val bits = 31 - Integer.numberOfLeadingZeros(N)
        for (i in 0 until N) r[i] = Integer.reverse(i) ushr (32 - bits)
    }

    private fun fft(re: FloatArray, im: FloatArray) {
        for (i in 0 until N) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var size = 2
        while (size <= N) {
            val half = size / 2
            val step = N / size
            var start = 0
            while (start < N) {
                var k = 0
                for (j in start until start + half) {
                    val wr = cosT[k]
                    val wi = sinT[k]
                    val xr = re[j + half] * wr - im[j + half] * wi
                    val xi = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - xr
                    im[j + half] = im[j] - xi
                    re[j] += xr
                    im[j] += xi
                    k += step
                }
                start += size
            }
            size *= 2
        }
    }

    private fun analyze(path: String): ByteArray {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            extractor.setDataSource(path)
            var track = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) {
                    track = i
                    format = f
                    break
                }
            }
            if (track < 0 || format == null) throw IllegalStateException("no audio track")
            if (format.containsKey(MediaFormat.KEY_DURATION) && format.getLong(MediaFormat.KEY_DURATION) / 1_000_000L > MAX_SECONDS) {
                throw IllegalStateException("track too long")
            }
            extractor.selectTrack(track)
            val mime = format.getString(MediaFormat.KEY_MIME)!!
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(format, null, null, 0)
            c.start()

            var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            if (channels < 1) channels = 1

            val out = ByteArrayOutputStream(1 shl 18)
            val ring = FloatArray(N)
            var ringPos = 0
            var total = 0L
            var nextFrameAt = N.toLong()
            val re = FloatArray(N)
            val im = FloatArray(N)
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            val frame = ByteArray(BANDS)

            while (!outputDone) {
                if (!inputDone) {
                    val inIdx = c.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val buf = c.getInputBuffer(inIdx)!!
                        val n = extractor.readSampleData(buf, 0)
                        if (n < 0) {
                            c.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            c.queueInputBuffer(inIdx, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = c.dequeueOutputBuffer(info, 10_000)
                if (outIdx >= 0) {
                    if (info.size > 0) {
                        val ob = c.getOutputBuffer(outIdx)!!
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        val sb = ob.slice().order(ByteOrder.nativeOrder()).asShortBuffer()
                        val frames = sb.remaining() / channels
                        val hop = max(1, sampleRate / FPS)
                        for (f in 0 until frames) {
                            var sum = 0f
                            for (ch in 0 until channels) sum += sb.get()
                            ring[ringPos] = sum / channels / 32768f
                            ringPos = (ringPos + 1) % N
                            total++
                            if (total >= nextFrameAt) {
                                nextFrameAt += hop
                                for (i in 0 until N) {
                                    re[i] = ring[(ringPos + i) % N] * window[i]
                                    im[i] = 0f
                                }
                                fft(re, im)
                                bands(re, im, sampleRate, frame)
                                out.write(frame, 0, BANDS)
                            }
                        }
                    }
                    c.releaseOutputBuffer(outIdx, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = c.outputFormat
                    if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = max(1, nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT))
                }
            }
            val bytes = out.toByteArray()
            if (bytes.isEmpty()) throw IllegalStateException("empty analysis")
            return bytes
        } finally {
            try { codec?.stop() } catch (_: Throwable) { }
            try { codec?.release() } catch (_: Throwable) { }
            try { extractor.release() } catch (_: Throwable) { }
        }
    }

    /** Peak magnitude of each log-spaced band -> 0..255 (dB scaled, with a gentle treble tilt). */
    private fun bands(re: FloatArray, im: FloatArray, sampleRate: Int, dst: ByteArray) {
        val nyq = sampleRate / 2.0
        val fLo = 45.0
        val fHi = min(15000.0, nyq * 0.95)
        val ratio = fHi / fLo
        val binHz = sampleRate.toDouble() / N
        for (b in 0 until BANDS) {
            val f0 = fLo * ratio.pow(b.toDouble() / BANDS)
            val f1 = fLo * ratio.pow((b + 1).toDouble() / BANDS)
            val b0 = max(1, (f0 / binHz).toInt())
            val b1 = min(N / 2 - 1, max(b0 + 1, Math.ceil(f1 / binHz).toInt()))
            var peak = 0.0
            for (k in b0..b1) {
                val m = sqrt((re[k] * re[k] + im[k] * im[k]).toDouble())
                if (m > peak) peak = m
            }
            val mag = peak / (N / 4.0)
            val fc = sqrt(f0 * f1)
            val db = 20.0 * log10(mag + 1e-6) + 3.0 * (ln(fc / 1000.0) / ln(2.0))
            val v = ((db + 62.0) / 52.0).coerceIn(0.0, 1.0)
            dst[b] = (v * 255.0).toInt().toByte()
        }
    }
}
