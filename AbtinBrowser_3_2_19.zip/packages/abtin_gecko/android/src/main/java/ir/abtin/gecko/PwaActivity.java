package ir.abtin.gecko;

import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;

import androidx.core.content.ContextCompat;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import org.json.JSONObject;
import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.BasicSelectionActionDelegate;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.WebRequestError;
import org.mozilla.geckoview.WebResponse;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.HashSet;
import java.util.Set;

/**
 * An installed web app (PWA): a screen of its own, in its own task (its own entry in Recents), exactly like a Chrome / Firefox
 * web app. It shares the browser's GeckoRuntime/profile so OAuth, cookies, passkeys and site storage
 * remain continuous, while retaining its own Android task and no browser chrome. Links outside the app
 * are handed to the browser except recognized identity-provider flows.
 */
public final class PwaActivity extends FragmentActivity {
    private static final String TAG = "AbtinPwa";

    private Engine e;
    private GeckoView gv;
    private GeckoSession session;
    private FrameLayout root;
    private View bar;
    private String startUrl = "";
    private String curUrl = "";
    private boolean canGoBack;
    private boolean fullscreen;
    private int barColor;
    private boolean pageColor; // the page told us its own colour: the manifest colour no longer overrides it
    private boolean loaded;
    private final Set<String> declinedLoginHosts = new HashSet<>();
    private static final int VPN_PERMISSION_REQUEST = 0x5A21;
    private static final int DNS_PERMISSION_REQUEST = 0x5A22;
    private static final String VPN_ACTION_START = "ir.abtin.abtin_browser.v2ray.START";
    private static final String VPN_ACTION_STOP = "ir.abtin.abtin_browser.v2ray.STOP";
    private static final String VPN_ACTION_QUERY = "ir.abtin.abtin_browser.v2ray.QUERY";
    private static final String VPN_ACTION_EVENT = "ir.abtin.abtin_browser.v2ray.EVENT";
    private static final String VPN_CONFIG_FILE = "v2ray_active.json";
    private static final String VPN_SERVICE_CLASS = "ir.abtin.abtin_browser.v2ray.V2rayVpnService";
    private static final String DNS_ACTION_START = "ir.abtin.abtin_browser.DNS_START";
    private static final String DNS_ACTION_STOP = "ir.abtin.abtin_browser.DNS_STOP";
    private static final String DNS_ACTION_EVENT = "ir.abtin.abtin_browser.DNS_EVENT";
    private static final String DNS_SERVICE_CLASS = "ir.abtin.abtin_browser.dns.DnsVpnService";
    private TextView vpnChip;
    private TextView dnsChip;
    private LinearLayout quickControlsBar;
    private View stripBg;          // the strip above the page (holds the DNS / VPN buttons): same colour as the web app's top
    private int stripColor;
    private String dnsState = "disconnected";
    private Intent pendingDnsStart;
    private boolean dnsReceiverRegistered;
    private final BroadcastReceiver dnsReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null || !"state".equals(intent.getStringExtra("type"))) return;
            dnsState = intent.getBooleanExtra("on", false) ? "connected" : "disconnected";
            runOnUiThread(() -> { updateDnsChip(); routeMaybeChanged(); });
        }
    };
    private String lastRouteKey = null;
    private final long createdAt = android.os.SystemClock.elapsedRealtime();
    private long stoppedAt;
    private final Runnable routeReload = () -> {
        // Gecko keeps its open sockets / DNS answers: a tunnel or DNS change only reaches the page after it reconnects.
        try { if (session != null && session.isOpen() && loaded) session.reload(); } catch (Throwable t) { Log.w(TAG, "route reload", t); }
    };
    /** Called on every VPN / DNS state event: when the route really changed (on <-> off), reload the page through the new route. */
    private void routeMaybeChanged() {
        final String key = ("connected".equals(vpnState) ? "v" : "-") + (("connected".equals(dnsState) || isPwaDnsOn()) ? "d" : "-");
        // right after launch the first answers only tell the starting state: that is a baseline, not a change
        if (!vpnKnown && android.os.SystemClock.elapsedRealtime() - createdAt < 2500L) { lastRouteKey = null; return; }
        if (lastRouteKey == null && vpnKnown && android.os.SystemClock.elapsedRealtime() - createdAt < 2500L) { lastRouteKey = key; return; }
        final String prev = lastRouteKey;
        lastRouteKey = key;
        if (prev == null || prev.equals(key) || !loaded) return;
        ui.removeCallbacks(routeReload);
        ui.postDelayed(routeReload, 900L); // let the new network settle first
    }
    private String vpnState = "disconnected";
    private boolean vpnKnown;      // the VPN service answered at least once since this activity started
    private Runnable vpnWait;      // first page load, waiting for that answer when a full-traffic VPN is up

    /** The SOCKS port the browser's VPN core listens on (the Flutter side stores it; 10808 is the core's default). */
    private int vpnSocksPort() {
        try {
            final Object v = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE).getAll().get("flutter.v2_socks");
            if (v instanceof Number && ((Number) v).intValue() > 0) return ((Number) v).intValue();
        } catch (Throwable ignored) { }
        return 10808;
    }

    /** Runs [r] now, or - when a VPN is active on the phone but the tunnel state is not known yet - as soon as it is (max 1.5 s). */
    private void whenVpnKnown(final Runnable r) {
        if (vpnKnown || e == null || !e.vpnActive) { r.run(); return; }
        final boolean[] done = {false};
        final Runnable once = () -> { if (done[0]) return; done[0] = true; r.run(); };
        vpnWait = once;
        ui.postDelayed(once, 1500L);
    }
    private Intent pendingVpnStart;
    private boolean vpnReceiverRegistered;
    private final BroadcastReceiver vpnReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            final String type = intent.getStringExtra("type");
            if ("state".equals(type)) {
                vpnState = intent.getStringExtra("state") == null ? "disconnected" : intent.getStringExtra("state");
                vpnKnown = true;
                // The web app has no Flutter side to tell Gecko about the tunnel: route its traffic through the core's SOCKS inbound
                // while connected, and back to direct otherwise. "connecting" keeps the previous route.
                if (e != null && ("connected".equals(vpnState) || "disconnected".equals(vpnState) || "error".equals(vpnState))) {
                    e.setProxyPort("connected".equals(vpnState) ? vpnSocksPort() : 0);
                }
                runOnUiThread(() -> { updateVpnChip(); routeMaybeChanged(); });
                if (vpnWait != null) { final Runnable w = vpnWait; vpnWait = null; ui.removeCallbacks(w); ui.post(w); }
            } else if ("ping".equals(type)) {
                final String id = intent.getStringExtra("id");
                final long ms = intent.getLongExtra("ms", -1L);
                if (id != null && !id.isEmpty()) {
                    try {
                        final android.content.SharedPreferences prefs = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE);
                        final JSONObject cache = new JSONObject(prefs.getString("flutter.v2_ping_cache", "{}"));
                        cache.put(id, (int) Math.max(-1L, Math.min(Integer.MAX_VALUE, ms)));
                        prefs.edit().putString("flutter.v2_ping_cache", cache.toString()).apply();
                    } catch (Throwable t) { Log.w(TAG, "save PWA ping", t); }
                }
            }
        }
    };

    /** Dialog builder in the app's own dark / light look (the web app used to get the bare system dialog). */
    private AlertDialog.Builder dialog() {
        final int theme = e != null && e.dark ? android.R.style.Theme_DeviceDefault_Dialog_Alert : android.R.style.Theme_DeviceDefault_Light_Dialog_Alert;
        return new AlertDialog.Builder(this, theme);
    }

    private static String humanSize(long b) {
        if (b <= 0) return "";
        final String[] u = {"B", "KB", "MB", "GB"};
        double v = b; int i = 0;
        while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
        return String.format(Locale.US, i == 0 ? "%.0f %s" : "%.1f %s", v, u[i]);
    }

    private boolean fa() { return e != null && "fa".equals(e.lang); }
    private String tr(String f, String en) { return fa() ? f : en; }

    private void hideKeyboardAfterLoginAutofill() {
        final Runnable hide = () -> {
            if (gv == null || gv.getWindowToken() == null) return;
            try {
                final InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(gv.getWindowToken(), 0);
            } catch (Throwable ignored) { }
        };
        final android.os.Handler main = new android.os.Handler(android.os.Looper.getMainLooper());
        main.post(hide);
        main.postDelayed(hide, 100L);
        main.postDelayed(hide, 300L);
    }

    @Override
    protected void onCreate(@Nullable android.os.Bundle b) {
        super.onCreate(b);
        e = Engine.get(this);
        e.ensureRuntime();

        final Uri d = getIntent() == null ? null : getIntent().getData();
        if (d == null || d.getScheme() == null || !d.getScheme().toLowerCase(Locale.ROOT).startsWith("http")) { finish(); return; }
        startUrl = d.toString();
        curUrl = startUrl;
        final String title = getIntent().getStringExtra("abtin_title");
        setLabel(title != null && !title.isEmpty() ? title : d.getHost());

        barColor = e.dark ? 0xFF111318 : 0xFFFFFFFF;
        // the colour this web app had last time: no white flash in the notch area while the page loads
        try {
            final int saved = getSharedPreferences("abtin_pwa_colors", MODE_PRIVATE).getInt(String.valueOf(d.getHost()), 0);
            if (saved != 0) barColor = saved;
        } catch (Throwable ignored) { }
        getWindow().setBackgroundDrawable(new ColorDrawable(barColor));
        // Edge-to-edge: the app's own root view (painted with the page colour) sits under the status bar, the camera cut-out and the
        // navigation bar, so the notch area is never the system's white / black; the insets below keep the page itself clear of them.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        // Paint the notch / camera cut-out area (also the side strips in landscape) with the app colour instead of
        // leaving it white or black, and keep the system from tinting the bars with its own contrast scrim.
        if (Build.VERSION.SDK_INT >= 28) {
            final android.view.WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                    ? android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().setStatusBarContrastEnforced(false);
            getWindow().setNavigationBarContrastEnforced(false);
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(barColor);
        // PWA-only independent DNS and VPN buttons. There is no toolbar/strip and the web
        // content keeps its full viewport; the two small controls float separately at top-right.
        gv = new GeckoView(this);
        // Keep Android Autofill enabled in installed PWAs. Google Password Manager and
        // Android Credential Provider need this surface for password/passkey sign-in.
        Engine.allowSystemAutofill(gv);
        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        // Reserve a dedicated safe strip for the two controls; web content starts below it.
        webLp.topMargin = dp(42);
        root.addView(gv, webLp);
        stripBg = new View(this);
        stripColor = barColor;
        try {
            final int sv = getSharedPreferences("abtin_pwa_colors", MODE_PRIVATE).getInt(d.getHost() + "#bg", 0);
            if (sv != 0) stripColor = sv;
        } catch (Throwable ignored) { }
        stripBg.setBackgroundColor(stripColor);
        root.addView(stripBg, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42), Gravity.TOP));

        // Dedicated safe strip: controls never float over page content or cover page actions.
        quickControlsBar = new LinearLayout(this);
        quickControlsBar.setOrientation(LinearLayout.HORIZONTAL);
        quickControlsBar.setGravity(Gravity.CENTER);
        quickControlsBar.setBackgroundColor(Color.TRANSPARENT);
        quickControlsBar.setClipToPadding(false);
        quickControlsBar.setClipChildren(false);
        FrameLayout.LayoutParams controlsLp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(34), Gravity.TOP | Gravity.END);
        controlsLp.setMargins(0, dp(8), dp(8), 0);
        root.addView(quickControlsBar, controlsLp);

        dnsChip = createQuickChip();
        dnsChip.setText("◈");
        dnsChip.setOnClickListener(v -> togglePwaDns());
        dnsChip.setOnLongClickListener(v -> { showPwaDnsPicker(); return true; });
        LinearLayout.LayoutParams dnsChipLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(28));
        dnsChipLp.setMargins(dp(4), 0, dp(4), 0);
        quickControlsBar.addView(dnsChip, dnsChipLp);

        vpnChip = createQuickChip();
        vpnChip.setText("⚿");
        vpnChip.setOnClickListener(v -> togglePwaVpn());
        vpnChip.setOnLongClickListener(v -> { showPwaVpnPicker(); return true; });
        LinearLayout.LayoutParams vpnChipLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(28));
        vpnChipLp.setMargins(dp(4), 0, dp(4), 0);
        quickControlsBar.addView(vpnChip, vpnChipLp);

        bar = new View(this);
        bar.setBackgroundColor(e.accent);
        bar.setVisibility(View.GONE);
        FrameLayout.LayoutParams progressLp = new FrameLayout.LayoutParams(0, dp(2), Gravity.TOP | Gravity.START);
        root.addView(bar, progressLp);
        updateVpnChip();
        updateDnsChip();
        setContentView(root);
        // Edge-to-edge devices draw under the system bars: keep the page clear of them (and above the keyboard).
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            final Insets sb = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            final Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(sb.left, fullscreen ? 0 : sb.top, sb.right, fullscreen ? ime.bottom : Math.max(sb.bottom, ime.bottom));
            return insets;
        });
        applyBarColor(barColor);
        try {
            ContextCompat.registerReceiver(this, vpnReceiver, new IntentFilter(VPN_ACTION_EVENT), ContextCompat.RECEIVER_NOT_EXPORTED);
            vpnReceiverRegistered = true;
            ContextCompat.registerReceiver(this, dnsReceiver, new IntentFilter(DNS_ACTION_EVENT), ContextCompat.RECEIVER_NOT_EXPORTED);
            dnsReceiverRegistered = true;
            sendBroadcast(new Intent(VPN_ACTION_QUERY).setPackage(getPackageName()));
            refreshDnsState();
        } catch (Throwable t) { Log.w(TAG, "VPN status receiver", t); }

        // Back: on Android 13+ the system only calls an OnBackInvokedCallback (onBackPressed is skipped, and on newer
        // releases the opt-out is ignored, which made Back close the web app at once). Older versions use onBackPressed.
        if (Build.VERSION.SDK_INT >= 33) {
            backCb = this::handleBack;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCb);
        }

        final GeckoSessionSettings.Builder sb = new GeckoSessionSettings.Builder()
                .usePrivateMode(false)
                .suspendMediaWhenInactive(false) // calls / voice messages keep playing when the app is in the background
                .userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
                .viewportMode(GeckoSessionSettings.VIEWPORT_MODE_MOBILE);
        { final String ua = e.effectiveUa(false, Engine.hostOf(startUrl)); if (!ua.isEmpty()) sb.userAgentOverride(ua); }
        // An installed web app runs in "standalone" display mode: (display-mode: standalone) matches, so sites show their app
        // screens (login, inbox...) and not the "download the app" / "open in browser" landing page they show browsers.
        try {
            final int standalone = GeckoSessionSettings.class.getField("DISPLAY_MODE_STANDALONE").getInt(null);
            sb.getClass().getMethod("displayMode", int.class).invoke(sb, standalone);
        } catch (Throwable t) { Log.w(TAG, "displayMode", t); }
        session = new GeckoSession(sb.build());
        session.setProgressDelegate(progress);
        session.setNavigationDelegate(navigation);
        session.setContentDelegate(content);
        session.setPermissionDelegate(permission);
        session.setPromptDelegate(new PwaPrompts());
        session.setSelectionActionDelegate(new BasicSelectionActionDelegate(this));
        session.open(e.runtime);
        gv.setSession(session);
        session.setActive(true);
        // The first page load waits for the built-in core extension (same rule as the browser's tabs).
        e.whenCoreReady(() -> whenLaidOut(() -> whenVpnKnown(() -> {
            if (!loaded && session != null) {
                loaded = true;
                if (e.extensions != null) e.extensions.wireSession(session, contentMsgs);
                session.loadUri(startUrl);
            }
        })));
    }

    /**
     * Runs [r] once the web view has a real size (and the window insets were applied). A page that starts loading while the view is still 0 px
     * wide measures its sliders / grids with a zero width: cards end up stacked on top of each other and parts of the page stay empty.
     * Normal tabs never hit this because they are shown long after layout; a web app starts loading right at launch.
     */
    private void whenLaidOut(final Runnable r) {
        final boolean[] done = {false};
        final Runnable once = () -> { if (done[0]) return; done[0] = true; r.run(); };
        if (gv == null) { once.run(); return; }
        if (gv.getWidth() > 0 && gv.getHeight() > 0 && gv.isLaidOut()) { ui.post(once); return; }
        gv.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int rr, int b, int ol, int ot, int or, int ob) {
                if (v.getWidth() > 0 && v.getHeight() > 0) {
                    v.removeOnLayoutChangeListener(this);
                    ui.post(once);
                }
            }
        });
        ui.postDelayed(once, 1500L); // never wait forever
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Same site opened again (shortcut tapped while running): this task is simply brought to the front.
        setIntent(intent);
    }

    @Override protected void onResume() {
        super.onResume();
        if (e != null) {
            e.pwaActivity = this;
            sendBroadcast(new Intent(VPN_ACTION_QUERY).setPackage(getPackageName()));
            refreshDnsState();
            routeMaybeChanged();
            // a login code may have arrived while the user was in the SMS app
            ui.postDelayed(() -> { if (e != null && e.pwaActivity == this) e.smsOtp.pushForeground(); }, 500);
        }
    }

    /** An SMS login code for the page on screen (see SmsOtp). */
    void deliverOtp(JSONObject j) {
        if (cport == null) return;
        try { cport.postMessage(j); } catch (Throwable t) { Log.w(TAG, "otp", t); }
    }

    @Override protected void onPause() {
        if (e != null && e.pwaActivity == this) e.pwaActivity = null;
        super.onPause();
    }

    @Override protected void onStop() {
        stoppedAt = android.os.SystemClock.elapsedRealtime();
        super.onStop();
    }

    @Override protected void onStart() {
        super.onStart();
        // After a while in the background Android drops the web view's drawing surface (and may kill Gecko's content process):
        // the page then comes back as a black rectangle. Attach the session again and make sure it is awake and painted.
        if (stoppedAt != 0 && loaded && session != null) {
            final long away = android.os.SystemClock.elapsedRealtime() - stoppedAt;
            stoppedAt = 0;
            revive(away);
        }
    }

    private void revive(final long awayMs) {
        try {
            if (!session.isOpen()) {
                session.open(e.runtime);
                gv.releaseSession();
                gv.setSession(session);
                session.setActive(true);
                session.loadUri(curUrl == null || curUrl.isEmpty() ? startUrl : curUrl);
                return;
            }
            if (awayMs > 15_000L) {
                gv.releaseSession();
                gv.setSession(session);
            }
            session.setActive(true);
            try { gv.coverUntilFirstPaint(barColor); } catch (Throwable ignored) { }
            gv.requestLayout();
            gv.invalidate();
            gv.requestFocus();
            // Still blank 1.5 s later (content process was gone without a callback)? Then check the pixels and reload.
            ui.postDelayed(() -> checkBlank(awayMs), 1500L);
        } catch (Throwable t) { Log.e(TAG, "revive", t); }
    }

    private void checkBlank(final long awayMs) {
        if (gv == null || session == null || isFinishing() || isDestroyed()) return;
        try {
            gv.capturePixels().accept(bmp -> {
                if (bmp == null) return;
                boolean blank = true;
                final int w = bmp.getWidth(), h = bmp.getHeight();
                final int first = bmp.getPixel(w / 2, h / 2);
                // sample a grid: a black frame has every sample (nearly) black and identical
                for (int yi = 1; yi < 6 && blank; yi++)
                    for (int xi = 1; xi < 6; xi++) {
                        final int p = bmp.getPixel(w * xi / 6, h * yi / 6);
                        if (p != first || (p & 0x00FFFFFF) != 0) { blank = false; break; }
                    }
                if (blank) runOnUiThread(() -> {
                    try {
                        if (session == null || isFinishing()) return;
                        gv.releaseSession();
                        gv.setSession(session);
                        session.setActive(true);
                        session.reload();
                    } catch (Throwable t) { Log.w(TAG, "blank reload", t); }
                });
            });
        } catch (Throwable t) { Log.w(TAG, "checkBlank", t); }
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33 && backCb != null) {
            try { getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCb); } catch (Throwable ignored) { }
            backCb = null;
        }
        if (e != null && e.pwaActivity == this) e.pwaActivity = null;
        if (vpnReceiverRegistered) { try { unregisterReceiver(vpnReceiver); } catch (Throwable ignored) { } vpnReceiverRegistered = false; }
        if (dnsReceiverRegistered) { try { unregisterReceiver(dnsReceiver); } catch (Throwable ignored) { } dnsReceiverRegistered = false; }
        try { closePopup(); } catch (Throwable ignored) { }
        try {
            if (gv != null && gv.getSession() != null) gv.releaseSession();
            if (session != null && session.isOpen()) session.close();
        } catch (Throwable t) { Log.w(TAG, "close", t); }
        session = null;
        super.onDestroy();
    }

    private android.window.OnBackInvokedCallback backCb;

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() { handleBack(); }

    private void handleBack() {
        if (popup != null) {
            if (popupCanGoBack) { try { popup.goBack(); } catch (Throwable t) { closePopup(); } } else closePopup();
            return;
        }
        if (fullscreen && session != null) { session.exitFullScreen(); return; }
        if (canGoBack && session != null) { session.goBack(); return; }
        // No page history left: chat web apps keep their screens in-page. Ask the page's content script to close the open
        // chat / dialog (Escape + a visible back/close button); only when it did nothing does the double-Back exit apply.
        if (cport != null) {
            final int id = ++backId;
            try {
                cport.postMessage(new JSONObject().put("cmd", "back").put("id", id));
                backTimeout = () -> { backTimeout = null; if (backId == id) exitOnDoubleBack(); };
                ui.postDelayed(backTimeout, 1200);
                return;
            } catch (Throwable t) { Log.w(TAG, "back msg", t); }
        }
        exitOnDoubleBack();
    }

    private void exitOnDoubleBack() {
        final long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastBackAt < 2000) { finish(); return; }
        lastBackAt = now;
        Engine.sendEscape(gv);
        Toast.makeText(this, tr("برای خروج، دوباره بازگشت را بزنید", "Press back again to exit"), Toast.LENGTH_SHORT).show();
    }

    private long lastBackAt;
    private int backId;
    private Runnable backTimeout;
    private org.mozilla.geckoview.WebExtension.Port cport;
    private final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());

    private final org.mozilla.geckoview.WebExtension.MessageDelegate contentMsgs = new org.mozilla.geckoview.WebExtension.MessageDelegate() {
        @Override public void onConnect(@NonNull final org.mozilla.geckoview.WebExtension.Port port) {
            if (!port.sender.isTopLevel()) return;
            cport = port;
            try { port.postMessage(new JSONObject().put("cmd", "pcOn").put("on", true)); } catch (Throwable ignored) { }
            port.setDelegate(new org.mozilla.geckoview.WebExtension.PortDelegate() {
                @Override public void onPortMessage(@NonNull Object message, @NonNull org.mozilla.geckoview.WebExtension.Port p) {
                    if (!(message instanceof JSONObject)) return;
                    final JSONObject j = (JSONObject) message;
                    final String type = j.optString("t");
                    if ("otpField".equals(type)) { e.smsOtp.onField(p); return; }
                    if ("otpUsed".equals(type)) { e.smsOtp.clear(); return; }
                    if ("pwaColor".equals(type)) {
                        final Integer pc = cssColor(j.optString("c", null));
                        if (pc != null) {
                            pageColor = true;
                            final int col = pc | 0xFF000000;
                            // a sign-in page (Google...) must not overwrite the colour remembered for the app itself
                            if (inScope(curUrl)) { try { getSharedPreferences("abtin_pwa_colors", MODE_PRIVATE).edit().putInt(String.valueOf(Uri.parse(startUrl).getHost()), col).apply(); } catch (Throwable ignored) { } }
                            runOnUiThread(() -> applyBarColor(col));
                        }
                        final Integer bgc = cssColor(j.optString("bg", null));
                        if (bgc != null) {
                            final int sc = bgc | 0xFF000000;
                            if (inScope(curUrl)) { try { getSharedPreferences("abtin_pwa_colors", MODE_PRIVATE).edit().putInt(Uri.parse(startUrl).getHost() + "#bg", sc).apply(); } catch (Throwable ignored) { } }
                            runOnUiThread(() -> applyStripColor(sc));
                        }
                        return;
                    }
                    if (!"backDone".equals(type)) return;
                    final int id = j.optInt("id", -1);
                    final boolean handled = j.optBoolean("handled", false);
                    runOnUiThread(() -> {
                        if (id != backId) return;
                        if (backTimeout != null) { ui.removeCallbacks(backTimeout); backTimeout = null; }
                        if (!handled) exitOnDoubleBack();
                    });
                }
                @Override public void onDisconnect(@NonNull org.mozilla.geckoview.WebExtension.Port p) { if (cport == p) cport = null; }
            });
        }
    };

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == VPN_PERMISSION_REQUEST) {
            Intent start = pendingVpnStart;
            pendingVpnStart = null;
            if (res == RESULT_OK && start != null) {
                try { ContextCompat.startForegroundService(this, start); vpnState = "connecting"; updateVpnChip(); }
                catch (Throwable t) { Toast.makeText(this, tr("شروع VPN ناموفق بود", "Could not start VPN"), Toast.LENGTH_LONG).show(); }
            } else {
                Toast.makeText(this, tr("مجوز VPN داده نشد", "VPN permission was denied"), Toast.LENGTH_SHORT).show();
            }
            return;
        }
        if (req == DNS_PERMISSION_REQUEST) {
            Intent start = pendingDnsStart;
            pendingDnsStart = null;
            if (res == RESULT_OK && start != null) {
                try { ContextCompat.startForegroundService(this, start); dnsState = "connecting"; updateDnsChip(); }
                catch (Throwable t) { Toast.makeText(this, tr("شروع DNS ناموفق بود", "Could not start DNS"), Toast.LENGTH_LONG).show(); }
            } else {
                Toast.makeText(this, tr("مجوز DNS داده نشد", "DNS permission was denied"), Toast.LENGTH_SHORT).show();
            }
            return;
        }
        if (e == null || !e.onActivityResult(req, res, data)) super.onActivityResult(req, res, data);
    }

    @Override
    public void onRequestPermissionsResult(int req, @NonNull String[] perms, @NonNull int[] results) {
        if (e == null || !e.onPermissionsResult(req, perms, results)) super.onRequestPermissionsResult(req, perms, results);
    }

    // ------------------------------------------------------------------ PWA VPN quick control

    private TextView createQuickChip() {
        TextView chip = new TextView(this);
        chip.setTextSize(18f);
        chip.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        chip.setTextColor(Color.WHITE);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(0, 0, 0, 0);
        chip.setMinWidth(dp(36));
        chip.setElevation(dp(1));
        chip.setIncludeFontPadding(false);
        return chip;
    }

    private void styleQuickChip(TextView chip, boolean on, boolean busy) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(on ? 0xCC176B48 : busy ? 0xCC765318 : 0x88343A46);
        bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), on ? 0xFF55C994 : busy ? 0xFFD5A64A : 0x667F8998);
        chip.setBackground(bg);
        chip.setEnabled(!busy);
        chip.setAlpha(busy ? .8f : 1f);
    }

    private void updateVpnChip() {
        if (vpnChip == null) return;
        final boolean on = "connected".equals(vpnState);
        final boolean busy = "connecting".equals(vpnState);
        vpnChip.setText("⚿");
        vpnChip.setContentDescription(on
                ? tr("VPN متصل؛ لمس برای قطع، لمس طولانی برای انتخاب کانفیگ", "VPN connected; tap to disconnect, long press for configs")
                : busy ? tr("VPN در حال اتصال", "VPN connecting") : tr("VPN خاموش؛ لمس برای اتصال، لمس طولانی برای انتخاب کانفیگ", "VPN off; tap to connect, long press for configs"));
        styleQuickChip(vpnChip, on, busy);
    }

    private JSONObject readPwaVpnConfigs() {
        try {
            final android.content.SharedPreferences prefs = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE);
            return new JSONObject(prefs.getString("flutter.v2_pwa_configs_v1", "{}"));
        } catch (Throwable t) { return new JSONObject(); }
    }

    private void showPwaVpnPicker() {
        final android.content.SharedPreferences prefs = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE);
        final String raw = prefs.getString("flutter.v2_profiles_v1", "[]");
        final JSONObject compiled = readPwaVpnConfigs();
        final java.util.ArrayList<String> names = new java.util.ArrayList<>();
        final java.util.ArrayList<String> ids = new java.util.ArrayList<>();
        JSONObject cache;
        try { cache = new JSONObject(prefs.getString("flutter.v2_ping_cache", "{}")); }
        catch (Throwable ignored) { cache = new JSONObject(); }
        try {
            final org.json.JSONArray profiles = new org.json.JSONArray(raw == null ? "[]" : raw);
            for (int i = 0; i < profiles.length(); i++) {
                final JSONObject item = profiles.optJSONObject(i);
                if (item == null) continue;
                final String id = item.optString("id", "");
                final String name = item.optString("name", "").trim();
                final JSONObject ready = compiled.optJSONObject(id);
                if (id.isEmpty() || name.isEmpty() || ready == null || ready.optString("config", "").isEmpty()) continue;
                ids.add(id);
                final int ping = cache.optInt(id, Integer.MIN_VALUE);
                names.add(ping == Integer.MIN_VALUE ? name + " · تست نشده" : ping < 0 ? name + " · ناموفق" : name + " · " + ping + " ms");
            }
        } catch (Throwable t) { Log.w(TAG, "read VPN profiles", t); }
        if (names.isEmpty()) {
            dialog().setTitle(tr("کانفیگ VPN", "VPN configs"))
                    .setMessage(tr("کانفیگی برای استفاده در PWA آماده نیست. مدیریت VPN مرورگر را یک‌بار باز کن.", "No PWA-ready VPN configs. Open the browser VPN manager once."))
                    .setPositiveButton(tr("باشه", "OK"), null).show();
            return;
        }
        final String selected = prefs.getString("flutter.v2_sel", "");
        final int[] chosen = {Math.max(0, ids.indexOf(selected))};
        final AlertDialog picker = dialog().setTitle(tr("کانفیگ‌های VPN", "VPN configurations"))
                .setSingleChoiceItems(names.toArray(new CharSequence[0]), chosen[0], (d, which) -> chosen[0] = which)
                .setPositiveButton(tr("اتصال", "Connect"), (d, which) -> startPwaVpn(ids.get(chosen[0])))
                .setNeutralButton(tr("تست پینگ", "Test ping"), (d, which) -> testPwaVpnPing(ids.get(chosen[0])))
                .setNegativeButton(tr("بستن", "Close"), null).create();
        picker.show();
    }

    private void testPwaVpnPing(String profileId) {
        final JSONObject profile = readPwaVpnConfigs().optJSONObject(profileId);
        if (profile == null) return;
        final String config = profile.optString("testConfig", "");
        if (config.isEmpty()) {
            Toast.makeText(this, tr("تست پینگ برای این کانفیگ ممکن نیست", "Ping test is unavailable for this config"), Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            final String safeId = profileId.replaceAll("[^A-Za-z0-9_-]", "");
            final File file = new File(getFilesDir(), "v2ray_test_pwa_" + safeId + "_" + android.os.SystemClock.elapsedRealtimeNanos() + ".json");
            try (FileOutputStream out = new FileOutputStream(file, false)) {
                out.write(config.getBytes(java.nio.charset.StandardCharsets.UTF_8));
            }
            final Intent test = new Intent().setClassName(getPackageName(), "ir.abtin.abtin_browser.v2ray.V2rayTestService")
                    .putExtra("id", profileId).putExtra("path", file.getAbsolutePath())
                    .putExtra("url", getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE).getString("flutter.v2TestUrl", "https://www.gstatic.com/generate_204"));
            startService(test);
            Toast.makeText(this, tr("تست پینگ واقعی شروع شد؛ نتیجه را با باز کردن دوبارهٔ فهرست ببین", "Real ping test started; reopen this list to see the result"), Toast.LENGTH_LONG).show();
        } catch (Throwable t) {
            Log.w(TAG, "PWA ping test", t);
            Toast.makeText(this, tr("شروع تست پینگ ناموفق بود", "Could not start ping test"), Toast.LENGTH_SHORT).show();
        }
    }

    private void startPwaVpn(String profileId) {
        if ("connecting".equals(vpnState)) return;
        final android.content.SharedPreferences prefs = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE);
        final JSONObject compiled = readPwaVpnConfigs();
        final JSONObject profile = compiled.optJSONObject(profileId);
        if (profile == null) {
            Toast.makeText(this, tr("اطلاعات اتصال این کانفیگ آماده نیست؛ مدیریت VPN مرورگر را یک‌بار باز کن", "This profile is not prepared yet; open the browser VPN manager once"), Toast.LENGTH_LONG).show();
            return;
        }
        final String config = profile.optString("config", "");
        if (config.isEmpty()) return;
        try {
            if (isPwaDnsOn()) {
                try { startService(new Intent(DNS_ACTION_STOP).setClassName(getPackageName(), DNS_SERVICE_CLASS)); } catch (Throwable ignored) { }
                dnsState = "disconnected";
                updateDnsChip();
            }
            final File configFile = new File(getFilesDir(), VPN_CONFIG_FILE);
            try (java.io.FileOutputStream out = new java.io.FileOutputStream(configFile, false)) {
                out.write(config.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                out.flush();
            }
            prefs.edit().putString("flutter.v2_sel", profileId).apply();
            final Intent start = new Intent(VPN_ACTION_START).setClassName(getPackageName(), VPN_SERVICE_CLASS)
                    .putExtra("name", profile.optString("name", "VPN"))
                    .putExtra("mtu", profile.optInt("mtu", 1500))
                    .putExtra("ipv6", profile.optBoolean("ipv6", true))
                    .putExtra("bypassLan", profile.optBoolean("bypassLan", true))
                    .putExtra("bypassIranIp", profile.optBoolean("bypassIranIp", true))
                    .putExtra("dns", profile.optString("dns", "8.8.8.8,8.8.4.4"))
                    .putExtra("skip", getSharedPreferences("v2ray_keepalive", MODE_PRIVATE).getString("skip", ""));
            final Intent prepare = VpnService.prepare(this);
            if (prepare != null) {
                pendingVpnStart = start;
                startActivityForResult(prepare, VPN_PERMISSION_REQUEST);
            } else {
                ContextCompat.startForegroundService(this, start);
                vpnState = "connecting";
                updateVpnChip();
            }
        } catch (Throwable t) {
            Log.w(TAG, "PWA VPN profile start", t);
            Toast.makeText(this, tr("اتصال این کانفیگ ناموفق بود", "Could not connect this profile"), Toast.LENGTH_LONG).show();
        }
    }

    private void togglePwaVpn() {
        if ("connecting".equals(vpnState)) return;
        if ("connected".equals(vpnState)) {
            sendBroadcast(new Intent(VPN_ACTION_STOP).setPackage(getPackageName()));
            vpnState = "disconnected";
            updateVpnChip();
            return;
        }
        final android.content.SharedPreferences prefs = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE);
        final String selected = prefs.getString("flutter.v2_sel", "");
        if (selected == null || selected.isEmpty()) {
            Toast.makeText(this, tr("ابتدا یک کانفیگ را با لمس طولانی انتخاب کن", "Long-press VPN and select a config first"), Toast.LENGTH_LONG).show();
            showPwaVpnPicker();
            return;
        }
        startPwaVpn(selected);
    }

    private void refreshDnsState() {
        try {
            final android.content.SharedPreferences state = getSharedPreferences("abtin_dns_runtime", MODE_PRIVATE);
            dnsState = state.getBoolean("on", false) ? "connected" : "disconnected";
        } catch (Throwable ignored) { dnsState = "disconnected"; }
        updateDnsChip();
    }

    private boolean isPwaDnsOn() {
        try { return getSharedPreferences("abtin_dns_runtime", MODE_PRIVATE).getBoolean("on", false); }
        catch (Throwable ignored) { return "connected".equals(dnsState); }
    }

    private void updateDnsChip() {
        if (dnsChip == null) return;
        final boolean on = "connected".equals(dnsState) || isPwaDnsOn();
        final boolean busy = "connecting".equals(dnsState);
        dnsChip.setText("◈");
        dnsChip.setContentDescription(busy ? tr("DNS در حال اتصال", "DNS connecting")
                : on ? tr("DNS روشن؛ لمس طولانی برای تنظیم", "DNS on; long press to configure")
                : tr("DNS خاموش؛ لمس طولانی برای تنظیم", "DNS off; long press to configure"));
        styleQuickChip(dnsChip, on, busy);
    }

    private JSONObject loadFlutterSettings() {
        try {
            final String raw = getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE)
                    .getString("flutter.settings_v2", "{}");
            return new JSONObject(raw == null ? "{}" : raw);
        } catch (Throwable ignored) { return new JSONObject(); }
    }

    private void saveFlutterSettings(JSONObject settings) {
        try {
            getSharedPreferences("FlutterSharedPreferences", MODE_PRIVATE).edit()
                    .putString("flutter.settings_v2", settings.toString()).apply();
        } catch (Throwable t) { Log.w(TAG, "save DNS selection", t); }
    }

    private String selectedDnsId() {
        return loadFlutterSettings().optString("dnsPreset", "shecan");
    }

    private String selectedDnsName() {
        final String id = selectedDnsId();
        if (id.startsWith("c:")) return id.substring(2);
        final String[][] names = {
            {"shecan","شکن","Shecan"},{"electro","الکترو","Electro"},{"radar","رادار","Radar"},
            {"403","403.online","403.online"},{"begzar","بگذر","Begzar"},{"google","گوگل","Google"},
            {"cloudflare","کلودفلر","Cloudflare"},{"cf_mal","کلودفلر ضدبدافزار","Cloudflare Malware"},
            {"cf_fam","کلودفلر خانواده","Cloudflare Family"},{"quad9","Quad9","Quad9"},
            {"opendns","OpenDNS","OpenDNS"},{"opendns_fam","OpenDNS خانواده","OpenDNS Family"},
            {"adguard","AdGuard","AdGuard"},{"adguard_fam","AdGuard خانواده","AdGuard Family"},
            {"cira","CIRA","CIRA"},{"cira_fam","CIRA خانواده","CIRA Family"},
            {"cleanb_sec","CleanBrowsing","CleanBrowsing"},{"cleanb_fam","CleanBrowsing Family","CleanBrowsing Family"},
            {"comodo","Comodo","Comodo"},{"controld","Control D","Control D"},
            {"controld_fam","Control D Family","Control D Family"},{"dnsfamily","DNS Family","DNS Family"},
            {"dnssb","DNS.SB","DNS.SB"},{"dnswatch","DNS.Watch","DNS.Watch"},
            {"fdn","FDN","FDN"},{"level3","Level3","Level3"},{"neustar","Neustar","Neustar"},
            {"neustar_fam","Neustar Family","Neustar Family"},{"neustar_safe","Neustar Safe","Neustar Safe"},
            {"safedns","SafeDNS","SafeDNS"},{"yandex","Yandex","Yandex"},{"yandex_safe","Yandex Safe","Yandex Safe"},
            {"yandex_fam","Yandex Family","Yandex Family"}
        };
        for (String[] n : names) if (n[0].equals(id)) return fa() ? n[1] : n[2];
        return fa() ? "شکن" : "Shecan";
    }

    private org.json.JSONArray readDnsCustoms(JSONObject settings) {
        try {
            final Object raw = settings.opt("dnsCustoms");
            if (raw instanceof org.json.JSONArray) return (org.json.JSONArray) raw;
            if (raw instanceof String) return new org.json.JSONArray((String) raw);
        } catch (Throwable t) { Log.w(TAG, "read custom DNS list", t); }
        return new org.json.JSONArray();
    }

    private String[] selectedDnsServers() {
        final JSONObject settings = loadFlutterSettings();
        String id = settings.optString("dnsPreset", "shecan");
        if (id.startsWith("c:")) {
            try {
                final org.json.JSONArray customs = readDnsCustoms(settings);
                for (int i = 0; i < customs.length(); i++) {
                    final JSONObject item = customs.optJSONObject(i);
                    if (item != null && id.substring(2).equals(item.optString("n"))) {
                        return validDnsServers(item.optString("s", ""));
                    }
                }
            } catch (Throwable ignored) { }
        }
        final String[][] presets = {
            {"shecan","178.22.122.100,185.51.200.2"},{"electro","78.157.42.100,78.157.42.101"},
            {"radar","10.202.10.10,10.202.10.11"},{"403","10.202.10.202,10.202.10.102"},
            {"begzar","185.55.226.26,185.55.225.25"},{"google","8.8.8.8,8.8.4.4"},
            {"cloudflare","1.1.1.1,1.0.0.1"},{"cf_mal","1.1.1.2,1.0.0.2"},
            {"cf_fam","1.1.1.3,1.0.0.3"},{"quad9","9.9.9.9,149.112.112.112"},
            {"opendns","208.67.222.222,208.67.220.220"},{"opendns_fam","208.67.222.123,208.67.220.123"},
            {"adguard","94.140.14.14,94.140.15.15"},{"adguard_fam","94.140.14.15,94.140.15.16"},
            {"cira","149.112.121.10,149.112.122.10"},{"cira_fam","149.112.121.30,149.112.122.30"},
            {"cleanb_sec","185.228.168.9,185.228.169.9"},{"cleanb_fam","185.228.168.168,185.228.169.168"},
            {"comodo","8.26.56.26,8.20.247.20"},{"controld","76.76.2.0,76.76.10.0"},
            {"controld_fam","76.76.2.4,76.76.10.4"},{"dnsfamily","94.130.180.225,78.47.64.161"},
            {"dnssb","185.222.222.222,45.11.45.11"},{"dnswatch","84.200.69.80,84.200.70.40"},
            {"fdn","80.67.169.12,80.67.169.40"},{"level3","4.2.2.1,4.2.2.2"},
            {"neustar","156.154.70.1,156.154.71.1"},{"neustar_fam","156.154.70.3,156.154.71.3"},
            {"neustar_safe","156.154.70.2,156.154.71.2"},{"safedns","195.46.39.39,195.46.39.40"},
            {"yandex","77.88.8.8,77.88.8.1"},{"yandex_safe","77.88.8.88,77.88.8.2"},
            {"yandex_fam","77.88.8.7,77.88.8.3"}
        };
        for (String[] item : presets) if (item[0].equals(id)) return validDnsServers(item[1]);
        return validDnsServers("178.22.122.100,185.51.200.2");
    }

    private String[] validDnsServers(String raw) {
        final java.util.ArrayList<String> out = new java.util.ArrayList<>();
        for (String ip : raw.split("[,;\\s]+")) {
            if (ip.matches("(?:[0-9]{1,3}\\.){3}[0-9]{1,3}")) {
                boolean valid = true;
                for (String part : ip.split("\\.")) if (Integer.parseInt(part) > 255) valid = false;
                if (valid) out.add(ip);
            }
        }
        return out.toArray(new String[0]);
    }

    private void togglePwaDns() {
        if ("connecting".equals(dnsState)) return;
        if (isPwaDnsOn()) {
            try { startService(new Intent(DNS_ACTION_STOP).setClassName(getPackageName(), DNS_SERVICE_CLASS)); }
            catch (Throwable t) { Log.w(TAG, "stop DNS", t); }
            dnsState = "disconnected";
            updateDnsChip();
            return;
        }
        if ("connected".equals(vpnState) || "connecting".equals(vpnState)) {
            Toast.makeText(this, tr("ابتدا VPN را خاموش کنید؛ DNS و VPN هم‌زمان قابل اجرا نیستند", "Turn off VPN first; DNS and VPN cannot run simultaneously"), Toast.LENGTH_LONG).show();
            return;
        }
        final String[] servers = selectedDnsServers();
        if (servers.length == 0) {
            Toast.makeText(this, tr("سرور DNS معتبر نیست", "No valid DNS server is selected"), Toast.LENGTH_LONG).show();
            return;
        }
        final Intent start = new Intent(DNS_ACTION_START).setClassName(getPackageName(), DNS_SERVICE_CLASS)
                .putExtra("servers", android.text.TextUtils.join(",", servers));
        try {
            final Intent prepare = VpnService.prepare(this);
            if (prepare != null) { pendingDnsStart = start; startActivityForResult(prepare, DNS_PERMISSION_REQUEST); }
            else { ContextCompat.startForegroundService(this, start); dnsState = "connecting"; updateDnsChip(); }
        } catch (Throwable t) {
            Log.w(TAG, "PWA DNS start", t);
            Toast.makeText(this, tr("شروع DNS ممکن نشد", "Could not start DNS"), Toast.LENGTH_LONG).show();
        }
    }

    private void showPwaDnsPicker() {
        final String[][] options = {
            {"shecan","شکن","Shecan"},{"electro","الکترو","Electro"},{"radar","رادار گیم","Radar Game"},
            {"403","403.online","403.online"},{"begzar","بگذر","Begzar"},{"google","گوگل","Google DNS"},
            {"cloudflare","کلودفلر","Cloudflare"},{"cf_mal","کلودفلر ضدبدافزار","Cloudflare Malware"},
            {"cf_fam","کلودفلر خانواده","Cloudflare Family"},{"quad9","Quad9","Quad9"},
            {"opendns","OpenDNS","OpenDNS"},{"opendns_fam","OpenDNS خانواده","OpenDNS Family"},
            {"adguard","AdGuard","AdGuard"},{"adguard_fam","AdGuard خانواده","AdGuard Family"},
            {"cira","CIRA","CIRA"},{"cira_fam","CIRA خانواده","CIRA Family"},
            {"cleanb_sec","CleanBrowsing امنیتی","CleanBrowsing Security"},
            {"cleanb_fam","CleanBrowsing خانواده","CleanBrowsing Family"},
            {"comodo","Comodo","Comodo"},{"controld","Control D","Control D"},
            {"controld_fam","Control D خانواده","Control D Family"},{"dnsfamily","DNS Family","DNS Family"},
            {"dnssb","DNS.SB","DNS.SB"},{"dnswatch","DNS.Watch","DNS.Watch"},
            {"fdn","FDN","FDN"},{"level3","Level3","Level3"},
            {"neustar","Neustar","Neustar"},{"neustar_fam","Neustar خانواده","Neustar Family"},
            {"neustar_safe","Neustar امن","Neustar Safe"},{"safedns","SafeDNS","SafeDNS"},
            {"yandex","Yandex","Yandex"},{"yandex_safe","Yandex امن","Yandex Safe"},
            {"yandex_fam","Yandex خانواده","Yandex Family"}
        };
        final JSONObject settings = loadFlutterSettings();
        final String current = settings.optString("dnsPreset", "shecan");
        final java.util.ArrayList<String> ids = new java.util.ArrayList<>();
        final java.util.ArrayList<CharSequence> labels = new java.util.ArrayList<>();
        int selected = 0;
        for (String[] option : options) {
            if (option[0].equals(current)) selected = ids.size();
            ids.add(option[0]);
            labels.add(fa() ? option[1] : option[2]);
        }
        try {
            final org.json.JSONArray customs = readDnsCustoms(settings);
            for (int i = 0; i < customs.length(); i++) {
                final JSONObject item = customs.optJSONObject(i);
                if (item == null) continue;
                final String name = item.optString("n", "").trim();
                if (name.isEmpty()) continue;
                final String id = "c:" + name;
                if (id.equals(current)) selected = ids.size();
                ids.add(id);
                labels.add(name + " · " + item.optString("s", ""));
            }
        } catch (Throwable ignored) { }
        final CharSequence[] items = labels.toArray(new CharSequence[0]);
        dialog().setTitle(tr("انتخاب سرور DNS", "Choose DNS server"))
                .setSingleChoiceItems(items, selected, (d, which) -> {
                    try {
                        settings.put("dnsPreset", ids.get(which));
                        saveFlutterSettings(settings);
                        if (isPwaDnsOn()) {
                            try { startService(new Intent(DNS_ACTION_STOP).setClassName(getPackageName(), DNS_SERVICE_CLASS)); } catch (Throwable ignored) { }
                            dnsState = "disconnected";
                            updateDnsChip();
                            d.dismiss();
                            ui.postDelayed(this::togglePwaDns, 250L);
                        } else {
                            updateDnsChip();
                            d.dismiss();
                        }
                    } catch (Throwable t) { Log.w(TAG, "select DNS", t); d.dismiss(); }
                }).setNegativeButton(tr("بستن", "Close"), null).show();
    }

    // ------------------------------------------------------------------ look

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @SuppressWarnings("deprecation")
    private void setLabel(String label) {
        try { setTaskDescription(new ActivityManager.TaskDescription(label == null || label.isEmpty() ? null : label)); } catch (Throwable ignored) { }
    }

    private void applyStripColor(int color) {
        stripColor = color;
        if (stripBg != null) stripBg.setBackgroundColor(color);
        updateVpnChip();
        updateDnsChip();
    }

    private void applyBarColor(int color) {
        barColor = color;
        root.setBackgroundColor(color);
        getWindow().setBackgroundDrawable(new ColorDrawable(color));
        try {
            getWindow().setStatusBarColor(color);
            getWindow().setNavigationBarColor(color);
            getWindow().getDecorView().setBackgroundColor(color);
        } catch (Throwable ignored) { }
        final boolean light = androidx.core.graphics.ColorUtils.calculateLuminance(color) > 0.5;
        final WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), root);
        if (c != null) {
            c.setAppearanceLightStatusBars(light);
            c.setAppearanceLightNavigationBars(light);
        }
    }

    private void setFullscreen(boolean on) {
        fullscreen = on;
        if (quickControlsBar != null) quickControlsBar.setVisibility(on ? View.GONE : View.VISIBLE);
        if (stripBg != null) stripBg.setVisibility(on ? View.GONE : View.VISIBLE);
        // The PWA content always uses the full viewport; the independent buttons are an overlay.
        if (gv != null) {
            FrameLayout.LayoutParams webLp = (FrameLayout.LayoutParams) gv.getLayoutParams();
            webLp.topMargin = on ? 0 : dp(42);
            gv.setLayoutParams(webLp);
        }
        if (bar != null) {
            FrameLayout.LayoutParams progressLp = (FrameLayout.LayoutParams) bar.getLayoutParams();
            progressLp.topMargin = 0;
            bar.setLayoutParams(progressLp);
        }
        final WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), root);
        if (c != null) {
            if (on) {
                c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsetsCompat.Type.systemBars());
            } else {
                c.show(WindowInsetsCompat.Type.systemBars());
            }
        }
        root.requestApplyInsets();
    }

    @Nullable
    private static Integer cssColor(@Nullable String s) {
        if (s == null || s.trim().isEmpty()) return null;
        try { return Color.parseColor(s.trim()); } catch (Throwable ignored) { }
        return null;
    }

    // ------------------------------------------------------------------ scope / external links

    private static String baseDomain(@Nullable String host) {
        if (host == null) return "";
        final String h = host.toLowerCase(Locale.ROOT);
        final String[] p = h.split("\\.");
        if (p.length <= 2) return h;
        // co.ir / ac.ir / com.au ...: the registrable domain has three labels
        final boolean shortTld = p[p.length - 1].length() == 2 && p[p.length - 2].length() <= 3;
        final int n = shortTld ? 3 : 2;
        final StringBuilder sb = new StringBuilder();
        for (int i = p.length - n; i < p.length; i++) { if (sb.length() > 0) sb.append('.'); sb.append(p[i]); }
        return sb.toString();
    }

    private boolean inScope(@Nullable String url) {
        try { return baseDomain(Uri.parse(url).getHost()).equals(baseDomain(Uri.parse(startUrl).getHost())); } catch (Throwable t) { return true; }
    }

    private boolean isIdentityFlow(@Nullable String url) {
        try {
            final Uri u = Uri.parse(url);
            final String h = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
            return h.equals("auth.openai.com") || h.endsWith(".auth.openai.com")
                    || h.equals("auth0.openai.com") || h.equals("login.openai.com")
                    || h.equals("accounts.google.com") || h.endsWith(".accounts.google.com")
                    || h.equals("gsi.google.com") || h.equals("oauthaccountmanager.googleapis.com")
                    || h.equals("login.microsoftonline.com") || h.endsWith(".microsoftonline.com")
                    || h.equals("appleid.apple.com") || h.equals("github.com")
                    || h.equals("login.live.com") || h.equals("id.twitch.tv")
                    || h.equals("discord.com") || h.equals("steamcommunity.com")
                    || h.equals("identitytoolkit.googleapis.com")
                    || h.equals("myaccount.google.com") || h.equals("oauth2.googleapis.com")
                    || h.equals("www.googleapis.com") || h.equals("accounts.youtube.com") || h.equals("apis.google.com")
                    || h.equals("content.googleapis.com") || h.equals("accounts.google.co.uk") || h.startsWith("accounts.google.");
        } catch (Throwable t) { return false; }
    }

    /** A new window that is part of a sign-in: known identity hosts, blank windows the page fills in later, and URLs that look like OAuth / login. */
    private boolean isPopupFlow(@Nullable String url) {
        if (url == null || url.isEmpty() || url.startsWith("about:")) return true; // window.open('') - the page navigates it itself
        if (isIdentityFlow(url)) return true;
        try {
            final Uri u = Uri.parse(url);
            final String h = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
            if (h.endsWith(".firebaseapp.com") || h.endsWith(".web.app") || h.endsWith(".auth0.com") || h.endsWith(".okta.com")
                    || h.endsWith(".b2clogin.com") || h.endsWith(".amazoncognito.com") || h.endsWith(".onelogin.com")) return true;
            final String pq = ((u.getPath() == null ? "" : u.getPath()) + "?" + (u.getQuery() == null ? "" : u.getQuery())).toLowerCase(Locale.ROOT);
            return pq.contains("oauth") || pq.contains("/authorize") || pq.contains("__/auth") || pq.contains("/sso") || pq.contains("openid")
                    || pq.contains("/signin") || pq.contains("/sign-in") || pq.contains("/login") || pq.contains("response_type=");
        } catch (Throwable t) { return false; }
    }

    // ------------------------------------------------------------------ sign-in popup (window.open)
    private GeckoSession popup;
    private GeckoView popupView;
    private FrameLayout popupLayer;
    private boolean popupCanGoBack;

    /** Creates the popup's session (Gecko opens it itself, like the browser's own window.open tabs) and shows it over the page. */
    private GeckoSession openPopup() {
        closePopup();
        final GeckoSessionSettings.Builder pb = new GeckoSessionSettings.Builder()
                .usePrivateMode(false)
                .userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
                .viewportMode(GeckoSessionSettings.VIEWPORT_MODE_MOBILE);
        { final String ua = e.effectiveUa(false, Engine.hostOf(startUrl)); if (!ua.isEmpty()) pb.userAgentOverride(ua); }
        final GeckoSession ps = new GeckoSession(pb.build());
        ps.setNavigationDelegate(popupNavigation);
        ps.setContentDelegate(popupContent);
        ps.setPermissionDelegate(permission);
        ps.setPromptDelegate(new PwaPrompts());
        popup = ps;
        popupCanGoBack = false;
        runOnUiThread(() -> {
            if (popup != ps || isFinishing()) return;
            popupLayer = new FrameLayout(this);
            popupLayer.setBackgroundColor(e.dark ? 0xFF111318 : 0xFFFFFFFF);
            popupLayer.setClickable(true); // touches never fall through to the page underneath
            popupView = new GeckoView(this);
            Engine.allowSystemAutofill(popupView);
            popupLayer.addView(popupView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            final FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            lp.topMargin = dp(42);
            // above the page, below the DNS / VPN buttons and the progress line
            root.addView(popupLayer, Math.max(0, root.indexOfChild(gv) + 1), lp);
            attachPopup(ps, 0);
        });
        return ps;
    }

    private void attachPopup(final GeckoSession ps, final int tries) {
        if (popup != ps || popupView == null) return;
        if (!ps.isOpen()) {
            if (tries < 60) ui.postDelayed(() -> attachPopup(ps, tries + 1), 50);
            return;
        }
        try {
            if (popupView.getSession() != null) popupView.releaseSession();
            popupView.setSession(ps);
            ps.setActive(true);
        } catch (Throwable t) { Log.w(TAG, "attachPopup", t); }
    }

    private void closePopup() {
        final GeckoSession ps = popup;
        popup = null;
        popupCanGoBack = false;
        try {
            if (popupLayer != null && root != null) root.removeView(popupLayer);
            if (popupView != null && popupView.getSession() != null) popupView.releaseSession();
        } catch (Throwable t) { Log.w(TAG, "closePopup view", t); }
        popupLayer = null;
        popupView = null;
        if (ps != null) { try { if (ps.isOpen()) ps.close(); } catch (Throwable t) { Log.w(TAG, "closePopup", t); } }
        if (session != null) { try { session.setActive(true); } catch (Throwable ignored) { } }
    }

    private final GeckoSession.NavigationDelegate popupNavigation = new GeckoSession.NavigationDelegate() {
        @Override public void onCanGoBack(@NonNull GeckoSession s, boolean can) { popupCanGoBack = can; }

        @Nullable @Override
        public GeckoResult<AllowOrDeny> onLoadRequest(@NonNull GeckoSession s, @NonNull LoadRequest req) {
            final Uri u = Uri.parse(req.uri);
            final String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
            switch (sc) {
                case "http": case "https": case "about": case "data": case "blob": case "javascript": case "moz-extension": case "ws": case "wss":
                    return GeckoResult.allow();
                default:
                    return GeckoResult.deny();
            }
        }

        @Nullable @Override
        public GeckoResult<GeckoSession> onNewSession(@NonNull GeckoSession s, @NonNull String uri) {
            runOnUiThread(() -> { try { s.loadUri(uri); } catch (Throwable ignored) { } });
            return null;
        }

        @Nullable @Override
        public GeckoResult<String> onLoadError(@NonNull GeckoSession s, @Nullable String uri, @NonNull WebRequestError error) {
            return GeckoResult.fromValue(ErrorPage.build(e.lang, e.dark, e.accent, uri, error));
        }
    };

    private final GeckoSession.ContentDelegate popupContent = new GeckoSession.ContentDelegate() {
        @Override public void onCloseRequest(@NonNull GeckoSession s) { runOnUiThread(PwaActivity.this::closePopup); }
        @Override public void onExternalResponse(@NonNull GeckoSession s, @NonNull WebResponse r) { saveDownload(r); }
        @Override public void onCrash(@NonNull GeckoSession s) { runOnUiThread(PwaActivity.this::closePopup); }
        @Override public void onKill(@NonNull GeckoSession s) { runOnUiThread(PwaActivity.this::closePopup); }
    };

    private void openInBrowser(String url) {
        try {
            final Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
            final Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            if (launch != null && launch.getComponent() != null) it.setComponent(launch.getComponent()); else it.setPackage(getPackageName());
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(it);
        } catch (Throwable t) { Log.w(TAG, "openInBrowser", t); }
    }

    // ------------------------------------------------------------------ delegates

    private final GeckoSession.ProgressDelegate progress = new GeckoSession.ProgressDelegate() {
        @Override public void onPageStart(@NonNull GeckoSession s, @NonNull String url) { runOnUiThread(() -> { bar.setVisibility(View.VISIBLE); setBar(5); }); }
        @Override public void onPageStop(@NonNull GeckoSession s, boolean ok) { runOnUiThread(() -> bar.setVisibility(View.GONE)); askPageColor(); }
        @Override public void onProgressChange(@NonNull GeckoSession s, int p) { runOnUiThread(() -> { if (p >= 100) bar.setVisibility(View.GONE); else { bar.setVisibility(View.VISIBLE); setBar(p); } }); }
    };

    /** The page's content script re-reads its top colour (the status bar / notch area follows it) now and shortly after. */
    private void askPageColor() {
        final Runnable ask = () -> {
            final org.mozilla.geckoview.WebExtension.Port p = cport;
            if (p == null) return;
            try { p.postMessage(new JSONObject().put("cmd", "pc")); } catch (Throwable ignored) { }
        };
        ui.post(ask);
        ui.postDelayed(ask, 350);
        ui.postDelayed(ask, 1200);
    }

    private void setBar(int pct) {
        final ViewGroup.LayoutParams lp = bar.getLayoutParams();
        lp.width = Math.max(dp(8), root.getWidth() * Math.max(0, Math.min(100, pct)) / 100);
        bar.setLayoutParams(lp);
    }

    private final GeckoSession.NavigationDelegate navigation = new GeckoSession.NavigationDelegate() {
        @Override
        public void onLocationChange(@NonNull GeckoSession s, @Nullable String url,
                                     @NonNull List<GeckoSession.PermissionDelegate.ContentPermission> perms, @NonNull Boolean gesture) {
            if (url != null && !url.startsWith("data:text/html")) curUrl = url;
            askPageColor();
        }

        @Override public void onCanGoBack(@NonNull GeckoSession s, boolean can) { canGoBack = can; }

        @Nullable @Override
        public GeckoResult<AllowOrDeny> onLoadRequest(@NonNull GeckoSession s, @NonNull LoadRequest req) {
            final Uri u = Uri.parse(req.uri);
            final String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
            switch (sc) {
                case "http": case "https":
                    // From inside the app a tapped link to another site opens in the browser; redirects / sign-in flows stay here.
                    if (req.hasUserGesture && inScope(curUrl) && !inScope(req.uri) && !isIdentityFlow(req.uri)) {
                        openInBrowser(req.uri);
                        return GeckoResult.deny();
                    }
                    return GeckoResult.allow();
                case "about": case "data": case "blob": case "javascript": case "moz-extension": case "view-source": case "ws": case "wss":
                    return GeckoResult.allow();
                case "file": case "content": case "chrome": case "resource": case "jar":
                    return GeckoResult.deny();
                case "intent": {
                    try {
                        final Intent it = Intent.parseUri(req.uri, Intent.URI_INTENT_SCHEME);
                        final String fb = it.getStringExtra("browser_fallback_url");
                        if (fb != null && (fb.startsWith("https://") || fb.startsWith("http://"))) runOnUiThread(() -> s.loadUri(fb));
                    } catch (Exception ignored) { }
                    return GeckoResult.deny();
                }
                default: {
                    final boolean direct = sc.equals("tel") || sc.equals("mailto") || sc.equals("sms");
                    if (!req.hasUserGesture && !direct && !req.isDirectNavigation) return GeckoResult.deny();
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Throwable ignored) { }
                    return GeckoResult.deny();
                }
            }
        }

        @Nullable @Override
        public GeckoResult<GeckoSession> onNewSession(@NonNull GeckoSession s, @NonNull String uri) {
            // Sign-in windows (Google / Apple / Firebase popups...) are real popups: the page that opened them keeps running underneath
            // and receives the result (window.opener.postMessage / close). Replacing the page with them, or sending them to the browser,
            // is why the app never came back after "Sign in with Google".
            if (isPopupFlow(uri)) return GeckoResult.fromValue(openPopup());
            // Other window.open / target=_blank: pages of the app itself replace the current one, other sites go to the browser.
            if (inScope(uri)) runOnUiThread(() -> s.loadUri(uri)); else openInBrowser(uri);
            return null;
        }

        @Nullable @Override
        public GeckoResult<String> onLoadError(@NonNull GeckoSession s, @Nullable String uri, @NonNull WebRequestError error) {
            return GeckoResult.fromValue(ErrorPage.build(e.lang, e.dark, e.accent, uri, error));
        }
    };

    private final GeckoSession.ContentDelegate content = new GeckoSession.ContentDelegate() {
        @Override public void onTitleChange(@NonNull GeckoSession s, @Nullable String title) {
            if (title != null && !title.isEmpty()) runOnUiThread(() -> setLabel(title));
        }

        @Override public void onFullScreen(@NonNull GeckoSession s, boolean on) { runOnUiThread(() -> setFullscreen(on)); }

        @Override public void onCloseRequest(@NonNull GeckoSession s) { runOnUiThread(PwaActivity.this::finish); }

        @Override public void onExternalResponse(@NonNull GeckoSession s, @NonNull WebResponse r) { saveDownload(r); }

        @Override public void onCrash(@NonNull GeckoSession s) { reopen(); }
        @Override public void onKill(@NonNull GeckoSession s) { reopen(); }

        // Web app manifest (theme_color / background_color): colours the status bar like an installed app.
        // No @Override: older GeckoView builds do not have this callback.
        public void onWebAppManifest(@NonNull GeckoSession s, @NonNull JSONObject manifest) {
            Integer c = cssColor(manifest.optString("theme_color", null));
            if (c == null) c = cssColor(manifest.optString("background_color", null));
            if (c == null) return;
            final int col = c | 0xFF000000;
            runOnUiThread(() -> { if (!pageColor) { applyBarColor(col); applyStripColor(col); } });
        }

        private void reopen() {
            runOnUiThread(() -> {
                try {
                    session.open(e.runtime);
                    gv.releaseSession();
                    gv.setSession(session);
                    session.loadUri(curUrl.isEmpty() ? startUrl : curUrl);
                } catch (Throwable t) { Log.e(TAG, "reopen", t); }
            });
        }
    };

    private final GeckoSession.PermissionDelegate permission = new GeckoSession.PermissionDelegate() {
        @Override
        public void onAndroidPermissionsRequest(@NonNull GeckoSession s, @Nullable String[] perms, @NonNull Callback cb) {
            runOnUiThread(() -> e.prompts.requestAndroidPermissions(perms, cb));
        }

        @Nullable @Override
        public GeckoResult<Integer> onContentPermissionRequest(@NonNull GeckoSession s, @NonNull ContentPermission perm) {
            switch (perm.permission) {
                case PERMISSION_GEOLOCATION: {
                    final GeckoResult<Integer> res = new GeckoResult<>();
                    final String host = Engine.hostOf(perm.uri);
                    yesNo(tr("دسترسی به مکان", "Location"), host + "\n" + tr("اجازه‌ی دسترسی به مکان شما؟", "Allow access to your location?"),
                            ok -> res.complete(ok ? ContentPermission.VALUE_ALLOW : ContentPermission.VALUE_DENY));
                    return res;
                }
                case PERMISSION_STORAGE_ACCESS: case PERMISSION_PERSISTENT_STORAGE: case PERMISSION_MEDIA_KEY_SYSTEM_ACCESS:
                    return GeckoResult.fromValue(ContentPermission.VALUE_ALLOW);
                default:
                    return GeckoResult.fromValue(ContentPermission.VALUE_PROMPT);
            }
        }

        @Override
        public void onMediaPermissionRequest(@NonNull GeckoSession s, @NonNull String uri, @Nullable MediaSource[] video,
                                             @Nullable MediaSource[] audio, @NonNull MediaCallback cb) {
            final boolean v = video != null && video.length > 0, a = audio != null && audio.length > 0;
            if (!v && !a) { cb.reject(); return; }
            final String what = v && a ? tr("دوربین و میکروفون", "camera and microphone") : v ? tr("دوربین", "camera") : tr("میکروفون", "microphone");
            yesNo(Engine.hostOf(uri), tr("اجازه‌ی استفاده از ", "Allow use of the ") + what + (fa() ? "؟" : "?"), ok -> {
                if (ok) cb.grant(v ? video[0] : null, a ? audio[0] : null); else cb.reject();
            });
        }
    };

    private interface Yes { void run(boolean ok); }

    private void yesNo(String title, String msg, Yes cb) {
        runOnUiThread(() -> {
            final boolean[] done = {false};
            try {
                new AlertDialog.Builder(this).setTitle(title).setMessage(msg)
                        .setPositiveButton(tr("اجازه", "Allow"), (d, w) -> { if (!done[0]) { done[0] = true; cb.run(true); } })
                        .setNegativeButton(tr("رد", "Block"), (d, w) -> { if (!done[0]) { done[0] = true; cb.run(false); } })
                        .setOnCancelListener(d -> { if (!done[0]) { done[0] = true; cb.run(false); } })
                        .show();
            } catch (Throwable t) { if (!done[0]) { done[0] = true; cb.run(false); } }
        });
    }

    // ------------------------------------------------------------------ prompts (native dialogs; files / dates / share reuse the browser's code)

    private final class PwaPrompts implements GeckoSession.PromptDelegate {
        @Nullable @Override
        public GeckoResult<PromptResponse> onLoginSave(@NonNull GeckoSession s, @NonNull AutocompleteRequest<org.mozilla.geckoview.Autocomplete.LoginSaveOption> p) {
            if (!e.savePasswords || e.logins == null || p.options == null || p.options.length == 0) return GeckoResult.fromValue(p.dismiss());
            final org.mozilla.geckoview.Autocomplete.LoginSaveOption o = p.options[0];
            final String host = Logins.hostOf(o.value.origin);
            if (e.logins.isNever(host)) return GeckoResult.fromValue(p.dismiss());
            final boolean upd = o.value.guid != null || e.logins.hasUser(o.value.origin, o.value.username);
            final GeckoResult<PromptResponse> res = new GeckoResult<>();
            runOnUiThread(() -> {
                final boolean[] done = {false};
                try {
                    final String u = o.value.username == null || o.value.username.isEmpty() ? "" : "\n" + o.value.username;
                    dialog()
                            .setTitle(upd ? tr("به‌روزرسانی رمز عبور؟", "Update password?") : tr("ذخیرهٔ رمز عبور؟", "Save password?"))
                            .setMessage(host + u)
                            .setPositiveButton(upd ? tr("به‌روزرسانی", "Update") : tr("ذخیره", "Save"), (d, w) -> { if (!done[0]) { done[0] = true; res.complete(p.confirm(o)); } })
                            .setNeutralButton(tr("هرگز", "Never"), (d, w) -> { if (!done[0]) { done[0] = true; e.logins.setNever(host); res.complete(p.dismiss()); } })
                            .setNegativeButton(tr("الان نه", "Not now"), (d, w) -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } })
                            .setOnCancelListener(d -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } })
                            .show();
                } catch (Throwable t) { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } }
            });
            return res;
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onLoginSelect(@NonNull GeckoSession s, @NonNull AutocompleteRequest<org.mozilla.geckoview.Autocomplete.LoginSelectOption> p) {
            if (!e.savePasswords || p.options == null || p.options.length == 0) return GeckoResult.fromValue(p.dismiss());
            // LoginSelectOption represents an existing saved credential. Do not
            // discard options based on optional fields that GeckoView may omit.
            final List<Integer> saved = new ArrayList<>();
            for (int i = 0; i < p.options.length; i++) saved.add(i);
            if (saved.isEmpty()) return GeckoResult.fromValue(p.dismiss());
            final String host = Logins.hostOf(p.options[saved.get(0)].value.origin);
            if (declinedLoginHosts.contains(host == null ? "" : host)) {
                focusLoginFields(s);
                return GeckoResult.fromValue(p.dismiss());
            }
            final GeckoResult<PromptResponse> res = new GeckoResult<>();
            if (!e.bioLogin) {
                showPwaLoginPicker(s, p, saved, host, false, res);
            } else {
                e.authenticateBiometric(host, authenticated -> {
                    if (Boolean.FALSE.equals(authenticated)) {
                        declinedLoginHosts.add(host == null ? "" : host);
                        focusLoginFields(s);
                        res.complete(p.dismiss());
                    }
                    else if (saved.size() == 1) {
                        hideKeyboardAfterLoginAutofill();
                        final PromptResponse response = p.confirm(p.options[saved.get(0)]);
                        if (Boolean.TRUE.equals(authenticated)) submitPwaLogin(s, host);
                        res.complete(response);
                    } else showPwaLoginPicker(s, p, saved, host, Boolean.TRUE.equals(authenticated), res);
                });
            }
            return res;
        }

        private void showPwaLoginPicker(GeckoSession s,
                AutocompleteRequest<org.mozilla.geckoview.Autocomplete.LoginSelectOption> p,
                List<Integer> saved, String host, boolean authenticated, GeckoResult<PromptResponse> res) {
            final CharSequence[] labels = new CharSequence[saved.size()];
            for (int i = 0; i < saved.size(); i++) {
                final org.mozilla.geckoview.Autocomplete.LoginEntry le = p.options[saved.get(i)].value;
                labels[i] = le.username == null || le.username.isEmpty() ? tr("(بدون نام کاربری)", "(no username)") : le.username;
            }
            runOnUiThread(() -> {
                final boolean[] done = {false};
                try {
                    dialog()
                            .setTitle(host)
                            .setItems(labels, (d, i) -> {
                                if (!done[0]) {
                                    done[0] = true;
                                    hideKeyboardAfterLoginAutofill();
                                    res.complete(p.confirm(p.options[saved.get(i)]));
                                    if (authenticated) submitPwaLogin(s, host);
                                }
                            })
                            .setOnCancelListener(d -> { if (!done[0]) { done[0] = true; declinedLoginHosts.add(host == null ? "" : host); focusLoginFields(s); res.complete(p.dismiss()); } })
                            .show();
                } catch (Throwable t) { if (!done[0]) { done[0] = true; declinedLoginHosts.add(host == null ? "" : host); focusLoginFields(s); res.complete(p.dismiss()); } }
            });
        }

        private void focusLoginFields(GeckoSession s) {
            try {
                final JSONObject command = new JSONObject();
                command.put("cmd", "focusLogin");
                final Engine engine = Engine.I;
                if (engine != null) engine.sendToPage(s, command);
            } catch (Throwable ignored) { }
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                if (gv == null || gv.getWindowToken() == null) return;
                try {
                    gv.requestFocus();
                    InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(gv, InputMethodManager.SHOW_IMPLICIT);
                } catch (Throwable ignored) { }
            }, 220L);
        }

        private void submitPwaLogin(GeckoSession s, String host) {
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                try {
                    final JSONObject command = new JSONObject();
                    command.put("cmd", "submitLogin"); command.put("host", host == null ? "" : host);
                    final Engine engine = Engine.I;
                    if (engine == null || !engine.sendToPage(s, command)) Log.w(TAG, "auto-submit unavailable: page bridge not ready");
                } catch (Throwable t) { Log.w(TAG, "auto-submit unavailable", t); }
            }, 600);
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onAlertPrompt(@NonNull GeckoSession s, @NonNull AlertPrompt p) {
            final GeckoResult<PromptResponse> res = new GeckoResult<>();
            runOnUiThread(() -> {
                final boolean[] done = {false};
                try {
                    dialog().setTitle(p.title).setMessage(p.message)
                            .setPositiveButton("OK", (d, w) -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } })
                            .setOnCancelListener(d -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } })
                            .show();
                } catch (Throwable t) { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } }
            });
            return res;
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onButtonPrompt(@NonNull GeckoSession s, @NonNull ButtonPrompt p) {
            final GeckoResult<PromptResponse> res = new GeckoResult<>();
            runOnUiThread(() -> {
                final boolean[] done = {false};
                try {
                    dialog().setTitle(p.title).setMessage(p.message)
                            .setPositiveButton(tr("تأیید", "OK"), (d, w) -> { if (!done[0]) { done[0] = true; res.complete(p.confirm(ButtonPrompt.Type.POSITIVE)); } })
                            .setNegativeButton(tr("انصراف", "Cancel"), (d, w) -> { if (!done[0]) { done[0] = true; res.complete(p.confirm(ButtonPrompt.Type.NEGATIVE)); } })
                            .setOnCancelListener(d -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } })
                            .show();
                } catch (Throwable t) { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } }
            });
            return res;
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onTextPrompt(@NonNull GeckoSession s, @NonNull TextPrompt p) {
            final GeckoResult<PromptResponse> res = new GeckoResult<>();
            runOnUiThread(() -> {
                final boolean[] done = {false};
                try {
                    final EditText et = new EditText(PwaActivity.this);
                    et.setInputType(InputType.TYPE_CLASS_TEXT);
                    if (p.defaultValue != null) et.setText(p.defaultValue);
                    dialog().setTitle(p.title).setMessage(p.message).setView(et)
                            .setPositiveButton(tr("تأیید", "OK"), (d, w) -> { if (!done[0]) { done[0] = true; res.complete(p.confirm(et.getText().toString())); } })
                            .setNegativeButton(tr("انصراف", "Cancel"), (d, w) -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } })
                            .setOnCancelListener(d -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } })
                            .show();
                } catch (Throwable t) { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } }
            });
            return res;
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onChoicePrompt(@NonNull GeckoSession s, @NonNull ChoicePrompt p) {
            final GeckoResult<PromptResponse> res = new GeckoResult<>();
            final List<ChoicePrompt.Choice> list = new ArrayList<>();
            flat(p.choices, list);
            if (list.isEmpty()) return GeckoResult.fromValue(p.dismiss());
            final CharSequence[] labels = new CharSequence[list.size()];
            final boolean[] checked = new boolean[list.size()];
            int sel = -1;
            for (int i = 0; i < labels.length; i++) {
                labels[i] = list.get(i).label;
                checked[i] = list.get(i).selected;
                if (checked[i] && sel < 0) sel = i;
            }
            final int selected = sel;
            runOnUiThread(() -> {
                final boolean[] done = {false};
                try {
                    final AlertDialog.Builder b = dialog();
                    if (p.title != null && !p.title.isEmpty()) b.setTitle(p.title);
                    if (p.type == ChoicePrompt.Type.MULTIPLE) {
                        b.setMultiChoiceItems(labels, checked, (d, i, on) -> checked[i] = on)
                                .setPositiveButton(tr("تأیید", "OK"), (d, w) -> {
                                    if (done[0]) return;
                                    done[0] = true;
                                    final List<String> ids = new ArrayList<>();
                                    for (int i = 0; i < checked.length; i++) if (checked[i]) ids.add(list.get(i).id);
                                    res.complete(p.confirm(ids.toArray(new String[0])));
                                });
                    } else {
                        b.setSingleChoiceItems(labels, selected, (d, i) -> {
                            if (done[0]) return;
                            done[0] = true;
                            res.complete(p.confirm(list.get(i).id));
                            d.dismiss();
                        });
                    }
                    b.setOnCancelListener(d -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } });
                    b.show();
                } catch (Throwable t) { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } }
            });
            return res;
        }

        private void flat(@Nullable ChoicePrompt.Choice[] cs, List<ChoicePrompt.Choice> out) {
            if (cs == null) return;
            for (ChoicePrompt.Choice c : cs) {
                if (c.separator) continue;
                if (c.items != null) { flat(c.items, out); continue; }
                if (!c.disabled) out.add(c);
            }
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onBeforeUnloadPrompt(@NonNull GeckoSession s, @NonNull BeforeUnloadPrompt p) {
            return GeckoResult.fromValue(p.confirm(AllowOrDeny.ALLOW));
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onRepostConfirmPrompt(@NonNull GeckoSession s, @NonNull RepostConfirmPrompt p) {
            return GeckoResult.fromValue(p.confirm(AllowOrDeny.ALLOW));
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onRedirectPrompt(@NonNull GeckoSession s, @NonNull RedirectPrompt p) {
            return GeckoResult.fromValue(p.confirm(AllowOrDeny.ALLOW));
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onPopupPrompt(@NonNull GeckoSession s, @NonNull PopupPrompt p) { return e.prompts.onPopupPrompt(s, p); }

        @Nullable @Override
        public GeckoResult<PromptResponse> onFilePrompt(@NonNull GeckoSession s, @NonNull FilePrompt p) { return e.prompts.onFilePrompt(s, p); }

        @Nullable @Override
        public GeckoResult<PromptResponse> onDateTimePrompt(@NonNull GeckoSession s, @NonNull DateTimePrompt p) { return e.prompts.onDateTimePrompt(s, p); }

        @Nullable @Override
        public GeckoResult<PromptResponse> onSharePrompt(@NonNull GeckoSession s, @NonNull SharePrompt p) { return e.prompts.onSharePrompt(s, p); }

        @Nullable @Override
        public GeckoResult<PromptResponse> onColorPrompt(@NonNull GeckoSession s, @NonNull ColorPrompt p) { return GeckoResult.fromValue(p.dismiss()); }
    }

    // ------------------------------------------------------------------ downloads (saved straight to the Downloads folder)

    private static String header(@Nullable Map<String, String> h, String name) {
        if (h == null) return null;
        for (Map.Entry<String, String> en : h.entrySet()) if (en.getKey() != null && en.getKey().equalsIgnoreCase(name)) return en.getValue();
        return null;
    }

    private static String fileName(WebResponse r) {
        String name = null;
        final String cd = header(r.headers, "Content-Disposition");
        if (cd != null) {
            final java.util.regex.Matcher m5 = java.util.regex.Pattern.compile("filename\\*\\s*=\\s*[^']*'[^']*'([^;]+)", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(cd);
            final java.util.regex.Matcher m = java.util.regex.Pattern.compile("filename\\s*=\\s*\"?([^\";]+)\"?", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(cd);
            if (m5.find()) { try { name = Uri.decode(m5.group(1).trim()); } catch (Throwable ignored) { } }
            if ((name == null || name.isEmpty()) && m.find()) name = m.group(1).trim();
        }
        if (name == null || name.isEmpty()) {
            try { name = Uri.parse(r.uri).getLastPathSegment(); } catch (Throwable ignored) { }
        }
        if (name == null || name.isEmpty()) name = "download_" + System.currentTimeMillis();
        return name.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    private void saveDownload(final WebResponse r) {
        if (r.body == null) return;
        if (e == null || !e.dlAsk) { startDownload(r); return; }
        final String name = fileName(r);
        long len = 0;
        try { final String cl = header(r.headers, "Content-Length"); if (cl != null) len = Long.parseLong(cl.trim()); } catch (Throwable ignored) { }
        final String size = humanSize(len);
        runOnUiThread(() -> {
            final boolean[] done = {false};
            try {
                dialog()
                        .setTitle(tr("دانلود فایل؟", "Download file?"))
                        .setMessage(name + (size.isEmpty() ? "" : "\n" + size) + "\n" + Engine.hostOf(String.valueOf(r.uri)))
                        .setPositiveButton(tr("دانلود", "Download"), (d, w) -> { if (!done[0]) { done[0] = true; startDownload(r); } })
                        .setNegativeButton(tr("لغو", "Cancel"), (d, w) -> { if (!done[0]) { done[0] = true; closeQuietly(r); } })
                        .setOnCancelListener(d -> { if (!done[0]) { done[0] = true; closeQuietly(r); } })
                        .show();
            } catch (Throwable t) { if (!done[0]) { done[0] = true; startDownload(r); } }
        });
    }

    private static void closeQuietly(WebResponse r) {
        try { if (r.body != null) r.body.close(); } catch (Throwable ignored) { }
    }

    private void startDownload(final WebResponse r) {
        final InputStream in = r.body;
        if (in == null) return;
        final String name = fileName(r);
        String mime = header(r.headers, "Content-Type");
        if (mime != null && mime.contains(";")) mime = mime.substring(0, mime.indexOf(';')).trim();
        final String type = mime == null || mime.isEmpty() ? "application/octet-stream" : mime;
        runOnUiThread(() -> Toast.makeText(this, tr("دانلود شروع شد: ", "Downloading: ") + name, Toast.LENGTH_SHORT).show());
        new Thread(() -> {
            boolean ok = false;
            try (InputStream src = in) {
                OutputStream out;
                Uri item = null;
                if (Build.VERSION.SDK_INT >= 29) {
                    final ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, type);
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    item = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (item == null) throw new IllegalStateException("no MediaStore item");
                    out = getContentResolver().openOutputStream(item);
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    if (dir == null) dir = getFilesDir();
                    dir.mkdirs();
                    out = new FileOutputStream(new File(dir, name));
                }
                if (out == null) throw new IllegalStateException("no output");
                try (OutputStream o = out) {
                    final byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = src.read(buf)) > 0) o.write(buf, 0, n);
                }
                if (item != null) {
                    final ContentValues done = new ContentValues();
                    done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(item, done, null, null);
                }
                ok = true;
            } catch (Throwable t) {
                Log.e(TAG, "download", t);
            }
            final boolean fin = ok;
            runOnUiThread(() -> Toast.makeText(this, (fin ? tr("ذخیره شد در دانلودها: ", "Saved to Downloads: ") : tr("دانلود ناموفق: ", "Download failed: ")) + name, Toast.LENGTH_LONG).show());
        }, "abtin-pwa-download").start();
    }
}
