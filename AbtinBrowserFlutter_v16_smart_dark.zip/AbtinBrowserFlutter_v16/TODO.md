# TODO
- Windows version: Gecko plugin is Android-only → add a Windows engine (WebView2) behind the same `gecko` API in lib/engine/gecko.dart.
- Verify on device: download folder (Downloads.java uses Engine.downloadDir), force-dark on dark/light sites, favicons.
- Run: flutter analyze && flutter build apk --release

- [ ] Re-run `flutter analyze` in CI to confirm 0 errors after v4 stage9 fixes (not verified locally: no Flutter SDK).

- [ ] v5: run `flutter pub get` (new deps: video_player, wakelock_plus, mobile_scanner, pointycastle) then `flutter analyze` — not compiled locally (no Flutter SDK).
- [ ] v5 verify on device: page video detection (mp4 / HLS / Instagram), merge video+audio (native Mux.java), in-app player, QR scan, VPN compatibility switch (Settings > Privacy).
- Not supported: DRM streams, live HLS, DASH .mpd manifests, HLS BYTERANGE.

- [ ] v7 verify on device: in-page video buttons (download / player / X per site; Settings > "Download & player buttons on videos"), pause->resume quickly, resume after app restart, play downloaded mp4/webm, merged DASH output (interleaved mux), HTML-instead-of-video downloads now fail instead of saving a broken file.

- [ ] v10 (merge of v9 + keyboard fix): verify on device — keyboard no longer closes on numeric fields; Chrome-style download notification buttons (Pause / Resume / Cancel) and round play/pause ring in Downloads page. Not compiled locally (no Flutter SDK).

- [ ] v10 speed pass: verify on device — download speed with 8 connections (default for new installs; existing users keep their saved value in Settings), 256 KB I/O buffers, new Gecko prefs (socket send buffer, caches, TLS tickets/0-RTT, early hints), non-blocking extension load at startup. Next candidates: enable R8 (needs a tested release build), baseline profiles.

- [ ] v11 Google one-tap sign-in (Settings > Google account; MainActivity.kt + lib/engine/google_account.dart): not compiled locally (no Flutter SDK). Needs a Web OAuth client ID pasted in Settings and an Android OAuth client (package ir.abtin.abtin_browser + SHA-1 of android/keystore/abtin-release.jks) in Google Cloud Console. Device needs Google Play services. Run `flutter pub get && flutter analyze`, then test on a phone with 2+ Google accounts.

- [ ] v12 player: Persian subtitles (lib/engine/subtitles.dart; auto-loads movie.srt/.vtt next to local files, or pick one via the subtitles button; UTF-8/UTF-16/Windows-1256 detected; RTL-aware) and RTL video title. Not compiled locally (no Flutter SDK): run flutter analyze and test with a cp1256 and a UTF-8 Persian .srt.

- [ ] v13 player: files with Persian/non-ASCII names play through an ASCII symlink in the app cache (_safePath in video_player_page.dart). Not compiled locally: verify on device with a Persian-named mp4/mkv.

- [ ] v14 download page: menu items "Download page (HTML)" (content.js savePage: styles + images inlined, scripts removed, → .html) and "Download page (PDF)" (Engine.savePdf, no print dialog) save into the download folder and appear in the Downloads page. Not compiled locally (no Flutter SDK): verify on device on a long page, a page with many images, and a private tab.

- [ ] v15 local files/projects: (1) MainActivity.kt local server now sends real CRLF (v14 sent literal "\\r\\n" so pages could not load), Range/206 for video+audio seek, streaming instead of readBytes, per-project URL /<id>/..., folder listing when there is no index.html, redirect for folder URLs without "/", more MIME types, no CORS header, copy runs off the UI thread, skips .git/node_modules, keeps 5 newest projects, wipes old copies at startup. (2) Open from file manager/Share: html/htm/svg/xml render as pages; css/js/txt/md/csv/log/yaml open in a text viewer (UTF-8 or windows-1256); json as before. Not compiled locally (no Flutter SDK): run flutter analyze, then test: a folder with index.html + css/js/images/fonts, a folder without index.html, a mp4 inside a project (seek), 2 projects in 2 tabs, a .css/.txt/.html file opened from a file manager.

- [ ] v16 smart dark mode: moved to assets/abtin_core/dark.js (all frames, document_start; content.js no longer has dark code). Applies before first paint (pending class), time-sliced scan (8 ms slices), iframes + open/closed shadow roots, coloured dark text (links) lightened with hue kept (--abtin-c), gradients handled separately from url() backgrounds, small logos on white / black-on-transparent inverted (background.js imgKind measures pixels, cached), animated style changes throttled, per-site override (menu: 'Dark mode for this site' -> AppState.darkSites -> core config -> getConfig/forceDark message). Not compiled/run locally: verify on device on a light news site, a site with an iframe/shadow DOM, a site that is already dark (must be left alone), a logo with white background, and the per-site toggle on/off. Known limits: ::before/::after colours and canvas/video are not touched; per-site 'off' still sends prefers-color-scheme: dark when the global switch is on.
