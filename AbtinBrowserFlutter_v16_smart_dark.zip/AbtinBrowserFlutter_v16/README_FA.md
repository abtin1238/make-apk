# آبتین v3 — مرورگر فلاتر با موتور GeckoView (Firefox)

مرورگر فارسی مبتنی بر Flutter و GeckoView. کد اصلی برنامه در `lib/`، افزونهٔ Android در `packages/abtin_gecko/` و نسخهٔ محلی `file_picker` در `packages/file_picker/` قرار دارد.

## ساخت APK امضاشده

نیازمندی‌های پیشنهادی: Flutter 3.47 یا جدیدتر، JDK 21، Android SDK Platform 37، Android Gradle Plugin 9.1.0 و Gradle 9.3.1.

```bash
flutter pub get
flutter build apk --release --target-platform android-arm64 --split-debug-info=build/symbols
```

این پیکربندی برای ARM64 است. خروجی در `build/app/outputs/flutter-apk/app-release.apk` قرار می‌گیرد. برای نصب روی دستگاه‌های معمولی 64 بیتی Android (arm64-v8a) مناسب است؛ برای ABIهای دیگر باید فیلترها و build جداگانه تنظیم شوند.

امضا از `android/key.properties` و کلید `android/keystore/abtin-release.jks` خوانده می‌شود. کلید پروژه با alias `abtin` ساخته شده است. مسیر keystore در فایل properties نسبت به پوشهٔ `android/` است.

## حفاظت از کلید

این بسته شامل کلید خصوصی keystore و رمز آن است تا بتوانید همین پروژه را مستقیماً با همان کلید build کنید. آن‌ها را محرمانه نگه دارید و در مخزن عمومی یا برای دیگران منتشر نکنید. یک نسخهٔ پشتیبان امن و رمزگذاری‌شده نگه دارید؛ برای انتشار نسخه‌های بعدی همین اپ، باید کلید امضای یکسان استفاده شود. اگر این کلید برای انتشار عمومی نیست، پیش از انتشار عمومی یک keystore اختصاصی جدید بسازید و مقادیر `android/key.properties` را به‌روزرسانی کنید.

## ساختار

- `lib/` — رابط و منطق Flutter (فارسی/RTL)
- `packages/abtin_gecko/` — افزونهٔ داخلی GeckoView
- `packages/file_picker/` — نسخهٔ محلی افزونه با `compileSdk 37`
- `android/` — تنظیمات Gradle، امضا و پروژهٔ Android


## طراحی گلس‌مورفیسم و تم‌ها
- فایل‌های جدید: `lib/palettes.dart` (۹ تم: اقیانوس، شفق، غروب، جنگل، نئون، نیمه‌شب، یخ، شکوفه، نعنا + حالت خودکار) و `lib/ui/glass.dart` (ویجت‌های شیشه‌ای).
- انتخاب تم: تنظیمات ← ظاهر. همان‌جا شدت بلور و پس‌زمینهٔ متحرک هم قابل تنظیم است.
- منوی سه‌نقطه کاملاً رنگی و شیشه‌ای بازنویسی شده (`lib/ui/browser_menu.dart`).
- برای افزودن تم جدید فقط یک مورد به `palettes` اضافه کنید.
