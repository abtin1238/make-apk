'use strict';
// Abtin Core - smart dark mode. Runs in EVERY frame at document_start (content.js is top-frame only).
//  - applies before the first paint (no white flash), then darkens light surfaces only;
//  - time-sliced scanning (no long main-thread stalls), open + closed shadow roots, iframes;
//  - coloured dark text (links) is lightened, not replaced by grey; gradients and url() backgrounds are kept apart;
//  - small logos with a white background / black-on-transparent get inverted (background page measures the pixels);
//  - per-site override (on/off) comes from the app (cfg.sites), see AppState.toggleDarkSite.
(function () {
  if (window.__abtinDark) return;
  window.__abtinDark = true;
  var isTop = window.top === window;
  var host = (location.hostname || '').toLowerCase().replace(/^www\./, '');
  var cfg = { forceDark: false, sites: {} };
  var on = false, skip = false, started = false;
  var mo = null, shadowMo = [], hooked = new WeakSet(), selfEdit = new WeakSet(), ownStyles = [];
  var work = [], wi = 0, pumping = false, pendingRoots = new Set(), flushTimer = 0;
  var T_SKIP = /^(script|style|link|meta|head|title|noscript|br|template|base|source|track|param|area|defs)$/;
  var T_MEDIA = /^(video|audio|canvas|iframe|object|embed|picture|svg|math|frame|frameset)$/;
  var SVGNS = 'http://www.w3.org/2000/svg';

  var BG = '#24262b', FG = '#e6e8ed', BD = '#50545d';
  function rules(p) {
    return [
      p + '[data-abtin-dark-bg="1"]{background-color:' + BG + '!important}',
      p + '[data-abtin-dark-grad="1"]{background-image:none!important;background-color:' + BG + '!important}',
      p + '[data-abtin-dark-fg="1"]{color:' + FG + '!important}',
      p + '[data-abtin-dark-fg="2"]{color:var(--abtin-c)!important}',
      p + '[data-abtin-dark-border="1"]{border-color:' + BD + '!important;outline-color:' + BD + '!important}',
      p + '[data-abtin-dark-img="1"]{filter:invert(.9) hue-rotate(180deg)!important}',
      p + 'input,' + p + 'textarea,' + p + 'select{color-scheme:dark}'
    ].join('');
  }
  var DOC_CSS = [
    'html.__abtin_dark:not(.__abtin_dark_sub){background:#202226!important}',
    'html.__abtin_dark{color-scheme:dark!important}',
    // before the first scan the body is already dark: no white flash while the page loads
    'html.__abtin_dark.__abtin_dark_pending:not(.__abtin_dark_sub) body{background-color:' + BG + '!important;color:' + FG + '!important}',
    rules('html.__abtin_dark ')
  ].join('');
  var SHADOW_CSS = rules('');

  // ---------------------------------------------------------------- colour helpers
  function rgb(c) {
    var m = /rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/.exec(c || '');
    if (!m || (m[4] !== undefined && parseFloat(m[4]) < 0.08)) return null;
    var r = +m[1], g = +m[2], b = +m[3], R = r / 255, G = g / 255, B = b / 255;
    return { r: r, g: g, b: b, l: 0.2126 * R + 0.7152 * G + 0.0722 * B, sat: Math.max(R, G, B) - Math.min(R, G, B) };
  }
  function lighten(c) { // keep the hue (links stay blue, errors stay red), raise the lightness
    var r = c.r / 255, g = c.g / 255, b = c.b / 255, mx = Math.max(r, g, b), mn = Math.min(r, g, b), h = 0, s = 0, l = (mx + mn) / 2, d = mx - mn;
    if (d > 0) {
      s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn);
      if (mx === r) h = ((g - b) / d + (g < b ? 6 : 0)); else if (mx === g) h = (b - r) / d + 2; else h = (r - g) / d + 4;
      h *= 60;
    }
    l = Math.max(l, 0.7); s = Math.min(s, 0.9);
    return 'hsl(' + Math.round(h) + ',' + Math.round(s * 100) + '%,' + Math.round(l * 100) + '%)';
  }
  function gradLight(bi) {
    var re = /rgba?\([^)]*\)/g, m, n = 0, l = 0, sat = 0;
    while ((m = re.exec(bi))) { var c = rgb(m[0]); if (!c) continue; n++; l += c.l; sat = Math.max(sat, c.sat); }
    return n > 0 && l / n > 0.72 && sat < 0.22;
  }

  // ---------------------------------------------------------------- style injection (adopted sheet + <style>: either may be blocked)
  function inject(root, css) {
    try {
      var sh = new window.CSSStyleSheet(); sh.replaceSync(css);
      root.adoptedStyleSheets = Array.prototype.slice.call(root.adoptedStyleSheets || []).concat([sh]);
      ownStyles.push({ root: root, sheet: sh });
    } catch (e) {}
    try {
      var st = document.createElement('style'); st.setAttribute('data-abtin-dark-style', '1'); st.textContent = css;
      (root === document ? (document.head || document.documentElement) : root).appendChild(st);
      ownStyles.push({ el: st });
    } catch (e) {}
  }
  function removeInjected() {
    ownStyles.forEach(function (o) {
      try {
        if (o.el && o.el.parentNode) o.el.parentNode.removeChild(o.el);
        if (o.sheet) o.root.adoptedStyleSheets = Array.prototype.slice.call(o.root.adoptedStyleSheets || []).filter(function (s) { return s !== o.sheet; });
      } catch (e) {}
    });
    ownStyles = [];
  }

  // ---------------------------------------------------------------- tagging one element
  function tag(el) {
    if (!el || el.nodeType !== 1) return;
    var t = el.tagName.toLowerCase();
    if (T_SKIP.test(t)) return;
    if (t === 'img') { maybeImg(el); return; }
    if (T_MEDIA.test(t) || el.namespaceURI === SVGNS) return;
    var cs;
    try { cs = getComputedStyle(el); } catch (e) { return; }
    if (cs.display === 'none') return;
    var bg = rgb(cs.backgroundColor), fg = rgb(cs.color), bd = null;
    if (bg && bg.l > 0.72 && bg.sat < 0.22) el.setAttribute('data-abtin-dark-bg', '1');
    else if (el.hasAttribute('data-abtin-dark-bg')) el.removeAttribute('data-abtin-dark-bg');
    var bi = cs.backgroundImage;
    if (bi && bi.indexOf('gradient') >= 0 && gradLight(bi)) el.setAttribute('data-abtin-dark-grad', '1');
    else if (el.hasAttribute('data-abtin-dark-grad')) el.removeAttribute('data-abtin-dark-grad');
    if (fg && fg.l < 0.42) {
      if (fg.sat >= 0.3) { // coloured text: lighten it, keep the hue
        var v = lighten(fg);
        if (el.style.getPropertyValue('--abtin-c') !== v) { selfEdit.add(el); el.style.setProperty('--abtin-c', v); }
        el.setAttribute('data-abtin-dark-fg', '2');
      } else el.setAttribute('data-abtin-dark-fg', '1');
    } else if (el.hasAttribute('data-abtin-dark-fg')) el.removeAttribute('data-abtin-dark-fg');
    bd = rgb(cs.borderTopColor);
    if (bd && bd.l > 0.68 && bd.sat < 0.2 && cs.borderTopStyle !== 'none') el.setAttribute('data-abtin-dark-border', '1');
    else if (el.hasAttribute('data-abtin-dark-border')) el.removeAttribute('data-abtin-dark-border');
  }

  // ---------------------------------------------------------------- images: logos on white / black glyphs on transparent
  var imgBusy = 0, imgQueue = [], imgCount = 0;
  function maybeImg(img) {
    if (img.__abtinImg) return;
    if (!img.complete || !img.naturalWidth) {
      if (!img.__abtinWait) { img.__abtinWait = true; img.addEventListener('load', function () { img.__abtinWait = false; maybeImg(img); }, { once: true }); }
      return;
    }
    var w = img.clientWidth, h = img.clientHeight;
    if (w < 8 || h < 8 || w > 480 || h > 480 || imgCount > 80) return; // big pictures are photos: leave them alone
    var src = img.currentSrc || img.src;
    if (!/^(https?:|data:image\/)/i.test(src || '') || src.length > 300000) return;
    img.__abtinImg = true; imgCount++;
    imgQueue.push({ img: img, src: src });
    nextImg();
  }
  function nextImg() {
    while (imgBusy < 3 && imgQueue.length) {
      var j = imgQueue.shift(); imgBusy++;
      (function (j) {
        browser.runtime.sendMessage({ t: 'imgKind', url: j.src }).then(function (k) {
          if (on && !skip && k === 'i') j.img.setAttribute('data-abtin-dark-img', '1');
        }).catch(function () {}).then(function () { imgBusy--; nextImg(); });
      })(j);
    }
  }

  // ---------------------------------------------------------------- collecting (incl. shadow roots) and time-sliced work
  function shadowOf(el) { try { return el.openOrClosedShadowRoot || el.shadowRoot || null; } catch (e) { return null; } }
  function collect(root, out) {
    if (root.nodeType === 1) { out.push(root); var s0 = shadowOf(root); if (s0) { hook(s0); collect(s0, out); } }
    var all = root.querySelectorAll ? root.querySelectorAll('*') : [];
    for (var i = 0; i < all.length; i++) {
      var el = all[i]; out.push(el);
      var sr = shadowOf(el);
      if (sr) { hook(sr); collect(sr, out); }
    }
  }
  function hook(sr) {
    if (hooked.has(sr)) return;
    hooked.add(sr);
    inject(sr, SHADOW_CSS);
    try {
      var m = new MutationObserver(onMutations);
      m.observe(sr, { subtree: true, childList: true, attributes: true, attributeFilter: ['style', 'class', 'src', 'srcset'] });
      shadowMo.push(m);
    } catch (e) {}
  }
  function enqueue(root) {
    if (!on || skip) return;
    var list = [];
    try { collect(root, list); } catch (e) {}
    if (work.length - wi > 30000) return;
    for (var i = 0; i < list.length; i++) work.push(list[i]);
    if (!pumping) { pumping = true; pump(); }
  }
  function later(fn) {
    if (window.requestIdleCallback) window.requestIdleCallback(fn, { timeout: 250 }); else setTimeout(fn, 16);
  }
  function pump() {
    var t0 = performance.now();
    while (wi < work.length) {
      if (!on || skip) { work = []; wi = 0; pumping = false; return; }
      tag(work[wi++]);
      if ((wi & 15) === 0 && performance.now() - t0 > 8) { later(pump); return; } // stay under one frame
    }
    work = []; wi = 0; pumping = false;
  }

  function onMutations(records) {
    if (!on || skip) return;
    var now = Date.now();
    for (var i = 0; i < records.length; i++) {
      var r = records[i];
      if (r.type === 'childList') {
        for (var j = 0; j < r.addedNodes.length; j++) { var n = r.addedNodes[j]; if (n.nodeType === 1 && !(n.getAttribute && n.getAttribute('data-abtin-dark-style'))) pendingRoots.add(n); }
      } else if (r.type === 'attributes') {
        var el = r.target;
        if (r.attributeName === 'style' && selfEdit.has(el)) { selfEdit.delete(el); continue; }
        if (r.attributeName === 'src' || r.attributeName === 'srcset') {
          if (el.tagName === 'IMG') { el.__abtinImg = false; el.removeAttribute('data-abtin-dark-img'); pendingRoots.add(el); }
          continue;
        }
        if (el.__abtinT && now - el.__abtinT < 400) continue; // animated styles: do not rescan every frame
        el.__abtinT = now;
        // a class change on <html>/<body> (site theme switch) can recolour everything below it
        pendingRoots.add(el);
        if (el === document.documentElement || el === document.body) pendingRoots.add(el);
      }
    }
    if (!flushTimer && pendingRoots.size) flushTimer = setTimeout(flush, 120);
  }
  function flush() {
    flushTimer = 0;
    var roots = Array.from(pendingRoots); pendingRoots.clear();
    roots.forEach(function (n) { if (n.isConnected) enqueue(n); });
  }

  // ---------------------------------------------------------------- page already dark? (judged without our own pending rule)
  function pageIsDark() {
    var h = document.documentElement;
    try {
      var nodes = [document.body, h];
      for (var i = 0; i < nodes.length; i++) {
        if (!nodes[i]) continue;
        var c = rgb(getComputedStyle(nodes[i]).backgroundColor);
        if (c && c.l < 0.38) return true;
      }
    } catch (e) {}
    return false;
  }

  // ---------------------------------------------------------------- start / stop
  function wanted() {
    var m = cfg.sites && cfg.sites[host];
    return m === 'on' ? true : m === 'off' ? false : !!cfg.forceDark;
  }
  function firstScan() {
    var h = document.documentElement;
    if (!h || !on) return;
    // judge the page WITHOUT our own rules (they paint html/body dark and would always look "already dark")
    h.classList.remove('__abtin_dark_pending', '__abtin_dark');
    skip = isTop ? pageIsDark() : false;
    if (skip) return; // site is dark already: do nothing (classes stay off)
    h.classList.add('__abtin_dark');
    enqueue(h);
    if (!mo) {
      mo = new MutationObserver(onMutations);
      mo.observe(h, { subtree: true, childList: true, attributes: true, attributeFilter: ['style', 'class', 'src', 'srcset'] });
    }
  }
  function start() {
    var h = document.documentElement;
    if (!h) { document.addEventListener('readystatechange', function () { if (wanted() && !on) start(); }, { once: true }); return; }
    on = true; skip = false;
    h.classList.add('__abtin_dark');
    if (isTop) h.classList.add('__abtin_dark_pending'); else h.classList.add('__abtin_dark_sub');
    inject(document, DOC_CSS);
    var go = function () { if (on) firstScan(); };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go, { once: true }); else go();
    // late stylesheets / lazy themes: one more pass (cheap pages only)
    window.addEventListener('load', function () { if (on && !skip && document.getElementsByTagName('*').length < 4000) enqueue(document.documentElement); }, { once: true });
  }
  function stop() {
    on = false; skip = false; work = []; wi = 0; pumping = false; imgQueue = [];
    if (mo) { mo.disconnect(); mo = null; }
    shadowMo.forEach(function (m) { try { m.disconnect(); } catch (e) {} }); shadowMo = []; hooked = new WeakSet();
    removeInjected();
    var h = document.documentElement;
    if (h) h.classList.remove('__abtin_dark', '__abtin_dark_pending', '__abtin_dark_sub');
    try {
      Array.prototype.forEach.call(document.querySelectorAll('[data-abtin-dark-bg],[data-abtin-dark-grad],[data-abtin-dark-fg],[data-abtin-dark-border],[data-abtin-dark-img]'), function (e) {
        ['bg', 'grad', 'fg', 'border', 'img'].forEach(function (k) { e.removeAttribute('data-abtin-dark-' + k); });
        if (e.style && e.style.getPropertyValue('--abtin-c')) e.style.removeProperty('--abtin-c');
        e.__abtinImg = false;
      });
    } catch (e) {}
    imgCount = 0;
  }
  function apply() {
    var w = wanted();
    if (w && !on) start(); else if (!w && on) stop();
  }

  browser.runtime.onMessage.addListener(function (m) {
    if (m && m.cmd === 'forceDark') {
      cfg.forceDark = !!m.on;
      if (m.sites) cfg.sites = m.sites;
      apply();
    }
  });
  browser.runtime.sendMessage({ t: 'getConfig' }).then(function (c) {
    if (!c) return;
    cfg.forceDark = !!c.forceDark;
    cfg.sites = c.darkSites || {};
    apply();
  }).catch(function () {});
})();
