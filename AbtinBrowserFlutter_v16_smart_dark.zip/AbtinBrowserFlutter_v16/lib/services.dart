import 'app_state.dart';
import 'engine/downloads.dart';
import 'engine/ext_manager.dart';
import 'engine/gecko.dart';
import 'engine/google_account.dart';
import 'engine/media_dl.dart';

final app = AppState();
final gecko = Gecko();
final extMgr = ExtensionManager();
final dlMgr = DownloadManager();
final mediaDl = MediaDownloader();
final googleAccount = GoogleAccount();
