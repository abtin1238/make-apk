import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import '../models.dart';
import 'media_dl.dart';
import '../services.dart';

/// Downloads are streamed natively by GeckoView (with the browser's cookies); this class mirrors their state.
class DownloadManager {
  final ValueNotifier<int> tick = ValueNotifier(0);
  int _last = 0;
  void Function(DownloadItem it)? onStarted;
  void Function(DownloadItem it)? onFinished;

  final Map<String, CancelToken> _tokens = {};

  Future<Directory> dir() async {
    final custom = app.str('downloadDir');
    if (custom.isNotEmpty) {
      try { final c = Directory(custom); await c.create(recursive: true); return c; } catch (_) {}
    }
    Directory? base;
    try { base = await getExternalStorageDirectory(); } catch (_) {}
    base ??= await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/Download');
    await d.create(recursive: true);
    return d;
  }

  String cleanName(String n) => _clean(n);
  Future<String> uniquePath(Directory d, String name) => _unique(d, name);

  /// Downloads driven from Dart (HLS, merged tracks): start / progress / end.
  DownloadItem begin(String url, String name, {bool private = false}) {
    final it = DownloadItem(id: 'x${DateTime.now().microsecondsSinceEpoch}', url: url, name: name, private: private);
    app.downloads.insert(0, it);
    onStarted?.call(it);
    _notify(true);
    _native(it, force: true);
    return it;
  }

  CancelToken token(DownloadItem it) => _tokens.putIfAbsent(it.id, () => CancelToken());
  int _lastNative = 0;
  void _native(DownloadItem it, {bool force = false}) {
    if (it.private) return;
    final n = DateTime.now().millisecondsSinceEpoch;
    if (!force && n - _lastNative < 700) return;
    _lastNative = n;
    gecko.call('dlNotify', {'id': it.id, 'name': it.name, 'received': it.received, 'total': it.total, 'status': it.status, 'path': it.path ?? '', 'private': it.private});
  }

  /// Opens a file with another app (own FileProvider). Returns ok | nofile | nohandler | installperm | error.
  Future<String> openPath(String path) async => (await gecko.call<String>('openFile', {'path': path})) ?? 'error';

  void report(DownloadItem it) { _notify(); _native(it); }

  void end(DownloadItem it, String status) {
    it.status = status;
    _tokens.remove(it.id);
    app.saveDownloads();
    onFinished?.call(it);
    _notify(true);
    _native(it, force: true);
  }

  String _clean(String n) {
    final c = n.replaceAll(RegExp(r'[\\/:*?"<>|\x00-\x1f]'), '_').trim();
    return c.isEmpty ? 'download' : (c.length > 120 ? c.substring(c.length - 120) : c);
  }

  Future<String> _unique(Directory d, String name) async {
    var p = '${d.path}/$name';
    if (!await File(p).exists()) return p;
    final dot = name.lastIndexOf('.');
    final base = dot > 0 ? name.substring(0, dot) : name, ext = dot > 0 ? name.substring(dot) : '';
    for (var i = 1; i < 1000; i++) {
      p = '${d.path}/$base ($i)$ext';
      if (!await File(p).exists()) return p;
    }
    return '${d.path}/${DateTime.now().millisecondsSinceEpoch}_$name';
  }

  void _notify([bool force = false]) {
    final n = DateTime.now().millisecondsSinceEpoch;
    if (force || n - _last > 250) { _last = n; tick.value++; }
  }

  /// Event from the native engine: {id,url,name,path,total,received,status,private}.
  void onEvent(Map<String, dynamic> e) {
    final id = '${e['id']}';
    final status = '${e['status']}';
    var it = app.downloads.where((d) => d.id == id).firstOrNull;
    final fresh = it == null;
    if (it == null) {
      it = DownloadItem(
        id: id, url: '${e['url'] ?? ''}', name: '${e['name'] ?? 'download'}', path: e['path'] as String?,
        private: e['private'] == true,
      );
      app.downloads.insert(0, it);
    }
    it.name = '${e['name'] ?? it.name}';
    if (e['path'] != null) it.path = e['path'] as String;
    it.total = (e['total'] as num?)?.toInt() ?? it.total;
    it.received = (e['received'] as num?)?.toInt() ?? it.received;
    it.status = status;
    it.speed = (e['speed'] as num?)?.toDouble() ?? 0;
    it.conns = (e['conns'] as num?)?.toInt() ?? it.conns;
    it.resumable = e['resumable'] == true;
    if (fresh && status == 'running') onStarted?.call(it);
    if (status != 'running') {
      app.saveDownloads();
      if (status != 'paused') onFinished?.call(it);
      _notify(true);
    } else {
      _notify();
    }
  }

  Future<void> start(String url, {String? name, String? referer, bool private = false}) async {
    if (url.startsWith('data:')) {
      final d = await dir();
      final i = url.indexOf(',');
      if (i < 0) return;
      final meta = url.substring(5, i);
      final bytes = meta.contains(';base64') ? base64Decode(url.substring(i + 1)) : utf8.encode(Uri.decodeComponent(url.substring(i + 1)));
      final path = await _unique(d, _clean(name ?? 'data.${meta.split(';').first.split('/').last}'));
      await File(path).writeAsBytes(bytes);
      final it = DownloadItem(id: '${DateTime.now().microsecondsSinceEpoch}', url: 'data:', name: path.split('/').last, path: path, total: bytes.length, received: bytes.length, status: 'done', private: private);
      app.downloads.insert(0, it);
      app.saveDownloads();
      _notify(true);
      onFinished?.call(it);
      return;
    }
    if (!url.startsWith('http')) return;
    await gecko.call('download', {'url': url, 'referer': referer ?? '', 'name': name ?? '', 'private': private});
  }

  /// Registers a finished local file (saved page) in the downloads list.
  DownloadItem _addDone(String path, int size, String url, bool private) {
    final it = DownloadItem(id: 'x${DateTime.now().microsecondsSinceEpoch}', url: url, name: path.split('/').last, path: path, total: size, received: size, status: 'done', private: private);
    app.downloads.insert(0, it);
    app.saveDownloads();
    _notify(true);
    onFinished?.call(it);
    return it;
  }

  String _pageName(String title, String url, String ext) {
    var base = title.trim();
    if (base.isEmpty) base = hostOf(url);
    if (base.isEmpty) base = 'page';
    return '${_clean(base)}.$ext';
  }

  /// Saves the page as a PDF file in the download folder. Returns true on success.
  Future<bool> savePagePdf(int tabId, String title, String url, {bool private = false}) async {
    final d = await dir();
    final path = await _unique(d, _pageName(title, url, 'pdf'));
    final ok = await gecko.call<bool>('savePdf', {'id': tabId, 'path': path}) == true;
    if (!ok) return false;
    int size = 0;
    try { size = await File(path).length(); } catch (_) {}
    _addDone(path, size, url, private);
    return true;
  }

  /// Receives the self-contained HTML built by the page script ({url,title,html}).
  Future<bool> onPageHtml(Map<String, dynamic> e, {bool private = false}) async {
    final html = '${e['html'] ?? ''}';
    if (html.isEmpty) return false;
    final url = '${e['url'] ?? ''}';
    try {
      final d = await dir();
      final path = await _unique(d, _pageName('${e['title'] ?? ''}', url, 'html'));
      final bytes = utf8.encode(html);
      await File(path).writeAsBytes(bytes);
      _addDone(path, bytes.length, url, private);
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Notification buttons (Pause / Resume / Cancel).
  void onAction(String id, String action) {
    final it = app.downloads.where((d) => d.id == id).firstOrNull;
    if (it == null) return;
    switch (action) {
      case 'pause': pause(it);
      case 'resume': if (it.status == 'failed') { retry(it); } else { resume(it); }
      case 'cancel': cancel(it);
    }
  }

  void pause(DownloadItem it) {
    if (!it.canPause) return;
    gecko.call('pauseDownload', {'id': it.id});
  }

  /// Continues a paused/failed download from the bytes already on disk (native manager) instead of starting over.
  void resume(DownloadItem it) {
    if (!it.native) return;
    it.status = 'running';
    _notify(true);
    gecko.call('resumeDownload', {'id': it.id, 'url': it.url, 'name': it.name, 'path': it.path ?? '', 'private': it.private});
  }

  Future<void> retry(DownloadItem it) async {
    if (it.native && it.path != null && it.url.startsWith('http') && !it.url.toLowerCase().split('?').first.endsWith('.m3u8')) { resume(it); return; }
    app.downloads.remove(it);
    app.saveDownloads();
    _notify(true);
    if (it.url.toLowerCase().split('?').first.endsWith('.m3u8')) {
      final v = await mediaDl.variants(it.url).catchError((_) => <HlsVariant>[]);
      if (v.isNotEmpty) await mediaDl.hls(v.first, title: it.name.replaceAll(RegExp(r'\.[A-Za-z0-9]{2,4}$'), ''), private: it.private);
      return;
    }
    await start(it.url, name: it.name, private: it.private);
  }

  void cancel(DownloadItem it) {
    if (it.status != 'running' && it.status != 'paused') return;
    final t = _tokens[it.id];
    if (t != null) { t.cancel(); return; }
    gecko.call('cancelDownload', {'id': it.id, 'path': it.path ?? ''});
  }

  Future<void> remove(DownloadItem it, {bool deleteFile = false}) async {
    cancel(it);
    if (deleteFile && it.path != null) { try { await File(it.path!).delete(); } catch (_) {} }
    app.downloads.remove(it);
    app.saveDownloads();
    _notify(true);
  }
}
