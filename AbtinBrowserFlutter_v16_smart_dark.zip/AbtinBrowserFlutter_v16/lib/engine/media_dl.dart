import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:pointycastle/export.dart';
import '../models.dart';
import '../services.dart';

class HlsVariant {
  HlsVariant(this.url, this.bandwidth, this.width, this.height, this.audioUrl);
  final String url;
  final int bandwidth, width, height;
  final String? audioUrl;

  String get label {
    final q = height > 0 ? '${height}p' : (width > 0 ? '${width}w' : '');
    final kb = bandwidth > 0 ? '${(bandwidth / 1000).round()} kbps' : '';
    final s = [q, kb].where((e) => e.isNotEmpty).join(' · ');
    return s.isEmpty ? 'Auto' : s;
  }
}

class _Seg {
  _Seg(this.url, this.seq, this.keyUri, this.iv, this.mapUri);
  final String url;
  final int seq;
  final String? keyUri, iv, mapUri;
}

class _Pl {
  final List<_Seg> segs = [];
  bool live = false, unsupported = false;
}

class _Prog {
  int bytes = 0, done = 0, all = 0;
}

class _Res {
  _Res(this.data, this.err);
  final Uint8List? data;
  final Object? err;
}

/// Downloads that are driven from Dart: HLS playlists (incl. AES-128) and separate video+audio tracks.
/// Results are remuxed to MP4 by the native side (MediaMuxer, no re-encoding).
class MediaDownloader {
  final Dio _dio = Dio();

  Map<String, dynamic> _headers(String referer) => {
        if (referer.startsWith('http')) 'Referer': referer,
        if (gecko.defaultUA.isNotEmpty) 'User-Agent': gecko.defaultUA,
      };

  String _abs(String base, String ref) => Uri.parse(base).resolve(ref).toString();
  String _after(String l) => l.substring(l.indexOf(':') + 1);

  Map<String, String> _attrs(String s) {
    final out = <String, String>{};
    for (final m in RegExp(r'([A-Z0-9-]+)=("[^"]*"|[^,]*)').allMatches(s)) {
      var v = m.group(2)!;
      if (v.startsWith('"') && v.length >= 2) v = v.substring(1, v.length - 1);
      out[m.group(1)!] = v;
    }
    return out;
  }

  Future<String> _text(String url, String referer) async {
    final r = await _dio.get<String>(url, options: Options(responseType: ResponseType.plain, headers: _headers(referer), receiveTimeout: const Duration(seconds: 30)));
    return r.data ?? '';
  }

  Future<Uint8List> _get(String url, String referer, CancelToken tok) async {
    Object? last;
    for (var i = 0; i < 4; i++) {
      try {
        final r = await _dio.get<List<int>>(url, cancelToken: tok, options: Options(responseType: ResponseType.bytes, headers: _headers(referer), receiveTimeout: const Duration(seconds: 40)));
        return Uint8List.fromList(r.data ?? const <int>[]);
      } catch (e) {
        if (e is DioException && CancelToken.isCancel(e)) rethrow;
        last = e;
        await Future<void>.delayed(Duration(milliseconds: 400 * (i + 1)));
      }
    }
    throw last ?? Exception('fetch failed');
  }

  /// Qualities of a master playlist (best first). A plain media playlist returns a single entry.
  Future<List<HlsVariant>> variants(String url, {String referer = ''}) async {
    final txt = await _text(url, referer);
    if (!txt.contains('#EXT-X-STREAM-INF')) return [HlsVariant(url, 0, 0, 0, null)];
    final lines = const LineSplitter().convert(txt);
    final audio = <String, String>{};
    for (final l in lines) {
      if (!l.startsWith('#EXT-X-MEDIA:')) continue;
      final a = _attrs(_after(l));
      if (a['TYPE'] == 'AUDIO' && a['URI'] != null) {
        final g = a['GROUP-ID'] ?? '';
        if (!audio.containsKey(g) || a['DEFAULT'] == 'YES') audio[g] = _abs(url, a['URI']!);
      }
    }
    final out = <HlsVariant>[];
    for (var i = 0; i < lines.length; i++) {
      if (!lines[i].startsWith('#EXT-X-STREAM-INF:')) continue;
      final a = _attrs(_after(lines[i]));
      var j = i + 1;
      while (j < lines.length && (lines[j].trim().isEmpty || lines[j].startsWith('#'))) {
        j++;
      }
      if (j >= lines.length) break;
      final res = (a['RESOLUTION'] ?? '').split('x');
      out.add(HlsVariant(
        _abs(url, lines[j].trim()),
        int.tryParse(a['BANDWIDTH'] ?? a['AVERAGE-BANDWIDTH'] ?? '') ?? 0,
        res.length == 2 ? int.tryParse(res[0]) ?? 0 : 0,
        res.length == 2 ? int.tryParse(res[1]) ?? 0 : 0,
        audio[a['AUDIO'] ?? ''],
      ));
    }
    out.sort((a, b) => b.bandwidth.compareTo(a.bandwidth));
    return out.isEmpty ? [HlsVariant(url, 0, 0, 0, null)] : out;
  }

  Future<_Pl> _playlist(String url, String referer) async {
    final txt = await _text(url, referer);
    final pl = _Pl()..live = !txt.contains('#EXT-X-ENDLIST');
    var seq = 0;
    String? keyUri, iv, mapUri;
    for (final raw in const LineSplitter().convert(txt)) {
      final l = raw.trim();
      if (l.isEmpty) continue;
      if (l.startsWith('#EXT-X-MEDIA-SEQUENCE:')) {
        seq = int.tryParse(_after(l).trim()) ?? 0;
      } else if (l.startsWith('#EXT-X-KEY:')) {
        final a = _attrs(_after(l));
        final method = a['METHOD'];
        if (method == 'NONE') {
          keyUri = null;
          iv = null;
        } else if (method == 'AES-128' && a['URI'] != null) {
          keyUri = _abs(url, a['URI']!);
          iv = a['IV'];
        } else {
          pl.unsupported = true;
        }
      } else if (l.startsWith('#EXT-X-MAP:')) {
        final a = _attrs(_after(l));
        if (a['URI'] != null) mapUri = _abs(url, a['URI']!);
        if (a.containsKey('BYTERANGE')) pl.unsupported = true;
      } else if (l.startsWith('#EXT-X-BYTERANGE')) {
        pl.unsupported = true;
      } else if (l.startsWith('#')) {
        continue;
      } else {
        pl.segs.add(_Seg(_abs(url, l), seq, keyUri, iv, mapUri));
        seq++;
      }
    }
    return pl;
  }

  Uint8List _decrypt(Uint8List data, Uint8List key, String? ivHex, int seq) {
    final iv = Uint8List(16);
    if (ivHex != null && ivHex.length > 2) {
      var h = ivHex.toLowerCase().startsWith('0x') ? ivHex.substring(2) : ivHex;
      h = h.padLeft(32, '0');
      for (var i = 0; i < 16; i++) {
        iv[i] = int.parse(h.substring(i * 2, i * 2 + 2), radix: 16);
      }
    } else {
      var s = seq;
      for (var i = 15; i >= 8 && s > 0; i--) {
        iv[i] = s & 0xff;
        s >>= 8;
      }
    }
    final c = CBCBlockCipher(AESEngine())..init(false, ParametersWithIV(KeyParameter(key), iv));
    final out = Uint8List(data.length);
    for (var off = 0; off + 16 <= data.length; off += 16) {
      c.processBlock(data, off, out, off);
    }
    if (out.isEmpty) return out;
    final pad = out.last;
    return (pad >= 1 && pad <= 16 && pad <= out.length) ? Uint8List.sublistView(out, 0, out.length - pad) : out;
  }

  Future<void> _fetchPlaylist(_Pl pl, String referer, File out, _Prog p, DownloadItem it, CancelToken tok) async {
    final sink = out.openWrite();
    try {
      final keys = <String, Uint8List>{};
      final n = pl.segs.length;
      final win = <int, Future<_Res>>{};
      var next = 0;
      String? lastMap;

      Future<_Res> fetch(int i) async {
        try {
          final s = pl.segs[i];
          var b = await _get(s.url, referer, tok);
          if (s.keyUri != null) {
            final k = keys[s.keyUri!] ?? await _get(s.keyUri!, referer, tok);
            keys[s.keyUri!] = k;
            b = _decrypt(b, k, s.iv, s.seq);
          }
          return _Res(b, null);
        } catch (e) {
          return _Res(null, e);
        }
      }

      for (var i = 0; i < n; i++) {
        if (tok.isCancelled) throw StateError('canceled');
        while (next < n && win.length < 4) {
          win[next] = fetch(next);
          next++;
        }
        final s = pl.segs[i];
        if (s.mapUri != null && s.mapUri != lastMap) {
          lastMap = s.mapUri;
          sink.add(await _get(s.mapUri!, referer, tok));
        }
        final r = await win.remove(i)!;
        if (r.err != null) throw r.err!;
        sink.add(r.data!);
        p.bytes += r.data!.length;
        p.done++;
        it.received = p.bytes;
        it.total = p.done > 0 && p.all > 0 ? (p.bytes * p.all / p.done).round() : -1;
        dlMgr.report(it);
      }
    } finally {
      await sink.close();
    }
  }

  Future<void> _deleteAll(List<File> fs) async {
    for (final f in fs) {
      try {
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
  }

  /// Download an HLS stream (chosen quality) and save it as MP4 (or raw .ts / fMP4 when remuxing is not possible).
  Future<void> hls(HlsVariant v, {String referer = '', String title = 'video', bool private = false}) async {
    final base = dlMgr.cleanName(title.isEmpty ? 'video' : title);
    final it = dlMgr.begin(v.url, '$base.mp4', private: private);
    final tok = dlMgr.token(it);
    final dir = await dlMgr.dir();
    final vf = File('${dir.path}/.${it.id}_v.bin');
    final af = File('${dir.path}/.${it.id}_a.bin');
    var status = 'done';
    String? out;
    try {
      final vp = await _playlist(v.url, referer);
      if (vp.live) throw StateError('live');
      if (vp.unsupported || vp.segs.isEmpty) throw StateError('unsupported');
      _Pl? ap;
      if (v.audioUrl != null) {
        ap = await _playlist(v.audioUrl!, referer);
        if (ap.live || ap.unsupported || ap.segs.isEmpty) ap = null;
      }
      final p = _Prog()..all = vp.segs.length + (ap?.segs.length ?? 0);
      await _fetchPlaylist(vp, referer, vf, p, it, tok);
      if (ap != null) await _fetchPlaylist(ap, referer, af, p, it, tok);

      final fmp4 = vp.segs.first.mapUri != null;
      out = await dlMgr.uniquePath(dir, '$base.mp4');
      final ok = await gecko.call<bool>('mux', {'inputs': [vf.path, if (ap != null) af.path], 'out': out}) == true;
      if (!ok) {
        try {
          final f = File(out);
          if (await f.exists()) await f.delete();
        } catch (_) {}
        out = await dlMgr.uniquePath(dir, fmp4 ? '$base.mp4' : '$base.ts');
        await vf.rename(out);
      }
      final len = await File(out).length();
      it.path = out;
      it.name = out.split('/').last;
      it.total = len;
      it.received = len;
    } catch (e) {
      status = tok.isCancelled ? 'canceled' : 'failed';
    } finally {
      await _deleteAll([vf, af]);
    }
    dlMgr.end(it, status);
  }

  /// Video-only + audio-only files (DASH style, e.g. Instagram / YouTube) -> one MP4 with sound.
  Future<void> merge(MediaItem v, MediaItem a, {String referer = '', String title = 'video', bool private = false}) async {
    final base = dlMgr.cleanName(title.isEmpty ? 'video' : title);
    final it = dlMgr.begin(v.url, '$base.mp4', private: private);
    final tok = dlMgr.token(it);
    final dir = await dlMgr.dir();
    final vf = File('${dir.path}/.${it.id}_v.bin');
    final af = File('${dir.path}/.${it.id}_a.bin');
    var status = 'done';
    String? out;
    try {
      final total = (v.size > 0 && a.size > 0) ? v.size + a.size : -1;
      await _dio.download(v.url, vf.path, cancelToken: tok, options: Options(headers: _headers(referer)), onReceiveProgress: (r, t) {
        it.received = r;
        it.total = total;
        dlMgr.report(it);
      });
      final vlen = await vf.length();
      await _dio.download(a.url, af.path, cancelToken: tok, options: Options(headers: _headers(referer)), onReceiveProgress: (r, t) {
        it.received = vlen + r;
        it.total = total;
        dlMgr.report(it);
      });
      final webm = v.ext == 'webm' || a.ext == 'weba';
      out = await dlMgr.uniquePath(dir, '$base.${webm ? 'webm' : 'mp4'}');
      final ok = await gecko.call<bool>('mux', {'inputs': [vf.path, af.path], 'out': out}) == true;
      if (!ok) {
        try {
          final f = File(out);
          if (await f.exists()) await f.delete();
        } catch (_) {}
        out = await dlMgr.uniquePath(dir, '$base.${v.ext}');
        await vf.rename(out);
      }
      final len = await File(out).length();
      it.path = out;
      it.name = out.split('/').last;
      it.total = len;
      it.received = len;
    } catch (e) {
      status = tok.isCancelled ? 'canceled' : 'failed';
    } finally {
      await _deleteAll([vf, af]);
    }
    dlMgr.end(it, status);
  }
}
