# Flutter / plugin glue
-dontwarn com.google.android.play.core.**
-keep class ir.abtin.** { *; }
# GeckoView ships its own consumer rules (JNI / @WrapForJNI), nothing extra needed here.
