package ir.abtin.sms

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.ParcelFileDescriptor
import androidx.compose.runtime.mutableIntStateOf
import rikka.shizuku.Shizuku
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * App-side client of the privileged call recorder (see ShellRecService).
 *
 * Android only lets the shell/root/system uid capture the call stream (AudioSource.VOICE_CALL needs
 * CAPTURE_AUDIO_OUTPUT). Shizuku — started once through ADB, wireless debugging or root — gives this app
 * a helper process running as that uid, and the helper does the actual recording.
 */
object ShizukuRec {
    const val PKG = "moe.shizuku.privileged.api"
    private const val REQ_CODE = 7301
    private const val SERVICE_VERSION = 1

    /** Bumped whenever Shizuku availability / permission / connection changes, so Compose can refresh. */
    val tick = mutableIntStateOf(0)

    @Volatile private var svc: IRecService? = null
    @Volatile private var latch: CountDownLatch? = null
    @Volatile private var bound = false
    private var inited = false
    private val main = Handler(Looper.getMainLooper())

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder != null && binder.pingBinder()) {
                svc = IRecService.Stub.asInterface(binder)
                tick.intValue++
                latch?.countDown()
            }
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            svc = null; bound = false
            tick.intValue++
        }
    }

    private var userServiceArgs: Shizuku.UserServiceArgs? = null
    private fun args(ctx: Context): Shizuku.UserServiceArgs =
        userServiceArgs ?: Shizuku.UserServiceArgs(ComponentName(ctx.packageName, ShellRecService::class.java.name))
            .daemon(false)
            .processNameSuffix("rec")
            .debuggable(false)
            .version(SERVICE_VERSION)
            .also { userServiceArgs = it }

    private lateinit var appCtx: Context

    @Synchronized fun init(c: Context) {
        if (inited) return
        inited = true
        appCtx = c.applicationContext
        runCatching {
            Shizuku.addBinderReceivedListenerSticky { tick.intValue++ }
            Shizuku.addBinderDeadListener { svc = null; bound = false; tick.intValue++ }
            Shizuku.addRequestPermissionResultListener { _, _ -> tick.intValue++ }
        }.onFailure { AppLog.i(c, "Shizuku listeners failed", it) }
    }

    // ------------------------------------------------------------------ status
    fun installed(c: Context): Boolean = runCatching { c.packageManager.getPackageInfo(PKG, 0); true }.getOrDefault(false)

    /** Shizuku is installed AND its server is running (binder received). */
    fun running(): Boolean = runCatching { Shizuku.pingBinder() }.getOrDefault(false)

    fun granted(): Boolean = running() && runCatching {
        !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    /** True when the user denied the request with "don't ask again" — permission must then be granted inside the Shizuku app. */
    fun deniedForever(): Boolean = running() && runCatching { Shizuku.shouldShowRequestPermissionRationale() }.getOrDefault(false)

    fun requestPermission() { runCatching { Shizuku.requestPermission(REQ_CODE) } }

    /** "ADB" for uid 2000, "root" for 0. */
    fun mode(): String = runCatching { if (Shizuku.getUid() == 0) "root" else "ADB" }.getOrDefault("?")

    fun statusText(c: Context): String {
        tick.intValue // read for recomposition
        return when {
            !installed(c) -> tr("Shizuku نصب نیست — لمس برای دریافت", "Shizuku is not installed — tap to get it")
            !running() -> tr("Shizuku اجرا نیست — لمس برای باز کردن برنامه و روشن کردن (ADB / دیباگ بی‌سیم / روت)", "Shizuku is not running — tap to open it and start it (ADB / wireless debugging / root)")
            granted() -> tr("✓ آماده (${mode()})", "✓ Ready (${mode()})")
            deniedForever() -> tr("مجوز رد شده — در برنامهٔ Shizuku به آبتین دسترسی بدهید", "Permission denied — allow Abtin inside the Shizuku app")
            else -> tr("مجوز داده نشده — لمس برای درخواست", "Permission not granted — tap to request")
        }
    }

    /** What the settings row does when tapped, depending on the current state. */
    fun onStatusClick(c: Context) {
        when {
            !installed(c) -> runCatching {
                c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            !running() || deniedForever() -> openShizuku(c)
            !granted() -> requestPermission()
            else -> {}
        }
    }

    fun openShizuku(c: Context) {
        runCatching {
            c.startActivity(c.packageManager.getLaunchIntentForPackage(PKG)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    // ------------------------------------------------------------------ connection
    private fun bindAsync(c: Context) {
        if (svc != null || bound || !granted()) return
        bound = true
        main.post {
            runCatching { Shizuku.bindUserService(args(c), conn) }.onFailure {
                bound = false
                AppLog.i(c, "Shizuku bindUserService failed", it)
            }
        }
    }

    /** Call as early as possible (e.g. when a call appears) so the helper process is already up when recording starts. */
    fun warmUp(c: Context) { if (granted()) bindAsync(c.applicationContext) }

    private fun awaitService(c: Context, seconds: Long): IRecService? {
        svc?.let { return it }
        val l = CountDownLatch(1)
        latch = l
        bindAsync(c)
        svc?.let { return it }
        l.await(seconds, TimeUnit.SECONDS)
        return svc
    }

    // ------------------------------------------------------------------ recording (blocking: use a background thread)
    /** Returns null on success, otherwise a human-readable reason. */
    fun startRecording(c: Context, file: File): String? {
        if (!granted()) return "Shizuku is not ready"
        val s = awaitService(c, 5) ?: return "Shizuku helper process did not start"
        val pfd = try {
            ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_WRITE or ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE)
        } catch (t: Throwable) { return "cannot open output file: $t" }
        val r = try { s.start(pfd, 0) } catch (t: Throwable) { "ERR binder: $t" } finally { runCatching { pfd.close() } }
        AppLog.i(c, "Shizuku rec start -> $r")
        return if (r != null && r.startsWith("OK")) null else (r ?: "no answer")
    }

    /** Returns the helper's summary ("OK src=.. frames=.. peak=..") or an error string. */
    fun stopRecording(c: Context): String {
        val s = svc ?: return "ERR service gone"
        val r = try { s.stop() ?: "ERR no answer" } catch (t: Throwable) { "ERR binder: $t" }
        AppLog.i(c, "Shizuku rec stop -> $r")
        return r
    }

    /** Frames/peak parsed from stopRecording(): true when audio was actually captured (not digital silence). */
    fun hasAudio(summary: String): Boolean {
        val peak = Regex("peak=(\\d+)").find(summary)?.groupValues?.get(1)?.toIntOrNull() ?: return false
        val frames = Regex("frames=(\\d+)").find(summary)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
        return frames > 0 && peak >= 8
    }

    /** Settings self-test (blocking). */
    fun selfTest(c: Context): String {
        if (!installed(c)) return "Shizuku is not installed."
        if (!running()) return "Shizuku is installed but not running."
        if (!granted()) return "Shizuku permission is not granted to Abtin."
        val s = awaitService(c, 6) ?: return "Shizuku helper process did not start (check the Debug log)."
        return try { s.diagnose() ?: "no answer" } catch (t: Throwable) { "binder error: $t" }
    }
}
