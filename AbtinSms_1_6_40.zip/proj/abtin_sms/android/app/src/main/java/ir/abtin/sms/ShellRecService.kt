package ir.abtin.sms

import android.app.Application
import android.content.AttributionSource
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ApplicationInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.Process
import java.io.FileDescriptor
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.abs
import kotlin.math.max
import kotlin.system.exitProcess

/**
 * Call recorder that runs OUTSIDE the app, in the privileged process Shizuku starts (shell uid 2000 via
 * ADB / wireless debugging, or root). The shell uid holds CAPTURE_AUDIO_OUTPUT, the permission Android
 * requires for AudioSource.VOICE_CALL / VOICE_UPLINK / VOICE_DOWNLINK, which a normal app can never get.
 *
 * Shizuku instantiates this class by name with its no-argument constructor.
 */
class ShellRecService : IRecService.Stub() {

    private class Session(val out: ParcelFileDescriptor, val desc: String, val rate: Int) {
        @Volatile var running = true
        @Volatile var peak = 0
        @Volatile var frames = 0L
        @Volatile var error = ""
        val threads = ArrayList<Thread>()
        val records = ArrayList<AudioRecord>()
        var writer: AacWriter? = null
    }

    private val lock = Any()
    private var session: Session? = null

    override fun destroy() {
        runCatching { stop() }
        exitProcess(0)
    }

    override fun isRecording(): Boolean = synchronized(lock) { session != null }

    override fun start(fd: ParcelFileDescriptor?, mode: Int): String {
        synchronized(lock) {
            if (session != null) return "ERR already recording"
            if (fd == null) return "ERR no output file"
            if (Build.VERSION.SDK_INT < 26) return "ERR Android 8+ required for the shell recorder"
            val log = StringBuilder()
            ShellEnv.prepare(log)
            val ctx = ShellEnv.context()

            // 1) The call mix (both sides) in one stream.
            for (rate in RATES) {
                val rec = open(SRC_VOICE_CALL, rate, ctx, log) ?: continue
                val s = Session(fd, "VOICE_CALL@$rate", rate)
                if (begin(s, listOf(rec), log)) { session = s; return "OK ${s.desc}" }
            }
            // 2) Some devices only expose the two directions separately: record both and mix them.
            for (rate in RATES) {
                val up = open(SRC_VOICE_UPLINK, rate, ctx, log) ?: continue
                val down = open(SRC_VOICE_DOWNLINK, rate, ctx, log)
                if (down == null) { runCatching { up.release() }; continue }
                val s = Session(fd, "UPLINK+DOWNLINK@$rate", rate)
                if (begin(s, listOf(up, down), log)) { session = s; return "OK ${s.desc}" }
            }
            return "ERR $log"
        }
    }

    override fun stop(): String {
        val s = synchronized(lock) { val x = session; session = null; x } ?: return "ERR not recording"
        s.running = false
        s.records.forEach { runCatching { it.stop() } }
        s.threads.forEach { runCatching { it.join(3000) } }
        s.records.forEach { runCatching { it.release() } }
        val werr = runCatching { s.writer?.finish() }.exceptionOrNull()
        runCatching { s.out.close() }
        return "OK src=${s.desc} frames=${s.frames} peak=${s.peak}" +
            (if (s.error.isNotEmpty()) " readError=${s.error}" else "") +
            (if (werr != null) " writerError=$werr" else "")
    }

    override fun diagnose(): String {
        val sb = StringBuilder()
        sb.appendLine("uid=${Process.myUid()} pid=${Process.myPid()} sdk=${Build.VERSION.SDK_INT} ${Build.MANUFACTURER} ${Build.MODEL}")
        val log = StringBuilder()
        ShellEnv.prepare(log)
        sb.appendLine("env: ${ShellEnv.status()}")
        if (log.isNotEmpty()) sb.appendLine(log.toString().trim())
        val ctx = ShellEnv.context()
        val names = mapOf(SRC_VOICE_CALL to "VOICE_CALL", SRC_VOICE_UPLINK to "VOICE_UPLINK", SRC_VOICE_DOWNLINK to "VOICE_DOWNLINK")
        for ((src, name) in names) {
            var ok = ""
            val l = StringBuilder()
            for (rate in RATES) {
                val r = open(src, rate, ctx, l)
                if (r != null) { ok = "opened @${rate}Hz"; runCatching { r.release() }; break }
            }
            sb.appendLine("$name: ${if (ok.isNotEmpty()) ok else "FAILED " + l.toString().trim()}")
        }
        sb.appendLine("(Opening can succeed even if no call is active; the real test is recording during a call.)")
        return sb.toString()
    }

    // ---------------------------------------------------------------- internals
    private fun open(source: Int, rate: Int, ctx: Context?, log: StringBuilder): AudioRecord? {
        val ch = AudioFormat.CHANNEL_IN_MONO
        val enc = AudioFormat.ENCODING_PCM_16BIT
        val min = AudioRecord.getMinBufferSize(rate, ch, enc)
        if (min <= 0) { log.append("src$source@$rate minBuffer=$min; "); return null }
        return try {
            val b = AudioRecord.Builder()
                .setAudioSource(source)
                .setAudioFormat(AudioFormat.Builder().setEncoding(enc).setSampleRate(rate).setChannelMask(ch).build())
                .setBufferSizeInBytes(max(min * 4, rate))
            if (Build.VERSION.SDK_INT >= 31 && ctx != null) b.setContext(ctx)
            val r = b.build()
            if (r.state != AudioRecord.STATE_INITIALIZED) {
                log.append("src$source@$rate not initialized; ")
                runCatching { r.release() }
                null
            } else r
        } catch (t: Throwable) {
            log.append("src$source@$rate ${t.javaClass.simpleName}: ${t.message}; ")
            null
        }
    }

    /** Starts the recorders, the AAC writer and the reader thread(s). Releases everything on failure. */
    private fun begin(s: Session, recs: List<AudioRecord>, log: StringBuilder): Boolean {
        try {
            s.writer = AacWriter(s.out.fileDescriptor, s.rate)
            s.records.addAll(recs)
            recs.forEach { it.startRecording() }
            if (recs.any { it.recordingState != AudioRecord.RECORDSTATE_RECORDING }) {
                log.append("${s.desc} did not enter RECORDING state; ")
                abort(s); return false
            }
        } catch (t: Throwable) {
            log.append("${s.desc} start: ${t.javaClass.simpleName}: ${t.message}; ")
            abort(s); return false
        }
        val chunk = s.rate / 25 // 40 ms
        if (recs.size == 1) {
            val rec = recs[0]
            s.threads.add(Thread({
                val buf = ShortArray(chunk)
                while (s.running) {
                    val n = rec.read(buf, 0, chunk)
                    if (n < 0) { if (s.running) s.error = "read=$n"; break }
                    if (n > 0) emit(s, buf, n)
                }
            }, "abtin-rec"))
        } else {
            val queues = recs.map { ConcurrentLinkedQueue<ShortArray>() }
            recs.forEachIndexed { i, rec ->
                s.threads.add(Thread({
                    while (s.running) {
                        val a = ShortArray(chunk)
                        val n = rec.read(a, 0, chunk)
                        if (n < 0) { if (s.running) s.error = "read$i=$n"; break }
                        if (n > 0) queues[i].add(if (n == chunk) a else a.copyOf(n))
                    }
                }, "abtin-rec-$i"))
            }
            s.threads.add(Thread({
                val a = queues[0]; val b = queues[1]
                while (s.running || a.isNotEmpty() || b.isNotEmpty()) {
                    val x = a.peek(); val y = b.peek()
                    when {
                        x != null && y != null -> { a.poll(); b.poll(); mix(s, x, y) }
                        x != null && a.size > 6 -> { a.poll(); mix(s, x, null) }
                        y != null && b.size > 6 -> { b.poll(); mix(s, y, null) }
                        !s.running && (x != null || y != null) -> { a.poll(); b.poll(); mix(s, x ?: y!!, null) }
                        else -> try { Thread.sleep(5) } catch (_: InterruptedException) { }
                    }
                }
            }, "abtin-mix"))
        }
        s.threads.forEach { it.start() }
        return true
    }

    private fun mix(s: Session, x: ShortArray, y: ShortArray?) {
        val n = max(x.size, y?.size ?: 0)
        val out = ShortArray(n)
        for (i in 0 until n) {
            val v = (if (i < x.size) x[i].toInt() else 0) + (if (y != null && i < y.size) y[i].toInt() else 0)
            out[i] = v.coerceIn(-32768, 32767).toShort()
        }
        emit(s, out, n)
    }

    private fun emit(s: Session, buf: ShortArray, n: Int) {
        var p = s.peak
        for (i in 0 until n) { val a = abs(buf[i].toInt()); if (a > p) p = a }
        s.peak = p
        s.frames += n
        runCatching { s.writer?.write(buf, n) }.onFailure { s.error = "write: $it" }
    }

    private fun abort(s: Session) {
        s.records.forEach { runCatching { it.stop() }; runCatching { it.release() } }
        s.records.clear()
        runCatching { s.writer?.abort() }
        s.writer = null
    }

    companion object {
        const val SRC_VOICE_UPLINK = 2
        const val SRC_VOICE_DOWNLINK = 3
        const val SRC_VOICE_CALL = 4
        val RATES = intArrayOf(16000, 48000, 44100, 8000)
    }
}

/** Mono 16-bit PCM -> AAC-LC in an MP4 (.m4a) written to a file descriptor. */
internal class AacWriter(fd: FileDescriptor, private val rate: Int) {
    private val codec: MediaCodec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
    private val muxer = MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private val info = MediaCodec.BufferInfo()
    private var track = -1
    private var muxStarted = false
    private var samples = 0L
    private var finished = false

    init {
        val f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1)
        f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
        f.setInteger(MediaFormat.KEY_BIT_RATE, 64_000)
        f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16_384)
        codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
    }

    @Synchronized fun write(pcm: ShortArray, n: Int) {
        if (finished) return
        var off = 0
        while (off < n) {
            val idx = codec.dequeueInputBuffer(10_000)
            if (idx < 0) { drain(0); continue }
            val buf = codec.getInputBuffer(idx) ?: continue
            buf.clear()
            val chunk = minOf(n - off, buf.remaining() / 2)
            buf.order(ByteOrder.nativeOrder()).asShortBuffer().put(pcm, off, chunk)
            codec.queueInputBuffer(idx, 0, chunk * 2, samples * 1_000_000L / rate, 0)
            samples += chunk
            off += chunk
            drain(0)
        }
    }

    @Synchronized fun finish() {
        if (finished) return
        finished = true
        try {
            var idx = codec.dequeueInputBuffer(200_000)
            var tries = 0
            while (idx < 0 && tries++ < 10) { drain(0); idx = codec.dequeueInputBuffer(100_000) }
            if (idx >= 0) codec.queueInputBuffer(idx, 0, 0, samples * 1_000_000L / rate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            var n = 0
            while (n++ < 100 && !drain(20_000)) { /* wait for end of stream */ }
        } finally {
            runCatching { codec.stop() }
            runCatching { codec.release() }
            if (muxStarted) runCatching { muxer.stop() }
            runCatching { muxer.release() }
        }
    }

    @Synchronized fun abort() {
        finished = true
        runCatching { codec.stop() }
        runCatching { codec.release() }
        runCatching { muxer.release() }
    }

    /** Pulls encoded frames into the muxer. Returns true once the end-of-stream frame was seen. */
    private fun drain(timeoutUs: Long): Boolean {
        while (true) {
            val o = codec.dequeueOutputBuffer(info, timeoutUs)
            when {
                o == MediaCodec.INFO_TRY_AGAIN_LATER -> return false
                o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (!muxStarted) { track = muxer.addTrack(codec.outputFormat); muxer.start(); muxStarted = true }
                }
                o >= 0 -> {
                    val ob = codec.getOutputBuffer(o)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (ob != null && info.size > 0 && muxStarted) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        muxer.writeSampleData(track, ob, info)
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return true
                }
            }
        }
    }
}

/**
 * A process started with app_process has no ActivityThread / application info, which AudioRecord
 * needs for its attribution (package name). This builds the same minimal fake environment as scrcpy:
 * the process pretends to be com.android.shell. Every step is best-effort and logged.
 */
internal object ShellEnv {
    private var prepared = false
    private var ctx: Context? = null
    private var status = "not prepared"

    fun context(): Context? = ctx
    fun status(): String = status

    @Synchronized fun prepare(log: StringBuilder) {
        if (prepared) return
        prepared = true
        val steps = StringBuilder()
        try {
            val atClass = Class.forName("android.app.ActivityThread")
            var thread = atClass.getDeclaredMethod("currentActivityThread").invoke(null)
            if (thread == null) {
                val c = atClass.getDeclaredConstructor(); c.isAccessible = true
                thread = c.newInstance()
                atClass.getDeclaredField("sCurrentActivityThread").apply { isAccessible = true }.set(null, thread)
                atClass.getDeclaredField("mSystemThread").apply { isAccessible = true }.setBoolean(thread, true)
                val ai = ApplicationInfo().apply { packageName = PKG }
                val bdClass = Class.forName("android.app.ActivityThread\$AppBindData")
                val bdc = bdClass.getDeclaredConstructor(); bdc.isAccessible = true
                val bd = bdc.newInstance()
                bdClass.getDeclaredField("appInfo").apply { isAccessible = true }.set(bd, ai)
                atClass.getDeclaredField("mBoundApplication").apply { isAccessible = true }.set(thread, bd)
                val sys = atClass.getDeclaredMethod("getSystemContext").invoke(thread) as Context
                val app = Application()
                ContextWrapper::class.java.getDeclaredField("mBase").apply { isAccessible = true }.set(app, sys)
                atClass.getDeclaredField("mInitialApplication").apply { isAccessible = true }.set(thread, app)
                steps.append("fake ActivityThread ok; ")
            } else steps.append("ActivityThread already present; ")
            if (Build.VERSION.SDK_INT >= 31) {
                val sys = atClass.getDeclaredMethod("getSystemContext").invoke(thread) as Context
                ctx = ShellContext(sys)
                steps.append("fake context ok; ")
            }
        } catch (t: Throwable) {
            steps.append("env setup failed: ${t.javaClass.simpleName}: ${t.message}; ")
        }
        status = steps.toString().trim()
        log.append("[env] ").append(status).append(' ')
    }

    const val PKG = "com.android.shell"
}

internal class ShellContext(base: Context) : ContextWrapper(base) {
    override fun getPackageName(): String = ShellEnv.PKG
    override fun getAttributionSource(): AttributionSource =
        AttributionSource.Builder(Process.myUid()).setPackageName(ShellEnv.PKG).build()
}
