package ir.abtin.sms

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SmsMessage
import android.widget.RemoteViews
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationCompat
import androidx.core.app.RemoteInput
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

class AbtinApp : Application() {
    override fun onCreate() {
        super.onCreate(); Prefs.init(this); AppLog.init(this)
        runCatching { ShizukuRec.init(this) }
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e -> AppLog.i(this, "CRASH in ${t.name}", e); old?.uncaughtException(t, e) }
        AppLog.i(this, "app start")
        Notifier.channel(this)
        // Call channels used to exist only after the first call notification; create them at start so they show in system settings.
        runCatching { Prefs.withProfile(true) { CallHub.channels(this) } }.onFailure { AppLog.i(this, "call channels FAILED", it) }
    }
}

/** Persistent + observable settings. */
class Setting<T : Any>(private val key: String, private val def: T) {
    private val states = mutableMapOf<String, MutableState<T>>()
    @Suppress("UNCHECKED_CAST")
    private fun s(): MutableState<T> = states.getOrPut(Prefs.profile) {
        val sp = Prefs.sp
        val scopedKey = "${Prefs.profile}_$key"
        val v = when (def) {
            // Legacy unscoped preferences belong to the original SMS app only.
            // The Phone profile must start from its own defaults instead of
            // accidentally inheriting SMS colors, notification flags or sounds.
            is Boolean -> sp.getBoolean(scopedKey, if (Prefs.profile == "sms") sp.getBoolean(key, def) else def)
            is String -> sp.getString(scopedKey, if (Prefs.profile == "sms") sp.getString(key, def) else def) ?: def
            is Float -> sp.getFloat(scopedKey, if (Prefs.profile == "sms") sp.getFloat(key, def) else def)
            is Int -> sp.getInt(scopedKey, if (Prefs.profile == "sms") sp.getInt(key, def) else def)
            else -> def
        } as T
        mutableStateOf(v)
    }
    var value: T
        get() = s().value
        set(v) {
            s().value = v
            val e = Prefs.sp.edit()
            val scopedKey = "${Prefs.profile}_$key"
            when (v) { is Boolean -> e.putBoolean(scopedKey, v); is String -> e.putString(scopedKey, v); is Float -> e.putFloat(scopedKey, v); is Int -> e.putInt(scopedKey, v) }
            e.apply()
        }
}

object Prefs {
    lateinit var sp: SharedPreferences
    // Settings are namespaced per app surface: SMS ("sms") and Phone ("phone").
    // Callers select the profile before reading/writing Setting values.
    var profile: String = "sms"
        private set
    fun useProfile(phone: Boolean) { profile = if (phone) "phone" else "sms" }
    fun <T> withProfile(phone: Boolean, block: () -> T): T {
        val previous = profile
        useProfile(phone)
        return try { block() } finally { profile = previous }
    }
    fun init(c: Context) { if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("abtin", 0) }
    val language = Setting("language", "system")    // system | fa | en
    val fontScale = Setting("fontScale", 1.0f)
    val chatZoom = Setting("chatZoom", 1.0f)           // pinch-to-zoom text size inside a conversation (multiplies fontScale)
    val showAvatars = Setting("showAvatars", true)
    val deliveryReports = Setting("deliveryReports", true)
    val enterSends = Setting("enterSends", false)
    val notifications = Setting("notifications", true)
    val vibrate = Setting("vibrate", true)
    val showPreview = Setting("showPreview", true)
    val pinned = Setting("pinned", "")              // thread ids, comma separated
    val archived = Setting("archived", "")          // thread ids
    val pin = Setting("pin", "")
    val templates = Setting("templates", "")
    val blocked = Setting("blocked", "")            // normalized numbers
    val spamFilter = Setting("spamFilter", true)
    val spam = Setting("spam", "")                  // normalized numbers flagged as spam
    val spamOk = Setting("spamOk", "")              // user whitelist (not spam)
    val spamWords = Setting("spamWords", "")        // custom words, one per line
    val spamBuiltin = Setting("spamBuiltin", true)  // also use the built-in word list for SMS
    val spamAsked = Setting("spamAsked", "")        // numbers the user already answered the "repeated caller" question for
    val callRepeatAsk = Setting("callRepeatAsk", true)   // phone profile: ask about numbers that call many times
    val callRepeatCount = Setting("callRepeatCount", 5)  // phone profile: calls within 3 days that trigger the question
    val sim = Setting("sim", -1)                    // default subscription id, -1 = system default
    val groupMms = Setting("groupMms", true)
    val bubbleShape = Setting("bubbleShape", "tail")     // tail | rounded | pill | square
    val chatBackground = Setting("chatBackground", 0)    // ARGB; 0 = default
    val incomingBubble = Setting("incomingBubble", 0)
    val outgoingBubble = Setting("outgoingBubble", 0)
    val accentColor = Setting("accentColor", 0)
    val swipeLeft = Setting("swipeLeft", "delete")       // delete | archive | read | none
    val swipeRight = Setting("swipeRight", "archive")
    val swipeHintDone = Setting("swipeHintDone", false)
    val showQuickReplies = Setting("showQuickReplies", false)
    val smartLinks = Setting("smartLinks", true)
    val linkPreview = Setting("linkPreview", true)       // link preview card under messages with URLs
    val codeChip = Setting("codeChip", true)             // "copy code" chip on OTP messages
    val sendSound = Setting("sendSound", false)
    val autoRecordCalls = Setting("autoRecordCalls", false)
    val useShizukuRec = Setting("useShizukuRec", true)   // record call audio through the Shizuku shell helper when available
    val lockPreview = Setting("lockPreview", true)
    val notifSound = Setting("notifSound", "")
    val autoDownloadMms = Setting("autoDownloadMms", true)
    val autoDownloadRoaming = Setting("autoDownloadRoaming", false)
    val simpleChars = Setting("simpleChars", false)
    val autoDeleteOtp = Setting("autoDeleteOtp", false)
    val persianDigits = Setting("persianDigits", true)
    // On by default for Xiaomi/Redmi/POCO: MIUI/HyperOS can silence a channel even when Android reports it as HIGH + sound + vibrate.
    val forceAlert = Setting("forceAlert", Build.MANUFACTURER.lowercase() in setOf("xiaomi", "redmi", "poco"))
    val showContactsTab = Setting("showContactsTab", false)   // SMS app: Contacts tab/shortcut (off = contacts only in New message picker)
    val starred = Setting("starred", "")                 // "s<id>" / "m<id>"
    val muted = Setting("muted", "")                     // thread ids
    val sendDelay = Setting("sendDelay", 0)              // seconds of undo window, 0 = off

    // Phone-profile notification preferences. These are stored under phone_* keys
    // and are never read by the SMS notification pipeline.
    val callNotifications = Setting("callNotifications", true)
    val callKeepOnTop = Setting("callKeepOnTop", true)
    val callVibrate = Setting("callVibrate", true)
    val callSoundEnabled = Setting("callSoundEnabled", true)
    val callNotifSound = Setting("callNotifSound", "")
    val callAccentColor = Setting("callAccentColor", 0)

    // Call theme + customization. Blank / 0 = "use the selected theme's value".
    val callTheme = Setting("callTheme", "original")
    val callLayout = Setting("callLayout", "")           // buttons | pill | swipe
    val callBtnShape = Setting("callBtnShape", "")       // circle | rounded | pill | square
    val callBtnStyle = Setting("callBtnStyle", "")       // filled | outline | glow
    val callBtnLabels = Setting("callBtnLabels", "")     // on | off
    val callBtnScale = Setting("callBtnScale", 1.0f)
    val callAnswerColor = Setting("callAnswerColor", 0)
    val callDeclineColor = Setting("callDeclineColor", 0)
    val callBtnIconColor = Setting("callBtnIconColor", 0)
    val callAnswerText = Setting("callAnswerText", "")
    val callDeclineText = Setting("callDeclineText", "")
    val callSubtitleText = Setting("callSubtitleText", "")
    val callAvatarRing = Setting("callAvatarRing", "")   // none | plain | glow | gradient | arc
    val callBgTop = Setting("callBgTop", 0)
    val callBgBottom = Setting("callBgBottom", 0)
    val callNotifBg = Setting("callNotifBg", 0)
    val callNotifText = Setting("callNotifText", 0)
    val callNotifStyle = Setting("callNotifStyle", "auto")   // auto | system | card
    val callBgImage = Setting("callBgImage", "")             // "" | res:<id> | file:<name>
    val callBgDim = Setting("callBgDim", 0.35f)
    val callOverlayAsked = Setting("callOverlayAsked", false)
    val callSetupDone = Setting("callSetupDone", false)
    val callSpamMode = Setting("callSpamMode", 1)           // 0 label only | 1 silence ring | 2 auto-reject (phone profile)
}

fun csv(s: Setting<String>): Set<String> = s.value.split(',').filter { it.isNotBlank() }.toSet()
fun toggle(s: Setting<String>, k: String) { val c = csv(s).toMutableSet(); if (!c.add(k)) c.remove(k); s.value = c.joinToString(",") }
fun addTo(s: Setting<String>, k: String) { val c = csv(s).toMutableSet(); c.add(k); s.value = c.joinToString(",") }
fun removeFrom(s: Setting<String>, k: String) { val c = csv(s).toMutableSet(); c.remove(k); s.value = c.joinToString(",") }
fun markSpam(n: String, spam: Boolean) {
    if (spam) { addTo(Prefs.spam, n); removeFrom(Prefs.spamOk, n) } else { removeFrom(Prefs.spam, n); addTo(Prefs.spamOk, n) }
}
// Spam numbers are shared by SMS and calls: always read/written in the SMS profile.
fun isSpamNumber(n: String): Boolean {
    if (n.none { it.isDigit() }) return false
    val k = norm(n)
    return Prefs.withProfile(false) { k !in csv(Prefs.spamOk) && k in csv(Prefs.spam) }
}
fun markSpamNumber(n: String, spam: Boolean) { if (n.any { it.isDigit() }) Prefs.withProfile(false) { markSpam(norm(n), spam) } }
fun isBlockedNumber(n: String): Boolean = n.any { it.isDigit() } && Prefs.withProfile(false) { norm(n) in csv(Prefs.blocked) }
fun blockNumber(n: String, block: Boolean) { if (n.any { it.isDigit() }) Prefs.withProfile(false) { if (block) addTo(Prefs.blocked, norm(n)) else removeFrom(Prefs.blocked, norm(n)) } }
fun markSpamAsked(n: String) { if (n.any { it.isDigit() }) Prefs.withProfile(false) { addTo(Prefs.spamAsked, norm(n)) } }
fun spamWordList(): List<String> = Prefs.withProfile(false) { Prefs.spamWords.value.lines().map { it.trim() }.filter { it.isNotEmpty() } }
fun callSpamMode(): Int = Prefs.withProfile(true) { Prefs.callSpamMode.value }
fun norm(a: String): String = a.filter { it.isDigit() }.takeLast(9).ifEmpty { a }

data class Conv(val threadId: Long, val address: String, val name: String?, val snippet: String, val date: Long, val unread: Int)
data class Msg(val id: Long, val threadId: Long, val address: String, val body: String, val date: Long, val type: Int, val status: Int,
               val mms: Boolean = false, val atts: List<Att> = emptyList())
data class ContactItem(val name: String, val number: String, val id: Long = 0, val starred: Boolean = false)

class SmsRepo(val ctx: Context) {
    val cr = ctx.contentResolver
    private val nameCache = HashMap<String, String?>()
    companion object {
        const val ACTION_SENT = "ir.abtin.sms.SENT"
        const val ACTION_DELIVERED = "ir.abtin.sms.DELIVERED"
        private val rc = AtomicInteger(1)
    }

    fun name(address: String): String? = nameCache.getOrPut(address) {
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) null
        else try {
            cr.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Exception) { null }
    }

    fun conversations(): List<Conv> = try { convsThreads() } catch (e: Exception) { convsSmsOnly() }

    private fun convsThreads(): List<Conv> {
        val canon = HashMap<String, String>()
        cr.query(Uri.parse("content://mms-sms/canonical-addresses"), arrayOf("_id", "address"), null, null, null)?.use { c ->
            while (c.moveToNext()) canon[c.getString(0)] = c.getString(1) ?: ""
        }
        val unread = HashMap<Long, Int>()
        listOf(Telephony.Sms.CONTENT_URI to "read=0", Telephony.Mms.CONTENT_URI to "read=0 AND msg_box=1").forEach { (u, w) ->
            cr.query(u, arrayOf("thread_id"), w, null, null)?.use { c ->
                while (c.moveToNext()) { val t = c.getLong(0); unread[t] = (unread[t] ?: 0) + 1 }
            }
        }
        val out = ArrayList<Conv>()
        cr.query(Uri.parse("content://mms-sms/conversations?simple=true"),
            arrayOf("_id", "date", "message_count", "recipient_ids", "snippet", "has_attachment"), null, null, "date DESC")?.use { c ->
            while (c.moveToNext()) {
                if (c.getInt(2) == 0) continue
                val addrs = (c.getString(3) ?: "").split(' ').mapNotNull { canon[it] }.filter { it.isNotBlank() }
                if (addrs.isEmpty()) continue
                var sn = c.getString(4) ?: ""
                if (sn.isBlank() && c.getInt(5) == 1) sn = "MMS"
                val tid = c.getLong(0)
                val nm = if (addrs.size == 1) name(addrs[0]) else addrs.joinToString(", ") { name(it) ?: it }
                out.add(Conv(tid, addrs.joinToString(","), nm, sn, c.getLong(1), unread[tid] ?: 0))
            }
        } ?: throw IllegalStateException("no threads")
        return out
    }

    private fun convsSmsOnly(): List<Conv> {
        val out = LinkedHashMap<Long, Conv>(); val unread = HashMap<Long, Int>()
        cr.query(Telephony.Sms.CONTENT_URI, arrayOf("thread_id", "address", "body", "date", "read"), null, null, "date DESC")?.use { c ->
            while (c.moveToNext()) {
                val t = c.getLong(0)
                if (c.getInt(4) == 0) unread[t] = (unread[t] ?: 0) + 1
                if (t !in out) { val a = c.getString(1) ?: ""; out[t] = Conv(t, a, name(a), c.getString(2) ?: "", c.getLong(3), 0) }
            }
        }
        return out.values.map { it.copy(unread = unread[it.threadId] ?: 0) }
    }

    fun messages(threadId: Long): List<Msg> {
        val l = ArrayList<Msg>()
        cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "thread_id", "address", "body", "date", "type", "status"),
            "thread_id=?", arrayOf(threadId.toString()), "date ASC")?.use { c ->
            while (c.moveToNext()) l += Msg(c.getLong(0), c.getLong(1), c.getString(2) ?: "", c.getString(3) ?: "", c.getLong(4), c.getInt(5), c.getInt(6))
        }
        return (l + runCatching { mmsMessages(threadId) }.getOrDefault(emptyList())).sortedBy { it.date }
    }

    fun searchMessages(q: String): List<Msg> {
        val l = ArrayList<Msg>()
        cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "thread_id", "address", "body", "date", "type", "status"),
            "body LIKE ?", arrayOf("%" + q + "%"), "date DESC LIMIT 100")?.use { c ->
            while (c.moveToNext()) l += Msg(c.getLong(0), c.getLong(1), c.getString(2) ?: "", c.getString(3) ?: "", c.getLong(4), c.getInt(5), c.getInt(6))
        }
        return l
    }

    fun backup(u: Uri): Int {
        val arr = org.json.JSONArray()
        cr.query(Telephony.Sms.CONTENT_URI, arrayOf("address", "body", "date", "date_sent", "type", "read"), null, null, "date ASC")?.use { c ->
            while (c.moveToNext()) arr.put(org.json.JSONObject().put("a", c.getString(0) ?: "").put("b", c.getString(1) ?: "")
                .put("d", c.getLong(2)).put("ds", c.getLong(3)).put("t", c.getInt(4)).put("r", c.getInt(5)))
        }
        val out = cr.openOutputStream(u) ?: throw java.io.IOException("open failed")
        out.use { it.write(arr.toString().toByteArray(Charsets.UTF_8)) }
        return arr.length()
    }

    fun restore(u: Uri): Int {
        val inp = cr.openInputStream(u) ?: return -1
        val arr = org.json.JSONArray(inp.use { String(it.readBytes(), Charsets.UTF_8) })
        var n = 0
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val a = o.getString("a"); val d = o.getLong("d"); val t = o.getInt("t")
            val dup = cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id"), "address=? AND date=? AND type=?",
                arrayOf(a, d.toString(), t.toString()), null)?.use { it.count > 0 } ?: false
            if (dup) continue
            val v = ContentValues().apply {
                put("address", a); put("body", o.getString("b")); put("date", d); put("date_sent", o.optLong("ds"))
                put("type", t); put("read", o.optInt("r", 1)); put("thread_id", threadIdFor(a))
            }
            if (cr.insert(Telephony.Sms.CONTENT_URI, v) != null) n++
        }
        return n
    }

    fun threadIdFor(address: String): Long = try {
        Telephony.Threads.getOrCreateThreadId(ctx, address.split(',', ';').map { it.trim() }.filter { it.isNotEmpty() }.toSet())
    } catch (e: Exception) { 0L }

    fun contacts(): List<ContactItem> {
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return emptyList()
        val l = ArrayList<ContactItem>()
        cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.CONTACT_ID, ContactsContract.CommonDataKinds.Phone.STARRED),
            null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")?.use { c ->
            while (c.moveToNext()) l += ContactItem(c.getString(0) ?: "", c.getString(1) ?: "", c.getLong(2), c.getInt(3) == 1)
        }
        return l.distinctBy { it.number.filter { ch -> ch.isDigit() } }
    }

    fun markRead(threadId: Long) {
        val v = ContentValues().apply { put("read", 1); put("seen", 1) }
        cr.update(Telephony.Sms.CONTENT_URI, v, "thread_id=? AND read=0", arrayOf(threadId.toString()))
        runCatching { cr.update(Telephony.Mms.CONTENT_URI, v, "thread_id=? AND read=0", arrayOf(threadId.toString())) }
    }
    fun markAllRead() {
        val v = ContentValues().apply { put("read", 1); put("seen", 1) }
        cr.update(Telephony.Sms.CONTENT_URI, v, "read=0", null)
        runCatching { cr.update(Telephony.Mms.CONTENT_URI, v, "read=0", null) }
    }
    fun deleteThread(threadId: Long) {
        cr.delete(Telephony.Sms.CONTENT_URI, "thread_id=?", arrayOf(threadId.toString()))
        runCatching { cr.delete(Telephony.Mms.CONTENT_URI, "thread_id=?", arrayOf(threadId.toString())) }
        runCatching { cr.delete(Uri.parse("content://mms-sms/conversations/$threadId"), null, null) }
    }
    fun deleteMessage(id: Long, mms: Boolean = false) {
        if (mms) cr.delete(Telephony.Mms.CONTENT_URI, "_id=?", arrayOf(id.toString()))
        else cr.delete(Telephony.Sms.CONTENT_URI, "_id=?", arrayOf(id.toString()))
    }

    fun send(address: String, body0: String, subId: Int = Prefs.sim.value) {
        val body = if (Prefs.simpleChars.value) simplify(body0) else body0
        val reports = Prefs.deliveryReports.value
        val v = ContentValues().apply {
            put("address", address); put("body", body); put("date", System.currentTimeMillis()); put("read", 1)
            put("type", Telephony.Sms.MESSAGE_TYPE_OUTBOX); put("thread_id", threadIdFor(address))
            put("status", if (reports) Telephony.Sms.STATUS_PENDING else Telephony.Sms.STATUS_NONE)
            if (subId >= 0) put("sub_id", subId)
        }
        val uri = cr.insert(Telephony.Sms.CONTENT_URI, v) ?: throw SecurityException("not default SMS app")
        transmit(uri, address, body, subId, reports)
    }

    /**
     * Sends the already-stored message. If the carrier rejects a message that asked for a delivery report
     * (some Iranian carriers do), StatusReceiver calls this again with reports=false so the message still goes out.
     */
    fun transmit(uri: Uri, address: String, body: String, subId: Int, reports: Boolean) {
        val sm = smsManagerFor(ctx, subId)
        val parts = sm.divideMessage(body)
        val sent = ArrayList<PendingIntent>(); val del = ArrayList<PendingIntent>()
        for (i in parts.indices) {
            sent += pi(ACTION_SENT, uri, i == parts.size - 1, extra = reports)
            if (reports) del += pi(ACTION_DELIVERED, uri, i == parts.size - 1, true)
        }
        // Like Google Messages: a message that fits in one SMS goes out as a plain single SMS,
        // only longer ones use the multipart (concatenated) path.
        if (parts.size <= 1) sm.sendTextMessage(address, null, parts.firstOrNull() ?: body, sent.firstOrNull(), if (reports) del.firstOrNull() else null)
        else sm.sendMultipartTextMessage(address, null, parts, sent, if (reports) del else null)
    }

    /** Retry a message whose first attempt (with delivery report) was rejected, this time without the report request. */
    fun retryWithoutReport(uri: Uri) {
        cr.query(uri, arrayOf("address", "body", "sub_id"), null, null, null)?.use { q ->
            if (!q.moveToFirst()) return
            val v = ContentValues().apply { put("type", Telephony.Sms.MESSAGE_TYPE_OUTBOX); put("status", Telephony.Sms.STATUS_NONE) }
            runCatching { cr.update(uri, v, null, null) }
            transmit(uri, q.getString(0) ?: return, q.getString(1) ?: "", runCatching { q.getInt(2) }.getOrDefault(-1), false)
        }
    }

    private fun pi(action: String, uri: Uri, last: Boolean, mutable: Boolean = false, extra: Boolean = false): PendingIntent =
        PendingIntent.getBroadcast(ctx, rc.getAndIncrement(),
            Intent(ctx, StatusReceiver::class.java).setAction(action).setData(uri).putExtra("last", last).putExtra("reports", extra),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (!mutable) PendingIntent.FLAG_IMMUTABLE else if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0))
}

/** Updates sent / delivery state of outgoing messages. */
class StatusReceiver : BroadcastReceiver() {
    private companion object { val retried: MutableSet<String> = java.util.Collections.synchronizedSet(HashSet()) }
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == ACTION_MMS_DL) {
            val code = resultCode; val pr = goAsync()
            Thread { try { Prefs.init(c); SmsRepo(c).onMmsDownloaded(i, code) } catch (e: Exception) { } finally { pr.finish() } }.start()
            return
        }
        val uri = i.data ?: return
        val last = i.getBooleanExtra("last", true)
        val v = ContentValues()
        when (i.action) {
            ACTION_MMS_SENT -> {
                v.put("msg_box", if (resultCode == Activity.RESULT_OK) 2 else 5)
                i.getStringExtra("file")?.let { File(it).delete() }
            }
            SmsRepo.ACTION_SENT ->
                if (resultCode == Activity.RESULT_OK) { if (last) v.put("type", Telephony.Sms.MESSAGE_TYPE_SENT) }
                else if (i.getBooleanExtra("reports", false) && retried.add(uri.toString())) {
                    // Carrier refused the message that asked for a delivery report: resend it without the request.
                    Prefs.init(c)
                    try { SmsRepo(c).retryWithoutReport(uri); return } catch (e: Exception) { v.put("type", Telephony.Sms.MESSAGE_TYPE_FAILED); v.put("error_code", resultCode) }
                }
                else { v.put("type", Telephony.Sms.MESSAGE_TYPE_FAILED); v.put("error_code", resultCode) }
            SmsRepo.ACTION_DELIVERED -> if (last) {
                val ok = try {
                    val pdu = i.getByteArrayExtra("pdu"); val fmt = i.getStringExtra("format")
                    pdu == null || SmsMessage.createFromPdu(pdu, fmt).status == 0
                } catch (e: Exception) { true }
                v.put("status", if (ok) Telephony.Sms.STATUS_COMPLETE else Telephony.Sms.STATUS_FAILED)
                v.put("date_sent", System.currentTimeMillis())
            }
        }
        if (v.size() > 0) try { c.contentResolver.update(uri, v, null, null) } catch (e: Exception) {}
    }
}

/** In-app debug log (file in app storage) – viewable/copyable/shareable from Settings → Notifications → Debug log. */
object AppLog {
    private var file: File? = null
    private val fmt = java.text.SimpleDateFormat("MM-dd HH:mm:ss.SSS", java.util.Locale.US)
    fun init(c: Context) { if (file == null) file = File(c.applicationContext.filesDir, "abtin_log.txt") }

    @Synchronized fun i(c: Context, msg: String, t: Throwable? = null) {
        runCatching {
            init(c); val f = file!!
            if (f.length() > 200_000) f.writeText(f.readText().takeLast(100_000))
            f.appendText("${fmt.format(java.util.Date())} [${Prefs.profile}] $msg" +
                (t?.let { "\n" + android.util.Log.getStackTraceString(it) } ?: "") + "\n")
        }
        android.util.Log.d("AbtinNotif", msg)
    }

    @Synchronized fun read(c: Context): String = runCatching { init(c); file!!.takeIf { it.exists() }?.readText() ?: "" }.getOrDefault("")
    @Synchronized fun clear(c: Context) { runCatching { init(c); file!!.delete() } }

    fun diagnostics(c: Context): String = runCatching {
        val sb = StringBuilder()
        val nm = c.getSystemService(NotificationManager::class.java)
        sb.appendLine("== STATE ==")
        sb.appendLine("device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
        sb.appendLine("default SMS app: ${Telephony.Sms.getDefaultSmsPackage(c)} (this app: ${c.packageName}) -> isDefault=${Telephony.Sms.getDefaultSmsPackage(c) == c.packageName}")
        sb.appendLine("RECEIVE_SMS granted: ${c.checkSelfPermission(android.Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED}")
        sb.appendLine("POST_NOTIFICATIONS granted: ${Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED}")
        sb.appendLine("areNotificationsEnabled: ${nm.areNotificationsEnabled()}")
        sb.appendLine("DND filter (1=all allowed): ${nm.currentInterruptionFilter}")
        sb.appendLine("ringer mode (0=silent,1=vibrate,2=normal): ${c.getSystemService(android.media.AudioManager::class.java).ringerMode}")
        sb.appendLine("battery optimization ignored: ${c.getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)}")
        Prefs.withProfile(false) {
            sb.appendLine("app switch forceAlert=${Prefs.forceAlert.value} notifications=${Prefs.notifications.value} vibrate=${Prefs.vibrate.value} preview=${Prefs.showPreview.value} customSound='${Prefs.notifSound.value}' muted='${Prefs.muted.value}'")
            if (Build.VERSION.SDK_INT >= 26) {
                val id = Notifier.chId(c); val ch = nm.getNotificationChannel(id)
                sb.appendLine("channel: $id importance=${ch?.importance} (4=high,3=default,2=low,0=none) sound=${ch?.sound} vibrate=${ch?.shouldVibrate()} bypassDnd=${ch?.canBypassDnd()}")
                sb.appendLine("all channels: " + nm.notificationChannels.joinToString { "${it.id}:${it.importance}" })
            }
        }
        sb.toString()
    }.getOrElse { "diagnostics failed: $it" }
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        AppLog.i(c, "SmsReceiver.onReceive action=${i.action}")
        if (i.action != Telephony.Sms.Intents.SMS_DELIVER_ACTION) return
        Prefs.init(c)
        val previousProfile = Prefs.profile
        try {
            Prefs.useProfile(false)
            val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
            val sub = i.getIntExtra("subscription", -1)
            val repo = SmsRepo(c)
            msgs.groupBy { it.originatingAddress ?: "" }.forEach { (addr, list) ->
                val body = list.joinToString("") { it.messageBody ?: "" }
                val blocked = norm(addr) in csv(Prefs.blocked)
                val spam = !blocked && Spam.check(repo, addr, body)
                if (spam) addTo(Prefs.spam, norm(addr))
                val quiet = blocked || spam
                AppLog.i(c, "sms from=$addr len=${body.length} blocked=$blocked spam=$spam")
                val v = ContentValues().apply {
                    put("address", addr); put("body", body); put("date", System.currentTimeMillis())
                    put("date_sent", list[0].timestampMillis); put("read", if (quiet) 1 else 0); put("seen", if (quiet) 1 else 0); put("type", 1)
                    if (sub >= 0) put("sub_id", sub)
                }
                try { c.contentResolver.insert(Telephony.Sms.Inbox.CONTENT_URI, v) } catch (e: Exception) { AppLog.i(c, "insert FAILED", e); return@forEach }
                if (quiet) { AppLog.i(c, "quiet (blocked/spam) -> no notification"); return@forEach }
                runCatching { Notifier.show(c, repo.threadIdFor(addr), addr, repo.name(addr), body) }.onFailure { AppLog.i(c, "Notifier.show THREW", it) }
            }
        } finally {
            Prefs.useProfile(previousProfile == "phone")
        }
    }
}

class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.WAP_PUSH_DELIVER_ACTION) return
        Prefs.init(c)
        Prefs.withProfile(false) {
            val data = i.getByteArrayExtra("data") ?: return@withProfile
            val n = Pdu.parse(data).takeIf { it.type == 0x82 } ?: Pdu.fromPush(data)?.takeIf { it.type == 0x82 } ?: return@withProfile
            val loc = n.loc ?: return@withProfile
            val sub = i.getIntExtra("subscription", -1)
            val roaming = try { c.getSystemService(android.telephony.TelephonyManager::class.java)?.isNetworkRoaming == true } catch (e: Exception) { false }
            if (!Prefs.autoDownloadMms.value || (roaming && !Prefs.autoDownloadRoaming.value)) { Notifier.mmsPending(c, loc, n.from ?: "", sub, n.tx ?: ""); return@withProfile }
            val pr = goAsync()
            Thread { try { Prefs.withProfile(false) { SmsRepo(c).downloadMms(loc, n.from ?: "", sub, n.tx ?: "") } } catch (e: Exception) { } finally { pr.finish() } }.start()
        }
    }
}

class RespondService : Service() {
    override fun onBind(i: Intent?) = null
    override fun onStartCommand(i: Intent?, f: Int, s: Int): Int {
        val to = i?.data?.schemeSpecificPart?.substringBefore('?')
        val msg = i?.getStringExtra(Intent.EXTRA_TEXT)
        Prefs.init(this)
        Prefs.withProfile(false) {
            if (!to.isNullOrBlank() && !msg.isNullOrBlank()) runCatching { SmsRepo(this).sendAny(to, msg) }
        }
        stopSelf(); return START_NOT_STICKY
    }
}

object Notifier {
    const val CH = "messages"
    var activeThread = -1L
    var foreground = false
    private const val TEST_ID = 7714

    fun channel(c: Context) { chId(c) }

    fun chId(c: Context): String {
        val snd = Prefs.notifSound.value
        val prefix = if (Prefs.profile == "phone") "phone_messages" else CH
        // "v4" forces Android to create a fresh channel. Channel audio is immutable, so reusing an older
        // channel can keep playing a sound selected in a previous app version.
        val force = Prefs.forceAlert.value
        val id = "${prefix}_v4_${snd.hashCode().toUInt().toString(16)}_${if (Prefs.vibrate.value) "vib" else "novib"}${if (force) "_app2" else ""}"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = c.getSystemService(NotificationManager::class.java)
            val existing = nm.getNotificationChannel(id)
            val ch = existing ?: NotificationChannel(id, tr("پیام‌های آبتین", "Abtin messages"), NotificationManager.IMPORTANCE_HIGH).apply {
                // Nothing is overridden by default: Android's own notification sound and vibration are used
                // (a single alert, played by the system). A sound is set only if the user picked one in settings.
                if (force) {
                    // The app plays the real sound/vibration itself (see manualAlert). The channel must NOT be fully silent:
                    // MIUI/HyperOS demote silent channels (no heads-up, no status-bar icon), so give it a 100 ms silent
                    // clip + a 1 ms vibration pattern. The system then treats it as an "alerting" channel and pops it up.
                    setSound(Uri.parse("android.resource://${c.packageName}/${R.raw.silent_alert}"),
                        android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    enableVibration(true); vibrationPattern = longArrayOf(0, 1)
                }
                else {
                    setSound(if (snd.isNotEmpty()) Uri.parse(snd) else android.provider.Settings.System.DEFAULT_NOTIFICATION_URI,
                        android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION)
                            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    enableVibration(Prefs.vibrate.value)
                    if (Prefs.vibrate.value) vibrationPattern = longArrayOf(0, 250, 150, 250)
                }
                lockscreenVisibility = Notification.VISIBILITY_PRIVATE
                setShowBadge(true)
            }
            ch.name = tr("پیام‌های آبتین", "Abtin messages")
            ch.description = tr("اعلان‌های پیام با ظاهر اختصاصی آبتین", "Messages with Abtin's custom notification design")
            nm.createNotificationChannel(ch)
            // Drop channels left behind by older versions / previous sound or vibration choices.
            runCatching {
                nm.notificationChannels.filter { it.id != id && it.id.startsWith("${prefix}_") }
                    .forEach { nm.deleteNotificationChannel(it.id) }
            }
        }
        return id
    }

    fun mmsPending(c: Context, loc: String, from: String, sub: Int, tx: String) {
        Prefs.init(c)
        Prefs.withProfile(false) {
            if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return@withProfile
            val pi = PendingIntent.getBroadcast(c, 777, Intent(c, NotifActionReceiver::class.java).setAction("MMS_DL")
                .putExtra("loc", loc).putExtra("from", from).putExtra("sub", sub).putExtra("tx", tx), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val title = SmsRepo(c).name(from) ?: from.ifBlank { tr("مخاطب ناشناس", "Unknown sender") }
            val body = tr("پیام چندرسانه‌ای جدید؛ برای دریافت لمس کنید", "New multimedia message; tap to download")
            val avatar = makeAvatar(c, from, title)
            val compact = messageViews(c, title, body, avatar, pi, false)
            val expanded = messageViews(c, title, body, avatar, pi, true, tr("دریافت پیام", "Download message"))
            val n = NotificationCompat.Builder(c, chId(c)).setSmallIcon(R.drawable.ic_notification_message)
                .setContentTitle(title).setContentText(body).setLargeIcon(avatar)
                .setCustomContentView(compact).setCustomBigContentView(expanded).setCustomHeadsUpContentView(compact)
                .setStyle(NotificationCompat.DecoratedCustomViewStyle()).setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE).setContentIntent(pi).setAutoCancel(true).build()
            c.getSystemService(NotificationManager::class.java).notify(777, n)
        }
    }

    private fun makeAvatar(c: Context, address: String, name: String?): Bitmap {
        val contactPhoto = runCatching {
            val lookup = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address))
            val photo = c.contentResolver.query(lookup, arrayOf(ContactsContract.PhoneLookup.PHOTO_URI), null, null, null)
                ?.use { if (it.moveToFirst()) it.getString(0) else null }
            photo?.let { c.contentResolver.openInputStream(Uri.parse(it))?.use { stream -> BitmapFactory.decodeStream(stream) } }
        }.getOrNull()
        val source = contactPhoto ?: Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888).also { bitmap ->
            val canvas = Canvas(bitmap)
            val colors = intArrayOf(0xFF3978FF.toInt(), 0xFF8058E8.toInt(), 0xFF1BA99A.toInt(), 0xFFE06D72.toInt(), 0xFFDB8B32.toInt())
            val idx = (name ?: address).hashCode().ushr(1) % colors.size
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                shader = LinearGradient(0f, 0f, 128f, 128f, colors[idx], colors[(idx + 1) % colors.size], Shader.TileMode.CLAMP)
            }
            canvas.drawCircle(64f, 64f, 64f, paint)
            paint.shader = null
            paint.color = android.graphics.Color.WHITE
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = 48f
            paint.typeface = android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD)
            val label = name?.trim()?.firstOrNull()?.toString() ?: address.takeLast(2)
            canvas.drawText(label.ifBlank { "?" }, 64f, 81f, paint)
        }
        val size = 128
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val shader = BitmapShader(source, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val scale = maxOf(size.toFloat() / source.width, size.toFloat() / source.height)
        val matrix = Matrix().apply {
            setScale(scale, scale)
            postTranslate((size - source.width * scale) / 2f, (size - source.height * scale) / 2f)
        }
        shader.setLocalMatrix(matrix)
        Canvas(out).drawCircle(size / 2f, size / 2f, size / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { this.shader = shader })
        source.recycle()
        return out
    }

    private fun messageViews(c: Context, title: String, body: String, avatar: Bitmap, open: PendingIntent, expanded: Boolean, openLabel: String = tr("باز کردن گفتگو", "Open conversation")): RemoteViews {
        val v = RemoteViews(c.packageName, if (expanded) R.layout.notification_message_expanded else R.layout.notification_message_compact)
        v.setImageViewBitmap(R.id.msg_avatar, avatar)
        v.setTextViewText(R.id.msg_title, title)
        v.setTextViewText(R.id.msg_body, body)
        v.setTextViewText(R.id.msg_time, android.text.format.DateFormat.getTimeFormat(c).format(java.util.Date()))
        v.setOnClickPendingIntent(R.id.msg_card, open)
        if (expanded) {
            v.setTextViewText(R.id.msg_open, openLabel)
            v.setOnClickPendingIntent(R.id.msg_open, open)
        }
        return v
    }

    /** Branded expanded notification. OTP extraction always uses the original SMS body,
     * never the privacy-masked text shown in the notification. */
    private fun actionViews(
        c: Context, id: Int, thread: Long, address: String, title: String,
        shownBody: String, originalBody: String
    ): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.notification_message_actions)
        v.setTextViewText(R.id.msg_phone, title.ifBlank { address })
        v.setTextViewText(R.id.msg_body, shownBody)
        v.setTextViewText(R.id.msg_reply, tr("↶  پاسخ", "↶  Reply"))

        val immutable = PendingIntent.FLAG_IMMUTABLE
        val update = PendingIntent.FLAG_UPDATE_CURRENT
        v.setTextViewText(R.id.btn_read, tr("◉  خواندن", "◉  Read"))
        v.setOnClickPendingIntent(R.id.btn_read, PendingIntent.getBroadcast(c, id + 2_000_000,
            Intent(c, NotifActionReceiver::class.java).setAction("READ").putExtra("thread", thread), immutable or update))

        // Parse from the real SMS body even when message preview is disabled.
        val code = if (Prefs.codeChip.value) findCode(originalBody) else null
        if (code != null) {
            v.setTextViewText(R.id.btn_copy, tr("▢  کپی کد", "▢  Copy code"))
            // PendingIntent identity includes data URI. Include body hash as well as code,
            // and cancel any stale token so an older notification can never copy an old OTP.
            // Clipboard writes from a background broadcast are blocked on MIUI/HyperOS (and Android 10+ in general),
            // so the copy runs in a tiny transparent activity that has window focus.
            val copyIntent = Intent(c, CopyCodeActivity::class.java)
                .setData(Uri.parse("abtin-sms://notification/otp/$thread/${originalBody.hashCode()}/$code"))
                .putExtra("thread", thread).putExtra("code", code)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            v.setOnClickPendingIntent(R.id.btn_copy, PendingIntent.getActivity(c,
                (id.toLong() * 31L + originalBody.hashCode()).toInt(), copyIntent,
                immutable or update))
            v.setViewVisibility(R.id.btn_copy, android.view.View.VISIBLE)
        } else {
            v.setViewVisibility(R.id.btn_copy, android.view.View.GONE)
        }

        val dial = address.trim()
        if (Regex("^\\+?[0-9 ]{5,}$").matches(dial)) {
            v.setTextViewText(R.id.btn_call, tr("☎  تماس", "☎  Call"))
            v.setOnClickPendingIntent(R.id.btn_call, PendingIntent.getActivity(c, id + 4_000_000,
                Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + dial.replace(" ", ""))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK), immutable or update))
            v.setViewVisibility(R.id.btn_call, android.view.View.VISIBLE)
        } else v.setViewVisibility(R.id.btn_call, android.view.View.GONE)

        val reply = Intent(c, MainActivity::class.java)
            .putExtra("thread", thread).putExtra("address", address)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        v.setOnClickPendingIntent(R.id.msg_reply, PendingIntent.getActivity(c, id + 5_000_000,
            reply, immutable or update))
        return v
    }

    fun showPreview(c: Context) {
        Prefs.init(c)
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        Prefs.withProfile(false) {
            val title = tr("سارا احمدی", "Sara Ahmadi")
            val address = "09120000000"
            val body = tr("سلام! پیش‌نمایش تازهٔ آبتین چطوره؟", "Hi! How do you like Abtin's refreshed look?")
            val avatar = makeAvatar(c, address, title)
            val open = PendingIntent.getActivity(c, TEST_ID, Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = NotificationCompat.Builder(c, chId(c))
                .setSmallIcon(R.drawable.ic_notification_message)
                .setColor(Prefs.accentColor.value.takeIf { it != 0 } ?: android.graphics.Color.rgb(47, 107, 255))
                .setContentTitle(title).setContentText(body).setLargeIcon(avatar)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setContentIntent(open).setAutoCancel(true)
                .build()
            c.getSystemService(NotificationManager::class.java).notify(TEST_ID, n)
            manualAlert(c)
        }
    }

    fun show(c: Context, thread: Long, address: String, name: String?, body: String, preview: Boolean = false) {
        Prefs.init(c)
        Prefs.withProfile(false) {
            AppLog.i(c, "show() thread=$thread preview=$preview")
            if (!preview && !Prefs.notifications.value) { AppLog.i(c, "SKIP: app notifications switch is OFF"); return@withProfile }
            if (!preview && thread.toString() in csv(Prefs.muted)) { AppLog.i(c, "SKIP: thread muted"); return@withProfile }
            if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) { AppLog.i(c, "SKIP: POST_NOTIFICATIONS not granted"); return@withProfile }
            val id = if (preview) TEST_ID else thread.toInt()
            val open = PendingIntent.getActivity(c, id, Intent(c, MainActivity::class.java)
                .putExtra("thread", thread).putExtra("address", address)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val sender = name ?: address
            val shownBody = if (Prefs.showPreview.value) body else tr("پیام جدید", "New message")
            val builder = NotificationCompat.Builder(c, chId(c))
                .setSmallIcon(R.drawable.ic_notification_message)
                .setColor(Prefs.accentColor.value.takeIf { it != 0 } ?: android.graphics.Color.rgb(47, 107, 255))
                .setContentTitle(sender).setContentText(shownBody)
                .setStyle(NotificationCompat.BigTextStyle().bigText(shownBody))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE).setAutoCancel(true).setContentIntent(open)
                .setVisibility(if (Prefs.lockPreview.value) NotificationCompat.VISIBILITY_PUBLIC else NotificationCompat.VISIBILITY_PRIVATE)
            // Use Android's standard template for heads-up/shade compatibility (especially MIUI/HyperOS).
            runCatching { builder.setLargeIcon(makeAvatar(c, address, sender)) }
            var replyAction: NotificationCompat.Action? = null
            if (!preview) {
                val replyFlags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
                val reply = PendingIntent.getBroadcast(c, id + 1_000_000, Intent(c, NotifActionReceiver::class.java)
                    .setAction("REPLY").putExtra("thread", thread).putExtra("address", address), replyFlags)
                val ri = RemoteInput.Builder("reply").setLabel(tr("پاسخ را بنویسید", "Type a reply")).build()
                replyAction = NotificationCompat.Action.Builder(android.R.drawable.ic_menu_send, tr("پاسخ", "Reply"), reply)
                    .addRemoteInput(ri).setSemanticAction(NotificationCompat.Action.SEMANTIC_ACTION_REPLY)
                    .setAllowGeneratedReplies(true).setShowsUserInterface(false).build()
                // The system "Reply" text row is added only by the standard fallback (see standard()):
                // the branded card has its own Reply button, and a second plain-text "Reply" below it looked like a label.
            } else builder.setTimeoutAfter(30_000)
            if (Build.VERSION.SDK_INT < 26) {
                builder.setDefaults(if (Prefs.vibrate.value) Notification.DEFAULT_ALL else Notification.DEFAULT_SOUND)
                if (Prefs.notifSound.value.isNotEmpty()) builder.setSound(Uri.parse(Prefs.notifSound.value))
                if (!Prefs.vibrate.value) builder.setVibrate(longArrayOf(0))
            }
            val nm = c.getSystemService(NotificationManager::class.java)
            // Custom buttons only in the expanded state; any failure falls back to the standard template below.
            var customOk = false
            if (!preview && Build.VERSION.SDK_INT >= 24) {
                customOk = runCatching {
                    val rv = actionViews(c, id, thread, address, sender, shownBody, body)
                    rv.apply(c, android.widget.FrameLayout(c)) // inflate locally; throws if the layout is invalid
                    builder.setStyle(NotificationCompat.DecoratedCustomViewStyle()).setCustomBigContentView(rv)
                    builder.setLargeIcon(null as Bitmap?)
                }.onFailure { AppLog.i(c, "custom buttons view FAILED, using standard", it) }.isSuccess
            }
            fun standard() {
                builder.setCustomBigContentView(null).setStyle(NotificationCompat.BigTextStyle().bigText(shownBody))
                builder.clearActions(); replyAction?.let { builder.addAction(it) }
            }
            if (!customOk) runCatching { standard() }
            try {
                nm.notify(id, builder.build()); AppLog.i(c, "notify($id) OK, channel=${chId(c)}, custom=$customOk")
                if (customOk && Build.VERSION.SDK_INT >= 23) android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    runCatching {
                        if (nm.activeNotifications.none { it.id == id }) {
                            AppLog.i(c, "custom notification missing after post -> standard")
                            standard(); nm.notify(id, builder.build())
                        }
                    }
                }, 1200)
            } catch (e: Throwable) {
                AppLog.i(c, "notify FAILED (custom=$customOk), retrying standard", e)
                val ok = runCatching { standard(); nm.notify(id, builder.build()) }.isSuccess
                if (ok) { if (!preview) manualAlert(c); return@withProfile }
                AppLog.i(c, "standard retry FAILED, trying plain fallback", e)
                runCatching {
                    nm.notify(id, NotificationCompat.Builder(c, chId(c)).setSmallIcon(R.drawable.ic_notification_message)
                        .setContentTitle(sender).setContentText(shownBody).setPriority(NotificationCompat.PRIORITY_HIGH)
                        .setCategory(NotificationCompat.CATEGORY_MESSAGE).setAutoCancel(true).setContentIntent(open).build())
                }
            }
            if (!preview) manualAlert(c)
        }
    }

    /** Safety net: if the OS/OEM left the channel silent or non-vibrating, play the default tone / vibrate ourselves. */
    private var lastTone: android.media.Ringtone? = null
    private fun manualAlert(c: Context) {
        runCatching {
            val nm = c.getSystemService(NotificationManager::class.java)
            val am = c.getSystemService(android.media.AudioManager::class.java)
            val mode = am.ringerMode
            // Stop a tone started before the phone was switched to Vibrate/Silent.
            if (mode != android.media.AudioManager.RINGER_MODE_NORMAL) {
                lastTone?.runCatching { stop() }
                lastTone = null
            }
            if (!nm.areNotificationsEnabled()) { AppLog.i(c, "manualAlert: notifications disabled in system"); return }
            if (Build.VERSION.SDK_INT >= 23 && nm.currentInterruptionFilter != NotificationManager.INTERRUPTION_FILTER_ALL) { AppLog.i(c, "manualAlert: DND active (${nm.currentInterruptionFilter})"); return }
            val ch = if (Build.VERSION.SDK_INT >= 26) nm.getNotificationChannel(chId(c)) else null
            if (ch == null || ch.importance == NotificationManager.IMPORTANCE_NONE) { AppLog.i(c, "manualAlert: channel missing/blocked importance=${ch?.importance}"); return }
            val force = Prefs.forceAlert.value
            val needSound = mode == android.media.AudioManager.RINGER_MODE_NORMAL &&
                (force || ch.sound == null || ch.importance < NotificationManager.IMPORTANCE_DEFAULT)
            // Vibrate even in RINGER_MODE_SILENT when the app's vibration option is enabled; never play a tone there.
            val needVib = Prefs.vibrate.value &&
                (mode != android.media.AudioManager.RINGER_MODE_NORMAL || force || !ch.shouldVibrate())
            AppLog.i(c, "manualAlert: ringer=$mode importance=${ch.importance} chSound=${ch.sound} chVibrate=${ch.shouldVibrate()} needSound=$needSound needVib=$needVib")
            if (!needSound) {
                lastTone?.runCatching { stop() }
                lastTone = null
            }
            if (needSound) {
                val uri = Prefs.notifSound.value.takeIf { it.isNotEmpty() }?.let { Uri.parse(it) }
                    ?: android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
                lastTone?.runCatching { stop() }
                lastTone = android.media.RingtoneManager.getRingtone(c, uri)
                lastTone?.apply {
                    if (Build.VERSION.SDK_INT >= 28) audioAttributes = android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION).build()
                    play()
                }
            }
            if (needVib) {
                val vib = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(android.os.VibratorManager::class.java).defaultVibrator
                          else @Suppress("DEPRECATION") c.getSystemService(android.os.Vibrator::class.java)
                if (Build.VERSION.SDK_INT >= 26) vib.vibrate(android.os.VibrationEffect.createWaveform(longArrayOf(0, 250, 150, 250), -1))
                else @Suppress("DEPRECATION") vib.vibrate(longArrayOf(0, 250, 150, 250), -1)
            }
        }.onFailure { AppLog.i(c, "manualAlert THREW", it) }
    }
}

class NotifActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Prefs.init(c)
        Prefs.withProfile(false) {
            if (i.action == "MMS_DL") {
                c.getSystemService(NotificationManager::class.java).cancel(777)
                val pr = goAsync()
                Thread { try {
                    Prefs.withProfile(false) {
                        SmsRepo(c).downloadMms(i.getStringExtra("loc") ?: return@withProfile, i.getStringExtra("from") ?: "", i.getIntExtra("sub", -1), i.getStringExtra("tx") ?: "")
                    }
                } catch (e: Exception) { } finally { pr.finish() } }.start()
                return@withProfile
            }
            val thread = i.getLongExtra("thread", 0)
            when (i.action) {
                "READ" -> runCatching { SmsRepo(c).markRead(thread) }
                "COPY" -> {
                    val code = i.getStringExtra("code").orEmpty()
                    if (Regex("^[0-9]{4,8}$").matches(code)) {
                        runCatching {
                            c.getSystemService(Context.CLIPBOARD_SERVICE).let { it as android.content.ClipboardManager }
                                .setPrimaryClip(android.content.ClipData.newPlainText("کد تأیید", code))
                            android.widget.Toast.makeText(c, tr("کد کپی شد", "Code copied"), android.widget.Toast.LENGTH_SHORT).show()
                            AppLog.i(c, "notification OTP copied (${code.length} digits)")
                        }.onFailure {
                            AppLog.i(c, "notification OTP copy FAILED", it)
                            android.widget.Toast.makeText(c, tr("کپی کد ناموفق بود", "Could not copy code"), android.widget.Toast.LENGTH_SHORT).show()
                        }
                    } else android.widget.Toast.makeText(c, tr("کد معتبر پیدا نشد", "No valid code found"), android.widget.Toast.LENGTH_SHORT).show()
                }
                "REPLY" -> {
                    val t = RemoteInput.getResultsFromIntent(i)?.getCharSequence("reply")?.toString()
                    val a = i.getStringExtra("address")
                    if (!t.isNullOrBlank() && a != null) runCatching {
                        val repo = SmsRepo(c)
                        repo.sendAny(a, t)
                        repo.markRead(thread)
                    }
                }
            }
            if (i.action != "COPY") c.getSystemService(NotificationManager::class.java).cancel(thread.toInt())
        }
    }
}


/** Transparent activity started by the notification's "Copy code" button: it has window focus, so the
 * clipboard write is allowed everywhere (a background BroadcastReceiver is blocked on MIUI/HyperOS). */
class CopyCodeActivity : Activity() {
    private var done = false
    override fun onCreate(savedInstanceState: android.os.Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        // Safety net in case window focus never arrives.
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ run() }, 700)
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) run()
    }
    private fun run() {
        if (done) return
        done = true
        val code = intent?.getStringExtra("code").orEmpty()
        Prefs.withProfile(false) {
            if (!Regex("^[0-9]{4,8}$").matches(code)) {
                android.widget.Toast.makeText(this, tr("کد معتبر پیدا نشد", "No valid code found"), android.widget.Toast.LENGTH_SHORT).show()
            } else {
                val ok = runCatching {
                    val clip = android.content.ClipData.newPlainText("code", code)
                    if (Build.VERSION.SDK_INT >= 33) clip.description.extras = android.os.PersistableBundle().apply {
                        putBoolean("android.content.extra.IS_SENSITIVE", true)
                    }
                    (getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).setPrimaryClip(clip)
                }.onFailure { AppLog.i(this, "notification OTP copy FAILED", it) }.isSuccess
                android.widget.Toast.makeText(this,
                    if (ok) tr("کد کپی شد", "Code copied") else tr("کپی کد ناموفق بود", "Could not copy code"),
                    android.widget.Toast.LENGTH_SHORT).show()
            }
        }
        finish()
        overridePendingTransition(0, 0)
    }
}


