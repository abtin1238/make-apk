package ir.abtin.filemanager;

import java.io.File;
import java.io.IOException;

/** Prepares the private package prefix and the shell init file used by the app terminal. */
public final class PkgEnv {
    private PkgEnv() {}

    /**
     * Creates $filesDir/usr, (re)writes etc/shrc and etc/aliases.sh and returns the extra
     * environment for the PTY child ("KEY=VALUE" lines; PATH_PREPEND is handled natively).
     */
    public static String prepare(String filesDir, String apkPath) throws IOException {
        File prefix = new File(filesDir, "usr");
        PkgCli cli = new PkgCli(prefix);
        cli.ensureDirs();
        String linker = new File("/system/bin/linker64").exists() ? "/system/bin/linker64" : "/system/bin/linker";
        String p = prefix.getPath();
        String shrc =
                "# Abtin terminal init (generated at every session start; put your own settings in $PREFIX/etc/shrc.local)\n"
                        + "export PREFIX='" + p + "'\n"
                        + "export ABTIN_LINKER='" + linker + "'\n"
                        + "export ABTIN_APK='" + apkPath.replace("'", "'\\''") + "'\n"
                        + "export LD_LIBRARY_PATH=\"$PREFIX/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}\"\n"
                        + "pkg() {\n"
                        + "  CLASSPATH=\"$ABTIN_APK\" /system/bin/app_process /system/bin ir.abtin.filemanager.PkgCli \"$@\"\n"
                        + "  _pkg_rc=$?\n"
                        + "  [ -r \"$PREFIX/etc/aliases.sh\" ] && . \"$PREFIX/etc/aliases.sh\"\n"
                        + "  return $_pkg_rc\n"
                        + "}\n"
                        + "alias apt=pkg\n"
                        + "_alpine_run() {\n"
                        + "  _AR=\"$PREFIX/alpine\"\n"
                        + "  [ -f \"$_AR/etc/alpine-release\" ] || { echo 'alpine: not installed (run: alpine setup)' >&2; return 1; }\n"
                        + "  [ -f \"$PREFIX/bin/proot\" ] || { echo 'alpine: proot missing (run: alpine proot <file|url>)' >&2; return 1; }\n"
                        + "  export PROOT_TMP_DIR=\"$PREFIX/tmp\"\n"
                        + "  [ -f \"$PREFIX/libexec/proot-loader\" ] && export PROOT_LOADER=\"$PREFIX/libexec/proot-loader\"\n"
                        + "  _AB=''\n"
                        + "  for _d in /dev /proc /sys /sdcard /storage; do [ -e \"$_d\" ] && _AB=\"$_AB -b $_d\"; done\n"
                        + "  $ABTIN_LINKER \"$PREFIX/bin/proot\" --kill-on-exit --link2symlink -0 -r \"$_AR\" $_AB -w /root \\\n"
                        + "    /usr/bin/env -i HOME=/root USER=root LANG=C.UTF-8 TERM=\"${TERM:-xterm-256color}\" \\\n"
                        + "    PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \"$@\"\n"
                        + "}\n"
                        + "_alpine_aliases() {\n"
                        + "  [ -f \"$PREFIX/alpine/etc/alpine-release\" ] || return 0\n"
                        + "  for _c in apk python3 python pip pip3 git node npm npx curl wget nano vim make gcc; do\n"
                        + "    for _p in /sbin /usr/bin /bin /usr/local/bin; do\n"
                        + "      if [ -e \"$PREFIX/alpine$_p/$_c\" ] || [ -L \"$PREFIX/alpine$_p/$_c\" ]; then alias \"$_c=_alpine_run $_c\"; break; fi\n"
                        + "    done\n"
                        + "  done\n"
                        + "}\n"
                        + "alpine() {\n"
                        + "  case \"$1\" in\n"
                        + "    setup|status|proot|remove|doctor)\n"
                        + "      CLASSPATH=\"$ABTIN_APK\" /system/bin/app_process /system/bin ir.abtin.filemanager.AlpineCli \"$@\"\n"
                        + "      _a_rc=$?; _alpine_aliases; return $_a_rc ;;\n"
                        + "    ''|shell) _alpine_run /bin/sh -l ;;\n"
                        + "    run) shift; _alpine_run \"$@\" ;;\n"
                        + "    update) _alpine_run apk update ;;\n"
                        + "    upgrade) _alpine_run apk upgrade ;;\n"
                        + "    install|add) shift; _alpine_run apk add --no-cache \"$@\"; _a_rc=$?; _alpine_aliases; return $_a_rc ;;\n"
                        + "    uninstall|del) shift; _alpine_run apk del \"$@\"; _a_rc=$?; _alpine_aliases; return $_a_rc ;;\n"
                        + "    bootstrap)\n"
                        + "      [ -f \"$PREFIX/alpine/etc/alpine-release\" ] || alpine setup || return 1\n"
                        + "      _alpine_run apk update && _alpine_run apk add --no-cache python3 py3-pip git; _a_rc=$?; _alpine_aliases; return $_a_rc ;;\n"
                        + "    *) echo 'usage: alpine [shell|run CMD|install PKG..|uninstall PKG..|update|upgrade|bootstrap|setup|proot FILE|status|remove|doctor]' >&2; return 2 ;;\n"
                        + "  esac\n"
                        + "}\n"
                        + "alias ll='ls -lA'\n"
                        + "[ -r \"$PREFIX/etc/aliases.sh\" ] && . \"$PREFIX/etc/aliases.sh\"\n"
                        + "_alpine_aliases\n"
                        + "[ -r \"$PREFIX/etc/shrc.local\" ] && . \"$PREFIX/etc/shrc.local\"\n";
        PkgCli.writeText(new File(prefix, "etc/shrc"), shrc);
        cli.regenAliases(java.util.Collections.<String>emptySet());
        String ld = System.getenv("LD_LIBRARY_PATH");
        StringBuilder env = new StringBuilder();
        env.append("PREFIX=").append(p).append('\n');
        env.append("ENV=").append(p).append("/etc/shrc\n");
        env.append("ABTIN_APK=").append(apkPath).append('\n');
        env.append("ABTIN_LINKER=").append(linker).append('\n');
        env.append("LD_LIBRARY_PATH=").append(p).append("/lib").append(ld == null || ld.isEmpty() ? "" : ":" + ld).append('\n');
        env.append("PATH_PREPEND=").append(p).append("/bin\n");
        return env.toString();
    }
}
