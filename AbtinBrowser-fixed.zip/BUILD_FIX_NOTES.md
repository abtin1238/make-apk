# Android build repair

- Updated Android Gradle Plugin from 9.1.0 to 9.1.1 (the minimum required by the Flutter SDK used by the supplied CI logs).
- Removed the vendored file_picker Android module's stale AGP 7.4.2 buildscript classpath so it uses the root project's single AGP version.
- Kept Kotlin 2.3.20 and Gradle wrapper 9.3.1 unchanged.

Build verification: source/configuration checks and ZIP integrity passed. A full APK build could not be run in this environment because the Flutter SDK is not installed.
