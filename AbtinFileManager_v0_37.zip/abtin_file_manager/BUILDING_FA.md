# راهنمای ساخت Abtin File Manager

## پیش‌نیازها

- Flutter 3.47.9 (Dart 3.13.7)؛ این نسخه برای ساخت این پروژه آزموده شده است
- JDK 17
- Android SDK Platform 36 و Android Build Tools 36.0.0
- Android Gradle Plugin 8.11.1 و Kotlin Gradle Plugin 2.2.20 (در تنظیمات پروژه)
- Gradle Wrapper پروژه نسخهٔ 8.14.3 را به‌صورت خودکار دریافت می‌کند

## ساخت APK Release

از ریشهٔ پروژه اجرا کنید:

```bash
flutter pub get
flutter build apk --release --target-platform android-arm,android-arm64,android-x64
```

خروجی در این مسیر قرار می‌گیرد:

```text
build/app/outputs/flutter-apk/app-release.apk
```

پروژه برای Android API 36 کامپایل می‌شود و حداقل Android API آن 24 است. APK این دستور کتابخانه‌های `arm64-v8a`، `armeabi-v7a` و `x86_64` را دارد و روی همهٔ این دستگاه‌ها نصب می‌شود (حجم بیشتر از APK فقط-ARM64).

## امضای Release با GitHub Actions

هیچ keystore، فایل `key.properties` یا رمز امضایی داخل این ZIP قرار ندارد. برای ساخت نسخهٔ Release از کلید خصوصی ذخیره‌شده در GitHub Actions Secrets استفاده می‌شود. این چهار Secret باید در مخزن GitHub تعریف شده باشند:

- `KEYSTORE_BASE64`: محتوای فایل JKS به‌صورت Base64
- `KEYSTORE_PASSWORD`: رمز keystore
- `KEY_ALIAS`: نام alias کلید
- `KEY_PASSWORD`: رمز کلید

Workflow فایل JKS را فقط هنگام اجرا در محیط موقت GitHub Runner بازیابی می‌کند، صحت آن را بررسی می‌کند و سپس APK را امضا می‌کند. اگر هر Secret موجود نباشد یا کلید معتبر نباشد، فرایند Release متوقف می‌شود و از کلید موقت یا debug برای انتشار استفاده نمی‌کند.

برای ساخت محلی Release، فایل `android/key.properties` را خودتان به‌صورت محلی ایجاد کنید و JKS را خارج از مخزن نگه دارید. این فایل‌ها را commit یا در ZIP عمومی قرار ندهید.

## نکته دربارهٔ سورس اصلاح‌شده

برای سازگاری با Flutter 3.47.9، نسخه‌های Gradle/AGP/Kotlin به‌روزرسانی و ABI خروجی به `arm64-v8a`، `armeabi-v7a` و `x86_64` محدود شده است. آیکون اختصاصی از `assets/icons/NeonGlassFileManagerIcon.png` به اندازه‌های لازم Android تبدیل شده و در لانچر و splash استفاده می‌شود. برنامه هنگام شروع مرحلهٔ بارگذاری را نشان می‌دهد و اگر مقداردهی اولیه شکست بخورد، مرحله و جزئیات خطا را روی صفحه نمایش می‌دهد. بستهٔ `dartssh2` در `vendor/dartssh2` نگهداری می‌شود و یک null-check کوچک برای سازگاری با Dart 3.13 دارد. نسخه‌های وابستگی در `pubspec.lock` ثبت شده‌اند.
