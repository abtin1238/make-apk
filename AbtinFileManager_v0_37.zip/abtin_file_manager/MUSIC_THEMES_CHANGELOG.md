# Music player themes

Added a persistent music-player-only theme selector (`musicPlayerTheme`) with four options:
- original: keeps the existing record + tonearm layout and original accent colour.
- classic: warm gold gramophone-inspired composition with spinning vinyl and reflected equalizer.
- cyber: circular album artwork with a radial spectrum ring.
- neo: soft glass-like album presentation and reflected equalizer.

The selection is stored with SharedPreferences. Existing playback/player service logic, queue, lyrics, seek, shuffle/repeat, EQ, visualizer, sleep timer, and other actions are unchanged.


## Signing hygiene
- Removed the embedded JKS and android/key.properties from the distributable project.
- Release workflows now require the configured GitHub Actions signing secrets and reject missing/invalid keys instead of silently generating a temporary signing key.
