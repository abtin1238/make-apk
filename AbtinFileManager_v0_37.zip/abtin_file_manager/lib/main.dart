import 'services/playlist_store.dart';
import 'package:flutter/material.dart' hide Icon;
import 'widgets/app_icon.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:media_kit/media_kit.dart';
import 'package:provider/provider.dart';
import 'core/app_lock.dart';
import 'core/l10n.dart';
import 'core/settings.dart';
import 'core/theme.dart';
import 'screens/lock_screen.dart';
import 'screens/shell.dart';
import 'services/folder_sizes.dart';
import 'services/media_store.dart';
import 'services/native.dart';
import 'services/player_service.dart';
import 'services/transfer_service.dart';
import 'services/vault_service.dart';

const _startupTimeout = Duration(seconds: 25);
final ValueNotifier<String> _startupStage =
    ValueNotifier('در حال آماده‌سازی برنامه');

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const _StartupScreen());
  // Let the first frame reach the screen before any native/plugin init runs.
  await WidgetsBinding.instance.endOfFrame
      .timeout(const Duration(seconds: 3), onTimeout: () {});
  await _launchApplication();
}

Future<void> _step(String label, Future<void> Function() action) async {
  _startupStage.value = label;
  debugPrint('[startup] START $label');
  try {
    await action().timeout(_startupTimeout);
    debugPrint('[startup] OK $label');
  } catch (error, stack) {
    debugPrint('[startup] FAILED $label: $error\n$stack');
    rethrow;
  }
}

Future<void> _launchApplication() async {
  try {
    await _step(
        'آماده‌سازی پخش‌کننده', () async => MediaKit.ensureInitialized());
    await _step('راه‌اندازی سرویس‌های Android', () async => Native.init());
    await _step('بارگذاری رسانه‌ها', MediaStore.init);
    await _step('بارگذاری فهرست‌های پخش', PlaylistStore.init);
    await _step('بارگذاری برچسب‌های فایل', TagCache.init);
    await _step('بارگذاری اطلاعات پوشه‌ها', FolderSizes.init);
    await _step('بارگذاری زبان برنامه', L.init);

    final settings = AppSettings();
    await _step('بارگذاری تنظیمات برنامه', settings.load);
    final lock = AppLock();
    await _step('آماده‌سازی قفل برنامه', lock.load);
    await _step('پاک‌سازی فایل‌های موقت', () async => VaultService.clearTemp());

    _startupStage.value = 'راه‌اندازی موتور پخش';
    final player = PlayerService();
    // Audio focus/notification setup is optional; a device/plugin problem here
    // should not prevent the file manager UI from opening.
    try {
      await _step('آماده‌سازی پخش پس‌زمینه', player.initBackground);
    } catch (error, stack) {
      debugPrint('[startup] Optional audio setup failed: $error\n$stack');
    }

    runApp(MultiProvider(
      providers: [
        ChangeNotifierProvider.value(value: settings),
        ChangeNotifierProvider.value(value: lock),
        ChangeNotifierProvider(create: (_) => TransferService()),
        ChangeNotifierProvider.value(value: player),
      ],
      child: const AbtinApp(),
    ));
  } catch (error, stack) {
    final failedAt = _startupStage.value;
    FlutterError.reportError(FlutterErrorDetails(
      exception: error,
      stack: stack,
      library: 'Abtin File Manager startup',
    ));
    runApp(_StartupFailureScreen(
      stage: failedAt,
      errorText: error.toString(),
      stackText: stack.toString(),
    ));
  }
}

class _StartupScreen extends StatelessWidget {
  const _StartupScreen();
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true),
        home: Scaffold(
          backgroundColor: const Color(0xFF000003),
          body: SafeArea(
            child: Center(
              child: ValueListenableBuilder<String>(
                valueListenable: _startupStage,
                builder: (context, stage, _) => Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const CircularProgressIndicator(color: Color(0xFF28E8F0)),
                    const SizedBox(height: 20),
                    const Text('Abtin File Manager',
                        style: TextStyle(fontSize: 18)),
                    const SizedBox(height: 8),
                    Text(stage, textAlign: TextAlign.center),
                  ],
                ),
              ),
            ),
          ),
        ),
      );
}

class _StartupFailureScreen extends StatelessWidget {
  final String stage;
  final String errorText;
  final String stackText;
  const _StartupFailureScreen({
    required this.stage,
    required this.errorText,
    required this.stackText,
  });

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true),
        home: Directionality(
          textDirection: TextDirection.rtl,
          child: Scaffold(
            backgroundColor: const Color(0xFF000003),
            appBar: AppBar(title: const Text('خطا در راه‌اندازی برنامه')),
            body: ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Icon(Icons.error_outline_rounded,
                    size: 64, color: Colors.orangeAccent),
                const SizedBox(height: 16),
                Text('برنامه هنگام «$stage» متوقف شد.',
                    style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                const Text(
                    'این پیام را برای پشتیبانی بفرستید؛ صفحهٔ سیاه به خطای قابل‌مشاهده تبدیل شده است.'),
                const SizedBox(height: 16),
                const Text('خطا:',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                SelectableText(errorText, textDirection: TextDirection.ltr),
                const SizedBox(height: 16),
                const Text('جزئیات فنی:',
                    style: TextStyle(fontWeight: FontWeight.bold)),
                SelectableText(stackText, textDirection: TextDirection.ltr),
              ],
            ),
          ),
        ),
      );
}

class AbtinApp extends StatelessWidget {
  const AbtinApp({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return MaterialApp(
      title: 'Abtin File Manager',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(false, s.btnColor, s.btnText, s.look),
      darkTheme: buildTheme(true, s.btnColor, s.btnText, s.look),
      themeMode: s.dark ? ThemeMode.dark : ThemeMode.light,
      locale: Locale(
          GlobalMaterialLocalizations.delegate.isSupported(Locale(L.lang))
              ? L.lang
              : 'en'),
      supportedLocales: [
        for (final c in L.langs)
          if (GlobalMaterialLocalizations.delegate.isSupported(Locale(c)))
            Locale(c)
      ],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      builder: (c, child) => AppStyleScope(
          ver: s.styleVer,
          child: Directionality(
              textDirection: L.rtl ? TextDirection.rtl : TextDirection.ltr,
              child: AppLockGate(child: child!))),
      home: const PermissionGate(),
    );
  }
}
