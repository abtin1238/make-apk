import 'package:flutter/material.dart' hide Icon;
import 'package:provider/provider.dart';
import '../core/color_spec.dart';
import '../core/layouts.dart';
import '../core/looks.dart';
import '../core/settings.dart';
import '../core/theme.dart';
import '../widgets/app_icon.dart';
import 'color_editor.dart';

/// Settings -> theme & colours: choose a look (classic / neon / glass / gradient) and change every colour of it
/// (accent colours, background, cards), with an optional gradient on the accent surfaces.
class ThemeColorsScreen extends StatelessWidget {
  const ThemeColorsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final cs = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final rc = resolveColors(dark, s.themeId, s.themeOv);
    final bgKey = dark ? 'bgD' : 'bgL';
    final cardKey = dark ? 'cardD' : 'cardL';

    Widget head(String t) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
          child: Text(t, style: Theme.of(context).textTheme.titleSmall?.copyWith(color: cs.primary, fontWeight: FontWeight.bold)),
        );

    Widget colorTile(String key, String title, String sub, Color current) {
      final changed = s.themeOv.containsKey(key);
      return ListTile(
        leading: Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(color: current, shape: BoxShape.circle, border: Border.all(color: cs.outline, width: 1)),
        ),
        title: Text(title),
        subtitle: Text(changed ? '${hexOf(current)}  •  ${tr2('تغییر داده شده', 'customised')}' : sub),
        trailing: changed
            ? IconButton(icon: const Icon(Icons.restart_alt_rounded), tooltip: tr2('بازنشانی', 'Reset'), onPressed: () => s.setThemeColor(key, null))
            : const Icon(Icons.chevron_right_rounded),
        onTap: () => showColorSpecSheet(
          context,
          title: title,
          initial: ColorSpec.solid(current.value),
          allowGradient: false,
          onCommit: (c) => s.setThemeColor(key, c.c1),
          onReset: changed ? () => s.setThemeColor(key, null) : null,
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: Text(tr2('تم و رنگ‌ها', 'Theme & colours')), actions: [
        IconButton(icon: const Icon(Icons.restart_alt_rounded), tooltip: tr2('بازنشانی رنگ‌ها', 'Reset colours'), onPressed: s.resetThemeColors),
      ]),
      body: ListView(padding: const EdgeInsets.only(bottom: 28), children: [
        head(tr2('ظاهر برنامه', 'App look')),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Column(children: [
            for (final l in appLooks) _LookCard(look: l, selected: s.look == l.id, onTap: () => s.setLook(l.id)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
          child: Text(
            tr2('با انتخاب هر ظاهر، پالت رنگ، چیدمان و سبک آیکون‌های همان تم اعمال می‌شود؛ بعد از آن می‌توانید هر رنگ را جداگانه عوض کنید.', 'Choosing a look applies its palette, layout and icon style; afterwards you can change every colour on its own.'),
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
        head(tr2('رنگ‌های تم', 'Theme colours')),
        // accent preview
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Container(
            height: 64,
            decoration: Looks.accent(ColorScheme.fromSeed(seedColor: rc.primary, primary: rc.primary, secondary: rc.secondary), radius: BorderRadius.circular(18)),
            alignment: Alignment.center,
            child: Text(tr2('پیش‌نمایش رنگ اصلی', 'Accent preview'), style: TextStyle(color: rc.primary.computeLuminance() > .6 ? Colors.black : Colors.white, fontWeight: FontWeight.w600)),
          ),
        ),
        SwitchListTile(
          secondary: const Icon(Icons.gradient_rounded),
          title: Text(tr2('گرادیانت در بخش‌های اصلی', 'Gradient on accent surfaces')),
          subtitle: Text(tr2('کارت حافظه، منوی کناری و ...: ترکیب رنگ اصلی و دوم', 'Storage card, side menu, ...: primary + secondary colour')),
          value: s.accentGradient,
          onChanged: s.setAccentGradient,
        ),
        colorTile('primary', tr2('رنگ اصلی', 'Primary colour'), tr2('مطابق پالت', 'From the palette'), rc.primary),
        colorTile('secondary', tr2('رنگ دوم (گرادیانت)', 'Secondary colour (gradient)'), tr2('مطابق پالت', 'From the palette'), rc.secondary),
        colorTile(bgKey, tr2('پس‌زمینه', 'Background'), tr2('مطابق پالت', 'From the palette'), rc.bg),
        colorTile(cardKey, tr2('کارت‌ها و پنجره‌ها', 'Cards and dialogs'), tr2('مطابق پالت', 'From the palette'), rc.card),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
          child: Text(
            dark
                ? tr2('رنگ پس‌زمینه و کارت برای حالت تاریک است؛ حالت روشن رنگ‌های جدا دارد.', 'Background and card colours are for dark mode; light mode keeps its own.')
                : tr2('رنگ پس‌زمینه و کارت برای حالت روشن است؛ حالت تاریک رنگ‌های جدا دارد.', 'Background and card colours are for light mode; dark mode keeps its own.'),
            style: Theme.of(context).textTheme.bodySmall,
          ),
        ),
        head(tr2('پالت‌های آماده', 'Ready-made palettes')),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Wrap(spacing: 12, runSpacing: 14, children: [
            for (var i = 0; i < appPalettes.length; i++)
              GestureDetector(
                onTap: () => s.setThemeId(i),
                child: SizedBox(
                  width: 72,
                  child: Column(children: [
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: LinearGradient(colors: [appPalettes[i].primary, appPalettes[i].secondary], begin: Alignment.topLeft, end: Alignment.bottomRight),
                        border: Border.all(color: i == s.themeId ? cs.onSurface : Colors.transparent, width: 3),
                      ),
                      child: i == s.themeId ? const Icon(Icons.check_rounded, color: Colors.white) : null,
                    ),
                    const SizedBox(height: 6),
                    Text(tr2(appPalettes[i].fa, appPalettes[i].en), style: const TextStyle(fontSize: 12), maxLines: 1, overflow: TextOverflow.ellipsis),
                  ]),
                ),
              ),
          ]),
        ),
      ]),
    );
  }
}

class _LookCard extends StatelessWidget {
  final AppLook look;
  final bool selected;
  final VoidCallback onTap;
  const _LookCard({required this.look, required this.selected, required this.onTap});

  /// A tiny card drawn in the style of [look] with the look's own palette.
  Widget _mini(BuildContext context) {
    final pal = appPalettes[look.palette >= 0 ? look.palette : 0];
    final dark = Theme.of(context).brightness == Brightness.dark;
    final bg = dark ? pal.darkBg : pal.lightBg;
    final r = BorderRadius.circular(10);
    BoxDecoration d;
    switch (look.id) {
      case 'neon':
        d = BoxDecoration(color: pal.darkCard, borderRadius: r, border: Border.all(color: pal.primary, width: 1.2), boxShadow: [BoxShadow(color: pal.primary.withOpacity(.45), blurRadius: 8, spreadRadius: -1)]);
        break;
      case 'glass':
        d = BoxDecoration(color: Colors.white.withOpacity(.12), borderRadius: r, border: Border.all(color: Colors.white24));
        break;
      case 'gradient':
        d = BoxDecoration(gradient: LinearGradient(colors: [pal.primary, pal.secondary]), borderRadius: r);
        break;
      default:
        d = BoxDecoration(color: dark ? pal.darkCard : Colors.white, borderRadius: r);
    }
    return Container(
      width: 74,
      height: 62,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(color: look.id == 'neon' ? pal.darkBg : bg, borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white12)),
      child: Container(decoration: d),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: selected ? cs.primary : cs.outlineVariant, width: selected ? 2.2 : 1),
            color: selected ? cs.primary.withOpacity(.08) : null,
          ),
          child: Row(children: [
            _mini(context),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(look.name, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 2),
                Text(look.desc, style: Theme.of(context).textTheme.bodySmall, maxLines: 3, overflow: TextOverflow.ellipsis),
              ]),
            ),
            if (selected) Icon(Icons.check_circle_rounded, color: cs.primary),
          ]),
        ),
      ),
    );
  }
}
