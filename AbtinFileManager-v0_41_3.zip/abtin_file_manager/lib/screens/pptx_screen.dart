import 'dart:io';
import 'dart:math' as math;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Icon;
import 'package:path/path.dart' as p;
import 'package:xml/xml.dart' show XmlElement;
import '../core/l10n.dart';
import '../core/layouts.dart';
import '../services/native.dart';
import '../services/office_service.dart';
import '../services/pptx_service.dart';
import '../widgets/pptx_paint.dart';
import '../widgets/app_icon.dart';
import '../widgets/ui.dart';
import 'color_editor.dart';
import 'saf_prompt.dart';

/// .pptx / .ppsx viewer + editor. Every slide is drawn as it is laid out (text boxes, placeholders, pictures);
/// tap a shape to select it, double-tap (or the pencil) edits its text, the bar below moves / resizes / formats /
/// deletes it. Slides can be added, duplicated, reordered, deleted. Save overwrites the file, "save copy" writes
/// "<name> (edited).pptx".
class PptxScreen extends StatefulWidget {
  final String path;
  const PptxScreen({super.key, required this.path});
  @override
  State<PptxScreen> createState() => _PptxScreenState();
}

class _PptxScreenState extends State<PptxScreen> {
  PptxFile? x;
  int selSlide = -1, selShape = -1;

  @override
  void initState() {
    super.initState();
    PptxFile.open(widget.path).then((v) {
      if (mounted) setState(() => x = v);
    }).catchError((e) {
      if (mounted) {
        snack(context, '$e');
        Navigator.pop(context);
      }
    });
  }

  PShape? get _sel {
    final f = x;
    if (f == null || selSlide < 0 || selSlide >= f.slides.length) return null;
    final sl = f.slides[selSlide];
    return selShape >= 0 && selShape < sl.shapes.length ? sl.shapes[selShape] : null;
  }

  void _clear() {
    selSlide = -1;
    selShape = -1;
  }

  Future<void> _save({required bool copy}) async {
    final f = x;
    if (f == null) return;
    if (!await ensureSdAll(context, [f.z.path])) return;
    try {
      if (copy) {
        final t = await f.z.saveCopy();
        Native.scan(t);
        if (mounted) snack(context, '${L.t('saved')}: ${p.basename(t)}');
      } else {
        await f.z.saveInPlace();
        Native.scan(f.z.path);
        if (mounted) {
          setState(() {});
          snack(context, '${L.t('saved')}: ${p.basename(f.z.path)}');
        }
      }
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _editText(PSlide s, PShape sh) async {
    final f = x!;
    if (sh.paras.isEmpty) return;
    final res = await showDialog<List<({int src, String text})>>(
      context: context,
      builder: (_) => _ParasDialog(initial: [for (final para in sh.paras) f.text(para)], fixed: sh.kind == PKind.table),
    );
    if (res == null) return;
    setState(() => f.applyParas(s, sh, res));
  }

  Future<void> _format(PSlide s, PShape sh) async {
    final f = x!;
    final info = sh.paras.isEmpty ? null : f.paraInfo(s, sh, sh.paras.first);
    final r = await showDialog<_Fmt>(
      context: context,
      builder: (_) => _FormatDialog(size: info?.sizePt ?? 18, bold: info?.bold ?? false, rgb: info?.rgb),
    );
    if (r == null) return;
    setState(() => f.setFormat(s, sh, sizePt: r.size, bold: r.bold, rgb: r.rgb));
  }

  Future<void> _addTextBox(PSlide s, int si) async {
    final f = x!;
    final ctl = TextEditingController();
    final t = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(tr2('افزودن کادر متن', 'Add text box')),
        content: TextField(controller: ctl, autofocus: true, minLines: 1, maxLines: 6),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(c)),
          FilledButton(onPressed: () => Navigator.pop(c, ctl.text), child: Text(L.t('ok'))),
        ],
      ),
    );
    if (t == null || t.trim().isEmpty) return;
    setState(() {
      final i = f.addTextBox(s, t);
      selSlide = si;
      selShape = i;
    });
  }

  Future<void> _addPicture(PSlide s, int si) async {
    final f = x!;
    final r = await FilePicker.platform.pickFiles(type: FileType.image);
    final path = r?.files.single.path;
    if (path == null) return;
    try {
      final bytes = await File(path).readAsBytes();
      final img = await decodeImageFromList(bytes);
      final i = f.addPicture(s, bytes, p.extension(path), img.width, img.height);
      if (i >= 0 && mounted) {
        setState(() {
          selSlide = si;
          selShape = i;
        });
      }
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Widget _bar(PSlide s, PShape sh) {
    final f = x!;
    final cs = Theme.of(context).colorScheme;
    Widget b(IconData ic, String tip, VoidCallback? on) => IconButton(icon: Icon(ic), tooltip: tip, onPressed: on);
    void nudge(double dx, double dy) => setState(() => f.moveShape(s, sh, dx, dy));
    return Material(
      color: cs.surfaceContainerHigh,
      elevation: 6,
      child: SafeArea(
        top: false,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [
            if (sh.hasText) b(Icons.edit_rounded, tr2('ویرایش متن', 'Edit text'), sh.paras.isEmpty ? null : () => _editText(s, sh)),
            if (sh.hasText) b(Icons.format_size_rounded, tr2('قالب‌بندی', 'Format'), sh.paras.isEmpty ? null : () => _format(s, sh)),
            b(Icons.arrow_back_rounded, tr2('چپ', 'Left'), () => nudge(-.01, 0)),
            b(Icons.arrow_upward_rounded, tr2('بالا', 'Up'), () => nudge(0, -.01)),
            b(Icons.arrow_downward_rounded, tr2('پایین', 'Down'), () => nudge(0, .01)),
            b(Icons.arrow_forward_rounded, tr2('راست', 'Right'), () => nudge(.01, 0)),
            b(Icons.rotate_right_rounded, tr2('چرخش', 'Rotate'), () => setState(() => f.rotateBy(s, sh, 15))),
            b(Icons.zoom_in_rounded, tr2('بزرگ‌تر', 'Bigger'), () => setState(() => f.scaleShape(s, sh, 1.1))),
            b(Icons.zoom_out_rounded, tr2('کوچک‌تر', 'Smaller'), () => setState(() => f.scaleShape(s, sh, .9))),
            b(Icons.delete_rounded, L.t('delete'), () async {
              if (await confirm(context, '${L.t('delete')}?')) {
                setState(() {
                  f.deleteShape(s, sh);
                  _clear();
                });
              }
            }),
            b(Icons.close_rounded, tr2('لغو انتخاب', 'Deselect'), () => setState(_clear)),
          ]),
        ),
      ),
    );
  }

  Widget _slideCard(PptxFile f, int i) {
    final s = f.slides[i];
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 4, 4, 10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Expanded(child: Text('${i + 1} / ${f.slides.length}', style: const TextStyle(fontSize: 11, color: Colors.grey))),
            IconButton(icon: const Icon(Icons.add_photo_alternate_rounded, size: 20), tooltip: tr2('افزودن تصویر', 'Add picture'), onPressed: () => _addPicture(s, i)),
            IconButton(icon: const Icon(Icons.text_fields_rounded, size: 20), tooltip: tr2('افزودن کادر متن', 'Add text box'), onPressed: () => _addTextBox(s, i)),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert_rounded, size: 20),
              onSelected: (a) async {
                if (a == 'up') {
                  setState(() {
                    f.move(i, -1);
                    _clear();
                  });
                } else if (a == 'down') {
                  setState(() {
                    f.move(i, 1);
                    _clear();
                  });
                } else if (a == 'dup') {
                  setState(() {
                    f.duplicate(i);
                    _clear();
                  });
                } else if (a == 'blank') {
                  setState(() {
                    f.duplicate(i, blank: true);
                    _clear();
                  });
                } else if (a == 'del') {
                  if (f.slides.length > 1 && await confirm(context, '${L.t('delete')}?')) {
                    setState(() {
                      f.delete(i);
                      _clear();
                    });
                  }
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(value: 'up', child: Text(L.t('moveUp'))),
                PopupMenuItem(value: 'down', child: Text(L.t('moveDown'))),
                PopupMenuItem(value: 'dup', child: Text(L.t('dupSlide'))),
                PopupMenuItem(value: 'blank', child: Text(L.t('newSlide'))),
                PopupMenuItem(value: 'del', child: Text(L.t('delete'))),
              ],
            ),
          ]),
          Padding(padding: const EdgeInsets.only(right: 6), child: _canvas(f, s, i)),
        ]),
      ),
    );
  }

  Color _c(int rgb, [double a = 1]) => Color(0xFF000000 | (rgb & 0xFFFFFF)).withOpacity(a);

  double _gx = 0, _gy = 0;

  Widget _canvas(PptxFile f, PSlide s, int si) {
    return LayoutBuilder(builder: (context, cons) {
      final w = cons.maxWidth;
      final k = w / f.slideW; // px per EMU
      final h = f.slideH * k;
      final pt = k * 12700; // px per point
      final bg = s.bg;
      final bgBase = bg.rgb ?? (bg.grad != null ? bg.grad!.first : 0xFFFFFF);
      final bgc = _c(bgBase);
      final defText = bgc.computeLuminance() < .4 ? Colors.white : Colors.black;
      BoxDecoration deco;
      if (bg.image != null) {
        deco = BoxDecoration(color: bgc, image: DecorationImage(image: MemoryImage(bg.image!), fit: BoxFit.cover));
      } else if (bg.grad != null) {
        final a = bg.gradAngle * math.pi / 180;
        deco = BoxDecoration(gradient: LinearGradient(colors: [for (final g in bg.grad!) _c(g)], begin: Alignment(-math.cos(a), -math.sin(a)), end: Alignment(math.cos(a), math.sin(a))));
      } else {
        deco = BoxDecoration(color: bgc);
      }
      return SizedBox(
        width: w,
        height: h,
        child: ClipRect(
          child: Stack(children: [
            Positioned.fill(child: GestureDetector(onTap: () => setState(_clear), child: DecoratedBox(decoration: deco))),
            for (final sh in s.backShapes) _place(f, s, si, -1, sh, k, pt, defText),
            for (var j = 0; j < s.shapes.length; j++) _place(f, s, si, j, s.shapes[j], k, pt, defText),
          ]),
        ),
      );
    });
  }

  Widget _place(PptxFile f, PSlide s, int si, int j, PShape sh, double k, double pt, Color defText) {
    final selected = j >= 0 && selSlide == si && selShape == j;
    final primary = Theme.of(context).colorScheme.primary;
    final bw = math.max(1.0, sh.w * k), bh = math.max(1.0, sh.h * k);
    Widget body = _body(f, s, sh, k, pt, defText);
    if (j < 0) {
      return Positioned(left: sh.x * k, top: sh.y * k, width: bw, height: bh, child: IgnorePointer(child: Transform.rotate(angle: sh.rot * math.pi / 180, child: body)));
    }
    final canDrag = selected && sh.movable;
    Widget content = Stack(clipBehavior: Clip.none, children: [
      Positioned.fill(child: body),
      Positioned.fill(
        child: IgnorePointer(
          child: DecoratedBox(decoration: BoxDecoration(border: Border.all(color: selected ? primary : Colors.grey.withOpacity(.25), width: selected ? 2 : .5))),
        ),
      ),
      if (canDrag)
        Positioned(
          right: 2,
          bottom: 2,
          width: 24,
          height: 24,
          child: GestureDetector(
            onPanStart: (d) {
              _gx = d.globalPosition.dx;
              _gy = d.globalPosition.dy;
            },
            onPanUpdate: (d) {
              final dx = d.globalPosition.dx - _gx, dy = d.globalPosition.dy - _gy;
              _gx = d.globalPosition.dx;
              _gy = d.globalPosition.dy;
              final r = sh.rot * math.pi / 180;
              final lw = dx * math.cos(r) + dy * math.sin(r), lh = -dx * math.sin(r) + dy * math.cos(r);
              setState(() => f.resizeBy(s, sh, lw / k, lh / k, keepAspect: sh.isPic));
            },
            child: Container(decoration: BoxDecoration(color: primary, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2))),
          ),
        ),
    ]);
    return Positioned(
      left: sh.x * k,
      top: sh.y * k,
      width: bw,
      height: bh,
      child: Transform.rotate(
        angle: sh.rot * math.pi / 180,
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => setState(() {
            selSlide = si;
            selShape = j;
          }),
          onDoubleTap: sh.hasText ? () => _editText(s, sh) : null,
          onPanStart: canDrag
              ? (d) {
                  _gx = d.globalPosition.dx;
                  _gy = d.globalPosition.dy;
                }
              : null,
          onPanUpdate: canDrag
              ? (d) {
                  final dx = d.globalPosition.dx - _gx, dy = d.globalPosition.dy - _gy;
                  _gx = d.globalPosition.dx;
                  _gy = d.globalPosition.dy;
                  setState(() => f.moveBy(s, sh, dx / k, dy / k));
                }
              : null,
          child: content,
        ),
      ),
    );
  }

  Widget _body(PptxFile f, PSlide s, PShape sh, double k, double pt, Color defText) {
    switch (sh.kind) {
      case PKind.pic:
        return sh.image == null ? const SizedBox() : Image.memory(sh.image!, fit: BoxFit.fill, errorBuilder: (_, __, ___) => const SizedBox());
      case PKind.chart:
        return sh.chart == null ? const SizedBox() : CustomPaint(painter: ChartPainter(sh.chart!, defText));
      case PKind.smart:
        return Stack(children: [
          for (final n in sh.smart ?? const <PSmartNode>[])
            Positioned(
              left: n.x * k,
              top: n.y * k,
              width: math.max(1.0, n.w * k),
              height: math.max(1.0, n.h * k),
              child: Transform.rotate(
                angle: n.rot * math.pi / 180,
                child: Stack(children: [
                  Positioned.fill(child: CustomPaint(painter: ShapePainter(geom: n.geom, adj: 16667, cust: const [], fill: n.fill, line: n.line, fillAlpha: 1, grad: null, gradAngle: 90, linePx: n.line == null ? 0 : 1, flipH: false, flipV: false))),
                  Positioned.fill(
                    child: Padding(
                      padding: EdgeInsets.all(math.max(1.0, 45720 * k)),
                      child: Center(
                        child: n.paras.isNotEmpty
                            ? _paras(f.cellParas(s, n.paras, defaultPt: 14), k, pt, n.fill != null && _c(n.fill!).computeLuminance() < .5 ? Colors.white : defText, center: true)
                            : Text(n.plain, textAlign: TextAlign.center, style: TextStyle(fontSize: 14 * pt, color: Colors.white)),
                      ),
                    ),
                  ),
                ]),
              ),
            ),
        ]);
      case PKind.table:
        return _table(f, s, sh, k, pt, defText);
      case PKind.text:
        break;
    }
    final hasGeom = sh.fill != null || sh.grad != null || (sh.line != null && sh.lineW > 0);
    final paras = f.paraList(s, sh);
    Color txt = defText;
    if (sh.fill != null && sh.fillAlpha > .5 && sh.fontClr == null) txt = _c(sh.fill!).computeLuminance() < .45 ? Colors.white : Colors.black;
    final anchor = sh.anchor == 'ctr' ? Alignment.center : (sh.anchor == 'b' ? Alignment.bottomCenter : Alignment.topCenter);
    return Stack(children: [
      if (hasGeom)
        Positioned.fill(
          child: CustomPaint(painter: ShapePainter(geom: sh.geom, adj: sh.adj, cust: sh.cust, fill: sh.fill, line: sh.line, fillAlpha: sh.fillAlpha, grad: sh.grad, gradAngle: sh.gradAngle, linePx: sh.lineW * k, flipH: sh.flipH, flipV: sh.flipV)),
        ),
      if (paras.isNotEmpty)
        Positioned.fill(
          child: ClipRect(
            child: Padding(
              padding: EdgeInsets.fromLTRB(sh.insL * k, sh.insT * k, sh.insR * k, sh.insB * k),
              child: OverflowBox(alignment: anchor, minHeight: 0, maxHeight: double.infinity, child: _paras(paras, k, pt, txt)),
            ),
          ),
        ),
    ]);
  }

  Widget _paras(List<PPara> list, double k, double pt, Color defText, {bool center = false, bool bold = false}) {
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [for (final pp in list) _para(pp, k, pt, defText, center, bold)]);
  }

  Widget _para(PPara pp, double k, double pt, Color defText, bool center, bool bold) {
    final align = center ? TextAlign.center : (pp.align == 'ctr' ? TextAlign.center : (pp.align == 'r' ? TextAlign.right : (pp.align == 'just' ? TextAlign.justify : TextAlign.left)));
    final spans = <InlineSpan>[
      for (final r in pp.runs)
        TextSpan(
          text: r.text,
          style: TextStyle(
            fontSize: r.sizePt * pt * (r.baseline != 0 ? .7 : 1),
            height: 1.15 * pp.lineSpacing,
            fontWeight: (r.bold || bold) ? FontWeight.bold : FontWeight.normal,
            fontStyle: r.italic ? FontStyle.italic : FontStyle.normal,
            decoration: TextDecoration.combine([if (r.underline) TextDecoration.underline, if (r.strike) TextDecoration.lineThrough]),
            color: r.rgb == null ? defText : _c(r.rgb!),
          ),
        ),
    ];
    final hasText = pp.runs.any((r) => r.text.trim().isNotEmpty);
    final txt = Text.rich(
      TextSpan(children: spans.isEmpty ? [TextSpan(text: ' ', style: TextStyle(fontSize: pp.sizePt * pt, height: 1.15))] : spans),
      textAlign: align,
    );
    Widget child = txt;
    if (pp.bullet != null && hasText) {
      final hang = pp.indent < 0 ? -pp.indent * k : pp.sizePt * pt * 1.1;
      child = Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: hang, child: Text(pp.bullet!, style: TextStyle(fontSize: pp.sizePt * pt, height: 1.15 * pp.lineSpacing, color: pp.bulletRgb == null ? defText : _c(pp.bulletRgb!)))),
        Expanded(child: txt),
      ]);
    }
    final startPad = pp.bullet != null && pp.indent < 0 ? math.max(0.0, (pp.marL + pp.indent) * k) : math.max(0.0, pp.marL * k);
    return Directionality(
      textDirection: pp.rtl ? TextDirection.rtl : TextDirection.ltr,
      child: Padding(
        padding: EdgeInsetsDirectional.only(start: startPad, top: pp.spcBef * pt, bottom: pp.spcAft * pt),
        child: child,
      ),
    );
  }

  Widget _table(PptxFile f, PSlide s, PShape sh, double k, double pt, Color defText) {
    final t = sh.table!;
    final rows = <Widget>[];
    for (var r = 0; r < t.rows.length; r++) {
      final cells = <Widget>[];
      var col = 0;
      for (final cell in t.rows[r]) {
        final span = cell.gridSpan < 1 ? 1 : cell.gridSpan;
        var cw = 0.0;
        for (var c = col; c < col + span && c < t.colW.length; c++) {
          cw += t.colW[c];
        }
        col += span;
        if (cell.hMerge) continue;
        int? fill = cell.fill;
        var header = false;
        if (fill == null && t.firstRow && r == 0) {
          fill = t.accent;
          header = true;
        } else if (fill == null && t.bandRow && r.isOdd) {
          fill = 0xE9EBF5;
        }
        final dark = fill != null && _c(fill).computeLuminance() < .5;
        cells.add(SizedBox(
          width: math.max(1.0, cw * k),
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 91440 * k, vertical: 45720 * k),
            decoration: BoxDecoration(color: fill == null ? null : _c(fill), border: Border.all(color: Colors.grey.withOpacity(.55), width: .5)),
            child: _paras(f.cellParas(s, cell.paras), k, pt, dark ? Colors.white : (fill == null ? defText : Colors.black), bold: header),
          ),
        ));
      }
      rows.add(ConstrainedBox(constraints: BoxConstraints(minHeight: t.rowH[r] * k), child: IntrinsicHeight(child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: cells))));
    }
    return ClipRect(child: OverflowBox(alignment: Alignment.topLeft, minHeight: 0, maxHeight: double.infinity, child: Column(mainAxisSize: MainAxisSize.min, children: rows)));
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    final sel = _sel;
    return PopScope(
      canPop: f == null || !f.z.changed,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await confirm(context, tr2('تغییرات ذخیره‌نشده از بین می‌رود. خارج می‌شوید؟', 'Unsaved changes will be lost. Leave?')) && context.mounted) {
          Navigator.pop(context);
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)),
          actions: [
            IconButton(icon: const Icon(Icons.open_in_new_rounded), tooltip: L.t('openWith'), onPressed: () => Native.openWith(widget.path, title: L.t('openWith'))),
            IconButton(
              icon: const Icon(Icons.save_rounded),
              tooltip: tr2('ذخیره', 'Save'),
              onPressed: f == null || !f.z.changed ? null : () => _save(copy: false),
            ),
            PopupMenuButton<String>(
              onSelected: (_) => _save(copy: true),
              itemBuilder: (_) => [PopupMenuItem(value: 'copy', child: Text(L.t('saveCopy')))],
            ),
          ],
        ),
        bottomNavigationBar: f == null || sel == null ? null : _bar(f.slides[selSlide], sel),
        body: f == null
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: f.slides.length,
                itemBuilder: (_, i) => _slideCard(f, i),
              ),
      ),
    );
  }
}

class _ParasDialog extends StatefulWidget {
  final List<String> initial;
  final bool fixed; // table cells: paragraphs can not be added / removed
  const _ParasDialog({required this.initial, this.fixed = false});
  @override
  State<_ParasDialog> createState() => _ParasDialogState();
}

class _Row {
  final int src;
  final TextEditingController c;
  _Row(this.src, String t) : c = TextEditingController(text: t);
}

class _ParasDialogState extends State<_ParasDialog> {
  late final List<_Row> rows = [for (var i = 0; i < widget.initial.length; i++) _Row(i, widget.initial[i])];

  @override
  void dispose() {
    for (final r in rows) {
      r.c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(tr2('ویرایش متن', 'Edit text')),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              for (var i = 0; i < rows.length; i++)
                Row(children: [
                  Expanded(child: TextField(controller: rows[i].c, minLines: 1, maxLines: 6, autofocus: i == 0)),
                  IconButton(
                    icon: const Icon(Icons.remove_circle_outline_rounded, size: 20),
                    tooltip: L.t('delete'),
                    onPressed: widget.fixed || rows.length <= 1 ? null : () => setState(() => rows.removeAt(i).c.dispose()),
                  ),
                ]),
              if (!widget.fixed)
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: TextButton.icon(
                  icon: const Icon(Icons.add_rounded, size: 20),
                  label: Text(tr2('پاراگراف جدید', 'New paragraph')),
                  onPressed: () => setState(() => rows.add(_Row(-1, ''))),
                ),
              ),
            ]),
          ),
        ),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(context)),
          FilledButton(
            onPressed: () => Navigator.pop(context, [for (final r in rows) (src: r.src, text: r.c.text)]),
            child: Text(L.t('ok')),
          ),
        ],
      );
}

class _Fmt {
  final double? size;
  final bool? bold;
  final int? rgb;
  const _Fmt(this.size, this.bold, this.rgb);
}

class _FormatDialog extends StatefulWidget {
  final double size;
  final bool bold;
  final int? rgb;
  const _FormatDialog({required this.size, required this.bold, required this.rgb});
  @override
  State<_FormatDialog> createState() => _FormatDialogState();
}

class _FormatDialogState extends State<_FormatDialog> {
  late double size = widget.size.clamp(6, 120).toDouble();
  late bool bold = widget.bold;
  int? rgb;
  bool colorChanged = false;

  @override
  void initState() {
    super.initState();
    rgb = widget.rgb;
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(tr2('قالب‌بندی متن', 'Text format')),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text('${tr2('اندازه', 'Size')}: ${size.round()} pt'),
              LSlider(value: size, min: 6, max: 120, onChanged: (v) => setState(() => size = v)),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(tr2('ضخیم', 'Bold')), value: bold, onChanged: (v) => setState(() => bold = v)),
              const SizedBox(height: 6),
              Text(tr2('رنگ متن', 'Text colour')),
              const SizedBox(height: 6),
              ColorPickerPanel(
                color: Color(0xFF000000 | (rgb ?? 0x000000)),
                onChanged: (_) {},
                onCommit: (c) => setState(() {
                  rgb = c.value & 0xFFFFFF;
                  colorChanged = true;
                }),
              ),
            ]),
          ),
        ),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(context)),
          FilledButton(onPressed: () => Navigator.pop(context, _Fmt(size, bold, colorChanged ? rgb : null)), child: Text(L.t('ok'))),
        ],
      );
}
