package ir.abtin.sms

import android.graphics.Bitmap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs
import kotlin.math.roundToInt

// ---------- helpers ----------
fun isFa() = Prefs.language.value.let { it == "fa" || (it == "system" && Locale.getDefault().language == "fa") }
fun tr(fa: String, en: String) = if (isFa()) fa else en

fun fmtDay(ms: Long): String = try {
    if (isFa()) android.icu.text.DateFormat.getPatternInstance("yMMMMd", android.icu.util.ULocale("fa_IR@calendar=persian")).format(Date(ms))
    else DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(ms))
} catch (e: Exception) { DateFormat.getDateInstance().format(Date(ms)) }

fun fmtWeekday(ms: Long): String = try {
    if (isFa()) android.icu.text.DateFormat.getPatternInstance("EEEE", android.icu.util.ULocale("fa_IR@calendar=persian")).format(Date(ms))
    else SimpleDateFormat("EEEE", Locale.getDefault()).format(Date(ms))
} catch (e: Exception) { SimpleDateFormat("EEEE", Locale.getDefault()).format(Date(ms)) }

fun fmtClock(ms: Long): String = SimpleDateFormat("HH:mm", Locale.US).format(Date(ms))
fun sameDay(a: Long, b: Long): Boolean { val x = Calendar.getInstance().apply { timeInMillis = a }; val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR) }
private fun startOfDay(ms: Long): Long = Calendar.getInstance().apply { timeInMillis = ms; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
fun daysAgo(ms: Long): Int = ((startOfDay(System.currentTimeMillis()) - startOfDay(ms)) / 86_400_000L).toInt()
fun listNum(s: String) = if (isFa() && Prefs.persianDigits.value) toFaDigits(s) else s
fun fmtList(ms: Long): String = listNum(when (val d = daysAgo(ms)) {
    0 -> fmtClock(ms)
    1 -> tr("دیروز", "Yesterday")
    in 2..6 -> fmtWeekday(ms)
    else -> fmtDay(ms)
}.let { it })
fun fmtChatDay(ms: Long): String = when (daysAgo(ms)) { 0 -> tr("امروز", "Today"); 1 -> tr("دیروز", "Yesterday"); else -> fmtDay(ms) }

fun hl(t: String, q: String, c: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (true) {
        val j = t.indexOf(q, i, true)
        if (j < 0) { append(t.substring(i)); break }
        append(t.substring(i, j))
        withStyle(SpanStyle(background = c.copy(alpha = .4f), fontWeight = FontWeight.Bold)) { append(t.substring(j, j + q.length)) }
        i = j + q.length
    }
}

fun templates(): List<String> = Prefs.templates.value.lines().map { it.trim() }.filter { it.isNotEmpty() }
    .ifEmpty { listOf(tr("باشه", "OK"), tr("بعداً تماس می‌گیرم", "I'll call you later"), tr("ممنون", "Thanks")) }

// ---------- shared UI ----------
@Composable
fun LockScreen() {
    val p = LocalPal.current
    var t by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Lock, null, tint = p.primary, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text(tr("پین را وارد کنید", "Enter PIN"), color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(t, { v -> t = v.filter { it.isDigit() }.take(8); if (t == Prefs.pin.value) Bus.locked.value = false },
            singleLine = true, visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
    }
}

@Composable
fun Backdrop(content: @Composable () -> Unit) {
    val p = LocalPal.current
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.bg2, p.bg)))
        .background(Brush.radialGradient(listOf(Color(0x732F6BFF), Color.Transparent), center = Offset(1100f, 80f), radius = 900f))
        .background(Brush.radialGradient(listOf(Color(0x3D8B3DFF), Color.Transparent), center = Offset(0f, 1900f), radius = 900f))) { content() }
}

@Composable
fun Avatar(repo: SmsRepo?, address: String, name: String, size: Dp, group: Boolean = false) {
    val p = LocalPal.current
    val bmp by produceState<Bitmap?>(null, address) {
        value = if (repo == null || group) null else withContext(Dispatchers.IO) { repo.photo(address) }
    }
    val b = bmp
    if (b != null) Image(b.asImageBitmap(), null, Modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop)
    else if (group) Box(Modifier.size(size).clip(CircleShape).background(p.inBubble), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.People, null, tint = p.text.copy(alpha = .85f), modifier = Modifier.size(size * 0.5f))
    } else {
        val cols = listOf(0xFF3D7BFF, 0xFF8A3DFF, 0xFFFF4D8D, 0xFF1DB954, 0xFFFF8A00, 0xFF00B8D9)
        val c = Color(cols[(name.hashCode() and 0x7fffffff) % cols.size])
        Box(Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(c, c.copy(alpha = .6f)))), contentAlignment = Alignment.Center) {
            Text(name.firstOrNull { it.isLetter() }?.uppercase() ?: "#", color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.4f).sp)
        }
    }
}

@Composable
fun CircleBtn(icon: ImageVector, onClick: () -> Unit, size: Dp = 48.dp, tint: Color? = null, content: @Composable () -> Unit = {}) {
    val p = LocalPal.current
    Box(Modifier.size(size).clip(CircleShape).background(p.surface).border(1.dp, p.line, CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Icon(icon, null, tint = tint ?: p.text, modifier = Modifier.size(22.dp)) }
        content()
    }
}

@Composable
fun IconBtn(icon: ImageVector, tint: Color, onClick: () -> Unit) =
    IconButton(onClick = onClick) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) { Icon(icon, null, tint = tint) }
    }

@Composable
fun PillField(value: String, onChange: (String) -> Unit, placeholder: String, modifier: Modifier = Modifier, leading: ImageVector? = null,
              keyboard: KeyboardOptions = KeyboardOptions.Default, actions: KeyboardActions = KeyboardActions.Default, maxLines: Int = 1) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(50)
    BasicTextField(value, onChange, modifier = modifier.heightIn(min = 49.dp).clip(shape).background(p.bg.copy(alpha = .55f)).border(1.dp, p.line, shape),
        textStyle = TextStyle(color = p.text, fontSize = 16.sp, textDirection = TextDirection.ContentOrRtl), cursorBrush = SolidColor(p.primary),
        maxLines = maxLines, singleLine = maxLines == 1, keyboardOptions = keyboard, keyboardActions = actions,
        decorationBox = { inner ->
            Row(Modifier.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (leading != null) { Icon(leading, null, tint = p.sub, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(10.dp)) }
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (value.isEmpty()) Text(placeholder, color = p.sub, fontSize = 16.sp)
                    inner()
                }
            }
        })
}

@Composable
fun DefaultBanner(onClick: () -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 6.dp).clip(RoundedCornerShape(18.dp)).background(Brush.horizontalGradient(listOf(p.primary, p.primary2)))
        .clickable(onClick = onClick).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(tr("برای دریافت و ارسال پیامک، آبتین SMS را برنامه پیش‌فرض کنید", "Set Abtin SMS as your default SMS app to send & receive"),
            color = p.onPrimary, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Text(tr("تنظیم", "Set"), color = p.onPrimary, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun BottomNav(nav: MutableState<Screen>, phone: Boolean = false) {
    val p = LocalPal.current
    val s = nav.value
    class NavItem(val icon: ImageVector, val label: String, val sel: Boolean, val go: () -> Unit)
    val settings = NavItem(Icons.Default.Settings, tr("تنظیمات", "Settings"), s is Screen.Settings) { Bus.page.value = ""; nav.value = Screen.Settings }
    val padOpen = Bus.pad.value
    val items = if (phone) listOf(
        NavItem(Icons.Default.People, tr("مخاطبین", "Contacts"), s is Screen.Contacts || s is Screen.ContactForm || s is Screen.ContactDetail || s is Screen.Groups) { nav.value = Screen.Contacts },
        NavItem(Icons.Default.History, tr("تاریخچه", "History"), s is Screen.Calls && Bus.callTab.intValue == 0 && !padOpen) { Bus.callTab.intValue = 0; Bus.pad.value = false; nav.value = Screen.Calls },
        NavItem(Icons.Default.Mic, tr("ضبط‌شده", "Recorded"), s is Screen.Calls && Bus.callTab.intValue == 1 && !padOpen) { Bus.callTab.intValue = 1; Bus.pad.value = false; nav.value = Screen.Calls },
        NavItem(Icons.Default.Dialpad, tr("شماره‌گیر", "Dialer"), s is Screen.Calls && padOpen) { Bus.pad.value = true; nav.value = Screen.Calls }
    ) else listOf(
        NavItem(Icons.Default.Home, tr("خانه", "Home"), s is Screen.Dash) { nav.value = Screen.Dash },
        NavItem(Icons.Default.ChatBubble, tr("پیام‌ها", "Messages"), s is Screen.Home) { nav.value = Screen.Home }
    ) + (if (Prefs.showContactsTab.value) listOf(NavItem(Icons.Default.People, tr("مخاطبین", "Contacts"), s is Screen.Contacts || s is Screen.ContactForm || s is Screen.ContactDetail || s is Screen.Groups) { nav.value = Screen.Contacts }) else emptyList<NavItem>()) + settings
    val dens = androidx.compose.ui.platform.LocalDensity.current
    val shape = remember(items.indexOfFirst { it.sel }, items.size, dens.density) { NavNotchShape(items.indexOfFirst { it.sel }, items.size, dens.density) }
    Row(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xCC2332AA), Color(0xF2080E46))), shape).border(1.dp, p.line, shape)
        .navigationBarsPadding().padding(horizontal = 8.dp).padding(top = 22.dp)) {
        items.forEach { it ->
            Column(Modifier.weight(1f).clickable(remember { MutableInteractionSource() }, null) { it.go() }.padding(bottom = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(30.dp).offset(y = if (it.sel) (-26).dp else 0.dp), contentAlignment = Alignment.Center) {
                    if (it.sel) Box(Modifier.requiredSize(58.dp).shadow(14.dp, CircleShape, ambientColor = Color(0xFF7A4CFF), spotColor = Color(0xFF7A4CFF)).clip(CircleShape).background(OrbBrush)
                        .border(1.dp, Color(0x66FFFFFF), CircleShape))
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Icon(it.icon, null, tint = if (it.sel) Color.White else Color(0xFFA9B5F5), modifier = Modifier.size(if (it.sel) 30.dp else 27.dp))
                    }
                }
                Text(it.label, color = if (it.sel) Cyan else Color(0xFFA9B5F5), fontSize = 12.sp, fontWeight = if (it.sel) FontWeight.Bold else FontWeight.Medium,
                    modifier = Modifier.offset(y = if (it.sel) (-18).dp else 0.dp).padding(top = 6.dp), maxLines = 1)
            }
        }
    }
}

/** Bottom bar outline: rounded top corners with a round "hole" (plus a gap) cut under the raised selected orb. */
class NavNotchShape(private val index: Int, private val count: Int, private val density: Float) : Shape {
    override fun createOutline(size: androidx.compose.ui.geometry.Size, layoutDirection: LayoutDirection, density: androidx.compose.ui.unit.Density): androidx.compose.ui.graphics.Outline {
        val d = this.density
        val w = size.width; val h = size.height
        val corner = 34f * d
        val path = androidx.compose.ui.graphics.Path()
        val rect = androidx.compose.ui.geometry.RoundRect(0f, 0f, w, h, androidx.compose.ui.geometry.CornerRadius(corner, corner), androidx.compose.ui.geometry.CornerRadius(corner, corner),
            androidx.compose.ui.geometry.CornerRadius.Zero, androidx.compose.ui.geometry.CornerRadius.Zero)
        if (index < 0 || count <= 0) { path.addRoundRect(rect); return androidx.compose.ui.graphics.Outline.Generic(path) }
        val pad = 8f * d
        val cx = pad + (index + .5f) * (w - 2 * pad) / count
        val cy = 11f * d                      // centre of the raised orb, measured from the top edge
        val r = (29f + 8f) * d                // orb radius + visible gap
        val fil = 12f * d; val drop = 4f * d
        val dx = kotlin.math.sqrt(r * r - (cy - drop) * (cy - drop))
        val ang = Math.toDegrees(kotlin.math.atan2((drop - cy).toDouble(), (-dx).toDouble())).toFloat()  // start angle on the circle (left side)
        path.moveTo(0f, corner)
        path.arcTo(androidx.compose.ui.geometry.Rect(0f, 0f, 2 * corner, 2 * corner), 180f, 90f, false)
        path.lineTo(cx - dx - fil, 0f)
        path.quadraticBezierTo(cx - dx, 0f, cx - dx, drop)
        path.arcTo(androidx.compose.ui.geometry.Rect(cx - r, cy - r, cx + r, cy + r), ang, -(180f + 2f * (ang + 180f)), false)
        path.quadraticBezierTo(cx + dx, 0f, cx + dx + fil, 0f)
        path.lineTo(w - corner, 0f)
        path.arcTo(androidx.compose.ui.geometry.Rect(w - 2 * corner, 0f, w, 2 * corner), 270f, 90f, false)
        path.lineTo(w, h); path.lineTo(0f, h); path.close()
        return androidx.compose.ui.graphics.Outline.Generic(path)
    }
}

// ---------- swipe ----------
class SwipeAct(val icon: ImageVector, val label: String, val color: Color, val removes: Boolean, val run: () -> Unit)

/** Drag left/right to reveal an action; keep dragging past 50% of the width to run it. Partial drag leaves the action button open. */
@Composable
fun SwipeRow(leftAct: SwipeAct?, rightAct: SwipeAct?, enabled: Boolean, content: @Composable () -> Unit) {
    val dir = LocalLayoutDirection.current
    val scope = rememberCoroutineScope()
    val off = remember { Animatable(0f) }
    var width by remember { mutableFloatStateOf(1f) }
    val leftRef by rememberUpdatedState(leftAct); val rightRef by rememberUpdatedState(rightAct)
    val reveal = 92f * LocalDensity.current.density
    fun settle() {
        scope.launch {
            val x = off.value
            val act = if (x > 0) rightRef else leftRef
            when {
                act != null && abs(x) >= width * 0.5f -> {
                    off.animateTo(if (x > 0) width else -width, tween(140))
                    act.run()
                    if (!act.removes) off.animateTo(0f, tween(180))
                }
                act != null && abs(x) >= reveal * 0.6f -> off.animateTo(if (x > 0) reveal else -reveal, tween(160))
                else -> off.animateTo(0f, tween(160))
            }
        }
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.fillMaxWidth().onSizeChanged { width = it.width.toFloat().coerceAtLeast(1f) }) {
            val x = off.value
            val act = if (x > 0) rightAct else if (x < 0) leftAct else null
            if (act != null) {
                val armed = abs(x) >= width * 0.5f
                Box(Modifier.matchParentSize().padding(horizontal = 20.dp, vertical = 3.5.dp).clip(RoundedCornerShape(20.dp))
                    .background(act.color.copy(alpha = if (armed) 1f else .85f))
                    .clickable { scope.launch { act.run(); if (!act.removes) off.animateTo(0f) } },
                    contentAlignment = if (x > 0) Alignment.CenterStart else Alignment.CenterEnd) {
                    Column(Modifier.width(76.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(act.icon, null, tint = Color.White, modifier = Modifier.size(if (armed) 30.dp else 24.dp))
                        Text(act.label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Box(Modifier.absoluteOffset { IntOffset(x.roundToInt(), 0) }
                .pointerInput(enabled, leftAct == null, rightAct == null) {
                    if (!enabled) return@pointerInput
                    detectHorizontalDragGestures(onDragEnd = { settle() }, onDragCancel = { settle() }) { change, dx ->
                        change.consume()
                        val nx = off.value + dx
                        val lo = if (leftRef != null) -width else 0f; val hi = if (rightRef != null) width else 0f
                        scope.launch { off.snapTo(nx.coerceIn(lo, hi)) }
                    }
                }) {
                CompositionLocalProvider(LocalLayoutDirection provides dir) { content() }
                if (abs(x) > 2f) Box(Modifier.matchParentSize().clickable(remember { MutableInteractionSource() }, null) { scope.launch { off.animateTo(0f) } })
            }
        }
    }
}

// ---------- Home ----------
@Composable
fun FilterChipX(label: String, badge: Int?, sel: Boolean, trailing: ImageVector? = null, onClick: () -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(50)
    Row(Modifier.height(37.dp).clip(shape).background(if (sel) p.primary.copy(alpha = .20f) else p.surface)
        .border(if (sel) 1.5.dp else 1.dp, if (sel) p.primary else p.line, shape).clickable(onClick = onClick).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = if (sel) p.text else p.sub, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        if (trailing != null) { Spacer(Modifier.width(4.dp)); Icon(trailing, null, tint = p.sub, modifier = Modifier.size(18.dp)) }
        if (badge != null) {
            Spacer(Modifier.width(10.dp))
            Box(Modifier.defaultMinSize(26.dp, 26.dp).clip(CircleShape).background(if (sel) p.primary else p.line), contentAlignment = Alignment.Center) {
                Text(listNum(badge.toString()), color = if (sel) p.onPrimary else p.text.copy(alpha = .8f), fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(repo: SmsRepo, act: ComponentActivity, nav: MutableState<Screen>, askDefault: () -> Unit) {
    val p = LocalPal.current
    val tick = Bus.tick.intValue
    val scope = rememberCoroutineScope()
    var convs by remember { mutableStateOf<List<Conv>>(emptyList()) }
    LaunchedEffect(tick) { convs = withContext(Dispatchers.IO) { runCatching { repo.purgeOtp() }; runCatching { repo.conversations() }.getOrDefault(emptyList()) } }
    var q by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var filter by remember { mutableIntStateOf(0) }   // 0 all 1 unread 2 contacts 3 unknown 4 archived 5 blocked 6 spam 7 starred
    var catMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var selMore by remember { mutableStateOf(false) }
    var confirmDel by remember { mutableStateOf<Set<Long>?>(null) }
    var selected by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var hidden by remember { mutableStateOf<Set<Long>>(emptySet()) }
    val selMode = selected.isNotEmpty()
    val pins = csv(Prefs.pinned); val arch = csv(Prefs.archived); val blk = csv(Prefs.blocked); val spm = csv(Prefs.spam); val mut = csv(Prefs.muted)
    var hits by remember { mutableStateOf<List<Msg>>(emptyList()) }
    LaunchedEffect(q, tick) { hits = if (q.trim().length < 2) emptyList() else withContext(Dispatchers.IO) { runCatching { repo.searchMessages(q.trim()) }.getOrDefault(emptyList()) } }
    var starredMsgs by remember { mutableStateOf<List<Msg>>(emptyList()) }
    LaunchedEffect(filter, tick, Prefs.starred.value) {
        starredMsgs = if (filter != 7) emptyList() else withContext(Dispatchers.IO) { csv(Prefs.starred).filter { it.startsWith("s") }.mapNotNull { repo.smsById(it.drop(1).toLongOrNull() ?: 0L) }.sortedByDescending { it.date } }
    }
    fun normal(c: Conv) = c.threadId.toString() !in arch && norm(c.address) !in blk && norm(c.address) !in spm
    val visible = convs.filter { it.threadId !in hidden }
    val shown = visible.filter {
        val b = norm(it.address) in blk; val a = it.threadId.toString() in arch; val sp = norm(it.address) in spm
        val tabOk = when (filter) {
            4 -> a && !b; 5 -> b; 6 -> sp && !b; 7 -> false
            else -> !a && !b && !sp && (filter == 0 || (filter == 1 && it.unread > 0) || (filter == 2 && it.name != null) || (filter == 3 && it.name == null))
        }
        tabOk && (q.isBlank() || (it.name ?: it.address).contains(q, true) || it.snippet.contains(q, true))
    }.sortedBy { if (it.threadId.toString() in pins) 0 else 1 }
    val totalCount = visible.count { normal(it) }
    val unreadCount = visible.filter { normal(it) }.sumOf { it.unread }

    fun archiveOf(c: Conv, to: Boolean) { val k = c.threadId.toString(); if ((k in arch) != to) toggle(Prefs.archived, k) }
    fun deleteConvs(l: Collection<Conv>) {
        hidden = hidden + l.map { it.threadId }
        scope.launch(Dispatchers.IO) { l.forEach { runCatching { repo.deleteThread(it.threadId) } }; withContext(Dispatchers.Main) { Bus.tick.intValue++ } }
    }
    fun swipeAct(kind: String, c: Conv): SwipeAct? = when (kind) {
        "delete" -> SwipeAct(Icons.Default.Delete, tr("حذف", "Delete"), Color(0xFFE5484D), true) { deleteConvs(listOf(c)) }
        "archive" -> if (c.threadId.toString() in arch)
            SwipeAct(Icons.Default.Unarchive, tr("بازگردانی", "Unarchive"), Color(0xFF2F6BFF), true) { hidden = hidden + c.threadId; archiveOf(c, false) }
        else SwipeAct(Icons.Default.Archive, tr("بایگانی", "Archive"), Color(0xFF2F6BFF), true) { hidden = hidden + c.threadId; archiveOf(c, true) }
        "read" -> if (c.unread > 0) SwipeAct(Icons.Default.MarkChatRead, tr("خوانده شد", "Read"), Color(0xFF1F9D6B), false) { scope.launch(Dispatchers.IO) { repo.markRead(c.threadId); withContext(Dispatchers.Main) { Bus.tick.intValue++ } } }
        else SwipeAct(Icons.Default.MarkChatUnread, tr("خوانده‌نشده", "Unread"), Color(0xFF1F9D6B), false) { scope.launch(Dispatchers.IO) { repo.markUnread(c.threadId); withContext(Dispatchers.Main) { Bus.tick.intValue++ } } }
        else -> null
    }
    val selConvs = convs.filter { it.threadId in selected }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            if (selMode) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    CircleBtn(Icons.Default.Close, { selected = emptySet() })
                    Text(listNum("${selected.size}") + " " + tr("گفتگو انتخاب شد", "selected"), color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f).padding(horizontal = 12.dp))
                    CircleBtn(Icons.Default.SelectAll, { selected = shown.map { it.threadId }.toSet() }); Spacer(Modifier.width(8.dp))
                    val allArch = selConvs.all { it.threadId.toString() in arch }
                    CircleBtn(if (allArch) Icons.Default.Unarchive else Icons.Default.Archive, {
                        hidden = hidden + selected; selConvs.forEach { archiveOf(it, !allArch) }; selected = emptySet()
                    }); Spacer(Modifier.width(8.dp))
                    CircleBtn(Icons.Default.Delete, { confirmDel = selected }, tint = p.danger); Spacer(Modifier.width(8.dp))
                    Box {
                        CircleBtn(Icons.Default.MoreVert, { selMore = true })
                        DropdownMenu(selMore, { selMore = false }) {
                            DropdownMenuItem(text = { Text(tr("سنجاق / برداشتن", "Pin / Unpin")) }, onClick = { selConvs.forEach { toggle(Prefs.pinned, it.threadId.toString()) }; selMore = false; selected = emptySet() })
                            DropdownMenuItem(text = { Text(tr("بی‌صدا / فعال", "Mute / Unmute")) }, onClick = { selConvs.forEach { toggle(Prefs.muted, it.threadId.toString()) }; selMore = false; selected = emptySet() })
                            DropdownMenuItem(text = { Text(tr("علامت خوانده‌شده", "Mark as read")) }, onClick = { val l = selected; selMore = false; selected = emptySet(); scope.launch(Dispatchers.IO) { l.forEach { repo.markRead(it) }; withContext(Dispatchers.Main) { Bus.tick.intValue++ } } })
                            DropdownMenuItem(text = { Text(tr("علامت خوانده‌نشده", "Mark as unread")) }, onClick = { val l = selected; selMore = false; selected = emptySet(); scope.launch(Dispatchers.IO) { l.forEach { repo.markUnread(it) }; withContext(Dispatchers.Main) { Bus.tick.intValue++ } } })
                            DropdownMenuItem(text = { Text(tr("مسدود کردن", "Block")) }, onClick = { selConvs.forEach { toggle(Prefs.blocked, norm(it.address)) }; selMore = false; selected = emptySet() })
                            DropdownMenuItem(text = { Text(tr("علامت اسپم", "Mark as spam")) }, onClick = { selConvs.forEach { markSpam(norm(it.address), true) }; selMore = false; selected = emptySet() })
                        }
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 14.dp), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(tr("پیام‌ها", "Messages"), color = p.text, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 46.sp)
                        Text(tr("گفتگوها همیشه پل آدم‌ها هستند.", "Conversations are always the bridge between people."), color = p.sub, fontSize = 15.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                    Box {
                        CircleBtn(Icons.Default.MoreVert, { moreMenu = true })
                        DropdownMenu(moreMenu, { moreMenu = false }) {
                            DropdownMenuItem(text = { Text(tr("علامت‌گذاری همه به‌عنوان خوانده‌شده", "Mark all as read")) }, onClick = { moreMenu = false; scope.launch(Dispatchers.IO) { runCatching { repo.markAllRead() }; withContext(Dispatchers.Main) { Bus.tick.intValue++ } } })
                            DropdownMenuItem(text = { Text(tr("پیام‌های ستاره‌دار", "Starred messages")) }, onClick = { moreMenu = false; filter = 7 })
                            DropdownMenuItem(text = { Text(tr("بایگانی", "Archived")) }, onClick = { moreMenu = false; filter = 4 })
                            DropdownMenuItem(text = { Text(tr("اسپم و مسدود", "Spam & blocked")) }, onClick = { moreMenu = false; filter = 6 })
                            DropdownMenuItem(text = { Text(tr("تنظیمات", "Settings")) }, onClick = { moreMenu = false; Bus.page.value = ""; nav.value = Screen.Settings })
                        }
                    }
                    Spacer(Modifier.width(16.dp))
                    CircleBtn(Icons.Default.Search, { searching = !searching; if (!searching) q = "" })
                }
            }
            if (searching) PillField(q, { q = it }, tr("جستجو…", "Search…"), Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp), Icons.Default.Search)
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                FilterChipX(tr("همه", "All"), totalCount, filter == 0) { filter = 0 }
                FilterChipX(tr("خوانده‌نشده", "Unread"), unreadCount, filter == 1) { filter = 1 }
                FilterChipX(tr("مخاطبین", "Contacts"), null, filter == 2) { filter = 2 }
                Box {
                    val catSel = filter >= 3
                    FilterChipX(when (filter) { 3 -> tr("ناشناس", "Unknown"); 4 -> tr("بایگانی", "Archived"); 5 -> tr("مسدود", "Blocked"); 6 -> tr("اسپم", "Spam"); 7 -> tr("ستاره‌دار", "Starred"); else -> tr("دسته‌ها", "Categories") },
                        null, catSel, Icons.Default.KeyboardArrowDown) { catMenu = true }
                    DropdownMenu(catMenu, { catMenu = false }) {
                        listOf(3 to tr("ناشناس", "Unknown"), 7 to tr("ستاره‌دار", "Starred"), 4 to tr("بایگانی", "Archived"), 5 to tr("مسدود", "Blocked"), 6 to tr("اسپم", "Spam")).forEach { (k, l) ->
                            DropdownMenuItem(text = { Text(l) }, onClick = { filter = k; catMenu = false })
                        }
                    }
                }
            }
            if (!isDefaultSms(act)) DefaultBanner(askDefault)
            if (!Prefs.swipeHintDone.value && !selMode && filter != 7) {
                val shape = RoundedCornerShape(20.dp)
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 8.dp).clip(shape).background(p.surface).border(1.dp, p.line, shape).padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(tr("برای گزینه‌های بیشتر، پیام را به چپ بکشید.", "Swipe a message left for more options."), color = p.sub, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.clip(RoundedCornerShape(14.dp)).background(Brush.horizontalGradient(listOf(p.primary, p.primary2))).padding(horizontal = 16.dp, vertical = 8.dp)) {
                        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White, modifier = Modifier.size(22.dp))
                                Icon(Icons.Default.Delete, null, tint = Color.White, modifier = Modifier.size(22.dp))
                            }
                        }
                    }
                    Spacer(Modifier.width(14.dp))
                    Icon(Icons.Default.Close, null, tint = p.sub, modifier = Modifier.size(22.dp).clickable { Prefs.swipeHintDone.value = true })
                }
            }
            if (filter != 7 && shown.isEmpty() && hits.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text(tr("پیامی وجود ندارد", "No messages"), color = p.sub) }
            if (filter == 7 && starredMsgs.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Text(tr("پیام ستاره‌داری وجود ندارد", "No starred messages"), color = p.sub) }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 84.dp)) {
                items(shown, key = { it.threadId }) { c ->
                    SwipeRow(swipeAct(Prefs.swipeLeft.value, c), swipeAct(Prefs.swipeRight.value, c), !selMode) {
                        ConvRow(repo, c, p, c.threadId.toString() in pins, c.threadId.toString() in mut, c.threadId in selected, selMode,
                            { if (selMode) selected = if (c.threadId in selected) selected - c.threadId else selected + c.threadId else nav.value = Screen.Chat(c.threadId, c.address) },
                            { selected = if (c.threadId in selected) selected - c.threadId else selected + c.threadId })
                    }
                }
                if (filter == 7) items(starredMsgs, key = { "st" + it.id }) { m ->
                    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 3.5.dp).clip(RoundedCornerShape(20.dp)).background(p.surface).border(1.dp, p.line, RoundedCornerShape(20.dp))
                        .clickable { nav.value = Screen.Chat(m.threadId, m.address) }.padding(14.dp)) {
                        Text(fixNum(repo.name(m.address) ?: m.address), color = p.text, fontWeight = FontWeight.Bold, style = TextStyle(textDirection = TextDirection.Content))
                        Text(m.body, color = p.sub, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content))
                        Text(fmtDay(m.date) + " " + fmtClock(m.date), color = p.sub.copy(alpha = .7f), fontSize = 12.sp)
                    }
                }
                if (hits.isNotEmpty()) {
                    item { Text(tr("نتایج در متن پیام‌ها", "In messages"), color = p.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 12.dp, bottom = 4.dp)) }
                    items(hits, key = { "m" + it.id }) { m ->
                        Column(Modifier.fillMaxWidth().clickable { nav.value = Screen.Chat(m.threadId, m.address) }.padding(horizontal = 20.dp, vertical = 8.dp)) {
                            Text(fixNum(repo.name(m.address) ?: m.address), color = p.text, fontWeight = FontWeight.SemiBold)
                            Text(hl(m.body, q.trim(), p.primary), color = p.sub, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
        if (!selMode) Box(Modifier.align(Alignment.BottomStart).padding(start = 18.dp, bottom = 10.dp).size(62.dp)
            .shadow(18.dp, CircleShape, ambientColor = p.primary, spotColor = p.primary).clip(CircleShape)
            .background(Brush.linearGradient(listOf(p.primary.copy(alpha = .95f), p.primary2))).clickable { nav.value = Screen.New }, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Edit, null, tint = Color.White, modifier = Modifier.size(28.dp))
        }
    }
    confirmDel?.let { ids ->
        AlertDialog(onDismissRequest = { confirmDel = null }, containerColor = p.surface, titleContentColor = p.text, textContentColor = p.sub,
            title = { Text(tr("حذف گفتگو", "Delete conversations")) },
            text = { Text(tr("${listNum(ids.size.toString())} گفتگو برای همیشه حذف شود؟", "Permanently delete ${ids.size} conversation(s)?")) },
            confirmButton = { TextButton({ deleteConvs(convs.filter { it.threadId in ids }); selected = emptySet(); confirmDel = null }) { Text(tr("حذف", "Delete"), color = p.danger) } },
            dismissButton = { TextButton({ confirmDel = null }) { Text(tr("لغو", "Cancel"), color = p.text) } })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ConvRow(repo: SmsRepo, c: Conv, p: Pal, pinned: Boolean, muted: Boolean, selected: Boolean, selMode: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val title = c.name ?: c.address
    val shape = RoundedCornerShape(20.dp)
    val group = ',' in c.address
    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 3.5.dp).clip(shape)
        .background(if (selected) p.primary.copy(alpha = .16f) else p.surface).border(if (selected) 1.5.dp else 1.dp, if (selected) p.primary else p.line, shape)
        .combinedClickable(onClick = onClick, onLongClick = onLong).padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        if (Prefs.showAvatars.value) {
            Box(contentAlignment = Alignment.BottomEnd) {
                Avatar(repo, c.address.substringBefore(','), title, 47.dp, group)
                if (selected) Box(Modifier.size(20.dp).clip(CircleShape).background(p.primary), contentAlignment = Alignment.Center) { Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(14.dp)) }
            }
            Spacer(Modifier.width(12.dp))
        } else if (selMode) { Checkbox(selected, null); Spacer(Modifier.width(8.dp)) }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(fixNum(title), color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content), modifier = Modifier.weight(1f, false))
                if (pinned) { Spacer(Modifier.width(6.dp)); Icon(Icons.Default.PushPin, null, tint = p.sub, modifier = Modifier.size(14.dp)) }
                if (muted) { Spacer(Modifier.width(6.dp)); Icon(Icons.Default.NotificationsOff, null, tint = p.sub, modifier = Modifier.size(14.dp)) }
            }
            Text(c.snippet, color = if (c.unread > 0) p.text.copy(alpha = .85f) else p.sub, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content))
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(fmtList(c.date), color = p.sub, fontSize = 13.sp)
            if (c.unread > 0) Box(Modifier.padding(top = 6.dp).defaultMinSize(22.dp, 22.dp).clip(CircleShape).background(p.badge), contentAlignment = Alignment.Center) {
                Text(listNum(c.unread.toString()), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp))
            }
        }
    }
}

// ---------- New message ----------
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NewScreen(repo: SmsRepo, nav: MutableState<Screen>) {
    val p = LocalPal.current
    var to by remember { mutableStateOf("") }
    val sel = remember { mutableStateListOf<String>() }
    var contacts by remember { mutableStateOf<List<ContactItem>>(emptyList()) }
    LaunchedEffect(Unit) { contacts = withContext(Dispatchers.IO) { runCatching { repo.contacts() }.getOrDefault(emptyList()) } }
    fun go() {
        val l = sel.toList() + (if (to.any { it.isDigit() }) listOf(to.trim()) else emptyList())
        if (l.isNotEmpty()) nav.value = Screen.Chat(0, l.joinToString(","))
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, { Bus.back.value.invoke() })
            Text(tr("پیام جدید", "New message"), color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(horizontal = 14.dp))
            if (sel.isNotEmpty()) TextButton({ go() }) { Text(tr("ادامه", "Next") + " (${sel.size})", color = p.primary) }
        }
        if (sel.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            sel.toList().forEach { n ->
                Text((contacts.firstOrNull { it.number == n }?.name ?: n) + " ✕", color = p.onPrimary, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(p.primary).clickable { sel.remove(n) }.padding(horizontal = 12.dp, vertical = 6.dp))
            }
        }
        PillField(to, { to = it }, tr("شماره یا نام مخاطب", "Number or contact name"), Modifier.fillMaxWidth().padding(horizontal = 20.dp), Icons.Default.Search,
            KeyboardOptions(imeAction = ImeAction.Go), KeyboardActions(onGo = { go() }))
        if (to.any { it.isDigit() }) Text(tr("ارسال به ", "Send to ") + to, color = p.primary, modifier = Modifier.fillMaxWidth().clickable { go() }.padding(20.dp))
        Text(tr("برای پیام گروهی، روی مخاطبین نگه دارید", "Long-press contacts to start a group message"), color = p.sub, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(contacts.filter { to.isBlank() || it.name.contains(to, true) || it.number.contains(to) }) { c ->
                val on = c.number in sel
                Row(Modifier.fillMaxWidth()
                    .combinedClickable(
                        onClick = { if (sel.isNotEmpty()) { if (on) sel.remove(c.number) else sel.add(c.number) } else nav.value = Screen.Chat(0, c.number) },
                        onLongClick = { if (on) sel.remove(c.number) else sel.add(c.number) })
                    .background(if (on) p.primary.copy(alpha = .15f) else Color.Transparent)
                    .padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(repo, c.number, c.name, 44.dp); Spacer(Modifier.width(12.dp))
                    Column { Text(c.name, color = p.text, fontWeight = FontWeight.SemiBold); Text(c.number, color = p.sub, fontSize = 13.sp) }
                }
            }
        }
    }
}
