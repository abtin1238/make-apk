package com.abtin.filemanager

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel

/** Foreground service shared by the LAN server and big copy jobs (wake lock, optional Wi-Fi lock, progress notification). Channel: abtin/fgs */
class TransferFgService : Service() {
    private var wl: PowerManager.WakeLock? = null
    private var wf: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val text = intent?.getStringExtra("text") ?: ""
        val title = intent?.getStringExtra("title") ?: "Abtin"
        val progress = intent?.getIntExtra("progress", -2) ?: -2
        val wifi = intent?.getBooleanExtra("wifi", false) ?: false
        val ch = "abtin_transfer"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(ch, "Transfers", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, ch) else Notification.Builder(this)
        b.setContentTitle(title).setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload).setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true)
        if (progress >= 0) b.setProgress(100, progress.coerceIn(0, 100), false) else if (progress == -1) b.setProgress(0, 0, true)
        val n = b.build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(7001, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(7001, n)
        if (wl == null) {
            wl = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "abtin:transfer").apply { acquire() }
        }
        // the Wi-Fi lock is only needed while the LAN server is one of the holders
        if (wifi && wf == null) {
            wf = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "abtin:transfer").apply { acquire() }
        } else if (!wifi && wf != null) {
            try { wf?.release() } catch (_: Throwable) {}
            wf = null
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { wl?.release() } catch (_: Throwable) {}
        try { wf?.release() } catch (_: Throwable) {}
        wl = null
        wf = null
        super.onDestroy()
    }
}

object FgsNative {
    fun register(ctx: Context, messenger: BinaryMessenger) {
        MethodChannel(messenger, "abtin/fgs").setMethodCallHandler { call, result ->
            try {
                val i = Intent(ctx, TransferFgService::class.java)
                when (call.method) {
                    "start" -> {
                        i.putExtra("text", call.argument<String>("text") ?: "")
                        i.putExtra("title", call.argument<String>("title") ?: "Abtin")
                        i.putExtra("progress", call.argument<Int>("progress") ?: -2)
                        i.putExtra("wifi", call.argument<Boolean>("wifi") ?: false)
                        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
                    }
                    "stop" -> ctx.stopService(i)
                    else -> { result.notImplemented(); return@setMethodCallHandler }
                }
                result.success(null)
            } catch (e: Throwable) {
                result.error("ERR", e.message, null)
            }
        }
    }
}
