package com.abtin.filemanager

import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File

/** Bluetooth sharing (system Bluetooth app) + Wi-Fi Direct (WifiP2pManager). Channel: abtin/nearby */
@SuppressLint("MissingPermission")
class NearbyNative(private val act: Activity, messenger: BinaryMessenger) : MethodChannel.MethodCallHandler {
    private val ch = MethodChannel(messenger, "abtin/nearby")
    private val wm = act.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private var chan: WifiP2pManager.Channel? = null
    private var receiver: BroadcastReceiver? = null

    init { ch.setMethodCallHandler(this) }

    private fun uris(paths: List<String>): ArrayList<Uri> {
        val auth = "${act.packageName}.abtinfiles"
        return ArrayList(paths.map { FileProvider.getUriForFile(act, auth, File(it)) })
    }

    private fun btSend(paths: List<String>) {
        val list = uris(paths)
        val i = Intent(if (list.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE).apply {
            type = "*/*"
            if (list.size == 1) putExtra(Intent.EXTRA_STREAM, list[0]) else putParcelableArrayListExtra(Intent.EXTRA_STREAM, list)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val bt = Intent(i).setPackage("com.android.bluetooth")
        if (bt.resolveActivity(act.packageManager) != null) {
            act.startActivity(bt)
        } else {
            act.startActivity(Intent.createChooser(i, null))
        }
    }

    private fun peers(l: Collection<WifiP2pDevice>) = l.map { mapOf("name" to it.deviceName, "addr" to it.deviceAddress, "status" to it.status) }

    private fun wfdStart(result: MethodChannel.Result) {
        val m = wm ?: return result.error("NA", "Wi-Fi Direct not available", null)
        if (chan == null) chan = m.initialize(act, act.mainLooper, null)
        val c = chan!!
        if (receiver == null) {
            receiver = object : BroadcastReceiver() {
                override fun onReceive(ctx: Context, intent: Intent) {
                    when (intent.action) {
                        WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION ->
                            ch.invokeMethod("state", intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1) == WifiP2pManager.WIFI_P2P_STATE_ENABLED)
                        WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION ->
                            m.requestPeers(c) { l -> ch.invokeMethod("peers", peers(l.deviceList)) }
                        WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION ->
                            m.requestConnectionInfo(c) { info ->
                                ch.invokeMethod("conn", mapOf(
                                    "connected" to info.groupFormed,
                                    "owner" to info.isGroupOwner,
                                    "ownerIp" to info.groupOwnerAddress?.hostAddress,
                                ))
                            }
                    }
                }
            }
            val f = IntentFilter().apply {
                addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            }
            ContextCompat.registerReceiver(act, receiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
        }
        m.discoverPeers(c, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = result.success(true)
            override fun onFailure(reason: Int) = result.error("DISCOVER", "discoverPeers failed ($reason): turn on Wi-Fi and Location", null)
        })
    }

    private fun wfdStop() {
        try { chan?.let { wm?.stopPeerDiscovery(it, null) } } catch (_: Exception) {}
        try { receiver?.let { act.unregisterReceiver(it) } } catch (_: Exception) {}
        receiver = null
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "btSend" -> { btSend(call.argument<List<String>>("paths")!!); result.success(true) }
                "btSettings" -> { act.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); result.success(true) }
                "btEnabled" -> result.success((act.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter?.isEnabled == true)
                "wfdStart" -> wfdStart(result)
                "wfdStop" -> { wfdStop(); result.success(true) }
                "wfdConnect" -> {
                    val m = wm ?: return result.error("NA", "Wi-Fi Direct not available", null)
                    val cfg = WifiP2pConfig().apply { deviceAddress = call.argument<String>("addr") }
                    m.connect(chan ?: return result.error("NA", "Start discovery first", null), cfg, object : WifiP2pManager.ActionListener {
                        override fun onSuccess() = result.success(true)
                        override fun onFailure(reason: Int) = result.error("CONNECT", "connect failed ($reason)", null)
                    })
                }
                "wfdDisconnect" -> {
                    val m = wm; val c = chan
                    if (m == null || c == null) return result.success(true)
                    m.removeGroup(c, object : WifiP2pManager.ActionListener {
                        override fun onSuccess() = result.success(true)
                        override fun onFailure(reason: Int) = result.success(false)
                    })
                }
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("ERR", e.message, null)
        }
    }
}
