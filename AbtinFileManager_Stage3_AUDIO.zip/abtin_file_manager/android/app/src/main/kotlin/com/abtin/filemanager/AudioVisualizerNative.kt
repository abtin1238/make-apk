package com.abtin.filemanager

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.audiofx.Visualizer
import android.os.Build
import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.EventChannel
import kotlin.math.floor
import kotlin.math.log2
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sqrt

/** Optional Android output-mix spectrum source. It streams levels only, never PCM/audio. */
class AudioVisualizerNative(
    private val context: Context,
    private val messenger: BinaryMessenger,
) : EventChannel.StreamHandler {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var sink: EventChannel.EventSink? = null
    @Volatile private var visualizer: Visualizer? = null

    fun register() {
        EventChannel(messenger, "abtin/audio_viz").setStreamHandler(this)
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink) {
        sink = events
        if (Build.VERSION.SDK_INT >= 23 && context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            events.error("permission", "Audio capture permission is required for the visualizer", null)
            return
        }
        try {
            val v = Visualizer(0)
            val range = Visualizer.getCaptureSizeRange()
            v.captureSize = range[1].coerceAtMost(1024)
            v.setDataCaptureListener(object : Visualizer.OnDataCaptureListener {
                override fun onWaveFormDataCapture(viz: Visualizer?, waveform: ByteArray?, samplingRate: Int) = Unit
                override fun onFftDataCapture(viz: Visualizer?, fft: ByteArray?, samplingRate: Int) {
                    if (fft == null) return
                    val levels = spectrum(fft)
                    main.post { sink?.success(levels) }
                }
            }, (Visualizer.getMaxCaptureRate() / 2).coerceAtLeast(1000), false, true)
            v.enabled = true
            visualizer = v
        } catch (e: Throwable) {
            events.error("visualizer", e.message ?: "Audio visualizer is unavailable on this device", null)
        }
    }

    override fun onCancel(arguments: Any?) {
        sink = null
        stop()
    }

    private fun stop() {
        try { visualizer?.enabled = false } catch (_: Throwable) { }
        try { visualizer?.release() } catch (_: Throwable) { }
        visualizer = null
    }

    private fun spectrum(fft: ByteArray): List<Double> {
        val bins = (fft.size / 2).coerceAtLeast(2)
        val bands = 40
        val logMax = log2(bins.toDouble())
        return (0 until bands).map { band ->
            val start = floor(2.0.pow(logMax * band / bands)).toInt().coerceIn(1, bins - 1)
            val end = floor(2.0.pow(logMax * (band + 1) / bands)).toInt().coerceIn(start + 1, bins)
            var peak = 0.0
            for (bin in start until end) {
                val real = fft[bin * 2].toInt()
                val imag = fft[bin * 2 + 1].toInt()
                peak = maxOf(peak, sqrt((real * real + imag * imag).toDouble()))
            }
            ((20.0 * log10((peak / 128.0).coerceAtLeast(0.0001) + 0.0001) + 60.0) / 60.0).coerceIn(0.0, 1.0)
        }
    }
}
