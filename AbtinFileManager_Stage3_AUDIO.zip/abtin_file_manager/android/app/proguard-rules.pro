# Abtin File Manager – R8/ProGuard rules (used when building with -Pminify=true)

# Archive libraries (reflection / service loading inside)
-keep class com.github.junrar.** { *; }
-dontwarn com.github.junrar.**
-keep class org.apache.commons.compress.** { *; }
-dontwarn org.apache.commons.compress.**
-keep class org.tukaani.xz.** { *; }
-dontwarn org.tukaani.xz.**
# optional codecs referenced by commons-compress that we do not ship
-dontwarn com.github.luben.zstd.**
-dontwarn org.brotli.dec.**
-dontwarn org.objectweb.asm.**
-dontwarn org.osgi.**
-dontwarn javax.annotation.**
-dontwarn org.slf4j.**
-dontwarn org.apache.commons.lang3.**

# PdfBox-Android
-keep class com.tom_roush.pdfbox.** { *; }
-keep class com.tom_roush.fontbox.** { *; }
-dontwarn com.tom_roush.pdfbox.**
-dontwarn com.gemalto.jp2.**

# Our own native bridge classes (MethodChannel handlers)
-keep class com.abtin.filemanager.** { *; }
-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# Flutter's Play-core deferred components are not used
-dontwarn com.google.android.play.core.**

# zip4j (AES zip create/extract, split archives)
-keep class net.lingala.zip4j.** { *; }
-dontwarn net.lingala.zip4j.**
