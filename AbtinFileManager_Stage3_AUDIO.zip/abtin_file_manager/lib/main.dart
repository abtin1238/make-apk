import 'services/playlist_store.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:media_kit/media_kit.dart';
import 'package:provider/provider.dart';
import 'core/app_lock.dart';
import 'core/l10n.dart';
import 'core/settings.dart';
import 'core/theme.dart';
import 'screens/lock_screen.dart';
import 'screens/shell.dart';
import 'services/folder_sizes.dart';
import 'services/media_store.dart';
import 'services/native.dart';
import 'services/player_service.dart';
import 'services/transfer_service.dart';
import 'services/vault_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MediaKit.ensureInitialized();
  Native.init();
  await MediaStore.init();
  await PlaylistStore.init();
  await TagCache.init();
  await FolderSizes.init();
  await L.init();
  final s = AppSettings();
  await s.load();
  final lock = AppLock();
  await lock.load();
  VaultService.clearTemp(); // decrypted vault copies never survive a restart
  final ps = PlayerService();
  await ps.initBackground();
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider.value(value: s),
      ChangeNotifierProvider.value(value: lock),
      ChangeNotifierProvider(create: (_) => TransferService()),
      ChangeNotifierProvider.value(value: ps),
    ],
    child: const AbtinApp(),
  ));
}

class AbtinApp extends StatelessWidget {
  const AbtinApp({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return MaterialApp(
      title: 'Abtin File Manager',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(false),
      darkTheme: buildTheme(true),
      themeMode: s.dark ? ThemeMode.dark : ThemeMode.light,
      locale: Locale(GlobalMaterialLocalizations.delegate.isSupported(Locale(L.lang)) ? L.lang : 'en'),
      supportedLocales: [for (final c in L.langs) if (GlobalMaterialLocalizations.delegate.isSupported(Locale(c))) Locale(c)],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      builder: (c, child) => Directionality(textDirection: L.rtl ? TextDirection.rtl : TextDirection.ltr, child: AppLockGate(child: child!)),
      home: const PermissionGate(),
    );
  }
}
