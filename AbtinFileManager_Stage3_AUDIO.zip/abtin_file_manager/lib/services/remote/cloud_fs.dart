import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter_appauth/flutter_appauth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'remote_fs.dart';

/// OAuth 2 (PKCE, system browser) for Dropbox and Google Drive.
/// The user enters their OWN client id (profile.extra); redirect URI: com.abtin.filemanager:/oauth
class CloudAuth {
  static const redirect = 'com.abtin.filemanager:/oauth';
  static const _app = FlutterAppAuth();

  static AuthorizationServiceConfiguration _cfg(String type) => type == 'dropbox'
      ? const AuthorizationServiceConfiguration(
          authorizationEndpoint: 'https://www.dropbox.com/oauth2/authorize', tokenEndpoint: 'https://api.dropbox.com/oauth2/token')
      : const AuthorizationServiceConfiguration(
          authorizationEndpoint: 'https://accounts.google.com/o/oauth2/v2/auth', tokenEndpoint: 'https://oauth2.googleapis.com/token');

  static Future<void> _store(String id, String access, String? refresh, DateTime? exp) async {
    final p = await SharedPreferences.getInstance();
    final old = _read(p, id);
    await p.setString('tok_$id', jsonEncode({
      'a': access,
      'r': refresh ?? old?['r'],
      'e': (exp ?? DateTime.now().add(const Duration(minutes: 50))).millisecondsSinceEpoch,
    }));
  }

  static Map? _read(SharedPreferences p, String id) {
    try {
      return jsonDecode(p.getString('tok_$id') ?? 'null') as Map?;
    } catch (_) {
      return null;
    }
  }

  static Future<bool> signedIn(String id) async => _read(await SharedPreferences.getInstance(), id) != null;

  static Future<void> signOut(String id) async => (await SharedPreferences.getInstance()).remove('tok_$id');

  static Future<void> login(RemoteProfile pr) async {
    if (pr.extra.trim().isEmpty) throw const RemoteError('Client ID is empty');
    final r = await _app.authorizeAndExchangeCode(AuthorizationTokenRequest(
      pr.extra.trim(),
      redirect,
      serviceConfiguration: _cfg(pr.type),
      scopes: pr.type == 'gdrive' ? ['https://www.googleapis.com/auth/drive'] : null,
      additionalParameters: pr.type == 'dropbox'
          ? {'token_access_type': 'offline'}
          : {'access_type': 'offline', 'prompt': 'consent'},
    ));
    if (r == null || r.accessToken == null) throw const RemoteError('Sign-in cancelled');
    await _store(pr.id, r.accessToken!, r.refreshToken, r.accessTokenExpirationDateTime);
  }

  /// Valid access token (refreshes when it is about to expire).
  static Future<String> token(RemoteProfile pr) async {
    final p = await SharedPreferences.getInstance();
    final t = _read(p, pr.id);
    if (t == null) throw const RemoteError('Not signed in');
    final exp = DateTime.fromMillisecondsSinceEpoch((t['e'] as num).toInt());
    if (exp.isAfter(DateTime.now().add(const Duration(minutes: 2)))) return '${t['a']}';
    final rt = t['r'] as String?;
    if (rt == null) throw const RemoteError('Session expired – sign in again');
    final r = await _app.token(TokenRequest(pr.extra.trim(), redirect, refreshToken: rt, serviceConfiguration: _cfg(pr.type), grantType: 'refresh_token'));
    if (r == null || r.accessToken == null) throw const RemoteError('Session expired – sign in again');
    await _store(pr.id, r.accessToken!, r.refreshToken, r.accessTokenExpirationDateTime);
    return r.accessToken!;
  }
}

class _Json {
  final HttpClient h = HttpClient();
  Future<Map<String, dynamic>> call(String method, Uri u, String token, {Object? body, Map<String, String>? headers}) async {
    final r = await h.openUrl(method, u);
    r.headers.set('Authorization', 'Bearer $token');
    headers?.forEach(r.headers.set);
    if (body != null) {
      final b = utf8.encode(jsonEncode(body));
      r.headers.set('Content-Type', 'application/json');
      r.headers.contentLength = b.length;
      r.add(b);
    }
    final res = await r.close();
    final text = await utf8.decodeStream(res);
    if (res.statusCode >= 300) throw RemoteError('HTTP ${res.statusCode}: ${text.length > 200 ? text.substring(0, 200) : text}');
    if (text.trim().isEmpty) return {};
    final j = jsonDecode(text);
    return j is Map<String, dynamic> ? j : {'value': j};
  }
}

String _asciiJson(Object o) {
  final s = jsonEncode(o);
  final b = StringBuffer();
  for (final c in s.codeUnits) {
    b.write(c > 126 ? '\\u${c.toRadixString(16).padLeft(4, '0')}' : String.fromCharCode(c));
  }
  return b.toString();
}

// ───────────────────────── Dropbox ─────────────────────────
class DropboxFs extends RemoteFs {
  final RemoteProfile pr;
  final _j = _Json();
  DropboxFs(this.pr);

  Future<String> _t() => CloudAuth.token(pr);
  static String _p(String path) => path == '/' ? '' : path;

  @override
  Future<void> connect() async {
    await CloudAuth.token(pr);
    await list('/');
  }

  @override
  Future<List<RemoteEntry>> list(String path) async {
    final out = <RemoteEntry>[];
    var j = await _j.call('POST', Uri.parse('https://api.dropboxapi.com/2/files/list_folder'), await _t(), body: {'path': _p(path), 'limit': 2000});
    while (true) {
      for (final e in (j['entries'] as List)) {
        final m = e as Map;
        final dir = m['.tag'] == 'folder';
        out.add(RemoteEntry('${m['name']}', dir,
            size: (m['size'] as num?)?.toInt(), modified: DateTime.tryParse('${m['server_modified'] ?? ''}')?.toLocal()));
      }
      if (j['has_more'] != true) break;
      j = await _j.call('POST', Uri.parse('https://api.dropboxapi.com/2/files/list_folder/continue'), await _t(), body: {'cursor': j['cursor']});
    }
    return out;
  }

  @override
  Future<void> download(String path, String local, {Prog? onProgress}) async {
    final r = await _j.h.postUrl(Uri.parse('https://content.dropboxapi.com/2/files/download'));
    r.headers.set('Authorization', 'Bearer ${await _t()}');
    r.headers.set('Dropbox-API-Arg', _asciiJson({'path': path}));
    final res = await r.close();
    if (res.statusCode != 200) {
      final t = await utf8.decodeStream(res);
      throw RemoteError('HTTP ${res.statusCode}: $t');
    }
    final total = res.contentLength;
    final sink = File(local).openWrite();
    var got = 0;
    try {
      await for (final c in res) {
        sink.add(c);
        got += c.length;
        onProgress?.call(got, total < 0 ? 0 : total);
      }
    } finally {
      await sink.close();
    }
  }

  static const _chunk = 8 * 1024 * 1024;

  Future<void> _post(String url, String token, Map arg, Stream<List<int>>? data, int len) async {
    final r = await _j.h.postUrl(Uri.parse(url));
    r.headers.set('Authorization', 'Bearer $token');
    r.headers.set('Dropbox-API-Arg', _asciiJson(arg));
    r.headers.set('Content-Type', 'application/octet-stream');
    r.headers.contentLength = len;
    if (data != null) await r.addStream(data);
    final res = await r.close();
    final t = await utf8.decodeStream(res);
    if (res.statusCode >= 300) throw RemoteError('HTTP ${res.statusCode}: $t');
    _last = t;
  }

  String _last = '';

  @override
  Future<void> upload(String local, String path, {Prog? onProgress}) async {
    final f = File(local);
    final len = await f.length();
    if (len <= 140 * 1024 * 1024) {
      var sent = 0;
      await _post('https://content.dropboxapi.com/2/files/upload', await _t(),
          {'path': path, 'mode': 'overwrite', 'mute': true},
          f.openRead().map((c) {
            sent += c.length;
            onProgress?.call(sent, len);
            return c;
          }),
          len);
      return;
    }
    // upload session for big files
    final raf = await f.open();
    try {
      await _post('https://content.dropboxapi.com/2/files/upload_session/start', await _t(), {'close': false}, null, 0);
      final sid = (jsonDecode(_last) as Map)['session_id'];
      var off = 0;
      while (off < len) {
        final n = (len - off) < _chunk ? len - off : _chunk;
        final buf = Uint8List(n);
        await raf.setPosition(off);
        await raf.readInto(buf);
        final last = off + n >= len;
        if (!last) {
          await _post('https://content.dropboxapi.com/2/files/upload_session/append_v2', await _t(),
              {'cursor': {'session_id': sid, 'offset': off}, 'close': false}, Stream.value(buf), n);
        } else {
          await _post('https://content.dropboxapi.com/2/files/upload_session/finish', await _t(), {
            'cursor': {'session_id': sid, 'offset': off},
            'commit': {'path': path, 'mode': 'overwrite', 'mute': true},
          }, Stream.value(buf), n);
        }
        off += n;
        onProgress?.call(off, len);
      }
    } finally {
      await raf.close();
    }
  }

  @override
  Future<void> mkdir(String path) async {
    await _j.call('POST', Uri.parse('https://api.dropboxapi.com/2/files/create_folder_v2'), await _t(), body: {'path': path});
  }

  @override
  Future<void> delete(String path, bool dir) async {
    await _j.call('POST', Uri.parse('https://api.dropboxapi.com/2/files/delete_v2'), await _t(), body: {'path': path});
  }

  @override
  Future<void> rename(String from, String to) async {
    await _j.call('POST', Uri.parse('https://api.dropboxapi.com/2/files/move_v2'), await _t(), body: {'from_path': from, 'to_path': to});
  }

  @override
  Future<void> close() async => _j.h.close(force: true);
}

// ───────────────────────── Google Drive ─────────────────────────
class DriveFs extends RemoteFs {
  final RemoteProfile pr;
  final _j = _Json();
  final Map<String, String> _ids = {'/': 'root'};
  final Map<String, String> _mime = {};
  DriveFs(this.pr);

  Future<String> _t() => CloudAuth.token(pr);
  static const _api = 'https://www.googleapis.com/drive/v3';
  static const _folder = 'application/vnd.google-apps.folder';

  @override
  Future<void> connect() async {
    await CloudAuth.token(pr);
    await list('/');
  }

  String _q(String s) => s.replaceAll('\\', '\\\\').replaceAll("'", "\\'");

  Future<String> _idOf(String path) async {
    if (_ids.containsKey(path)) return _ids[path]!;
    final pid = await _idOf(RPath.parent(path));
    final j = await _j.call('GET', Uri.parse('$_api/files').replace(queryParameters: {
      'q': "'$pid' in parents and name = '${_q(RPath.name(path))}' and trashed = false",
      'fields': 'files(id,mimeType)',
      'pageSize': '1',
    }), await _t());
    final l = j['files'] as List;
    if (l.isEmpty) throw RemoteError('Not found: $path');
    _ids[path] = '${l.first['id']}';
    _mime[path] = '${l.first['mimeType']}';
    return _ids[path]!;
  }

  @override
  Future<List<RemoteEntry>> list(String path) async {
    final id = await _idOf(path);
    final out = <RemoteEntry>[];
    String? pageToken;
    do {
      final j = await _j.call('GET', Uri.parse('$_api/files').replace(queryParameters: {
        'q': "'$id' in parents and trashed = false",
        'fields': 'nextPageToken,files(id,name,mimeType,size,modifiedTime)',
        'pageSize': '1000',
        'orderBy': 'folder,name',
        if (pageToken != null) 'pageToken': pageToken,
      }), await _t());
      for (final e in (j['files'] as List)) {
        final m = e as Map;
        final name = '${m['name']}'.replaceAll('/', '_');
        final cp = RPath.join(path, name);
        _ids[cp] = '${m['id']}';
        _mime[cp] = '${m['mimeType']}';
        out.add(RemoteEntry(name, m['mimeType'] == _folder,
            size: int.tryParse('${m['size'] ?? ''}'), modified: DateTime.tryParse('${m['modifiedTime'] ?? ''}')?.toLocal()));
      }
      pageToken = j['nextPageToken'] as String?;
    } while (pageToken != null);
    return out;
  }

  @override
  Future<void> download(String path, String local, {Prog? onProgress}) async {
    final id = await _idOf(path);
    final native = (_mime[path] ?? '').startsWith('application/vnd.google-apps');
    final u = native
        ? Uri.parse('$_api/files/$id/export').replace(queryParameters: {'mimeType': 'application/pdf'})
        : Uri.parse('$_api/files/$id').replace(queryParameters: {'alt': 'media'});
    final r = await _j.h.getUrl(u);
    r.headers.set('Authorization', 'Bearer ${await _t()}');
    final res = await r.close();
    if (res.statusCode != 200) {
      final t = await utf8.decodeStream(res);
      throw RemoteError('HTTP ${res.statusCode}: $t');
    }
    final total = res.contentLength;
    final sink = File(local).openWrite();
    var got = 0;
    try {
      await for (final c in res) {
        sink.add(c);
        got += c.length;
        onProgress?.call(got, total < 0 ? 0 : total);
      }
    } finally {
      await sink.close();
    }
  }

  @override
  Future<void> upload(String local, String path, {Prog? onProgress}) async {
    final f = File(local);
    final len = await f.length();
    final pid = await _idOf(RPath.parent(path));
    final tok = await _t();
    final init = await _j.h.postUrl(Uri.parse('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable'));
    init.headers.set('Authorization', 'Bearer $tok');
    init.headers.set('Content-Type', 'application/json; charset=UTF-8');
    init.headers.set('X-Upload-Content-Length', '$len');
    final meta = utf8.encode(jsonEncode({'name': RPath.name(path), 'parents': [pid]}));
    init.headers.contentLength = meta.length;
    init.add(meta);
    final ir = await init.close();
    final loc = ir.headers.value('location');
    final it = await utf8.decodeStream(ir);
    if (ir.statusCode != 200 || loc == null) throw RemoteError('HTTP ${ir.statusCode}: $it');
    final put = await _j.h.putUrl(Uri.parse(loc));
    put.headers.contentLength = len;
    var sent = 0;
    await put.addStream(f.openRead().map((c) {
      sent += c.length;
      onProgress?.call(sent, len);
      return c;
    }));
    final pr2 = await put.close();
    final t = await utf8.decodeStream(pr2);
    if (pr2.statusCode >= 300) throw RemoteError('HTTP ${pr2.statusCode}: $t');
    try {
      _ids[path] = '${(jsonDecode(t) as Map)['id']}';
    } catch (_) {}
  }

  @override
  Future<void> mkdir(String path) async {
    final pid = await _idOf(RPath.parent(path));
    final j = await _j.call('POST', Uri.parse('$_api/files'), await _t(), body: {'name': RPath.name(path), 'mimeType': _folder, 'parents': [pid]});
    _ids[path] = '${j['id']}';
    _mime[path] = _folder;
  }

  @override
  Future<void> delete(String path, bool dir) async {
    final id = await _idOf(path);
    await _j.call('PATCH', Uri.parse('$_api/files/$id'), await _t(), body: {'trashed': true}); // trash, not permanent
    _ids.removeWhere((k, v) => k == path || k.startsWith('$path/'));
  }

  @override
  Future<void> rename(String from, String to) async {
    final id = await _idOf(from);
    final q = <String, String>{};
    if (RPath.parent(from) != RPath.parent(to)) {
      q['addParents'] = await _idOf(RPath.parent(to));
      q['removeParents'] = await _idOf(RPath.parent(from));
    }
    await _j.call('PATCH', Uri.parse('$_api/files/$id').replace(queryParameters: q.isEmpty ? null : q), await _t(), body: {'name': RPath.name(to)});
    _ids.removeWhere((k, v) => k == from || k.startsWith('$from/'));
  }

  @override
  Future<void> close() async => _j.h.close(force: true);
}
