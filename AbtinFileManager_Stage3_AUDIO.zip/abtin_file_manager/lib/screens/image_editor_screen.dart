import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../widgets/ui.dart';

class _Prep {
  final Uint8List preview;
  final int w, h;
  _Prep(this.preview, this.w, this.h);
}

_Prep _prepare(Uint8List bytes) {
  var im = img.decodeImage(bytes);
  if (im == null) throw Exception('decode');
  im = img.bakeOrientation(im);
  final w = im.width, h = im.height;
  if (w > 2048 || h > 2048) {
    im = img.copyResize(im, width: w >= h ? 2048 : null, height: h > w ? 2048 : null);
  }
  final out = im.hasAlpha ? img.encodePng(im) : img.encodeJpg(im, quality: 90);
  return _Prep(Uint8List.fromList(out), w, h);
}

Uint8List _render(Map<String, dynamic> a) {
  var im = img.decodeImage(a['bytes'] as Uint8List)!;
  im = img.bakeOrientation(im);
  final t = a['turns'] as int;
  if (t != 0) im = img.copyRotate(im, angle: t * 90);
  if (a['fh'] as bool) im = img.flip(im, direction: img.FlipDirection.horizontal);
  if (a['fv'] as bool) im = img.flip(im, direction: img.FlipDirection.vertical);
  final c = (a['crop'] as List).cast<double>();
  final x = (c[0] * im.width).round().clamp(0, im.width - 1);
  final y = (c[1] * im.height).round().clamp(0, im.height - 1);
  final w = ((c[2] - c[0]) * im.width).round().clamp(1, im.width - x);
  final h = ((c[3] - c[1]) * im.height).round().clamp(1, im.height - y);
  if (x != 0 || y != 0 || w != im.width || h != im.height) im = img.copyCrop(im, x: x, y: y, width: w, height: h);
  final b = a['b'] as double, ct = a['c'] as double, s = a['s'] as double;
  if (b != 1 || ct != 1 || s != 1) im = img.adjustColor(im, brightness: b, contrast: ct, saturation: s);
  switch (a['ext'] as String) {
    case 'png': return Uint8List.fromList(img.encodePng(im));
    case 'bmp': return Uint8List.fromList(img.encodeBmp(im));
    case 'gif': return Uint8List.fromList(img.encodeGif(im));
    default: return Uint8List.fromList(img.encodeJpg(im, quality: 95));
  }
}

enum _Tool { none, crop, adjust }

class ImageEditorScreen extends StatefulWidget {
  final String path;
  const ImageEditorScreen({super.key, required this.path});
  @override
  State<ImageEditorScreen> createState() => _ImageEditorScreenState();
}

class _ImageEditorScreenState extends State<ImageEditorScreen> {
  _Prep? prep;
  String? err;
  int turns = 0;
  bool fh = false, fv = false;
  Rect crop = const Rect.fromLTRB(0, 0, 1, 1);
  double? ratio;
  double br = 1, ct = 1, sat = 1;
  _Tool tool = _Tool.none;

  static const _full = Rect.fromLTRB(0, 0, 1, 1);

  bool get dirty => turns != 0 || fh || fv || crop != _full || br != 1 || ct != 1 || sat != 1;
  double get dw => (turns.isOdd ? prep!.h : prep!.w).toDouble();
  double get dh => (turns.isOdd ? prep!.w : prep!.h).toDouble();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final b = await File(widget.path).readAsBytes();
      final r = await compute(_prepare, b);
      if (mounted) setState(() => prep = r);
    } catch (e) {
      if (mounted) setState(() => err = '${L.t('error')}: $e');
    }
  }

  void _resetCrop() { crop = _full; ratio = null; }

  void _rot(int d) => setState(() { turns = (turns + d) % 4; if (turns < 0) turns += 4; _resetCrop(); });
  void _flip(bool h) => setState(() { if (h) { fh = !fh; } else { fv = !fv; } _resetCrop(); });

  void _preset(double? r) {
    // r = width / height in pixels, null = free
    setState(() {
      ratio = r;
      if (r == null) return;
      final a = dw / dh;
      final rw = r > a ? 1.0 : r * dh / dw;
      final rh = r > a ? (dw / r) / dh : 1.0;
      crop = Rect.fromCenter(center: const Offset(.5, .5), width: rw, height: rh);
    });
  }

  List<double> _matrix() {
    const lr = .2126, lg = .7152, lb = .0722;
    final f = br * ct, o = 127.5 * (1 - ct), s = sat;
    final a = (lr * (1 - s) + s) * f, b = lg * (1 - s) * f, c = lb * (1 - s) * f;
    final d = lr * (1 - s) * f, e = (lg * (1 - s) + s) * f, g = lb * (1 - s) * f;
    final h = lr * (1 - s) * f, i = lg * (1 - s) * f, j = (lb * (1 - s) + s) * f;
    return [a, b, c, 0, o, d, e, g, 0, o, h, i, j, 0, o, 0, 0, 0, 1, 0];
  }

  Future<void> _save() async {
    final ext = FileOps.ext(widget.path);
    final canOverwrite = const {'jpg', 'jpeg', 'png', 'bmp', 'gif'}.contains(ext);
    final outExt = switch (ext) { 'png' => 'png', 'bmp' => 'bmp', 'gif' => 'gif', 'jpg' || 'jpeg' => 'jpg', _ => 'png' };
    final choice = await showModalBottomSheet<bool>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.save_alt_rounded), title: Text(L.t('saveCopy')), onTap: () => Navigator.pop(context, false)),
          if (canOverwrite) ListTile(leading: const Icon(Icons.save_rounded), title: Text(L.t('overwrite')), onTap: () => Navigator.pop(context, true)),
        ]),
      ),
    );
    if (choice == null || !mounted) return;
    if (!await ensureSdAll(context, [widget.path])) return;
    if (!mounted) return;
    String? target;
    final ok = await busy(context, () async {
      final bytes = await File(widget.path).readAsBytes();
      final out = await compute(_render, <String, dynamic>{
        'bytes': bytes, 'turns': turns, 'fh': fh, 'fv': fv,
        'crop': [crop.left, crop.top, crop.right, crop.bottom],
        'b': br, 'c': ct, 's': sat, 'ext': outExt,
      });
      final t = choice ? widget.path : FileOps.unique(p.dirname(widget.path), '${p.basenameWithoutExtension(widget.path)} (edited).$outExt');
      if (await Saf.use(t)) {
        await Saf.writeBytes(t, out);
      } else {
        final tmp = '$t.tmp';
        try {
          await File(tmp).writeAsBytes(out, flush: true);
          await File(tmp).rename(t);
        } catch (_) {
          try { await File(tmp).delete(); } catch (_) {}
          rethrow;
        }
      }
      target = t;
    });
    if (!ok || target == null || !mounted) return;
    PaintingBinding.instance.imageCache.clear();
    PaintingBinding.instance.imageCache.clearLiveImages();
    await Native.scan(target!);
    if (mounted) Navigator.pop(context, target);
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: !dirty,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await confirm(context, L.t('discard')) && context.mounted) Navigator.pop(context);
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black54,
          title: Text(L.t('edit'), style: const TextStyle(fontSize: 16)),
          actions: [
            if (dirty)
              IconButton(
                icon: const Icon(Icons.restart_alt_rounded),
                tooltip: L.t('reset'),
                onPressed: () => setState(() { turns = 0; fh = fv = false; _resetCrop(); br = ct = sat = 1; }),
              ),
            IconButton(icon: const Icon(Icons.check_rounded), tooltip: L.t('save'), onPressed: dirty && prep != null ? _save : null),
          ],
        ),
        body: err != null
            ? Center(child: Text(err!, style: const TextStyle(color: Colors.white70)))
            : prep == null
                ? const Center(child: CircularProgressIndicator())
                : Column(children: [
                    Expanded(child: Padding(padding: const EdgeInsets.all(12), child: _canvas())),
                    _panel(),
                    _bar(),
                  ]),
      ),
    );
  }

  Widget _canvas() => Center(
        child: AspectRatio(
          aspectRatio: dw / dh,
          child: Stack(fit: StackFit.expand, children: [
            Transform.scale(
              scaleX: fh ? -1 : 1,
              scaleY: fv ? -1 : 1,
              child: RotatedBox(
                quarterTurns: turns,
                child: ColorFiltered(
                  colorFilter: ColorFilter.matrix(_matrix()),
                  child: Image.memory(prep!.preview, fit: BoxFit.fill, gaplessPlayback: true),
                ),
              ),
            ),
            if (tool == _Tool.crop) _CropOverlay(rect: crop, ratio: ratio, onChanged: (r) => setState(() => crop = r)),
          ]),
        ),
      );

  Widget _panel() {
    if (tool == _Tool.crop) {
      Widget chip(String t, double? r) => Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: ChoiceChip(label: Text(t), selected: ratio == r && (r != null || crop != _full || ratio == null), onSelected: (_) => r == null && t == L.t('reset') ? setState(_resetCrop) : _preset(r)),
          );
      return SizedBox(
        height: 52,
        child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
          chip(L.t('freeCrop'), null), chip('1:1', 1), chip('4:3', 4 / 3), chip('3:4', 3 / 4), chip('16:9', 16 / 9), chip('9:16', 9 / 16),
        ]),
      );
    }
    if (tool == _Tool.adjust) {
      Widget row(String t, double v, double min, double max, ValueChanged<double> f) => Row(children: [
            SizedBox(width: 90, child: Padding(padding: const EdgeInsets.only(left: 12), child: Text(t, style: const TextStyle(color: Colors.white70, fontSize: 13)))),
            Expanded(child: Slider(value: v, min: min, max: max, onChanged: (x) => setState(() => f(x)))),
          ]);
      return Column(mainAxisSize: MainAxisSize.min, children: [
        row(L.t('brightness'), br, .5, 1.5, (x) => br = x),
        row(L.t('contrast'), ct, .5, 1.5, (x) => ct = x),
        row(L.t('saturation'), sat, 0, 2, (x) => sat = x),
      ]);
    }
    return const SizedBox.shrink();
  }

  Widget _bar() {
    Widget b(IconData i, String tip, VoidCallback f, {bool on = false}) =>
        IconButton(icon: Icon(i, color: on ? Theme.of(context).colorScheme.primary : Colors.white), tooltip: tip, onPressed: f);
    return SafeArea(
      top: false,
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        b(Icons.rotate_left_rounded, L.t('rotate'), () => _rot(-1)),
        b(Icons.rotate_right_rounded, L.t('rotate'), () => _rot(1)),
        b(Icons.flip_rounded, L.t('flipH'), () => _flip(true)),
        b(Icons.flip_rounded, L.t('flipV'), () => _flip(false)),
        b(Icons.crop_rounded, L.t('crop'), () => setState(() => tool = tool == _Tool.crop ? _Tool.none : _Tool.crop), on: tool == _Tool.crop),
        b(Icons.tune_rounded, L.t('adjust'), () => setState(() => tool = tool == _Tool.adjust ? _Tool.none : _Tool.adjust), on: tool == _Tool.adjust),
      ]),
    );
  }
}

class _CropOverlay extends StatefulWidget {
  final Rect rect; // normalised
  final double? ratio; // w/h
  final ValueChanged<Rect> onChanged;
  const _CropOverlay({required this.rect, required this.ratio, required this.onChanged});
  @override
  State<_CropOverlay> createState() => _CropOverlayState();
}

class _CropOverlayState extends State<_CropOverlay> {
  static const hit = 32.0, minSize = 48.0;
  int mode = -1; // 0..3 corners (tl,tr,br,bl), 4 move
  Offset anchor = Offset.zero;

  @override
  Widget build(BuildContext context) => LayoutBuilder(builder: (c, box) {
        final sz = box.biggest;
        Rect px() => Rect.fromLTRB(widget.rect.left * sz.width, widget.rect.top * sz.height, widget.rect.right * sz.width, widget.rect.bottom * sz.height);
        void emit(Rect r) => widget.onChanged(Rect.fromLTRB(r.left / sz.width, r.top / sz.height, r.right / sz.width, r.bottom / sz.height));
        final r = px();
        final corners = [r.topLeft, r.topRight, r.bottomRight, r.bottomLeft];
        return GestureDetector(
          behavior: HitTestBehavior.opaque,
          onPanStart: (d) {
            mode = -1;
            for (var i = 0; i < 4; i++) {
              if ((corners[i] - d.localPosition).distance < hit) { mode = i; anchor = corners[(i + 2) % 4]; return; }
            }
            if (r.contains(d.localPosition)) mode = 4;
          },
          onPanUpdate: (d) {
            if (mode < 0) return;
            final cur = px();
            if (mode == 4) {
              var dx = d.delta.dx, dy = d.delta.dy;
              dx = dx.clamp(-cur.left, sz.width - cur.right);
              dy = dy.clamp(-cur.top, sz.height - cur.bottom);
              emit(cur.shift(Offset(dx, dy)));
              return;
            }
            final moving = corners[mode] + d.delta;
            final m = Offset(moving.dx.clamp(0.0, sz.width), moving.dy.clamp(0.0, sz.height));
            final sx = m.dx >= anchor.dx ? 1.0 : -1.0, sy = m.dy >= anchor.dy ? 1.0 : -1.0;
            var w = (m.dx - anchor.dx).abs(), h = (m.dy - anchor.dy).abs();
            final rt = widget.ratio;
            if (rt != null) {
              final maxW = sx > 0 ? sz.width - anchor.dx : anchor.dx;
              final maxH = sy > 0 ? sz.height - anchor.dy : anchor.dy;
              w = [w, maxW, maxH * rt].reduce((a, b) => a < b ? a : b);
              if (w < minSize) w = minSize;
              h = w / rt;
            } else {
              if (w < minSize) w = minSize;
              if (h < minSize) h = minSize;
            }
            emit(Rect.fromPoints(anchor, Offset(anchor.dx + sx * w, anchor.dy + sy * h)).intersect(Offset.zero & sz));
          },
          onPanEnd: (_) => mode = -1,
          child: CustomPaint(size: sz, painter: _CropPainter(r)),
        );
      });
}

class _CropPainter extends CustomPainter {
  final Rect r;
  _CropPainter(this.r);
  @override
  void paint(Canvas canvas, Size size) {
    final dim = Path()
      ..addRect(Offset.zero & size)
      ..addRect(r)
      ..fillType = PathFillType.evenOdd;
    canvas.drawPath(dim, Paint()..color = Colors.black54);
    final line = Paint()..color = Colors.white..style = PaintingStyle.stroke..strokeWidth = 1.5;
    canvas.drawRect(r, line);
    final thin = Paint()..color = Colors.white38..strokeWidth = 1;
    for (var i = 1; i < 3; i++) {
      canvas.drawLine(Offset(r.left + r.width * i / 3, r.top), Offset(r.left + r.width * i / 3, r.bottom), thin);
      canvas.drawLine(Offset(r.left, r.top + r.height * i / 3), Offset(r.right, r.top + r.height * i / 3), thin);
    }
    final hp = Paint()..color = Colors.white;
    for (final c in [r.topLeft, r.topRight, r.bottomRight, r.bottomLeft]) {
      canvas.drawCircle(c, 8, hp);
    }
  }

  @override
  bool shouldRepaint(_CropPainter o) => o.r != r;
}
