import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/l10n.dart';
import '../services/cast_service.dart';
import '../services/media_store.dart';
import '../services/native.dart';
import '../services/player_service.dart';
import 'video_tools.dart';

/// Full video player: gestures (seek / brightness / volume / double-tap / long-press 2x),
/// lock, rotate, aspect, PiP, subtitles (delay, size, colour, encoding), audio delay,
/// track picker, playlist, screenshot, resume position, network streams.
class VideoPlayerScreen extends StatefulWidget {
  final List<String> paths; // local paths or http(s)/rtsp URLs
  final int index;
  const VideoPlayerScreen({super.key, required this.paths, required this.index});
  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  late final Player player = Player();
  late final VideoController controller = VideoController(player);
  int cur = 0;
  BoxFit fit = BoxFit.contain;
  double rate = 1, subSize = 28, subDelay = 0, audioDelay = 0;
  Color subColor = Colors.white;
  String codepage = 'utf8:cp1256';
  bool visible = true, locked = false, muted = false, buffering = false;
  int orient = 0; // 0 auto, 1 landscape, 2 portrait
  PlaylistMode loop = PlaylistMode.none;
  double? _drag;
  List<(Duration, String)> chapters = [];
  // pinch-zoom (two fingers) and two-finger pan
  double zoom = 1;
  Offset pan = Offset.zero;
  bool _pinch = false;
  final _ptr = <int, Offset>{};
  double _z0 = 1, _d0 = 1;
  Offset _p0 = Offset.zero, _m0 = Offset.zero;
  Duration? abA, abB; // A-B loop
  // seek preview (frame bubble while dragging the slider)
  Uint8List? _prev;
  Duration _prevT = Duration.zero;
  final _prevCache = <String, Uint8List>{};
  Timer? _prevTimer;
  int _prevReq = 0;
  static const _bucketMs = 2000;
  Timer? _sleepT;
  DateTime? _sleepAt;
  bool hwDec = true;
  Timer? _hideT, _hudT, _saveT;
  StreamSubscription? _s1, _s2, _s3, _s4, _s5, _s6;

  // HUD
  IconData? hudIcon;
  String hudText = '';
  double? hudValue;

  // gesture state
  Duration _hStart = Duration.zero;
  double _hAcc = 0, _vAcc = 0, _vBase = 0;
  bool _vLeft = true;
  bool _seeking = false;
  double _prevRate = 1;

  bool _isUrl(String s) => RegExp(r'^[a-z]+://', caseSensitive: false).hasMatch(s);
  String get curPath => widget.paths[cur];
  String get curTitle => _isUrl(curPath) ? Uri.decodeFull(p.basename(Uri.parse(curPath).path)).isEmpty ? Uri.parse(curPath).host : Uri.decodeFull(p.basename(Uri.parse(curPath).path)) : p.basename(curPath);

  @override
  void initState() {
    super.initState();
    cur = widget.index;
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    Native.keepOn(true);
    Native.pipAuto(true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) context.read<PlayerService>().player.pause(); // stop background music
    });
    _prop('sub-codepage', codepage);
    player.open(Playlist(widget.paths.map((e) => Media(e)).toList(), index: cur));
    _s1 = player.stream.playlist.listen((pl) {
      if (mounted && pl.index != cur) {
        _saveNow();
        setState(() { cur = pl.index; abA = null; abB = null; _prev = null; });
        _onNewItem();
      }
    });
    _s2 = player.stream.buffering.listen((b) { if (mounted) setState(() => buffering = b); });
    _s3 = player.stream.error.listen((e) {
      if (mounted && e.isNotEmpty) _hud(Icons.error_outline_rounded, e);
    });
    _s4 = player.stream.height.listen((h) => _autoOrient());
    _s5 = player.stream.playing.listen((pl) {
      if (!mounted) return;
      if (pl) { _scheduleHide(); } else { _hideT?.cancel(); setState(() => visible = true); }
    });
    _s6 = player.stream.position.listen((pos) {
      final a = abA, b = abB;
      if (a != null && b != null && pos >= b) player.seek(a);
    });
    _loadHw();
    _saveT = Timer.periodic(const Duration(seconds: 5), (_) => _saveNow());
    Native.inPip.addListener(_pipChanged);
    _onNewItem();
    _scheduleHide();
  }

  void _pipChanged() { if (mounted) setState(() {}); }

  @override
  void dispose() {
    _saveNow();
    for (final s in [_s1, _s2, _s3, _s4, _s5, _s6]) { s?.cancel(); }
    _hideT?.cancel();
    _hudT?.cancel();
    _saveT?.cancel();
    _sleepT?.cancel();
    _prevTimer?.cancel();
    Native.inPip.removeListener(_pipChanged);
    Native.setBrightness(-1);
    Native.keepOn(false);
    Native.pipAuto(false);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations([]);
    if (CastService.I.active != null) CastService.I.stop();
    player.dispose();
    super.dispose();
  }

  // ---------- helpers ----------
  Future<void> _prop(String k, String v) async {
    try { await (player.platform as dynamic).setProperty(k, v); } catch (_) {}
  }

  Future<void> _loadHw() async {
    try {
      final sp = await SharedPreferences.getInstance();
      hwDec = sp.getBool('video_hw') ?? true;
      if (!hwDec) await _prop('hwdec', 'no');
      if (mounted) setState(() {});
    } catch (_) {}
  }

  Future<void> _toggleHw() async {
    hwDec = !hwDec;
    await _prop('hwdec', hwDec ? 'auto-safe' : 'no');
    try { (await SharedPreferences.getInstance()).setBool('video_hw', hwDec); } catch (_) {}
    if (mounted) setState(() {});
    _hud(Icons.memory_rounded, '${L.t('hwDecoder')}: ${hwDec ? L.t('on') : L.t('off')}');
  }

  void _preview(double ms) {
    _prevT = Duration(milliseconds: ms.round());
    final b = (ms / _bucketMs).round();
    final path = curPath;
    final key = '$path|$b';
    final hit = _prevCache[key];
    if (hit != null) {
      _prev = hit;
      return;
    }
    final req = ++_prevReq;
    _prevTimer?.cancel();
    _prevTimer = Timer(const Duration(milliseconds: 120), () async {
      try {
        final d = await VideoThumbnail.thumbnailData(video: path, imageFormat: ImageFormat.JPEG, timeMs: b * _bucketMs, maxWidth: 320, quality: 60);
        if (d == null || d.isEmpty) return;
        if (_prevCache.length > 80) _prevCache.remove(_prevCache.keys.first);
        _prevCache[key] = d;
        if (mounted && req == _prevReq && _drag != null && path == curPath) setState(() => _prev = d);
      } catch (_) {}
    });
  }

  Widget _previewW() {
    final dur = player.state.duration;
    final x = _drag;
    if (x == null || _prev == null || dur <= Duration.zero) return const SizedBox.shrink();
    final f = (x / dur.inMilliseconds).clamp(0.0, 1.0).toDouble();
    return Positioned(
      left: 52,
      right: 52,
      bottom: 150 + MediaQuery.of(context).padding.bottom,
      child: IgnorePointer(
        child: Align(
          alignment: Alignment(f * 2 - 1, 0),
          child: Container(
            width: 170,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(color: Colors.black, borderRadius: BorderRadius.circular(8), border: Border.all(color: Colors.white24)),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Image.memory(_prev!, width: 170, fit: BoxFit.cover, gaplessPlayback: true),
              Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Text(_fmt(_prevT), style: const TextStyle(fontSize: 12))),
            ]),
          ),
        ),
      ),
    );
  }

  void _toggleAB() {
    final pos = player.state.position;
    if (abA == null) {
      setState(() => abA = pos);
      _hud(Icons.repeat_rounded, 'A  ${_fmt(pos)}');
    } else if (abB == null) {
      if (pos <= abA! + const Duration(milliseconds: 500)) return;
      setState(() => abB = pos);
      _hud(Icons.repeat_rounded, 'A-B  ${_fmt(abA!)} → ${_fmt(pos)}');
    } else {
      setState(() { abA = null; abB = null; });
      _hud(Icons.repeat_rounded, '${L.t('abLoop')}: ${L.t('off')}');
    }
  }

  Future<void> _step(bool fwd) async {
    try {
      await player.pause();
      await (player.platform as dynamic).command([fwd ? 'frame-step' : 'frame-back-step']);
    } catch (_) {}
  }

  Future<void> _sleepMenu() async {
    final r = await showModalBottomSheet<int>(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          ListTile(title: Text(L.t('sleepTimer'), style: const TextStyle(fontWeight: FontWeight.bold))),
          if (_sleepAt != null) ListTile(leading: const Icon(Icons.timer_off_rounded), title: Text(L.t('off')), onTap: () => Navigator.pop(context, -1)),
          for (final m in [15, 30, 45, 60, 90, 120]) ListTile(leading: const Icon(Icons.bedtime_rounded), title: Text('$m ${L.t('minutes')}'), onTap: () => Navigator.pop(context, m)),
        ]),
      ),
    );
    if (r == null || !mounted) return;
    _sleepT?.cancel();
    if (r < 0) {
      setState(() => _sleepAt = null);
      _hud(Icons.timer_off_rounded, '${L.t('sleepTimer')}: ${L.t('off')}');
      return;
    }
    setState(() => _sleepAt = DateTime.now().add(Duration(minutes: r)));
    _sleepT = Timer(Duration(minutes: r), () {
      if (!mounted) return;
      player.pause();
      setState(() => _sleepAt = null);
    });
    _hud(Icons.bedtime_rounded, '$r ${L.t('minutes')}');
  }

  void _saveNow() {
    try { MediaStore.savePos(curPath, player.state.position, player.state.duration); } catch (_) {}
  }

  String _fmt(Duration d) {
    final h = d.inHours, m = d.inMinutes.remainder(60).toString().padLeft(2, '0'), s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  void _hud(IconData ic, String t, {double? v}) {
    setState(() { hudIcon = ic; hudText = t; hudValue = v; });
    _hudT?.cancel();
    _hudT = Timer(const Duration(milliseconds: 900), () { if (mounted) setState(() => hudIcon = null); });
  }

  void _scheduleHide() {
    _hideT?.cancel();
    if (!player.state.playing) return;
    _hideT = Timer(const Duration(seconds: 4), () { if (mounted && _drag == null) setState(() => visible = false); });
  }

  void _toggleControls() {
    setState(() => visible = !visible);
    if (visible) _scheduleHide();
  }

  void _autoOrient() {
    if (!mounted || orient != 0) return;
    final w = player.state.width ?? 0, h = player.state.height ?? 0;
    if (w == 0 || h == 0) return;
    SystemChrome.setPreferredOrientations(w >= h
        ? [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]
        : [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  }

  void _cycleOrient() {
    orient = (orient + 1) % 3;
    if (orient == 0) {
      SystemChrome.setPreferredOrientations(DeviceOrientation.values);
      _autoOrient();
    } else if (orient == 1) {
      SystemChrome.setPreferredOrientations([DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    } else {
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    }
    _hud(Icons.screen_rotation_rounded, [L.t('auto'), L.t('landscape'), L.t('portrait')][orient]);
  }

  Future<void> _loadChapters() async {
    final path = curPath;
    if (mounted) setState(() => chapters = []);
    final out = <(Duration, String)>[];
    try {
      final np = player.platform as dynamic;
      await player.stream.duration.firstWhere((d) => d > Duration.zero).timeout(const Duration(seconds: 10));
      final n = int.tryParse('${await np.getProperty('chapter-list/count')}') ?? 0;
      for (var i = 0; i < n; i++) {
        final t = double.tryParse('${await np.getProperty('chapter-list/$i/time')}') ?? 0;
        final title = '${await np.getProperty('chapter-list/$i/title')}'.trim();
        out.add((Duration(milliseconds: (t * 1000).round()), title.isEmpty ? '${L.t('chapter')} ${i + 1}' : title));
      }
    } catch (_) {}
    if (mounted && path == curPath) setState(() => chapters = out);
  }

  String? get _chapterNow {
    if (chapters.length < 2) return null;
    final pos = player.state.position;
    final i = chapters.lastIndexWhere((c) => c.$1 <= pos);
    return chapters[i < 0 ? 0 : i].$2;
  }

  // ---------- pinch zoom ----------
  void _ptrDown(PointerDownEvent e) {
    _ptr[e.pointer] = e.position;
    if (_ptr.length == 2) {
      final v = _ptr.values.toList();
      _pinch = true;
      _z0 = zoom;
      _p0 = pan;
      _d0 = math.max((v[0] - v[1]).distance, 1);
      _m0 = (v[0] + v[1]) / 2;
    }
  }

  void _ptrMove(PointerMoveEvent e, Size size) {
    if (!_ptr.containsKey(e.pointer)) return;
    _ptr[e.pointer] = e.position;
    if (_ptr.length != 2) return;
    final v = _ptr.values.toList();
    final z = (_z0 * (v[0] - v[1]).distance / _d0).clamp(1.0, 5.0).toDouble();
    final m = (v[0] + v[1]) / 2;
    final mx = (z - 1) * size.width / 2, my = (z - 1) * size.height / 2;
    setState(() {
      zoom = z;
      pan = Offset((_p0.dx + m.dx - _m0.dx).clamp(-mx, mx).toDouble(), (_p0.dy + m.dy - _m0.dy).clamp(-my, my).toDouble());
    });
  }

  void _ptrUp(PointerEvent e) {
    _ptr.remove(e.pointer);
    if (_ptr.isEmpty) _pinch = false;
  }

  Future<void> _onNewItem() async {
    _loadChapters();
    // external subtitle next to the file
    if (!_isUrl(curPath)) {
      final base = p.withoutExtension(curPath);
      for (final e in ['srt', 'vtt', 'ass', 'ssa', 'sub']) {
        if (File('$base.$e').existsSync()) {
          await Future.delayed(const Duration(milliseconds: 600));
          if (mounted) await player.setSubtitleTrack(SubtitleTrack.uri('$base.$e', title: p.basename('$base.$e')));
          break;
        }
      }
    }
    // resume
    final st = MediaStore.state(curPath);
    if (st != null) {
      final path = curPath;
      try {
        await player.stream.duration.firstWhere((d) => d > Duration.zero).timeout(const Duration(seconds: 8));
        if (mounted && path == curPath) {
          await player.seek(Duration(milliseconds: st[0]));
          _hud(Icons.history_rounded, '${L.t('resumed')} ${_fmt(Duration(milliseconds: st[0]))}');
        }
      } catch (_) {}
    }
    Native.pipAuto(true, _aspect);
  }

  double get _aspect {
    final w = player.state.width ?? 16, h = player.state.height ?? 9;
    return h == 0 ? 16 / 9 : w / h;
  }

  // ---------- gestures ----------
  void _doubleTap(Offset pos, double width) {
    if (locked || _pinch) return;
    if (zoom > 1.01) {
      setState(() { zoom = 1; pan = Offset.zero; });
      return;
    }
    if (pos.dx < width / 3) {
      _seekBy(-10);
    } else if (pos.dx > width * 2 / 3) {
      _seekBy(10);
    } else {
      player.playOrPause();
    }
  }

  void _seekBy(int s) {
    var t = player.state.position + Duration(seconds: s);
    final d = player.state.duration;
    if (t < Duration.zero) t = Duration.zero;
    if (d > Duration.zero && t > d) t = d;
    player.seek(t);
    _hud(s < 0 ? Icons.fast_rewind_rounded : Icons.fast_forward_rounded, '${s > 0 ? '+' : ''}$s s  ${_fmt(t)}');
  }

  // ---------- menus ----------
  void _tracks() {
    final t = player.state.tracks;
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(children: [
          ListTile(title: Text(L.t('subtitles'), style: const TextStyle(fontWeight: FontWeight.bold))),
          ListTile(leading: const Icon(Icons.subtitles_off_rounded), title: Text(L.t('off')), onTap: () { player.setSubtitleTrack(SubtitleTrack.no()); Navigator.pop(context); }),
          for (final s in t.subtitle.where((e) => e.id != 'auto' && e.id != 'no'))
            ListTile(leading: const Icon(Icons.subtitles_rounded), title: Text(s.title ?? s.language ?? s.id), onTap: () { player.setSubtitleTrack(s); Navigator.pop(context); }),
          ListTile(
            leading: const Icon(Icons.cloud_download_rounded),
            title: Text(L.t('subDownload')),
            onTap: () {
              Navigator.pop(context);
              showSubtitleSearch(this.context, player, curPath, onInfo: (m) => _hud(Icons.subtitles_rounded, m));
            },
          ),
          ListTile(
            leading: const Icon(Icons.add_rounded),
            title: Text('${L.t('subtitles')}…'),
            onTap: () async {
              Navigator.pop(context);
              final r = await FilePicker.platform.pickFiles();
              final f = r?.files.single.path;
              if (f != null) await player.setSubtitleTrack(SubtitleTrack.uri(f, title: p.basename(f)));
            },
          ),
          ListTile(title: Text(L.t('audioTrack'), style: const TextStyle(fontWeight: FontWeight.bold))),
          for (final a in t.audio.where((e) => e.id != 'auto' && e.id != 'no'))
            ListTile(leading: const Icon(Icons.audiotrack_rounded), title: Text(a.title ?? a.language ?? a.id), onTap: () { player.setAudioTrack(a); Navigator.pop(context); }),
        ]),
      ),
    );
  }

  Future<void> _delayDialog(String title, double value, void Function(double) onSet) async {
    var v = value;
    await showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text('$title: ${v.toStringAsFixed(1)} s'),
          content: Row(children: [
            IconButton(icon: const Icon(Icons.remove_circle_outline_rounded), onPressed: () => set(() => v = ((v - .1) * 10).round() / 10)),
            Expanded(child: Slider(min: -10, max: 10, divisions: 200, value: v.clamp(-10, 10).toDouble(), onChanged: (x) => set(() => v = (x * 10).round() / 10))),
            IconButton(icon: const Icon(Icons.add_circle_outline_rounded), onPressed: () => set(() => v = ((v + .1) * 10).round() / 10)),
          ]),
          actions: [
            TextButton(onPressed: () => set(() => v = 0), child: Text(L.t('reset'))),
            FilledButton(onPressed: () { onSet(v); Navigator.pop(c); }, child: Text(L.t('ok'))),
          ],
        ),
      ),
    );
  }

  void _subStyle() {
    showModalBottomSheet(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (c, set) => SafeArea(
          child: ListView(shrinkWrap: true, children: [
            ListTile(title: Text(L.t('subSize'), style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Slider(min: 14, max: 60, value: subSize, onChanged: (v) { set(() => subSize = v); setState(() {}); })),
            ListTile(
              title: Text(L.t('color')),
              trailing: Wrap(spacing: 8, children: [
                for (final col in [Colors.white, Colors.yellow, Colors.cyanAccent, Colors.greenAccent])
                  GestureDetector(onTap: () { set(() => subColor = col); setState(() {}); }, child: CircleAvatar(radius: 13, backgroundColor: col, child: subColor == col ? const Icon(Icons.check, size: 16, color: Colors.black) : null)),
              ]),
            ),
            ListTile(
              title: Text(L.t('subEnc')),
              trailing: DropdownButton<String>(
                value: codepage,
                underline: const SizedBox(),
                items: const [
                  DropdownMenuItem(value: 'utf8:cp1256', child: Text('UTF-8 / Arabic-Persian (1256)')),
                  DropdownMenuItem(value: 'utf8', child: Text('UTF-8')),
                  DropdownMenuItem(value: 'utf8:cp1252', child: Text('Latin (1252)')),
                  DropdownMenuItem(value: 'utf8:cp1251', child: Text('Cyrillic (1251)')),
                  DropdownMenuItem(value: 'utf8:cp1254', child: Text('Turkish (1254)')),
                ],
                onChanged: (v) async {
                  set(() => codepage = v!);
                  await _prop('sub-codepage', v!);
                  // reload the current subtitle so the new encoding applies
                  final sub = player.state.track.subtitle;
                  if (sub.id != 'no' && sub.id != 'auto') await player.setSubtitleTrack(sub);
                },
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Future<void> _screenshot() async {
    try {
      final bytes = await player.screenshot(format: 'image/png');
      if (bytes == null) return;
      final dir = Directory('/storage/emulated/0/Pictures/Abtin');
      await dir.create(recursive: true);
      final f = File('${dir.path}/${p.basenameWithoutExtension(curTitle)}_${DateTime.now().millisecondsSinceEpoch}.png');
      await f.writeAsBytes(bytes);
      Native.scan(f.path);
      _hud(Icons.photo_camera_rounded, '${L.t('saved')}: ${p.basename(f.path)}');
    } catch (e) {
      _hud(Icons.error_outline_rounded, '$e');
    }
  }

  void _playlist() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => SizedBox(
        height: MediaQuery.of(context).size.height * .6,
        child: ListView.builder(
          itemCount: widget.paths.length,
          itemBuilder: (c, i) => ListTile(
            selected: i == cur,
            leading: Text('${i + 1}'),
            title: Text(Uri.decodeFull(p.basename(widget.paths[i])), maxLines: 1, overflow: TextOverflow.ellipsis),
            onTap: () { player.jump(i); Navigator.pop(c); },
          ),
        ),
      ),
    );
  }

  Future<void> _cast() async {
    final started = await showCastSheet(context, player, curPath, curTitle);
    if (started && mounted) {
      player.pause();
      setState(() {});
    }
  }

  Future<void> _stopCast() async {
    final pos = CastService.I.position;
    await CastService.I.stop();
    if (!mounted) return;
    if (pos > Duration.zero) await player.seek(pos);
    player.play();
    setState(() {});
  }

  Future<void> _enterPip() async {
    final ok = await Native.pip(_aspect);
    if (!ok && mounted) _hud(Icons.picture_in_picture_alt_rounded, L.t('pipNo'));
  }

  // ---------- UI ----------
  Widget _topBar() => Container(
        decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black87, Colors.transparent])),
        padding: const EdgeInsets.fromLTRB(4, 4, 4, 16),
        child: SafeArea(
          bottom: false,
          child: Row(children: [
            IconButton(icon: const Icon(Icons.arrow_back_rounded), onPressed: () => Navigator.pop(context)),
            Expanded(child: Text(curTitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14))),
            IconButton(icon: Icon(CastService.I.active != null ? Icons.cast_connected_rounded : Icons.cast_rounded), tooltip: L.t('cast'), onPressed: _cast),
            IconButton(icon: const Icon(Icons.subtitles_rounded), tooltip: L.t('subtitles'), onPressed: _tracks),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert_rounded),
              onSelected: (v) {
                switch (v) {
                  case 'subdelay': _delayDialog(L.t('subDelay'), subDelay, (x) { subDelay = x; _prop('sub-delay', x.toString()); }); break;
                  case 'audiodelay': _delayDialog(L.t('audioDelay'), audioDelay, (x) { audioDelay = x; _prop('audio-delay', x.toString()); }); break;
                  case 'substyle': _subStyle(); break;
                  case 'shot': _screenshot(); break;
                  case 'ab': _toggleAB(); break;
                  case 'sleep': _sleepMenu(); break;
                  case 'hw': _toggleHw(); break;
                  case 'pip': _enterPip(); break;
                  case 'list': _playlist(); break;
                  case 'mute': setState(() => muted = !muted); player.setVolume(muted ? 0 : 100); break;
                  case 'loop':
                    loop = loop == PlaylistMode.none ? PlaylistMode.single : loop == PlaylistMode.single ? PlaylistMode.loop : PlaylistMode.none;
                    player.setPlaylistMode(loop);
                    _hud(loop == PlaylistMode.single ? Icons.repeat_one_rounded : Icons.repeat_rounded, loop == PlaylistMode.none ? L.t('off') : loop == PlaylistMode.single ? '1' : L.t('all'));
                    break;
                  default:
                    if (v.startsWith('r')) { rate = double.parse(v.substring(1)); player.setRate(rate); _hud(Icons.speed_rounded, '${rate}x'); }
                }
              },
              itemBuilder: (_) => [
                for (final v in [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0]) PopupMenuItem(value: 'r$v', child: Text('${L.t('speed')} ${v}x${rate == v ? '  ✓' : ''}')),
                const PopupMenuDivider(),
                PopupMenuItem(value: 'subdelay', child: Text(L.t('subDelay'))),
                PopupMenuItem(value: 'audiodelay', child: Text(L.t('audioDelay'))),
                PopupMenuItem(value: 'substyle', child: Text(L.t('subStyle'))),
                const PopupMenuDivider(),
                PopupMenuItem(value: 'loop', child: Text(L.t('loop'))),
                PopupMenuItem(value: 'ab', child: Text('${L.t('abLoop')}${abA == null ? '' : abB == null ? '  (A…)' : '  (A-B ✓)'}')),
                PopupMenuItem(value: 'sleep', child: Text('${L.t('sleepTimer')}${_sleepAt == null ? '' : '  ✓'}')),
                PopupMenuItem(value: 'hw', child: Text('${L.t('hwDecoder')}: ${hwDec ? L.t('on') : L.t('off')}')),
                PopupMenuItem(value: 'mute', child: Text(muted ? L.t('unmute') : L.t('mute'))),
                PopupMenuItem(value: 'shot', child: Text(L.t('screenshot'))),
                PopupMenuItem(value: 'pip', child: Text(L.t('pip'))),
                if (widget.paths.length > 1) PopupMenuItem(value: 'list', child: Text(L.t('playlist'))),
              ],
            ),
          ]),
        ),
      );

  Widget _bottomBar() => Container(
        decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black87, Colors.transparent])),
        padding: const EdgeInsets.fromLTRB(12, 24, 12, 4),
        child: SafeArea(
          top: false,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            StreamBuilder<Duration>(
              stream: player.stream.position,
              builder: (_, snap) {
                final pos = snap.data ?? player.state.position;
                final dur = player.state.duration;
                final maxMs = math.max(dur.inMilliseconds, 1).toDouble();
                final v = (_drag ?? pos.inMilliseconds.toDouble()).clamp(0, maxMs).toDouble();
                final chNow = _chapterNow;
                return Column(mainAxisSize: MainAxisSize.min, children: [
                  if (chNow != null) Text(chNow, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Colors.white70)),
                  Row(children: [
                  Text(_fmt(Duration(milliseconds: v.round())), style: const TextStyle(fontSize: 12)),
                  Expanded(
                    child: Stack(alignment: Alignment.center, children: [
                      if (chapters.length > 1 && dur > Duration.zero)
                        Positioned.fill(
                          child: IgnorePointer(child: CustomPaint(painter: _TickPainter([for (final c in chapters.skip(1)) c.$1.inMilliseconds / dur.inMilliseconds]))),
                        ),
                      Slider(
                      value: v,
                      max: maxMs,
                      onChangeStart: (_) => _hideT?.cancel(),
                      onChanged: (x) => setState(() { _drag = x; _preview(x); }),
                      onChangeEnd: (x) {
                        player.seek(Duration(milliseconds: x.round()));
                        setState(() { _drag = null; _prev = null; });
                        _scheduleHide();
                      },
                    ),
                    ]),
                  ),
                  Text(_fmt(dur), style: const TextStyle(fontSize: 12)),
                  ]),
                ]);
              },
            ),
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              IconButton(icon: const Icon(Icons.lock_open_rounded), tooltip: L.t('lock'), onPressed: () => setState(() { locked = true; visible = false; })),
              IconButton(icon: const Icon(Icons.skip_previous_rounded), onPressed: widget.paths.length > 1 ? player.previous : null),
              IconButton(iconSize: 30, icon: const Icon(Icons.replay_10_rounded), onPressed: () => _seekBy(-10)),
              StreamBuilder<bool>(
                stream: player.stream.playing,
                builder: (_, s) {
                  final playing = s.data ?? player.state.playing;
                  return Row(mainAxisSize: MainAxisSize.min, children: [
                    if (!playing) IconButton(icon: const Icon(Icons.skip_previous_outlined), tooltip: L.t('framePrev'), onPressed: () => _step(false)),
                    IconButton(iconSize: 46, icon: Icon(playing ? Icons.pause_circle_filled_rounded : Icons.play_circle_fill_rounded), onPressed: player.playOrPause),
                    if (!playing) IconButton(icon: const Icon(Icons.skip_next_outlined), tooltip: L.t('frameNext'), onPressed: () => _step(true)),
                  ]);
                },
              ),
              IconButton(iconSize: 30, icon: const Icon(Icons.forward_10_rounded), onPressed: () => _seekBy(10)),
              IconButton(icon: const Icon(Icons.skip_next_rounded), onPressed: widget.paths.length > 1 ? player.next : null),
              if (chapters.length > 1) IconButton(icon: const Icon(Icons.bookmarks_rounded), tooltip: L.t('chapters'), onPressed: () => showChapters(context, player, chapters)),
              IconButton(icon: Icon(Icons.compare_arrows_rounded, color: abA != null ? Colors.amber : null), tooltip: L.t('abLoop'), onPressed: _toggleAB),
              IconButton(icon: const Icon(Icons.screen_rotation_rounded), tooltip: L.t('rotate'), onPressed: _cycleOrient),
              IconButton(
                icon: const Icon(Icons.aspect_ratio_rounded),
                tooltip: L.t('aspect'),
                onPressed: () {
                  setState(() => fit = fit == BoxFit.contain ? BoxFit.cover : fit == BoxFit.cover ? BoxFit.fill : BoxFit.contain);
                  _hud(Icons.aspect_ratio_rounded, fit == BoxFit.contain ? L.t('fit') : fit == BoxFit.cover ? L.t('crop') : L.t('stretch'));
                },
              ),
            ]),
          ]),
        ),
      );

  Widget _hudW() {
    if (hudIcon == null) return const SizedBox.shrink();
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        decoration: BoxDecoration(color: Colors.black.withOpacity(.65), borderRadius: BorderRadius.circular(16)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(hudIcon, size: 34),
          const SizedBox(height: 4),
          Text(hudText, style: const TextStyle(fontSize: 15)),
          if (hudValue != null) Padding(padding: const EdgeInsets.only(top: 6), child: SizedBox(width: 110, child: LinearProgressIndicator(value: hudValue!.clamp(0, 1).toDouble()))),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pip = Native.inPip.value;
    return PopScope(
      canPop: !locked,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: LayoutBuilder(builder: (context, cons) {
          final w = cons.maxWidth, h = cons.maxHeight;
          Offset tapPos = Offset.zero;
          return Listener(
            behavior: HitTestBehavior.translucent,
            onPointerDown: _ptrDown,
            onPointerMove: (e) => _ptrMove(e, Size(w, h)),
            onPointerUp: _ptrUp,
            onPointerCancel: _ptrUp,
            child: Stack(fit: StackFit.expand, children: [
            ClipRect(
              child: Transform(
                alignment: Alignment.center,
                transform: Matrix4.translationValues(pan.dx, pan.dy, 0)..scale(zoom, zoom, 1),
                child: Video(
                  controller: controller,
                  fit: fit,
                  controls: NoVideoControls,
                  subtitleViewConfiguration: SubtitleViewConfiguration(
                    style: TextStyle(height: 1.35, fontSize: subSize, color: subColor, fontWeight: FontWeight.w500, backgroundColor: const Color(0x99000000)),
                    textAlign: TextAlign.center,
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 56),
                  ),
                ),
              ),
            ),
            if (!pip)
              GestureDetector(
                behavior: HitTestBehavior.translucent,
                onTap: () { if (locked) { setState(() => visible = !visible); if (visible) Future.delayed(const Duration(seconds: 3), () { if (mounted && locked) setState(() => visible = false); }); } else { _toggleControls(); } },
                onDoubleTapDown: (d) => tapPos = d.localPosition,
                onDoubleTap: () => _doubleTap(tapPos, w),
                onLongPressStart: (_) { if (locked || _pinch) return; _prevRate = rate; player.setRate(2); _hud(Icons.fast_forward_rounded, '2x'); },
                onLongPressEnd: (_) { if (locked) return; player.setRate(_prevRate); },
                onHorizontalDragStart: (_) { if (locked || _pinch) return; _hStart = player.state.position; _hAcc = 0; _seeking = true; },
                onHorizontalDragUpdate: (d) {
                  if (locked || _pinch || !_seeking) return;
                  _hAcc += d.delta.dx;
                  final dur = player.state.duration;
                  var t = _hStart + Duration(seconds: (_hAcc / w * 120).round());
                  if (t < Duration.zero) t = Duration.zero;
                  if (dur > Duration.zero && t > dur) t = dur;
                  final diff = t - _hStart;
                  _hud(diff.isNegative ? Icons.fast_rewind_rounded : Icons.fast_forward_rounded, '${_fmt(t)}  (${diff.inSeconds >= 0 ? '+' : ''}${diff.inSeconds}s)');
                  _hStart2 = t;
                },
                onHorizontalDragEnd: (_) { if (locked || !_seeking) return; _seeking = false; if (_hStart2 != null) player.seek(_hStart2!); _hStart2 = null; },
                onVerticalDragStart: (d) async {
                  if (locked || _pinch) return;
                  _vLeft = d.localPosition.dx < w / 2;
                  _vAcc = 0;
                  _vBase = _vLeft ? await Native.brightness() : await Native.sysVolume();
                },
                onVerticalDragUpdate: (d) {
                  if (locked || _pinch) return;
                  _vAcc -= d.delta.dy / h * 1.3;
                  final v = (_vBase + _vAcc).clamp(0.0, 1.0).toDouble();
                  if (_vLeft) {
                    Native.setBrightness(v);
                    _hud(Icons.brightness_6_rounded, '${(v * 100).round()}%', v: v);
                  } else {
                    Native.setSysVolume(v);
                    _hud(v == 0 ? Icons.volume_off_rounded : Icons.volume_up_rounded, '${(v * 100).round()}%', v: v);
                  }
                },
              ),
            if (buffering && !pip) const Center(child: CircularProgressIndicator()),
            if (!pip) IgnorePointer(child: _hudW()),
            if (!pip && visible && !locked) Positioned(top: 0, left: 0, right: 0, child: _topBar()),
            if (!pip && visible && !locked) Positioned(bottom: 0, left: 0, right: 0, child: _bottomBar()),
            if (!pip && visible && !locked && _drag != null) _previewW(),
            if (!pip && locked && visible)
              Positioned(
                left: 16, top: h / 2 - 28,
                child: FloatingActionButton.small(backgroundColor: Colors.black54, onPressed: () => setState(() { locked = false; visible = true; _scheduleHide(); }), child: const Icon(Icons.lock_rounded)),
              ),
            if (!pip && zoom > 1.01)
              Positioned(
                right: 16,
                top: h / 2 - 20,
                child: ActionChip(
                  backgroundColor: Colors.black54,
                  label: Text('${zoom.toStringAsFixed(1)}x  ✕'),
                  onPressed: () => setState(() { zoom = 1; pan = Offset.zero; }),
                ),
              ),
            if (!pip && CastService.I.active != null) Positioned(bottom: 0, left: 0, right: 0, child: CastBar(onStop: _stopCast)),
          ]),
          );
        }),
      ),
    );
  }

  Duration? _hStart2;
}

class _TickPainter extends CustomPainter {
  final List<double> at; // fractions 0..1
  _TickPainter(this.at);
  @override
  void paint(Canvas c, Size s) {
    final paint = Paint()
      ..color = Colors.white70
      ..strokeWidth = 2;
    const pad = 24.0; // Slider track inset
    final w = s.width - 2 * pad;
    for (final f in at) {
      final x = pad + w * f.clamp(0.0, 1.0);
      c.drawLine(Offset(x, s.height / 2 - 7), Offset(x, s.height / 2 + 7), paint);
    }
  }

  @override
  bool shouldRepaint(covariant _TickPainter o) => o.at != at;
}
