import 'package:flutter/material.dart';
import '../widgets/adaptive_nav.dart';
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import 'analyzer_screen.dart';
import 'duplicates_screen.dart';
import 'icon_style_screen.dart';
import 'path_list_screen.dart';
import 'trash_screen.dart';
import 'saf_prompt.dart';
import 'security_screen.dart';
import '../services/file_ops.dart';
import '../services/saf.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return Scaffold(
      appBar: AppBar(title: Text(L.t('settings'))),
      body: MaxWidth(child: ListView(children: [
        SwitchListTile(secondary: const Icon(Icons.dark_mode_rounded), title: Text(L.t('dark')), value: s.dark, onChanged: s.setDark),
        ListTile(
          leading: const Icon(Icons.language_rounded),
          title: Text(L.t('language')),
          trailing: DropdownButton<String>(
            value: L.lang,
            underline: const SizedBox(),
            items: [for (final c in L.langs) DropdownMenuItem(value: c, child: Text(L.nameOf(c)))],
            onChanged: (v) => s.setLang(v!),
          ),
        ),
        SwitchListTile(secondary: const Icon(Icons.splitscreen_rounded), title: Text(L.t('dual')), subtitle: Text(L.t('dualSub')), value: s.dual, onChanged: s.setDual),
        ListTile(leading: const Icon(Icons.palette_rounded), title: Text(L.t('iconStyle')), subtitle: Text(L.t('iconStyleSub')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const IconStyleScreen()))),
        SwitchListTile(secondary: const Icon(Icons.visibility_rounded), title: Text(L.t('hidden')), value: s.showHidden, onChanged: s.setHidden),
        SwitchListTile(secondary: const Icon(Icons.warning_amber_rounded), title: Text(L.t('confirmDelete')), value: s.confirmDelete, onChanged: s.setConfirm),
        SwitchListTile(secondary: const Icon(Icons.sync_rounded), title: Text(L.t('bgCopy')), subtitle: Text(L.t('bgCopySub')), value: s.bgCopy, onChanged: s.setBgCopy),
        SwitchListTile(secondary: const Icon(Icons.folder_special_rounded), title: Text(L.t('folderSizes')), subtitle: Text(L.t('folderSizesSub')), value: s.folderSizes, onChanged: s.setFolderSizes),
        SwitchListTile(secondary: const Icon(Icons.delete_outline_rounded), title: Text(L.t('trash')), subtitle: Text(L.t('trashSub')), value: s.trashEnabled, onChanged: s.setTrash),
        ListTile(leading: const Icon(Icons.restore_from_trash_rounded), title: Text(L.t('trash')), subtitle: Text(L.t('trashOpen')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TrashScreen()))),
        ListTile(leading: const Icon(Icons.shield_rounded), title: Text(L.t('security')), subtitle: Text(L.t('securitySub')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SecurityScreen()))),
        for (final r in FileOps.roots().where((r) => r.sd)) _SdTile(root: r),
        const Divider(),
        ListTile(leading: const Icon(Icons.pie_chart_rounded), title: Text(L.t('analyzer')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AnalyzerScreen()))),
        ListTile(leading: const Icon(Icons.content_copy_rounded), title: Text(L.t('dupFinder')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DuplicatesScreen()))),
        ListTile(leading: const Icon(Icons.star_rounded), title: Text(L.t('favorites')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PathListScreen(title: L.t('favorites'), fav: true)))),
        ListTile(leading: const Icon(Icons.history_rounded), title: Text(L.t('recents')), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PathListScreen(title: L.t('recents'), fav: false)))),
        const Divider(),
        ListTile(leading: const Icon(Icons.info_outline_rounded), title: Text(L.t('about')), subtitle: const Text('Abtin File Manager 0.30.0')),
      ])),
    );
  }
}

class _SdTile extends StatefulWidget {
  final StorageRoot root;
  const _SdTile({required this.root});
  @override
  State<_SdTile> createState() => _SdTileState();
}

class _SdTileState extends State<_SdTile> {
  Future<int> _state() async {
    // 0 = not needed, 1 = granted, 2 = needs access
    if (!await Saf.needsSaf(widget.root.path)) return 0;
    return await Saf.has(Saf.volumeOf(widget.root.path)!) ? 1 : 2;
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<int>(
        future: _state(),
        builder: (c, snap) => ListTile(
          leading: const Icon(Icons.sd_card_rounded),
          title: Text('${L.t('sdAccess')} (${widget.root.name})'),
          subtitle: Text(snap.data == 1 ? L.t('sdGranted') : snap.data == 2 ? L.t('sdNotGranted') : L.t('sdDirect')),
          onTap: snap.data == 0 || snap.data == null
              ? null
              : () async {
                  await manageSdAccess(context, widget.root.path);
                  if (mounted) setState(() {});
                },
        ),
      );
}
