import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../services/player_service.dart';

class EqualizerScreen extends StatelessWidget {
  const EqualizerScreen({super.key});
  static const presets = <String, List<double>>{
    'Flat': [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    'Rock': [4, 3, 2, -1, -2, 2, 4, 5, 5, 5],
    'Pop': [-1, 1, 3, 4, 3, 0, -1, -1, 1, 2],
    'Jazz': [3, 2, 1, 2, -2, -2, 0, 1, 2, 3],
    'Classical': [4, 3, 2, 2, -1, -1, 0, 2, 3, 4],
    'Hip-Hop': [5, 4, 2, 3, -1, -1, 2, 0, 2, 3],
    'Electronic': [5, 4, 1, 0, -2, 2, 1, 3, 4, 5],
  };

  @override
  Widget build(BuildContext context) {
    final pl = context.watch<PlayerService>();
    return Scaffold(
      appBar: AppBar(
        title: Text(L.t('equalizer')),
        actions: [Switch(value: pl.eqOn, onChanged: (v) { pl.eqOn = v; pl.applyEq(); })],
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Wrap(spacing: 8, children: [
          for (final e in presets.entries)
            ActionChip(label: Text(e.key), onPressed: () { pl.eq = List.of(e.value); pl.eqOn = true; pl.applyEq(); }),
        ]),
        const SizedBox(height: 16),
        SizedBox(
          height: 240,
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            for (var i = 0; i < 10; i++)
              Column(children: [
                Expanded(
                  child: RotatedBox(
                    quarterTurns: 3,
                    child: Slider(min: -12, max: 12, value: pl.eq[i], onChanged: (v) { pl.eq[i] = v; pl.touch(); }, onChangeEnd: (_) => pl.applyEq()),
                  ),
                ),
                Text(PlayerService.eqFreqs[i] >= 1000 ? '${PlayerService.eqFreqs[i] ~/ 1000}k' : '${PlayerService.eqFreqs[i]}', style: const TextStyle(fontSize: 10)),
              ]),
          ]),
        ),
        ListTile(title: Text(L.t('bass')), subtitle: Slider(min: 0, max: 15, value: pl.bass, onChanged: (v) { pl.bass = v; pl.touch(); }, onChangeEnd: (_) => pl.applyEq())),
        ListTile(title: Text(L.t('volume')), subtitle: Slider(min: -10, max: 10, value: pl.preamp, onChanged: (v) { pl.preamp = v; pl.touch(); }, onChangeEnd: (_) => pl.applyEq())),
        OutlinedButton(onPressed: () { pl.eq = List.filled(10, 0); pl.bass = 0; pl.preamp = 0; pl.applyEq(); }, child: Text(L.t('reset'))),
      ]),
    );
  }
}
