import 'dart:io';
import 'package:flutter/material.dart';
import '../services/saf.dart';
import '../services/file_ops.dart';
import 'saf_prompt.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/highlighter.dart';
import '../widgets/ui.dart';
import 'hash_screen.dart';
import 'hex_viewer_screen.dart';

class TextEditorScreen extends StatefulWidget {
  final String path;
  const TextEditorScreen({super.key, required this.path});
  @override
  State<TextEditorScreen> createState() => _TextEditorScreenState();
}

class _TextEditorScreenState extends State<TextEditorScreen> {
  late final CodeController ctl = CodeController(lang: Hl.langOf(widget.path));
  bool loaded = false, dirty = false;
  double font = 14;

  @override
  void initState() {
    super.initState();
    File(widget.path).readAsString().then((t) { if (mounted) setState(() { ctl.text = t; loaded = true; }); }).catchError((e) {
      if (mounted) { snack(context, '$e'); Navigator.pop(context); }
    });
  }

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  void _push(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    ctl.dark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(
        title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 16)),
        actions: [
          IconButton(icon: const Icon(Icons.text_decrease_rounded), onPressed: () => setState(() => font = (font - 1).clamp(9, 40))),
          IconButton(icon: const Icon(Icons.text_increase_rounded), onPressed: () => setState(() => font = (font + 1).clamp(9, 40))),
          IconButton(
            icon: Icon(Icons.save_rounded, color: dirty ? Colors.amber : null),
            tooltip: L.t('save'),
            onPressed: () async {
              if (!await ensureSdAll(context, [widget.path])) return;
              try {
                await Saf.writeString(widget.path, ctl.text);
              } on OpError catch (e) {
                if (mounted) snack(context, L.t(e.key));
                return;
              }
              setState(() => dirty = false);
              if (mounted) snack(context, L.t('done'));
            },
          ),
          PopupMenuButton<int>(
            onSelected: (v) {
              if (v == 0) setState(() => ctl.enabled = !ctl.enabled);
              if (v == 1) _push(HexViewerScreen(path: widget.path));
              if (v == 2) _push(HashScreen(path: widget.path));
            },
            itemBuilder: (_) => [
              if (ctl.lang.isNotEmpty) CheckedPopupMenuItem(value: 0, checked: ctl.enabled, child: Text(L.t('syntax'))),
              PopupMenuItem(value: 1, child: Text(L.t('hex'))),
              PopupMenuItem(value: 2, child: Text(L.t('hash'))),
            ],
          ),
        ],
      ),
      body: !loaded
          ? const Center(child: CircularProgressIndicator())
          : TextField(
              controller: ctl,
              maxLines: null,
              expands: true,
              textAlignVertical: TextAlignVertical.top,
              style: TextStyle(fontFamily: 'monospace', fontSize: font),
              onChanged: (_) { if (!dirty) setState(() => dirty = true); },
              decoration: const InputDecoration(border: InputBorder.none, contentPadding: EdgeInsets.all(12)),
            ),
    );
  }
}
