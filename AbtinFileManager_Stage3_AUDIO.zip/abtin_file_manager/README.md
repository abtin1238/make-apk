# Abtin File Manager (Flutter)
Complete file manager + media player + LAN transfer + archive extractor (zip/rar/7z/tar/gz/bz2/xz).

```
flutter create . --platforms=android --org com.abtin
flutter pub get
flutter run
```
Needs `android/local.properties` (flutter.sdk). See TODO.md for status and roadmap.

v0.3: Word (rich formatting, tables, images, undo, find/replace), legacy .doc (text -> .docx) and PDF (draw/highlight/text/page ops) are editable in-app. See TODO.md.
v0.4: complete media player (background audio + notification, tags/cover art, sleep timer, queue editor; video gestures, PiP, subtitles tools, resume, network streams) and media library screen.

v0.17: tar.gz / 7z (password) creation, extraction & compression progress, ProGuard rules, release signing (`android/key.properties`), CI workflow and unit tests. See TODO.md.
