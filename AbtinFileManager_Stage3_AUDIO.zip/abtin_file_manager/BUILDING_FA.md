# راهنمای ساخت Abtin File Manager

## پیش‌نیازها

- Flutter 3.38.5 یا جدیدتر و Dart سازگار
- JDK 17 یا جدیدتر
- Android SDK Platform 36 و Android Build Tools 36.0.0
- Gradle Wrapper پروژه نسخهٔ 8.9 را به‌صورت خودکار دریافت می‌کند

## ساخت APK Release

از ریشهٔ پروژه اجرا کنید:

```bash
flutter pub get
flutter build apk --release --target-platform android-arm64
```

خروجی در این مسیر قرار می‌گیرد:

```text
build/app/outputs/flutter-apk/app-release.apk
```

پروژه برای Android API 36 کامپایل می‌شود و حداقل Android API آن 24 است.

## امضای Release

فایل `android/key.properties` به keystore موجود در `android/keystore/abtin-file-manager-release.jks` اشاره می‌کند. مقادیر alias و رمزها در همان فایل تنظیم شده‌اند. برای ساخت، این دو فایل باید کنار سورس باقی بمانند.

**محرمانگی:** keystore و رمزهای آن اختیار امضای نسخه‌های بعدی برنامه را می‌دهند. فایل را در مخزن عمومی یا برای افراد دیگر منتشر نکنید و یک نسخهٔ پشتیبان امن و جداگانه نگه دارید. اگر keystore گم شود، به‌روزرسانی نصب‌های امضاشده با این کلید ممکن نخواهد بود.

## نکته دربارهٔ سورس اصلاح‌شده

برای سازگاری با Flutter جدید، موارد ناسازگار در API آیکن/تم، callback نوع nullable مربوط به PDF، خواندن provider و enumهای `ftpconnect` اصلاح شده‌اند. dependencyهای resolveشده در `pubspec.lock` قفل شده‌اند تا buildهای بعدی تا حد ممکن تکرارپذیر باشند.
