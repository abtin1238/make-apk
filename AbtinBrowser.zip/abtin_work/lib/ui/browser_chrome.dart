part of 'browser_page.dart';
// ignore_for_file: invalid_use_of_protected_member

extension _Chrome on _BrowserPageState {
  /// Icon shown for an empty "new tab" (instead of a '+' / letter).
  Widget _mapsIcon(double size) => ClipRRect(borderRadius: BorderRadius.circular(size * .22), child: AbtinLogo(size: size));

  Widget _fav(BrowserTab t, {double size = 18}) {
    if (t.isNewTab && !t.private) return _mapsIcon(size);
    final f = t.faviconUrl ?? (t.private ? null : app.faviconFor(t.url.isNotEmpty ? t.url : (t.lazyUrl ?? '')));
    if (f != null && f.isNotEmpty) return _iconFrom(f, t.displayTitle, size);
    if (t.private) return Icon(Icons.visibility_off, size: size, color: const Color(0xFFB794F6));
    return _letter(t.displayTitle.isEmpty ? '+' : t.displayTitle, size);
  }

  Widget _iconFrom(String f, String title, double size) => siteIconFrom(f, title, size);

  Widget _siteIcon(String url, String title, double size) => SiteIcon(url, title: title, size: size);

  Widget _letter(String s, double size) => siteLetter(s, size);

  // ---------------- tab strip ----------------
  /// Tabs keep a fixed minimum width; with many tabs the strip scrolls horizontally.
  /// Tab strip + address bar drawn as ONE piece: the selected tab has the same colour as the toolbar below it.
  /// Own top-bar colour chosen with the sliders in Settings (0 = follow the accent colour).
  Color? _customBar() { final v = app.num_('barColor'); return v == 0 ? null : Color(v); }

  /// Readable foreground for the top bar (matters when a custom bar colour is set).
  Color? _barFg() { final c = _customBar(); return c == null ? null : (c.computeLuminance() > .5 ? const Color(0xDE000000) : Colors.white); }

  /// Colour scheme for everything drawn on the top bar: on a custom bar colour the text/icon colour follows its brightness.
  ColorScheme _cs() {
    final cs = Theme.of(context).colorScheme;
    final fg = _barFg();
    return fg == null ? cs : cs.copyWith(onSurface: fg, onSurfaceVariant: fg);
  }

  Widget _barTheme(Widget child) {
    final fg = _barFg();
    if (fg == null) return child;
    final th = Theme.of(context);
    return Theme(
      data: th.copyWith(
        colorScheme: th.colorScheme.copyWith(onSurface: fg, onSurfaceVariant: fg),
        iconTheme: IconThemeData(color: fg),
        textTheme: th.textTheme.apply(bodyColor: fg, displayColor: fg),
      ),
      child: DefaultTextStyle.merge(style: TextStyle(color: fg), child: child),
    );
  }

  /// Base colour of the top bar: a custom colour, else it follows the accent colour (and the palette).
  Color _barBase() {
    final custom = _customBar();
    if (custom != null) return custom;
    final cs = Theme.of(context).colorScheme;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final base = app.iosLook ? app.palette.appBarColor('ios') : cs.surface;
    return Color.alphaBlend(cs.primary.withValues(alpha: dark ? .14 : .10), base);
  }

  Color _stripColor() {
    final custom = _customBar();
    if (custom != null) return Color.alphaBlend(Colors.black.withValues(alpha: .14), custom);
    final cs = Theme.of(context).colorScheme;
    // Chrome Black theme: strip is pure black, the active tab + toolbar are one lighter piece (like the light theme).
    if (app.palette.id == 'chrome-black') return const Color(0xFF000000);
    return Color.alphaBlend(cs.onSurface.withValues(alpha: .07), _barBase());
  }

  Color _activeFill() {
    final custom = _customBar();
    if (custom != null) return current.private ? Color.alphaBlend(const Color(0xFF8B5CF6).withValues(alpha: .35), custom) : custom;
    final cs = Theme.of(context).colorScheme;
    final accent = current.private ? const Color(0xFF8B5CF6) : cs.primary;
    final base = app.iosLook ? app.palette.appBarColor('ios') : cs.surface;
    // White trapezoid tabs (light browser theme): pure white active tab + toolbar, no accent tint.
    if (_lay == TabLayout.chrome && Theme.of(context).brightness == Brightness.light) {
      return current.private ? Color.alphaBlend(accent.withValues(alpha: .12), Colors.white) : Colors.white;
    }
    if (app.palette.id == 'chrome-black') {
      return current.private ? Color.alphaBlend(accent.withValues(alpha: .18), const Color(0xFF202124)) : const Color(0xFF202124);
    }
    return Color.alphaBlend(accent.withValues(alpha: Theme.of(context).brightness == Brightness.dark ? .30 : .22), base);
  }

  /// Height of the top bar: in the iOS look the menu opens BELOW it so it never covers the gear.
  double _menuTopInset() {
    if (!app.iosLook) return 0;
    final box = _chromeKey.currentContext?.findRenderObject();
    return box is RenderBox && box.hasSize ? box.size.height : 0;
  }

  /// Layouts whose active tab is not "joined" to the toolbar use one flat toolbar colour for strip and bar.
  Color _topEdgeColor() => _lay.joined ? _stripColor() : _barBase();

  Widget _topChrome() {
    final lay = _lay;
    final joined = lay.joined;
    final strip = Container(color: joined ? _stripColor() : _barBase(), padding: EdgeInsets.only(top: joined ? 2 : 0), child: _tabStrip());
    final bar = Container(color: joined ? _activeFill() : _barBase(), padding: const EdgeInsets.only(top: 3, bottom: 2), child: app.iosLook ? _iosTopBar() : _addressBar());
    return _barTheme(Column(mainAxisSize: MainAxisSize.min, children: [
      if (lay.stripBelow) ...[bar, strip] else ...[strip, bar],
      if (!joined) Container(height: .6, color: Theme.of(context).dividerColor),
    ]));
  }

  /// Loading progress drawn INSIDE the address bar (like Safari) instead of a thin line under the bar.
  Widget? _progressFill(BrowserTab t) {
    if (!(t.loading && t.progress > 0 && t.progress < 1)) return null;
    final cs = _cs();
    return Positioned.fill(child: Directionality(textDirection: TextDirection.ltr, child: Align(alignment: Alignment.centerLeft, child: FractionallySizedBox(widthFactor: t.progress, heightFactor: 1, child: ColoredBox(color: cs.primary.withValues(alpha: .26))))));
  }

  TabLayout get _lay => app.palette.tabLayout;

  /// Width of one tab: most layouts share a clamped width, "compact" collapses every inactive tab to its icon.
  double _tabW(int i, double boxW, int n) {
    double clampW(double lo, double hi) => (boxW / n).clamp(lo, hi).toDouble();
    switch (_lay) {
      case TabLayout.compact:
        const slot = 46.0;
        final sel = (boxW - slot * (n - 1)).clamp(120.0, 180.0).toDouble();
        return i == cur ? sel : slot;
      case TabLayout.pills: return clampW(118, 160);
      case TabLayout.cards: return clampW(120, 165);
      case TabLayout.chrome: return clampW(124, 180);
      case TabLayout.angled: return clampW(128, 175);
      case TabLayout.folder: return clampW(122, 165);
      case TabLayout.underline: return clampW(112, 155);
      case TabLayout.ios: return clampW(110, 150);
    }
  }

  Widget _tabStrip() {
    return SizedBox(
      height: _lay.stripHeight,
      child: Row(children: [
        Expanded(
          child: LayoutBuilder(builder: (ctx, box) {
            final n = tabs.length;
            double widthOf(int i) => _tabW(i, box.maxWidth, n);
            // Bring the selected tab (or a newly opened one) into view.
            if (_lastCur != cur || _lastTabCount != n) {
              final grew = n > _lastTabCount;
              _lastCur = cur; _lastTabCount = n;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (!tabScroll.hasClients) return;
                final pos = tabScroll.position;
                var before = 0.0;
                for (var i = 0; i < cur && i < n; i++) { before += widthOf(i); }
                final w = widthOf(cur.clamp(0, n - 1));
                final target = grew && cur == n - 1 ? pos.maxScrollExtent : (before - (box.maxWidth - w) / 2).clamp(0.0, pos.maxScrollExtent);
                tabScroll.animateTo(target.toDouble(), duration: const Duration(milliseconds: 220), curve: Curves.easeOut);
              });
            }
            return ListView.builder(
              controller: tabScroll,
              scrollDirection: Axis.horizontal, itemCount: n,
              physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
              itemBuilder: (_, i) => SizedBox(width: widthOf(i), child: _tabChip(tabs[i], i == cur, widthOf(i))),
            );
          }),
        ),
        InkWell(onTap: () => openTab(''), borderRadius: BorderRadius.circular(12), child: const SizedBox(width: 34, height: 34, child: Icon(Icons.add, size: 20))),
      ]),
    );
  }

  /// Close (✕) button of a tab: always a roomy 28 px target, optionally on a round background.
  Widget _closeBtn(BrowserTab t, Color color, {bool circle = false}) => InkWell(
        onTap: () => closeTab(t), customBorder: const CircleBorder(),
        child: Container(
          width: 28, height: 28, alignment: Alignment.center,
          child: Container(
            width: circle ? 20 : 24, height: circle ? 20 : 24, alignment: Alignment.center,
            decoration: circle ? BoxDecoration(shape: BoxShape.circle, color: color.withValues(alpha: .16)) : null,
            child: Icon(Icons.close, size: circle ? 13 : 15, color: color),
          ),
        ),
      );

  Widget _tabChip(BrowserTab t, bool sel, double w) {
    final cs = _cs();
    final lay = _lay;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final g = t.groupId == null ? null : app.groups.where((x) => x.id == t.groupId).firstOrNull;
    final stripe = g == null ? null : Color(g.color);
    final fg = cs.onSurface;
    final dim = cs.onSurfaceVariant.withValues(alpha: .80);
    final accent = t.private ? const Color(0xFF8B5CF6) : cs.primary;
    final base = _barBase();
    final soft = Color.alphaBlend(fg.withValues(alpha: .075), base);

    // One row for every layout: site icon · title · ✕. All the spacing sits INSIDE the clipped silhouette, so the icon,
    // the title and the ✕ can never be cut by a slanted / round tab end.
    Widget row({double start = 10, double end = 2, bool close = true, bool title = true, bool tile = false, bool circle = false, Color? ink, Color? sub}) {
      final f = ink ?? fg, d = sub ?? dim;
      final icon = tile
          ? Container(width: 24, height: 24, alignment: Alignment.center, decoration: BoxDecoration(color: f.withValues(alpha: .10), borderRadius: BorderRadius.circular(8)), child: _fav(t, size: 15))
          : _fav(t, size: 17);
      return Padding(
        padding: EdgeInsetsDirectional.only(start: start, end: end),
        child: Row(children: [
          icon,
          if (title) ...[
            SizedBox(width: tile ? 8 : 7),
            Expanded(child: Text(t.isNewTab ? tr('تب جدید', 'New tab') : t.displayTitle, maxLines: 1, overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 12.5, height: 1.2, fontWeight: sel ? FontWeight.w700 : FontWeight.w500, color: sel ? f : d))),
            if (close) _closeBtn(t, sel ? f : d, circle: circle) else const SizedBox(width: 8),
          ] else
            const SizedBox.shrink(),
        ]),
      );
    }

    Widget wrap(Widget child) => GestureDetector(behavior: HitTestBehavior.opaque, onTap: () => selectTab(t), child: child);
    Widget stripeBar() => stripe == null ? const SizedBox.shrink() : Positioned(left: 10, right: 10, top: 0, height: 2.5, child: DecoratedBox(decoration: BoxDecoration(color: stripe, borderRadius: BorderRadius.circular(2))));
    Widget body(Widget r) => Stack(fit: StackFit.expand, children: [stripeBar(), r]);

    switch (lay) {
      // ── Safari ──────────────────────────────────────────────
      case TabLayout.ios: {
        final inactive = dark ? const Color(0xFF3A3A3F) : const Color(0xFFDADADF);
        final sub = dark ? Colors.white70 : Colors.black54;
        return wrap(Container(
          margin: const EdgeInsets.fromLTRB(2, 4, 2, 0),
          decoration: BoxDecoration(color: sel ? _activeFill() : inactive, borderRadius: const BorderRadius.vertical(top: Radius.circular(10))),
          child: body(row(start: 10, end: 2, sub: sub)),
        ));
      }
      // ── floating capsules ───────────────────────────────────
      case TabLayout.pills:
        return wrap(Container(
          margin: const EdgeInsets.symmetric(horizontal: 3, vertical: 5),
          decoration: BoxDecoration(
            color: sel ? _activeFill() : fg.withValues(alpha: .07),
            borderRadius: BorderRadius.circular(22),
            border: sel ? Border.all(color: accent.withValues(alpha: .7), width: 1.2) : null,
          ),
          child: body(row(start: 11, end: 4, circle: true)),
        ));
      // ── Chrome-style rounded white tab, separators between inactive tabs ───
      case TabLayout.chrome:
        return wrap(Container(
          margin: const EdgeInsets.only(top: 4, left: 1, right: 1),
          child: ClipPath(
            clipper: const BrowserTabClipper(BrowserTabShape.trapezoid),
            child: Container(
              color: sel ? _activeFill() : Colors.transparent,
              child: Stack(fit: StackFit.expand, children: [
                if (!sel) PositionedDirectional(end: 0, top: 9, bottom: 9, child: Container(width: 1, color: dim.withValues(alpha: .35))),
                if (sel) Positioned(left: 0, right: 0, top: 0, height: 2.5, child: ColoredBox(color: accent)),
                body(row(start: 12, end: 4)),
              ]),
            ),
          ),
        ));
      // ── glass cards with an icon tile; strip lives UNDER the address bar ──
      case TabLayout.cards:
        return wrap(Container(
          margin: const EdgeInsets.symmetric(horizontal: 3, vertical: 5),
          decoration: BoxDecoration(
            color: sel ? Color.alphaBlend(accent.withValues(alpha: dark ? .24 : .16), base) : fg.withValues(alpha: .06),
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: sel ? accent.withValues(alpha: .65) : fg.withValues(alpha: .08), width: sel ? 1.2 : 1),
          ),
          child: body(row(start: 5, end: 4, tile: true, circle: true)),
        ));
      // ── flat tabs with an accent underline, ✕ only on the active tab ──
      case TabLayout.underline:
        return wrap(Container(
          margin: const EdgeInsets.symmetric(horizontal: 2),
          child: Stack(fit: StackFit.expand, children: [
            body(row(start: 10, end: 4, close: sel)),
            PositionedDirectional(start: 8, end: 8, bottom: 0, height: 3,
                child: DecoratedBox(decoration: BoxDecoration(color: sel ? accent : Colors.transparent, borderRadius: const BorderRadius.vertical(top: Radius.circular(3))))),
          ]),
        ));
      // ── parallelogram tabs ──────────────────────────────────
      case TabLayout.angled:
        return wrap(Container(
          margin: const EdgeInsets.only(top: 4, left: 1, right: 1),
          child: ClipPath(
            clipper: const BrowserTabClipper(BrowserTabShape.angled),
            child: Container(color: sel ? _activeFill() : soft, child: body(row(start: 24, end: 20))),
          ),
        ));
      // ── compact: the active tab is wide, the rest are just their site icon (long press = close) ──
      case TabLayout.compact:
        if (sel) {
          return wrap(Container(
            margin: const EdgeInsets.only(top: 4, left: 1, right: 1),
            decoration: BoxDecoration(color: _activeFill(), borderRadius: const BorderRadius.vertical(top: Radius.circular(9))),
            child: body(row(start: 11, end: 3)),
          ));
        }
        return GestureDetector(
          behavior: HitTestBehavior.opaque, onTap: () => selectTab(t), onLongPress: () => closeTab(t),
          child: Container(
            margin: const EdgeInsets.only(top: 8, left: 2, right: 2, bottom: 2),
            decoration: BoxDecoration(color: fg.withValues(alpha: .06), borderRadius: BorderRadius.circular(10)),
            alignment: Alignment.center,
            child: _fav(t, size: 18),
          ),
        );
      // ── folder tabs: the active one is raised and has an accent cap, the rest sit lower ──
      case TabLayout.folder:
        return wrap(Align(
          alignment: Alignment.bottomCenter,
          child: Container(
            height: sel ? 33 : 27,
            margin: const EdgeInsets.symmetric(horizontal: 2),
            decoration: BoxDecoration(
              color: sel ? _activeFill() : soft,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(13)),
              border: sel ? Border(top: BorderSide(color: accent, width: 2.5)) : null,
            ),
            child: body(row(start: 11, end: 3)),
          ),
        ));
    }
  }

  // ---------------- address bar ----------------
  Widget _barBtn(IconData i, VoidCallback? f, {double size = 20}) => IconButton(
        onPressed: f, icon: Icon(i, size: size), padding: EdgeInsets.zero,
        constraints: const BoxConstraints.tightFor(width: 34, height: 32), visualDensity: VisualDensity.compact,
      );

  /// Tap toggles the selected DNS; long press opens its configuration list.
  Widget _dnsButton() {
    final on = dnsMgr.on, busy = dnsMgr.busy && !on;
    // The IconButton's own `tooltip` would swallow the long press (it shows the hint instead), so the hint lives in a
    // manual-trigger Tooltip: same accessibility label, no gesture of its own.
    return GestureDetector(
      onLongPress: _showDnsQuickPicker,
      child: Tooltip(
        message: tr('لمس: روشن/خاموش · لمس طولانی: انتخاب DNS', 'Tap: toggle · long press: choose DNS'),
        triggerMode: TooltipTriggerMode.manual,
        child: IconButton(
        onPressed: busy ? null : () async { await toggleDns(); },
        padding: EdgeInsets.zero,
        constraints: const BoxConstraints.tightFor(width: 34, height: 32),
        visualDensity: VisualDensity.compact,
        icon: busy
            ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2))
            : Icon(on ? Icons.dns_rounded : Icons.dns_outlined, size: 20, color: on ? const Color(0xFF34C759) : null),
        ),
      ),
    );
  }

  Future<void> _showDnsQuickPicker() async {
    await showModalBottomSheet<void>(
      context: context, isScrollControlled: true, showDragHandle: true,
      builder: (sheetContext) => SafeArea(child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: MediaQuery.of(sheetContext).size.height * .62),
        child: ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 16), shrinkWrap: true, children: [
          ListTile(dense: true, title: Text(tr('انتخاب DNS', 'Choose DNS'), style: const TextStyle(fontWeight: FontWeight.bold)), trailing: IconButton(tooltip: tr('مدیریت کامل', 'Full manager'), icon: const Icon(Icons.tune_rounded), onPressed: () { Navigator.pop(sheetContext); _push(const DnsPage()); })),
          for (final c in dnsMgr.customs)
            RadioListTile<String>(dense: true, value: 'c:${c['n']}', groupValue: dnsMgr.selected, title: Text(c['n']!), subtitle: Text(c['s']!, textDirection: TextDirection.ltr), onChanged: (v) { if (v != null) { dnsMgr.select(v); Navigator.pop(sheetContext); } }),
          for (final p in dnsPresets)
            RadioListTile<String>(dense: true, value: p.id, groupValue: dnsMgr.selected, title: Text(tr(p.fa, p.en)), onChanged: (v) { if (v != null) { dnsMgr.select(v); Navigator.pop(sheetContext); } }),
        ]),
      )),
    );
  }

  Future<void> _showVpnQuickPicker() async {
    await v2ray.init();
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context, isScrollControlled: true, showDragHandle: true,
      builder: (sheetContext) => AnimatedBuilder(
        animation: v2ray,
        builder: (context, _) => SafeArea(child: ConstrainedBox(
          constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * .62),
          child: v2ray.profiles.isEmpty
              ? Padding(padding: const EdgeInsets.all(24), child: Text(tr('کانفیگی ذخیره نشده است', 'No saved configurations')))
              : ListView(padding: const EdgeInsets.fromLTRB(12, 0, 12, 16), shrinkWrap: true, children: [
                  ListTile(dense: true, title: Text(tr('انتخاب کانفیگ VPN', 'Choose VPN config'), style: const TextStyle(fontWeight: FontWeight.bold)), trailing: IconButton(tooltip: tr('مدیریت کامل', 'Full manager'), icon: const Icon(Icons.tune_rounded), onPressed: () { Navigator.pop(sheetContext); _push(const V2rayPage()); })),
                  for (final p in v2ray.profiles)
                    ListTile(
                      dense: true,
                      leading: Icon(p.id == v2ray.selectedId ? Icons.radio_button_checked : Icons.radio_button_off, color: p.id == v2ray.selectedId ? Theme.of(context).colorScheme.primary : null),
                      title: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(p.testing ? tr('در حال تست پینگ…', 'Testing ping…') : p.ping == null ? tr('پینگ تست نشده', 'Ping not tested') : p.ping! < 0 ? '✕' : '${p.ping} ms', textDirection: TextDirection.ltr),
                      trailing: IconButton(tooltip: tr('تست پینگ واقعی', 'Real ping test'), icon: p.testing ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.network_ping_rounded), onPressed: p.testing ? null : () => v2ray.ping(p)),
                      onTap: () async {
                        v2ray.select(p);
                        Navigator.pop(sheetContext);
                        final err = await v2ray.connect(p);
                        if (err != null && mounted) toast(tr('اتصال این کانفیگ ناموفق بود', 'Could not connect this config'));
                      },
                    ),
                ]),
        )),
      ),
    );
  }

  /// The button next to the menu. What it does is chosen in Settings > Appearance (or it can be hidden).
  Widget _topButton(String mode) {
    final t = current;
    final page = t.started && !t.showHome;
    final web = page && t.url.startsWith('http');
    switch (mode) {
      case 'none':
        return const SizedBox(width: 4);
      case 'newtab':
        return _barBtn(Icons.add_rounded, () => openTab(''));
      case 'private':
        return _barBtn(Icons.visibility_off_outlined, () => openTab('', private: true), size: 20);
      case 'home':
        return _barBtn(Icons.home_outlined, page ? () { setState(() => t.showHome = true); _syncAddr(); } : null);
      case 'reload':
        return _barBtn(t.loading ? Icons.close : Icons.refresh, page ? () => gecko.call(t.loading ? 'stop' : 'reload', {'id': t.nid}) : null);
      case 'bookmark':
        return _barBtn(app.isBookmarked(t.url) ? Icons.star : Icons.star_border, web ? () {
          setState(() => app.toggleBookmark(t.url, t.title));
          toast(app.isBookmarked(t.url) ? tr('به نشانک‌ها افزوده شد', 'Bookmarked') : tr('از نشانک‌ها حذف شد', 'Bookmark removed'));
        } : null);
      case 'vpn':
        return _vpnButton();
      case 'share':
        return _barBtn(Icons.share_outlined, page ? () => Share.share(t.url) : null, size: 20);
      case 'reader':
        return _barBtn(Icons.chrome_reader_mode_outlined, page && !t.failed ? _toggleReader : null, size: 20);
      case 'video':
        return _barBtn(Icons.smart_display_outlined, page ? _openMediaSheet : null, size: 21);
      case 'qr':
        return _barBtn(Icons.qr_code_scanner_rounded, _scanQr, size: 21);
      case 'bookmarks':
        return _barBtn(Icons.bookmarks_outlined, _openBookmarks, size: 20);
      case 'downloads':
        return _barBtn(Icons.download_outlined, _openDownloads, size: 20);
      case 'screenshot':
        return _barBtn(Icons.photo_camera_outlined, page ? _takeScreenshot : null, size: 20);
      case 'desktop':
        return _barBtn(Icons.desktop_windows_outlined, page ? () { setState(() => t.desktop = !t.desktop); gecko.call('setDesktop', {'id': t.nid, 'desktop': t.desktop}); } : null, size: 20);
      case 'find':
        return _barBtn(Icons.find_in_page_outlined, page ? () => setState(() => finding = true) : null, size: 20);
      case 'settings':
        return _barBtn(Icons.tune_rounded, _openSettings, size: 20);
      case 'menu':
        return _barBtn(Icons.settings_outlined, _openMenu, size: 21);
      case 'extensions':
        return _barBtn(Icons.extension_outlined, _openExtensions, size: 21);
      case 'dns':
        return _dnsButton();
      case 'tabs':
      default:
        final cs = _cs();
        return InkWell(
          onTap: _openSwitcher, borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 24, height: 24, margin: const EdgeInsets.symmetric(horizontal: 5), alignment: Alignment.center,
            decoration: BoxDecoration(border: Border.all(color: cs.onSurface.withValues(alpha: .8), width: 1.5), borderRadius: BorderRadius.circular(7)),
            child: Text('${tabs.length}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
          ),
        );
    }
  }

  /// Tap toggles the selected VPN; long press opens the config list and real ping tests.
  Widget _vpnButton() {
    final cs = _cs();
    final on = v2ray.connected, busy = v2ray.connecting;
    return GestureDetector(
      onLongPress: _showVpnQuickPicker,
      child: Tooltip(
        message: tr('لمس: اتصال/قطع · لمس طولانی: کانفیگ و پینگ', 'Tap: connect/disconnect · long press: configs and ping'),
        triggerMode: TooltipTriggerMode.manual,
        child: IconButton(
        onPressed: busy ? null : () async {
          if (v2ray.connected) { await v2ray.disconnect(); }
          else {
            final err = await v2ray.connect();
            if (err != null && mounted) toast(tr('اتصال VPN ناموفق بود', 'VPN connection failed'));
          }
        },
        icon: busy
            ? SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: cs.primary))
            : Icon(on ? Icons.vpn_key : Icons.vpn_key_off_outlined, size: 20, color: on ? Colors.greenAccent.shade400 : null),
        padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 34, height: 32), visualDensity: VisualDensity.compact,
        ),
      ),
    );
  }

  Future<void> _toggleReader() async {
    final t = current;
    final ok = await gecko.call<bool>('contentCmd', {'id': t.nid, 'cmd': {'cmd': 'reader', 'dark': app.dark, 'lang': app.lang}});
    if (ok != true) toast(tr('حالت خواندن برای این صفحه آماده نیست؛ چند ثانیه بعد دوباره امتحان کنید', 'Reader mode is not ready for this page yet'));
  }

  /// Inspect element: toggles the in-page inspector (tap an element to see / edit its attributes, styles, box model and HTML).
  Future<void> _inspectElement() async {
    final t = current;
    final ok = await gecko.call<bool>('contentCmd', {'id': t.nid, 'cmd': {'cmd': 'inspect', 'lang': app.lang}});
    if (ok != true) toast(tr('بازرسی المنت برای این صفحه آماده نیست؛ چند ثانیه بعد دوباره امتحان کنید', 'Inspector is not ready for this page yet'));
  }

  Widget _addressBar() {
    final t = current;
    IconData lockIcon; Color? lockColor;
    if (t.showHome) { lockIcon = Icons.search; lockColor = null; }
    else if (t.failed) { lockIcon = Icons.warning_amber_rounded; lockColor = Colors.orange; }
    else if (t.secure) { lockIcon = Icons.lock; lockColor = const Color(0xFF34C759); }
    else { lockIcon = Icons.lock_open; lockColor = Colors.redAccent; }
    return Padding(
      padding: const EdgeInsets.fromLTRB(2, 0, 2, 2),
      child: Row(children: [
        _barBtn(Icons.arrow_back, () async { if (await _back()) {} }),
        Expanded(
          child: Glass(
            radius: 16, borderColor: t.private ? const Color(0xFF8B5CF6) : null, borderWidth: t.private ? 1.4 : 1,
            child: Stack(children: [
             if (_progressFill(t) != null) _progressFill(t)!,
             Row(children: [
              IconButton(
                visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 30, height: 32),
                onPressed: t.showHome ? null : _siteInfo, icon: Icon(lockIcon, size: 15, color: lockColor),
              ),
              Expanded(
                child: Stack(children: [
                  TextField(
                    controller: addr, focusNode: addrFocus, textDirection: TextDirection.ltr, textInputAction: TextInputAction.go,
                    keyboardType: TextInputType.url, autocorrect: false, enableSuggestions: false, style: const TextStyle(fontSize: 14),
                    onChanged: _onAddrChanged, onSubmitted: (v) => navigate(current, v),
                    decoration: InputDecoration(border: InputBorder.none, isDense: true, hintText: tr('جست‌وجو یا وارد کردن آدرس', 'Search or enter address'), contentPadding: const EdgeInsets.symmetric(vertical: 6)),
                  ),
                  // loaded page: a tap opens the Copy / Edit popup instead of starting to type
                  if (_urlTapMode(t)) Positioned.fill(child: _urlTapCatcher()),
                ]),
              ),
              if (editing && addr.text.isNotEmpty)
                IconButton(visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 30, height: 32), tooltip: tr('پاک کردن آدرس', 'Clear address'), onPressed: () { addr.clear(); _onAddrChanged(''); }, icon: const Icon(Icons.close, size: 20))
              else if (editing || t.showHome)
                IconButton(visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 30, height: 32), tooltip: tr('اسکن QR', 'Scan QR'), onPressed: _scanQr, icon: const Icon(Icons.qr_code_scanner_rounded, size: 19))
              else ...[
                if (t.media.isNotEmpty)
                  IconButton(
                    visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 34, height: 32), tooltip: tr('ویدیوهای صفحه', 'Page videos'),
                    onPressed: _openMediaSheet,
                    icon: Badge(label: Text('${t.media.length}', style: const TextStyle(fontSize: 9)), child: Icon(Icons.smart_display_rounded, size: 21, color: Theme.of(context).colorScheme.primary)),
                  ),
                IconButton(visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 30, height: 32), onPressed: () => gecko.call(t.loading ? 'stop' : 'reload', {'id': t.nid}), icon: Icon(t.loading ? Icons.close : Icons.refresh, size: 18)),
              ],
            ]),
            ]),
          ),
        ),
        _topButton(app.barSlot(1)),
        _topButton(app.barSlot(2)),
        _topButton(app.barSlot(3)),
        // the main menu must always stay reachable, even if none of the three buttons was set to it
        if (!app.barHas('menu')) _barBtn(Icons.settings_outlined, _openMenu, size: 21),
      ]),
    );
  }

  // ---------------- iOS (Safari) bottom chrome ----------------
  Widget _iosIcon(IconData i, VoidCallback? f, {Widget? child}) {
    final cs = _cs();
    final on = f != null;
    return Expanded(
      child: InkResponse(
        onTap: f, radius: 26, containedInkWell: false,
        child: SizedBox(height: 44, child: Center(child: child ?? Icon(i, size: 26, color: on ? cs.primary : cs.onSurface.withValues(alpha: .30)))),
      ),
    );
  }

  Widget _iosTabsIcon() {
    final cs = _cs();
    return Container(
      width: 24, height: 24, alignment: Alignment.center,
      decoration: BoxDecoration(border: Border.all(color: cs.primary, width: 1.8), borderRadius: BorderRadius.circular(6)),
      child: Text('${tabs.length}', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: cs.primary, height: 1)),
    );
  }

  Widget _iosAddressPill() {
    final t = current;
    final cs = _cs();
    final dark = Theme.of(context).brightness == Brightness.dark;
    final fill = dark ? const Color(0x3D767680) : const Color(0x1F767680);
    final web = t.started && !t.showHome;
    var host = web ? hostOf(t.url) : '';
    if (host.startsWith('www.')) host = host.substring(4);
    final label = t.showHome || host.isEmpty ? tr('جست‌وجو یا وارد کردن آدرس', 'Search or enter website name') : host;
    final lock = t.failed ? Icons.warning_amber_rounded : (t.secure ? Icons.lock : Icons.lock_open);
    final lockColor = t.failed ? Colors.orange : (t.secure ? cs.onSurface.withValues(alpha: .55) : Colors.redAccent);
    final progress = t.loading && t.progress > 0 && t.progress < 1 ? t.progress : 0.0;
    return Container(
      height: 40,
      decoration: BoxDecoration(color: fill, borderRadius: BorderRadius.circular(12), border: t.private ? Border.all(color: const Color(0xFF8B5CF6), width: 1.4) : null),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(children: [
          if (progress > 0)
            Positioned.fill(child: Directionality(textDirection: TextDirection.ltr, child: Align(alignment: Alignment.centerLeft, child: FractionallySizedBox(widthFactor: progress, heightFactor: 1, child: ColoredBox(color: cs.primary.withValues(alpha: .20)))))),
          Row(children: [
            // gear (was "aA"): opens the main menu; long press = site info
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: _openMenu, onLongPress: t.showHome ? null : _siteInfo,
              child: SizedBox(width: 44, height: 42, child: Center(child: Icon(Icons.settings_outlined, size: 21, color: cs.onSurface))),
            ),
            Expanded(
              child: Stack(alignment: Alignment.center, children: [
                Opacity(
                  opacity: editing ? 1 : 0,
                  // Fills the whole 40 px pill and centres the line itself: the old 11 px vertical padding made the field
                  // taller than the pill, so the clipped pill showed only half of the typed text.
                  child: SizedBox(
                    height: 40,
                    child: TextField(
                      controller: addr, focusNode: addrFocus, textDirection: TextDirection.ltr, textInputAction: TextInputAction.go,
                      keyboardType: TextInputType.url, autocorrect: false, enableSuggestions: false,
                      expands: true, maxLines: null, minLines: null, textAlignVertical: TextAlignVertical.center,
                      style: const TextStyle(fontSize: 16, height: 1.25),
                      onChanged: _onAddrChanged, onSubmitted: (v) => navigate(current, v),
                      decoration: InputDecoration(border: InputBorder.none, isCollapsed: true, hintText: tr('جست‌وجو یا وارد کردن آدرس', 'Search or enter website name'), contentPadding: EdgeInsets.zero),
                    ),
                  ),
                ),
                if (!editing)
                  IgnorePointer(child: Row(mainAxisSize: MainAxisSize.min, children: [
                    if (web) ...[Icon(lock, size: 12, color: lockColor), const SizedBox(width: 4)],
                    Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr, style: TextStyle(fontSize: 16, color: web ? cs.onSurface : cs.onSurface.withValues(alpha: .5)))),
                  ])),
                if (_urlTapMode(t)) Positioned.fill(child: _urlTapCatcher()),
              ]),
            ),
            if (editing && addr.text.isNotEmpty)
              GestureDetector(
                behavior: HitTestBehavior.opaque, onTap: () { addr.clear(); _onAddrChanged(''); },
                child: SizedBox(width: 40, height: 42, child: Icon(Icons.cancel, size: 18, color: cs.onSurface.withValues(alpha: .45))),
              )
            else if (!editing && web)
              GestureDetector(
                behavior: HitTestBehavior.opaque, onTap: () => gecko.call(t.loading ? 'stop' : 'reload', {'id': t.nid}),
                child: SizedBox(width: 44, height: 42, child: Icon(t.loading ? Icons.close_rounded : Icons.refresh_rounded, size: 20, color: cs.onSurface)),
              )
            else
              const SizedBox(width: 12),
          ]),
        ]),
      ),
    );
  }

  Widget _iosTopBar() {
    final cs = _cs();
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 2, 10, 4),
      child: Row(children: [
        Expanded(child: _iosAddressPill()),
        if (editing || _suggHold)
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: _closeAddr,
            child: Padding(padding: const EdgeInsets.only(left: 12), child: Text(tr('انصراف', 'Cancel'), style: TextStyle(fontSize: 17, color: cs.primary))),
          )
        else ...[
          _topButton(app.barSlot(1)),
          _topButton(app.barSlot(2)),
          _topButton(app.barSlot(3)),
        ],
      ]),
    );
  }

  Widget _iosBottomChrome() {
    final t = current;
    final cs = _cs();
    final bar = _barBase();
    final sep = Theme.of(context).dividerColor;
    final page = t.started && !t.showHome;
    final web = page && t.url.startsWith('http');
    final vpnMode = app.barHas('vpn');
    return Container(
      decoration: BoxDecoration(color: bar, border: Border(top: BorderSide(color: sep, width: .5))),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        if (!editing && !_suggHold)
          Padding(
            padding: const EdgeInsets.fromLTRB(6, 4, 6, 2),
            child: Row(children: [
              _iosIcon(Icons.arrow_back_ios_new_rounded, page && t.canBack ? () => gecko.call('back', {'id': t.nid}) : null, child: Icon(Icons.arrow_back_ios_new_rounded, size: 22, color: page && t.canBack ? cs.primary : cs.onSurface.withValues(alpha: .30))),
              _iosIcon(Icons.arrow_forward_ios_rounded, page && t.canForward ? () => gecko.call('forward', {'id': t.nid}) : null, child: Icon(Icons.arrow_forward_ios_rounded, size: 22, color: page && t.canForward ? cs.primary : cs.onSurface.withValues(alpha: .30))),
              _iosIcon(Icons.ios_share_rounded, web ? () => Share.share(t.url) : null),
              if (vpnMode) Expanded(child: Center(child: _vpnButton())) else _iosIcon(Icons.menu_book_outlined, _openBookmarks),
              if (app.flag('dnsBtn')) Expanded(child: Center(child: _dnsButton())),
              _iosIcon(Icons.layers_outlined, _openSwitcher, child: _iosTabsIcon()),
            ]),
          )
        else
          const SizedBox.shrink(),
      ]),
    );
  }

  Color? _cssColor(String? c) {
    if (c == null) return null;
    var h = c.trim();
    if (!h.startsWith('#')) return null;
    h = h.substring(1);
    if (h.length == 3) h = h.split('').map((x) => '$x$x').join();
    if (h.length != 6) return null;
    final v = int.tryParse(h, radix: 16);
    return v == null ? null : Color(0xFF000000 | v);
  }

  Widget _progressBar() {
    final t = current;
    return SizedBox(height: 2, child: t.loading && t.progress > 0 && t.progress < 1 ? Directionality(textDirection: TextDirection.ltr, child: LinearProgressIndicator(value: t.progress, minHeight: 2)) : null);
  }

  // ---------------- Chrome-style address popup (Copy / Edit) ----------------
  /// A loaded page: tapping its address shows the Copy / Edit popup. On the home page / an empty tab it types directly.
  bool _urlTapMode(BrowserTab t) => !editing && !t.showHome && t.started && t.url.isNotEmpty;

  Widget _urlTapCatcher() => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: () => setState(() => _urlMenu = !_urlMenu),
        child: const SizedBox.expand(),
      );

  void _copyUrl() {
    final u = current.url;
    setState(() => _urlMenu = false);
    if (u.isEmpty) return;
    Clipboard.setData(ClipboardData(text: u));
    toast(tr('لینک کپی شد', 'Link copied'));
  }

  void _editUrl() {
    setState(() => _urlMenu = false);
    addrFocus.requestFocus(); // the focus listener selects the whole address; the ✕ button clears it
  }

  Widget _urlMenuPopup() {
    final cs = Theme.of(context).colorScheme;
    Widget btn(IconData i, String label, VoidCallback f) => InkWell(
          onTap: f, borderRadius: BorderRadius.circular(22),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 11),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(i, size: 20, color: cs.primary),
              const SizedBox(width: 8),
              Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
            ]),
          ),
        );
    return Positioned.fill(
      child: Stack(children: [
        // tap anywhere else to dismiss
        Positioned.fill(child: GestureDetector(behavior: HitTestBehavior.opaque, onTap: () => setState(() => _urlMenu = false), child: const SizedBox.expand())),
        Align(
          alignment: Alignment.topCenter,
          child: Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Material(
              elevation: 8, color: cs.surfaceContainerHigh, shape: const StadiumBorder(),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                btn(Icons.content_copy_rounded, tr('کپی', 'Copy'), _copyUrl),
                Container(width: 1, height: 22, color: cs.outlineVariant),
                btn(Icons.edit_rounded, tr('ویرایش', 'Edit'), _editUrl),
              ]),
            ),
          ),
        ),
      ]),
    );
  }

  // ---------------- suggestions ----------------
  void _onAddrChanged(String v) {
    _sugT?.cancel();
    setState(() {});
    if (v.trim().isEmpty) { setState(() => sugg = []); return; }
    _sugT = Timer(const Duration(milliseconds: 180), () async {
      final q = v.trim().toLowerCase();
      final local = <Suggestion>[];
      for (final b in app.bookmarks) {
        if (local.length >= 3) break;
        if (b.url.toLowerCase().contains(q) || b.title.toLowerCase().contains(q)) local.add(Suggestion('bookmark', b.title, b.url));
      }
      for (final h in app.history) {
        if (local.length >= 6) break;
        if ((h.url.toLowerCase().contains(q) || h.title.toLowerCase().contains(q)) && !local.any((x) => x.url == h.url)) local.add(Suggestion('history', h.title, h.url));
      }
      if (!mounted) return;
      setState(() => sugg = [Suggestion('search', v.trim(), v.trim()), ...local]);
      final se = engines[app.str('engine')]!;
      if (app.flag('suggest') && !current.private && se.suggest.isNotEmpty) {
        try {
          final r = await _dio.get<String>(se.suggest.replaceFirst('%s', Uri.encodeComponent(v)), options: Options(responseType: ResponseType.plain, receiveTimeout: const Duration(seconds: 2), sendTimeout: const Duration(seconds: 2)));
          final j = jsonDecode(r.data ?? '[]');
          if (j is List && j.length > 1 && j[1] is List && mounted && addr.text == v) {
            final web = (j[1] as List).take(5).map((e) => Suggestion('web', '$e', '$e')).toList();
            setState(() => sugg = [sugg.first, ...web, ...sugg.skip(1)]);
          }
        } catch (_) {}
      }
    });
  }

  Widget _suggestionsPanel() => Positioned.fill(
        child: GlassBackground(child: Material(
          type: MaterialType.transparency,
          child: sugg.isEmpty
              ? const SizedBox()
              : ListView.builder(
                  keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag, itemCount: sugg.length,
                  itemBuilder: (_, i) {
                    final s = sugg[i];
                    final icon = {'search': Icons.search, 'web': Icons.search, 'history': Icons.history, 'bookmark': Icons.star_border}[s.type]!;
                    return ListTile(
                      dense: true, leading: Icon(icon, size: 20),
                      title: Text(s.type == 'search' ? s.title : s.title.isEmpty ? s.url : s.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: s.type == 'history' || s.type == 'bookmark' ? Text(s.url, maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr) : null,
                      trailing: IconButton(icon: const Icon(Icons.north_west, size: 16), onPressed: () { addr.text = s.url; addr.selection = TextSelection.collapsed(offset: addr.text.length); _onAddrChanged(addr.text); }),
                      onTap: () => navigate(current, s.url),
                    );
                  },
                ),
        )),
      );

  // ---------------- find in page ----------------
  void _closeFind() {
    gecko.call('findClear', {'id': current.nid});
    setState(() { finding = false; findCount = 0; findIdx = 0; });
    findCtl.clear();
  }

  Widget _findBar() => Glass(
        radius: 18, margin: const EdgeInsets.fromLTRB(8, 4, 8, 6),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Row(children: [
            Expanded(child: TextField(controller: findCtl, autofocus: true, decoration: InputDecoration(hintText: tr('جست‌وجو در صفحه', 'Find in page'), border: InputBorder.none), onChanged: (v) => v.isEmpty ? gecko.call('findClear', {'id': current.nid}) : gecko.call('find', {'id': current.nid, 'text': v, 'backwards': false}))),
            Text(findCount == 0 ? '0' : '$findIdx/$findCount', style: const TextStyle(fontSize: 12)),
            IconButton(onPressed: () => gecko.call('find', {'id': current.nid, 'text': findCtl.text, 'backwards': true}), icon: const Icon(Icons.keyboard_arrow_up)),
            IconButton(onPressed: () => gecko.call('find', {'id': current.nid, 'text': findCtl.text, 'backwards': false}), icon: const Icon(Icons.keyboard_arrow_down)),
            IconButton(onPressed: _closeFind, icon: const Icon(Icons.close)),
          ]),
        ),
      );

  // ---------------- home / error ----------------
  Widget _home(BrowserTab t) {
    final cs = _cs();
    if (t.private) {
      Widget row(IconData i, String s) => Container(
            margin: const EdgeInsets.only(top: 10), padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(14)),
            child: Row(children: [Icon(i, color: const Color(0xFFB794F6)), const SizedBox(width: 12), Expanded(child: Text(s))]),
          );
      return GlassBackground(child: Padding(
        padding: const EdgeInsets.all(24),
        child: ListView(children: [
          const SizedBox(height: 30),
          const Icon(Icons.visibility_off, size: 72, color: Color(0xFFB794F6)),
          const SizedBox(height: 14),
          Center(child: Text(tr('حالت ناشناس', 'Private mode'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
          const SizedBox(height: 10),
          Text(tr('هیچ تاریخچه‌ای ذخیره نمی‌شود و کوکی‌های ساخته‌شده در این نشست هنگام بستن تب پاک می‌شوند.', 'No history is saved, and cookies created in this session are removed when the tab closes.'), textAlign: TextAlign.center),
          const SizedBox(height: 18),
          row(Icons.history_toggle_off, tr('عدم ذخیرهٔ تاریخچه', 'No history saved')),
          row(Icons.cookie_outlined, tr('پاک‌سازی کوکی‌های نشست', 'Session cookies cleared')),
          row(Icons.gpp_good_outlined, tr('محافظت در برابر ردیاب‌ها', 'Tracker protection')),
        ]),
      ));
    }
    Widget tile(IconData i, String s, VoidCallback f) => ListTile(dense: true, leading: Icon(i, color: cs.primary), title: Text(s), onTap: f);
    final mv = app.mostVisited(4);
    return GlassBackground(
      child: ListView(padding: const EdgeInsets.fromLTRB(16, 20, 16, 30), children: [
        Center(child: _mapsIcon(64)),
        const SizedBox(height: 8),
        Center(child: Text('آبتین', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: cs.onSurface))),
        const SizedBox(height: 16),
        InkWell(
          onTap: () => addrFocus.requestFocus(), borderRadius: BorderRadius.circular(26),
          child: Glass(
            radius: 26, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(children: [const Icon(Icons.search), const SizedBox(width: 10), Text('${tr('جست‌وجو در', 'Search with')} ${engines[app.str('engine')]!.name}', style: TextStyle(color: cs.onSurface.withValues(alpha: .6)))]),
          ),
        ),
        const SizedBox(height: 20),
        GridView.count(
          crossAxisCount: 4, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), childAspectRatio: .85,
          children: [
            for (var i = 0; i < app.dials.length; i++) _dial(app.dials[i], i),
            InkWell(onTap: _addDialDialog, child: Column(children: [
              Container(width: 52, height: 52, decoration: BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.add)),
              const SizedBox(height: 6), Text(tr('افزودن', 'Add'), style: const TextStyle(fontSize: 12)),
            ])),
          ],
        ),
        if (mv.isNotEmpty) ...[
          Padding(padding: const EdgeInsets.only(top: 12, bottom: 4), child: Text(tr('پربازدیدها', 'Most visited'), style: const TextStyle(fontWeight: FontWeight.bold))),
          for (final h in mv) ListTile(dense: true, leading: _siteIcon(h.url, hostOf(h.url), 30), title: Text(h.title, maxLines: 1, overflow: TextOverflow.ellipsis), subtitle: Text(hostOf(h.url), maxLines: 1), onTap: () => navigate(t, h.url)),
        ],
        const SizedBox(height: 12),
        GlassCard(margin: EdgeInsets.zero, child: Column(children: [
          tile(Icons.star_border, tr('نشانک‌ها', 'Bookmarks'), _openBookmarks),
          tile(Icons.history, tr('تاریخچه', 'History'), _openHistory),
          tile(Icons.download_outlined, tr('دانلودها', 'Downloads'), _openDownloads),
          tile(Icons.extension_outlined, tr('افزونه‌ها', 'Extensions'), _openExtensions),
          tile(Icons.settings_outlined, tr('تنظیمات', 'Settings'), _openSettings),
        ])),
      ]),
    );
  }

  Widget _dial(SpeedDial d, int i) => InkWell(
        onTap: () => navigate(current, d.url),
        onLongPress: () async {
          final del = await _ask(tr('حذف میان‌بر؟', 'Remove shortcut?'), d.title);
          if (del) { setState(() => app.dials.removeAt(i)); app.saveDials(); }
        },
        child: Column(children: [
          _siteIcon(d.url, d.title, 52),
          const SizedBox(height: 6), Text(d.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
        ]),
      );

  Future<void> _addDialDialog({String? title, String? url}) async {
    final t = TextEditingController(text: title), u = TextEditingController(text: url);
    final ok = await showGlassDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('افزودن میان‌بر', 'Add shortcut')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: t, decoration: InputDecoration(labelText: tr('عنوان', 'Title'))),
          TextField(controller: u, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'URL')),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('افزودن', 'Add')))],
      ),
    );
    if (ok == true && u.text.trim().isNotEmpty) {
      var url2 = u.text.trim();
      if (!url2.contains('://')) url2 = 'https://$url2';
      setState(() => app.dials.add(SpeedDial(t.text.trim().isEmpty ? hostOf(url2) : t.text.trim(), url2)));
      app.saveDials();
    }
  }
}
