import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart' hide Icon;

import '../widgets/app_icon.dart';

import 'package:flutter/foundation.dart' show listEquals;
import 'package:flutter/services.dart';

import '../services/saf.dart';
import '../services/file_ops.dart';
import 'saf_prompt.dart';

import 'package:path/path.dart' as p;

import '../core/l10n.dart';
import '../services/highlighter.dart';
import '../services/code_assist.dart';
import '../services/web_preview.dart';
import '../services/code_runner.dart';
import '../services/run_session.dart';
import '../widgets/run_panel.dart';
import '../core/layouts.dart' show tr2;
import '../widgets/ui.dart';
import '../widgets/abtin_global_rail.dart' show abtinPageRoute;
import 'package:path_provider/path_provider.dart';
import '../services/remote/remote_edit.dart';
import '../services/remote/remote_factory.dart';
import '../services/remote/remote_fs.dart';
import 'remote_screen.dart';
import 'hash_screen.dart';
import 'hex_viewer_screen.dart';
import 'viewer_delete.dart';
import '../services/term_tab.dart';
import '../widgets/editor_term_panel.dart';
import '../services/debug_session.dart';
import '../widgets/code_gutter.dart';
import '../widgets/debug_view.dart';
import '../widgets/debug_widgets.dart';
import '../widgets/explorer_view.dart';
import '../widgets/side_panel.dart';

/// Text / code file: opens in VIEW mode (read-only, selectable, syntax highlighted).
/// The edit button switches to edit mode; save returns to view mode.
class TextEditorScreen extends StatefulWidget {
  /// Local file. For a server file this is the local cache copy of [remote].
  final String path;

  /// Set when the text belongs to a file on an FTP / SFTP / ... server: saving uploads it.
  final RemoteDoc? remote;
  const TextEditorScreen({super.key, required this.path, this.remote});
  @override
  State<TextEditorScreen> createState() => _TextEditorScreenState();

  /// Downloads a server file (progress dialog) and opens it in the editor.
  /// [fs] = an already connected session (the server browser's); without it a
  /// new connection is made. [replace] swaps the current screen instead of stacking.
  static Future<void> openRemote(
    BuildContext c,
    RemoteProfile profile,
    String remotePath, {
    RemoteFs? fs,
    int? size,
    bool replace = false,
  }) async {
    if (size != null && size > RemoteDoc.maxEditBytes) {
      final go = await confirm(
        c,
        tr2('این فایل بزرگ است (${FileOps.fmt(size)}) و ویرایشگر ممکن است کند شود. ادامه می‌دهید؟',
            'This file is large (${FileOps.fmt(size)}); the editor may be slow. Continue?'),
      );
      if (!go || !c.mounted) return;
    }
    final tmp = await getTemporaryDirectory();
    final doc = RemoteDoc(profile: profile, remotePath: remotePath, cacheRoot: tmp.path, fs: fs);
    if (!c.mounted) {
      await doc.dispose();
      return;
    }
    final ok = await busyProgress(
      c,
      tr2('در حال دریافت از سرور…', 'Downloading from the server…'),
      (report) => doc.fetch(onProgress: (d, t) => report(t > 0 ? (d / t).clamp(0.0, 1.0).toDouble() : null)),
    );
    if (!ok || !c.mounted) {
      await doc.dispose();
      return;
    }
    final route = abtinPageRoute<void>(
      (_) => TextEditorScreen(path: doc.cachePath, remote: doc),
      hideRail: true,
    );
    if (replace) {
      await Navigator.pushReplacement<void, void>(c, route);
    } else {
      await Navigator.push<void>(c, route);
    }
  }
}

class _TextEditorScreenState extends State<TextEditorScreen> {
  static const int _historyLimit = 80;
  static const int _historyBudget = 2 * 1024 * 1024;

  late final CodeController ctl = CodeController(lang: Hl.langOf(_path));
  final FocusNode focus = FocusNode();
  bool loaded = false, dirty = false, editing = false;
  double font = 14;
  int indentWidth = 4;
  String _savedText = '';
  TextEditingValue _lastStableValue = TextEditingValue.empty;
  final List<TextEditingValue> _undo = [];
  final List<TextEditingValue> _redo = [];
  int _undoBytes = 0, _redoBytes = 0;
  bool _applyingHistory = false;
  List<String> _sugg = const [];
  RunSession? _run;
  final TextEditingController _runArgs = TextEditingController();
  bool _runOpen = false, _runBig = false;
  // VS Code style bottom panel: the Run tab + terminal tabs share one panel.
  TermTabs? _terms;
  bool _runTab = false;
  Timer? _suggTimer;
  bool _uploading = false;
  final ValueNotifier<double?> _upProg = ValueNotifier<double?>(null);

  // ---- multi-file editing (tabs), side panel, debugger ----
  late String _path = widget.path;
  late RemoteDoc? _remote = widget.remote;
  final List<_Doc> _docs = [];
  int _cur = 0;
  final BreakpointStore _bps = BreakpointStore();
  final DebugSession _debug = DebugSession();
  bool _debugShown = false, _dbgTab = false;
  bool _sideOpen = false;
  int _sideTab = 0;
  bool? _wrapOverride;
  Timer? _watch;
  bool _checking = false;
  int _tick = 0;
  final ScrollController _vScroll = ScrollController();
  final ScrollController _hScroll = ScrollController();
  static const double _lineMul = 1.45;
  double _lh = 20, _viewH = 400, _cw = 8, _cwFont = -1;
  String? _mText;
  CodeMetrics _mm = const CodeMetrics(1, 0, false);

  @override
  void initState() {
    super.initState();
    ctl.addListener(_onControllerChanged);
    _debug.onStopped = _onDebugStopped;
    _debug.addListener(_rebuild);
    _bps.addListener(_rebuild);
    File(_path)
        .readAsString()
        .then((t) {
          if (!mounted) return;
          ctl.value = TextEditingValue(
            text: t,
            selection: TextSelection.collapsed(offset: t.length),
          );
          _savedText = t;
          _lastStableValue = ctl.value;
          if (ctl.lang.isEmpty) {
            final nl = t.indexOf('\n');
            ctl.lang = Hl.langOfContent(_path, nl < 0 ? t : t.substring(0, nl));
          }
          _docs.add(_Doc(_path, _remote, ctl.value, t, ctl.lang));
          _cur = 0;
          setState(() => loaded = true);
        })
        .catchError((e) {
          if (mounted) {
            snack(context, '$e');
            Navigator.pop(context);
          }
        });
  }

  @override
  void dispose() {
    _suggTimer?.cancel();
    _upProg.dispose();
    if (_docs.isEmpty) {
      final rd = widget.remote;
      if (rd != null) unawaited(rd.dispose());
    }
    for (final d in _docs) {
      final rd = d.remote;
      if (rd != null) unawaited(rd.dispose());
    }
    _watch?.cancel();
    _debug.removeListener(_rebuild);
    _bps.removeListener(_rebuild);
    _debug.dispose();
    _bps.dispose();
    _vScroll.dispose();
    _hScroll.dispose();
    _run?.dispose();
    _terms?.dispose();
    _runArgs.dispose();
    ctl.removeListener(_onControllerChanged);
    ctl.dispose();
    focus.dispose();
    super.dispose();
  }

  void _push(Widget w) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => w));

  Future<void> _openPreview() async {
    // the preview shows the editor's current text, saved or not
    final ok = await WebPreview.open(_path, () => ctl.text);
    if (!ok && mounted) snack(context, tr2('پیش‌نمایش باز نشد', 'Could not open the preview'));
  }

  /// Writes the editor text to disk without leaving edit mode (the runner reads the file).
  Future<bool> _saveQuiet() async {
    final rd = _remote;
    if (rd != null) {
      // server file: only the local cache copy is refreshed (the runner reads it); nothing is uploaded
      try {
        await rd.writeCache(ctl.text);
        return true;
      } catch (e) {
        if (mounted) snack(context, '$e');
        return false;
      }
    }
    if (!await ensureSdAll(context, [_path])) return false;
    try {
      await Saf.writeString(_path, ctl.text);
    } on OpError catch (e) {
      if (mounted) snack(context, L.t(e.key));
      return false;
    }
    if (!mounted) return false;
    _savedText = ctl.text;
    setState(() => dirty = false);
    return true;
  }

  /// Runs the file inside Alpine (proot) and shows the output in the panel below the editor.
  Future<void> _startRun([RunPre pre = RunPre.none]) async {
    final r = CodeRunner.runnerFor(ctl.lang);
    if (r == null) {
      snack(context, tr2('اجرای این زبان پشتیبانی نمی‌شود', 'This language cannot be run'));
      return;
    }
    if (dirty && !await _saveQuiet()) return;
    final session = _run ??= RunSession();
    setState(() {
      _runOpen = true;
      _runTab = true;
      _dbgTab = false;
    });
    await session.run(filePath: _path, runner: r, args: _runArgs.text, pre: pre);
  }

  /// Hides the bottom panel (terminals keep running, like VS Code).
  void _closePanel() {
    setState(() => _runOpen = false);
  }

  /// Closes the Run tab: stops the program and drops the session.
  void _closeRunTab() {
    _run?.stop();
    final old = _run;
    setState(() {
      _run = null;
      _runTab = false;
      if ((_terms == null || _terms!.tabs.isEmpty) && !_debugShown) _runOpen = false;
      if (_debugShown) _dbgTab = true;
    });
    old?.dispose();
  }

  TermTabs _ensureTerms() {
    return _terms ??= TermTabs(
      cwd: p.dirname(_path),
      onEmpty: () {
        if (!mounted) return;
        setState(() {
          if (_run != null) {
            _runTab = true;
          } else if (_debugShown) {
            _dbgTab = true;
          } else {
            _runOpen = false;
          }
        });
      },
    );
  }

  /// Toggles the terminal in the bottom panel (opens a first tab on demand).
  void _openTerminal() {
    final terms = _ensureTerms();
    if (_runOpen && !_runTab && !_dbgTab) {
      focus.requestFocus();
      setState(() => _runOpen = false);
      return;
    }
    if (terms.tabs.isEmpty) terms.add();
    focus.unfocus();
    setState(() {
      _runOpen = true;
      _runTab = false;
      _dbgTab = false;
    });
  }

  void _onControllerChanged() {
    final value = ctl.value;
    if (_applyingHistory || !loaded) return;

    // Do not put intermediate IME composing text on the undo stack. The stable
    // pre-composition value remains the undo target until composition commits.
    if (value.composing.isValid && !value.composing.isCollapsed) {
      if (mounted) setState(() {});
      return;
    }

    if (value.text != _lastStableValue.text) {
      _pushHistory(_undo, value: _lastStableValue, isUndo: true);
      _clearHistory(_redo, isUndo: false);
    }
    _lastStableValue = value;
    dirty = value.text != _savedText;
    _scheduleSuggest();
    // Selection-only changes move the status-bar caret as well.
    if (mounted) setState(() {});
  }

  void _scheduleSuggest() {
    _suggTimer?.cancel();
    if (!editing || ctl.lang.isEmpty) {
      if (_sugg.isNotEmpty) _sugg = const [];
      return;
    }
    _suggTimer = Timer(const Duration(milliseconds: 90), () {
      if (!mounted) return;
      final sel = ctl.selection;
      final next = (editing && sel.isValid && sel.isCollapsed)
          ? CodeAssist.suggest(ctl.text, sel.extentOffset, ctl.lang)
          : const <String>[];
      if (!listEquals(next, _sugg)) setState(() => _sugg = next);
    });
  }

  void _applySuggestion(String word) {
    final sel = ctl.selection;
    if (!sel.isValid || !sel.isCollapsed) return;
    final text = ctl.text;
    final caret = sel.extentOffset.clamp(0, text.length).toInt();
    final start = CodeAssist.wordStart(text, caret);
    ctl.value = ctl.value.copyWith(
      text: text.replaceRange(start, caret, word),
      selection: TextSelection.collapsed(offset: start + word.length),
      composing: TextRange.empty,
    );
    focus.requestFocus();
  }

  void _insertText(String s) {
    final sel = ctl.selection;
    final text = ctl.text;
    final a = sel.isValid ? sel.start.clamp(0, text.length).toInt() : text.length;
    final b = sel.isValid ? sel.end.clamp(0, text.length).toInt() : text.length;
    ctl.value = ctl.value.copyWith(
      text: text.replaceRange(a, b, s),
      selection: TextSelection.collapsed(offset: a + s.length),
      composing: TextRange.empty,
    );
    focus.requestFocus();
  }

  /// Inserts an open/close pair; wraps the selection when there is one.
  void _insertPair(String open, String close) {
    final sel = ctl.selection;
    final text = ctl.text;
    final a = sel.isValid ? sel.start.clamp(0, text.length).toInt() : text.length;
    final b = sel.isValid ? sel.end.clamp(0, text.length).toInt() : text.length;
    final inner = text.substring(a, b);
    ctl.value = ctl.value.copyWith(
      text: text.replaceRange(a, b, '$open$inner$close'),
      selection: TextSelection.collapsed(offset: inner.isEmpty ? a + open.length : a + open.length + inner.length + close.length),
      composing: TextRange.empty,
    );
    focus.requestFocus();
  }

  void _toggleComment() {
    if (!editing) return;
    final sel = ctl.selection;
    final r = CodeAssist.toggleComment(
      ctl.text,
      sel.isValid ? sel.start : ctl.text.length,
      sel.isValid ? sel.end : ctl.text.length,
      ctl.lang,
    );
    if (r == null) return;
    ctl.value = ctl.value.copyWith(
      text: r.text,
      selection: TextSelection(baseOffset: r.start, extentOffset: r.end),
      composing: TextRange.empty,
    );
    focus.requestFocus();
  }

  int _valueBytes(TextEditingValue v) => v.text.length * 2;

  String _spaces(int count) => List<String>.filled(count, ' ').join();

  void _pushHistory(
    List<TextEditingValue> stack, {
    required TextEditingValue value,
    required bool isUndo,
  }) {
    final bytes = _valueBytes(value);
    if (bytes > _historyBudget) {
      _clearHistory(stack, isUndo: isUndo);
      return;
    }
    final currentBytes = isUndo ? _undoBytes : _redoBytes;
    var total = currentBytes;
    while (stack.isNotEmpty &&
        (stack.length >= _historyLimit || total + bytes > _historyBudget)) {
      total -= _valueBytes(stack.removeAt(0));
    }
    stack.add(value);
    total += bytes;
    if (isUndo) {
      _undoBytes = total;
    } else {
      _redoBytes = total;
    }
  }

  void _clearHistory(List<TextEditingValue> stack, {required bool isUndo}) {
    stack.clear();
    if (isUndo) {
      _undoBytes = 0;
    } else {
      _redoBytes = 0;
    }
  }

  void _applyHistory(TextEditingValue value) {
    _applyingHistory = true;
    ctl.value = value.copyWith(composing: TextRange.empty);
    _applyingHistory = false;
    _lastStableValue = ctl.value;
    dirty = ctl.text != _savedText;
    setState(() {});
  }

  void _undoEdit() {
    if (!editing || _undo.isEmpty) return;
    final target = _undo.removeLast();
    _undoBytes -= _valueBytes(target);
    _pushHistory(_redo, value: ctl.value, isUndo: false);
    _applyHistory(target);
  }

  void _redoEdit() {
    if (!editing || _redo.isEmpty) return;
    final target = _redo.removeLast();
    _redoBytes -= _valueBytes(target);
    _pushHistory(_undo, value: ctl.value, isUndo: true);
    _applyHistory(target);
  }

  void _startEdit() {
    setState(() => editing = true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) focus.requestFocus();
    });
  }

  void _stopEdit() {
    focus.unfocus();
    _suggTimer?.cancel();
    setState(() {
      editing = false;
      _sugg = const [];
    });
  }

  /// Server file: cache copy -> check nobody changed it meanwhile -> upload.
  /// On any failure the editor stays in edit mode with the text still marked unsaved.
  Future<void> _saveRemote(RemoteDoc rd) async {
    if (_uploading) return;
    final text = ctl.text;
    setState(() => _uploading = true);
    _upProg.value = null;
    var saved = false;
    try {
      await rd.writeCache(text);
      if (await rd.changedRemotely()) {
        if (!mounted) return;
        final overwrite = await confirm(
          context,
          tr2('این فایل بعد از باز شدن روی سرور تغییر کرده است. با ذخیره‌کردن، نسخهٔ سرور بازنویسی می‌شود. ادامه می‌دهید؟',
              'This file changed on the server after you opened it. Saving will overwrite the server version. Continue?'),
        );
        if (!overwrite) return;
      }
      await rd.push(onProgress: (d, t) => _upProg.value = t > 0 ? (d / t).clamp(0.0, 1.0).toDouble() : null);
      saved = true;
    } catch (e) {
      if (mounted) snack(context, '${L.t('error')}: $e');
    } finally {
      if (mounted) {
        setState(() {
          _uploading = false;
          if (saved) {
            _savedText = text;
            dirty = ctl.text != text;
            if (!dirty) editing = false;
          }
        });
        if (saved) {
          focus.unfocus();
          snack(context, tr2('روی سرور ذخیره شد', 'Saved to the server'));
        }
      }
    }
  }

  /// Throws away the editor text and downloads the server version again.
  Future<void> _reloadRemote() async {
    final rd = _remote;
    if (rd == null || _uploading) return;
    if (dirty && !await confirm(context, L.t('discard'))) return;
    if (!mounted) return;
    final ok = await busyProgress(
      context,
      tr2('در حال دریافت از سرور…', 'Downloading from the server…'),
      (report) => rd.fetch(onProgress: (d, t) => report(t > 0 ? (d / t).clamp(0.0, 1.0).toDouble() : null)),
    );
    if (!ok || !mounted) return;
    try {
      final t = await File(_path).readAsString();
      if (!mounted) return;
      _applyingHistory = true;
      ctl.value = TextEditingValue(text: t, selection: const TextSelection.collapsed(offset: 0));
      _applyingHistory = false;
      _savedText = t;
      _lastStableValue = ctl.value;
      _clearHistory(_undo, isUndo: true);
      _clearHistory(_redo, isUndo: false);
      setState(() => dirty = false);
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  /// Menu: pick a file on a saved server and open it here (replaces this screen).
  Future<void> _openFromServer() async {
    if (_uploading) return;
    if (dirty && !await confirm(context, L.t('discard'))) return;
    if (!mounted) return;
    final pick = await Navigator.push<RemotePick>(
      context,
      MaterialPageRoute(builder: (_) => const RemoteScreen(pick: RemotePickMode.file)),
    );
    if (pick == null || !mounted) return;
    await TextEditorScreen.openRemote(context, pick.profile, pick.path, replace: true);
  }

  /// Menu: upload the current editor text as a NEW file (or over a file) in a server folder.
  Future<void> _saveCopyToServer() async {
    if (_uploading) return;
    final pick = await Navigator.push<RemotePick>(
      context,
      MaterialPageRoute(builder: (_) => const RemoteScreen(pick: RemotePickMode.folder)),
    );
    if (pick == null || !mounted) return;
    final name = await promptText(
      context,
      tr2('نام فایل روی سرور', 'File name on the server'),
      initial: _remote?.name ?? p.basename(_path),
    );
    if (name == null || name.isEmpty || !mounted) return;
    if (name.contains('/') || name.contains('\\')) {
      snack(context, tr2('نام نامعتبر است', 'Invalid name'));
      return;
    }
    final text = ctl.text;
    final fs = createRemote(pick.profile);
    File? tmpFile;
    try {
      var exists = false;
      var ok = await busy(context, () async {
        await fs.connect();
        exists = (await fs.list(pick.path)).any((e) => e.name == name);
      });
      if (!ok || !mounted) return;
      if (exists &&
          !await confirm(
            context,
            tr2('فایلی با این نام روی سرور هست. بازنویسی شود؟', 'A file with this name already exists on the server. Overwrite it?'),
          )) {
        return;
      }
      if (!mounted) return;
      final tmp = await getTemporaryDirectory();
      final dir = await Directory(p.join(tmp.path, 'remote_edit')).create(recursive: true);
      tmpFile = File(p.join(dir.path, 'copy_${DateTime.now().microsecondsSinceEpoch}_$name'));
      await tmpFile.writeAsString(text, flush: true);
      final up = tmpFile;
      if (!mounted) return;
      ok = await busyProgress(
        context,
        tr2('در حال ارسال به سرور…', 'Uploading to the server…'),
        (report) => fs.upload(up.path, RPath.join(pick.path, name),
            onProgress: (d, t) => report(t > 0 ? (d / t).clamp(0.0, 1.0).toDouble() : null)),
      );
      if (ok && mounted) snack(context, tr2('روی سرور ذخیره شد', 'Saved to the server'));
    } finally {
      try {
        await fs.close();
      } catch (_) {}
      try {
        await tmpFile?.delete();
      } catch (_) {}
    }
  }

  Future<void> _save() async {
    final rd = _remote;
    if (rd != null) return _saveRemote(rd);
    if (!await ensureSdAll(context, [_path])) return;
    try {
      await Saf.writeString(_path, ctl.text);
    } on OpError catch (e) {
      if (mounted) snack(context, L.t(e.key));
      return;
    }
    if (!mounted) return;
    _savedText = ctl.text;
    setState(() {
      dirty = false;
      editing = false;
    });
    focus.unfocus();
    snack(context, L.t('done'));
  }


  void _rebuild() {
    if (mounted) setState(() {});
    _syncWatch();
  }

  // ---------- Claude Code (runs in the app terminal with the user's own login) ----------
  static const _claudeCmd =
      r'{ [ -f "$PREFIX/termux/.abtin-termux" ] || termux setup -y; } && '
      r'{ [ -e "$PREFIX/termux/files/usr/bin/npm" ] || _termux_run pkg install -y nodejs; } && '
      r'{ [ -e "$PREFIX/termux/files/usr/bin/claude" ] || { echo "Installing Claude Code (needs internet)..."; _termux_run npm install -g @anthropic-ai/claude-code; }; } && '
      r'_termux_run claude';

  Future<void> _openClaude() async {
    final terms = _ensureTerms();
    final t = terms.add(cwd: p.dirname(widget.path));
    t.customTitle = 'Claude Code';
    focus.unfocus();
    setState(() {
      _runOpen = true;
      _runTab = false;
      _dbgTab = false;
    });
    await _saveAllQuiet();
    await t.start();
    await t.sendRaw('$_claudeCmd\n');
  }

  /// While a terminal is open (Claude Code edits files on disk) keep the open tabs in sync.
  void _syncWatch() {
    final need = _terms?.tabs.isNotEmpty ?? false;
    if (need && _watch == null) {
      _watch = Timer.periodic(const Duration(seconds: 2), (_) {
        if (_sideOpen && mounted) setState(() => _tick++);
        _checkExternal();
      });
    } else if (!need && _watch != null) {
      _watch!.cancel();
      _watch = null;
    }
  }

  Future<void> _checkExternal() async {
    if (_checking || !mounted || !loaded) return;
    _checking = true;
    try {
      for (var i = 0; i < _docs.length; i++) {
        final path = _pathOf(i);
        if ((i == _cur ? _remote : _docs[i].remote) != null) continue;
        if (i == _cur ? dirty : _docs[i].dirty) continue;
        final f = File(path);
        if (!f.existsSync() || await f.length() > 500 * 1024) continue;
        final t = await f.readAsString();
        if (!mounted || i >= _docs.length || _pathOf(i) != path) return;
        if (i == _cur ? dirty : _docs[i].dirty) continue;
        if (t == (i == _cur ? _savedText : _docs[i].savedText)) continue;
        _reloadDocText(i, t);
      }
    } catch (_) {
      // unreadable / binary file: ignore
    } finally {
      _checking = false;
    }
  }

  void _reloadDocText(int i, String t) {
    if (i == _cur) {
      final off = ctl.selection.baseOffset.clamp(0, t.length).toInt();
      _applyingHistory = true;
      ctl.value = TextEditingValue(text: t, selection: TextSelection.collapsed(offset: off));
      _applyingHistory = false;
      _savedText = t;
      _lastStableValue = ctl.value;
      dirty = false;
      _undo.clear();
      _redo.clear();
      _undoBytes = 0;
      _redoBytes = 0;
    } else {
      final d = _docs[i];
      d.value = TextEditingValue(text: t, selection: const TextSelection.collapsed(offset: 0));
      d.savedText = t;
      d.undo.clear();
      d.redo.clear();
      d.undoBytes = 0;
      d.redoBytes = 0;
    }
    if (mounted) setState(() {});
  }


  String _pathOf(int i) => i == _cur ? _path : _docs[i].path;

  Set<String> _dirtyPaths() {
    final out = <String>{};
    for (var i = 0; i < _docs.length; i++) {
      if (i == _cur ? dirty : _docs[i].dirty) out.add(_pathOf(i));
    }
    return out;
  }

  bool get _anyDirty => _dirtyPaths().isNotEmpty;

  void _stashCurrent() {
    if (_docs.isEmpty || !loaded) return;
    final d = _docs[_cur];
    d.path = _path;
    d.remote = _remote;
    d.value = ctl.value;
    d.savedText = _savedText;
    d.dirty = dirty;
    d.lang = ctl.lang;
    d.undo
      ..clear()
      ..addAll(_undo);
    d.redo
      ..clear()
      ..addAll(_redo);
    d.undoBytes = _undoBytes;
    d.redoBytes = _redoBytes;
    d.scroll = _vScroll.hasClients && _vScroll.positions.length == 1 ? _vScroll.offset : 0;
  }

  void _loadDoc(_Doc d) {
    _path = d.path;
    _remote = d.remote;
    _applyingHistory = true;
    ctl.lang = d.lang;
    ctl.value = d.value;
    _applyingHistory = false;
    _savedText = d.savedText;
    _lastStableValue = ctl.value;
    dirty = d.dirty;
    _undo
      ..clear()
      ..addAll(d.undo);
    _redo
      ..clear()
      ..addAll(d.redo);
    _undoBytes = d.undoBytes;
    _redoBytes = d.redoBytes;
    final off = d.scroll;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_vScroll.hasClients && _vScroll.positions.length == 1) {
        _vScroll.jumpTo(off.clamp(0.0, _vScroll.position.maxScrollExtent).toDouble());
      }
    });
  }

  void _switchTo(int i) {
    if (i == _cur || i < 0 || i >= _docs.length) return;
    _stashCurrent();
    _cur = i;
    _loadDoc(_docs[i]);
    setState(() {});
  }

  /// Opens [path] in a tab (or switches to it) and optionally scrolls to [line].
  Future<void> _openPath(String path, {int? line}) async {
    for (var i = 0; i < _docs.length; i++) {
      if (_pathOf(i) == path) {
        _switchTo(i);
        if (line != null) _scrollToLine(line);
        return;
      }
    }
    try {
      final f = File(path);
      final len = await f.length();
      if (len > 3 * 1024 * 1024 && mounted && !await confirm(context, tr2('این فایل بزرگ است. باز شود؟', 'This file is large. Open it?'))) return;
      final t = await f.readAsString();
      if (!mounted) return;
      var lang = Hl.langOf(path);
      if (lang.isEmpty) {
        final nl = t.indexOf('\n');
        lang = Hl.langOfContent(path, nl < 0 ? t : t.substring(0, nl));
      }
      _stashCurrent();
      final d = _Doc(path, null, TextEditingValue(text: t, selection: const TextSelection.collapsed(offset: 0)), t, lang);
      _docs.add(d);
      _cur = _docs.length - 1;
      _loadDoc(d);
      setState(() {
        if (MediaQuery.of(context).size.width < 720) _sideOpen = false;
      });
      if (line != null) _scrollToLine(line);
    } catch (e) {
      if (mounted) snack(context, tr2('این فایل به‌صورت متن باز نشد', 'Cannot open this file as text') + ': $e');
    }
  }

  void _removeDocAt(int i) {
    if (i < 0 || i >= _docs.length) return;
    final rd = _docs[i].remote;
    if (rd != null) unawaited(rd.dispose());
    _docs.removeAt(i);
    if (_docs.isEmpty) {
      dirty = false;
      Navigator.of(context).pop();
      return;
    }
    if (i == _cur) {
      _cur = math.min(i, _docs.length - 1);
      _loadDoc(_docs[_cur]);
    } else if (i < _cur) {
      _cur--;
    }
    setState(() {});
  }

  Future<void> _closeTab(int i) async {
    final isDirty = i == _cur ? dirty : _docs[i].dirty;
    if (isDirty && !await confirm(context, L.t('discard'))) return;
    if (!mounted) return;
    _removeDocAt(i);
  }

  void _onFsRenamed(String from, String to) {
    for (var i = 0; i < _docs.length; i++) {
      final path = _pathOf(i);
      if (path == from || p.isWithin(from, path)) {
        final np = path == from ? to : p.join(to, p.relative(path, from: from));
        _docs[i].path = np;
        if (i == _cur) _path = np;
      }
    }
    _bps.renamePath(from, to);
    setState(() {});
  }

  void _onFsDeleted(String path) {
    for (var i = _docs.length - 1; i >= 0; i--) {
      final dp = _pathOf(i);
      if (dp == path || p.isWithin(path, dp)) {
        if (i == _cur) dirty = false;
        _removeDocAt(i);
        if (!mounted || _docs.isEmpty) return;
      }
    }
    _bps.removePath(path);
  }

  /// Writes every changed local file (the debugger runs the files on disk).
  Future<bool> _saveAllQuiet() async {
    _stashCurrent();
    for (var i = 0; i < _docs.length; i++) {
      final d = _docs[i];
      if (d.remote != null) continue;
      final text = d.value.text;
      if (text == d.savedText) continue;
      if (!mounted || !await ensureSdAll(context, [d.path])) return false;
      try {
        await Saf.writeString(d.path, text);
      } on OpError catch (e) {
        if (mounted) snack(context, L.t(e.key));
        return false;
      }
      d.savedText = text;
      d.dirty = false;
      if (i == _cur) {
        _savedText = text;
        dirty = false;
      }
    }
    if (mounted) setState(() {});
    return true;
  }

  Future<void> _saveAll() async {
    if (await _saveAllQuiet() && mounted) snack(context, L.t('done'));
  }

  // ---------- debugger ----------
  bool get _canDebug => loaded && _remote == null && DebugSession.supports(ctl.lang);

  Future<void> _startDebug([RunPre pre = RunPre.none]) async {
    if (!_canDebug) {
      snack(context, tr2('دیباگر برای فایل‌های Python و JavaScript کار می‌کند', 'The debugger supports Python and JavaScript files'));
      return;
    }
    if (!await _saveAllQuiet()) return;
    if (!mounted) return;
    setState(() {
      _debugShown = true;
      _runOpen = true;
      _runTab = false;
      _dbgTab = true;
    });
    await _debug.start(filePath: _path, store: _bps, args: _runArgs.text, pre: pre, language: ctl.lang);
  }

  Future<void> _restartDebug() async {
    await _debug.stop();
    if (mounted) await _startDebug();
  }

  void _closeDebugTab() {
    unawaited(_debug.stop());
    setState(() {
      _debugShown = false;
      _dbgTab = false;
      if (_run != null) {
        _runTab = true;
      } else if (_terms == null || _terms!.tabs.isEmpty) {
        _runOpen = false;
      }
    });
  }

  void _onDebugStopped(String file, int line, String reason) {
    if (!mounted) return;
    _goto(file, line);
  }

  Future<void> _goto(String file, int line) async {
    if (file.startsWith('<') || !File(file).existsSync()) return;
    await _openPath(file, line: line);
  }

  void _toggleBp(int line) {
    _bps.toggle(_path, line);
    _debug.breakpointsChanged();
  }

  Future<void> _editCondition(String file, int line) async {
    final old = _bps.of(file)[line] ?? '';
    final c = await promptText(
      context,
      tr2('شرط بریک‌پوینت (خط $line) — خالی = بدون شرط', 'Breakpoint condition (line $line) — empty = always'),
      initial: old,
    );
    if (c == null || !mounted) return;
    if (!_bps.has(file, line)) _bps.toggle(file, line);
    _bps.setCondition(file, line, c);
    _debug.breakpointsChanged();
  }

  void _scrollToLine(int line) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_vScroll.hasClients || _vScroll.positions.length != 1) return;
      final off = _vScroll.offset;
      final top = (line - 1) * _lh;
      if (top >= off && top + _lh <= off + _viewH) return;
      final target = (top - _viewH / 3).clamp(0.0, _vScroll.position.maxScrollExtent).toDouble();
      _vScroll.animateTo(target, duration: const Duration(milliseconds: 220), curve: Curves.easeOut);
    });
  }

  // ---------- editor area (gutter + horizontal scrolling) ----------
  bool get _wrapOn => _wrapOverride ?? ctl.lang.isEmpty;

  CodeMetrics _metrics() {
    final t = ctl.text;
    if (!identical(t, _mText)) {
      _mText = t;
      _mm = CodeMetrics.scan(t);
    }
    return _mm;
  }

  void _ensureCharW() {
    if (_cwFont == font) return;
    final tp = TextPainter(
      text: TextSpan(text: 'MMMMMMMMMM', style: TextStyle(fontFamily: 'monospace', fontSize: font)),
      textDirection: TextDirection.ltr,
    )..layout();
    _cw = tp.width / 10;
    _cwFont = font;
    tp.dispose();
  }

  int? _lineAt(double dy, int lines) {
    final off = _vScroll.hasClients && _vScroll.positions.length == 1 ? _vScroll.offset : 0.0;
    final i = ((dy + off) / _lh).floor();
    return i >= 0 && i < lines ? i + 1 : null;
  }

  Widget _textArea(BuildContext context) {
    final style = TextStyle(fontFamily: 'monospace', fontSize: font, height: _lineMul);
    final strut = StrutStyle(fontFamily: 'monospace', fontSize: font, height: _lineMul, forceStrutHeight: true);
    _lh = font * _lineMul;
    Widget field(EdgeInsets pad) => Focus(
          onKeyEvent: _onKeyEvent,
          child: TextField(
            controller: ctl,
            focusNode: focus,
            readOnly: !editing || _uploading,
            showCursor: editing,
            enableInteractiveSelection: true,
            maxLines: null,
            expands: true,
            textAlignVertical: TextAlignVertical.top,
            scrollController: _vScroll,
            style: style,
            strutStyle: strut,
            inputFormatters: [TextInputFormatter.withFunction(_formatInput)],
            decoration: InputDecoration(border: InputBorder.none, filled: false, contentPadding: pad),
          ),
        );
    if (_wrapOn) return field(const EdgeInsets.all(12));

    final cs = Theme.of(context).colorScheme;
    final m = _metrics();
    _ensureCharW();
    final gw = math.max(46.0, m.lines.toString().length * _cw * .85 + 30);
    final bpMap = _bps.of(_path);
    final unv = _bps.unverified[_path] ?? const <int>{};
    final cf = _debug.paused ? _debug.topFrame : null;
    final execLine = (cf != null && cf.file == _path) ? cf.line : null;
    final exc = _debug.paused && _debug.stopReason == 'exception';
    return LayoutBuilder(
      builder: (context, bc) {
        final viewH = math.max(0.0, bc.maxHeight - 6);
        _viewH = viewH;
        final contentW = math.min(
          math.max(bc.maxWidth - gw, m.maxCols * _cw * (m.wide ? 1.5 : 1.0) + 72),
          200000.0,
        );
        return Directionality(
          textDirection: TextDirection.ltr,
          child: Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Row(
              children: [
                Container(
                  width: gw,
                  height: viewH,
                  decoration: BoxDecoration(border: Border(right: BorderSide(color: cs.outlineVariant.withOpacity(.5)))),
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTapUp: (d) {
                      final l = _lineAt(d.localPosition.dy, m.lines);
                      if (l != null) _toggleBp(l);
                    },
                    onLongPressStart: (d) {
                      final l = _lineAt(d.localPosition.dy, m.lines);
                      if (l != null) _editCondition(_path, l);
                    },
                    child: CustomPaint(
                      size: Size.infinite,
                      painter: GutterPainter(
                        scroll: _vScroll,
                        lines: m.lines,
                        lineHeight: _lh,
                        fontSize: font,
                        breakpoints: bpMap,
                        unverified: unv,
                        current: execLine,
                        numberColor: cs.onSurfaceVariant.withOpacity(.6),
                        currentColor: const Color(0xFFE3B341),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: LineBandPainter(
                              scroll: _vScroll,
                              lineHeight: _lh,
                              line: execLine,
                              color: exc ? const Color(0x33FF5252) : const Color(0x44E3B341),
                            ),
                          ),
                        ),
                      ),
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        controller: _hScroll,
                        child: SizedBox(width: contentW, height: viewH, child: field(const EdgeInsets.symmetric(horizontal: 8))),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ---------- tabs + run/debug buttons ----------
  Widget _editorBar(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final canRun = CodeRunner.supports(ctl.lang);
    Widget btn(IconData i, String tip, VoidCallback f, Color c) => IconButton(
          icon: Icon(i, color: c),
          tooltip: tip,
          visualDensity: VisualDensity.compact,
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(minWidth: 40, minHeight: 38),
          onPressed: f,
        );
    return Container(
      height: 38,
      color: cs.surfaceContainerHighest.withOpacity(.5),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(
          children: [
            Expanded(
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _docs.length,
                itemBuilder: (context, i) {
                  final sel = i == _cur;
                  final d = _docs[i];
                  final name = i == _cur
                      ? (_remote?.name ?? p.basename(_path))
                      : (d.remote?.name ?? p.basename(d.path));
                  final isDirty = i == _cur ? dirty : d.dirty;
                  return InkWell(
                    onTap: () => _switchTo(i),
                    child: Container(
                      padding: const EdgeInsets.only(left: 12, right: 4),
                      decoration: BoxDecoration(
                        color: sel ? cs.surface : null,
                        border: Border(top: BorderSide(color: sel ? cs.primary : Colors.transparent, width: 2)),
                      ),
                      child: Row(
                        children: [
                          ConstrainedBox(
                            constraints: const BoxConstraints(maxWidth: 150),
                            child: Text(
                              name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(fontSize: 13, fontWeight: sel ? FontWeight.w600 : null),
                            ),
                          ),
                          const SizedBox(width: 4),
                          if (isDirty)
                            Container(
                              width: 8,
                              height: 8,
                              decoration: const BoxDecoration(color: Colors.amber, shape: BoxShape.circle),
                            ),
                          InkResponse(
                            onTap: () => _closeTab(i),
                            radius: 14,
                            child: const Padding(padding: EdgeInsets.all(6), child: Icon(Icons.close_rounded, size: 15)),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            if (loaded) btn(Icons.auto_awesome_rounded, tr2('Claude Code (با حساب خودتان)', 'Claude Code (your own login)'), _openClaude, const Color(0xFFD97757)),
            if (canRun) btn(Icons.play_arrow_rounded, tr2('اجرای کد', 'Run'), () => _startRun(), const Color(0xFF39D353)),
            if (_canDebug) btn(Icons.bug_report_rounded, tr2('دیباگ', 'Debug'), () => _startDebug(), const Color(0xFFE5534B)),
            if (loaded && WebPreview.supportsPath(_path))
              btn(Icons.play_circle_outline_rounded, tr2('پیش‌نمایش', 'Preview'), _openPreview, cs.primary),
          ],
        ),
      ),
    );
  }

  Widget _appLeading(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (Navigator.of(context).canPop()) const BackButton(),
          IconButton(
            icon: Icon(_sideOpen ? Icons.menu_open_rounded : Icons.menu_rounded),
            tooltip: tr2('منو (فایل‌ها و دیباگ)', 'Menu (files & debug)'),
            visualDensity: VisualDensity.compact,
            onPressed: () => setState(() => _sideOpen = !_sideOpen),
          ),
        ],
      );

  /// Hamburger side panel (left, like VS Code) on top of / next to the editor.
  Widget _withSide(BuildContext context, BoxConstraints bc, Widget content) {
    final dir = Directionality.of(context);
    final wide = bc.maxWidth >= 720;
    final pw = math.min(310.0, bc.maxWidth * .84);
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Stack(
        children: [
          Positioned.fill(
            left: (wide && _sideOpen) ? pw : 0,
            child: Directionality(textDirection: dir, child: content),
          ),
          if (_sideOpen && !wide)
            Positioned.fill(
              child: GestureDetector(
                onTap: () => setState(() => _sideOpen = false),
                child: const ColoredBox(color: Color(0x66000000)),
              ),
            ),
          AnimatedPositioned(
            duration: const Duration(milliseconds: 180),
            curve: Curves.easeOutCubic,
            left: _sideOpen ? 0 : -pw - 12,
            top: 0,
            bottom: 0,
            width: pw,
            child: SidePanel(
              tab: _sideTab,
              onTab: (i) => setState(() => _sideTab = i),
              onClose: () => setState(() => _sideOpen = false),
              debugActive: _debugShown && _debug.active,
              explorer: ExplorerView(
                root: p.dirname(widget.path),
                activePath: _path,
                dirty: _dirtyPaths(),
                onOpen: (path) => _openPath(path),
                onRenamed: _onFsRenamed,
                onDeleted: _onFsDeleted,
                refreshTick: _tick,
              ),
              debug: DebugView(
                session: _debug,
                bps: _bps,
                canDebug: _canDebug,
                onStart: () => _startDebug(),
                onGoto: _goto,
                onEditCondition: _editCondition,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteThis() async {
    if (await deleteFromViewer(context, _path) && mounted) {
      dirty = false;
      _bps.removePath(_path);
      _removeDocAt(_cur);
    }
  }

  TextEditingValue _formatInput(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    // Let active IME composition and multi-character input (including ordinary
    // paste) pass through untouched.
    if (newValue.composing.isValid && !newValue.composing.isCollapsed)
      return newValue;
    final diff = _textDiff(oldValue, newValue);
    if (diff == null) return newValue;
    final cursor = newValue.selection.isValid
        ? newValue.selection.extentOffset
        : -1;

    if (diff.inserted.isEmpty) {
      // Backspace on an opener that still has its auto-inserted closer: remove both.
      if (diff.removed.length == 1 &&
          newValue.selection.isValid &&
          newValue.selection.isCollapsed &&
          cursor == diff.start &&
          diff.start < newValue.text.length &&
          CodeAssist.deletesPair(
            diff.removed,
            newValue.text[diff.start],
            ctl.lang,
          )) {
        return newValue.copyWith(
          text: newValue.text.replaceRange(diff.start, diff.start + 1, ''),
          selection: TextSelection.collapsed(offset: diff.start),
          composing: TextRange.empty,
        );
      }
      return newValue;
    }

    if (diff.inserted == '\n' && cursor == diff.start + 1) {
      final e = CodeAssist.enter(
        oldValue.text,
        diff.start,
        ctl.lang,
        indentWidth,
        afterFrom: diff.start + diff.removed.length,
      );
      if (e.insert.isNotEmpty) {
        final text = newValue.text.replaceRange(
          diff.start + 1,
          diff.start + 1,
          e.insert,
        );
        return newValue.copyWith(
          text: text,
          selection: TextSelection.collapsed(offset: diff.start + 1 + e.caret),
          composing: TextRange.empty,
        );
      }
    }

    final closeChars = const {')', ']', '}', '"', "'", '`'};
    if (diff.inserted.length == 1 &&
        cursor == diff.start + 1 &&
        newValue.selection.isCollapsed) {
      final typed = diff.inserted;
      if (closeChars.contains(typed) &&
          oldValue.selection.isCollapsed &&
          oldValue.selection.extentOffset == diff.start &&
          oldValue.text.startsWith(typed, diff.start)) {
        // Typing over the already-present paired closer advances rather than duplicates it.
        return oldValue.copyWith(
          selection: TextSelection.collapsed(offset: diff.start + 1),
          composing: TextRange.empty,
        );
      }
      final prev = diff.start > 0 ? newValue.text[diff.start - 1] : '';
      final next = cursor < newValue.text.length ? newValue.text[cursor] : '';
      if (CodeAssist.shouldPair(typed, prev, next, ctl.lang)) {
        const pairs = {'(': ')', '[': ']', '{': '}', '"': '"', "'": "'", '`': '`'};
        // Insert the matching character after the caret, not inside any active
        // composition. Selection offsets are UTF-16 offsets as required by Flutter.
        final text = newValue.text.replaceRange(cursor, cursor, pairs[typed]!);
        return newValue.copyWith(
          text: text,
          selection: TextSelection.collapsed(offset: cursor),
          composing: TextRange.empty,
        );
      }
    }
    return newValue;
  }

  _EditDiff? _textDiff(TextEditingValue oldValue, TextEditingValue newValue) {
    final oldText = oldValue.text;
    final newText = newValue.text;
    // Prefer the old selection as the edit anchor. A plain common-prefix diff
    // cannot distinguish inserting a repeated character (for example ')' just
    // before an existing ')') from typing after it.
    if (oldValue.selection.isValid &&
        newValue.selection.isValid &&
        newValue.selection.isCollapsed) {
      final start = oldValue.selection.start;
      final end = oldValue.selection.end;
      final cursor = newValue.selection.extentOffset;
      if (start <= end &&
          end <= oldText.length &&
          cursor >= start &&
          cursor <= newText.length) {
        final inserted = newText.substring(start, cursor);
        if (oldText.replaceRange(start, end, inserted) == newText) {
          return _EditDiff(start, oldText.substring(start, end), inserted);
        }
      }
    }
    var prefix = 0;
    final minLength = oldText.length < newText.length
        ? oldText.length
        : newText.length;
    while (prefix < minLength &&
        oldText.codeUnitAt(prefix) == newText.codeUnitAt(prefix)) {
      prefix++;
    }
    var oldEnd = oldText.length;
    var newEnd = newText.length;
    while (oldEnd > prefix &&
        newEnd > prefix &&
        oldText.codeUnitAt(oldEnd - 1) == newText.codeUnitAt(newEnd - 1)) {
      oldEnd--;
      newEnd--;
    }
    return _EditDiff(
      prefix,
      oldText.substring(prefix, oldEnd),
      newText.substring(prefix, newEnd),
    );
  }

  KeyEventResult _onKeyEvent(FocusNode node, KeyEvent event) {
    if (event is! KeyDownEvent && event is! KeyRepeatEvent)
      return KeyEventResult.ignored;
    final key = event.logicalKey;
    final keyboard = HardwareKeyboard.instance;
    final primary = keyboard.isControlPressed || keyboard.isMetaPressed;
    if (primary && key == LogicalKeyboardKey.keyZ) {
      if (keyboard.isShiftPressed) {
        _redoEdit();
      } else {
        _undoEdit();
      }
      return KeyEventResult.handled;
    }
    if (primary && key == LogicalKeyboardKey.keyY) {
      _redoEdit();
      return KeyEventResult.handled;
    }
    if (primary && key == LogicalKeyboardKey.keyF) {
      _showFindReplace();
      return KeyEventResult.handled;
    }
    if (primary && key == LogicalKeyboardKey.keyG) {
      _goToLine();
      return KeyEventResult.handled;
    }
    if (primary && key == LogicalKeyboardKey.keyS) {
      if (editing && !_uploading) _save();
      return KeyEventResult.handled;
    }
    if (!editing) return KeyEventResult.ignored;
    if (primary && key == LogicalKeyboardKey.slash) {
      _toggleComment();
      return KeyEventResult.handled;
    }
    if (key == LogicalKeyboardKey.tab) {
      _indentSelection(outdent: keyboard.isShiftPressed);
      return KeyEventResult.handled;
    }
    return KeyEventResult.ignored;
  }

  int _lineStart(String text, int offset) =>
      offset <= 0 ? 0 : text.lastIndexOf('\n', offset - 1) + 1;

  void _indentSelection({required bool outdent}) {
    if (!editing) return;
    final value = ctl.value;
    final text = value.text;
    final selection = value.selection.isValid
        ? value.selection
        : TextSelection.collapsed(offset: 0);
    final start = selection.start.clamp(0, text.length).toInt();
    final end = selection.end.clamp(0, text.length).toInt();
    if (!outdent && selection.isCollapsed) {
      final spaces = _spaces(indentWidth);
      final nextText = text.replaceRange(start, start, spaces);
      ctl.value = value.copyWith(
        text: nextText,
        selection: TextSelection.collapsed(offset: start + spaces.length),
        composing: TextRange.empty,
      );
      return;
    }

    final lastOffset = end > start && text.codeUnitAt(end - 1) == 10
        ? end - 1
        : end;
    final starts = <int>[];
    var line = _lineStart(text, start);
    final lastLine = _lineStart(text, lastOffset);
    while (line <= lastLine) {
      starts.add(line);
      final next = text.indexOf('\n', line);
      if (next < 0 || next + 1 > lastLine) break;
      line = next + 1;
    }

    var nextText = text;
    var nextStart = start;
    var nextEnd = end;
    if (!outdent) {
      final spaces = _spaces(indentWidth);
      for (final at in starts.reversed) {
        nextText = nextText.replaceRange(at, at, spaces);
      }
      int shifted(int offset) =>
          offset + starts.where((at) => at <= offset).length * spaces.length;
      nextStart = shifted(start);
      nextEnd = shifted(end);
    } else {
      final removals = <(int, int)>[];
      for (final at in starts) {
        if (at >= text.length) continue;
        if (text.codeUnitAt(at) == 9) {
          removals.add((at, 1));
        } else {
          var count = 0;
          while (count < indentWidth &&
              at + count < text.length &&
              text.codeUnitAt(at + count) == 32) {
            count++;
          }
          if (count > 0) removals.add((at, count));
        }
      }
      for (final removal in removals.reversed) {
        nextText = nextText.replaceRange(
          removal.$1,
          removal.$1 + removal.$2,
          '',
        );
      }
      int shifted(int offset) {
        var result = offset;
        for (final removal in removals) {
          if (offset > removal.$1) {
            result -= offset < removal.$1 + removal.$2
                ? offset - removal.$1
                : removal.$2;
          }
        }
        return result;
      }

      nextStart = shifted(start);
      nextEnd = shifted(end);
    }
    ctl.value = value.copyWith(
      text: nextText,
      selection: TextSelection(baseOffset: nextStart, extentOffset: nextEnd),
      composing: TextRange.empty,
    );
  }

  (int, int) _lineColumn(int offset) {
    final safe = offset.clamp(0, ctl.text.length).toInt();
    var line = 1;
    var lastBreak = -1;
    for (var i = 0; i < safe; i++) {
      if (ctl.text.codeUnitAt(i) == 10) {
        line++;
        lastBreak = i;
      }
    }
    return (line, safe - lastBreak);
  }

  Future<void> _showFindReplace() async {
    final selected = ctl.selection;
    final initial = selected.isValid && !selected.isCollapsed
        ? ctl.text.substring(selected.start, selected.end)
        : '';
    final query = TextEditingController(text: initial);
    final replacement = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('جست‌وجو و جایگزینی'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: query,
              autofocus: true,
              decoration: const InputDecoration(
                labelText: 'عبارت مورد جست‌وجو',
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: replacement,
              decoration: const InputDecoration(labelText: 'جایگزینی با'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => _findNext(query.text),
            child: const Text('یافتن بعدی'),
          ),
          TextButton(
            onPressed: editing
                ? () => _replaceSelected(query.text, replacement.text)
                : null,
            child: const Text('جایگزینی'),
          ),
          TextButton(
            onPressed: editing
                ? () => _replaceAll(query.text, replacement.text)
                : null,
            child: const Text('جایگزینی همه'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(L.t('done')),
          ),
        ],
      ),
    );
    query.dispose();
    replacement.dispose();
  }

  void _findNext(String query) {
    if (query.isEmpty) return;
    final text = ctl.text;
    final selection = ctl.selection;
    final from = selection.isValid
        ? selection.end.clamp(0, text.length).toInt()
        : 0;
    var at = text.indexOf(query, from);
    if (at < 0 && from > 0) at = text.indexOf(query);
    if (at < 0) {
      snack(context, 'موردی پیدا نشد');
      return;
    }
    ctl.selection = TextSelection(
      baseOffset: at,
      extentOffset: at + query.length,
    );
    if (editing) focus.requestFocus();
  }

  void _replaceSelected(String query, String replacement) {
    if (!editing || query.isEmpty) return;
    final selection = ctl.selection;
    if (selection.isValid &&
        !selection.isCollapsed &&
        ctl.text.substring(selection.start, selection.end) == query) {
      final text = ctl.text.replaceRange(
        selection.start,
        selection.end,
        replacement,
      );
      final caret = selection.start + replacement.length;
      ctl.value = TextEditingValue(
        text: text,
        selection: TextSelection.collapsed(offset: caret),
      );
      _findNext(query);
    } else {
      _findNext(query);
    }
  }

  void _replaceAll(String query, String replacement) {
    if (!editing || query.isEmpty) return;
    final value = ctl.value;
    final beforeCaret = value.selection.isValid
        ? value.selection.extentOffset
        : 0;
    var matchesBefore = 0;
    var from = 0;
    while (true) {
      final at = value.text.indexOf(query, from);
      if (at < 0) break;
      if (at < beforeCaret) matchesBefore++;
      from = at + query.length;
    }
    final result = value.text.replaceAll(query, replacement);
    if (result == value.text) {
      snack(context, 'موردی پیدا نشد');
      return;
    }
    final caret =
        (beforeCaret + matchesBefore * (replacement.length - query.length))
            .clamp(0, result.length)
            .toInt();
    ctl.value = TextEditingValue(
      text: result,
      selection: TextSelection.collapsed(offset: caret),
    );
  }

  Future<void> _goToLine() async {
    final lines = ctl.text.split('\n').length;
    final selected = ctl.selection;
    final initialLine = selected.isValid
        ? _lineColumn(selected.extentOffset).$1
        : 1;
    final input = TextEditingController(text: '$initialLine');
    final result = await showDialog<int>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('رفتن به خط'),
        content: TextField(
          controller: input,
          autofocus: true,
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: 'شمارهٔ خط (۱ تا $lines)'),
          onSubmitted: (v) => Navigator.pop(dialogContext, int.tryParse(v)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(L.t('cancel')),
          ),
          FilledButton(
            onPressed: () =>
                Navigator.pop(dialogContext, int.tryParse(input.text)),
            child: Text(L.t('ok')),
          ),
        ],
      ),
    );
    input.dispose();
    if (result == null || !mounted) return;
    final target = result.clamp(1, lines).toInt();
    var offset = 0;
    for (var line = 1; line < target; line++) {
      final next = ctl.text.indexOf('\n', offset);
      if (next < 0) break;
      offset = next + 1;
    }
    ctl.selection = TextSelection.collapsed(offset: offset);
    if (editing) focus.requestFocus();
  }

  Widget _assistBar(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    Widget chip(Widget child, VoidCallback onTap, {bool strong = false, String? tip}) {
      final w = InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Container(
          alignment: Alignment.center,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          margin: const EdgeInsets.symmetric(vertical: 5, horizontal: 2),
          decoration: BoxDecoration(
            color: strong ? cs.primaryContainer : cs.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(8),
          ),
          child: child,
        ),
      );
      return tip == null ? w : Tooltip(message: tip, child: w);
    }

    Widget txt(String t, {bool strong = false}) => Text(
          t,
          style: TextStyle(
            fontFamily: 'monospace',
            fontSize: 14,
            fontWeight: strong ? FontWeight.w600 : null,
            color: strong ? cs.onPrimaryContainer : cs.onSurface,
          ),
        );

    const pairs = [('()', '(', ')'), ('{}', '{', '}'), ('[]', '[', ']'), ('""', '"', '"'), ("''", "'", "'"), ('<>', '<', '>')];
    const singles = [')', '}', ']', ';', ':', ',', '.', '=', '+', '-', '*', '/', '\\', '_', '!', '&', '|', '#', r'$', '%', '?', '@', '<', '>', '"', "'"];
    final cm = CodeAssist.comment(ctl.lang);
    return TextFieldTapRegion(
      child: Container(
        height: 42,
        width: double.infinity,
        color: cs.surface,
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 4),
            children: [
              for (final w in _sugg) chip(txt(w, strong: true), () => _applySuggestion(w), strong: true),
              if (_sugg.isNotEmpty) const SizedBox(width: 8),
              chip(txt('Tab'), () {
                _indentSelection(outdent: false);
                focus.requestFocus();
              }),
              if (cm != null) chip(txt(cm.open), _toggleComment, tip: tr2('کامنت / حذف کامنت', 'Toggle comment')),
              for (final pr in pairs) chip(txt(pr.$1), () => _insertPair(pr.$2, pr.$3)),
              for (final ch in singles) chip(txt(ch), () => _insertText(ch)),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickLanguage() async {
    final chosen = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        title: Text(L.t('syntax')),
        children: [
          SizedBox(
            width: double.maxFinite,
            height: MediaQuery.of(ctx).size.height * .6,
            child: ListView(
              children: [
                ListTile(
                  dense: true,
                  title: const Text('—'),
                  selected: ctl.lang.isEmpty,
                  onTap: () => Navigator.pop(ctx, ''),
                ),
                for (final d in Hl.all)
                  ListTile(
                    dense: true,
                    title: Text(d.name),
                    selected: ctl.lang == d.id,
                    onTap: () => Navigator.pop(ctx, d.id),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
    if (chosen == null || !mounted) return;
    setState(() {
      ctl.lang = chosen;
      ctl.enabled = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    _syncWatch();
    ctl.dark = Theme.of(context).brightness == Brightness.dark;
    final caret = ctl.selection.isValid ? ctl.selection.extentOffset : 0;
    final position = _lineColumn(caret);
    return PopScope(
      canPop: !_anyDirty && !_uploading,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop || _uploading) return;
        if (await confirm(context, L.t('discard')) && context.mounted)
          Navigator.pop(context);
      },
      child: Scaffold(
        appBar: AppBar(
          leadingWidth: Navigator.of(context).canPop() ? 104 : 52,
          leading: _appLeading(context),
          title: _remote == null
              ? Text(
                  p.basename(_path),
                  style: const TextStyle(fontSize: 16),
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _remote!.name,
                      style: const TextStyle(fontSize: 16),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      _remote!.label,
                      style: const TextStyle(fontSize: 11),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
          actions: [
            if (editing) ...[
              IconButton(
                icon: const Icon(Icons.visibility_rounded),
                tooltip: L.t('view'),
                onPressed: _stopEdit,
              ),
              IconButton(
                icon: Icon(
                  _remote == null ? Icons.save_rounded : Icons.cloud_upload_rounded,
                  color: dirty ? Colors.amber : null,
                ),
                tooltip: _remote == null ? L.t('save') : tr2('ذخیره روی سرور', 'Save to the server'),
                onPressed: _uploading ? null : _save,
              ),
            ] else if (loaded)
              IconButton(
                icon: const Icon(Icons.edit_rounded),
                tooltip: L.t('edit'),
                onPressed: _startEdit,
              ),
            if (loaded)
              IconButton(
                icon: const Icon(Icons.terminal_rounded),
                tooltip: tr2('ترمینال (پنل پایین، چند تب)', 'Terminal (bottom panel, multiple tabs)'),
                onPressed: _openTerminal,
              ),
            PopupMenuButton<int>(
              onSelected: (v) {
                if (v == 0) setState(() => ctl.enabled = !ctl.enabled);
                if (v == 1) _push(HexViewerScreen(path: _path));
                if (v == 2) _push(HashScreen(path: _path));
                if (v == 3) {
                  Clipboard.setData(ClipboardData(text: ctl.text));
                  snack(context, L.t('done'));
                }
                if (v == 4) _deleteThis();
                if (v == 5) _showFindReplace();
                if (v == 6) _goToLine();
                if (v == 7) _undoEdit();
                if (v == 8) _redoEdit();
                if (v == 9) _indentSelection(outdent: false);
                if (v == 10) _indentSelection(outdent: true);
                if (v == 11) setState(() => indentWidth = 2);
                if (v == 12) setState(() => indentWidth = 4);
                if (v == 13) _pickLanguage();
                if (v == 14) _toggleComment();
                if (v == 20) _openFromServer();
                if (v == 21) _saveCopyToServer();
                if (v == 22) _reloadRemote();
                if (v == 30) setState(() => _wrapOverride = !_wrapOn);
                if (v == 31) _saveAll();
                if (v == 32) setState(() => font = (font - 1).clamp(9, 40).toDouble());
                if (v == 33) setState(() => font = (font + 1).clamp(9, 40).toDouble());
                if (v == 34) {
                  _bps.clear();
                  _debug.breakpointsChanged();
                }
              },
              itemBuilder: (_) => [
                if (ctl.lang.isNotEmpty)
                  CheckedPopupMenuItem(
                    value: 0,
                    checked: ctl.enabled,
                    child: Text(L.t('syntax')),
                  ),
                PopupMenuItem(value: 13, enabled: loaded, child: Text(L.t('syntax') + ': ' + (Hl.nameOf(ctl.lang).isEmpty ? '—' : Hl.nameOf(ctl.lang)))),
                PopupMenuItem(value: 3, child: Text(L.t('copyAll'))),
                PopupMenuItem(
                  value: 5,
                  enabled: loaded,
                  child: const Text('جست‌وجو و جایگزینی'),
                ),
                PopupMenuItem(
                  value: 6,
                  enabled: loaded,
                  child: const Text('رفتن به خط'),
                ),
                if (editing) ...[
                  PopupMenuItem(
                    value: 7,
                    enabled: _undo.isNotEmpty,
                    child: const Text('بازگشت (Undo)'),
                  ),
                  PopupMenuItem(
                    value: 8,
                    enabled: _redo.isNotEmpty,
                    child: const Text('انجام دوباره (Redo)'),
                  ),
                  if (CodeAssist.comment(ctl.lang) != null)
                    PopupMenuItem(
                      value: 14,
                      child: Text(tr2('کامنت / حذف کامنت خط‌ها', 'Toggle comment')),
                    ),
                  PopupMenuItem(
                    value: 9,
                    child: const Text('افزایش تورفتگی خط/انتخاب'),
                  ),
                  PopupMenuItem(
                    value: 10,
                    child: const Text('کاهش تورفتگی خط/انتخاب'),
                  ),
                  CheckedPopupMenuItem(
                    value: 11,
                    checked: indentWidth == 2,
                    child: const Text('اندازهٔ تورفتگی: ۲ فاصله'),
                  ),
                  CheckedPopupMenuItem(
                    value: 12,
                    checked: indentWidth == 4,
                    child: const Text('اندازهٔ تورفتگی: ۴ فاصله'),
                  ),
                ],
                PopupMenuItem(
                  value: 20,
                  enabled: loaded && !_uploading,
                  child: Text(tr2('باز کردن از سرور (FTP / SFTP)…', 'Open from server (FTP / SFTP)…')),
                ),
                PopupMenuItem(
                  value: 21,
                  enabled: loaded && !_uploading,
                  child: Text(tr2('ذخیرهٔ یک کپی روی سرور…', 'Save a copy to a server…')),
                ),
                if (_remote != null)
                  PopupMenuItem(
                    value: 22,
                    enabled: !_uploading,
                    child: Text(tr2('بارگیری دوبارهٔ فایل از سرور', 'Reload from the server')),
                  ),
                CheckedPopupMenuItem(
                  value: 30,
                  checked: _wrapOn,
                  child: Text(tr2('شکستن خط‌ها (Word wrap)', 'Word wrap')),
                ),
                PopupMenuItem(value: 31, enabled: loaded, child: Text(tr2('ذخیرهٔ همهٔ فایل‌ها', 'Save all'))),
                PopupMenuItem(value: 32, child: Text(tr2('کوچک‌کردن متن', 'Smaller text'))),
                PopupMenuItem(value: 33, child: Text(tr2('بزرگ‌کردن متن', 'Larger text'))),
                if (!_bps.isEmpty)
                  PopupMenuItem(value: 34, child: Text(tr2('حذف همهٔ بریک‌پوینت‌ها', 'Remove all breakpoints'))),
                PopupMenuItem(value: 1, child: Text(L.t('hex'))),
                PopupMenuItem(value: 2, child: Text(L.t('hash'))),
                if (_remote == null)
                  PopupMenuItem(value: 4, child: Text(L.t('delete'))),
              ],
            ),
          ],
        ),
        floatingActionButton: (loaded && !editing)
            ? FloatingActionButton.extended(
                onPressed: _startEdit,
                icon: const Icon(Icons.edit_rounded),
                label: Text(L.t('edit')),
              )
            : null,
        body: !loaded
            ? const Center(child: CircularProgressIndicator())
            : LayoutBuilder(
                builder: (context, bc) {
                final content = Column(
                children: [
                  if (_uploading)
                    ValueListenableBuilder<double?>(
                      valueListenable: _upProg,
                      builder: (_, v, __) => LinearProgressIndicator(value: v, minHeight: 3),
                    ),
                  _editorBar(context),
                  if (_debugShown) DebugToolbar(session: _debug, onRestart: _restartDebug, onStop: () => _debug.stop()),
                  Expanded(child: _textArea(context)),
                  if (_runOpen && (_run != null || _debugShown || (_terms?.tabs.isNotEmpty ?? false)))
                    SizedBox(
                      height: (bc.maxHeight * (bc.maxHeight < 360 ? .5 : (_runBig ? .7 : .4))).clamp(0.0, 560.0).toDouble(),
                      child: EditorTermPanel(
                        terms: _ensureTerms(),
                        run: _run,
                        runArgs: _runArgs,
                        runSelected: _runTab && _run != null && !_dbgTab,
                        debug: _debugShown ? _debug : null,
                        bps: _bps,
                        debugSelected: _dbgTab,
                        canDebug: _canDebug,
                        onSelectDebug: () => setState(() {
                          _dbgTab = true;
                          _runTab = false;
                        }),
                        onCloseDebug: _closeDebugTab,
                        onDebugStart: (pre) => _startDebug(pre),
                        onGoto: _goto,
                        onEditCondition: _editCondition,
                        big: _runBig,
                        onSelectRun: () => setState(() {
                          _runTab = true;
                          _dbgTab = false;
                        }),
                        onCloseRun: _closeRunTab,
                        onRun: (pre) => _startRun(pre),
                        onTerminalSelected: () => setState(() {
                          _runTab = false;
                          _dbgTab = false;
                        }),
                        onToggleSize: () => setState(() => _runBig = !_runBig),
                        onClose: _closePanel,
                      ),
                    ),
                  if (editing) _assistBar(context),
                  Container(
                    height: 30,
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: Theme.of(context)
                          .colorScheme
                          .surfaceContainerHighest
                          .withOpacity(.55),
                      border: Border(
                        top: BorderSide(
                          color: Theme.of(context).dividerColor
                              .withOpacity(.35),
                        ),
                      ),
                    ),
                    child: Row(
                      children: [
                        Text(
                          (editing ? 'ویرایش' : 'فقط‌خواندنی') +
                              (_remote == null ? '' : ' • ${_remote!.profile.type.toUpperCase()}'),
                          style: Theme.of(context).textTheme.labelSmall,
                        ),
                        const Spacer(),
                        if (Hl.nameOf(ctl.lang).isNotEmpty) ...[
                          Directionality(
                            textDirection: TextDirection.ltr,
                            child: Text(
                              Hl.nameOf(ctl.lang),
                              style: Theme.of(context).textTheme.labelSmall,
                            ),
                          ),
                          const SizedBox(width: 16),
                        ],
                        Directionality(
                          textDirection: TextDirection.ltr,
                          child: Text(
                            '${position.$1}:${position.$2}',
                            style: Theme.of(context).textTheme.labelSmall
                                ?.copyWith(fontFamily: 'monospace'),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              );
              return _withSide(context, bc, content);
            }),
      ),
    );
  }
}

class _EditDiff {
  final int start;
  final String removed;
  final String inserted;
  const _EditDiff(this.start, this.removed, this.inserted);
}

/// One open file (tab). The live one is held in the controller; the others are stashed here.
class _Doc {
  String path;
  RemoteDoc? remote;
  TextEditingValue value;
  String savedText;
  String lang;
  bool dirty = false;
  final List<TextEditingValue> undo = [];
  final List<TextEditingValue> redo = [];
  int undoBytes = 0, redoBytes = 0;
  double scroll = 0;
  _Doc(this.path, this.remote, this.value, this.savedText, this.lang);
}
