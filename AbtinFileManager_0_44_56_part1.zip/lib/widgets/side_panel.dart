import 'package:flutter/material.dart';

import '../core/layouts.dart' show tr2;

/// Left side of the editor: thin activity bar (Explorer / Debug) + the chosen view.
/// Opened and closed with the hamburger button of the editor.
class SidePanel extends StatelessWidget {
  final int tab;
  final ValueChanged<int> onTab;
  final VoidCallback onClose;
  final Widget explorer;
  final Widget debug;
  final bool debugActive;
  const SidePanel({
    super.key,
    required this.tab,
    required this.onTab,
    required this.onClose,
    required this.explorer,
    required this.debug,
    this.debugActive = false,
  });

  Widget _act(BuildContext context, IconData icon, String tip, int i, {bool dot = false}) {
    final cs = Theme.of(context).colorScheme;
    final sel = tab == i;
    return InkWell(
      onTap: () => onTab(i),
      child: Container(
        width: 44,
        height: 46,
        decoration: BoxDecoration(
          border: Border(left: BorderSide(color: sel ? cs.primary : Colors.transparent, width: 2.5)),
        ),
        child: Tooltip(
          message: tip,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Icon(icon, size: 24, color: sel ? cs.onSurface : cs.onSurfaceVariant.withOpacity(.7)),
              if (dot)
                const Positioned(right: 9, top: 10, child: CircleAvatar(radius: 4, backgroundColor: Color(0xFFE5534B))),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Material(
        elevation: 6,
        color: cs.surface,
        child: Row(
          children: [
            Container(
              width: 44,
              color: cs.surfaceContainerHighest.withOpacity(.6),
              child: Column(
                children: [
                  _act(context, Icons.folder_copy_outlined, tr2('فایل‌ها', 'Explorer'), 0),
                  _act(context, Icons.bug_report_outlined, tr2('دیباگ', 'Debug'), 1, dot: debugActive),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.keyboard_double_arrow_left_rounded, size: 20),
                    tooltip: tr2('بستن منو', 'Close'),
                    onPressed: onClose,
                  ),
                  const SizedBox(height: 6),
                ],
              ),
            ),
            VerticalDivider(width: 1, color: cs.outlineVariant),
            Expanded(
              child: IndexedStack(index: tab, children: [explorer, debug]),
            ),
          ],
        ),
      ),
    );
  }
}
