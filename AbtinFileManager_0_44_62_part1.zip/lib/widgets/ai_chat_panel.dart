import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/layouts.dart' show tr2;
import '../services/ai_client.dart';
import '../services/ai_session.dart';
import '../services/ai_settings.dart';
import 'ai_settings_dialog.dart';

/// What the editor attaches to a question: label shown in the chat + text sent to the model.
class AiAttach {
  const AiAttach(this.label, this.context);
  final String label;
  final String context;
}

/// Chat UI of the AI assistant (used in the editor side panel and in the full-screen page).
class AiChatPanel extends StatefulWidget {
  const AiChatPanel({super.key, required this.session, this.attach, this.onApplyCode, this.onPickFolder});
  final AiSession session;

  /// Current file / selection of the editor (null outside the editor).
  final AiAttach? Function()? attach;

  /// Inserts a code block into the editor.
  final void Function(String code)? onApplyCode;

  /// Full-screen chat: lets the user choose the project folder.
  final VoidCallback? onPickFolder;

  @override
  State<AiChatPanel> createState() => _AiChatPanelState();
}

bool _isRtl(String s) {
  for (final r in s.runes) {
    if ((r >= 0x0590 && r <= 0x08FF) || (r >= 0xFB1D && r <= 0xFEFC)) return true;
    if ((r >= 0x41 && r <= 0x5A) || (r >= 0x61 && r <= 0x7A)) return false;
  }
  return false;
}

class _AiChatPanelState extends State<AiChatPanel> {
  final _input = TextEditingController();
  final _scroll = ScrollController();
  bool _attachOn = true;

  AiSession get _s => widget.session;

  @override
  void initState() {
    super.initState();
    AiSettings.load().then((_) {
      if (mounted) setState(() {});
    });
    _s.approve = _approve;
    _s.addListener(_changed);
    _s.load();
  }

  @override
  void dispose() {
    _s.removeListener(_changed);
    if (_s.approve == _approve) _s.approve = null;
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _changed() {
    if (!mounted) return;
    setState(() {});
    if (_s.busy) _toEnd();
  }

  void _toEnd() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
    });
  }

  Future<bool> _approve(AiToolCall c, String preview, bool dangerous) async {
    if (!mounted) return false;
    final r = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: Text(dangerous ? tr2('حذف را تأیید می‌کنید؟', 'Allow delete?') : tr2('این تغییر اعمال شود؟', 'Apply this change?')),
        content: SingleChildScrollView(
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: SelectableText(preview, style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(tr2('رد کردن', 'Reject'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(tr2('اعمال', 'Apply'))),
        ],
      ),
    );
    return r == true;
  }

  Future<void> _send() async {
    final t = _input.text.trim();
    if (t.isEmpty || _s.busy) return;
    final a = (_attachOn && widget.attach != null) ? widget.attach!() : null;
    _input.clear();
    _toEnd();
    await _s.send(t, context: a?.context ?? '', label: a?.label ?? '');
    _toEnd();
  }

  Future<void> _settings() async {
    await showAiSettings(context);
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final shown = [for (final m in _s.msgs) if (m.role != 'tool') m];
    final results = {for (final m in _s.msgs) if (m.role == 'tool') m.callId: m};
    final prov = AiSettings.current;
    return Column(children: [
      _header(cs, prov),
      const Divider(height: 1),
      Expanded(
        child: shown.isEmpty
            ? _empty(cs)
            : ListView.builder(
                controller: _scroll,
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
                itemCount: shown.length,
                itemBuilder: (_, i) => _bubble(cs, shown[i], results, i == shown.length - 1),
              ),
      ),
      if (_s.error != null)
        Container(
          width: double.infinity,
          color: cs.errorContainer,
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(child: SelectableText(_s.error!, style: TextStyle(fontSize: 12, color: cs.onErrorContainer))),
            InkWell(onTap: () => setState(() => _s.error = null), child: const Padding(padding: EdgeInsets.all(4), child: Icon(Icons.close_rounded, size: 16))),
          ]),
        ),
      _inputBar(cs),
    ]);
  }

  Widget _header(ColorScheme cs, AiProvider prov) {
    final ready = AiSettings.ready;
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 4, 4, 4),
      child: Row(children: [
        const Icon(Icons.auto_awesome_rounded, size: 18, color: Color(0xFFD97757)),
        const SizedBox(width: 6),
        Expanded(
          child: InkWell(
            onTap: _settings,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Text(
                ready ? '${prov.name.split(' (').first} · ${AiSettings.modelOf(prov.id)}' : tr2('انتخاب سرویس و کلید API', 'Choose provider & API key'),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: ready ? null : cs.error),
              ),
            ),
          ),
        ),
        if (widget.onPickFolder != null)
          IconButton(
            visualDensity: VisualDensity.compact,
            tooltip: tr2('پوشهٔ پروژه', 'Project folder'),
            icon: Icon(_s.root == null ? Icons.folder_off_outlined : Icons.folder_open_rounded, size: 20),
            onPressed: widget.onPickFolder,
          ),
        IconButton(visualDensity: VisualDensity.compact, tooltip: tr2('تنظیمات', 'Settings'), icon: const Icon(Icons.tune_rounded, size: 20), onPressed: _settings),
        IconButton(
          visualDensity: VisualDensity.compact,
          tooltip: tr2('گفتگوی جدید', 'New chat'),
          icon: const Icon(Icons.add_comment_outlined, size: 20),
          onPressed: _s.msgs.isEmpty && _s.error == null ? null : () => _s.clear(),
        ),
      ]),
    );
  }

  Widget _empty(ColorScheme cs) {
    final tools = _s.toolsActive;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.auto_awesome_rounded, size: 40, color: Color(0xFFD97757)),
          const SizedBox(height: 12),
          Text(
            tr2('دستیار کدنویسی', 'Coding assistant'),
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          Text(
            tools
                ? tr2('ChatGPT، DeepSeek، Kimi K3، Claude و … با API. می‌تواند فایل‌های این پروژه را بخواند، جست‌وجو و (با تأیید شما) ویرایش کند.',
                    'ChatGPT, DeepSeek, Kimi K3, Claude … through their APIs. It can read, search and (with your approval) edit files of this project.')
                : tr2('ChatGPT، DeepSeek، Kimi K3، Claude و … با API. برای کار روی فایل‌ها یک پوشهٔ پروژه انتخاب کنید.',
                    'ChatGPT, DeepSeek, Kimi K3, Claude … through their APIs. Pick a project folder to let it work on files.'),
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 13, color: cs.onSurfaceVariant),
          ),
          if (!AiSettings.ready) ...[
            const SizedBox(height: 14),
            FilledButton.icon(onPressed: _settings, icon: const Icon(Icons.key_rounded, size: 18), label: Text(tr2('وارد کردن کلید API', 'Enter API key'))),
          ],
        ]),
      ),
    );
  }

  Widget _inputBar(ColorScheme cs) {
    final canAttach = widget.attach != null;
    return Container(
      decoration: BoxDecoration(border: Border(top: BorderSide(color: cs.outlineVariant))),
      padding: const EdgeInsets.fromLTRB(8, 6, 8, 8),
      child: Column(children: [
        if (canAttach)
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: FilterChip(
              visualDensity: VisualDensity.compact,
              avatar: const Icon(Icons.attach_file_rounded, size: 15),
              label: Text(tr2('فایل/انتخاب فعلی ادیتور', 'Current file / selection'), style: const TextStyle(fontSize: 12)),
              selected: _attachOn,
              onSelected: (v) => setState(() => _attachOn = v),
            ),
          ),
        Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Expanded(
            child: TextField(
              controller: _input,
              minLines: 1,
              maxLines: 6,
              textInputAction: TextInputAction.newline,
              decoration: InputDecoration(
                isDense: true,
                hintText: tr2('از دستیار بپرسید…', 'Ask the assistant…'),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
                contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              ),
            ),
          ),
          const SizedBox(width: 6),
          _s.busy
              ? IconButton.filledTonal(onPressed: _s.stop, icon: const Icon(Icons.stop_rounded), tooltip: tr2('توقف', 'Stop'))
              : IconButton.filled(onPressed: _send, icon: const Icon(Icons.arrow_upward_rounded), tooltip: tr2('ارسال', 'Send')),
        ]),
      ]),
    );
  }

  // ------------------------------------------------------------ messages
  Widget _bubble(ColorScheme cs, AiMsg m, Map<String, AiMsg> results, bool last) {
    if (m.role == 'user') {
      return Align(
        alignment: AlignmentDirectional.centerEnd,
        child: Container(
          margin: const EdgeInsets.symmetric(vertical: 4),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          constraints: const BoxConstraints(maxWidth: 420),
          decoration: BoxDecoration(color: cs.primaryContainer, borderRadius: BorderRadius.circular(14)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            if (m.attachLabel.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.attach_file_rounded, size: 13),
                  const SizedBox(width: 2),
                  Flexible(child: Text(m.attachLabel, style: const TextStyle(fontSize: 11), overflow: TextOverflow.ellipsis)),
                ]),
              ),
            Directionality(
              textDirection: _isRtl(m.text) ? TextDirection.rtl : TextDirection.ltr,
              child: SelectableText(m.text, style: TextStyle(color: cs.onPrimaryContainer)),
            ),
          ]),
        ),
      );
    }
    final streaming = _s.busy && last;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        if (m.reasoning.isNotEmpty)
          Theme(
            data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
            child: ExpansionTile(
              dense: true,
              tilePadding: EdgeInsets.zero,
              childrenPadding: const EdgeInsets.only(bottom: 6),
              title: Text(tr2('تفکر مدل', 'Thinking'), style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
              children: [
                Directionality(
                  textDirection: _isRtl(m.reasoning) ? TextDirection.rtl : TextDirection.ltr,
                  child: SelectableText(m.reasoning, style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant)),
                ),
              ],
            ),
          ),
        if (m.text.isNotEmpty) ..._markdown(cs, m.text),
        for (final c in m.calls) _toolChip(cs, c, results[c.id]),
        if (streaming && m.text.isEmpty && m.calls.isEmpty)
          const Padding(padding: EdgeInsets.all(6), child: SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))),
        if (!streaming && m.text.isNotEmpty)
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: InkWell(
              onTap: () => Clipboard.setData(ClipboardData(text: m.text)),
              child: Padding(padding: const EdgeInsets.all(4), child: Icon(Icons.copy_rounded, size: 14, color: cs.onSurfaceVariant)),
            ),
          ),
      ]),
    );
  }

  Widget _toolChip(ColorScheme cs, AiToolCall c, AiMsg? r) {
    final running = r == null;
    final err = r?.isError == true;
    final icon = running ? Icons.hourglass_top_rounded : (err ? Icons.error_outline_rounded : Icons.check_circle_outline_rounded);
    final col = running ? cs.onSurfaceVariant : (err ? cs.error : const Color(0xFF39A85B));
    final path = c.args['path'] ?? c.args['pattern'] ?? c.args['from'] ?? '';
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 2),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: cs.surfaceContainerHighest.withOpacity(.6), borderRadius: BorderRadius.circular(10)),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          Icon(icon, size: 15, color: col),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              '${c.name} $path${r != null && (err || c.name.startsWith('edit') || c.name.startsWith('write')) ? '  —  ${r.text.split('\n').first}' : ''}',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 11.5, fontFamily: 'monospace'),
            ),
          ),
        ]),
      ),
    );
  }

  // ------------------------------------------------------------ tiny markdown
  List<Widget> _markdown(ColorScheme cs, String text) {
    final out = <Widget>[];
    final lines = text.split('\n');
    final para = <String>[];
    void flush() {
      if (para.isEmpty) return;
      final t = para.join('\n').trim();
      para.clear();
      if (t.isEmpty) return;
      out.add(Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Directionality(
          textDirection: _isRtl(t) ? TextDirection.rtl : TextDirection.ltr,
          child: SelectableText.rich(TextSpan(children: _inline(t, cs), style: const TextStyle(fontSize: 14, height: 1.45))),
        ),
      ));
    }

    var i = 0;
    while (i < lines.length) {
      final l = lines[i];
      if (l.trimLeft().startsWith('```')) {
        flush();
        final lang = l.trim().substring(3).trim();
        final code = <String>[];
        i++;
        while (i < lines.length && !lines[i].trimLeft().startsWith('```')) {
          code.add(lines[i]);
          i++;
        }
        i++; // closing fence (or end of the text while streaming)
        out.add(_codeBlock(cs, lang, code.join('\n')));
        continue;
      }
      para.add(l);
      i++;
    }
    flush();
    return out;
  }

  List<InlineSpan> _inline(String t, ColorScheme cs) {
    final spans = <InlineSpan>[];
    final re = RegExp(r'(\*\*[^*\n]+\*\*)|(`[^`\n]+`)');
    var pos = 0;
    for (final mt in re.allMatches(t)) {
      if (mt.start > pos) spans.add(TextSpan(text: _stripMd(t.substring(pos, mt.start))));
      final s = mt.group(0)!;
      if (s.startsWith('**')) {
        spans.add(TextSpan(text: s.substring(2, s.length - 2), style: const TextStyle(fontWeight: FontWeight.w700)));
      } else {
        spans.add(TextSpan(
          text: s.substring(1, s.length - 1),
          style: TextStyle(fontFamily: 'monospace', fontSize: 13, backgroundColor: cs.surfaceContainerHighest),
        ));
      }
      pos = mt.end;
    }
    if (pos < t.length) spans.add(TextSpan(text: _stripMd(t.substring(pos))));
    return spans;
  }

  String _stripMd(String s) => s.replaceAllMapped(RegExp(r'^#{1,6}\s*', multiLine: true), (_) => '').replaceAllMapped(RegExp(r'^(\s*)[-*]\s+', multiLine: true), (m) => '${m[1]}• ');

  Widget _codeBlock(ColorScheme cs, String lang, String code) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 4),
      decoration: BoxDecoration(color: cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(10)),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 2, 2, 0),
            child: Row(children: [
              Expanded(child: Text(lang, style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant))),
              IconButton(
                visualDensity: VisualDensity.compact,
                iconSize: 16,
                tooltip: tr2('کپی', 'Copy'),
                icon: const Icon(Icons.copy_rounded),
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: code));
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr2('کپی شد', 'Copied')), duration: const Duration(seconds: 1)));
                },
              ),
              if (widget.onApplyCode != null)
                IconButton(
                  visualDensity: VisualDensity.compact,
                  iconSize: 16,
                  tooltip: tr2('درج در ادیتور (جایگزین انتخاب)', 'Insert into editor (replaces selection)'),
                  icon: const Icon(Icons.input_rounded),
                  onPressed: () => widget.onApplyCode!(code),
                ),
            ]),
          ),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
            child: SelectableText(code, style: const TextStyle(fontFamily: 'monospace', fontSize: 12.5, height: 1.35)),
          ),
        ]),
      ),
    );
  }
}
