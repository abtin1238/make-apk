package ir.abtin.sms;

import android.os.ParcelFileDescriptor;

// Runs inside a Shizuku "user service" process (shell uid 2000, or root).
// All transaction ids are explicit because Shizuku requires destroy() = 16777114.
interface IRecService {
    void destroy() = 16777114;
    // Starts recording the call audio into `out` (an m4a/AAC file opened read-write by the app).
    // Returns "OK ..." or "ERR ..." with a detailed reason.
    String start(in ParcelFileDescriptor out, int mode) = 2;
    // Stops and finalises the file. Returns "OK src=.. frames=.. peak=.." or "ERR ..".
    String stop() = 3;
    boolean isRecording() = 4;
    // Probes which audio sources can be opened from the shell process (for the settings self-test).
    String diagnose() = 5;
}
