package ir.abtin.sms

import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Abtin SMS home: hero card, shortcut rail, scheduled / group tiles, stats and the latest messages (mockup 2). */
@Composable
fun SmsDashboard(repo: SmsRepo, act: ComponentActivity, nav: MutableState<Screen>, askDefault: () -> Unit) {
    val p = LocalPal.current
    val tick = Bus.tick.intValue
    var convs by remember { mutableStateOf<List<Conv>>(emptyList()) }
    var recv by remember { mutableIntStateOf(0) }
    var sent by remember { mutableIntStateOf(0) }
    LaunchedEffect(tick) {
        withContext(Dispatchers.IO) {
            convs = runCatching { repo.conversations() }.getOrDefault(emptyList())
            recv = repo.countType(1); sent = repo.countType(2)
        }
    }
    val arch = csv(Prefs.archived); val blk = csv(Prefs.blocked); val spm = csv(Prefs.spam)
    val latest = convs.filter { it.threadId.toString() !in arch && norm(it.address) !in blk && norm(it.address) !in spm }.take(4)
    fun go(s: Screen) { nav.value = s }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(bottom = 100.dp)) {
            BrandHeader("Abtin", "SMS", tr("مدیریت و ارسال پیامک", "Manage & send SMS"), Icons.Default.Person) { Bus.page.value = ""; go(Screen.Settings) }
            if (!isDefaultSms(act)) DefaultBanner(askDefault)
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    HeroCard(tr("ارسال پیامک هوشمند", "Smart SMS"), tr("سریع، آسان و مطمئن", "Fast, easy and reliable"), tr("ارسال پیامک", "Send SMS"),
                        Icons.Default.Send, { go(Screen.Send(0)) }) { PhoneArt(1) }
                    Spacer(Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        TileCard(tr("ارسال زمان‌بندی شده", "Scheduled"), tr("برنامه‌ریزی ارسال پیامک", "Plan your messages"), Icons.Default.CalendarMonth, Color.White,
                            Color(0x80893DFF), Color(0x4D3228AA), { go(Screen.Scheduled) }, Modifier.weight(1f))
                        TileCard(tr("ارسال گروهی", "Group send"), tr("به چندین مخاطب", "To many contacts"), Icons.Default.People, Color(0xFFB7FFE9),
                            Color(0x8018D39A), Color(0x4D0A5A78), { go(Screen.Send(2)) }, Modifier.weight(1f))
                    }
                }
                RailBar(listOf(
                    RailItem(Icons.Default.People, true) { go(Screen.Contacts) },
                    RailItem(Icons.Default.Schedule, false) { go(Screen.Scheduled) },
                    RailItem(Icons.Default.BarChart, false) { go(Screen.Stats) },
                    RailItem(Icons.Default.Inbox, false) { go(Screen.Home) },
                    RailItem(Icons.Default.Settings, false) { Bus.page.value = ""; go(Screen.Settings) }
                ))
            }
            // stats
            Row(Modifier.padding(horizontal = 18.dp).padding(top = 14.dp).fillMaxWidth().glass(RoundedCornerShape(24.dp), Brush.linearGradient(listOf(Color(0x5918D39A), Color(0x80141E78))))
                .padding(vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                StatCol(Icons.Default.Download, Color(0xFF3FE3B4), listNum(recv.toString()), tr("پیام‌های دریافتی", "Received"), Modifier.weight(1f)) { go(Screen.Home) }
                Box(Modifier.width(1.dp).height(70.dp).background(p.line))
                StatCol(Icons.Default.Send, Color(0xFF4DB8FF), listNum(sent.toString()), tr("پیام‌های ارسالی", "Sent"), Modifier.weight(1f)) { go(Screen.Stats) }
            }
            // latest messages
            Column(Modifier.padding(horizontal = 18.dp).padding(top = 14.dp).fillMaxWidth().glass(RoundedCornerShape(26.dp)).padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.clickable { go(Screen.Home) }, verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.KeyboardArrowLeft, null, tint = Cyan, modifier = Modifier.size(22.dp))
                        Text(tr("مشاهده همه", "View all"), color = Cyan, fontSize = 15.sp, fontWeight = FontWeight.Medium, style = FaStyle)
                    }
                    Spacer(Modifier.weight(1f))
                    Text(tr("آخرین پیام‌ها", "Latest messages"), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, style = FaStyle)
                    Box(Modifier.padding(start = 8.dp).size(10.dp).clip(CircleShape).background(Color(0xFF8B5CFF)))
                }
                Spacer(Modifier.height(10.dp))
                if (latest.isEmpty()) Text(tr("هنوز پیامی نیست", "No messages yet"), color = p.sub, modifier = Modifier.fillMaxWidth().padding(16.dp), textAlign = TextAlign.Center)
                latest.forEach { c ->
                    val shape = RoundedCornerShape(18.dp)
                    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(shape).background(Color(0x3314196E)).clickable { go(Screen.Chat(c.threadId, c.address)) }.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Avatar(repo, c.address, c.name ?: c.address, 46.dp, group = c.address.contains(','))
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(fixNum(c.name ?: c.address), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, style = FaStyle)
                            Text(c.snippet, color = p.sub, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, style = FaStyle)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(fmtList(c.date), color = p.sub, fontSize = 12.sp)
                            Box(Modifier.padding(top = 6.dp).size(10.dp).clip(CircleShape).background(if (c.unread > 0) Color(0xFF2A9BFF) else Color(0xFF7C86B8)))
                        }
                    }
                }
            }
        }
        Box(Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(end = 18.dp, bottom = 16.dp).size(66.dp)
            .shadow(18.dp, CircleShape, ambientColor = Color(0xFF5B3CFF), spotColor = Color(0xFF5B3CFF)).clip(CircleShape).background(OrbBrush)
            .border(1.dp, Color(0x66FFFFFF), CircleShape).clickable { go(Screen.New) }, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Edit, null, tint = Color.White, modifier = Modifier.size(28.dp))
        }
    }
}

@Composable
private fun StatCol(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, value: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Column(modifier.clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(34.dp))
        Text(value, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
        Text(label, color = Color(0xFFA9B3EF), fontSize = 13.sp, style = FaStyle.copy(textAlign = TextAlign.Center))
    }
}
