package ir.abtin.sms

import android.app.Activity
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.core.view.WindowCompat

/** The single Abtin theme (dark navy, from the design mockups). Colors can be overridden with the HSV sliders in Settings. */
data class Pal(
    val bg: Color, val bg2: Color, val surface: Color, val nav: Color, val line: Color,
    val primary: Color, val primary2: Color, val onPrimary: Color,
    val inBubble: Color, val out1: Color, val out2: Color,
    val text: Color, val sub: Color, val badge: Color, val tick: Color, val danger: Color
)

object Def {
    val bg = Color(0xFF050A26); val inBubble = Color(0xFF15204F); val out = Color(0xFF2650C8); val accent = Color(0xFF2F6BFF)
}

private fun custom(v: Int, fb: Color): Color = if (v == 0) fb else Color(v)

fun buildPal(): Pal {
    val bg = custom(Prefs.chatBackground.value, Def.bg)
    val acc = custom(Prefs.accentColor.value, Def.accent)
    val out = custom(Prefs.outgoingBubble.value, Def.out)
    return Pal(
        bg = bg, bg2 = lerp(bg, Color.White, .045f), surface = lerp(bg, Color(0xFF6E86FF), .13f), nav = lerp(bg, Color(0xFF6E86FF), .10f),
        line = lerp(bg, Color(0xFF8FA4FF), .26f),
        primary = acc, primary2 = lerp(acc, Color.Black, .22f), onPrimary = Color.White,
        inBubble = custom(Prefs.incomingBubble.value, Def.inBubble),
        out1 = out, out2 = lerp(out, Color.Black, .14f),
        text = Color(0xFFEAF0FF), sub = Color(0xFF9AA6E0),
        badge = lerp(acc, Color.White, .28f), tick = Color(0xFF58A6FF), danger = Color(0xFFFF5C5C)
    )
}

val LocalPal = compositionLocalOf { buildPal() }

@Composable
fun AbtinTheme(content: @Composable () -> Unit) {
    val p = buildPal()
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window ?: return@SideEffect
        val ic = WindowCompat.getInsetsController(w, view)
        ic.isAppearanceLightStatusBars = false; ic.isAppearanceLightNavigationBars = false
    }
    val scheme = darkColorScheme(primary = p.primary, onPrimary = p.onPrimary, background = p.bg, surface = p.surface,
        onSurface = p.text, onBackground = p.text, surfaceVariant = p.surface, onSurfaceVariant = p.sub,
        surfaceContainer = p.surface, surfaceContainerHigh = p.surface, outline = p.line, outlineVariant = p.line)
    CompositionLocalProvider(LocalPal provides p) { MaterialTheme(colorScheme = scheme, content = content) }
}

/** Message bubble outline. style: tail | rounded | pill | square. Tail styles reserve [TAIL_DP] on the tail side. */
const val TAIL_DP = 7f

class BubbleShape(private val out: Boolean, private val style: String) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val d = density.density; val w = size.width; val h = size.height
        return when (style) {
            "pill" -> Outline.Rounded(RoundRect(0f, 0f, w, h, CornerRadius(minOf(h / 2f, 28 * d))))
            "square" -> Outline.Rounded(RoundRect(0f, 0f, w, h, CornerRadius(8 * d)))
            "rounded" -> {
                val big = 20 * d; val small = 5 * d
                Outline.Rounded(RoundRect(0f, 0f, w, h, CornerRadius(big), CornerRadius(big),
                    CornerRadius(if (out) small else big), CornerRadius(if (out) big else small)))
            }
            else -> Outline.Generic(tail(w, h, d))
        }
    }

    private fun tail(w: Float, h: Float, d: Float): Path {
        val r = minOf(20 * d, h / 2f, (w - TAIL_DP * d) / 2f); val bw = w - TAIL_DP * d
        fun m(x: Float) = if (out) x else w - x
        return Path().apply {
            moveTo(m(r), 0f); lineTo(m(bw - r), 0f)
            quadraticBezierTo(m(bw), 0f, m(bw), r)
            lineTo(m(bw), maxOf(r, h - 14 * d))
            cubicTo(m(bw), h - 6 * d, m(bw + 2 * d), h - 1.5f * d, m(w), h)
            cubicTo(m(w - 3 * d), h, m(bw - 2 * d), h, m(bw - 12 * d), h)
            lineTo(m(r), h)
            quadraticBezierTo(m(0f), h, m(0f), h - r)
            lineTo(m(0f), r)
            quadraticBezierTo(m(0f), 0f, m(r), 0f)
            close()
        }
    }
}

val PillShape = CircleShape
