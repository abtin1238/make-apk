# Build fix notes — AbtinSMS 1.6.0

- Replaced the unavailable `android.icu.util.PersianCalendar()` constructor with ICU's supported locale-based calendar factory: `Calendar.getInstance(ULocale("fa_IR@calendar=persian"))`. This preserves Jalali-calendar behavior in Persian mode and removes the reported unresolved-reference error.
- Gregorian mode continues to use the device's default ICU calendar locale.
- No SMS scheduling, sending, permissions, or UI logic was changed.

Validation: source-level checks confirm the unresolved class reference is removed and the ICU locale calendar factory is used. A Kotlin/Gradle build was not run in this environment because Flutter and Dart SDKs are not installed.
