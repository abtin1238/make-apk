import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'ir.dart';
import 'theme.dart';

/// کتابخانه‌ی کدهای IR برگرفته از دیتابیس Mi Remote (پروژه‌ی mi_remote_database، AGPL-3.0).
/// داده‌ها به‌صورت فشرده در assets/mi_ir_db.gz هستند؛ هر برند یک خط JSON است و فقط همان لحظه خوانده می‌شود.

const List<MapEntry<String, String>> kMiDevices = [
  MapEntry('tv', 'TV'),
  MapEntry('stb', 'Set-top box'),
  MapEntry('box', 'Android Box'),
  MapEntry('av', 'A/V receiver'),
  MapEntry('dvd', 'DVD'),
  MapEntry('proj', 'Projector'),
  MapEntry('cable', 'Cable / Sat'),
];

/// کلید دکمه‌ی اپ ← نام‌های Mi به ترتیب اولویت
const Map<String, List<String>> _appToMi = {
  'POWER': ['power'],
  'POWER_ON': ['power'],
  'MUTE': ['mute'],
  'HOME': ['home'],
  'BACK': ['back', 'exit'],
  'RECENTS': ['menu'],
  'QUICK_SETTINGS': ['set'],
  'NOTIFICATIONS': ['tv_av', 'input', 'source', 'AV'],
  'UP': ['up'],
  'DOWN': ['down'],
  'LEFT': ['left'],
  'RIGHT': ['right'],
  'ENTER': ['ok', 'enter', 'sel'],
  'VOL_UP': ['vol+'],
  'VOL_DOWN': ['vol-'],
  'CH_UP': ['ch+'],
  'CH_DOWN': ['ch-'],
  'PLAY_PAUSE': ['play', 'pause'],
  'PREV': ['previous'],
  'NEXT': ['next'],
  'RED': ['red'],
  'GREEN': ['green'],
  'YELLOW': ['yellow'],
  'BLUE': ['blue'],
  'INFO': ['info', 'display'],
  'TEXT': ['teletext'],
  'EPG': ['guide'],
  '0': ['0'],
  '1': ['1'],
  '2': ['2'],
  '3': ['3'],
  '4': ['4'],
  '5': ['5'],
  '6': ['6'],
  '7': ['7'],
  '8': ['8'],
  '9': ['9'],
};

class MiBrand {
  final String name;
  final int line;
  final int sets;
  const MiBrand(this.name, this.line, this.sets);
}

/// یک مجموعه‌کد (مثل یک «پروفایل» داخل Mi Remote)
class MiSet {
  /// نام دکمه در Mi ← کد
  final Map<String, IrCode> byName;
  const MiSet(this.byName);

  IrCode? get power => byName['power'];

  /// تبدیل به کدهای پروفایل اپ: دکمه‌های هم‌نام + بقیه‌ی دکمه‌ها با پیشوند x:
  Map<String, IrCode> toProfileCodes() {
    final out = <String, IrCode>{};
    final used = <String>{};
    for (final e in _appToMi.entries) {
      for (final n in e.value) {
        final c = byName[n];
        if (c != null) {
          out[e.key] = c;
          used.add(n);
          break;
        }
      }
    }
    for (final e in byName.entries) {
      if (!used.contains(e.key)) out['x:${e.key}'] = e.value;
    }
    return out;
  }
}

List<Object> _unpack(Uint8List gz) {
  final raw = gzip.decode(gz);
  final bytes = raw is Uint8List ? raw : Uint8List.fromList(raw);
  final starts = <int>[0];
  for (var i = 0; i < bytes.length; i++) {
    if (bytes[i] == 10) starts.add(i + 1);
  }
  return [bytes, Int32List.fromList(starts)];
}

class MiDb {
  static final MiDb instance = MiDb._();
  MiDb._();

  Uint8List? _bytes;
  Int32List _starts = Int32List(0);
  final Map<String, List<MiBrand>> index = {};
  Future<void>? _loading;

  Future<void> load() => _loading ??= _load();

  Future<void> _load() async {
    final data = await rootBundle.load('assets/mi_ir_db.gz');
    final res = await compute(_unpack, data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes));
    _bytes = res[0] as Uint8List;
    _starts = res[1] as Int32List;
    final head = jsonDecode(utf8.decode(Uint8List.sublistView(_bytes!, 0, _starts[1] - 1))) as Map;
    index.clear();
    for (final e in head.entries) {
      index[e.key as String] = [
        for (final b in (e.value as List)) MiBrand(b[0] as String, b[1] as int, b[2] as int),
      ];
    }
  }

  /// حافظه را آزاد می‌کند (با بستن پنجره).
  void release() {
    _bytes = null;
    _starts = Int32List(0);
    index.clear();
    _loading = null;
  }

  List<MiSet> sets(MiBrand b) {
    final bytes = _bytes;
    if (bytes == null) return const [];
    final s = _starts[b.line];
    final e = (b.line + 1 < _starts.length) ? _starts[b.line + 1] - 1 : bytes.length;
    final j = jsonDecode(utf8.decode(Uint8List.sublistView(bytes, s, e))) as Map;
    final pats = j['p'] as List;
    List<int> pat(int i) {
      final p = pats[i] as List;
      return [for (var k = 1; k < p.length; k++) (p[k] as int) * 10];
    }

    IrCode code(Object ref) {
      if (ref is List) {
        final i = ref[0] as int;
        return IrCode('raw', 0, 0, raw: pat(i), rawAlt: pat(ref[1] as int), rawFreq: (pats[i] as List)[0] as int);
      }
      final i = ref as int;
      return IrCode('raw', 0, 0, raw: pat(i), rawFreq: (pats[i] as List)[0] as int);
    }

    return [
      for (final m in (j['s'] as List)) MiSet({for (final e in (m as Map).entries) e.key as String: code(e.value as Object)}),
    ];
  }
}

Future<void> showMiLibrary(BuildContext context, IrController ir) {
  return showDialog<void>(
    context: context,
    builder: (_) => Dialog(
      backgroundColor: const Color(0xff0c1124),
      insetPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: kBlue.withOpacity(0.6)),
      ),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 560, maxHeight: MediaQuery.of(context).size.height * 0.85),
        child: Padding(padding: const EdgeInsets.all(14), child: MiLibraryPanel(ir: ir)),
      ),
    ),
  ).whenComplete(MiDb.instance.release);
}

class MiLibraryPanel extends StatefulWidget {
  final IrController ir;
  const MiLibraryPanel({super.key, required this.ir});
  @override
  State<MiLibraryPanel> createState() => _MiLibraryPanelState();
}

class _MiLibraryPanelState extends State<MiLibraryPanel> {
  String dev = 'tv';
  String query = '';
  bool loading = true;
  String? error;

  MiBrand? brand;
  List<MiSet> sets = const [];
  int n = 0;
  String note = '';

  IrController get ir => widget.ir;

  @override
  void initState() {
    super.initState();
    MiDb.instance.load().then((_) {
      if (mounted) setState(() => loading = false);
    }).catchError((Object e) {
      if (mounted) {
        setState(() {
          loading = false;
          error = 'خواندن کتابخانه ناموفق بود: $e';
        });
      }
    });
  }

  void _open(MiBrand b) {
    final s = MiDb.instance.sets(b);
    setState(() {
      brand = b;
      sets = s;
      n = 0;
      note = '';
    });
  }

  Future<void> _send(IrCode? c) async {
    if (c == null) return;
    if (!ir.hasEmitter) {
      setState(() => note = 'این گوشی فرستنده‌ی IR ندارد');
      return;
    }
    await ir.sendCode(c);
  }

  Future<void> _save() async {
    final b = brand;
    if (b == null || sets.isEmpty) return;
    final ctl = TextEditingController(text: '${b.name} ${n + 1}');
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xff0c1124),
        title: const Text('نام پروفایل', style: TextStyle(fontSize: 15)),
        content: TextField(controller: ctl, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(ctl.text), child: const Text('ذخیره')),
        ],
      ),
    );
    if (name == null) return;
    ir.addMiProfile(name.trim().isEmpty ? '${b.name} ${n + 1}' : name.trim(), sets[n].toProfileCodes());
    if (mounted) Navigator.of(context).pop();
    irMessengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(const SnackBar(content: Text('پروفایل ساخته و فعال شد. اگر دکمه‌ای جابه‌جا بود از «تخصیص دکمه‌ها» درستش کنید.')));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const SizedBox(height: 160, child: Center(child: CircularProgressIndicator()));
    }
    if (error != null) {
      return Column(mainAxisSize: MainAxisSize.min, children: [
        Text(error!, style: const TextStyle(color: Color(0xffffa23c))),
        TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('بستن')),
      ]);
    }
    return brand == null ? _brandList() : _setsPage();
  }

  Widget _brandList() {
    final all = MiDb.instance.index[dev] ?? const <MiBrand>[];
    final q = query.trim().toLowerCase();
    final list = q.isEmpty ? all : all.where((b) => b.name.toLowerCase().contains(q)).toList();
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Text('کتابخانه‌ی کدهای Mi Remote',
          textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Wrap(spacing: 6, runSpacing: 4, alignment: WrapAlignment.center, children: [
        for (final d in kMiDevices)
          ChoiceChip(
            label: Text(d.value, style: const TextStyle(fontSize: 12)),
            selected: dev == d.key,
            onSelected: (_) => setState(() => dev = d.key),
          ),
      ]),
      const SizedBox(height: 6),
      TextField(
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'نام برند (مثلاً philips)'),
        onChanged: (v) => setState(() => query = v),
      ),
      const SizedBox(height: 4),
      Text('${list.length} برند', style: const TextStyle(fontSize: 11, color: kHint), textAlign: TextAlign.center),
      Flexible(
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: list.length,
          itemBuilder: (_, i) => ListTile(
            dense: true,
            title: Text(list[i].name),
            trailing: Text('${list[i].sets} مجموعه', style: const TextStyle(fontSize: 11, color: kHint)),
            onTap: () => _open(list[i]),
          ),
        ),
      ),
      TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('بستن')),
    ]);
  }

  static const _tests = <MapEntry<String, String>>[
    MapEntry('vol+', 'صدا +'),
    MapEntry('vol-', 'صدا −'),
    MapEntry('ch+', 'کانال +'),
    MapEntry('ch-', 'کانال −'),
    MapEntry('mute', 'بی‌صدا'),
    MapEntry('up', 'بالا'),
    MapEntry('down', 'پایین'),
    MapEntry('left', 'چپ'),
    MapEntry('right', 'راست'),
    MapEntry('ok', 'OK'),
    MapEntry('enter', 'Enter'),
    MapEntry('menu', 'منو'),
    MapEntry('tv_av', 'ورودی'),
    MapEntry('input', 'Input'),
    MapEntry('source', 'Source'),
    MapEntry('back', 'برگشت'),
    MapEntry('home', 'خانه'),
  ];

  Widget _setsPage() {
    final b = brand!;
    final cur = sets.isEmpty ? null : sets[n];
    return SingleChildScrollView(
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          IconButton(onPressed: () => setState(() => brand = null), icon: const Icon(Icons.arrow_back)),
          Expanded(
            child: Text(b.name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(width: 48),
        ]),
        const SizedBox(height: 6),
        const Text(
          'گوشی را رو به دستگاه بگیرید و دکمه‌ی پاور را بزنید. اگر واکنش نشان داد، چند دکمه‌ی دیگر را هم امتحان کنید، بعد ذخیره کنید.',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12, color: kHint),
        ),
        const SizedBox(height: 10),
        Text('مجموعه‌ی ${n + 1} از ${sets.length}',
            textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: kCyan)),
        Text('${cur?.byName.length ?? 0} دکمه • ${cur?.power?.label ?? ''}',
            textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: kHint)),
        const SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          IconButton.outlined(
            onPressed: n > 0 ? () => setState(() => n--) : null,
            icon: const Icon(Icons.chevron_left),
            tooltip: 'قبلی',
          ),
          const SizedBox(width: 16),
          InkWell(
            onTap: () => _send(cur?.power),
            customBorder: const CircleBorder(),
            child: Container(
              width: 88,
              height: 88,
              decoration: const BoxDecoration(shape: BoxShape.circle, color: Color(0xff00a878)),
              child: const Icon(Icons.power_settings_new, size: 44, color: Colors.white),
            ),
          ),
          const SizedBox(width: 16),
          IconButton.outlined(
            onPressed: n < sets.length - 1 ? () => setState(() => n++) : null,
            icon: const Icon(Icons.chevron_right),
            tooltip: 'بعدی',
          ),
        ]),
        const SizedBox(height: 10),
        const Text('تست دکمه‌های دیگر این مجموعه', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: kHint)),
        const SizedBox(height: 4),
        Wrap(spacing: 6, runSpacing: 2, alignment: WrapAlignment.center, children: [
          for (final t in _tests)
            if (cur?.byName.containsKey(t.key) ?? false)
              ActionChip(label: Text(t.value, style: const TextStyle(fontSize: 11)), onPressed: () => _send(cur!.byName[t.key])),
        ]),
        if (note.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(note, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Color(0xffffa23c))),
          ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: cur == null ? null : _save,
          icon: const Icon(Icons.check),
          label: const Text('کار می‌کند → ذخیره‌ی پروفایل'),
          style: FilledButton.styleFrom(backgroundColor: const Color(0xff1f9d55)),
        ),
      ]),
    );
  }
}
