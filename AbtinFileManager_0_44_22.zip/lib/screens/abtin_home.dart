import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart' hide Icon;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../widgets/app_icon.dart';
import '../widgets/neon_kit.dart';
import '../widgets/ui.dart';
import 'browser_screen.dart';
import 'home_cats.dart';
import 'home_variants.dart' show StorageBuilder;
import 'feature_catalog.dart';

String tr2(String fa, String en) => L.lang == 'fa' ? fa : en;

/// Reference-inspired Abtin home screen. The artwork and proportions scale with the device.
class AbtinHome extends StatelessWidget {
  const AbtinHome({super.key});

  void _push(BuildContext context, Widget page) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  void _openCategory(BuildContext context, String key) {
    final category = homeCat(homeCats(), key);
    if (category != null) _push(context, category.page);
  }

  Future<void> _newFolder(BuildContext context) async {
    final name = await promptText(context, tr2('ایجاد پوشه', 'Create folder'));
    if (name == null || name.trim().isEmpty || !context.mounted) return;
    final ok =
        await busy(context, () => FileOps.mkdir(FileOps.root, name.trim()));
    if (ok && context.mounted)
      snack(
          context, '${tr2('پوشه ساخته شد', 'Folder created')}: ${name.trim()}');
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final k = (width / 393).clamp(.86, 1.18).toDouble();
    final roots = FileOps.roots();
    final dark = Theme.of(context).brightness == Brightness.dark;
    final page = Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton:
          _AddFolderButton(k: k, onTap: () => _newFolder(context)),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      body: SafeArea(
        bottom: false,
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: ListView(
            padding: EdgeInsets.fromLTRB(13 * k, 6 * k, 13 * k, 92 * k),
            children: [
              _BrandHeader(k: k, dark: dark),
              SizedBox(height: 11 * k),
              _StorageStack(
                  roots: roots,
                  k: k,
                  dark: dark,
                  onOpen: (r) => _push(context,
                      BrowserScreen(initialPath: r.path, root: true))),
              SizedBox(height: 12 * k),
              _QuickCategories(
                  k: k,
                  dark: dark,
                  onOpen: (key) {
                    _openCategory(context, key);
                  }),
              FeatureSections(k: k, dark: dark),
            ],
          ),
        ),
      ),
    );
    return Directionality(
        textDirection: TextDirection.ltr, child: NeonBackdrop(child: page));
  }
}

class _BrandHeader extends StatelessWidget {
  final double k;
  final bool dark;
  const _BrandHeader({required this.k, required this.dark});

  @override
  Widget build(BuildContext context) {
    final ink = dark ? const Color(0xFFF2F5FF) : const Color(0xFF172447);
    return SizedBox(
      height: 66 * k,
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          Container(
            width: 51 * k,
            height: 51 * k,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [
                Color(0xFF1225B8),
                Color(0xFF4A16E8),
                Color(0xFF0C71EF)
              ], begin: Alignment.topLeft, end: Alignment.bottomRight),
              border: Border.all(color: const Color(0xFF398AFF), width: 1.2),
              boxShadow: [
                BoxShadow(
                    color:
                        const Color(0xFF5427FF).withOpacity(dark ? .55 : .22),
                    blurRadius: 15 * k)
              ],
            ),
            child: Icon(Icons.folder_copy_rounded,
                size: 31 * k, color: const Color(0xFF78D8FF)),
          ),
          SizedBox(width: 12 * k),
          Expanded(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                RichText(
                    text: TextSpan(
                        style: TextStyle(
                            fontSize: 18 * k,
                            fontWeight: FontWeight.w700,
                            color: ink),
                        children: const [
                      TextSpan(text: 'Abtin '),
                      TextSpan(
                          text: 'File Manager',
                          style: TextStyle(color: Color(0xFF17C9EF))),
                    ])),
                SizedBox(height: 2 * k),
                Text(
                    tr2('مدیریت فایل‌های شما',
                        'Your files, beautifully managed'),
                    style: TextStyle(
                        fontSize: 11.5 * k, color: ink.withOpacity(.72))),
              ])),
          Container(
              width: 9 * k,
              height: 9 * k,
              decoration: const BoxDecoration(
                  color: Color(0xFF00DF91),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: Color(0xAA00DF91), blurRadius: 8)
                  ])),
          SizedBox(width: 4 * k),
        ]),
      ),
    );
  }
}

class _StorageStack extends StatelessWidget {
  final List<StorageRoot> roots;
  final double k;
  final bool dark;
  final void Function(StorageRoot) onOpen;
  const _StorageStack(
      {required this.roots,
      required this.k,
      required this.dark,
      required this.onOpen});

  @override
  Widget build(BuildContext context) {
    final sdCount = roots.where((r) => r.sd && !r.usb).length;
    final usbCount = roots.where((r) => r.usb).length;
    var sdN = 0, usbN = 0;
    final cards = <Widget>[];
    for (final r in roots) {
      late final String title;
      late final CustomPainter icon;
      late final Color bar;
      if (!r.sd) {
        title = tr2('حافظه داخلی', 'Internal storage');
        icon = _MiniDiskPainter(dark);
        bar = const Color(0xFF923AFF);
      } else if (r.usb) {
        usbN++;
        title = tr2('فلش / OTG', 'USB / OTG') + (usbCount > 1 ? ' $usbN' : '');
        icon = const _UsbPainter();
        bar = const Color(0xFF4D7CFF);
      } else {
        sdN++;
        title = tr2('کارت حافظه', 'SD card') + (sdCount > 1 ? ' $sdN' : '');
        icon = const _SdPainter();
        bar = const Color(0xFF09D6E8);
      }
      cards.add(Padding(
        padding: EdgeInsets.only(bottom: 9 * k),
        child: StorageBuilder(
            root: r,
            builder: (total, used) => _DriveCard(
                k: k,
                dark: dark,
                icon: icon,
                title: title,
                bar: bar,
                ratio: total == 0
                    ? 0.0
                    : (used / total).clamp(0.0, 1.0).toDouble(),
                detail: total == 0
                    ? '…'
                    : '${FileOps.fmt(used)} / ${FileOps.fmt(total)}',
                onTap: () => onOpen(r))),
      ));
    }
    cards.add(_RamCard(k: k, dark: dark));
    return Column(children: cards);
  }
}

class _DriveCard extends StatelessWidget {
  final double k;
  final bool dark;
  final CustomPainter icon;
  final String title, detail;
  final Color bar;
  final double ratio;
  final VoidCallback? onTap;
  const _DriveCard(
      {required this.k,
      required this.dark,
      required this.icon,
      required this.title,
      required this.detail,
      required this.bar,
      required this.ratio,
      this.onTap});

  @override
  Widget build(BuildContext context) {
    final ink = dark ? const Color(0xFFEAF0FF) : const Color(0xFF18254A);
    return Container(
      height: 78 * k,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22 * k),
        gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: dark
                ? const [Color(0xFF111A49), Color(0xFF10245A), Color(0xFF0A1D4A)]
                : const [Color(0xFFEAF5FF), Color(0xFFDDEBFF), Color(0xFFE9E8FF)]),
        border: Border.all(
            color: const Color(0xFF506EFF).withOpacity(dark ? .8 : .65),
            width: 1.1),
        boxShadow: [
          BoxShadow(
              color: const Color(0xFF206BFF).withOpacity(dark ? .23 : .12),
              blurRadius: 13 * k)
        ],
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(22 * k),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 12 * k, vertical: 8 * k),
            child: Row(children: [
              SizedBox(
                  width: 58 * k,
                  height: 60 * k,
                  child: CustomPaint(painter: icon)),
              SizedBox(width: 8 * k),
              Expanded(
                  flex: 6,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${(ratio * 100).round()}%',
                            style: TextStyle(
                                color: ink,
                                fontSize: 25 * k,
                                fontWeight: FontWeight.w700,
                                height: 1.02)),
                        SizedBox(height: 2 * k),
                        FittedBox(
                            fit: BoxFit.scaleDown,
                            alignment: AlignmentDirectional.centerStart,
                            child: Text(detail,
                                style: TextStyle(
                                    color: ink.withOpacity(.84),
                                    fontSize: 11.5 * k,
                                    fontWeight: FontWeight.w500))),
                      ])),
              Container(
                  width: 1,
                  height: 54 * k,
                  margin: EdgeInsets.symmetric(horizontal: 10 * k),
                  color: const Color(0xFFADC8FF).withOpacity(.55)),
              Expanded(
                  flex: 5,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                color: ink,
                                fontSize: 13 * k,
                                fontWeight: FontWeight.w600)),
                        SizedBox(height: 6 * k),
                        ClipRRect(
                            borderRadius: BorderRadius.circular(6 * k),
                            child: LinearProgressIndicator(
                                value: ratio,
                                minHeight: 7 * k,
                                backgroundColor: const Color(0xFF233B88)
                                    .withOpacity(dark ? .9 : .25),
                                valueColor:
                                    AlwaysStoppedAnimation<Color>(bar))),
                      ])),
              SizedBox(width: 3 * k),
              if (onTap != null)
                Icon(Icons.chevron_right_rounded, color: ink, size: 22 * k),
            ]),
          ),
        ),
      ),
    );
  }
}

/// RAM usage card (reads /proc/meminfo, refreshed every 3 s). Hidden when it can't be read.
class _RamCard extends StatefulWidget {
  final double k;
  final bool dark;
  const _RamCard({required this.k, required this.dark});
  @override
  State<_RamCard> createState() => _RamCardState();
}

class _RamCardState extends State<_RamCard> {
  Timer? _t;
  int _total = 0, _avail = 0; // kB

  @override
  void initState() {
    super.initState();
    _read();
    _t = Timer.periodic(const Duration(seconds: 3), (_) => _read());
  }

  void _read() {
    int total = 0, avail = 0;
    try {
      for (final l in File('/proc/meminfo').readAsLinesSync()) {
        final m = RegExp(r'^(MemTotal|MemAvailable):\s+(\d+)').firstMatch(l);
        if (m == null) continue;
        if (m.group(1) == 'MemTotal') total = int.parse(m.group(2)!);
        if (m.group(1) == 'MemAvailable') avail = int.parse(m.group(2)!);
      }
    } catch (_) {}
    if (mounted && (total != _total || avail != _avail)) {
      setState(() {
        _total = total;
        _avail = avail;
      });
    }
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_total <= 0) return const SizedBox.shrink();
    final used = (_total - _avail).clamp(0, _total);
    return _DriveCard(
        k: widget.k,
        dark: widget.dark,
        icon: const _RamPainter(),
        title: tr2('حافظه رم', 'RAM'),
        bar: const Color(0xFFFF9A2E),
        ratio: used / _total,
        detail: '${FileOps.fmt(used * 1024)} / ${FileOps.fmt(_total * 1024)}');
  }
}

/// 3D SD card (78x80 design box).
class _SdPainter extends CustomPainter {
  const _SdPainter();
  Path _body(double dx, double dy) => Path()
    ..moveTo(18 + dx, 8 + dy)
    ..lineTo(46 + dx, 8 + dy)
    ..lineTo(60 + dx, 22 + dy)
    ..lineTo(60 + dx, 72 + dy)
    ..quadraticBezierTo(60 + dx, 77 + dy, 55 + dx, 77 + dy)
    ..lineTo(23 + dx, 77 + dy)
    ..quadraticBezierTo(18 + dx, 77 + dy, 18 + dx, 72 + dy)
    ..close();
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 78, size.height / 80);
    canvas.translate(39, 40);
    canvas.rotate(-.26);
    canvas.translate(-39, -40);
    canvas.drawPath(_body(4, 4), Paint()..color = const Color(0xFF0C1E78));
    canvas.drawPath(
        _body(0, 0),
        Paint()
          ..shader = const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF58B4FF), Color(0xFF1E55E6), Color(0xFF1536A8)])
              .createShader(const Rect.fromLTWH(18, 8, 42, 69)));
    canvas.drawPath(
        _body(0, 0),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.4
          ..color = const Color(0xFF9ED7FF));
    for (var i = 0; i < 5; i++) {
      canvas.drawRRect(
          RRect.fromRectAndRadius(Rect.fromLTWH(22.0 + i * 5.6, 11, 3.6, 9),
              const Radius.circular(1)),
          Paint()..color = const Color(0xFFFFC53D));
    }
    final tp = TextPainter(
        text: const TextSpan(
            text: 'SD',
            style: TextStyle(
                color: Colors.white,
                fontSize: 21,
                fontWeight: FontWeight.w900,
                shadows: [Shadow(color: Color(0xFF0C1E78), offset: Offset(1.5, 1.5))])),
        textDirection: TextDirection.ltr)
      ..layout();
    tp.paint(canvas, Offset(39 - tp.width / 2, 44));
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// 3D USB flash drive (78x80 design box).
class _UsbPainter extends CustomPainter {
  const _UsbPainter();
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 78, size.height / 80);
    canvas.translate(39, 40);
    canvas.rotate(-.5);
    canvas.translate(-39, -40);
    RRect rr(double l, double t, double w, double h, double r) =>
        RRect.fromRectAndRadius(Rect.fromLTWH(l, t, w, h), Radius.circular(r));
    // body extrusion + body
    canvas.drawRRect(rr(25, 30, 30, 46, 7), Paint()..color = const Color(0xFF0A1A66));
    canvas.drawRRect(
        rr(22, 27, 30, 46, 7),
        Paint()
          ..shader = const LinearGradient(
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                  colors: [Color(0xFF2D6BFF), Color(0xFF8CCBFF), Color(0xFF1B3FC8)])
              .createShader(const Rect.fromLTWH(22, 27, 30, 46)));
    // metal connector
    canvas.drawRRect(
        rr(26, 6, 22, 24, 2.5),
        Paint()
          ..shader = const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFF4F8FF), Color(0xFF8FA0C8)])
              .createShader(const Rect.fromLTWH(26, 6, 22, 24)));
    canvas.drawRRect(rr(30, 12, 5, 8, 1), Paint()..color = const Color(0xFF1A2766));
    canvas.drawRRect(rr(39, 12, 5, 8, 1), Paint()..color = const Color(0xFF1A2766));
    // usb mark + strap hole
    final mark = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.2
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(const Offset(37, 40), const Offset(37, 62), mark);
    canvas.drawCircle(const Offset(37, 64), 2.8, Paint()..color = Colors.white);
    canvas.drawLine(const Offset(37, 48), const Offset(30, 43), mark);
    canvas.drawLine(const Offset(37, 52), const Offset(44, 47), mark);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// 3D RAM chip (78x80 design box).
class _RamPainter extends CustomPainter {
  const _RamPainter();
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 78, size.height / 80);
    RRect rr(double l, double t, double w, double h, double r) =>
        RRect.fromRectAndRadius(Rect.fromLTWH(l, t, w, h), Radius.circular(r));
    final pin = Paint()..color = const Color(0xFFFFC53D);
    for (var i = 0; i < 6; i++) {
      canvas.drawRRect(rr(14.0 + i * 8.4, 14, 4.6, 10, 1), pin);
      canvas.drawRRect(rr(14.0 + i * 8.4, 56, 4.6, 12, 1), pin);
    }
    canvas.drawRRect(rr(10, 26, 60, 36, 6), Paint()..color = const Color(0xFF5B2200));
    canvas.drawRRect(
        rr(8, 22, 60, 36, 6),
        Paint()
          ..shader = const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFFFFB347), Color(0xFFFF6A1A), Color(0xFFC23B00)])
              .createShader(const Rect.fromLTWH(8, 22, 60, 36)));
    canvas.drawRRect(
        rr(8, 22, 60, 36, 6),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.3
          ..color = const Color(0xFFFFD9A0));
    final tp = TextPainter(
        text: const TextSpan(
            text: 'RAM',
            style: TextStyle(
                color: Colors.white,
                fontSize: 17,
                fontWeight: FontWeight.w900,
                shadows: [Shadow(color: Color(0xFF7A2A00), offset: Offset(1.2, 1.2))])),
        textDirection: TextDirection.ltr)
      ..layout();
    tp.paint(canvas, Offset(38 - tp.width / 2, 40 - tp.height / 2));
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _MiniDiskPainter extends CustomPainter {
  final bool dark;
  const _MiniDiskPainter(this.dark);
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 78, size.height / 80);
    final sidePaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [Color(0xFF2A8BFF), Color(0xFF9BE8FF), Color(0xFF1B50D8)],
        stops: [0, .45, 1],
      ).createShader(const Rect.fromLTWH(6, 0, 66, 80));
    final topPaint = Paint()..color = const Color(0xFFBDF0FF);
    final innerPaint = Paint()..color = const Color(0xFF6FD0FF);
    for (final y in const [50.0, 32.0, 14.0]) {
      final side = Path()
        ..moveTo(6, y)
        ..lineTo(6, y + 14)
        ..cubicTo(6, y + 21, 21, y + 25, 39, y + 25)
        ..cubicTo(57, y + 25, 72, y + 21, 72, y + 14)
        ..lineTo(72, y)
        ..close();
      canvas.drawPath(side, sidePaint);
      canvas.drawOval(
          Rect.fromCenter(center: Offset(39, y), width: 66, height: 22),
          topPaint);
      canvas.drawOval(
          Rect.fromCenter(center: Offset(39, y), width: 28, height: 9),
          innerPaint);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _MiniDiskPainter oldDelegate) =>
      dark != oldDelegate.dark;
}

class _QuickCategories extends StatelessWidget {
  final double k;
  final bool dark;
  final ValueChanged<String> onOpen;
  const _QuickCategories(
      {required this.k, required this.dark, required this.onOpen});
  @override
  Widget build(BuildContext context) {
    const data = [
      ('images', 'images', Color(0xFF22C8D5)),
      ('videos', 'videos', Color(0xFF833BFF)),
      ('music', 'audio', Color(0xFF8D36FF)),
      ('downloads', 'other', Color(0xFF08D3A1)),
    ];
    return Row(children: [
      for (var i = 0; i < data.length; i++) ...[
        if (i > 0) SizedBox(width: 8 * k),
        Expanded(
            child: _QuickTile(
                k: k,
                dark: dark,
                title: L.t(data[i].$1),
                iconKey: data[i].$2,
                accent: data[i].$3,
                onTap: () => onOpen(data[i].$1))),
      ],
    ]);
  }
}

class _QuickTile extends StatelessWidget {
  final double k;
  final bool dark;
  final String title;
  final String iconKey;
  final Color accent;
  final VoidCallback onTap;
  const _QuickTile(
      {required this.k,
      required this.dark,
      required this.title,
      required this.iconKey,
      required this.accent,
      required this.onTap});
  @override
  Widget build(BuildContext context) => Container(
        height: 91 * k,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(17 * k),
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: dark
                  ? [
                      Color.lerp(accent, const Color(0xFF09142E), .45)!,
                      const Color(0xFF0A1431)
                    ]
                  : [
                      Color.lerp(accent, Colors.white, .82)!,
                      const Color(0xFFEDF3FF)
                    ]),
          border: Border.all(
              color: accent.withOpacity(dark ? .7 : .52), width: 1.1),
          boxShadow: [
            BoxShadow(
                color: accent.withOpacity(dark ? .22 : .13), blurRadius: 11 * k)
          ],
        ),
        child: Material(
            color: Colors.transparent,
            child: InkWell(
                borderRadius: BorderRadius.circular(17 * k),
                onTap: onTap,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                          width: 36 * k,
                          height: 34 * k,
                          decoration: BoxDecoration(
                              color: dark
                                  ? accent.withOpacity(.24)
                                  : Colors.white.withOpacity(.78),
                              borderRadius: BorderRadius.circular(9 * k),
                              boxShadow: [
                                BoxShadow(
                                    color: accent.withOpacity(.25),
                                    blurRadius: 7 * k)
                              ]),
                          child: KeyIcon(iconKey, size: 25 * k)),
                      SizedBox(height: 7 * k),
                      Text(title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 11.5 * k,
                              fontWeight: FontWeight.w600,
                              color: dark
                                  ? const Color(0xFFF3F5FF)
                                  : const Color(0xFF17264D))),
                    ]))),
      );
}

class _AddFolderButton extends StatelessWidget {
  final double k;
  final VoidCallback onTap;
  const _AddFolderButton({required this.k, required this.onTap});
  @override
  Widget build(BuildContext context) => Container(
        width: 58 * k,
        height: 58 * k,
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF00C8E9),
                  Color(0xFF164DF2),
                  Color(0xFFE900D5)
                ]),
            border: Border.all(color: const Color(0xFF55E6FF), width: 1.1),
            boxShadow: const [
              BoxShadow(
                  color: Color(0x994B4DFF), blurRadius: 18, spreadRadius: 1)
            ]),
        child: Material(
            color: Colors.transparent,
            child: InkWell(
                onTap: onTap,
                customBorder: const CircleBorder(),
                child: Icon(Icons.add_rounded,
                    color: Colors.white, size: 34 * k))),
      );
}
