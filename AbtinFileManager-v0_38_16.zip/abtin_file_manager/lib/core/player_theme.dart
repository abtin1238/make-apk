import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// A ready-made colour scheme for the video player.
class PlayerPreset {
  final String id, fa, en;
  final Color accent, accent2, highlight;
  const PlayerPreset(this.id, this.fa, this.en, this.accent, this.accent2, this.highlight);
}

/// Look & feel of the video player (neon glass). Independent from the app theme,
/// but one preset can follow the app palette. Everything is persisted.
class PlayerTheme extends ChangeNotifier {
  PlayerTheme._();
  static final PlayerTheme I = PlayerTheme._();

  static const presets = <PlayerPreset>[
    PlayerPreset('violet', 'بنفش آبتین', 'Abtin Violet', Color(0xFF8A2BFF), Color(0xFF5B21B6), Color(0xFFB57BFF)),
    PlayerPreset('neon', 'نئون آبتین', 'Abtin Neon', Color(0xFF2F6BFF), Color(0xFF8B5CF6), Color(0xFF22E4FF)),
    PlayerPreset('ocean', 'اقیانوس', 'Ocean', Color(0xFF00B8D4), Color(0xFF2979FF), Color(0xFF64FFDA)),
    PlayerPreset('sunset', 'غروب', 'Sunset', Color(0xFFFF6D00), Color(0xFFE91E63), Color(0xFFFFD180)),
    PlayerPreset('emerald', 'زمرد', 'Emerald', Color(0xFF00C853), Color(0xFF00BFA5), Color(0xFFB9F6CA)),
    PlayerPreset('rose', 'رز', 'Rose', Color(0xFFFF4081), Color(0xFFAA00FF), Color(0xFFFF80AB)),
    PlayerPreset('gold', 'طلایی', 'Gold', Color(0xFFFFB300), Color(0xFFFF6F00), Color(0xFFFFE082)),
    PlayerPreset('mono', 'مونو', 'Mono', Color(0xFFB0BEC5), Color(0xFF78909C), Color(0xFFFFFFFF)),
  ];

  /// 'app' = follow the app palette, 'custom' = user colours, otherwise a preset id.
  String mode = 'violet';
  Color customAccent = const Color(0xFF00E5FF);
  Color customAccent2 = const Color(0xFFB44CFF);
  Color customHighlight = const Color(0xFF22E4FF);
  double glass = .42; // panel opacity 0.15 .. 0.8
  double glow = .8; // neon strength 0 .. 1
  bool blur = true;
  bool badge = true; // 4K / HDR badges
  bool loaded = false;

  Color? _appPrimary, _appSecondary;

  /// Called from the player with the current app colour scheme (used by the 'app' mode).
  void bindApp(Color primary, Color secondary) {
    _appPrimary = primary;
    _appSecondary = secondary;
  }

  Color get accent {
    if (mode == 'custom') return customAccent;
    if (mode == 'app') return _appPrimary ?? presets.first.accent;
    return _preset.accent;
  }

  Color get accent2 {
    if (mode == 'custom') return customAccent2;
    if (mode == 'app') return _appSecondary ?? presets.first.accent2;
    return _preset.accent2;
  }

  /// Bright colour used for the seek bar, play ring and selected chips.
  Color get highlight {
    if (mode == 'custom') return customHighlight;
    if (mode == 'app') return Color.lerp(accent, Colors.white, .35)!;
    return _preset.highlight;
  }

  PlayerPreset get _preset => presets.firstWhere((e) => e.id == mode, orElse: () => presets.first);

  LinearGradient get gradient => LinearGradient(colors: [accent, accent2], begin: Alignment.topLeft, end: Alignment.bottomRight);
  LinearGradient get seekGradient => LinearGradient(colors: [highlight, accent]);

  Future<void> load() async {
    if (loaded) return;
    try {
      final p = await SharedPreferences.getInstance();
      mode = p.getString('pt_mode') ?? 'violet';
      // one-time: move people who never changed the old default to the new violet "Aptin Music" look
      if (!(p.getBool('pt_mig_violet') ?? false)) {
        if (mode == 'neon') mode = 'violet';
        await p.setBool('pt_mig_violet', true);
        await p.setString('pt_mode', mode);
      }
      customAccent = Color(p.getInt('pt_c1') ?? customAccent.value);
      customAccent2 = Color(p.getInt('pt_c2') ?? customAccent2.value);
      customHighlight = Color(p.getInt('pt_c3') ?? customHighlight.value);
      glass = (p.getDouble('pt_glass') ?? glass).clamp(.15, .8).toDouble();
      glow = (p.getDouble('pt_glow') ?? glow).clamp(0.0, 1.0).toDouble();
      blur = p.getBool('pt_blur') ?? true;
      badge = p.getBool('pt_badge') ?? true;
    } catch (_) {}
    loaded = true;
    notifyListeners();
  }

  Future<void> _save() async {
    notifyListeners();
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('pt_mode', mode);
      await p.setInt('pt_c1', customAccent.value);
      await p.setInt('pt_c2', customAccent2.value);
      await p.setInt('pt_c3', customHighlight.value);
      await p.setDouble('pt_glass', glass);
      await p.setDouble('pt_glow', glow);
      await p.setBool('pt_blur', blur);
      await p.setBool('pt_badge', badge);
    } catch (_) {}
  }

  void setMode(String v) { mode = v; _save(); }
  void setCustom({Color? a, Color? b, Color? c}) {
    mode = 'custom';
    if (a != null) customAccent = a;
    if (b != null) customAccent2 = b;
    if (c != null) customHighlight = c;
    _save();
  }

  void setGlass(double v) { glass = v; _save(); }
  void setGlow(double v) { glow = v; _save(); }
  void setBlur(bool v) { blur = v; _save(); }
  void setBadge(bool v) { badge = v; _save(); }

  void reset() {
    mode = 'violet';
    customAccent = const Color(0xFF00E5FF);
    customAccent2 = const Color(0xFFB44CFF);
    customHighlight = const Color(0xFF22E4FF);
    glass = .42;
    glow = .8;
    blur = true;
    badge = true;
    _save();
  }
}
