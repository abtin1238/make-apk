import 'package:flutter/material.dart';
import 'theme.dart';

/// User-chosen colour / shape of the folder and file-type icons (settings -> icon style).
class IconPrefs {
  static final colors = <String, int>{};
  static final shapes = <String, int>{};

  /// key -> available shapes (index 0 = default)
  static const Map<String, List<IconData>> options = {
    'folder': [Icons.folder_rounded, Icons.folder_outlined, Icons.folder_open_rounded, Icons.folder_special_rounded, Icons.snippet_folder_rounded, Icons.folder_copy_rounded],
    'images': [Icons.image_rounded, Icons.photo_rounded, Icons.photo_library_rounded, Icons.landscape_rounded],
    'videos': [Icons.play_circle_rounded, Icons.movie_rounded, Icons.videocam_rounded, Icons.smart_display_rounded, Icons.theaters_rounded],
    'audio': [Icons.music_note_rounded, Icons.audiotrack_rounded, Icons.headphones_rounded, Icons.library_music_rounded, Icons.equalizer_rounded],
    'docs': [Icons.description_rounded, Icons.article_rounded, Icons.text_snippet_rounded, Icons.sticky_note_2_rounded, Icons.menu_book_rounded],
    'pdf': [Icons.picture_as_pdf_rounded, Icons.picture_as_pdf_outlined, Icons.description_rounded, Icons.article_rounded],
    'apps': [Icons.android_rounded, Icons.apps_rounded, Icons.widgets_rounded, Icons.install_mobile_rounded],
    'archives': [Icons.archive_rounded, Icons.folder_zip_rounded, Icons.inventory_2_rounded, Icons.compress_rounded],
    'other': [Icons.insert_drive_file_rounded, Icons.description_rounded, Icons.attach_file_rounded, Icons.note_rounded],
  };

  static const keys = ['folder', 'images', 'videos', 'audio', 'docs', 'pdf', 'apps', 'archives', 'other'];

  static const palette = <int>[
    0xFFFFB84D, 0xFFFF9F43, 0xFFFF5C7A, 0xFFE53935, 0xFFEC407A, 0xFF8B5CF6, 0xFF2F6BFF,
    0xFF29B6F6, 0xFF26C6DA, 0xFF2ECC71, 0xFF9CCC65, 0xFFF5A623, 0xFF8D6E63, 0xFF78909C, 0xFFFFFFFF,
  ];

  static Color defaultColor(String key) {
    switch (key) {
      case 'folder': return const Color(0xFFFFB84D);
      case 'images': return const Color(0xFF2ECC71);
      case 'videos': return AppColors.purple;
      case 'audio': return AppColors.gold;
      case 'docs':
      case 'pdf': return const Color(0xFFFF5C7A);
      case 'apps': return const Color(0xFF3DDC84);
      case 'archives': return const Color(0xFFFF9F43);
      default: return Colors.blueGrey;
    }
  }

  static Color color(String key) => colors[key] != null ? Color(colors[key]!) : defaultColor(key);

  static IconData icon(String key) {
    final l = options[key] ?? options['other']!;
    final i = shapes[key] ?? 0;
    return l[i >= 0 && i < l.length ? i : 0];
  }
}
