import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'icon_prefs.dart';
import '../services/copy_job.dart';
import 'l10n.dart';

class AppSettings extends ChangeNotifier {
  late SharedPreferences _p;
  bool dark = true, showHidden = false, confirmDelete = true, asc = true, trashEnabled = true, grid = false, folderSizes = true, dual = false, bgCopy = true;
  int themeId = 0;
  String audioStyle = 'vinyl'; // music player look: 'vinyl' | 'neon'
  int sortBy = 0; // 0 name 1 size 2 date 3 type
  bool sortPerFolder = false; // new sort choices apply to the current folder only
  final Map<String, List<int>> folderSort = {}; // path -> [sortBy, asc ? 1 : 0]
  List<String> favorites = [], recents = [];

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    dark = _p.getBool('dark') ?? true;
    themeId = _p.getInt('themeId') ?? 0;
    audioStyle = _p.getString('audioStyle') ?? 'vinyl';
    showHidden = _p.getBool('hidden') ?? false;
    confirmDelete = _p.getBool('confirm') ?? true;
    asc = _p.getBool('asc') ?? true;
    trashEnabled = _p.getBool('trash') ?? true;
    grid = _p.getBool('grid') ?? false;
    folderSizes = _p.getBool('fsize') ?? true;
    dual = _p.getBool('dual') ?? false;
    bgCopy = _p.getBool('bgCopy') ?? true;
    CopyJob.background = bgCopy;
    try {
      final m = jsonDecode(_p.getString('iconPrefs') ?? '{}') as Map;
      IconPrefs.colors..clear()..addAll({for (final e in (m['c'] as Map? ?? {}).entries) '${e.key}': (e.value as num).toInt()});
      IconPrefs.shapes..clear()..addAll({for (final e in (m['s'] as Map? ?? {}).entries) '${e.key}': (e.value as num).toInt()});
    } catch (_) {}
    sortBy = _p.getInt('sort') ?? 0;
    sortPerFolder = _p.getBool('sortPerFolder') ?? false;
    try {
      final m = jsonDecode(_p.getString('folderSort') ?? '{}') as Map;
      folderSort..clear()..addAll({for (final e in m.entries) '${e.key}': [for (final x in (e.value as List)) (x as num).toInt()]});
    } catch (_) {}
    L.use(_p.getString('lang') ?? 'fa');
    favorites = _p.getStringList('fav') ?? [];
    recents = _p.getStringList('recent') ?? [];
  }

  void _save() => notifyListeners();
  void setDark(bool v) { dark = v; _p.setBool('dark', v); _save(); }
  void setAudioStyle(String v) { audioStyle = v; _p.setString('audioStyle', v); _save(); }
  void setThemeId(int v) { themeId = v; _p.setInt('themeId', v); _save(); }
  void setHidden(bool v) { showHidden = v; _p.setBool('hidden', v); _save(); }
  void setConfirm(bool v) { confirmDelete = v; _p.setBool('confirm', v); _save(); }
  void setBgCopy(bool v) { bgCopy = v; CopyJob.background = v; _p.setBool('bgCopy', v); _save(); }
  void setDual(bool v) { dual = v; _p.setBool('dual', v); _save(); }
  void _saveIcons() {
    _p.setString('iconPrefs', jsonEncode({'c': IconPrefs.colors, 's': IconPrefs.shapes}));
    _save();
  }
  void setIconColor(String key, int? c) { c == null ? IconPrefs.colors.remove(key) : IconPrefs.colors[key] = c; _saveIcons(); }
  void setIconShape(String key, int? i) { i == null ? IconPrefs.shapes.remove(key) : IconPrefs.shapes[key] = i; _saveIcons(); }
  void resetIcons() { IconPrefs.colors.clear(); IconPrefs.shapes.clear(); _saveIcons(); }
  void setGrid(bool v) { grid = v; _p.setBool('grid', v); _save(); }
  void setFolderSizes(bool v) { folderSizes = v; _p.setBool('fsize', v); _save(); }
  void setTrash(bool v) { trashEnabled = v; _p.setBool('trash', v); _save(); }
  void setLang(String v) { L.use(v); _p.setString('lang', v); _save(); }
  void setSort(int s, bool a) { sortBy = s; asc = a; _p.setInt('sort', s); _p.setBool('asc', a); _save(); }
  /// Sort of [path]: its own setting when it has one, else the global one.
  (int, bool) sortFor(String path) {
    final o = folderSort[path];
    return o == null || o.length < 2 ? (sortBy, asc) : (o[0], o[1] == 1);
  }

  bool hasFolderSort(String path) => folderSort.containsKey(path);
  void _saveFolderSort() { _p.setString('folderSort', jsonEncode(folderSort)); _save(); }
  void setFolderSort(String path, int s, bool a) { folderSort[path] = [s, a ? 1 : 0]; _saveFolderSort(); }
  void clearFolderSort(String path) { folderSort.remove(path); _saveFolderSort(); }
  void setSortPerFolder(bool v) { sortPerFolder = v; _p.setBool('sortPerFolder', v); _save(); }
  bool isFav(String path) => favorites.contains(path);
  void toggleFav(String path) {
    isFav(path) ? favorites.remove(path) : favorites.add(path);
    _p.setStringList('fav', favorites);
    _save();
  }
  void renamePath(String from, String to) {
    String m(String x) => x == from ? to : (x.startsWith('$from/') ? to + x.substring(from.length) : x);
    favorites = favorites.map(m).toList();
    recents = recents.map(m).toList();
    _p.setStringList('fav', favorites);
    _p.setStringList('recent', recents);
    if (folderSort.keys.any((k) => m(k) != k)) {
      final moved = {for (final e in folderSort.entries) m(e.key): e.value};
      folderSort..clear()..addAll(moved);
      _p.setString('folderSort', jsonEncode(folderSort));
    }
    _save();
  }
  void removePath(String path) {
    bool g(String x) => x == path || x.startsWith('$path/');
    favorites.removeWhere(g);
    recents.removeWhere(g);
    _p.setStringList('fav', favorites);
    _p.setStringList('recent', recents);
    if (folderSort.keys.any(g)) {
      folderSort.removeWhere((k, _) => g(k));
      _p.setString('folderSort', jsonEncode(folderSort));
    }
    _save();
  }
  void addRecent(String path) {
    recents.remove(path);
    recents.insert(0, path);
    if (recents.length > 60) recents.removeLast();
    _p.setStringList('recent', recents);
    notifyListeners();
  }
}
