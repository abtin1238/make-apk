import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../services/file_ops.dart';
import '../services/folder_sizes.dart';
import '../services/thumbs.dart';
import 'ui.dart';

/// Image thumbnail / video frame / APK icon / folder or file icon.
class FileThumb extends StatefulWidget {
  final FItem item;
  final double size;
  const FileThumb({super.key, required this.item, this.size = 44});
  @override
  State<FileThumb> createState() => _FileThumbState();
}

class _FileThumbState extends State<FileThumb> {
  Future<Uint8List?>? _f;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(FileThumb old) {
    super.didUpdateWidget(old);
    if (old.item.path != widget.item.path || old.item.modified != widget.item.modified) _load();
  }

  void _load() {
    final i = widget.item;
    if (i.isDir) {
      _f = null;
    } else if (FileOps.isCat(i.path, Cat.videos)) {
      _f = Thumbs.video(i);
    } else if (FileOps.ext(i.path) == 'apk') {
      _f = Thumbs.apkIcon(i);
    } else {
      _f = null;
    }
  }

  Widget _icon(double s) => Icon(iconFor(widget.item.path, widget.item.isDir), color: colorFor(widget.item.path, widget.item.isDir), size: s * .8);

  @override
  Widget build(BuildContext context) {
    final i = widget.item, s = widget.size;
    Widget child;
    if (!i.isDir && FileOps.isCat(i.path, Cat.images) && FileOps.ext(i.path) != 'svg') {
      child = ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Image.file(File(i.path), width: s, height: s, fit: BoxFit.cover, cacheWidth: (s * 3).round().clamp(96, 600), errorBuilder: (_, __, ___) => _icon(s)),
      );
    } else if (_f != null) {
      final apk = FileOps.ext(i.path) == 'apk';
      child = FutureBuilder<Uint8List?>(
        future: _f,
        builder: (_, snap) {
          final d = snap.data;
          if (d == null) return _icon(s);
          if (apk) return Padding(padding: EdgeInsets.all(s * .08), child: Image.memory(d, fit: BoxFit.contain, gaplessPlayback: true));
          return ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Stack(fit: StackFit.expand, children: [
              Image.memory(d, fit: BoxFit.cover, gaplessPlayback: true),
              Align(
                alignment: Alignment.bottomRight,
                child: Container(
                  margin: const EdgeInsets.all(2),
                  decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                  child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: (s * .28).clamp(12, 26).toDouble()),
                ),
              ),
            ]),
          );
        },
      );
    } else {
      child = _icon(s);
    }
    return SizedBox(width: s, height: s, child: Center(child: child));
  }
}

/// Folder size line (`12.4 MB • date`), cached and refreshed in the background.
class FolderSizeText extends StatefulWidget {
  final String path;
  final DateTime modified;
  final String suffix;
  final TextStyle? style;
  const FolderSizeText({super.key, required this.path, required this.modified, this.suffix = '', this.style});
  @override
  State<FolderSizeText> createState() => _FolderSizeTextState();
}

class _FolderSizeTextState extends State<FolderSizeText> {
  int? size;

  @override
  void initState() {
    super.initState();
    _check();
  }

  @override
  void didUpdateWidget(FolderSizeText old) {
    super.didUpdateWidget(old);
    _check();
  }

  void _check() {
    size = FolderSizes.cached(widget.path);
    if (!FolderSizes.fresh(widget.path, widget.modified)) {
      final path = widget.path;
      FolderSizes.get(path, mtime: widget.modified).then((v) {
        if (mounted && widget.path == path) setState(() => size = v);
      });
    }
  }

  @override
  Widget build(BuildContext context) => Text(
        '${size == null ? '…' : FileOps.fmt(size!)}${widget.suffix}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: widget.style,
      );
}
