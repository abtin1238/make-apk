import 'package:flutter/material.dart';
import '../core/theme.dart';

/// Dots + numeric keypad. Calls [onComplete] as soon as [length] digits were typed, then clears itself.
class PinEntry extends StatefulWidget {
  final int length;
  final Future<void> Function(String pin) onComplete;
  final IconData? extraIcon; // bottom-left key (fingerprint button)
  final VoidCallback? onExtra;
  final bool enabled;
  const PinEntry({super.key, required this.length, required this.onComplete, this.extraIcon, this.onExtra, this.enabled = true});
  @override
  State<PinEntry> createState() => _PinEntryState();
}

class _PinEntryState extends State<PinEntry> {
  String _v = '';
  bool _busy = false;

  Future<void> _digit(String d) async {
    if (!widget.enabled || _busy || _v.length >= widget.length) return;
    setState(() => _v += d);
    if (_v.length == widget.length) {
      final v = _v;
      _busy = true;
      try {
        await widget.onComplete(v);
      } finally {
        _busy = false;
        if (mounted) setState(() => _v = '');
      }
    }
  }

  void _back() {
    if (_busy || _v.isEmpty) return;
    setState(() => _v = _v.substring(0, _v.length - 1));
  }

  Widget _key(Widget child, VoidCallback? onTap) => Padding(
        padding: const EdgeInsets.all(6),
        child: SizedBox(
          width: 72, height: 72,
          child: Material(
            color: Theme.of(context).cardColor,
            shape: const CircleBorder(),
            child: InkWell(customBorder: const CircleBorder(), onTap: widget.enabled ? onTap : null, child: Center(child: child)),
          ),
        ),
      );

  Widget _num(String d) => _key(Text(d, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w500)), () => _digit(d));

  @override
  Widget build(BuildContext context) {
    final on = AppColors.blue, off = Theme.of(context).disabledColor;
    // digits and keypad always read left-to-right, also in Persian
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (var i = 0; i < widget.length; i++)
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 6),
              width: 14, height: 14,
              decoration: BoxDecoration(shape: BoxShape.circle, color: i < _v.length ? on : Colors.transparent, border: Border.all(color: i < _v.length ? on : off, width: 2)),
            ),
        ]),
        const SizedBox(height: 28),
        for (final row in const [['1', '2', '3'], ['4', '5', '6'], ['7', '8', '9']])
          Row(mainAxisSize: MainAxisSize.min, children: [for (final d in row) _num(d)]),
        Row(mainAxisSize: MainAxisSize.min, children: [
          widget.extraIcon != null ? _key(Icon(widget.extraIcon, size: 30), widget.onExtra) : const SizedBox(width: 84, height: 84),
          _num('0'),
          _key(const Icon(Icons.backspace_outlined), _back),
        ]),
      ]),
    );
  }
}
