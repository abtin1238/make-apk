import 'package:flutter/material.dart';
import '../core/l10n.dart';
import '../core/icon_prefs.dart';
import '../core/theme.dart';
import '../services/file_ops.dart';

String iconKey(String path, bool dir) {
  if (dir) return 'folder';
  switch (FileOps.catOf(path)) {
    case Cat.images: return 'images';
    case Cat.videos: return 'videos';
    case Cat.audio: return 'audio';
    case Cat.docs: return FileOps.ext(path) == 'pdf' ? 'pdf' : 'docs';
    case Cat.apps: return 'apps';
    case Cat.archives: return 'archives';
    default: return 'other';
  }
}

IconData iconFor(String path, bool dir) => IconPrefs.icon(iconKey(path, dir));

Color colorFor(String path, bool dir) => IconPrefs.color(iconKey(path, dir));

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c).hideCurrentSnackBar();
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));
}

Future<String?> promptText(BuildContext c, String title, {String initial = '', bool obscure = false}) {
  final ctl = TextEditingController(text: initial);
  final dot = initial.lastIndexOf('.');
  ctl.selection = TextSelection(baseOffset: 0, extentOffset: dot > 0 ? dot : initial.length);
  return showDialog<String>(
    context: c,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: ctl, autofocus: true, obscureText: obscure,
        onSubmitted: (v) => Navigator.pop(c, v.trim()),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: Text(L.t('cancel'))),
        FilledButton(onPressed: () => Navigator.pop(c, ctl.text.trim()), child: Text(L.t('ok'))),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      content: Text(msg),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: Text(L.t('cancel'))),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(L.t('ok'))),
      ],
    ),
  );
  return r ?? false;
}

/// Runs [job] behind a blocking spinner; shows error in a snackbar.
Future<bool> busy(BuildContext c, Future<void> Function() job) async {
  showDialog(
    context: c,
    barrierDismissible: false,
    builder: (_) => const PopScope(canPop: false, child: Center(child: CircularProgressIndicator())),
  );
  var ok = true;
  try {
    await job();
  } catch (e) {
    ok = false;
    final msg = e is OpError ? (e.arg == null ? L.t(e.key) : '${L.t(e.key)}: ${e.arg}') : '${L.t('error')}: $e';
    if (c.mounted) snack(c, msg);
  }
  if (c.mounted) Navigator.of(c, rootNavigator: true).pop();
  return ok;
}

/// Like [busy] but shows a title and a percentage bar. The job reports its
/// progress through the callback: 0..1, or null for "unknown" (indeterminate).
Future<bool> busyProgress(BuildContext c, String title, Future<void> Function(void Function(double?) report) job) async {
  final prog = ValueNotifier<double?>(null);
  showDialog(
    context: c,
    barrierDismissible: false,
    builder: (_) => PopScope(
      canPop: false,
      child: AlertDialog(
        title: Text(title),
        content: ValueListenableBuilder<double?>(
          valueListenable: prog,
          builder: (_, v, __) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            LinearProgressIndicator(value: v, minHeight: 8, borderRadius: BorderRadius.circular(6)),
            const SizedBox(height: 8),
            Text(v == null ? '…' : '${(v * 100).clamp(0, 100).round()}%'),
          ]),
        ),
      ),
    ),
  );
  var ok = true;
  try {
    await job((v) => prog.value = v);
  } catch (e) {
    ok = false;
    final msg = e is OpError ? (e.arg == null ? L.t(e.key) : '${L.t(e.key)}: ${e.arg}') : '${L.t('error')}: $e';
    if (c.mounted) snack(c, msg);
  }
  if (c.mounted) Navigator.of(c, rootNavigator: true).pop();
  prog.dispose();
  return ok;
}

class GradCard extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  const GradCard({super.key, required this.child, this.onTap, this.padding = const EdgeInsets.all(14)});
  @override
  Widget build(BuildContext context) => Material(
        color: Theme.of(context).cardColor,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(borderRadius: BorderRadius.circular(18), onTap: onTap, child: Padding(padding: padding, child: child)),
      );
}
