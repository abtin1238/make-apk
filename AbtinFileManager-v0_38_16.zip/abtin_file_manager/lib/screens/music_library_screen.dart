import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../core/theme.dart';
import '../services/file_ops.dart';
import '../services/player_service.dart';
import '../services/playlist_store.dart';
import '../widgets/ui.dart';
import 'audio_player_screen.dart';
import 'opener.dart';
import 'playlist_screens.dart';

/// Music only (no videos): songs, albums, artists, folders, favourites, playlists.
class MusicLibraryScreen extends StatefulWidget {
  const MusicLibraryScreen({super.key});
  @override
  State<MusicLibraryScreen> createState() => _MusicLibraryScreenState();
}

class _MusicLibraryScreenState extends State<MusicLibraryScreen> {
  final audios = <FItem>[];
  bool done = false;
  String q = '';

  @override
  void initState() {
    super.initState();
    _scan();
  }

  Future<void> _scan() async {
    var n = 0;
    await for (final f in FileOps.walk(FileOps.root, skipAndroid: true)) {
      if (!mounted) return;
      if (FileOps.catOf(f.path) != Cat.audio) continue;
      try {
        final s = await f.stat();
        audios.add(FItem(f, false, s.size, s.modified));
      } catch (_) {}
      if (++n % 25 == 0) setState(() {});
    }
    audios.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    if (mounted) setState(() => done = true);
    await TagCache.scan([for (final a in audios) MapEntry(a.path, a.size)], () => mounted, () { if (mounted) setState(() {}); });
  }

  bool _match(FItem i) => q.isEmpty || i.name.toLowerCase().contains(q);

  Future<void> _playAll({bool shuffle = false}) async {
    final list = audios.where(_match).map((e) => e.path).toList();
    if (list.isEmpty) return;
    if (shuffle) list.shuffle();
    await context.read<PlayerService>().playList(list, 0);
    if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const AudioPlayerScreen()));
  }

  Widget _tile(FItem it, List<FItem> list) {
    final t = TagCache.get(it.path, it.size);
    final title = (t != null && t[0].isNotEmpty) ? t[0] : p.basenameWithoutExtension(it.name);
    final sub = (t != null && t[1].isNotEmpty) ? t[1] : p.basename(p.dirname(it.path));
    return ListTile(
      leading: const CircleAvatar(backgroundColor: Colors.black26, child: Icon(Icons.music_note_rounded, color: AppColors.gold)),
      title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text('$sub • ${FileOps.fmt(it.size)} • ${FileOps.dt(it.modified)}', maxLines: 1, style: const TextStyle(fontSize: 11)),
      onTap: () => Opener.open(context, it.path, siblings: list.map((e) => e.path).toList()),
    );
  }

  Widget _songs() {
    final list = audios.where(_match).toList();
    return Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
        child: Row(children: [
          Expanded(child: FilledButton.icon(icon: const Icon(Icons.play_arrow_rounded), label: Text(L.t('playAll')), onPressed: list.isEmpty ? null : () => _playAll())),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.shuffle_rounded), label: Text(L.t('shuffle')), onPressed: list.isEmpty ? null : () => _playAll(shuffle: true))),
        ]),
      ),
      Expanded(
        child: list.isEmpty
            ? Center(child: done ? Text(L.t('empty')) : const CircularProgressIndicator())
            : ListView.builder(itemCount: list.length, itemBuilder: (_, i) => _tile(list[i], list)),
      ),
    ]);
  }

  /// idx: 1 = artist, 2 = album (same layout as TagCache values).
  Map<String, List<String>> _group(int idx) {
    final m = <String, List<String>>{};
    for (final a in audios) {
      final t = TagCache.get(a.path, a.size);
      var k = t == null ? '' : t[idx];
      if (k.isEmpty && idx == 2) k = p.basename(p.dirname(a.path));
      if (q.isNotEmpty && !k.toLowerCase().contains(q) && !a.name.toLowerCase().contains(q)) continue;
      m.putIfAbsent(k, () => []).add(a.path);
    }
    return m;
  }

  Widget _folders() {
    final m = <String, List<FItem>>{};
    for (final i in audios) {
      m.putIfAbsent(p.dirname(i.path), () => []).add(i);
    }
    final keys = m.keys.where((k) => q.isEmpty || p.basename(k).toLowerCase().contains(q)).toList()
      ..sort((a, b) => p.basename(a).toLowerCase().compareTo(p.basename(b).toLowerCase()));
    if (keys.isEmpty) return Center(child: done ? Text(L.t('empty')) : const CircularProgressIndicator());
    return ListView.builder(
      itemCount: keys.length,
      itemBuilder: (_, i) => ListTile(
        leading: Icon(iconFor('', true), color: colorFor('', true), size: 36),
        title: Text(p.basename(keys[i])),
        subtitle: Text('${m[keys[i]]!.length}', style: const TextStyle(fontSize: 11)),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TrackListScreen(title: p.basename(keys[i]), paths: m[keys[i]]!.map((e) => e.path).toList()))),
      ),
    );
  }

  Widget _favs() {
    final s = context.watch<AppSettings>();
    final favs = audios.where((e) => s.isFav(e.path) && _match(e)).toList();
    if (favs.isEmpty) return Center(child: Text(L.t('empty')));
    return ListView.builder(itemCount: favs.length, itemBuilder: (_, i) => _tile(favs[i], favs));
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 6,
        child: Scaffold(
          appBar: AppBar(
            title: Text(L.t('music') + (done ? ' (${audios.length})' : '')),
            bottom: TabBar(isScrollable: true, tabs: [
              Tab(text: L.t('songs')),
              Tab(text: L.t('albums')),
              Tab(text: L.t('artists')),
              Tab(text: L.t('folders')),
              Tab(text: L.t('favorites')),
              Tab(text: L.t('playlists')),
            ]),
          ),
          body: Column(children: [
            Padding(
              padding: const EdgeInsets.all(8),
              child: TextField(onChanged: (v) => setState(() => q = v.toLowerCase()), decoration: InputDecoration(hintText: L.t('search'), prefixIcon: const Icon(Icons.search_rounded))),
            ),
            if (!done) const LinearProgressIndicator(),
            Expanded(
              child: TabBarView(children: [
                _songs(),
                GroupTab(groups: _group(2), done: done, grid: true),
                GroupTab(groups: _group(1), done: done),
                _folders(),
                _favs(),
                const PlaylistsTab(),
              ]),
            ),
          ]),
        ),
      );
}
