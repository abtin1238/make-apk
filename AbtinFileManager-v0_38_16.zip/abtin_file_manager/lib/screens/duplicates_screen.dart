import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../services/dup_service.dart';
import '../services/file_ops.dart';
import '../services/trash_service.dart';
import '../widgets/ui.dart';
import 'opener.dart';
import 'saf_prompt.dart';

class DuplicatesScreen extends StatefulWidget {
  final String start;
  const DuplicatesScreen({super.key, this.start = FileOps.root});
  @override
  State<DuplicatesScreen> createState() => _DuplicatesScreenState();
}

class _DuplicatesScreenState extends State<DuplicatesScreen> {
  List<DupGroup> groups = [];
  final sel = <String>{};
  bool running = false, stop = false, scanned = false;
  String phase = '';
  double? progress;
  int minKb = 1;

  @override
  void initState() {
    super.initState();
    _scan();
  }

  @override
  void dispose() {
    stop = true;
    super.dispose();
  }

  Future<void> _scan() async {
    stop = false;
    setState(() { running = true; groups = []; sel.clear(); phase = 'list'; progress = null; });
    final r = await DupService.scan(
      widget.start,
      minSize: minKb * 1024,
      onProgress: (ph, v) { if (mounted) setState(() { phase = ph; progress = v; }); },
      cancelled: () => stop || !mounted,
    );
    if (!mounted) return;
    setState(() { groups = r; running = false; scanned = true; });
  }

  int get _wasted => groups.fold(0, (a, g) => a + g.wasted);

  void _auto(bool keepOldest) {
    sel.clear();
    for (final g in groups) {
      final keep = keepOldest ? g.files.first : g.files.last; // files sorted oldest -> newest
      for (final f in g.files) {
        if (f != keep) sel.add(f.path);
      }
    }
    setState(() {});
  }

  void _toggle(DupGroup g, DupFile f) {
    if (sel.contains(f.path)) {
      sel.remove(f.path);
    } else {
      // never allow deleting every copy
      if (g.files.where((x) => sel.contains(x.path)).length >= g.files.length - 1) {
        snack(context, L.t('dupKeepOne'));
        return;
      }
      sel.add(f.path);
    }
    setState(() {});
  }

  Future<void> _delete() async {
    final list = sel.toList();
    if (list.isEmpty) return;
    if (!await ensureSdAll(context, list)) return;
    if (!mounted) return;
    final st = context.read<AppSettings>();
    final msg = st.trashEnabled ? '${L.t('moveToTrash')} (${list.length})?' : '${L.t('deletePermanent')} (${list.length})?';
    if (!await confirm(context, msg)) return;
    if (!mounted) return;
    final removed = <String>{};
    final ok = await busy(context, () async {
      for (final path in list) {
        final e = FileSystemEntity.isDirectorySync(path) ? Directory(path) as FileSystemEntity : File(path);
        try {
          if (st.trashEnabled) {
            await TrashService.moveToTrash(e);
          } else {
            await FileOps.delete(e);
          }
          removed.add(path);
        } on OpError catch (_) {}
      }
    });
    if (!mounted) return;
    setState(() {
      for (final g in groups) {
        g.files.removeWhere((f) => removed.contains(f.path));
      }
      groups.removeWhere((g) => g.files.length < 2);
      sel.removeAll(removed);
    });
    if (ok) snack(context, L.t('done'));
  }

  @override
  Widget build(BuildContext context) {
    final freed = groups.fold<int>(0, (a, g) => a + g.files.where((f) => sel.contains(f.path)).length * g.size);
    return Scaffold(
      appBar: AppBar(
        title: Text(L.t('dupFinder'), style: const TextStyle(fontSize: 16)),
        actions: [
          if (groups.isNotEmpty)
            PopupMenuButton<int>(
              icon: const Icon(Icons.auto_fix_high_rounded),
              onSelected: (v) => v == 2 ? setState(sel.clear) : _auto(v == 0),
              itemBuilder: (_) => [
                PopupMenuItem(value: 0, child: Text(L.t('dupKeepOldest'))),
                PopupMenuItem(value: 1, child: Text(L.t('dupKeepNewest'))),
                PopupMenuItem(value: 2, child: Text(L.t('dupClear'))),
              ],
            ),
          if (running)
            IconButton(icon: const Icon(Icons.stop_rounded), onPressed: () => stop = true)
          else
            IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: _scan),
        ],
      ),
      body: Column(children: [
        if (running) LinearProgressIndicator(value: progress),
        if (running) Padding(padding: const EdgeInsets.all(8), child: Text('${L.t('dupPhase_$phase')}${progress == null ? '' : ' ${(progress! * 100).toStringAsFixed(0)}%'}')),
        if (!running && scanned && groups.isEmpty) Expanded(child: Center(child: Text(L.t('dupNone')))),
        if (groups.isNotEmpty) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: Row(children: [
              Expanded(child: Text('${L.t('dupGroups')}: ${groups.length}  •  ${L.t('dupWasted')}: ${FileOps.fmt(_wasted)}', style: const TextStyle(fontWeight: FontWeight.bold))),
            ]),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: groups.length,
              itemBuilder: (c, gi) {
                final g = groups[gi];
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Column(children: [
                    ListTile(
                      dense: true,
                      leading: Icon(iconFor(g.files.first.path, false), color: colorFor(g.files.first.path, false)),
                      title: Text(p.basename(g.files.first.path), maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text('${g.files.length} × ${FileOps.fmt(g.size)}'),
                    ),
                    for (final f in g.files)
                      CheckboxListTile(
                        dense: true,
                        value: sel.contains(f.path),
                        onChanged: (_) => _toggle(g, f),
                        title: Text(p.basename(f.path), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
                        subtitle: Text('${p.dirname(f.path)}\n${FileOps.dt(f.modified)}', style: const TextStyle(fontSize: 11)),
                        secondary: IconButton(icon: const Icon(Icons.open_in_new_rounded, size: 20), onPressed: () => Opener.open(context, f.path)),
                      ),
                  ]),
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: sel.isEmpty ? null : _delete,
                  icon: const Icon(Icons.delete_rounded),
                  label: Text('${L.t('delete')} (${sel.length}) • ${FileOps.fmt(freed)}'),
                ),
              ),
            ),
          ),
        ],
      ]),
    );
  }
}
