import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../services/nearby.dart';
import '../services/transfer_service.dart';
import '../widgets/ui.dart';

class NearbyScreen extends StatelessWidget {
  const NearbyScreen({super.key});
  @override
  Widget build(BuildContext context) => ChangeNotifierProvider(create: (_) => Nearby(), child: const _Body());
}

class _Body extends StatefulWidget {
  const _Body();
  @override
  State<_Body> createState() => _BodyState();
}

class _BodyState extends State<_Body> {
  late final Nearby n = context.read<Nearby>();

  @override
  void dispose() {
    n.stop();
    super.dispose();
  }

  static String _status(int s) => const ['wfdConnected', 'wfdInvited', 'wfdFailed', 'wfdAvailable', 'wfdUnavailable'][s.clamp(0, 4)];

  Future<void> _send(String ip) async {
    final t = context.read<TransferService>();
    final r = await FilePicker.platform.pickFiles(allowMultiple: true);
    final files = r?.paths.whereType<String>().toList() ?? [];
    if (files.isEmpty || !mounted) return;
    String? pin;
    for (var i = 0; i < 3; i++) {
      try {
        await t.sendTo(ip, TransferService.port, files, pin: pin);
        if (mounted) snack(context, L.t('done'));
        return;
      } on NeedPin {
        if (!mounted) return;
        pin = await promptText(context, L.t('enterPin'));
        if (pin == null || pin.isEmpty) return;
      } catch (e) {
        if (mounted) snack(context, '$e');
        return;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final w = context.watch<Nearby>();
    final t = context.watch<TransferService>();
    return Scaffold(
      appBar: AppBar(title: Text(L.t('nearbyTitle'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(L.t('bluetooth'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 4),
        Text(L.t('btHint'), style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(
            child: FilledButton.icon(
              icon: const Icon(Icons.bluetooth_rounded),
              label: Text(L.t('btSend')),
              onPressed: () async {
                final r = await FilePicker.platform.pickFiles(allowMultiple: true);
                final files = r?.paths.whereType<String>().toList() ?? [];
                if (files.isEmpty) return;
                try {
                  await Nearby.btSend(files);
                } catch (e) {
                  if (mounted) snack(context, '$e');
                }
              },
            ),
          ),
          const SizedBox(width: 8),
          OutlinedButton(onPressed: Nearby.btSettings, child: Text(L.t('btSettings'))),
        ]),
        const Divider(height: 32),
        Text(L.t('wifiDirect'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 4),
        Text(L.t('wfdHint'), style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 8),
        if (!w.p2pEnabled) Text(L.t('wfdOff'), style: const TextStyle(color: Colors.redAccent)),
        Row(children: [
          FilledButton.icon(
            icon: Icon(w.scanning ? Icons.stop_rounded : Icons.wifi_find_rounded),
            label: Text(w.scanning ? L.t('stop') : L.t('wfdScan')),
            onPressed: () async {
              try {
                w.scanning ? await w.stop() : await w.start();
              } catch (e) {
                if (mounted) snack(context, '$e');
              }
            },
          ),
          const SizedBox(width: 8),
          if (w.scanning) const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)),
          const Spacer(),
          if (w.connected) TextButton(onPressed: w.disconnect, child: Text(L.t('wfdDisconnect'))),
        ]),
        if (w.connected) ...[
          const SizedBox(height: 8),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(L.t('wfdLinked'), style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                if (w.isOwner) ...[
                  Text(L.t('wfdOwner'), style: const TextStyle(fontSize: 12)),
                  SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(L.t('lanServer')), value: t.running, onChanged: (v) => v ? t.start() : t.stop()),
                  if (t.url != null) SelectableText(t.url!),
                  if (t.requirePin && t.running) Text('${L.t('yourPin')}: ${t.pin}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                ] else ...[
                  Text('${L.t('wfdClient')} (${w.ownerIp ?? '?'})', style: const TextStyle(fontSize: 12)),
                  const SizedBox(height: 8),
                  FilledButton.icon(
                    icon: const Icon(Icons.send_rounded),
                    label: Text(L.t('wfdSendOwner')),
                    onPressed: w.ownerIp == null ? null : () => _send(w.ownerIp!),
                  ),
                ],
              ]),
            ),
          ),
        ],
        const SizedBox(height: 8),
        if (w.peers.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(w.scanning ? L.t('wfdSearching') : '—')),
        for (final p in w.peers)
          ListTile(
            leading: const Icon(Icons.phone_android_rounded),
            title: Text(p.name.isEmpty ? p.addr : p.name),
            subtitle: Text(L.t(_status(p.status))),
            trailing: p.status == 3
                ? TextButton(
                    onPressed: () async {
                      try {
                        await w.connect(p.addr);
                      } catch (e) {
                        if (mounted) snack(context, '$e');
                      }
                    },
                    child: Text(L.t('connect')),
                  )
                : null,
          ),
      ]),
    );
  }
}
