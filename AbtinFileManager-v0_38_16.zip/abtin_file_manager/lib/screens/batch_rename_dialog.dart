import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/file_ops.dart';

/// One planned rename. [error] is an l10n key when the new name is unusable.
class RenamePlan {
  final FItem item;
  final String newName;
  final String? error;
  const RenamePlan(this.item, this.newName, this.error);
  bool get changed => newName != item.name;
}

/// Template tokens: {name} = original name without extension, {n} / {n:3} = counter (zero padded).
List<RenamePlan> planBatchRename(List<FItem> items, String tpl, String find, String repl, int start) {
  final out = <RenamePlan>[];
  final counter = RegExp(r'\{n(?::(\d+))?\}');
  var n = start;
  for (final i in items) {
    final ext = i.isDir ? '' : p.extension(i.name);
    var base = i.isDir ? i.name : p.basenameWithoutExtension(i.name);
    if (find.isNotEmpty) base = base.replaceAll(find, repl);
    final cur = n++;
    var nn = tpl.replaceAll('{name}', base).replaceAllMapped(counter, (m) => cur.toString().padLeft(int.tryParse(m[1] ?? '') ?? 0, '0')) + ext;
    String? err;
    try {
      nn = FileOps.checkName(nn);
    } on OpError catch (e) {
      err = e.key;
    }
    out.add(RenamePlan(i, nn, err));
  }
  // clashes inside the plan, or with files that are not part of the selection
  final names = <String, int>{};
  for (final r in out) { names[r.newName.toLowerCase()] = (names[r.newName.toLowerCase()] ?? 0) + 1; }
  final mine = items.map((e) => e.path).toSet();
  for (var k = 0; k < out.length; k++) {
    final r = out[k];
    if (r.error != null || !r.changed) continue;
    final target = p.join(p.dirname(r.item.path), r.newName);
    final other = FileOps.exists(target) && !mine.contains(target) && !_sameFile(r.item.path, target);
    if (names[r.newName.toLowerCase()]! > 1 || other) out[k] = RenamePlan(r.item, r.newName, 'exists');
  }
  return out;
}

bool _sameFile(String a, String b) => a != b && a.toLowerCase() == b.toLowerCase();

Future<List<RenamePlan>?> askBatchRename(BuildContext c, List<FItem> items) {
  final tpl = TextEditingController(text: '{name}');
  final find = TextEditingController();
  final repl = TextEditingController();
  final start = TextEditingController(text: '1');
  return showDialog<List<RenamePlan>>(
    context: c,
    builder: (_) => StatefulBuilder(builder: (ctx, set) {
      final plan = planBatchRename(items, tpl.text, find.text, repl.text, int.tryParse(start.text) ?? 1);
      final ok = plan.every((r) => r.error == null) && plan.any((r) => r.changed);
      return AlertDialog(
        title: Text('${L.t('batchRename')} (${items.length})'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: tpl, onChanged: (_) => set(() {}), decoration: InputDecoration(labelText: L.t('brTemplate'), helperText: '{name}  {n}  {n:3}')),
            Row(children: [
              Expanded(child: TextField(controller: find, onChanged: (_) => set(() {}), decoration: InputDecoration(labelText: L.t('brFind')))),
              const SizedBox(width: 8),
              Expanded(child: TextField(controller: repl, onChanged: (_) => set(() {}), decoration: InputDecoration(labelText: L.t('brReplace')))),
            ]),
            TextField(controller: start, keyboardType: TextInputType.number, onChanged: (_) => set(() {}), decoration: InputDecoration(labelText: L.t('brStart'))),
            const SizedBox(height: 8),
            Flexible(
              child: ListView(shrinkWrap: true, children: [
                for (final r in plan)
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    title: Text(r.item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: Colors.grey)),
                    subtitle: Text(r.newName, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13, color: r.error != null ? Colors.redAccent : null)),
                    trailing: r.error != null ? const Icon(Icons.error_outline_rounded, color: Colors.redAccent, size: 18) : null,
                  ),
              ]),
            ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(L.t('cancel'))),
          TextButton(onPressed: ok ? () => Navigator.pop(ctx, plan.where((r) => r.changed).toList()) : null, child: Text(L.t('ok'))),
        ],
      );
    }),
  );
}
