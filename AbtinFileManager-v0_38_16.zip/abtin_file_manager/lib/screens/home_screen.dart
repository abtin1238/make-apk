import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../core/theme.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../widgets/adaptive_nav.dart';
import '../widgets/ui.dart';
import 'analyzer_screen.dart';
import 'browser_screen.dart';
import 'category_screen.dart';
import 'media_screen.dart';
import 'music_library_screen.dart';
import 'photo_albums_screen.dart';
import 'ext_screen.dart';
import 'path_list_screen.dart';
import 'search_screen.dart';
import 'trash_screen.dart';

class HomeScreen extends StatelessWidget {
  final VoidCallback onOpenFiles;
  const HomeScreen({super.key, required this.onOpenFiles});

  void _go(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final cats = <(IconData, String, Color, Widget)>[
      (Icons.article_rounded, 'word', const Color(0xFF2B7CD3), ExtScreen(title: L.t('word'), exts: const {'docx', 'docm', 'dotx', 'dotm', 'doc'})),
      (Icons.picture_as_pdf_rounded, 'pdf', const Color(0xFFFF5C7A), ExtScreen(title: L.t('pdf'), exts: const {'pdf'})),
      (Icons.text_snippet_rounded, 'text', Colors.blueGrey, ExtScreen(title: L.t('text'), exts: FileOps.textExts)),
      (Icons.image_rounded, 'images', const Color(0xFF2ECC71), const PhotoAlbumsScreen()),
      (Icons.perm_media_rounded, 'media', AppColors.purple, const MediaScreen()),
      (Icons.play_circle_rounded, 'videos', AppColors.purple, const CategoryScreen(cat: Cat.videos)),
      (Icons.music_note_rounded, 'music', AppColors.gold, const MusicLibraryScreen()),
      (Icons.description_rounded, 'docs', const Color(0xFFFF5C7A), const CategoryScreen(cat: Cat.docs)),
      (Icons.android_rounded, 'apps', const Color(0xFF3DDC84), const CategoryScreen(cat: Cat.apps)),
      (Icons.archive_rounded, 'archives', const Color(0xFFFF9F43), const CategoryScreen(cat: Cat.archives)),
      (Icons.download_rounded, 'downloads', AppColors.blue, const BrowserScreen(initialPath: FileOps.downloads)),
      (Icons.star_rounded, 'favorites', Colors.amber, PathListScreen(title: L.t('favorites'), fav: true)),
      (Icons.history_rounded, 'recents', Colors.cyan, PathListScreen(title: L.t('recents'), fav: false)),
      (Icons.delete_rounded, 'trash', Colors.blueGrey, const TrashScreen()),
    ];
    return SafeArea(
      child: MaxWidth(width: 960, child: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(gradient: AppColors.grad, borderRadius: BorderRadius.circular(12)),
            child: Icon(iconFor('', true), color: Colors.white),
          ),
          const SizedBox(width: 12),
          const Expanded(child: Text('Abtin File Manager', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
          IconButton(icon: const Icon(Icons.search_rounded), onPressed: () => _go(context, const SearchScreen())),
        ]),
        const SizedBox(height: 16),
        for (final r in FileOps.roots()) _StorageCard(root: r, onTap: () => _go(context, BrowserScreen(initialPath: r.path, root: true))),
        const SizedBox(height: 8),
        GridView.count(
          crossAxisCount: (MediaQuery.of(context).size.width ~/ 130).clamp(3, 7), shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: 1.05,
          children: [
            for (final c in cats)
              GradCard(
                onTap: () => _go(context, c.$4),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(c.$1, size: 32, color: c.$3),
                  const SizedBox(height: 8),
                  Text(L.t(c.$2), style: const TextStyle(fontSize: 12), textAlign: TextAlign.center),
                ]),
              ),
          ],
        ),
        const SizedBox(height: 10),
        GradCard(
          onTap: () => _go(context, const AnalyzerScreen()),
          child: Row(children: [
            const Icon(Icons.pie_chart_rounded, color: AppColors.blue),
            const SizedBox(width: 12),
            Text(L.t('analyzer')),
          ]),
        ),
        if (s.recents.isNotEmpty) const SizedBox(height: 4),
      ])),
    );
  }
}

class _StorageCard extends StatelessWidget {
  final StorageRoot root;
  final VoidCallback onTap;
  const _StorageCard({required this.root, required this.onTap});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: FutureBuilder<List<int>>(
          future: Native.storage(root.path),
          builder: (c, snap) {
            final t = snap.data?[0] ?? 0, f = snap.data?[1] ?? 0;
            final used = t - f;
            return GradCard(
              onTap: onTap,
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Icon(root.sd ? Icons.sd_card_rounded : Icons.smartphone_rounded, color: AppColors.blue),
                  const SizedBox(width: 10),
                  Expanded(child: Text(root.sd ? '${L.t('sdcard')} (${root.name})' : L.t('internal'), style: const TextStyle(fontWeight: FontWeight.w600))),
                  Text(t == 0 ? '' : '${FileOps.fmt(used)} / ${FileOps.fmt(t)}', style: const TextStyle(fontSize: 12)),
                ]),
                const SizedBox(height: 10),
                ClipRRect(borderRadius: BorderRadius.circular(6), child: LinearProgressIndicator(value: t == 0 ? 0 : used / t, minHeight: 8)),
              ]),
            );
          },
        ),
      );
}
