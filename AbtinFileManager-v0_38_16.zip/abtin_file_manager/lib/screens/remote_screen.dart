import 'package:flutter/material.dart';
import '../core/l10n.dart';
import '../services/remote/cloud_fs.dart';
import '../services/remote/remote_fs.dart';
import '../widgets/ui.dart';
import 'remote_browser_screen.dart';

IconData remoteIcon(String t) => const {
      'ftp': Icons.dns_rounded,
      'sftp': Icons.terminal_rounded,
      'smb': Icons.lan_rounded,
      'webdav': Icons.cloud_sync_rounded,
      'dropbox': Icons.cloud_rounded,
      'gdrive': Icons.add_to_drive_rounded,
    }[t] ??
    Icons.cloud_rounded;

String remoteTypeName(String t) => const {'ftp': 'FTP / FTPS', 'sftp': 'SFTP (SSH)', 'smb': 'SMB (Windows share)', 'webdav': 'WebDAV', 'dropbox': 'Dropbox', 'gdrive': 'Google Drive'}[t] ?? t;

class RemoteScreen extends StatefulWidget {
  const RemoteScreen({super.key});
  @override
  State<RemoteScreen> createState() => _RemoteScreenState();
}

class _RemoteScreenState extends State<RemoteScreen> {
  List<RemoteProfile> list = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await RemoteStore.load();
    if (mounted) setState(() => list = l);
  }

  Future<void> _edit([RemoteProfile? p]) async {
    final r = await Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => ProfileEditScreen(profile: p)));
    if (r == true) _load();
  }

  Future<void> _open(RemoteProfile p) async {
    var pr = p;
    if (!p.cloud && p.pass.isEmpty && p.type != 'ftp') {
      final pw = await promptText(context, L.t('password'), obscure: true);
      if (pw == null || !mounted) return;
      pr = RemoteProfile.fromJson(p.toJson())..pass = pw;
    }
    Navigator.push(context, MaterialPageRoute(builder: (_) => RemoteBrowserScreen(profile: pr)));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(L.t('remote'))),
        floatingActionButton: FloatingActionButton(onPressed: () => _edit(), child: const Icon(Icons.add_rounded)),
        body: list.isEmpty
            ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(L.t('remoteSub'), textAlign: TextAlign.center)))
            : ListView(children: [
                for (final p in list)
                  ListTile(
                    leading: Icon(remoteIcon(p.type)),
                    title: Text(p.name.isEmpty ? p.host : p.name),
                    subtitle: Text(p.cloud ? remoteTypeName(p.type) : '${remoteTypeName(p.type)} • ${p.host}'),
                    onTap: () => _open(p),
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) async {
                        if (v == 'e') {
                          _edit(p);
                        } else if (await confirm(context, L.t('delete'))) {
                          await RemoteStore.remove(p);
                          _load();
                        }
                      },
                      itemBuilder: (_) => [
                        PopupMenuItem(value: 'e', child: Text(L.t('edit'))),
                        PopupMenuItem(value: 'd', child: Text(L.t('delete'))),
                      ],
                    ),
                  ),
              ]),
      );
}

class ProfileEditScreen extends StatefulWidget {
  final RemoteProfile? profile;
  const ProfileEditScreen({super.key, this.profile});
  @override
  State<ProfileEditScreen> createState() => _ProfileEditScreenState();
}

class _ProfileEditScreenState extends State<ProfileEditScreen> {
  late RemoteProfile p;
  final name = TextEditingController(), host = TextEditingController(), port = TextEditingController(), user = TextEditingController();
  final pass = TextEditingController(), path = TextEditingController(), extra = TextEditingController();
  bool signed = false;

  @override
  void initState() {
    super.initState();
    p = widget.profile == null
        ? RemoteProfile(id: DateTime.now().microsecondsSinceEpoch.toString(), port: 21)
        : RemoteProfile.fromJson(widget.profile!.toJson());
    name.text = p.name;
    host.text = p.host;
    port.text = '${p.port}';
    user.text = p.user;
    pass.text = p.pass;
    path.text = p.path;
    extra.text = p.extra;
    CloudAuth.signedIn(p.id).then((v) => mounted ? setState(() => signed = v) : null);
  }

  void _setType(String t) {
    setState(() {
      p.type = t;
      port.text = '${RemoteProfile.defaultPort(t)}';
      p.flag = false;
    });
  }

  void _collect() {
    p.name = name.text.trim();
    p.host = host.text.trim();
    p.port = int.tryParse(port.text) ?? RemoteProfile.defaultPort(p.type);
    p.user = user.text.trim();
    p.pass = pass.text;
    p.path = path.text.trim().isEmpty ? '/' : path.text.trim();
    p.extra = extra.text;
  }

  Future<void> _save() async {
    _collect();
    if (p.name.isEmpty) p.name = p.cloud ? remoteTypeName(p.type) : p.host;
    final l = await RemoteStore.load();
    final i = l.indexWhere((e) => e.id == p.id);
    i >= 0 ? l[i] = p : l.add(p);
    await RemoteStore.save(l);
    if (mounted) Navigator.pop(context, true);
  }

  Widget _f(TextEditingController c, String label, {bool obscure = false, TextInputType? kb, int lines = 1, String? hint}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(
          controller: c,
          obscureText: obscure,
          keyboardType: kb,
          minLines: lines,
          maxLines: lines,
          decoration: InputDecoration(labelText: label, hintText: hint),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final t = p.type;
    return Scaffold(
      appBar: AppBar(title: Text(widget.profile == null ? L.t('addServer') : L.t('editServer')), actions: [IconButton(icon: const Icon(Icons.check_rounded), onPressed: _save)]),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        DropdownButtonFormField<String>(
          value: t,
          decoration: InputDecoration(labelText: L.t('protocol')),
          items: [for (final x in RemoteProfile.types) DropdownMenuItem(value: x, child: Text(remoteTypeName(x)))],
          onChanged: (v) => _setType(v!),
        ),
        const SizedBox(height: 10),
        _f(name, L.t('profName')),
        if (p.cloud) ...[
          _f(extra, L.t('clientId')),
          Text(t == 'dropbox' ? L.t('dropboxHint') : L.t('gdriveHint'), style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 12),
          Row(children: [
            FilledButton.icon(
              icon: const Icon(Icons.login_rounded),
              label: Text(signed ? L.t('signedIn') : L.t('signIn')),
              onPressed: () async {
                _collect();
                final ok = await busy(context, () => CloudAuth.login(p));
                if (ok && mounted) setState(() => signed = true);
              },
            ),
            const SizedBox(width: 8),
            if (signed)
              TextButton(
                onPressed: () async {
                  await CloudAuth.signOut(p.id);
                  if (mounted) setState(() => signed = false);
                },
                child: Text(L.t('signOut')),
              ),
          ]),
        ] else ...[
          _f(host, t == 'webdav' ? 'URL' : L.t('host'), hint: t == 'webdav' ? 'https://cloud.example.com/remote.php/dav/files/me/' : null),
          if (t != 'webdav') _f(port, L.t('port'), kb: TextInputType.number),
          if (t == 'smb') _f(extra, L.t('domain')),
          _f(user, L.t('user')),
          _f(pass, t == 'sftp' ? L.t('passOrPhrase') : L.t('password'), obscure: true),
          if (t == 'sftp') _f(extra, L.t('privateKey'), lines: 4, hint: '-----BEGIN OPENSSH PRIVATE KEY-----'),
          if (t != 'webdav') _f(path, L.t('path')),
          if (t == 'ftp') SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('FTPES (TLS)'), value: p.flag, onChanged: (v) => setState(() => p.flag = v)),
          if (t == 'webdav') SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(L.t('allowInsecure')), subtitle: Text(L.t('allowInsecureSub')), value: p.flag, onChanged: (v) => setState(() => p.flag = v)),
          SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(L.t('savePass')), subtitle: Text(L.t('savePassSub')), value: p.savePass, onChanged: (v) => setState(() => p.savePass = v)),
        ],
      ]),
    );
  }
}
