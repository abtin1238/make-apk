import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../widgets/ui.dart';
import 'archive_dialog.dart';
import 'hash_screen.dart';

class ApkInfoScreen extends StatefulWidget {
  final String path;
  const ApkInfoScreen({super.key, required this.path});
  @override
  State<ApkInfoScreen> createState() => _ApkInfoScreenState();
}

class _ApkInfoScreenState extends State<ApkInfoScreen> {
  Map<String, dynamic>? info;
  Uint8List? icon;
  String? err;
  int size = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      size = await File(widget.path).length();
      final i = await Native.apkInfo(widget.path);
      if (i == null) throw Exception(L.t('apkInvalid'));
      final ic = await Native.apkIcon(widget.path);
      if (mounted) setState(() { info = i; icon = ic; });
    } catch (e) {
      if (mounted) setState(() => err = '$e');
    }
  }

  Future<void> _install() async {
    if (!await Native.canInstall()) {
      if (!mounted) return;
      if (!await confirm(context, L.t('allowInstallMsg'))) return;
      await Native.installSettings();
      return;
    }
    final r = await OpenFilex.open(widget.path, type: 'application/vnd.android.package-archive');
    if (r.type != ResultType.done && mounted) snack(context, r.message);
  }

  String _status() {
    final iv = info!['installedCode'];
    if (iv == null) return L.t('newInstall');
    final cur = (info!['versionCode'] as num).toInt();
    final inst = (iv as num).toInt();
    final name = '${info!['installedName']} ($inst)';
    if (cur > inst) return '${L.t('update')}: $name';
    if (cur == inst) return '${L.t('sameVersion')}: $name';
    return '${L.t('downgrade')}: $name';
  }

  Widget _kv(String k, String v) => ListTile(
        dense: true,
        title: Text(k, style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor)),
        subtitle: SelectableText(v, style: const TextStyle(fontSize: 14)),
      );

  @override
  Widget build(BuildContext context) {
    final i = info;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 16))),
      body: err != null
          ? Center(child: Padding(padding: const EdgeInsets.all(20), child: Text(err!, textAlign: TextAlign.center)))
          : i == null
              ? const Center(child: CircularProgressIndicator())
              : ListView(padding: const EdgeInsets.all(12), children: [
                  Row(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: icon != null ? Image.memory(icon!, width: 72, height: 72) : const Icon(Icons.android_rounded, size: 72, color: Color(0xFF3DDC84)),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${i['label']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        Text('${i['package']}', style: const TextStyle(fontSize: 12)),
                        const SizedBox(height: 4),
                        Text(_status(), style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.primary)),
                      ]),
                    ),
                  ]),
                  const SizedBox(height: 14),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    FilledButton.icon(onPressed: _install, icon: const Icon(Icons.install_mobile_rounded), label: Text(L.t('install'))),
                    if (i['installedCode'] != null)
                      OutlinedButton.icon(onPressed: () => Native.uninstall('${i['package']}'), icon: const Icon(Icons.delete_outline_rounded), label: Text(L.t('uninstall'))),
                    OutlinedButton.icon(onPressed: () => showArchiveDialog(context, widget.path, null), icon: const Icon(Icons.folder_zip_rounded), label: Text(L.t('contents'))),
                    OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => HashScreen(path: widget.path))), icon: const Icon(Icons.tag_rounded), label: Text(L.t('hash'))),
                  ]),
                  const SizedBox(height: 8),
                  _kv(L.t('version'), '${i['versionName']} (${i['versionCode']})'),
                  _kv('minSdk / targetSdk', '${i['minSdk']} / ${i['targetSdk']}'),
                  _kv(L.t('size'), '${FileOps.fmt(size)} ($size B)'),
                  _kv(L.t('components'), '${L.t('activities')}: ${i['activities']}  •  ${L.t('services')}: ${i['services']}  •  ${L.t('receivers')}: ${i['receivers']}  •  ${L.t('providers')}: ${i['providers']}'),
                  for (final s in (i['signatures'] as List? ?? const []))
                    _kv('${L.t('signature')} (SHA-256)', '$s'),
                  ExpansionTile(
                    title: Text('${L.t('permissions')} (${(i['permissions'] as List).length})'),
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
                        child: Align(
                          alignment: AlignmentDirectional.centerStart,
                          child: SelectableText((i['permissions'] as List).join('\n'), style: const TextStyle(fontFamily: 'monospace', fontSize: 11)),
                        ),
                      ),
                    ],
                  ),
                ]),
    );
  }
}
