import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:pdfx/pdfx.dart';
import '../core/l10n.dart';
import '../widgets/ui.dart';

class PlaceResult {
  final double x, y, w; // fractions of the displayed page, x/y = top-left
  PlaceResult(this.x, this.y, this.w);
}

/// Shows the page and lets the user drag the signature / stamp to the exact spot and resize it.
class PdfPlaceScreen extends StatefulWidget {
  final String path;
  final int page;
  final Uint8List stamp;
  final int anchor; // initial position: 0 bottom-right, 1 bottom-left, 2 centre, 3 top-right, 4 top-left
  final double width; // initial width fraction
  const PdfPlaceScreen({super.key, required this.path, required this.page, required this.stamp, this.anchor = 0, this.width = .25});
  @override
  State<PdfPlaceScreen> createState() => _PdfPlaceScreenState();
}

class _PdfPlaceScreenState extends State<PdfPlaceScreen> {
  Uint8List? png;
  double ratio = 1, stampRatio = 1; // page h/w, stamp h/w
  late double w = widget.width;
  double x = 0, y = 0;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final d = await PdfDocument.openFile(widget.path);
      final pg = await d.getPage(widget.page);
      final scale = (1200 / pg.width).clamp(1.0, 2.5).toDouble();
      final r = await pg.render(width: pg.width * scale, height: pg.height * scale, format: PdfPageImageFormat.png, backgroundColor: '#FFFFFF');
      ratio = pg.height / pg.width;
      await pg.close();
      await d.close();
      final im = await decodeImageFromList(widget.stamp);
      stampRatio = im.height / im.width;
      _anchor();
      if (mounted) setState(() { png = r?.bytes; loading = false; });
    } catch (e) {
      if (mounted) {
        snack(context, '${L.t('error')}: $e');
        Navigator.pop(context);
      }
    }
  }

  double get _h => w * stampRatio / ratio; // stamp height as fraction of page height

  void _anchor() {
    const m = .04;
    final left = m, right = 1 - m - w, top = m, bottom = 1 - m - _h;
    switch (widget.anchor) {
      case 1: x = left; y = bottom;
      case 2: x = (1 - w) / 2; y = (1 - _h) / 2;
      case 3: x = right; y = top;
      case 4: x = left; y = top;
      default: x = right; y = bottom;
    }
  }

  void _clamp() {
    x = x.clamp(0.0, (1 - w).clamp(0.0, 1.0)).toDouble();
    y = y.clamp(0.0, (1 - _h).clamp(0.0, 1.0)).toDouble();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(L.t('placeStamp'), style: const TextStyle(fontSize: 15)),
          actions: [IconButton(icon: const Icon(Icons.check_rounded), onPressed: loading ? null : () => Navigator.pop(context, PlaceResult(x, y, w)))],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : Column(children: [
                Expanded(
                  child: LayoutBuilder(builder: (c, cons) {
                    var pw = cons.maxWidth, ph = pw * ratio;
                    if (ph > cons.maxHeight) {
                      ph = cons.maxHeight;
                      pw = ph / ratio;
                    }
                    return Center(
                      child: SizedBox(
                        width: pw,
                        height: ph,
                        child: Stack(children: [
                          Image.memory(png!, width: pw, height: ph, fit: BoxFit.fill),
                          Positioned(
                            left: x * pw,
                            top: y * ph,
                            width: w * pw,
                            height: _h * ph,
                            child: GestureDetector(
                              onPanUpdate: (d) => setState(() {
                                x += d.delta.dx / pw;
                                y += d.delta.dy / ph;
                                _clamp();
                              }),
                              child: Container(
                                decoration: BoxDecoration(border: Border.all(color: Theme.of(context).colorScheme.primary, width: 1.2)),
                                child: Image.memory(widget.stamp, fit: BoxFit.fill),
                              ),
                            ),
                          ),
                        ]),
                      ),
                    );
                  }),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(children: [
                    Text(L.t('sizeLabel')),
                    Expanded(child: Slider(value: w, min: .08, max: .8, onChanged: (v) => setState(() { w = v; _clamp(); }))),
                  ]),
                ),
              ]),
      );
}
