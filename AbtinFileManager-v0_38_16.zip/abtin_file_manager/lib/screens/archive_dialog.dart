import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/archive_service.dart';
import '../services/file_ops.dart';
import '../services/saf.dart';
import '../widgets/ui.dart';
import 'job_dialog.dart';
import 'saf_prompt.dart';
import 'archive_view_screen.dart';

/// [only]: extract just these entries (folders end with '/'), used by the contents browser.
/// [password]: already known password (pre-filled).
Future<void> showArchiveDialog(BuildContext c, String path, VoidCallback? onChanged, {List<String>? only, String? password}) async {
  final folder = ArchiveService.defaultFolderName(ArchiveService.firstVolume(path).replaceAll(RegExp(r'\.(001|part0*1\.rar)$', caseSensitive: false), ''));
  final dst = TextEditingController(text: p.join(path.contains('/cache/incoming/') ? p.join(FileOps.root, 'Download') : p.dirname(path), folder));
  final pw = TextEditingController(text: password ?? '');
  final go = await showDialog<String>(
    context: c,
    builder: (_) => AlertDialog(
      title: Text(p.basename(path), maxLines: 2, overflow: TextOverflow.ellipsis),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: dst, decoration: InputDecoration(labelText: L.t('extractTo'))),
        const SizedBox(height: 10),
        TextField(controller: pw, obscureText: true, decoration: InputDecoration(labelText: L.t('password'))),
      ]),
      actions: [
        if (only == null)
          TextButton(
            onPressed: () => Navigator.pop(c, 'view'),
            child: Text(L.t('viewContents')),
          ),
        TextButton(onPressed: () => Navigator.pop(c, 'no'), child: Text(L.t('cancel'))),
        FilledButton(onPressed: () => Navigator.pop(c, 'go'), child: Text(only == null ? L.t('extract') : L.tr('extractSelected', {'n': only.length}))),
      ],
    ),
  );
  if (go == 'view' && c.mounted && only == null) {
    await Navigator.push(c, MaterialPageRoute(builder: (_) => ArchiveViewScreen(path: path, password: pw.text.isEmpty ? null : pw.text, onChanged: onChanged)));
    return;
  }
  if (go != 'go') return;
  final out = dst.text.trim();
  final pass = pw.text.isEmpty ? null : pw.text;
  if (!c.mounted || !await ensureSdAll(c, [out])) return;
  if (!c.mounted) return;
  if (await Saf.needsSaf(out)) {
    // SD card without direct write access: extract to a temp folder, then move it over.
    final tmp = Directory(p.join(Directory.systemTemp.path, 'abtin_x_${DateTime.now().microsecondsSinceEpoch}'));
    try {
      final ok = await busyProgress(c, L.t('extracting'), (r) => ArchiveService.extract(path, tmp.path, password: pass, only: only, onProgress: r));
      if (ok && c.mounted) {
        try { await Saf.mkdirs(out); } catch (_) {}
        final job = await runCopyJob(c, tmp.listSync(followLinks: false), out, move: true);
        if (c.mounted) {
          snack(c, jobResultText(job));
          onChanged?.call();
        }
      }
    } finally {
      try { tmp.deleteSync(recursive: true); } catch (_) {}
    }
    return;
  }
  final ok = await busyProgress(c, L.t('extracting'), (r) => ArchiveService.extract(path, out, password: pass, only: only, onProgress: r));
  if (ok && c.mounted) {
    snack(c, L.t('done'));
    onChanged?.call();
  }
}

/// Result of [askCompress]: file name (with extension), format and optional password.
class CompressChoice {
  final String name;
  final String format; // 'zip' | 'targz' | '7z'
  final String? password;
  final int volumeMB; // 0 = single file
  const CompressChoice(this.name, this.format, this.password, [this.volumeMB = 0]);
}

String _swapExt(String name, String format) {
  var n = name;
  for (final e in const ['.tar.gz', '.zip', '.7z', '.tgz']) {
    if (n.toLowerCase().endsWith(e)) {
      n = n.substring(0, n.length - e.length);
      break;
    }
  }
  return '$n${ArchiveService.extFor(format)}';
}

Future<CompressChoice?> askCompress(BuildContext c, String baseName) {
  final name = TextEditingController(text: '$baseName.zip');
  final pw = TextEditingController();
  final vol = TextEditingController();
  var fmt = 'zip';
  return showDialog<CompressChoice>(
    context: c,
    builder: (_) => StatefulBuilder(
      builder: (ctx, set) => AlertDialog(
        title: Text(L.t('compress')),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            TextField(controller: name, decoration: InputDecoration(labelText: L.t('name'))),
            const SizedBox(height: 12),
            Text(L.t('format')),
            Wrap(spacing: 8, children: [
              for (final f in const [('zip', 'fmtZip'), ('targz', 'fmtTarGz'), ('7z', 'fmt7z')])
                ChoiceChip(
                  label: Text(L.t(f.$2)),
                  selected: fmt == f.$1,
                  onSelected: (_) => set(() {
                    fmt = f.$1;
                    if (fmt == 'targz') pw.clear();
                    name.text = _swapExt(name.text.trim(), fmt);
                  }),
                ),
            ]),
            if (fmt != 'targz') ...[
              const SizedBox(height: 10),
              TextField(controller: pw, obscureText: true, decoration: InputDecoration(labelText: L.t('password'))),
              if (fmt == 'zip') Padding(padding: const EdgeInsets.only(top: 6), child: Text(L.t('zipAesNote'), style: Theme.of(ctx).textTheme.bodySmall)),
            ],
            const SizedBox(height: 10),
            TextField(
              controller: vol,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: L.t('volumeMb'), hintText: '100'),
            ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(L.t('cancel'))),
          FilledButton(
            onPressed: () {
              final n = name.text.trim();
              if (n.isEmpty) return;
              final mb = int.tryParse(vol.text.trim()) ?? 0;
              Navigator.pop(ctx, CompressChoice(n, fmt, fmt != 'targz' && pw.text.isNotEmpty ? pw.text : null, mb < 0 ? 0 : mb));
            },
            child: Text(L.t('compress')),
          ),
        ],
      ),
    ),
  );
}
