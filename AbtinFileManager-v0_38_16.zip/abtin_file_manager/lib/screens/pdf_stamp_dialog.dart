import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../core/l10n.dart';

class StampSpec {
  final Uint8List png;
  final int anchor;
  final double w;
  StampSpec(this.png, this.anchor, this.w);
}

Future<StampSpec?> showStampDialog(BuildContext context) => showDialog<StampSpec>(context: context, builder: (_) => const _StampDialog());

class _PadPainter extends CustomPainter {
  final List<List<Offset>> strokes;
  _PadPainter(this.strokes);
  @override
  void paint(Canvas c, Size s) => _paintStrokes(c, strokes, 2.5);
  @override
  bool shouldRepaint(covariant _PadPainter o) => true;
}

void _paintStrokes(Canvas c, List<List<Offset>> strokes, double w) {
  final paint = Paint()
    ..color = const Color(0xFF1A237E)
    ..strokeWidth = w
    ..style = PaintingStyle.stroke
    ..strokeCap = StrokeCap.round
    ..strokeJoin = StrokeJoin.round;
  for (final st in strokes) {
    if (st.length == 1) {
      c.drawCircle(st.first, w / 2, paint..style = PaintingStyle.fill);
      paint.style = PaintingStyle.stroke;
    } else {
      final path = Path()..moveTo(st.first.dx, st.first.dy);
      for (final q in st.skip(1)) {
        path.lineTo(q.dx, q.dy);
      }
      c.drawPath(path, paint);
    }
  }
}

class _StampDialog extends StatefulWidget {
  const _StampDialog();
  @override
  State<_StampDialog> createState() => _StampDialogState();
}

class _StampDialogState extends State<_StampDialog> {
  final strokes = <List<Offset>>[];
  final txt = TextEditingController();
  int anchor = 0;
  double w = .25;

  Future<Uint8List?> _make() async {
    final t = txt.text.trim();
    final rec = ui.PictureRecorder();
    final c = Canvas(rec);
    int iw, ih;
    if (t.isNotEmpty) {
      final rtl = RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(t);
      final tp = TextPainter(
        text: TextSpan(text: t, style: const TextStyle(fontSize: 56, color: Color(0xFF1A237E))),
        textDirection: rtl ? TextDirection.rtl : TextDirection.ltr,
      )..layout();
      iw = tp.width.ceil() + 16;
      ih = tp.height.ceil() + 16;
      tp.paint(c, const Offset(8, 8));
    } else if (strokes.isNotEmpty) {
      var x0 = double.infinity, y0 = double.infinity, x1 = -double.infinity, y1 = -double.infinity;
      for (final st in strokes) {
        for (final o in st) {
          if (o.dx < x0) x0 = o.dx;
          if (o.dy < y0) y0 = o.dy;
          if (o.dx > x1) x1 = o.dx;
          if (o.dy > y1) y1 = o.dy;
        }
      }
      const sc = 3.0;
      iw = ((x1 - x0 + 16) * sc).ceil();
      ih = ((y1 - y0 + 16) * sc).ceil();
      c.scale(sc);
      c.translate(-x0 + 8, -y0 + 8);
      _paintStrokes(c, strokes, 2.5);
    } else {
      return null;
    }
    final im = await rec.endRecording().toImage(iw, ih);
    final bd = await im.toByteData(format: ui.ImageByteFormat.png);
    return bd?.buffer.asUint8List();
  }

  @override
  Widget build(BuildContext context) {
    final names = [L.t('bottomRight'), L.t('bottomLeft'), L.t('center'), L.t('topRight'), L.t('topLeft')];
    return AlertDialog(
      title: Text(L.t('signStamp')),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            height: 150,
            width: 300,
            decoration: BoxDecoration(color: Colors.white, border: Border.all(color: Colors.grey)),
            child: ClipRect(
              child: GestureDetector(
                onPanStart: (d) => setState(() => strokes.add([d.localPosition])),
                onPanUpdate: (d) => setState(() => strokes.last.add(d.localPosition)),
                child: CustomPaint(painter: _PadPainter(strokes), size: Size.infinite),
              ),
            ),
          ),
          Align(alignment: AlignmentDirectional.centerEnd, child: TextButton(onPressed: () => setState(strokes.clear), child: Text(L.t('clearPad')))),
          TextField(controller: txt, decoration: InputDecoration(labelText: L.t('typeText'))),
          const SizedBox(height: 8),
          Wrap(spacing: 6, children: [
            for (var i = 0; i < names.length; i++) ChoiceChip(label: Text(names[i]), selected: anchor == i, onSelected: (_) => setState(() => anchor = i)),
          ]),
          Row(children: [
            Text(L.t('sizeLabel')),
            Expanded(child: Slider(value: w, min: .1, max: .6, onChanged: (v) => setState(() => w = v))),
          ]),
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text(L.t('cancel'))),
        FilledButton(
          onPressed: () async {
            final png = await _make();
            if (png != null && context.mounted) Navigator.pop(context, StampSpec(png, anchor, w));
          },
          child: Text(L.t('ok')),
        ),
      ],
    );
  }
}
