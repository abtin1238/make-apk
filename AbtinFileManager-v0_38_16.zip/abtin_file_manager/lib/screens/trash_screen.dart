import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../services/file_ops.dart';
import '../services/trash_service.dart';
import '../widgets/ui.dart';
import 'saf_prompt.dart';

class TrashScreen extends StatefulWidget {
  const TrashScreen({super.key});
  @override
  State<TrashScreen> createState() => _TrashScreenState();
}

class _TrashScreenState extends State<TrashScreen> {
  List<TrashEntry>? items;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await TrashService.list();
    if (mounted) setState(() => items = r);
  }

  Future<void> _restore(List<TrashEntry> l) async {
    if (!await ensureSdAll(context, l.map((e) => e.item))) return;
    if (!mounted) return;
    final ok = await busy(context, () async {
      for (final e in l) {
        await TrashService.restore(e);
      }
    });
    if (!mounted) return;
    await _load();
    if (ok && mounted) snack(context, L.t('restored'));
  }

  Future<void> _purge(List<TrashEntry> l, String ask) async {
    if (!await confirm(context, ask)) return;
    if (!mounted || !await ensureSdAll(context, l.map((e) => e.item))) return;
    if (!mounted) return;
    await busy(context, () async {
      for (final e in l) {
        await TrashService.purge(e);
      }
    });
    if (mounted) await _load();
  }

  Future<String> _size(TrashEntry e) async {
    if (e.size < 0) e.size = await FileOps.dirSize(Directory(e.item));
    return FileOps.fmt(e.size);
  }

  @override
  Widget build(BuildContext context) {
    final l = items;
    final on = context.watch<AppSettings>().trashEnabled;
    return Scaffold(
      appBar: AppBar(
        title: Text(L.t('trash')),
        actions: [
          if (l != null && l.isNotEmpty) ...[
            IconButton(icon: const Icon(Icons.restore_rounded), tooltip: L.t('restoreAll'), onPressed: () => _restore(l)),
            IconButton(icon: const Icon(Icons.delete_sweep_rounded), tooltip: L.t('emptyTrash'), onPressed: () => _purge(l, L.t('emptyTrashAsk'))),
          ],
        ],
      ),
      body: Column(children: [
        if (!on)
          Container(
            width: double.infinity,
            color: Theme.of(context).cardColor,
            padding: const EdgeInsets.all(12),
            child: Text(L.t('trashOff'), style: const TextStyle(fontSize: 12.5)),
          ),
        Expanded(
          child: l == null
              ? const Center(child: CircularProgressIndicator())
              : l.isEmpty
                  ? Center(child: Text(L.t('trashEmpty')))
                  : ListView.builder(
                      itemCount: l.length,
                      itemBuilder: (c, i) {
                        final e = l[i];
                        return ListTile(
                          leading: Icon(iconFor(e.name, e.isDir), color: colorFor(e.name, e.isDir), size: 34),
                          title: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: FutureBuilder<String>(
                            future: _size(e),
                            builder: (_, s) => Text(
                              '${s.data ?? ''}${s.hasData ? ' • ' : ''}${e.time.toString().split('.').first}\n${p.dirname(e.orig)}',
                              maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11),
                            ),
                          ),
                          isThreeLine: true,
                          trailing: PopupMenuButton<int>(
                            onSelected: (v) => v == 0 ? _restore([e]) : _purge([e], '${L.t('deletePermanent')}?'),
                            itemBuilder: (_) => [
                              PopupMenuItem(value: 0, child: Text(L.t('restore'))),
                              PopupMenuItem(value: 1, child: Text(L.t('deletePermanent'))),
                            ],
                          ),
                        );
                      },
                    ),
        ),
      ]),
    );
  }
}
