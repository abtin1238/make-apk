import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../widgets/ui.dart';

/// Installs .xapk / .apks / .apkm bundles (or a folder of split APKs): extracts, copies OBB, then one installer session.
class BundleInstallScreen extends StatefulWidget {
  final String path;
  const BundleInstallScreen({super.key, required this.path});
  @override
  State<BundleInstallScreen> createState() => _BundleInstallScreenState();
}

class _BundleInstallScreenState extends State<BundleInstallScreen> {
  Map<String, dynamic>? info;
  Uint8List? icon;
  List<String> apks = [];
  List<(String, String)> obbs = []; // (source, destination)
  String? err;
  bool busyNow = false;

  @override
  void initState() {
    super.initState();
    Native.installResult.addListener(_onResult);
    _load();
  }

  @override
  void dispose() {
    Native.installResult.removeListener(_onResult);
    super.dispose();
  }

  void _onResult() {
    final r = Native.installResult.value;
    if (r == null || !mounted) return;
    final ok = (r['status'] as num?)?.toInt() == 0;
    snack(context, ok ? L.t('installStarted') : '${L.t('installFailed')}: ${r['msg'] ?? ''}');
  }

  List<String> _findApks(Directory d) {
    final all = [
      for (final e in d.listSync(recursive: true))
        if (e is File && e.path.toLowerCase().endsWith('.apk') && !e.path.contains('${p.separator}standalones${p.separator}')) e.path
    ]..sort();
    final uni = all.where((e) => p.basename(e) == 'universal.apk').toList();
    return uni.isNotEmpty ? uni : all;
  }

  Future<void> _load() async {
    try {
      Directory dir;
      if (FileSystemEntity.isDirectorySync(widget.path)) {
        dir = Directory(widget.path);
      } else {
        final tmp = await getTemporaryDirectory();
        dir = Directory(p.join(tmp.path, 'bundle_${DateTime.now().millisecondsSinceEpoch}'))..createSync(recursive: true);
        await Native.archExtract(widget.path, dir.path, null);
      }
      var list = _findApks(dir);
      final mf = File(p.join(dir.path, 'manifest.json'));
      if (mf.existsSync()) {
        try {
          final m = jsonDecode(mf.readAsStringSync()) as Map;
          final sp = [for (final e in (m['split_apks'] as List? ?? const [])) p.join(dir.path, '${(e as Map)['file']}')]
              .where((e) => File(e).existsSync()).toList();
          if (sp.isNotEmpty) list = sp;
          for (final e in (m['expansions'] as List? ?? const [])) {
            final f = '${(e as Map)['file']}', ip = '${e['install_path']}';
            if (File(p.join(dir.path, f)).existsSync()) obbs.add((p.join(dir.path, f), p.join('/storage/emulated/0', ip)));
          }
        } catch (_) {}
      }
      if (obbs.isEmpty) {
        final ob = Directory(p.join(dir.path, 'Android'));
        if (ob.existsSync()) {
          for (final e in ob.listSync(recursive: true)) {
            if (e is File) obbs.add((e.path, p.join('/storage/emulated/0', p.relative(e.path, from: dir.path))));
          }
        }
      }
      if (list.isEmpty) throw Exception(L.t('noApkInBundle'));
      final base = list.firstWhere((e) => p.basename(e) == 'base.apk', orElse: () => list.first);
      final i = await Native.apkInfo(base);
      final ic = await Native.apkIcon(base);
      if (mounted) setState(() { apks = list; info = i; icon = ic; });
    } catch (e) {
      if (mounted) setState(() => err = '$e');
    }
  }

  Future<void> _install() async {
    if (!await Native.canInstall()) {
      if (!mounted) return;
      if (!await confirm(context, L.t('allowInstallMsg'))) return;
      await Native.installSettings();
      return;
    }
    setState(() => busyNow = true);
    try {
      for (final o in obbs) {
        await Directory(p.dirname(o.$2)).create(recursive: true);
        await File(o.$1).copy(o.$2);
      }
      if (obbs.isNotEmpty && mounted) snack(context, L.t('obbCopied'));
    } catch (_) {}
    final e = await Native.installSplits(apks);
    if (mounted) {
      setState(() => busyNow = false);
      if (e != null) snack(context, '${L.t('installFailed')}: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final i = info;
    return Scaffold(
      appBar: AppBar(title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 16))),
      body: err != null
          ? Center(child: Padding(padding: const EdgeInsets.all(20), child: Text(err!, textAlign: TextAlign.center)))
          : apks.isEmpty
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const CircularProgressIndicator(), const SizedBox(height: 12), Text(L.t('extracting'))]))
              : ListView(padding: const EdgeInsets.all(12), children: [
                  Row(children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: icon != null ? Image.memory(icon!, width: 72, height: 72) : const Icon(Icons.android_rounded, size: 72, color: Color(0xFF3DDC84)),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('${i?['label'] ?? p.basenameWithoutExtension(widget.path)}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                        if (i != null) Text('${i['package']}', style: const TextStyle(fontSize: 12)),
                        if (i != null) Text('${i['versionName']} (${i['versionCode']})', style: const TextStyle(fontSize: 12)),
                      ]),
                    ),
                  ]),
                  const SizedBox(height: 14),
                  Wrap(spacing: 8, children: [
                    FilledButton.icon(
                        onPressed: busyNow ? null : _install, icon: const Icon(Icons.install_mobile_rounded), label: Text(L.t('install'))),
                    if (i != null && i['installedCode'] != null)
                      OutlinedButton.icon(
                          onPressed: () => Native.uninstall('${i['package']}'), icon: const Icon(Icons.delete_outline_rounded), label: Text(L.t('uninstall'))),
                  ]),
                  const SizedBox(height: 8),
                  ExpansionTile(
                    initiallyExpanded: true,
                    title: Text('${L.t('splitApks')} (${apks.length})'),
                    children: [
                      for (final a in apks) ListTile(dense: true, title: Text(p.basename(a)), subtitle: Text(FileOps.fmt(File(a).lengthSync()))),
                      for (final o in obbs) ListTile(dense: true, leading: const Icon(Icons.sd_storage_rounded), title: Text(p.basename(o.$1)), subtitle: Text(o.$2, style: const TextStyle(fontSize: 10))),
                    ],
                  ),
                ]),
    );
  }
}
