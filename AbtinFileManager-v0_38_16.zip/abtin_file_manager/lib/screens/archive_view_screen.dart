import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/archive_service.dart';
import '../services/file_ops.dart';
import '../widgets/ui.dart';
import 'archive_dialog.dart';
import 'opener.dart';

class _Node {
  final String name; // one path segment
  final String full; // entry name inside the archive; folders end with '/'
  final bool dir;
  int size;
  _Node(this.name, this.full, this.dir, this.size);
}

/// Browse the contents of an archive without extracting it, tick entries and extract only those.
class ArchiveViewScreen extends StatefulWidget {
  final String path;
  final String? password;
  final VoidCallback? onChanged;
  const ArchiveViewScreen({super.key, required this.path, this.password, this.onChanged});
  @override
  State<ArchiveViewScreen> createState() => _ArchiveViewState();
}

class _ArchiveViewState extends State<ArchiveViewScreen> {
  List<ArchiveEntry>? _all;
  String? _err;
  String? _pw;
  String _cwd = '';
  final Set<String> _sel = {};

  @override
  void initState() {
    super.initState();
    _pw = widget.password;
    _load();
  }

  String _msg(Object e) => e is OpError ? (e.arg == null ? L.t(e.key) : '${L.t(e.key)}: ${e.arg}') : '${L.t('error')}: $e';

  Future<void> _load() async {
    setState(() {
      _all = null;
      _err = null;
    });
    try {
      final l = await ArchiveService.list(widget.path, password: _pw);
      if (!mounted) return;
      if (_pw == null && l.any((e) => e.enc)) {
        // the names are readable, the content needs the password: ask now so "extract" just works
        final pw = await _askPassword();
        if (pw != null) _pw = pw;
      }
      if (mounted) setState(() => _all = l);
    } on OpError catch (e) {
      if (e.key == 'wrongPassword' && mounted) {
        final pw = await _askPassword();
        if (pw != null && mounted) {
          _pw = pw;
          return _load();
        }
      }
      if (mounted) setState(() => _err = _msg(e));
    } catch (e) {
      if (mounted) setState(() => _err = _msg(e));
    }
  }

  Future<String?> _askPassword() {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(L.t('password')),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(L.t('needPassword')),
          const SizedBox(height: 8),
          TextField(controller: c, obscureText: true, autofocus: true, onSubmitted: (v) => Navigator.pop(ctx, v)),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(L.t('cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: Text(L.t('ok'))),
        ],
      ),
    ).then((v) => v == null || v.isEmpty ? null : v);
  }

  List<_Node> _children() {
    final m = <String, _Node>{};
    for (final e in _all ?? const <ArchiveEntry>[]) {
      if (!e.name.startsWith(_cwd) || e.name == _cwd) continue;
      final rest = e.name.substring(_cwd.length);
      final i = rest.indexOf('/');
      if (i < 0) {
        m[rest] = _Node(rest, '$_cwd$rest', false, e.size);
      } else {
        final seg = rest.substring(0, i);
        final n = m.putIfAbsent(seg, () => _Node(seg, '$_cwd$seg/', true, 0));
        if (!e.dir) n.size += e.size;
      }
    }
    final l = m.values.toList()
      ..sort((a, b) {
        if (a.dir != b.dir) return a.dir ? -1 : 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });
    return l;
  }

  bool _checked(_Node n) => ArchiveService.matches(n.full, _sel.toList());

  void _toggle(_Node n) {
    setState(() {
      if (_sel.contains(n.full)) {
        _sel.remove(n.full);
      } else if (!_checked(n)) {
        _sel.add(n.full); // already covered by a ticked parent folder: nothing to add
      }
    });
  }

  String _up(String c) {
    final t = c.endsWith('/') ? c.substring(0, c.length - 1) : c;
    final i = t.lastIndexOf('/');
    return i < 0 ? '' : t.substring(0, i + 1);
  }

  /// Tap on a file: unpack just that entry to a temporary folder and open it with the normal viewer,
  /// so the user never has to extract the whole archive to look at one file.
  Future<void> _openEntry(_Node n) async {
    final tmp = await getTemporaryDirectory();
    final root = Directory(p.join(tmp.path, 'archive_open'));
    try {
      if (root.existsSync()) {
        final now = DateTime.now();
        for (final d in root.listSync()) {
          if (now.difference(d.statSync().modified).inHours >= 24) d.deleteSync(recursive: true);
        }
      }
    } catch (_) {}
    final dir = Directory(p.join(root.path, '${DateTime.now().microsecondsSinceEpoch}'));
    if (!mounted) return;
    showDialog(context: context, barrierDismissible: false, builder: (_) => const Center(child: CircularProgressIndicator()));
    String? out;
    Object? err;
    try {
      await ArchiveService.extract(widget.path, dir.path, password: _pw, only: [n.full]);
      final guess = p.join(dir.path, ArchiveService.normName(n.full));
      if (File(guess).existsSync()) {
        out = guess;
      } else if (dir.existsSync()) {
        for (final f in dir.listSync(recursive: true)) {
          if (f is File) {
            out = f.path;
            break;
          }
        }
      }
    } catch (e) {
      err = e;
    }
    if (mounted) Navigator.of(context, rootNavigator: true).pop();
    if (!mounted) return;
    if (out == null) {
      snack(context, err != null ? _msg(err) : L.t('error'));
      return;
    }
    await Opener.open(context, out);
  }

  Future<void> _extract(List<String>? only) async {
    await showArchiveDialog(context, widget.path, widget.onChanged, only: only, password: _pw);
  }

  @override
  Widget build(BuildContext context) {
    final kids = _all == null ? const <_Node>[] : _children();
    return PopScope(
      canPop: _cwd.isEmpty,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) setState(() => _cwd = _up(_cwd));
      },
      child: Scaffold(
        appBar: AppBar(
          title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(p.basename(widget.path), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16)),
            Text(_cwd.isEmpty ? L.t('archiveContents') : '/$_cwd', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
          ]),
          actions: [
            if (_all != null)
              IconButton(
                tooltip: L.t('selectAll'),
                icon: const Icon(Icons.select_all_rounded),
                onPressed: () => setState(() {
                  for (final n in kids) {
                    _sel.add(n.full);
                  }
                }),
              ),
            if (_sel.isNotEmpty)
              IconButton(tooltip: L.t('selectNone'), icon: const Icon(Icons.deselect_rounded), onPressed: () => setState(_sel.clear)),
          ],
        ),
        body: _body(kids),
        bottomNavigationBar: _all == null
            ? null
            : SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Row(children: [
                    Expanded(child: OutlinedButton(onPressed: () => _extract(null), child: Text(L.t('extractAll')))),
                    const SizedBox(width: 10),
                    Expanded(
                      child: FilledButton(
                        onPressed: _sel.isEmpty ? null : () => _extract(_sel.toList()),
                        child: Text(L.tr('extractSelected', {'n': _sel.length})),
                      ),
                    ),
                  ]),
                ),
              ),
      ),
    );
  }

  Widget _body(List<_Node> kids) {
    if (_err != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(_err!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.redAccent)),
        ),
      );
    }
    if (_all == null) return const Center(child: CircularProgressIndicator());
    if (kids.isEmpty) return Center(child: Text(L.t('empty')));
    return ListView.builder(
      itemCount: kids.length + (_cwd.isEmpty ? 0 : 1),
      itemBuilder: (_, i) {
        if (_cwd.isNotEmpty) {
          if (i == 0) {
            return ListTile(
              leading: const Icon(Icons.folder_open_rounded),
              title: const Text('..'),
              onTap: () => setState(() => _cwd = _up(_cwd)),
            );
          }
          i--;
        }
        final n = kids[i];
        final on = _checked(n);
        return ListTile(
          leading: Icon(iconFor(n.name, n.dir), color: colorFor(n.name, n.dir)),
          title: Text(n.name, maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text(n.dir ? (n.size > 0 ? FileOps.fmt(n.size) : '') : FileOps.fmt(n.size), style: const TextStyle(fontSize: 11)),
          trailing: Checkbox(value: on, onChanged: (_) => _toggle(n)),
          onTap: n.dir ? () => setState(() => _cwd = n.full) : (_sel.isNotEmpty ? () => _toggle(n) : () => _openEntry(n)),
          onLongPress: () => _toggle(n),
        );
      },
    );
  }
}
