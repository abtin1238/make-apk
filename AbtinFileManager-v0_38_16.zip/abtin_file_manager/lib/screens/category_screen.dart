import 'dart:io';
import 'package:flutter/material.dart';
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../widgets/ui.dart';
import 'opener.dart';

class CategoryScreen extends StatefulWidget {
  final Cat cat;
  const CategoryScreen({super.key, required this.cat});
  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  List<FItem>? items;
  @override
  void initState() {
    super.initState();
    FileOps.scanCat(widget.cat).then((r) { if (mounted) setState(() => items = r); });
  }

  String get title => {
        Cat.images: L.t('images'), Cat.videos: L.t('videos'), Cat.audio: L.t('music'),
        Cat.docs: L.t('docs'), Cat.apps: L.t('apps'), Cat.archives: L.t('archives'),
      }[widget.cat]!;

  @override
  Widget build(BuildContext context) {
    final list = items;
    return Scaffold(
      appBar: AppBar(title: Text(title + (list == null ? '' : ' (${list.length})'))),
      body: list == null
          ? Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Center(child: CircularProgressIndicator()), const SizedBox(height: 12), Text(L.t('scanning'))])
          : list.isEmpty
              ? Center(child: Text(L.t('empty')))
              : widget.cat == Cat.images
                  ? GridView.builder(
                      padding: const EdgeInsets.all(4),
                      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 130, mainAxisSpacing: 3, crossAxisSpacing: 3),
                      itemCount: list.length,
                      itemBuilder: (c, i) => GestureDetector(
                        onTap: () => Opener.open(context, list[i].path, siblings: list.map((e) => e.path).toList()),
                        child: Stack(fit: StackFit.expand, children: [
Image.file(File(list[i].path), fit: BoxFit.cover, cacheWidth: 250, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image_rounded)),
Positioned(left: 0, right: 0, bottom: 0, child: Container(
  padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 2),
  color: Colors.black54,
  child: Text(FileOps.dt(list[i].modified), maxLines: 1, textAlign: TextAlign.center, style: const TextStyle(fontSize: 9.5, color: Colors.white)))),
]),
                      ),
                    )
                  : ListView.builder(
                      itemCount: list.length,
                      itemBuilder: (c, i) => ListTile(
                        leading: Icon(iconFor(list[i].path, false), color: colorFor(list[i].path, false), size: 34),
                        title: Text(list[i].name, maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text('${FileOps.fmt(list[i].size)} • ${FileOps.dt(list[i].modified)}', style: const TextStyle(fontSize: 11)),
                        onTap: () => Opener.open(context, list[i].path, siblings: list.map((e) => e.path).toList()),
                      ),
                    ),
    );
  }
}
