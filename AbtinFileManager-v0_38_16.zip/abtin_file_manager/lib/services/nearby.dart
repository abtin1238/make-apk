import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

class WfdPeer {
  final String name, addr;
  final int status; // 0 connected 1 invited 2 failed 3 available 4 unavailable
  const WfdPeer(this.name, this.addr, this.status);
}

/// Bluetooth sharing + Wi-Fi Direct. Native side: NearbyNative.kt, channel abtin/nearby.
/// Wi-Fi Direct only builds the link; files then travel over the normal LAN transfer (HTTP).
class Nearby extends ChangeNotifier {
  static const _c = MethodChannel('abtin/nearby');
  List<WfdPeer> peers = [];
  bool scanning = false, connected = false, isOwner = false, p2pEnabled = true;
  String? ownerIp;

  Nearby() {
    _c.setMethodCallHandler((call) async {
      switch (call.method) {
        case 'peers':
          peers = [
            for (final m in (call.arguments as List)) WfdPeer('${(m as Map)['name']}', '${m['addr']}', (m['status'] as num).toInt()),
          ];
        case 'state':
          p2pEnabled = call.arguments == true;
        case 'conn':
          final m = call.arguments as Map;
          connected = m['connected'] == true;
          isOwner = m['owner'] == true;
          ownerIp = m['ownerIp'] as String?;
      }
      notifyListeners();
    });
  }

  // ── Bluetooth
  static Future<bool> btEnabled() async => await _c.invokeMethod<bool>('btEnabled') ?? false;
  static Future<void> btSend(List<String> paths) => _c.invokeMethod('btSend', {'paths': paths});
  static Future<void> btSettings() => _c.invokeMethod('btSettings');

  // ── Wi-Fi Direct
  Future<void> start() async {
    await [Permission.locationWhenInUse, Permission.nearbyWifiDevices].request();
    scanning = true;
    notifyListeners();
    try {
      await _c.invokeMethod('wfdStart');
    } catch (_) {
      scanning = false;
      notifyListeners();
      rethrow;
    }
  }

  Future<void> stop() async {
    scanning = false;
    await _c.invokeMethod('wfdStop');
    notifyListeners();
  }

  Future<void> connect(String addr) => _c.invokeMethod('wfdConnect', {'addr': addr});

  Future<void> disconnect() async {
    await _c.invokeMethod('wfdDisconnect');
    connected = false;
    ownerIp = null;
    notifyListeners();
  }
}
