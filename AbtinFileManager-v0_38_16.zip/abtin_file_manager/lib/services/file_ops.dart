import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'native.dart';
import 'saf.dart';
import 'folder_sizes.dart';

/// Error with a l10n key (shown to the user as-is).
class OpError implements Exception {
  final String key;
  final String? arg;
  const OpError(this.key, [this.arg]);
  @override
  String toString() => arg == null ? key : '$key: $arg';
}

class FItem {
  final FileSystemEntity entity;
  final bool isDir;
  final int size;
  final DateTime modified;
  FItem(this.entity, this.isDir, this.size, this.modified);
  String get path => entity.path;
  String get name => p.basename(entity.path);
}

class StorageRoot {
  final String name, path;
  final bool sd;
  StorageRoot(this.name, this.path, this.sd);
}

enum Cat { images, videos, audio, docs, apps, archives }

class FileOps {
  static const root = '/storage/emulated/0';
  static const downloads = '/storage/emulated/0/Download';

  static const Map<Cat, Set<String>> exts = {
    Cat.images: {'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'heic', 'heif', 'svg', 'tiff', 'ico'},
    Cat.videos: {'mp4', 'mkv', 'avi', 'mov', 'wmv', 'flv', 'webm', 'm4v', '3gp', 'ts', 'mpg', 'mpeg', 'vob', 'ogv'},
    Cat.audio: {'mp3', 'wav', 'flac', 'aac', 'm4a', 'ogg', 'opus', 'wma', 'amr', 'mid', 'midi', 'ape', 'aiff'},
    Cat.docs: {'pdf', 'doc', 'docx', 'docm', 'dotx', 'dotm', 'xls', 'xlsx', 'ppt', 'pptx', 'txt', 'rtf', 'odt', 'ods', 'odp', 'csv', 'epub', 'md', 'json', 'xml', 'html', 'log'},
    Cat.apps: {'apk', 'xapk', 'apks', 'apkm', 'aab'},
    Cat.archives: {'zip', 'rar', '7z', 'tar', 'gz', 'tgz', 'bz2', 'tbz', 'tbz2', 'xz', 'txz', 'jar', 'cbz', 'cbr', 'lzma', 'z'},
  };
  static const textExts = {'txt', 'md', 'json', 'xml', 'html', 'htm', 'css', 'js', 'dart', 'kt', 'java', 'py', 'log', 'csv', 'ini', 'conf', 'yaml', 'yml', 'srt', 'vtt', 'lrc', 'sh', 'properties', 'gradle', 'cfg', 'kts', 'ts', 'tsx', 'jsx', 'c', 'cpp', 'h', 'hpp', 'cs', 'go', 'rs', 'swift', 'php', 'sql', 'toml', 'rb', 'bat', 'scss', 'bash', 'scala', 'groovy', 'smali'};

  static String ext(String path) => p.extension(path).toLowerCase().replaceFirst('.', '');
  /// x.7z.001, x.zip.002, x.z01, x.r00 – parts of multi-volume archives.
  static final _volume = RegExp(r'\.(7z|zip|rar|tar|gz|tgz|bz2|xz)\.\d{3}$|\.z\d{2}$|\.r\d{2}$', caseSensitive: false);
  static Cat? catOf(String path) {
    if (_volume.hasMatch(path)) return Cat.archives;
    final e = ext(path);
    for (final en in exts.entries) {
      if (en.value.contains(e)) return en.key;
    }
    return null;
  }

  static bool isCat(String path, Cat c) => catOf(path) == c;
  static bool isText(String path) => textExts.contains(ext(path));

  /// 'yyyy-MM-dd HH:mm'
  static String dt(DateTime d) {
    String t(int n) => n.toString().padLeft(2, '0');
    return '${d.year}-${t(d.month)}-${t(d.day)} ${t(d.hour)}:${t(d.minute)}';
  }

  static String fmt(int b) {
    if (b < 1024) return '$b B';
    const u = ['KB', 'MB', 'GB', 'TB'];
    double v = b / 1024;
    int i = 0;
    while (v >= 1024 && i < u.length - 1) {
      v /= 1024;
      i++;
    }
    return '${v.toStringAsFixed(v >= 100 ? 0 : 1)} ${u[i]}';
  }

  static List<StorageRoot> roots() {
    final r = [StorageRoot('internal', root, false)];
    try {
      for (final e in Directory('/storage').listSync()) {
        final n = p.basename(e.path);
        if (n == 'emulated' || n == 'self' || e is! Directory) continue;
        r.add(StorageRoot(n, e.path, true));
      }
    } catch (_) {}
    return r;
  }

  static Future<List<FItem>> list(String dir, {bool hidden = false, int sortBy = 0, bool asc = true}) async {
    final out = <FItem>[];
    await for (final e in Directory(dir).list(followLinks: false)) {
      if (!hidden && p.basename(e.path).startsWith('.')) continue;
      if (p.basename(e.path) == '.AbtinTrash') continue;
      try {
        final st = await e.stat();
        out.add(FItem(e, st.type == FileSystemEntityType.directory, st.size, st.modified));
      } catch (_) {}
    }
    out.sort((a, b) {
      if (a.isDir != b.isDir) return a.isDir ? -1 : 1;
      int c;
      switch (sortBy) {
        case 1: c = a.size.compareTo(b.size); break;
        case 2: c = a.modified.compareTo(b.modified); break;
        case 3: c = ext(a.path).compareTo(ext(b.path)); break;
        default: c = a.name.toLowerCase().compareTo(b.name.toLowerCase());
      }
      return asc ? c : -c;
    });
    return out;
  }

  static bool exists(String path) => FileSystemEntity.typeSync(path, followLinks: false) != FileSystemEntityType.notFound;

  static String unique(String dir, String name) {
    var t = p.join(dir, name);
    if (exists(t)) {
      final base = p.basenameWithoutExtension(name), e = p.extension(name);
      var i = 1;
      do {
        t = p.join(dir, '$base ($i)$e');
        i++;
      } while (exists(t));
    }
    return t;
  }

  static final _bad = RegExp(r'[\\/:*?"<>|\x00-\x1F]');

  /// Returns the cleaned name or throws [OpError].
  static String checkName(String raw) {
    final n = raw.trim();
    if (n.isEmpty) throw const OpError('nameEmpty');
    if (n == '.' || n == '..' || _bad.hasMatch(n)) throw const OpError('invalidName');
    if (utf8.encode(n).length > 255) throw const OpError('nameTooLong');
    return n;
  }

  static Future<void> _scan(Iterable<String> paths) async {
    final l = paths.toList();
    if (l.isNotEmpty) await Native.scanMany(l);
  }

  static Future<List<String>> _filesIn(FileSystemEntity e) async {
    if (e is File) return [e.path];
    if (e is Directory) return [await for (final f in walk(e.path, hidden: true)) f.path];
    return [e.path];
  }

  static Future<void> copy(FileSystemEntity src, String destDir) async {
    if (src is Directory && p.isWithin(src.path, destDir) || src.path == destDir) {
      throw Exception('Cannot copy a folder into itself');
    }
    final target = unique(destDir, p.basename(src.path));
    if (src is Directory) {
      await Directory(target).create(recursive: true);
      await for (final c in src.list(followLinks: false)) {
        await copy(c, target);
      }
    } else if (src is File) {
      await src.copy(target);
    }
  }

  static Future<void> move(FileSystemEntity src, String destDir) async {
    if (p.dirname(src.path) == destDir) return;
    final target = unique(destDir, p.basename(src.path));
    try {
      await src.rename(target);
    } on FileSystemException {
      await copy(src, destDir);
      await delete(src);
    }
  }

  /// Deletes a file / folder / link. Missing entries are ignored.
  static Future<void> delete(FileSystemEntity e) async {
    FolderSizes.invalidate(e.path);
    final gone = await _filesIn(e);
    if (await Saf.use(e.path)) {
      if (FileSystemEntity.typeSync(e.path, followLinks: false) != FileSystemEntityType.notFound) await Saf.delete(e.path);
      await _scan(gone);
      return;
    }
    try {
      final t = FileSystemEntity.typeSync(e.path, followLinks: false);
      if (t == FileSystemEntityType.notFound) return;
      if (t == FileSystemEntityType.link) {
        await Link(e.path).delete();
      } else if (t == FileSystemEntityType.directory) {
        await Directory(e.path).delete(recursive: true);
      } else {
        await File(e.path).delete();
      }
    } on FileSystemException catch (x) {
      if (exists(e.path)) throw OpError('delFail', '${p.basename(e.path)} (${x.osError?.message ?? x.message})');
    }
    await _scan(gone);
  }

  static Future<void> rename(FileSystemEntity e, String rawName) async {
    final name = checkName(rawName);
    final old = e.path;
    if (p.basename(old) == name) return;
    final target = p.join(p.dirname(old), name);
    var viaTmp = false;
    if (exists(target)) {
      // same entity under a different case (case-insensitive FS) is fine, anything else is a clash
      if (p.basename(old).toLowerCase() == name.toLowerCase() && FileSystemEntity.identicalSync(old, target)) {
        viaTmp = true;
      } else {
        throw OpError('exists', name);
      }
    }
    FolderSizes.invalidate(old);
    FolderSizes.invalidate(target);
    final files = await _filesIn(e);
    try {
      if (viaTmp) {
        final tmp = unique(p.dirname(old), '.${p.basename(old)}.tmp');
        await _rawRename(old, tmp);
        await _rawRename(tmp, target);
      } else {
        await _rawRename(old, target);
      }
    } on FileSystemException catch (x) {
      throw OpError('renameFail', x.osError?.message ?? x.message);
    }
    await _scan([
      ...files,
      if (e is Directory) ...files.map((f) => p.join(target, p.relative(f, from: old))) else target,
    ]);
  }

  static Future<void> _rawRename(String from, String to) async {
    if (await Saf.use(from)) {
      await Saf.rename(from, p.basename(to));
      return;
    }
    final t = FileSystemEntity.typeSync(from, followLinks: false);
    if (t == FileSystemEntityType.directory) {
      await Directory(from).rename(to);
    } else if (t == FileSystemEntityType.link) {
      await Link(from).rename(to);
    } else {
      await File(from).rename(to);
    }
  }

  static Future<void> mkdir(String dir, String rawName) async {
    final name = checkName(rawName);
    final t = p.join(dir, name);
    if (exists(t)) throw OpError('exists', name);
    FolderSizes.invalidate(t);
    if (await Saf.use(t)) {
      await Saf.mkdirs(t);
      return;
    }
    try {
      await Directory(t).create();
    } on FileSystemException catch (x) {
      throw OpError('createFail', x.osError?.message ?? x.message);
    }
  }

  static Future<void> touch(String dir, String rawName) async {
    final name = checkName(rawName);
    final t = p.join(dir, name);
    if (exists(t)) throw OpError('exists', name);
    FolderSizes.invalidate(t);
    if (await Saf.use(t)) {
      await Saf.createFile(t);
      await _scan([t]);
      return;
    }
    try {
      await File(t).create();
    } on FileSystemException catch (x) {
      throw OpError('createFail', x.osError?.message ?? x.message);
    }
    await _scan([t]);
  }

  static Future<int> dirSize(FileSystemEntity e) async {
    if (e is File) return e.length();
    int t = 0;
    await for (final f in walk(e.path, hidden: true)) {
      try { t += await f.length(); } catch (_) {}
    }
    return t;
  }

  static Stream<File> walk(String dir, {bool hidden = false, bool skipAndroid = false}) async* {
    List<FileSystemEntity> items;
    try {
      items = await Directory(dir).list(followLinks: false).toList();
    } catch (_) {
      return;
    }
    for (final e in items) {
      final n = p.basename(e.path);
      if (!hidden && n.startsWith('.')) continue;
      if (e is File) {
        yield e;
      } else if (e is Directory) {
        if (skipAndroid && dir == root && n == 'Android') continue;
        yield* walk(e.path, hidden: hidden, skipAndroid: skipAndroid);
      }
    }
  }

  static Future<List<FItem>> scanCat(Cat c, {String dir = root}) async {
    final out = <FItem>[];
    await for (final f in walk(dir, skipAndroid: true)) {
      if (isCat(f.path, c)) {
        try {
          final s = await f.stat();
          out.add(FItem(f, false, s.size, s.modified));
        } catch (_) {}
      }
    }
    out.sort((a, b) => b.modified.compareTo(a.modified));
    return out;
  }
}
