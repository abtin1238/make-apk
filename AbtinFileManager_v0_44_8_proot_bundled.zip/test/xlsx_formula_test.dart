import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/xlsx_format.dart';
import 'package:abtin_file_manager/services/xlsx_formula.dart';
import 'package:abtin_file_manager/services/office_service.dart';
import 'package:abtin_file_manager/services/xlsx_model.dart';

void main() {
  group('XlsxFormulaEngine', () {
    final values = <String, dynamic>{'A1': 10, 'A2': 20, 'A3': 30, 'B1': 'Abtin'};
    dynamic cell(String ref) => values[ref] ?? '';
    List<dynamic> range(String a, String b) {
      if (a == 'A1' && b == 'A3') return [10, 20, 30];
      return const [];
    }

    test('arithmetic and precedence', () {
      expect(XlsxFormulaEngine.evaluate('=2+3*4', cell: cell, range: range), 14.0);
      expect(XlsxFormulaEngine.evaluate('=(2+3)*4', cell: cell, range: range), 20.0);
    });

    test('cell references and ranges', () {
      expect(XlsxFormulaEngine.evaluate('=A1+A2', cell: cell, range: range), 30.0);
      expect(XlsxFormulaEngine.evaluate('=SUM(A1:A3)', cell: cell, range: range), 60.0);
      expect(XlsxFormulaEngine.evaluate('=AVERAGE(A1:A3)', cell: cell, range: range), 20.0);
    });

    test('common text and logical functions', () {
      expect(XlsxFormulaEngine.evaluate('=CONCAT(B1," Maps")', cell: cell, range: range), 'Abtin Maps');
      expect(XlsxFormulaEngine.evaluate('=IF(A1>5,"yes","no")', cell: cell, range: range), 'yes');
      expect(XlsxFormulaEngine.evaluate('=ROUND(3.14159,2)', cell: cell, range: range), 3.14);
    });

    test('division by zero returns an Excel error', () {
      expect(XlsxFormulaEngine.evaluate('=1/0', cell: cell, range: range), '#DIV/0!');
    });
  });

  group('XlsxFormulaEngine – extended functions', () {
    // A1:B3 = [[1,"a"],[2,"b"],[3,"c"]]
    final grid = <String, dynamic>{'A1': 1, 'B1': 'a', 'A2': 2, 'B2': 'b', 'A3': 3, 'B3': 'c'};
    dynamic cell(String ref) => grid[ref] ?? '';
    List<dynamic> range(String a, String b) {
      final x = XRange.parse('$a:$b')!;
      return [for (final r in x.refs) grid[r] ?? ''];
    }

    dynamic ev(String f) => XlsxFormulaEngine.evaluate(f, cell: cell, range: range, now: DateTime(2024, 3, 15, 10, 30));

    test('lookup', () {
      expect(ev('=VLOOKUP(2,A1:B3,2,FALSE)'), 'b');
      expect(ev('=INDEX(A1:B3,3,2)'), 'c');
      expect(ev('=MATCH(3,A1:A3,0)'), 3.0);
      expect(ev('=VLOOKUP(9,A1:B3,2,FALSE)'), '#N/A');
    });

    test('error handling functions', () {
      expect(ev('=IFERROR(1/0,"x")'), 'x');
      expect(ev('=IFERROR(5,"x")'), 5.0);
      expect(ev('=ISERROR(1/0)'), true);
      expect(ev('=IF(A1=0,0,10/A1)'), 10.0);
    });

    test('conditional aggregates', () {
      expect(ev('=SUMIF(A1:A3,">1")'), 5.0);
      expect(ev('=COUNTIF(B1:B3,"a")'), 1);
      expect(ev('=SUMIFS(A1:A3,B1:B3,"<>a")'), 5.0);
      expect(ev('=AVERAGEIF(A1:A3,">=2")'), 2.5);
    });

    test('text', () {
      expect(ev('=SUBSTITUTE("a-b-c","-","+")'), 'a+b+c');
      expect(ev('=TEXT(1234.5,"#,##0.00")'), '1,234.50');
      expect(ev('=PROPER("hello world")'), 'Hello World');
      expect(ev('=TEXTJOIN(",",TRUE,B1:B3)'), 'a,b,c');
      expect(ev('=FIND("c","abc")'), 3.0);
    });

    test('statistics and math', () {
      expect(ev('=MEDIAN(A1:A3)'), 2.0);
      expect(ev('=LARGE(A1:A3,2)'), 2.0);
      expect(ev('=SUMPRODUCT(A1:A3,A1:A3)'), 14.0);
      expect(ev('=MOD(-3,2)'), 1.0);
      expect(ev('=ROUNDUP(2.1,0)'), 3.0);
      expect(ev('=GCD(12,18)'), 6.0);
    });

    test('dates', () {
      expect(ev('=YEAR(TODAY())'), 2024.0);
      expect(ev('=MONTH(DATE(2020,5,17))'), 5.0);
      expect(ev('=DAYS(DATE(2024,3,10),DATE(2024,3,1))'), 9.0);
      expect(ev('=EOMONTH(DATE(2024,1,31),1)'), XNumFmt.toSerial(DateTime.utc(2024, 2, 29)));
      expect(ev('=DATEDIF(DATE(2020,1,1),DATE(2024,6,1),"Y")'), 4.0);
    });

    test('finance', () {
      expect((ev('=PMT(0.01,12,-1000)') as double), closeTo(88.8488, 0.001));
    });

    test('unknown names and cross-sheet references', () {
      expect(ev('=FOO(1)'), '#NAME?');
      final v = XlsxFormulaEngine.evaluate("='My Sheet'!A1+Other!B2", cell: cell, range: range, sheetCell: (s, r) => s == 'My Sheet' ? 5 : 7);
      expect(v, 12.0);
    });
  });

  group('Xlsx formula fill', () {
    test('relative references shift while absolute references stay fixed', () {
      expect(xlsxShiftFormula('AVERAGE(A2:B2)+\$C\$1', 0, 1),
          'AVERAGE(A3:B3)+\$C\$1');
      expect(xlsxShiftFormula('SUM(\$A1:B\$3)', 1, 1), 'SUM(\$A2:C\$3)');
    });
  });

  group('XNumFmt', () {
    test('numbers', () {
      expect(XNumFmt.format(1234.567, '0.00'), '1234.57');
      expect(XNumFmt.format(1234.567, '#,##0'), '1,235');
      expect(XNumFmt.format(0.256, '0%'), '26%');
      expect(XNumFmt.format(0.256, '0.0%'), '25.6%');
      expect(XNumFmt.format(-5, '0.0'), '-5.0');
      expect(XNumFmt.format(1500, '"\$"#,##0.00'), '\$1,500.00');
    });

    test('dates and times', () {
      final d = XNumFmt.toSerial(DateTime.utc(2024, 3, 5, 14, 7, 9));
      expect(XNumFmt.format(d, 'yyyy-mm-dd'), '2024-03-05');
      expect(XNumFmt.format(d, 'h:mm:ss'), '14:07:09');
      expect(XNumFmt.format(d, 'h:mm AM/PM'), '2:07 PM');
      expect(XNumFmt.format(d, 'dd/mm/yyyy'), '05/03/2024');
    });

    test('general', () {
      expect(XNumFmt.general(3.0), '3');
      expect(XNumFmt.general(0.1 + 0.2), '0.3');
    });
  });
}
