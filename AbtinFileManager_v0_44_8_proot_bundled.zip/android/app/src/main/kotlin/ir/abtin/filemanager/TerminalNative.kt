package ir.abtin.filemanager

import android.os.Build
import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/** Manages real Android PTY sessions. forkpty and terminal I/O are implemented by TerminalPty JNI. */
class TerminalNative(
    messenger: BinaryMessenger,
    private val homeDirectory: String,
    private val tempDirectory: String,
    private val apkPath: String = "",
    private val nativeLibDir: String = "",
) : EventChannel.StreamHandler {
    private val main = Handler(Looper.getMainLooper())
    private val sessions = ConcurrentHashMap<String, Session>()
    @Volatile private var eventSink: EventChannel.EventSink? = null

    init {
        MethodChannel(messenger, "abtin/terminal").setMethodCallHandler(::onMethodCall)
        EventChannel(messenger, "abtin/terminal/events").setStreamHandler(this)
    }

    private fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "start" -> start(call, result)
            "writeLine" -> write(call, result, appendNewline = true)
            "writeRaw" -> write(call, result, appendNewline = false)
            "interrupt" -> control(call, result, 3)
            "eof" -> control(call, result, 4)
            "resize" -> resize(call, result)
            "close" -> {
                val id = call.argument<String>("sessionId")
                result.success(id != null && closeSession(id))
            }
            "closeAll" -> {
                closeAll()
                result.success(true)
            }
            else -> result.notImplemented()
        }
    }

    private fun start(call: MethodCall, result: MethodChannel.Result) {
        try {
            val requested = call.argument<String>("cwd")
                ?: throw IllegalArgumentException("مسیر کاری مشخص نشده است")
            val directory = java.io.File(requested).canonicalFile
            if (!directory.exists() || !directory.isDirectory) {
                throw IllegalArgumentException("مسیر کاری باید پوشه‌ای موجود باشد")
            }
            if (!directory.canRead() || !directory.canExecute()) {
                throw IllegalArgumentException("دسترسی لازم برای ورود به این پوشه وجود ندارد")
            }
            val columns = (call.argument<Int>("columns") ?: 80).coerceIn(20, 500)
            val rows = (call.argument<Int>("rows") ?: 24).coerceIn(5, 300)
            // Package prefix ($HOME/usr), shell init (pkg command + aliases) and extra environment.
            val extraEnv = try {
                PkgEnv.prepare(homeDirectory, apkPath, Build.SUPPORTED_ABIS.firstOrNull() ?: "", nativeLibDir)
            } catch (_: Throwable) {
                ""
            }
            val native = TerminalPty.startNative(
                directory.path,
                homeDirectory,
                tempDirectory,
                columns,
                rows,
                extraEnv,
            )
            if (native.size < 2 || native[0] <= 0 || native[1] < 0) {
                throw IOException("PTY backend returned invalid process handles")
            }
            val id = UUID.randomUUID().toString()
            val session = Session(id, native[0].toInt(), native[1].toInt(), directory.path)
            sessions[id] = session
            session.readerThread = Thread({ readOutput(session) }, "terminal-pty-reader-$id").apply {
                isDaemon = true
                start()
            }
            result.success(mapOf("sessionId" to id, "cwd" to directory.path, "pty" to true))
        } catch (e: Throwable) {
            result.error("TERMINAL_START", e.message ?: "راه‌اندازی PTY ناموفق بود", null)
        }
    }

    private fun write(call: MethodCall, result: MethodChannel.Result, appendNewline: Boolean) {
        val session = getSession(call, result) ?: return
        val text = call.argument<String>("text")
        if (text == null) {
            result.error("TERMINAL_ARGUMENT", "متن ورودی نامعتبر است", null)
            return
        }
        val bytes = (if (appendNewline) "$text\n" else text).toByteArray(StandardCharsets.UTF_8)
        writeBytes(session, bytes, result)
    }

    private fun control(call: MethodCall, result: MethodChannel.Result, value: Int) {
        val session = getSession(call, result) ?: return
        val code = TerminalPty.sendControlNative(session.masterFd, value)
        if (code < 0) result.error("TERMINAL_WRITE", "نوشتن نویسهٔ کنترلی ناموفق بود (errno ${-code})", null)
        else result.success(true)
    }

    private fun resize(call: MethodCall, result: MethodChannel.Result) {
        val session = getSession(call, result) ?: return
        val columns = (call.argument<Int>("columns") ?: 80).coerceIn(20, 500)
        val rows = (call.argument<Int>("rows") ?: 24).coerceIn(5, 300)
        val code = TerminalPty.resizeNative(session.masterFd, columns, rows)
        if (code < 0) result.error("TERMINAL_RESIZE", "تنظیم اندازهٔ PTY ناموفق بود (errno ${-code})", null)
        else result.success(true)
    }

    private fun getSession(call: MethodCall, result: MethodChannel.Result): Session? {
        val id = call.argument<String>("sessionId")
        if (id == null) {
            result.error("TERMINAL_ARGUMENT", "شناسهٔ نشست نامعتبر است", null)
            return null
        }
        val session = sessions[id]
        if (session == null || session.closed) {
            result.error("TERMINAL_CLOSED", "نشست PTY فعال نیست", null)
            return null
        }
        return session
    }

    private fun writeBytes(session: Session, bytes: ByteArray, result: MethodChannel.Result) {
        try {
            synchronized(session.writeLock) {
                if (session.closed) throw IOException("نشست PTY فعال نیست")
                var offset = 0
                while (offset < bytes.size) {
                    val count = TerminalPty.writeNative(session.masterFd, bytes, offset, bytes.size - offset)
                    if (count < 0) throw IOException("نوشتن در PTY ناموفق بود (errno ${-count})")
                    if (count == 0) throw IOException("PTY نوشتن را نپذیرفت")
                    offset += count
                }
            }
            result.success(true)
        } catch (e: Throwable) {
            result.error("TERMINAL_WRITE", e.message ?: "نوشتن در PTY ناموفق بود", null)
        }
    }

    private fun readOutput(session: Session) {
        val source = object : InputStream() {
            private val one = ByteArray(1)
            override fun read(): Int {
                val count = TerminalPty.readNative(session.masterFd, one, 1)
                if (count == 0) return -1
                if (count < 0) throw IOException("PTY closed (errno ${-count})")
                return one[0].toInt() and 0xff
            }

            override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
                if (length == 0) return 0
                val temp = ByteArray(minOf(length, 8192))
                val count = TerminalPty.readNative(session.masterFd, temp, temp.size)
                if (count == 0) return -1
                if (count < 0) throw IOException("PTY closed (errno ${-count})")
                temp.copyInto(buffer, offset, 0, count)
                return count
            }
        }
        try {
            InputStreamReader(source, StandardCharsets.UTF_8).use { reader ->
                val chars = CharArray(4096)
                while (true) {
                    val count = reader.read(chars)
                    if (count < 0) break
                    if (count > 0) emit(mapOf(
                        "sessionId" to session.id,
                        "type" to "output",
                        "text" to String(chars, 0, count),
                    ))
                }
            }
        } catch (_: Throwable) {
            // PTY returns EIO when the shell closes; this is the normal end-of-session path.
        } finally {
            session.closed = true
            val exitCode = try { TerminalPty.waitForNative(session.pid) } catch (_: Throwable) { 255 }
            session.closeMaster()
            sessions.remove(session.id, session)
            emit(mapOf("sessionId" to session.id, "type" to "exit", "exitCode" to exitCode))
        }
    }

    private fun emit(event: Map<String, Any?>) {
        main.post { eventSink?.success(event) }
    }

    override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        eventSink = events
    }

    override fun onCancel(arguments: Any?) {
        eventSink = null
    }

    private fun closeSession(id: String): Boolean {
        val session = sessions[id] ?: return false
        if (session.closed) return false
        session.closed = true
        try { TerminalPty.terminateNative(session.pid) } catch (_: Throwable) {}
        // A misbehaving foreground process must not leave a blocked reader or child behind.
        Thread({
            try { Thread.sleep(700) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
            if (sessions.containsKey(id)) {
                try { TerminalPty.forceKillNative(session.pid) } catch (_: Throwable) {}
                session.closeMaster()
            }
        }, "terminal-pty-kill-$id").apply { isDaemon = true; start() }
        return true
    }

    fun closeAll() {
        sessions.keys.toList().forEach { closeSession(it) }
    }

    private inner class Session(
        val id: String,
        val pid: Int,
        val masterFd: Int,
        val cwd: String,
    ) {
        val writeLock = Any()
        private val fdClosed = AtomicBoolean(false)
        @Volatile var closed = false
        @Volatile var readerThread: Thread? = null

        fun closeMaster() {
            if (fdClosed.compareAndSet(false, true)) TerminalPty.closeNative(masterFd)
        }
    }
}
