arm64-v8a/libproot.so          = proot (static aarch64, from skirsten/proot-portable-android-binaries, Termux-based, GPL-2.0)
arm64-v8a/libproot-loader.so   = 64-bit loader carved out of that binary (it embeds its loaders)
arm64-v8a/libproot-loader32.so = 32-bit loader carved out of the same binary
The terminal uses them automatically (PROOT_LOADER / PROOT_LOADER_32), so nothing is extracted/executed from app data.
32-bit-only phones (armeabi-v7a) have no bundled proot: they fall back to the download in `alpine bootstrap`.
