import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

/// Artwork bounds in design units (the flat cassette illustration).
const Rect _kBounds = Rect.fromLTWH(58, 84, 684, 432);

/// width / height of the cassette artwork.
const double kCassetteAspect = 684 / 432;

// ---- palette (dark cassette with gold reels, taken from the reference) ----
const Color _kShell = Color(0xFF1B1C20);
const Color _kShellHi = Color(0xFF2E3037);
const Color _kShellLo = Color(0xFF0F1013);
const Color _kEdge = Color(0xFF3B3D45);
const Color _kInk = Color(0xFF0B0B0D);
const Color _kGroove = Color(0xFF3A3D45);
const Color _kRed = Color(0xFFE8392F);
const Color _kCyan = Color(0xFF19D3EA);
const Color _kGold = Color(0xFFE2B52B);
const Color _kGoldHi = Color(0xFFFFE08A);
const Color _kGoldDark = Color(0xFF9A6C14);
const Color _kBand = Color(0xFF1A1B1F);

// ---- tape mechanics (design units) ----
const double _kReelR = 50; // radius of the gold reel
const double _kPackMin = 58; // tape pack radius when the reel is empty
const double _kPackMax = 150; // tape pack radius when the reel holds all the tape
const double _kTapeSpeed = 150; // tape linear speed at 1.0x, units / second

const Rect _kWinFrame = Rect.fromLTRB(338, 232, 462, 328);
const Rect _kWinInner = Rect.fromLTRB(344, 238, 456, 322);
const Offset _kLeftReel = Offset(275, 280);
const Offset _kRightReel = Offset(525, 280);

/// Radius of the tape pack that holds [fill] (0..1) of the whole tape.
/// Tape area is conserved, so r^2 grows linearly with the amount of tape.
double _packRadius(double fill) {
  final f = fill.clamp(0.0, 1.0).toDouble();
  return math.sqrt(_kPackMin * _kPackMin +
      (_kPackMax * _kPackMax - _kPackMin * _kPackMin) * f);
}

bool _hasRtl(String s) => RegExp(r'[֐-ࣿ]').hasMatch(s);

class _CassetteModel extends ChangeNotifier {
  double leftAngle = 0;
  double rightAngle = math.pi; // the red marker of the right reel starts at the bottom
  double progress = 0;
  double travel = 0; // distance the tape has travelled (design units)
  void ping() => notifyListeners();
}

/// A flat cassette whose reels turn, whose tape moves from the left reel to the
/// right reel and whose tape packs grow / shrink with the song position.
///
/// The speed follows the playback rate: tape linear speed is constant
/// (`_kTapeSpeed * rate`) so a reel turns faster while it is nearly empty and
/// slower when it is full, exactly like a real cassette.
class AnimatedCassette extends StatefulWidget {
  final bool playing;
  final double rate;

  /// Song position as 0..1, read every frame.
  final double Function() progress;
  final String title;
  final String artist;
  final Uint8List? art;

  /// Text printed on the dark band at the bottom of the label.
  final String bandText;

  const AnimatedCassette({
    super.key,
    required this.playing,
    required this.rate,
    required this.progress,
    required this.title,
    this.artist = '',
    this.art,
    this.bandText = '',
  });

  @override
  State<AnimatedCassette> createState() => _AnimatedCassetteState();
}

class _AnimatedCassetteState extends State<AnimatedCassette>
    with SingleTickerProviderStateMixin {
  final _CassetteModel _m = _CassetteModel();
  late final Ticker _ticker;
  Duration _last = Duration.zero;

  @override
  void initState() {
    super.initState();
    _m.progress = widget.progress();
    _ticker = createTicker(_tick)..start();
  }

  void _tick(Duration t) {
    var dt = (t - _last).inMicroseconds / 1000000.0;
    _last = t;
    if (dt < 0 || dt > .1) dt = .016;
    final p = widget.progress().clamp(0.0, 1.0).toDouble();
    final moved = (p - _m.progress).abs() > .0002;
    _m.progress = p;
    if (widget.playing) {
      final rate = widget.rate.clamp(.25, 4.0).toDouble();
      final v = _kTapeSpeed * rate;
      // angular speed = linear speed / radius of the pack
      _m.leftAngle += v / _packRadius(1 - p) * dt;
      _m.rightAngle += v / _packRadius(p) * dt;
      _m.travel += v * dt;
    }
    if (widget.playing || moved) _m.ping();
  }

  @override
  void dispose() {
    _ticker.dispose();
    _m.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: kCassetteAspect,
      child: LayoutBuilder(builder: (context, bc) {
        final sx = bc.maxWidth / _kBounds.width;
        double x(double v) => (v - _kBounds.left) * sx;
        double y(double v) => (v - _kBounds.top) * sx;
        final hasArt = widget.art != null;
        final title = widget.title.trim();
        final artist = widget.artist.trim();
        final band = (widget.bandText.trim().isEmpty ? title : widget.bandText).trim();
        final tRtl = _hasRtl(title);
        final aRtl = _hasRtl(artist);
        return Stack(clipBehavior: Clip.none, children: [
          const Positioned.fill(
              child: RepaintBoundary(
                  child: CustomPaint(painter: _CassetteBodyPainter()))),
          // artist photo on the right of the label
          Positioned(
            left: x(597),
            top: y(219),
            width: 96 * sx,
            height: 121 * sx,
            child: hasArt
                ? Image.memory(widget.art!,
                    fit: BoxFit.cover,
                    gaplessPlayback: true,
                    errorBuilder: (_, __, ___) => const SizedBox.shrink())
                : Center(
                    child: Icon(Icons.music_note_rounded,
                        size: 40 * sx, color: Colors.white24)),
          ),
          Positioned.fill(
              child: RepaintBoundary(
                  child: CustomPaint(painter: _CassetteMechPainter(_m)))),
          // title (top of the white label)
          Positioned(
            left: x(129),
            top: y(144),
            width: (685 - 129) * sx,
            height: 34 * sx,
            child: Align(
              alignment: tRtl ? Alignment.centerRight : Alignment.centerLeft,
              child: Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textDirection: tRtl ? TextDirection.rtl : TextDirection.ltr,
                style: TextStyle(
                    fontFamily: tRtl ? 'Vazir' : null,
                    fontSize: 26 * sx,
                    height: 1.1,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFF0D0D0F)),
              ),
            ),
          ),
          if (artist.isNotEmpty)
            Positioned(
              left: x(129),
              top: y(180),
              width: (685 - 129) * sx,
              height: 18 * sx,
              child: Align(
                alignment: aRtl ? Alignment.centerRight : Alignment.centerLeft,
                child: Text(
                  artist,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textDirection: aRtl ? TextDirection.rtl : TextDirection.ltr,
                  style: TextStyle(
                      fontFamily: aRtl ? 'Vazir' : null,
                      fontSize: 11.5 * sx,
                      height: 1.1,
                      letterSpacing: aRtl ? 0 : 1.6 * sx,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF1A1A1C)),
                ),
              ),
            ),
          // Persian title on the dark band
          if (band.isNotEmpty)
            Positioned(
              left: x(120),
              top: y(341),
              width: 560 * sx,
              height: 48 * sx,
              child: Center(
                child: Text(
                  band,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textDirection:
                      _hasRtl(band) ? TextDirection.rtl : TextDirection.ltr,
                  style: TextStyle(
                      fontFamily: 'Vazir',
                      fontSize: 22 * sx,
                      height: 1.1,
                      color: const Color(0xFFEDEDEF)),
                ),
              ),
            ),
        ]);
      }),
    );
  }
}

// ---------------------------------------------------------------------------
// Static layer: shell, label, stripes, holes. Painted only once.
// ---------------------------------------------------------------------------
class _CassetteBodyPainter extends CustomPainter {
  const _CassetteBodyPainter();

  Paint _shellPaint(Rect r) => Paint()
    ..shader = const LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [_kShellHi, _kShell, _kShellLo])
        .createShader(r);

  void _screw(Canvas c, Offset o, {double r = 9}) {
    c.drawCircle(
        o,
        r,
        Paint()
          ..shader = const RadialGradient(
                  center: Alignment(-.3, -.4),
                  colors: [Color(0xFF50535C), Color(0xFF202227)])
              .createShader(Rect.fromCircle(center: o, radius: r)));
    c.drawCircle(
        o,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6
          ..color = _kInk);
    final d = r * .55;
    c.drawLine(
        o + Offset(-d, d),
        o + Offset(d, -d),
        Paint()
          ..strokeWidth = 2
          ..strokeCap = StrokeCap.round
          ..color = _kInk);
  }

  void _hole(Canvas c, Offset o) {
    // soft cyan glow, dark well, cyan ring
    c.drawCircle(
        o,
        15,
        Paint()
          ..color = _kCyan.withOpacity(.45)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5));
    c.drawCircle(o, 13, Paint()..color = const Color(0xFF07090B));
    c.drawCircle(
        o,
        13,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..color = _kCyan);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final s = math.min(size.width / _kBounds.width, size.height / _kBounds.height);
    canvas.save();
    canvas.scale(s);
    canvas.translate(-_kBounds.left, -_kBounds.top);

    final edge = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2.5
      ..strokeJoin = StrokeJoin.round
      ..color = _kEdge;
    final groove = Paint()
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round
      ..color = _kGroove;

    final shell = RRect.fromLTRBR(70, 88, 730, 506, const Radius.circular(14));
    // neumorphic shadows: dark one bottom-right, faint light one top-left
    canvas.drawRRect(
        shell.shift(const Offset(0, 9)),
        Paint()
          ..color = Colors.black.withOpacity(.75)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16));
    canvas.drawRRect(
        shell.shift(const Offset(-3, -3)),
        Paint()
          ..color = const Color(0xFF2A2D35).withOpacity(.35)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9));

    // side nubs
    for (final x in const [62.0, 724.0]) {
      final r = RRect.fromLTRBR(x, 352, x + 14, 506, const Radius.circular(5));
      canvas.drawRRect(r, _shellPaint(r.outerRect));
      canvas.drawRRect(r, edge..strokeWidth = 2);
    }
    edge.strokeWidth = 2.5;

    // shell
    canvas.drawRRect(shell, _shellPaint(shell.outerRect));
    canvas.drawRRect(shell, edge);
    // top bevel highlight
    canvas.drawLine(
        const Offset(84, 90.5),
        const Offset(716, 90.5),
        Paint()
          ..strokeWidth = 1.2
          ..color = Colors.white.withOpacity(.10));

    // bottom trapezoid
    final trap = Path()
      ..moveTo(190, 416)
      ..lineTo(610, 416)
      ..quadraticBezierTo(618, 416, 620, 424)
      ..lineTo(642, 504)
      ..quadraticBezierTo(644, 512, 636, 512)
      ..lineTo(164, 512)
      ..quadraticBezierTo(156, 512, 158, 504)
      ..lineTo(180, 424)
      ..quadraticBezierTo(182, 416, 190, 416)
      ..close();
    canvas.drawPath(
        trap,
        Paint()
          ..shader = const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFF26282D), Color(0xFF131418)])
              .createShader(const Rect.fromLTRB(158, 416, 644, 512)));
    canvas.drawPath(trap, edge);

    canvas.drawLine(const Offset(110, 105), const Offset(690, 105), groove);
    canvas.drawLine(const Offset(200, 425), const Offset(600, 425), groove);

    // ---- label ----
    final label = RRect.fromLTRBR(107, 128, 693, 390, const Radius.circular(6));
    canvas.drawRRect(label, Paint()..color = const Color(0xFFF6F6F6));
    canvas.save();
    canvas.clipRRect(label);
    canvas.drawRect(const Rect.fromLTRB(107, 128, 693, 143), Paint()..color = _kRed);
    canvas.drawRect(
        const Rect.fromLTRB(107, 204, 693, 219),
        Paint()
          ..shader = const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFF6F6F6), Color(0xFFD9D9DE)])
              .createShader(const Rect.fromLTRB(107, 204, 693, 219)));
    // striped left panel (black lines on white)
    final stripe = Paint()
      ..strokeWidth = 2.2
      ..color = const Color(0xFF1B1B1F);
    for (var yy = 223.0; yy < 338; yy += 5.5) {
      canvas.drawLine(Offset(107, yy), Offset(205, yy), stripe);
    }
    // photo panel background (the artwork is laid over it)
    canvas.drawRect(
        const Rect.fromLTRB(597, 219, 693, 340),
        Paint()
          ..shader = const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFF3A3F4A), Color(0xFF17181C)])
              .createShader(const Rect.fromLTRB(597, 219, 693, 340)));
    // window frame
    final frame = RRect.fromLTRBR(205, 219, 597, 340, const Radius.circular(6));
    canvas.drawRRect(frame, Paint()..color = const Color(0xFF111214));
    canvas.drawRRect(
        frame,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..color = const Color(0xFF2C2E34));
    for (final o in const [
      Offset(217, 231),
      Offset(585, 231),
      Offset(217, 328),
      Offset(585, 328)
    ]) {
      _screw(canvas, o, r: 4);
    }
    // bottom band
    canvas.drawRect(const Rect.fromLTRB(107, 340, 693, 390), Paint()..color = _kBand);
    canvas.drawLine(
        const Offset(107, 340.5),
        const Offset(693, 340.5),
        Paint()
          ..strokeWidth = 1
          ..color = Colors.white.withOpacity(.08));
    canvas.restore();
    canvas.drawRRect(
        label,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..color = _kInk);

    // holes + screws
    for (final o in const [
      Offset(243, 485),
      Offset(307, 479),
      Offset(493, 479),
      Offset(558, 485)
    ]) {
      _hole(canvas, o);
    }
    for (final o in const [
      Offset(90, 103),
      Offset(710, 103),
      Offset(90, 487),
      Offset(710, 487),
      Offset(400, 447)
    ]) {
      _screw(canvas, o);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _CassetteBodyPainter old) => false;
}

// ---------------------------------------------------------------------------
// Moving layer: gold reels, tape packs and the centre window.
// ---------------------------------------------------------------------------
class _CassetteMechPainter extends CustomPainter {
  final _CassetteModel m;
  _CassetteMechPainter(this.m) : super(repaint: m);

  void _reel(Canvas c, Offset center, double angle) {
    c.save();
    c.translate(center.dx, center.dy);
    // dark well
    c.drawCircle(Offset.zero, _kReelR + 4, Paint()..color = _kInk);
    // metallic gold ring
    final ringRect = Rect.fromCircle(center: Offset.zero, radius: _kReelR);
    c.drawCircle(
        Offset.zero,
        _kReelR,
        Paint()
          ..shader = const SweepGradient(colors: [
            _kGold,
            _kGoldHi,
            _kGoldDark,
            _kGold,
            _kGoldHi,
            _kGoldDark,
            _kGold
          ]).createShader(ringRect));
    c.drawCircle(
        Offset.zero,
        _kReelR,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = _kGoldDark);
    // turning parts
    c.save();
    c.rotate(angle);
    final dot = Paint()..color = const Color(0xFF1A1206);
    for (var i = 0; i < 12; i++) {
      final a = i * math.pi / 6;
      c.drawCircle(Offset(math.cos(a) * 41, math.sin(a) * 41), 3.6, dot);
    }
    // marker so the turning is easy to see
    c.drawPath(
        Path()
          ..moveTo(0, -_kReelR + 1)
          ..lineTo(-4.5, -_kReelR + 8)
          ..lineTo(4.5, -_kReelR + 8)
          ..close(),
        Paint()..color = const Color(0xFF3A2606));
    // hub teeth
    final tooth = Paint()..color = _kGold;
    for (var i = 0; i < 6; i++) {
      c.save();
      c.rotate(i * math.pi / 3);
      c.drawRRect(
          RRect.fromLTRBR(-3.2, -35, 3.2, -28, const Radius.circular(1.5)), tooth);
      c.restore();
    }
    c.restore();
    // glossy black ball (fixed light)
    c.drawCircle(Offset.zero, 31, Paint()..color = const Color(0xFF0A0A0C));
    c.drawCircle(
        Offset.zero,
        26,
        Paint()
          ..shader = const RadialGradient(
                  center: Alignment(-.35, -.45),
                  radius: 1.0,
                  colors: [Color(0xFF8A8D96), Color(0xFF26282E), Color(0xFF040405)],
                  stops: [0, .45, 1])
              .createShader(Rect.fromCircle(center: Offset.zero, radius: 26)));
    c.drawOval(Rect.fromCenter(center: const Offset(-9, -11), width: 11, height: 7),
        Paint()..color = Colors.white.withOpacity(.55));
    c.restore();
  }

  void _window(Canvas c, double p) {
    final frame = RRect.fromRectAndRadius(_kWinFrame, const Radius.circular(4));
    c.drawRRect(frame, Paint()..color = const Color(0xFF0E0F11));
    c.drawRRect(
        frame,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = const Color(0xFF2A2C32));
    c.save();
    c.clipRect(_kWinInner);
    // tan tape window
    c.drawRect(
        _kWinInner,
        Paint()
          ..shader = const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Color(0xFFD7C5A5), Color(0xFFA48F6D)])
              .createShader(_kWinInner));
    // brown tape packs seen through the window
    void pack(Offset centre, double r) {
      final rect = Rect.fromCircle(center: centre, radius: r);
      c.drawCircle(
          centre,
          r,
          Paint()
            ..shader = RadialGradient(
                    colors: const [Color(0xFF6B4A33), Color(0xFF3A281C), Color(0xFF22160E)],
                    stops: [(_kPackMin - 4) / r, (_kPackMin - 4) / r + (1 - (_kPackMin - 4) / r) * .6, 1.0])
                .createShader(rect));
      final wind = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = .8
        ..color = Colors.black.withOpacity(.22);
      for (var rr = r - 3; rr > _kPackMin; rr -= 3.2) {
        c.drawCircle(centre, rr, wind);
      }
    }

    pack(_kLeftReel, _packRadius(1 - p));
    pack(_kRightReel, _packRadius(p));

    // counter ticks in the middle of the window
    final tick = Paint()
      ..strokeWidth = 2.6
      ..strokeCap = StrokeCap.round
      ..color = const Color(0xFF8E9097).withOpacity(.85);
    for (var i = -2; i <= 2; i++) {
      c.drawLine(Offset(400 + i * 12.0, 262), Offset(400 + i * 12.0, 296), tick);
    }
    // glass reflection
    c.drawRect(_kWinInner.deflate(0).intersect(const Rect.fromLTRB(344, 238, 456, 252)),
        Paint()..color = Colors.white.withOpacity(.10));
    c.restore();
  }

  @override
  void paint(Canvas canvas, Size size) {
    final s = math.min(size.width / _kBounds.width, size.height / _kBounds.height);
    canvas.save();
    canvas.scale(s);
    canvas.translate(-_kBounds.left, -_kBounds.top);
    final p = m.progress.clamp(0.0, 1.0).toDouble();
    _window(canvas, p);
    _reel(canvas, _kLeftReel, m.leftAngle);
    _reel(canvas, _kRightReel, m.rightAngle);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _CassetteMechPainter old) => old.m != m;
}
