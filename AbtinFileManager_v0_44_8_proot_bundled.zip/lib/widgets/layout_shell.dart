import 'package:flutter/material.dart' hide Icon;
import 'app_icon.dart';
import '../core/l10n.dart';
import '../core/layout_scope.dart';
import '../core/layouts.dart';
import '../core/looks.dart';
import '../core/theme.dart';
import '../screens/home_cats.dart';
import 'adaptive_nav.dart';
import 'glass_kit.dart';
import 'neon_kit.dart';
import '../screens/browser_screen.dart';
import '../services/file_ops.dart';

/// Arranges the app's main tabs according to the chosen layout theme:
/// classic (bottom bar) · drawer (side menu) · dashboard (floating pill bar) · rail (slim side rail) · tabs (top tab strip).
class LayoutShell extends StatefulWidget {
  final String layout;
  final int selected;
  final ValueChanged<int> onSelect;
  final List<NavItem> items;
  final Widget body;
  final Widget? bottom; // mini player
  const LayoutShell({super.key, required this.layout, required this.selected, required this.onSelect, required this.items, required this.body, this.bottom});
  @override
  State<LayoutShell> createState() => _LayoutShellState();
}

class _LayoutShellState extends State<LayoutShell> {
  final _key = GlobalKey<ScaffoldState>();

  bool get _wide => MediaQuery.of(context).size.width >= AdaptiveNav.breakpoint;

  Widget _withMini(Widget body) => Column(children: [Expanded(child: body), if (widget.bottom != null) widget.bottom!]);

  @override
  Widget build(BuildContext context) {
    switch (widget.layout) {
      case 'drawer':
        return _drawer(context);
      case 'dashboard':
        return _dashboard(context);
      case 'rail':
        return _rail(context);
      case 'tabs':
        return _tabs(context);
    }
    // glass look on phones: frosted bottom bar (Home / Recents / Starred / More)
    if (Looks.current == 'glass' && widget.layout == 'classic' && !_wide) return _glass(context);
    if (Looks.current == 'abtin' && widget.layout == 'classic') return _abtin(context);
    return AdaptiveNav(selected: widget.selected, onSelect: widget.onSelect, items: widget.items, body: widget.body, bottom: widget.bottom);
  }

  // ---- glass: frosted translucent bottom bar over the content
  Widget _glass(BuildContext context) => Scaffold(
        extendBody: true,
        body: widget.body,
        bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
          if (widget.bottom != null) widget.bottom!,
          GlassNavBar(selected: widget.selected, onSelect: widget.onSelect, items: widget.items),
        ]),
      );

  Widget _abtin(BuildContext context) => Scaffold(
        extendBody: true,
        body: widget.body,
        bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
          if (widget.bottom != null) widget.bottom!,
          AbtinNavBar(selected: widget.selected, onSelect: widget.onSelect, items: widget.items),
        ]),
      );

  // ---- neon rail: three icons (home, transfer, settings) in a glowing strip; maps onto tabs 0, 2, 3
  Widget _neonRail(BuildContext context) {
    const map = [0, 2, 3];
    final items = [
      for (final i in map)
        if (i < widget.items.length)
          i == 3
              ? NavItem(Icons.settings_rounded, widget.items[i].label)
              : i == 2
                  ? NavItem(Icons.swap_horiz_rounded, widget.items[i].label)
                  : widget.items[i],
    ];
    final sel = map.indexOf(widget.selected);
    return Scaffold(
      body: Row(children: [
        NeonRail(
          selected: sel,
          onSelect: (k) => widget.onSelect(map[k]),
          items: items,
          onStorage: () {
            final r = FileOps.roots();
            if (r.isNotEmpty) Navigator.push(context, MaterialPageRoute(builder: (_) => BrowserScreen(initialPath: r.first.path, root: true)));
          },
        ),
        Expanded(child: LayoutScope(layout: 'rail', child: _withMini(widget.body))),
      ]),
    );
  }

  // ---- drawer: no bottom bar, side menu (always visible on tablets)
  Widget _drawer(BuildContext context) {
    if (_wide) {
      return Scaffold(
        body: Row(children: [
          SizedBox(
            width: 290,
            child: Material(color: Theme.of(context).cardColor, child: SafeArea(child: _DrawerContent(selected: widget.selected, onSelect: widget.onSelect, items: widget.items, closeAfter: false))),
          ),
          const VerticalDivider(width: 1),
          Expanded(child: LayoutScope(layout: 'drawer', child: _withMini(widget.body))),
        ]),
      );
    }
    return Scaffold(
      key: _key,
      drawer: Drawer(child: SafeArea(child: _DrawerContent(selected: widget.selected, onSelect: widget.onSelect, items: widget.items, closeAfter: true))),
      body: LayoutScope(layout: 'drawer', openMenu: () => _key.currentState?.openDrawer(), child: widget.body),
      bottomNavigationBar: widget.bottom,
    );
  }

  // ---- dashboard: floating rounded bar
  Widget _dashboard(BuildContext context) => Scaffold(
        body: LayoutScope(layout: 'dashboard', child: widget.body),
        bottomNavigationBar: Column(mainAxisSize: MainAxisSize.min, children: [
          if (widget.bottom != null) widget.bottom!,
          _FloatingNavBar(selected: widget.selected, onSelect: widget.onSelect, items: widget.items),
        ]),
      );

  // ---- rail: slim rail on every screen size (extended with labels on tablets)
  Widget _rail(BuildContext context) {
    if (Looks.current == 'neon' && widget.items.length >= 4) return _neonRail(context);
    final wide = _wide;
    final cs = Theme.of(context).colorScheme;
    final fancy = !Looks.isClassic; // neon / glass / gradient looks: the rail floats in a rounded, outlined panel
    final rail = NavigationRail(
      selectedIndex: widget.selected,
      onDestinationSelected: widget.onSelect,
      extended: wide,
      minWidth: 60,
      backgroundColor: fancy ? Colors.transparent : null,
      indicatorColor: fancy ? cs.primary.withOpacity(.25) : null,
      labelType: NavigationRailLabelType.none,
      leading: Padding(
        padding: const EdgeInsets.only(top: 8, bottom: 8),
        child: Container(
          width: 36, height: 36,
          decoration: fancy ? Looks.accent(cs, radius: BorderRadius.circular(10)) : BoxDecoration(gradient: AppColors.grad, borderRadius: BorderRadius.circular(10)),
          child: const Icon(Icons.folder_rounded, color: Colors.white, size: 20),
        ),
      ),
      destinations: [for (final i in widget.items) NavigationRailDestination(icon: Icon(i.icon), label: Text(i.label))],
    );
    return Scaffold(
      body: Row(children: [
        SafeArea(
          child: fancy
              ? Padding(
                  padding: const EdgeInsets.fromLTRB(6, 8, 6, 8),
                  child: DecoratedBox(
                    decoration: Looks.card(context, radius: 24),
                    child: ClipRRect(borderRadius: BorderRadius.circular(24), child: rail),
                  ),
                )
              : rail,
        ),
        if (!fancy) const VerticalDivider(width: 1),
        Expanded(child: LayoutScope(layout: 'rail', child: _withMini(widget.body))),
      ]),
    );
  }

  // ---- tabs: strip on top
  Widget _tabs(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      body: Column(children: [
        Material(
          color: Theme.of(context).cardColor,
          child: SafeArea(
            bottom: false,
            child: SizedBox(
              height: 54,
              child: Row(children: [
                for (var i = 0; i < widget.items.length; i++)
                  Expanded(
                    child: InkWell(
                      onTap: () => widget.onSelect(i),
                      child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                        Icon(widget.items[i].icon, size: 21, color: i == widget.selected ? cs.primary : Theme.of(context).hintColor),
                        const SizedBox(height: 2),
                        Text(widget.items[i].label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11, fontWeight: i == widget.selected ? FontWeight.bold : FontWeight.normal, color: i == widget.selected ? cs.primary : Theme.of(context).hintColor)),
                        const SizedBox(height: 4),
                        AnimatedContainer(duration: const Duration(milliseconds: 180), height: 3, margin: const EdgeInsets.symmetric(horizontal: 14), decoration: BoxDecoration(color: i == widget.selected ? cs.primary : Colors.transparent, borderRadius: BorderRadius.circular(3))),
                      ]),
                    ),
                  ),
              ]),
            ),
          ),
        ),
        Expanded(
          child: MediaQuery.removePadding(
            context: context,
            removeTop: true,
            child: LayoutScope(layout: 'tabs', child: widget.body),
          ),
        ),
        if (widget.bottom != null) widget.bottom!,
      ]),
    );
  }
}

// ------------------------------------------------------------------ Abtin bottom bar

class AbtinNavBar extends StatelessWidget {
  final int selected;
  final ValueChanged<int> onSelect;
  final List<NavItem> items;
  const AbtinNavBar({super.key, required this.selected, required this.onSelect, required this.items});

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final fg = dark ? const Color(0xFFE8EDFF) : const Color(0xFF263557);
    return SafeArea(
      top: false,
      minimum: const EdgeInsets.fromLTRB(6, 5, 6, 5),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(6, 0, 6, 0),
        child: Container(
        height: 67,
        padding: const EdgeInsets.all(1.3),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(38),
          gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF8D21FF), Color(0xFF245BFF), Color(0xFF7E22FF)]),
          boxShadow: [BoxShadow(color: const Color(0xFF762EFF).withOpacity(dark ? .48 : .22), blurRadius: 15, spreadRadius: -3)],
        ),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(37),
            gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: dark ? const [Color(0xFF0B1028), Color(0xFF111638)] : const [Color(0xFFF9FBFF), Color(0xFFE7EEFF)]),
          ),
          child: Row(textDirection: TextDirection.ltr, children: [
            for (var i = 0; i < items.length; i++)
              Expanded(child: InkWell(
                borderRadius: BorderRadius.circular(32),
                onTap: () => onSelect(i),
                child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                  Icon(items[i].icon, size: 25, color: i == selected ? const Color(0xFF09D5EF) : fg.withOpacity(.84)),
                  const SizedBox(height: 2),
                  Padding(padding: const EdgeInsets.symmetric(horizontal: 1), child: FittedBox(fit: BoxFit.scaleDown, child: Text(items[i].label, maxLines: 1, style: TextStyle(fontSize: 10.5, color: i == selected ? const Color(0xFF10DDF2) : fg, fontWeight: i == selected ? FontWeight.w700 : FontWeight.w500)))),
                  const SizedBox(height: 3),
                  AnimatedContainer(duration: const Duration(milliseconds: 170), width: i == selected ? 67 : 0, height: 3, decoration: BoxDecoration(color: i == selected ? const Color(0xFF08D8EF) : Colors.transparent, borderRadius: BorderRadius.circular(4), boxShadow: i == selected ? const [BoxShadow(color: Color(0xFF00DFFF), blurRadius: 7)] : null)),
                ]),
              )),
          ]),
        ),
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------ floating bar

class _FloatingNavBar extends StatelessWidget {
  final int selected;
  final ValueChanged<int> onSelect;
  final List<NavItem> items;
  const _FloatingNavBar({required this.selected, required this.onSelect, required this.items});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(0, 6, 0, 10),
        child: Material(
          elevation: 8,
          color: Theme.of(context).cardColor,
          borderRadius: BorderRadius.circular(30),
          child: Padding(
            padding: const EdgeInsets.all(5),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              for (var i = 0; i < items.length; i++)
                Flexible(
                  flex: i == selected ? 2 : 1,
                  child: InkWell(
                    borderRadius: BorderRadius.circular(24),
                    onTap: () => onSelect(i),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      height: 46,
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      decoration: BoxDecoration(color: i == selected ? cs.primary.withOpacity(.22) : Colors.transparent, borderRadius: BorderRadius.circular(24)),
                      child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Icon(items[i].icon, size: 22, color: i == selected ? cs.primary : Theme.of(context).hintColor),
                        if (i == selected) ...[
                          const SizedBox(width: 6),
                          Flexible(child: Text(items[i].label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5, fontWeight: FontWeight.bold, color: cs.primary))),
                        ],
                      ]),
                    ),
                  ),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}

// ------------------------------------------------------------------ drawer content

class _DrawerContent extends StatelessWidget {
  final int selected;
  final ValueChanged<int> onSelect;
  final List<NavItem> items;
  final bool closeAfter;
  const _DrawerContent({required this.selected, required this.onSelect, required this.items, required this.closeAfter});

  @override
  Widget build(BuildContext context) {
    final cats = homeCats();
    final cs = Theme.of(context).colorScheme;
    return ListView(padding: EdgeInsets.zero, children: [
      Container(
        padding: const EdgeInsets.fromLTRB(18, 22, 18, 18),
        margin: const EdgeInsets.fromLTRB(10, 8, 10, 8),
        decoration: Looks.accent(cs, radius: BorderRadius.circular(22)),
        child: Row(children: [
          const Icon(Icons.folder_rounded, color: Colors.white, size: 36),
          const SizedBox(width: 12),
          const Expanded(child: Text('Abtin File Manager', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold))),
        ]),
      ),
      for (var i = 0; i < items.length; i++)
        ListTile(
          selected: i == selected,
          selectedTileColor: cs.primary.withOpacity(.16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          contentPadding: const EdgeInsets.symmetric(horizontal: 20),
          leading: Icon(items[i].icon),
          title: Text(items[i].label),
          onTap: () {
            if (closeAfter) Navigator.of(context).pop();
            onSelect(i);
          },
        ),
      const Divider(height: 24),
      Padding(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 4),
        child: Text(tr2('دسترسی سریع', 'Quick access'), style: TextStyle(fontSize: 12, color: Theme.of(context).hintColor, fontWeight: FontWeight.bold)),
      ),
      for (final c in cats)
        ListTile(
          dense: true,
          contentPadding: const EdgeInsets.symmetric(horizontal: 20),
          leading: Icon(c.icon, color: c.color, size: 22),
          title: Text(L.t(c.key)),
          onTap: () {
            final nav = Navigator.of(context);
            if (closeAfter) nav.pop();
            nav.push(MaterialPageRoute(builder: (_) => c.page));
          },
        ),
    ]);
  }
}
