import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/settings.dart';

/// Bridge from the app-wide visual rail to the root Shell's tab and page routes.
class AbtinGlobalNavigation {
  static ValueChanged<String>? onNavigate;
  static final ValueNotifier<String> active = ValueNotifier<String>('home');
  static final ValueNotifier<bool> shellVisible = ValueNotifier<bool>(false);
  static final ValueNotifier<bool> rootRailVisible = ValueNotifier<bool>(true);
  static final ValueNotifier<bool> railVisible = ValueNotifier<bool>(true);
  static final ValueNotifier<bool> hideRail = ValueNotifier<bool>(false);

  static void setRootRailVisible(bool visible) {
    rootRailVisible.value = visible;
    if (!AbtinRailRouteObserver.hasSecondaryPage.value) {
      railVisible.value = visible;
    }
  }

  static void navigate(String destination) {
    active.value = destination;
    onNavigate?.call(destination);
  }
}

const String _abtinNoRailRouteName = 'abtin.no-rail';
const String _abtinRailRouteName = 'abtin.rail-destination';

/// Use for full-screen players and editors that should not show the global rail.
MaterialPageRoute<T> abtinPageRoute<T>(
  WidgetBuilder builder, {
  bool hideRail = false,
  bool showRail = false,
}) =>
    MaterialPageRoute<T>(
        settings:
            hideRail
                ? const RouteSettings(name: _abtinNoRailRouteName)
                : showRail
                    ? const RouteSettings(name: _abtinRailRouteName)
                    : null,
        builder: showRail && !hideRail
            ? (BuildContext c) => AbtinRailLane(visible: true, child: builder(c))
            : builder);

/// Keeps the rail only on its own destinations; unrelated pushed screens hide it.
class AbtinRailRouteObserver extends NavigatorObserver {
  static final ValueNotifier<bool> hasPopup = ValueNotifier<bool>(false);
  static final ValueNotifier<bool> hasSecondaryPage = ValueNotifier<bool>(false);
  final Set<Route<dynamic>> _popups = <Route<dynamic>>{};
  final List<Route<dynamic>> _pages = <Route<dynamic>>[];

  void _refresh() => hasPopup.value = _popups.isNotEmpty;
  void _refreshPages() {
    final secondary = _pages.length > 1;
    hasSecondaryPage.value = secondary;
    AbtinGlobalNavigation.railVisible.value = secondary
        ? _pages.last.settings.name == _abtinRailRouteName
        : AbtinGlobalNavigation.rootRailVisible.value;
  }

  void _setPage(Route<dynamic>? route) {
    AbtinGlobalNavigation.hideRail.value =
        route?.settings.name == _abtinNoRailRouteName;
  }

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPush(route, previousRoute);
    if (route is PopupRoute<dynamic>) {
      _popups.add(route);
      _refresh();
    } else {
      _pages.remove(route);
      _pages.add(route);
      _setPage(route);
      _refreshPages();
    }
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didPop(route, previousRoute);
    _popups.remove(route);
    _refresh();
    if (route is! PopupRoute<dynamic>) {
      _pages.remove(route);
      _setPage(previousRoute);
      _refreshPages();
    }
  }

  @override
  void didRemove(Route<dynamic> route, Route<dynamic>? previousRoute) {
    super.didRemove(route, previousRoute);
    _popups.remove(route);
    _refresh();
    if (route is! PopupRoute<dynamic>) {
      _pages.remove(route);
      _setPage(previousRoute);
      _refreshPages();
    }
  }

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) {
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
    if (oldRoute != null) {
      _popups.remove(oldRoute);
      _pages.remove(oldRoute);
    }
    if (newRoute is PopupRoute<dynamic>) {
      _popups.add(newRoute);
    } else {
      if (newRoute != null) {
        _pages.remove(newRoute);
        _pages.add(newRoute);
      }
      _setPage(newRoute);
    }
    _refresh();
    _refreshPages();
  }
}

final AbtinRailRouteObserver abtinRailRouteObserver = AbtinRailRouteObserver();

/// A floating, always-available shortcut rail for the Abtin reference look.
class AbtinGlobalRail extends StatelessWidget {
  const AbtinGlobalRail({super.key});

  static const _items = <(String, IconData, String, String)>[
    ('home', Icons.home_rounded, 'خانه', 'Home'),
    ('favorites', Icons.star_rounded, 'علاقه‌مندی‌ها', 'Favorites'),
    ('recents', Icons.schedule_rounded, 'اخیر', 'Recent files'),
    ('trash', Icons.delete_outline_rounded, 'سطل زباله', 'Trash'),
    ('settings', Icons.settings_rounded, 'تنظیمات', 'Settings'),
  ];

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
        valueListenable: AbtinGlobalNavigation.active,
        builder: (context, active, _) => Container(
          width: 52,
          padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 3),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(27),
            gradient: const LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF1A1D82), Color(0xFF10125E)],
            ),
            border: Border.all(color: const Color(0x665B78FF), width: 1.1),
            boxShadow: const [
              BoxShadow(color: Color(0x553C4BFF), blurRadius: 16),
              BoxShadow(
                color: Color(0x332E3AFF),
                blurRadius: 14,
                spreadRadius: -4,
                offset: Offset(0, 2),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              for (final item in _items) ...[
                if (item != _items.first) const SizedBox(height: 5),
                _RailButton(
                  icon: item.$2,
                  label: item.$3,
                  tooltip: item.$4,
                  selected: active == item.$1,
                  onTap: () => AbtinGlobalNavigation.navigate(item.$1),
                ),
              ],
            ],
          ),
        ),
      );
}

class _RailButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final String tooltip;
  final bool selected;
  final VoidCallback onTap;

  const _RailButton({
    required this.icon,
    required this.label,
    required this.tooltip,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) => Tooltip(
        message: tooltip,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Material(
            color: selected ? const Color(0xFF1C3FD8) : const Color(0xFF1C1F8E),
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: onTap,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: selected
                      ? Border.all(color: const Color(0xFF3DA3FF), width: 1.5)
                      : null,
                  boxShadow: selected
                      ? const [
                          BoxShadow(color: Color(0xAA2D7BFF), blurRadius: 12)
                        ]
                      : null,
                ),
                child: Icon(icon,
                    size: 25,
                    color: selected
                        ? const Color(0xFF33D6FF)
                        : const Color(0xFFE5E8FF)),
              ),
            ),
          ),
        ),
      );
}

/// Width reserved for the rail: rail (52) + outer margin (8) + gap (12).
const double kAbtinRailLane = 72;

/// Puts the rail on the physical right edge and reserves a lane for it, so the
/// page content ends where the rail starts (nothing goes underneath it).
/// Only the page body is narrowed: the bottom navigation bar and the
/// mini-player live outside this widget and keep the full screen width.
class AbtinRailLane extends StatelessWidget {
  final Widget child;
  final bool visible;
  const AbtinRailLane({super.key, required this.child, this.visible = true});

  @override
  Widget build(BuildContext context) {
    final look = context.select<AppSettings, String>((s) => s.look);
    final show = visible && look == 'abtin';
    final mq = MediaQuery.of(context);
    final safe = mq.viewPadding;
    // the structure stays identical when the rail is hidden, so the page below
    // keeps its state when the rail toggles
    return Stack(
      fit: StackFit.expand,
      children: [
        Positioned.fill(
          child: Padding(
            padding: EdgeInsets.only(right: show ? kAbtinRailLane + safe.right : 0),
            child: show
                ? MediaQuery(
                    data: mq.copyWith(
                      padding: mq.padding.copyWith(right: 0),
                      viewPadding: mq.viewPadding.copyWith(right: 0),
                    ),
                    child: child,
                  )
                : MediaQuery(data: mq, child: child),
          ),
        ),
        if (show)
          Positioned(
            top: 104 + safe.top,
            right: 8 + safe.right,
            child: const AbtinGlobalRail(),
          ),
      ],
    );
  }
}

/// Kept for compatibility: the rail is no longer a global overlay, each page
/// lays it out itself through [AbtinRailLane].
class AbtinAppChrome extends StatelessWidget {
  final Widget child;
  const AbtinAppChrome({super.key, required this.child});
  @override
  Widget build(BuildContext context) => child;
}
