import 'dart:async';

// ignore: deprecated_member_use
import 'package:flutter/material.dart';
import 'package:xterm/xterm.dart';

import '../services/terminal_native.dart';

/// Android /system/bin/sh terminal with a native PTY backend and ANSI emulator.
class TerminalScreen extends StatefulWidget {
  final String cwd;
  const TerminalScreen({super.key, required this.cwd});

  @override
  State<TerminalScreen> createState() => _TerminalScreenState();
}

class _TerminalScreenState extends State<TerminalScreen> {
  static const _maxHistory = 100;
  final _native = TerminalNative();
  final _terminal = Terminal(maxLines: 10000);
  final _history = <String>[];
  final _lineBuffer = StringBuffer();
  StreamSubscription<Map<String, dynamic>>? _events;

  String? _sessionId;
  String _cwd = '';
  String _status = 'در حال راه‌اندازی…';
  bool _starting = false;
  int _historyEscapeState = 0;
  int _columns = 80;
  int _rows = 24;

  bool get _running => _sessionId != null;

  @override
  void initState() {
    super.initState();
    _terminal.onOutput = _sendToPty;
    _terminal.onResize = (columns, rows, _, __) {
      _columns = columns.clamp(20, 500).toInt();
      _rows = rows.clamp(5, 300).toInt();
      final id = _sessionId;
      if (id != null) {
        unawaited(_native.resize(id, _columns, _rows).catchError((_) {}));
      }
    };
    _events = _native.events.listen(
      _onEvent,
      onError: (Object error) =>
          _terminal.write('\r\n[stream error: $error]\r\n'),
    );
    _start();
  }

  @override
  void dispose() {
    _events?.cancel();
    final id = _sessionId;
    _sessionId = null;
    if (id != null) {
      unawaited(_native.close(id).catchError((_) {}));
    }
    super.dispose();
  }

  Future<void> _start() async {
    if (_starting || _running) return;
    setState(() {
      _starting = true;
      _status = 'در حال اتصال PTY…';
    });
    try {
      final session =
          await _native.start(widget.cwd, columns: _columns, rows: _rows);
      if (!mounted) {
        unawaited(_native.close(session.id).catchError((_) {}));
        return;
      }
      setState(() {
        _sessionId = session.id;
        _cwd = session.cwd;
        _starting = false;
        _status = 'PTY متصل';
      });
      _terminal.write('\r\n[Android PTY connected: ${session.cwd}]\r\n');
      unawaited(_native.resize(session.id, _columns, _rows).catchError((_) {}));
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _starting = false;
        _status = 'اتصال ناموفق';
      });
      _terminal.write('\r\n[PTY error] $error\r\n');
    }
  }

  void _onEvent(Map<String, dynamic> event) {
    if (!mounted || event['sessionId'] != _sessionId) return;
    switch (event['type']) {
      case 'output':
        final text = event['text'];
        if (text is String) _terminal.write(text);
        break;
      case 'exit':
        final code = event['exitCode'];
        setState(() {
          _sessionId = null;
          _status = 'پایان نشست${code == null ? '' : ' (کد $code)'}';
        });
        _terminal.write(
            '\r\n[PTY session ended${code == null ? '' : '; exit code: $code'}]\r\n');
        break;
    }
  }

  Future<void> _sendToPty(String data) async {
    final id = _sessionId;
    if (id == null || data.isEmpty) return;
    _trackHistory(data);
    try {
      await _native.writeRaw(id, data);
    } catch (error) {
      _terminal.write('\r\n[input error] $error\r\n');
    }
  }

  void _trackHistory(String data) {
    for (final rune in data.runes) {
      if (_historyEscapeState == 1) {
        _historyEscapeState = rune == 0x5b
            ? 2
            : rune == 0x5d
                ? 3
                : 0;
        continue;
      } else if (_historyEscapeState == 2) {
        if (rune >= 0x40 && rune <= 0x7e) _historyEscapeState = 0;
        continue;
      } else if (_historyEscapeState == 3) {
        if (rune == 0x07) {
          _historyEscapeState = 0;
        } else if (rune == 0x1b) {
          _historyEscapeState = 4;
        }
        continue;
      } else if (_historyEscapeState == 4) {
        _historyEscapeState = rune == 0x5c ? 0 : 3;
        continue;
      }
      if (rune == 0x1b) {
        _historyEscapeState = 1;
      } else if (rune == 0x0d || rune == 0x0a) {
        final command = _lineBuffer.toString().trim();
        if (command.isNotEmpty &&
            (_history.isEmpty || _history.last != command)) {
          _history.add(command);
          if (_history.length > _maxHistory) _history.removeAt(0);
        }
        _lineBuffer.clear();
      } else if (rune == 0x08 || rune == 0x7f) {
        final text = _lineBuffer.toString();
        if (text.isNotEmpty) {
          _lineBuffer.clear();
          _lineBuffer.write(
              String.fromCharCodes(text.runes.take(text.runes.length - 1)));
        }
      } else if (rune >= 0x20 && rune != 0x7f) {
        _lineBuffer.writeCharCode(rune);
      }
    }
  }

  Future<void> _stop() async {
    final id = _sessionId;
    if (id == null) return;
    setState(() {
      _status = 'در حال بستن PTY…';
    });
    try {
      await _native.close(id);
    } catch (error) {
      _terminal.write('\r\n[close error] $error\r\n');
    }
  }

  Future<void> _sendRaw(String value) async {
    final id = _sessionId;
    if (id == null) return;
    try {
      await _native.writeRaw(id, value);
    } catch (error) {
      _terminal.write('\r\n[input error] $error\r\n');
    }
  }

  Future<void> _control(String key) async {
    final id = _sessionId;
    if (id == null) return;
    switch (key) {
      case 'C':
        await _native.interrupt(id);
        break;
      case 'D':
        await _native.eof(id);
        break;
      case 'L':
        await _sendRaw('\u000c');
        break;
      case 'A':
        await _sendRaw('\u0001');
        break;
      case 'U':
        await _sendRaw('\u0015');
        break;
      case 'W':
        await _sendRaw('\u0017');
        break;
    }
  }

  Future<void> _showHistory() async {
    if (_history.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تاریخچهٔ فرمان‌ها خالی است')),
      );
      return;
    }
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: SafeArea(
          child: ListView(
            shrinkWrap: true,
            children: [
              const ListTile(title: Text('تاریخچهٔ فرمان‌ها')),
              for (final command in _history.reversed)
                ListTile(
                  dense: true,
                  title: Text(command,
                      textDirection: TextDirection.ltr,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis),
                  onTap: () => Navigator.pop(context, command),
                ),
            ],
          ),
        ),
      ),
    );
    if (selected != null && mounted) _terminal.textInput(selected);
  }

  Future<void> _showHelp() async {
    await showDialog<void>(
      context: context,
      builder: (context) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('ترمینال Android'),
          content: const SingleChildScrollView(
            child: Text(
              'این ترمینال از PTY واقعی Android استفاده می‌کند و برنامه‌های تعاملی و ANSI را اجرا می‌کند.\n\n'
              'برای فعال‌کردن محیط توسعه لینوکس، فقط یک‌بار اجرا کن:\n'
              '  alpine bootstrap\n\n'
              'این دستور Alpine و PRoot را نصب می‌کند و Python، pip، Node.js، npm و Git را آماده می‌کند. پس از آن مستقیم از دستورهای زیر استفاده کن:\n'
              '  python --version\n'
              '  pip install requests\n'
              '  node --version\n'
              '  npm install\n'
              '  npm run <script>\n\n'
              'محیط Alpine در حافظهٔ داخلی اپ باقی می‌ماند و پوشهٔ کاری فعلی ترمینال با مسیر /workspace در لینوکس در دسترس است؛ بنابراین node_modules و فایل‌های پروژه در همان پوشه ذخیره می‌شوند.\n\n'
              'مدیر بستهٔ سبک خود اپ نیز با دستور pkg (یا apt) در دسترس است.\n'
              'محدودیت‌های sandbox اندروید برقرار است و این محیط root واقعی اندروید نیست.',
            ),
          ),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('بستن'))
          ],
        ),
      ),
    );
  }

  Future<void> _closeScreen() async {
    await _stop();
    if (mounted) Navigator.of(context).maybePop();
  }

  Widget _key(String label,
          {String? input, String? control, bool wide = false}) =>
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 3),
        child: OutlinedButton(
          onPressed: !_running
              ? null
              : control != null
                  ? () => _control(control)
                  : () => _sendRaw(input ?? label),
          style: OutlinedButton.styleFrom(
            foregroundColor: const Color(0xFFB1BAC4),
            side: const BorderSide(color: Color(0xFF30363D)),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            minimumSize: Size(wide ? 56 : 38, 31),
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            visualDensity: VisualDensity.compact,
          ),
          child: Text(label,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 11)),
        ),
      );

  Widget _extraKeys() => SizedBox(
        height: 42,
        child: ListView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
          children: [
            _key('ESC', input: '\u001b'),
            _key('TAB', input: '\t'),
            _key('CTRL+C', control: 'C', wide: true),
            _key('CTRL+D', control: 'D', wide: true),
            _key('CTRL+L', control: 'L', wide: true),
            _key('CTRL+A', control: 'A', wide: true),
            _key('CTRL+U', control: 'U', wide: true),
            _key('CTRL+W', control: 'W', wide: true),
            _key('pip/npm', input: 'alpine bootstrap\r', wide: true),
            _key('↑', input: '\u001b[A'),
            _key('↓', input: '\u001b[B'),
            _key('←', input: '\u001b[D'),
            _key('→', input: '\u001b[C'),
            _key('|'),
            _key('/'),
            _key('~'),
          ],
        ),
      );

  @override
  Widget build(BuildContext context) {
    const termTheme = TerminalTheme(
      cursor: Color(0xFF39D353),
      selection: Color(0x8039D353),
      foreground: Color(0xFFE6EDF3),
      background: Color(0xFF080808),
      black: Color(0xFF000000),
      red: Color(0xFFCC4444),
      green: Color(0xFF39D353),
      yellow: Color(0xFFE3B341),
      blue: Color(0xFF58A6FF),
      magenta: Color(0xFFD2A8FF),
      cyan: Color(0xFF39C5CF),
      white: Color(0xFFE6EDF3),
      brightBlack: Color(0xFF6E7681),
      brightRed: Color(0xFFFF7B72),
      brightGreen: Color(0xFF56D364),
      brightYellow: Color(0xFFEAC54F),
      brightBlue: Color(0xFF79C0FF),
      brightMagenta: Color(0xFFD2A8FF),
      brightCyan: Color(0xFF56D4DD),
      brightWhite: Color(0xFFFFFFFF),
      searchHitBackground: Color(0xFFFFFF2B),
      searchHitBackgroundCurrent: Color(0xFF31FF26),
      searchHitForeground: Color(0xFF000000),
    );
    final theme = ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: const Color(0xFF080808),
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFF39D353),
        secondary: Color(0xFF8B949E),
        surface: Color(0xFF111111),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF101010),
        foregroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 52,
      ),
    );
    return Theme(
      data: theme,
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
          backgroundColor: const Color(0xFF080808),
          appBar: AppBar(
            title: const Text('ترمینال', style: TextStyle(fontSize: 17)),
            actions: [
              if (_running)
                IconButton(
                    tooltip: 'توقف نشست',
                    onPressed: _stop,
                    icon:
                        const Icon(Icons.stop_rounded, color: Colors.redAccent))
              else
                IconButton(
                    tooltip: 'شروع نشست',
                    onPressed: _starting ? null : _start,
                    icon: const Icon(Icons.play_arrow_rounded)),
              IconButton(
                  tooltip: 'تاریخچه',
                  onPressed: _showHistory,
                  icon: const Icon(Icons.history_rounded)),
              IconButton(
                  tooltip: 'راهنما',
                  onPressed: _showHelp,
                  icon: const Icon(Icons.info_outline_rounded)),
              IconButton(
                  tooltip: 'بستن صفحه',
                  onPressed: _closeScreen,
                  icon: const Icon(Icons.close_rounded)),
            ],
          ),
          body: SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(12, 4, 12, 4),
                  child: Row(
                    children: [
                      Icon(Icons.circle,
                          size: 10,
                          color: _running
                              ? const Color(0xFF39D353)
                              : Colors.orangeAccent),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          '${_status.toLowerCase()}  •  ${_cwd.isEmpty ? widget.cwd : _cwd}',
                          textDirection: TextDirection.ltr,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 10.5,
                              color: Color(0xFF8B949E),
                              fontFamily: 'monospace'),
                        ),
                      ),
                      IconButton(
                        tooltip: 'پاک‌کردن صفحه',
                        onPressed: () => _terminal.write('\u001b[2J\u001b[H'),
                        icon: const Icon(Icons.delete_sweep_outlined),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: Container(
                    color: termTheme.background,
                    alignment: Alignment.topLeft,
                    child: TerminalView(
                      _terminal,
                      theme: termTheme,
                      textStyle:
                          const TerminalStyle(fontSize: 14, height: 1.25),
                      autofocus: true,
                      autoResize: true,
                      deleteDetection: true,
                      padding: const EdgeInsets.fromLTRB(12, 8, 12, 6),
                      keyboardAppearance: Brightness.dark,
                    ),
                  ),
                ),
                _extraKeys(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
