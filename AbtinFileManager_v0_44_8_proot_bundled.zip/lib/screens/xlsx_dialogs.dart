import 'package:flutter/material.dart' hide Icon;
import '../core/l10n.dart';
import '../core/layouts.dart';
import '../services/office_service.dart';
import '../widgets/app_icon.dart';
import '../widgets/office_chrome.dart';
import '../widgets/ui.dart';

Color _rgb(int v) => Color(0xFF000000 | v);

int _mix(int a, int b, double k) {
  int ch(int s) => (((a >> s) & 255) + ((((b >> s) & 255) - ((a >> s) & 255)) * k)).round().clamp(0, 255).toInt();
  return (ch(16) << 16) | (ch(8) << 8) | ch(0);
}

const _std = [0xC00000, 0xFF0000, 0xFFC000, 0xFFFF00, 0x92D050, 0x00B050, 0x00B0F0, 0x0070C0, 0x002060, 0x7030A0];
const _grays = [0xFFFFFF, 0xF2F2F2, 0xD9D9D9, 0xBFBFBF, 0xA6A6A6, 0x808080, 0x595959, 0x404040, 0x262626, 0x000000];

Future<T?> _sheet<T>(BuildContext c, Widget Function(BuildContext) b) => showModalBottomSheet<T>(
      context: c,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) => Theme(data: officeTheme(c), child: SafeArea(child: Padding(padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom), child: b(ctx)))),
    );

Widget _title(String t) => Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(t, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)));

/// Colour palette. null = cancelled, -1 = no colour, otherwise 0xRRGGBB.
Future<int?> pickColor(BuildContext c, {required String title, bool allowNone = true, int? current}) {
  final hex = TextEditingController(text: current == null ? '' : current.toRadixString(16).padLeft(6, '0').toUpperCase());
  final rows = <List<int>>[
    _grays,
    _std,
    [for (final v in _std) _mix(v, 0xFFFFFF, .8)],
    [for (final v in _std) _mix(v, 0xFFFFFF, .6)],
    [for (final v in _std) _mix(v, 0xFFFFFF, .4)],
    [for (final v in _std) _mix(v, 0x000000, .25)],
  ];
  return _sheet<int>(
    c,
    (ctx) => SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        _title(title),
        for (final row in rows)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              for (final v in row)
                GestureDetector(
                  onTap: () => Navigator.pop(ctx, v),
                  child: Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(color: _rgb(v), borderRadius: BorderRadius.circular(6), border: Border.all(color: Colors.black26, width: current == v ? 3 : 1)),
                  ),
                ),
            ]),
          ),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(
            child: TextField(
              controller: hex,
              textDirection: TextDirection.ltr,
              maxLength: 6,
              decoration: InputDecoration(labelText: tr2('کد رنگ (مثلاً FF8800)', 'Hex colour (e.g. FF8800)'), counterText: '', prefixText: '#'),
            ),
          ),
          const SizedBox(width: 8),
          FilledButton(
            onPressed: () {
              final v = int.tryParse(hex.text.trim(), radix: 16);
              if (v != null && hex.text.trim().length == 6) Navigator.pop(ctx, v);
            },
            child: Text(L.t('ok')),
          ),
        ]),
        if (allowNone) TextButton.icon(onPressed: () => Navigator.pop(ctx, -1), icon: const Icon(Icons.format_color_reset_rounded), label: Text(tr2('بدون رنگ / خودکار', 'No colour / automatic'))),
      ]),
    ),
  );
}

/// Number-format picker. Returns the code ('' = General) or null when cancelled.
Future<String?> pickNumFmt(BuildContext c, String current) {
  final ctl = TextEditingController(text: current);
  return _sheet<String>(
    c,
    (ctx) => SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 12),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        _title(tr2('قالب عدد', 'Number format')),
        for (final f in XNumFmt.presets)
          ListTile(
            dense: true,
            selected: (f.$4 == 'General' ? '' : f.$4) == current,
            title: Text(tr2(f.$2, f.$3)),
            trailing: Text(f.$1 == 'text' ? 'abc' : XNumFmt.format(f.$1.startsWith('date') || f.$1.startsWith('time') ? 45292.5625 : 1234.567, f.$4), style: const TextStyle(color: Colors.grey)),
            onTap: () => Navigator.pop(ctx, f.$4 == 'General' ? '' : f.$4),
          ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(children: [
            Expanded(child: TextField(controller: ctl, textDirection: TextDirection.ltr, decoration: InputDecoration(labelText: tr2('قالب سفارشی (مثلاً 0.000 یا dd/mm/yyyy)', 'Custom code (e.g. 0.000 or dd/mm/yyyy)')))),
            const SizedBox(width: 8),
            FilledButton(onPressed: () => Navigator.pop(ctx, ctl.text.trim()), child: Text(L.t('ok'))),
          ]),
        ),
      ]),
    ),
  );
}

/// Highlight presets (fill, text) used by conditional formats.
const kHighlights = <(String, String, int, int)>[
  ('قرمز روشن', 'Light red', 0xFFC7CE, 0x9C0006),
  ('زرد', 'Yellow', 0xFFEB9C, 0x9C5700),
  ('سبز', 'Green', 0xC6EFCE, 0x006100),
  ('آبی', 'Blue', 0xBDD7EE, 0x1F4E78),
  ('نارنجی', 'Orange', 0xF8CBAD, 0x833C0B),
  ('قرمز پررنگ', 'Strong red', 0xC00000, 0xFFFFFF),
];

/// kind: gt, lt, eq, between, text, dup, unique.
Future<XCond?> condDialog(BuildContext c, XRange range, String kind) async {
  final v1 = TextEditingController(), v2 = TextEditingController();
  var style = 0;
  final needs = kind == 'gt' || kind == 'lt' || kind == 'eq' || kind == 'between' || kind == 'text';
  final title = switch (kind) {
    'gt' => tr2('بزرگ‌تر از', 'Greater than'),
    'lt' => tr2('کوچک‌تر از', 'Less than'),
    'eq' => tr2('برابر با', 'Equal to'),
    'between' => tr2('بین', 'Between'),
    'text' => tr2('شامل متن', 'Text contains'),
    'dup' => tr2('مقادیر تکراری', 'Duplicate values'),
    _ => tr2('مقادیر یکتا', 'Unique values'),
  };
  return showDialog<XCond>(
    context: c,
    builder: (ctx) => Theme(
      data: officeTheme(c),
      child: StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: Text(title),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(range.ref, style: const TextStyle(color: Colors.grey)),
              if (needs) TextField(controller: v1, autofocus: true, decoration: InputDecoration(labelText: kind == 'text' ? tr2('متن', 'Text') : tr2('مقدار', 'Value'))),
              if (kind == 'between') TextField(controller: v2, decoration: InputDecoration(labelText: tr2('تا', 'And'))),
              const SizedBox(height: 12),
              Text(tr2('نمایش با', 'Format with')),
              Wrap(spacing: 8, runSpacing: 8, children: [
                for (var i = 0; i < kHighlights.length; i++)
                  ChoiceChip(
                    selected: style == i,
                    label: Text(tr2(kHighlights[i].$1, kHighlights[i].$2), style: TextStyle(color: _rgb(kHighlights[i].$4), fontWeight: FontWeight.w600)),
                    backgroundColor: _rgb(kHighlights[i].$3),
                    selectedColor: _rgb(kHighlights[i].$3),
                    side: BorderSide(color: style == i ? Colors.black87 : Colors.transparent, width: 2),
                    onSelected: (_) => set(() => style = i),
                  ),
              ]),
            ]),
          ),
          actions: [
            CancelButton(onPressed: () => Navigator.pop(ctx)),
            FilledButton(
              onPressed: () {
                if (needs && v1.text.trim().isEmpty) return;
                if (kind == 'between' && v2.text.trim().isEmpty) return;
                final h = kHighlights[style];
                final num1 = double.tryParse(v1.text.trim());
                String val(String t) => double.tryParse(t.trim()) != null || kind == 'text' ? t.trim() : '"${t.trim()}"';
                Navigator.pop(
                  ctx,
                  XCond(
                    type: kind == 'text' ? 'containsText' : (kind == 'dup' ? 'duplicate' : (kind == 'unique' ? 'unique' : 'cellIs')),
                    range: range,
                    op: switch (kind) { 'gt' => 'greaterThan', 'lt' => 'lessThan', 'eq' => 'equal', 'between' => 'between', _ => '' },
                    v1: num1 != null || kind == 'text' ? v1.text.trim() : val(v1.text),
                    v2: val(v2.text),
                    fill: h.$3,
                    color: h.$4,
                  ),
                );
              },
              child: Text(L.t('ok')),
            ),
          ],
        ),
      ),
    ),
  );
}

class ValidationResult {
  final XValidation? validation;
  final bool remove;
  const ValidationResult(this.validation, this.remove);
}

Future<ValidationResult?> validationDialog(BuildContext c, XRange range, XValidation? existing) {
  var type = existing?.type ?? 'list';
  var op = existing?.op ?? 'between';
  var blank = existing?.allowBlank ?? true, dropdown = existing?.dropdown ?? true;
  final f1 = TextEditingController(text: existing == null ? '' : (existing.type == 'list' && existing.f1.startsWith('"') ? existing.items.join(',') : existing.f1));
  final f2 = TextEditingController(text: existing?.f2 ?? '');
  final msg = TextEditingController(text: existing?.message ?? '');
  const types = ['list', 'whole', 'decimal', 'textLength', 'date'];
  const ops = ['between', 'notBetween', 'equal', 'notEqual', 'greaterThan', 'lessThan', 'greaterThanOrEqual', 'lessThanOrEqual'];
  String typeLabel(String t) => switch (t) {
        'list' => tr2('فهرست', 'List'),
        'whole' => tr2('عدد صحیح', 'Whole number'),
        'decimal' => tr2('عدد اعشاری', 'Decimal'),
        'textLength' => tr2('طول متن', 'Text length'),
        _ => tr2('تاریخ', 'Date'),
      };
  String opLabel(String o) => switch (o) {
        'between' => tr2('بین', 'between'),
        'notBetween' => tr2('خارج از', 'not between'),
        'equal' => tr2('برابر', 'equal to'),
        'notEqual' => tr2('نابرابر', 'not equal to'),
        'greaterThan' => tr2('بزرگ‌تر از', 'greater than'),
        'lessThan' => tr2('کوچک‌تر از', 'less than'),
        'greaterThanOrEqual' => tr2('بزرگ‌تر یا مساوی', 'greater or equal'),
        _ => tr2('کوچک‌تر یا مساوی', 'less or equal'),
      };
  return showDialog<ValidationResult>(
    context: c,
    builder: (ctx) => Theme(
      data: officeTheme(c),
      child: StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: Text(tr2('اعتبارسنجی داده', 'Data validation')),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(range.ref, style: const TextStyle(color: Colors.grey)),
              DropdownButton<String>(isExpanded: true, value: type, items: [for (final t in types) DropdownMenuItem(value: t, child: Text(typeLabel(t)))], onChanged: (v) => set(() => type = v ?? type)),
              if (type == 'list')
                TextField(controller: f1, decoration: InputDecoration(labelText: tr2('موارد (با ویرگول جدا کنید) یا محدوده مثل A1:A5', 'Items (comma separated) or range like A1:A5')))
              else ...[
                DropdownButton<String>(isExpanded: true, value: op, items: [for (final o in ops) DropdownMenuItem(value: o, child: Text(opLabel(o)))], onChanged: (v) => set(() => op = v ?? op)),
                TextField(controller: f1, decoration: InputDecoration(labelText: op.contains('etween') ? tr2('حداقل', 'Minimum') : tr2('مقدار', 'Value'))),
                if (op.contains('etween')) TextField(controller: f2, decoration: InputDecoration(labelText: tr2('حداکثر', 'Maximum'))),
              ],
              TextField(controller: msg, decoration: InputDecoration(labelText: tr2('پیام راهنما (اختیاری)', 'Input message (optional)'))),
              SwitchListTile(dense: true, contentPadding: EdgeInsets.zero, value: blank, onChanged: (v) => set(() => blank = v), title: Text(tr2('اجازهٔ خالی', 'Allow blank'))),
              if (type == 'list') SwitchListTile(dense: true, contentPadding: EdgeInsets.zero, value: dropdown, onChanged: (v) => set(() => dropdown = v), title: Text(tr2('نمایش فلش فهرست', 'Show drop-down arrow'))),
            ]),
          ),
          actions: [
            if (existing != null) TextButton(onPressed: () => Navigator.pop(ctx, const ValidationResult(null, true)), child: Text(tr2('حذف', 'Remove'))),
            CancelButton(onPressed: () => Navigator.pop(ctx)),
            FilledButton(
              onPressed: () {
                final t = f1.text.trim();
                if (t.isEmpty) return;
                var formula1 = t;
                if (type == 'list' && XRange.parse(t) == null && !t.contains('!')) {
                  formula1 = '"${t.split(RegExp(r'[,،;]')).map((e) => e.trim()).where((e) => e.isNotEmpty).join(',')}"';
                }
                Navigator.pop(ctx, ValidationResult(XValidation(range: range, type: type, op: op, f1: formula1, f2: f2.text.trim(), allowBlank: blank, dropdown: dropdown, message: msg.text.trim()), false));
              },
              child: Text(L.t('ok')),
            ),
          ],
        ),
      ),
    ),
  );
}

class SortResult {
  final List<(int, bool)> keys;
  final bool header;
  const SortResult(this.keys, this.header);
}

Future<SortResult?> sortDialog(BuildContext c, XlsxFile f, XSheet sh, XRange rg, {bool header = true, int? firstKey}) {
  var hdr = header;
  var k1 = firstKey ?? rg.c1, k2 = -1;
  var a1 = true, a2 = true;
  String colLabel(int col) {
    final h = hdr ? f.displayText(sh, refOf(col, rg.r1)) : '';
    return '${tr2('ستون', 'Column')} ${colName(col)}${h.isEmpty ? '' : ' — $h'}';
  }

  return showDialog<SortResult>(
    context: c,
    builder: (ctx) => Theme(
      data: officeTheme(c),
      child: StatefulBuilder(
        builder: (ctx, set) {
          Widget keyRow(String label, int value, bool asc, void Function(int) onCol, void Function(bool) onAsc, {bool optional = false}) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(label, style: const TextStyle(fontWeight: FontWeight.w600)),
                Row(children: [
                  Expanded(
                    child: DropdownButton<int>(
                      isExpanded: true,
                      value: value,
                      items: [
                        if (optional) DropdownMenuItem(value: -1, child: Text(tr2('— هیچ —', '— none —'))),
                        for (var col = rg.c1; col <= rg.c2; col++) DropdownMenuItem(value: col, child: Text(colLabel(col), overflow: TextOverflow.ellipsis)),
                      ],
                      onChanged: (v) => set(() => onCol(v ?? value)),
                    ),
                  ),
                  IconButton(onPressed: () => set(() => onAsc(!asc)), icon: Icon(asc ? Icons.arrow_downward_rounded : Icons.arrow_upward_rounded), tooltip: asc ? 'A→Z' : 'Z→A'),
                ]),
              ]);
          return AlertDialog(
            title: Text(tr2('مرتب‌سازی سفارشی', 'Custom sort')),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                CheckboxListTile(dense: true, contentPadding: EdgeInsets.zero, value: hdr, onChanged: (v) => set(() => hdr = v ?? true), title: Text(tr2('ردیف اول عنوان است', 'First row is a header'))),
                keyRow(tr2('مرتب‌سازی بر اساس', 'Sort by'), k1, a1, (v) => k1 = v, (v) => a1 = v),
                keyRow(tr2('سپس بر اساس', 'Then by'), k2, a2, (v) => k2 = v, (v) => a2 = v, optional: true),
              ]),
            ),
            actions: [
              CancelButton(onPressed: () => Navigator.pop(ctx)),
              FilledButton(onPressed: () => Navigator.pop(ctx, SortResult([(k1, a1), if (k2 >= 0) (k2, a2)], hdr)), child: Text(L.t('ok'))),
            ],
          );
        },
      ),
    ),
  );
}

class FilterResult {
  final Set<String>? allowed; // null with clear = remove the column filter
  final bool clear;
  final String? sort; // asc / desc
  const FilterResult({this.allowed, this.clear = false, this.sort});
}

Future<FilterResult?> filterDialog(BuildContext c, List<String> values, Set<String>? current, String title) {
  final chosen = <String>{...(current ?? values)};
  final q = TextEditingController();
  return _sheet<FilterResult>(
    c,
    (ctx) => StatefulBuilder(
      builder: (ctx, set) {
        final shown = values.where((v) => q.text.isEmpty || v.toLowerCase().contains(q.text.toLowerCase())).toList();
        return SizedBox(
          height: MediaQuery.of(ctx).size.height * .75,
          child: Column(children: [
            _title(title),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(children: [
                Expanded(child: OutlinedButton.icon(onPressed: () => Navigator.pop(ctx, const FilterResult(sort: 'asc')), icon: const Icon(Icons.arrow_downward_rounded, size: 18), label: const Text('A → Z'))),
                const SizedBox(width: 8),
                Expanded(child: OutlinedButton.icon(onPressed: () => Navigator.pop(ctx, const FilterResult(sort: 'desc')), icon: const Icon(Icons.arrow_upward_rounded, size: 18), label: const Text('Z → A'))),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: TextField(controller: q, onChanged: (_) => set(() {}), decoration: InputDecoration(prefixIcon: const Icon(Icons.search_rounded), hintText: tr2('جستجو', 'Search'), isDense: true)),
            ),
            Row(children: [
              TextButton(onPressed: () => set(() => chosen.addAll(shown)), child: Text(tr2('انتخاب همه', 'Select all'))),
              TextButton(onPressed: () => set(() => chosen.removeAll(shown)), child: Text(tr2('هیچ‌کدام', 'Clear'))),
              const Spacer(),
              Text('${chosen.length}/${values.length}  '),
            ]),
            Expanded(
              child: ListView(children: [
                for (final v in shown)
                  CheckboxListTile(
                    dense: true,
                    value: chosen.contains(v),
                    title: Text(v.isEmpty ? tr2('(خالی)', '(blank)') : v, maxLines: 1, overflow: TextOverflow.ellipsis),
                    onChanged: (on) => set(() => on == true ? chosen.add(v) : chosen.remove(v)),
                  ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                if (current != null) TextButton(onPressed: () => Navigator.pop(ctx, const FilterResult(clear: true)), child: Text(tr2('حذف فیلتر', 'Clear filter'))),
                const Spacer(),
                FilledButton(onPressed: () => Navigator.pop(ctx, chosen.length == values.length ? const FilterResult(clear: true) : FilterResult(allowed: chosen)), child: Text(L.t('ok'))),
              ]),
            ),
          ]),
        );
      },
    ),
  );
}

// ------------------------------------------------------------------------------------------------ functions
/// name|category|fa|en
const _fnData = '''
SUM|math|جمع اعداد|Adds numbers
AVERAGE|stat|میانگین|Average of numbers
COUNT|stat|شمارش اعداد|Counts numbers
COUNTA|stat|شمارش سلول‌های غیرخالی|Counts non-empty cells
COUNTBLANK|stat|شمارش سلول‌های خالی|Counts blank cells
MAX|stat|بزرگ‌ترین مقدار|Largest value
MIN|stat|کوچک‌ترین مقدار|Smallest value
PRODUCT|math|حاصل‌ضرب|Multiplies numbers
ROUND|math|گرد کردن|Rounds a number
ROUNDUP|math|گرد کردن به بالا|Rounds up
ROUNDDOWN|math|گرد کردن به پایین|Rounds down
INT|math|بخش صحیح (به پایین)|Rounds down to integer
TRUNC|math|حذف اعشار|Truncates decimals
CEILING|math|گرد به بالا تا مضرب|Rounds up to multiple
FLOOR|math|گرد به پایین تا مضرب|Rounds down to multiple
MROUND|math|گرد تا نزدیک‌ترین مضرب|Rounds to multiple
ABS|math|قدر مطلق|Absolute value
SQRT|math|ریشهٔ دوم|Square root
POWER|math|توان|Power
MOD|math|باقی‌ماندهٔ تقسیم|Remainder
SIGN|math|علامت عدد|Sign of a number
EXP|math|e به توان|e raised to a power
LN|math|لگاریتم طبیعی|Natural logarithm
LOG|math|لگاریتم|Logarithm
LOG10|math|لگاریتم در مبنای ۱۰|Base-10 logarithm
FACT|math|فاکتوریل|Factorial
COMBIN|math|ترکیب|Combinations
PERMUT|math|جایگشت|Permutations
GCD|math|بزرگ‌ترین مقسوم‌علیه مشترک|Greatest common divisor
LCM|math|کوچک‌ترین مضرب مشترک|Least common multiple
EVEN|math|گرد به نزدیک‌ترین زوج|Round to even
ODD|math|گرد به نزدیک‌ترین فرد|Round to odd
QUOTIENT|math|خارج‌قسمت صحیح|Integer quotient
PI|math|عدد پی|Value of pi
RAND|math|عدد تصادفی ۰ تا ۱|Random 0..1
RANDBETWEEN|math|عدد تصادفی بین دو عدد|Random integer in range
SIN|math|سینوس|Sine
COS|math|کسینوس|Cosine
TAN|math|تانژانت|Tangent
ASIN|math|آرک‌سینوس|Arcsine
ACOS|math|آرک‌کسینوس|Arccosine
ATAN|math|آرک‌تانژانت|Arctangent
ATAN2|math|آرک‌تانژانت دو آرگومانی|Arctangent of x,y
DEGREES|math|رادیان به درجه|Radians to degrees
RADIANS|math|درجه به رادیان|Degrees to radians
SUMPRODUCT|math|مجموع حاصل‌ضرب آرایه‌ها|Sum of products
SUMSQ|math|مجموع مربعات|Sum of squares
SUBTOTAL|math|جمع جزئی|Subtotal
SUMIF|math|جمع با شرط|Sum with a condition
SUMIFS|math|جمع با چند شرط|Sum with conditions
COUNTIF|stat|شمارش با شرط|Count with a condition
COUNTIFS|stat|شمارش با چند شرط|Count with conditions
AVERAGEIF|stat|میانگین با شرط|Average with a condition
AVERAGEIFS|stat|میانگین با چند شرط|Average with conditions
MAXIFS|stat|بیشینه با شرط|Max with conditions
MINIFS|stat|کمینه با شرط|Min with conditions
MEDIAN|stat|میانه|Median
MODE|stat|مد (پرتکرارترین)|Most frequent value
STDEV|stat|انحراف معیار نمونه|Sample standard deviation
STDEVP|stat|انحراف معیار جامعه|Population standard deviation
VAR|stat|واریانس نمونه|Sample variance
VARP|stat|واریانس جامعه|Population variance
LARGE|stat|k‌امین بزرگ‌ترین|k-th largest
SMALL|stat|k‌امین کوچک‌ترین|k-th smallest
RANK|stat|رتبه|Rank
PERCENTILE|stat|صدک|Percentile
QUARTILE|stat|چارک|Quartile
CORREL|stat|ضریب همبستگی|Correlation
SLOPE|stat|شیب خط رگرسیون|Regression slope
INTERCEPT|stat|عرض از مبدأ رگرسیون|Regression intercept
GEOMEAN|stat|میانگین هندسی|Geometric mean
IF|logic|شرط|If condition
IFS|logic|چند شرط|Multiple conditions
IFERROR|logic|مقدار جایگزین در خطا|Value if error
IFNA|logic|مقدار جایگزین برای N/A|Value if #N/A
AND|logic|و (همه درست)|All true
OR|logic|یا (یکی درست)|Any true
NOT|logic|نقیض|Negates
XOR|logic|یای انحصاری|Exclusive or
SWITCH|logic|انتخاب بر اساس مقدار|Switch on a value
TRUE|logic|درست|TRUE
FALSE|logic|نادرست|FALSE
LEN|text|طول متن|Text length
LEFT|text|کاراکترهای ابتدای متن|Left characters
RIGHT|text|کاراکترهای انتهای متن|Right characters
MID|text|بخشی از متن|Middle part of text
UPPER|text|حروف بزرگ|Uppercase
LOWER|text|حروف کوچک|Lowercase
PROPER|text|حرف اول بزرگ|Capitalize words
TRIM|text|حذف فاصله‌های اضافه|Trim spaces
CLEAN|text|حذف کاراکترهای کنترلی|Remove control characters
FIND|text|یافتن متن (حساس به حروف)|Find text (case-sensitive)
SEARCH|text|یافتن متن|Search text
SUBSTITUTE|text|جایگزینی متن|Substitute text
REPLACE|text|جایگزینی بر اساس موقعیت|Replace by position
REPT|text|تکرار متن|Repeat text
TEXT|text|تبدیل عدد به متن با قالب|Format number as text
VALUE|text|تبدیل متن به عدد|Text to number
CONCAT|text|چسباندن متن‌ها|Join text
CONCATENATE|text|چسباندن متن‌ها|Join text
TEXTJOIN|text|چسباندن با جداکننده|Join with delimiter
EXACT|text|مقایسهٔ دقیق متن|Exact comparison
CHAR|text|کاراکتر از کد|Character from code
CODE|text|کد کاراکتر|Code of character
UNICHAR|text|کاراکتر یونیکد|Unicode character
UNICODE|text|کد یونیکد|Unicode code point
T|text|فقط متن|Text only
N|text|فقط عدد|Number only
FIXED|text|عدد با اعشار ثابت|Fixed decimals text
HYPERLINK|text|پیوند|Hyperlink
VLOOKUP|lookup|جستجوی عمودی|Vertical lookup
HLOOKUP|lookup|جستجوی افقی|Horizontal lookup
LOOKUP|lookup|جستجو|Lookup
XLOOKUP|lookup|جستجوی پیشرفته|Extended lookup
MATCH|lookup|موقعیت مقدار|Position of a value
INDEX|lookup|مقدار در موقعیت|Value at position
CHOOSE|lookup|انتخاب از فهرست|Choose from list
ROW|lookup|شمارهٔ ردیف|Row number
COLUMN|lookup|شمارهٔ ستون|Column number
ROWS|lookup|تعداد ردیف‌ها|Number of rows
COLUMNS|lookup|تعداد ستون‌ها|Number of columns
INDIRECT|lookup|ارجاع از متن|Reference from text
TODAY|date|تاریخ امروز|Today
NOW|date|اکنون|Now
DATE|date|ساخت تاریخ|Build a date
TIME|date|ساخت زمان|Build a time
YEAR|date|سال|Year
MONTH|date|ماه|Month
DAY|date|روز|Day
HOUR|date|ساعت|Hour
MINUTE|date|دقیقه|Minute
SECOND|date|ثانیه|Second
WEEKDAY|date|روز هفته|Day of week
WEEKNUM|date|شمارهٔ هفته|Week number
DAYS|date|تعداد روز بین دو تاریخ|Days between
DATEDIF|date|اختلاف تاریخ‌ها|Date difference
EDATE|date|تاریخ چند ماه بعد|Date months later
EOMONTH|date|آخر ماه|End of month
NETWORKDAYS|date|روزهای کاری|Working days
DATEVALUE|date|متن به تاریخ|Text to date
TIMEVALUE|date|متن به زمان|Text to time
PMT|fin|قسط وام|Loan payment
FV|fin|ارزش آتی|Future value
PV|fin|ارزش فعلی|Present value
NPV|fin|ارزش خالص فعلی|Net present value
IRR|fin|نرخ بازده داخلی|Internal rate of return
NPER|fin|تعداد دوره‌ها|Number of periods
SLN|fin|استهلاک خط مستقیم|Straight-line depreciation
ISBLANK|info|آیا خالی است|Is blank
ISNUMBER|info|آیا عدد است|Is number
ISTEXT|info|آیا متن است|Is text
ISLOGICAL|info|آیا منطقی است|Is logical
ISERROR|info|آیا خطا است|Is error
ISERR|info|آیا خطا (جز N/A) است|Is error except N/A
ISNA|info|آیا N/A است|Is #N/A
ISEVEN|info|آیا زوج است|Is even
ISODD|info|آیا فرد است|Is odd
NA|info|مقدار N/A|Returns #N/A
''';

class XFunc {
  final String name, cat, fa, en;
  const XFunc(this.name, this.cat, this.fa, this.en);
}

List<XFunc> get kFunctions => [
      for (final l in _fnData.trim().split('\n'))
        if (l.contains('|'))
          XFunc(l.split('|')[0], l.split('|')[1], l.split('|')[2], l.split('|')[3]),
    ];

const kFunctionCats = <(String, String, String)>[
  ('all', 'همه', 'All'),
  ('math', 'ریاضی', 'Math'),
  ('stat', 'آماری', 'Statistical'),
  ('logic', 'منطقی', 'Logical'),
  ('text', 'متن', 'Text'),
  ('lookup', 'جستجو و مرجع', 'Lookup & reference'),
  ('date', 'تاریخ و زمان', 'Date & time'),
  ('fin', 'مالی', 'Financial'),
  ('info', 'اطلاعات', 'Information'),
];

/// Function library; returns the chosen function name or null.
Future<String?> pickFunction(BuildContext c) {
  var cat = 'all';
  final q = TextEditingController();
  final all = kFunctions;
  return _sheet<String>(
    c,
    (ctx) => StatefulBuilder(
      builder: (ctx, set) {
        final shown = all.where((f) => (cat == 'all' || f.cat == cat) && (q.text.isEmpty || f.name.toLowerCase().contains(q.text.toLowerCase()) || f.fa.contains(q.text) || f.en.toLowerCase().contains(q.text.toLowerCase()))).toList();
        return SizedBox(
          height: MediaQuery.of(ctx).size.height * .8,
          child: Column(children: [
            _title('${tr2('کتابخانهٔ توابع', 'Function library')} (${all.length})'),
            Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: TextField(controller: q, onChanged: (_) => set(() {}), decoration: InputDecoration(prefixIcon: const Icon(Icons.search_rounded), hintText: tr2('جستجوی تابع', 'Search functions'), isDense: true))),
            SizedBox(
              height: 46,
              child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
                for (final k in kFunctionCats)
                  Padding(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6), child: ChoiceChip(label: Text(tr2(k.$2, k.$3)), selected: cat == k.$1, onSelected: (_) => set(() => cat = k.$1))),
              ]),
            ),
            Expanded(
              child: ListView(children: [
                for (final f in shown)
                  ListTile(
                    dense: true,
                    leading: officeFx(kOfficeGreen, size: 20),
                    title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                    subtitle: Text(tr2(f.fa, f.en)),
                    onTap: () => Navigator.pop(ctx, f.name),
                  ),
              ]),
            ),
          ]),
        );
      },
    ),
  );
}
