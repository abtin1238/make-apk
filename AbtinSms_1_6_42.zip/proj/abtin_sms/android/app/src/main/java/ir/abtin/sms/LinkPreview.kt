package ir.abtin.sms

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.pow
import kotlin.math.tan

data class LinkMeta(val url: String, val host: String, val title: String, val desc: String, val image: Bitmap?, val video: Boolean = false)

object LinkPreviews {
    private val cache = ConcurrentHashMap<String, LinkMeta>()
    private val urlRx = Regex("(https?://[^\\s]+|www\\.[^\\s]+)", RegexOption.IGNORE_CASE)
    private const val MAX_HTML = 256 * 1024
    private const val MAX_IMG = 3 * 1024 * 1024

    fun firstUrl(t: String): String? {
        val m = urlRx.find(t)?.value ?: return null
        val s = m.trimEnd('.', ',', ')', ']', '!', '?', '؟', '،', ';', ':', '"', '\'')
        return if (s.startsWith("www.", true)) "https://$s" else s
    }

    private fun open(u: String, accept: String, timeout: Int = 7000): HttpURLConnection {
        var url = u
        repeat(6) {
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = timeout; readTimeout = timeout; instanceFollowRedirects = false
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AbtinSMS LinkPreview")
                setRequestProperty("Accept", accept)
                setRequestProperty("Accept-Language", "fa,en;q=0.8")
            }
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: error("redirect")
                url = URL(URL(url), loc).toString(); c.disconnect()
                if (!url.startsWith("http", true)) error("scheme")
            } else return c
        }
        error("too many redirects")
    }

    private fun readLimited(i: java.io.InputStream, max: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream(); val b = ByteArray(8192)
        while (out.size() < max) { val n = i.read(b); if (n < 0) break; out.write(b, 0, n) }
        return out.toByteArray()
    }

    private fun meta(html: String, vararg names: String): String? {
        for (n in names) {
            val a = Regex("<meta[^>]+(?:property|name)\\s*=\\s*[\"']$n[\"'][^>]*content\\s*=\\s*[\"']([^\"']*)[\"']", RegexOption.IGNORE_CASE).find(html)
            val b = Regex("<meta[^>]+content\\s*=\\s*[\"']([^\"']*)[\"'][^>]*(?:property|name)\\s*=\\s*[\"']$n[\"']", RegexOption.IGNORE_CASE).find(html)
            val v = (a ?: b)?.groupValues?.get(1)?.trim()
            if (!v.isNullOrEmpty()) return unescape(v)
        }
        return null
    }

    private fun unescape(s: String) = s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&#x27;", "'")
        .replace("&lt;", "<").replace("&gt;", ">").replace(Regex("\\s+"), " ").trim()

    private fun isMaps(host: String, path: String) =
        (host.contains("google.") && path.startsWith("/maps")) || host == "maps.app.goo.gl" || host == "goo.gl" || host.contains("consent.google")

    /** Offline card built from the URL alone, shown at once and kept when the site gives no usable metadata. */
    fun fallback(url: String): LinkMeta {
        val u = runCatching { URL(url) }.getOrNull() ?: return LinkMeta(url, url.take(40), "", "", null)
        val host = u.host.removePrefix("www.")
        val path = runCatching { Uri.decode(u.path.replace("+", " ")) }.getOrDefault(u.path)
        val last = path.trimEnd('/').substringAfterLast('/')
        val maps = isMaps(host, u.path)
        val ext = last.substringAfterLast('.', "").lowercase()
        val title = when {
            maps && path.contains("/place/") -> path.substringAfter("/place/").substringBefore('/').substringBefore(',').trim()
            maps -> "Google Maps"
            last.contains('.') && ext.length in 2..5 -> last
            else -> last.take(80)
        }
        val desc = when {
            maps -> tr("مکان در نقشه گوگل", "Location on Google Maps")
            ext in setOf("zip", "apk", "pdf", "rar", "7z", "mp4", "mp3") -> tr("فایل قابل دانلود", "Downloadable file")
            else -> ""
        }
        return LinkMeta(url, host, title, desc, null)
    }

    private fun coords(u: String): Pair<Double, Double>? {
        val s = runCatching { Uri.decode(u) }.getOrDefault(u)
        val rx = listOf(
            Regex("!3d(-?\\d+\\.\\d+)!4d(-?\\d+\\.\\d+)"),
            Regex("@(-?\\d+\\.\\d+),(-?\\d+\\.\\d+)"),
            Regex("[?&](?:q|ll|query|center)=(-?\\d+\\.\\d+),\\s*(-?\\d+\\.\\d+)")
        )
        for (r in rx) r.find(s)?.let { return it.groupValues[1].toDouble() to it.groupValues[2].toDouble() }
        return null
    }

    /** OpenStreetMap tiles stitched into a 640x360 picture with a pin at the point. */
    private fun mapImage(lat: Double, lng: Double): Bitmap? = runCatching {
        val z = 16; val n = 2.0.pow(z)
        val xf = (lng + 180.0) / 360.0 * n
        val r = Math.toRadians(lat)
        val yf = (1.0 - ln(tan(r) + 1.0 / cos(r)) / PI) / 2.0 * n
        val tx = floor(xf).toInt(); val ty = floor(yf).toInt()
        val px = ((xf - tx) * 256).toInt(); val py = ((yf - ty) * 256).toInt()
        val bmp = Bitmap.createBitmap(640, 360, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp); cv.drawColor(0xFFE8E4DC.toInt())
        var ok = 0
        for (dx in -2..2) for (dy in -1..1) {
            val t = runCatching {
                val c = open("https://tile.openstreetmap.org/$z/${tx + dx}/${ty + dy}.png", "image/png")
                if (c.responseCode !in 200..299) null else c.inputStream.use { BitmapFactory.decodeStream(it) }
            }.getOrNull() ?: continue
            cv.drawBitmap(t, (320 - px + dx * 256).toFloat(), (180 - py + dy * 256).toFloat(), null); ok++
        }
        if (ok == 0) return null
        val pin = Paint(Paint.ANTI_ALIAS_FLAG)
        pin.color = 0xFFFFFFFF.toInt(); cv.drawCircle(320f, 180f, 16f, pin)
        pin.color = 0xFFE53935.toInt(); cv.drawCircle(320f, 180f, 11f, pin)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG); tp.textSize = 18f; tp.color = 0xFF333333.toInt()
        cv.drawText("© OpenStreetMap", 440f, 352f, tp)
        bmp
    }.getOrNull()

    private fun videoFrame(u: String): Bitmap? = runCatching {
        val r = MediaMetadataRetriever()
        try { r.setDataSource(u, HashMap<String, String>()); r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) } finally { runCatching { r.release() } }
    }.getOrNull()

    private fun decode(bytes: ByteArray): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1
        while (o.outWidth / (s * 2) >= 800) s *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun loadImage(u: String, timeout: Int = 7000): Bitmap? = runCatching {
        val c = open(u, "image/*", timeout)
        if (c.responseCode !in 200..299) error("http")
        decode(c.inputStream.use { readLimited(it, MAX_IMG) })
    }.getOrNull()

    /** Picture of the page itself when the site gives no image (third-party screenshot service). */
    private fun screenshot(u: String): Bitmap? = loadImage("https://image.thum.io/get/width/640/crop/360/$u", 20000)

    suspend fun load(url: String): LinkMeta? {
        cache[url]?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching {
                val fb = fallback(url)
                val c = open(url, "text/html,application/xhtml+xml,image/*,video/*;q=0.9,*/*;q=0.5")
                val finalUrl = c.url.toString()
                val ct = (c.contentType ?: "").lowercase()
                if (c.responseCode !in 200..299) error("http")
                val host = URL(finalUrl).host.removePrefix("www.")
                val name = runCatching { Uri.decode(URL(finalUrl).path).trimEnd('/').substringAfterLast('/') }.getOrDefault("")
                val res: LinkMeta = when {
                    ct.startsWith("image/") -> LinkMeta(url, host, name, tr("تصویر", "Image"), decode(c.inputStream.use { readLimited(it, MAX_IMG) }))
                    ct.startsWith("video/") -> { c.disconnect(); LinkMeta(url, host, name, tr("ویدیو", "Video"), videoFrame(finalUrl), true) }
                    ct.contains("html") -> {
                        val raw = c.inputStream.use { readLimited(it, MAX_HTML) }
                        val cs = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(ct)?.groupValues?.get(1)
                            ?: Regex("charset\\s*=\\s*[\"']?([\\w-]+)", RegexOption.IGNORE_CASE).find(String(raw, Charsets.ISO_8859_1))?.groupValues?.get(1) ?: "UTF-8"
                        val html = String(raw, runCatching { charset(cs) }.getOrDefault(Charsets.UTF_8))
                        val fu = URL(finalUrl)
                        if (isMaps(host, fu.path)) {
                            val pt = coords(finalUrl) ?: coords(url)
                            val mf = fallback(finalUrl)
                            LinkMeta(url, host, if (mf.title == "Google Maps") fb.title else mf.title, tr("مکان در نقشه گوگل", "Location on Google Maps"), pt?.let { mapImage(it.first, it.second) })
                        } else {
                            val title = meta(html, "og:title", "twitter:title")
                                ?: Regex("<title[^>]*>([^<]*)</title>", RegexOption.IGNORE_CASE).find(html)?.groupValues?.get(1)?.let { unescape(it) } ?: ""
                            val desc = meta(html, "og:description", "twitter:description", "description") ?: ""
                            val isVideo = meta(html, "og:video", "og:video:url", "og:video:secure_url", "twitter:player") != null || meta(html, "og:type")?.startsWith("video") == true
                            val imgUrl = (meta(html, "og:image", "og:image:secure_url", "twitter:image", "twitter:image:src")
                                ?: Regex("<link[^>]+rel\\s*=\\s*[\"']image_src[\"'][^>]*href\\s*=\\s*[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE).find(html)?.groupValues?.get(1))
                                ?.let { runCatching { URL(fu, it).toString() }.getOrNull() }
                            val img = imgUrl?.let { loadImage(it) } ?: screenshot(finalUrl)
                            LinkMeta(url, host, title.take(120).ifEmpty { fb.title }, desc.take(200), img, isVideo)
                        }
                    }
                    else -> error("file")
                }
                if (res.image == null && res.title == fb.title && res.desc == fb.desc) error("nothing new")
                cache[url] = res; res
            }.getOrNull()
        }
    }
}

@Composable
fun LinkPreviewCard(body: String, fg: Color, p: Pal) {
    if (!Prefs.linkPreview.value) return
    val url = remember(body) { LinkPreviews.firstUrl(body) } ?: return
    var meta by remember(url) { mutableStateOf(LinkPreviews.fallback(url)) }
    LaunchedEffect(url) { LinkPreviews.load(url)?.let { meta = it } }
    val m = meta
    val ctx = LocalContext.current
    Column(Modifier.padding(top = 6.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = .22f))
        .clickable { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(m.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }) {
        m.image?.let {
            Box(Modifier.fillMaxWidth().height(160.dp), contentAlignment = Alignment.Center) {
                Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                if (m.video) Box(Modifier.size(46.dp).clip(CircleShape).background(Color.Black.copy(alpha = .55f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Filled.PlayArrow, null, tint = Color.White, modifier = Modifier.size(30.dp))
                }
            }
        }
        Column(Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) {
            Text(m.host, color = p.sub, fontSize = 11.sp, maxLines = 1)
            if (m.title.isNotEmpty()) Text(m.title, color = fg, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content))
            if (m.desc.isNotEmpty()) Text(m.desc, color = fg.copy(alpha = .8f), fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content))
        }
    }
}
