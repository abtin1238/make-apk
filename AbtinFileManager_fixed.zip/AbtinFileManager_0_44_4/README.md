# Abtin File Manager (Flutter)
Complete file manager + media player + LAN transfer + archive extractor (zip/rar/7z/tar/gz/bz2/xz).

```
flutter create . --platforms=android --org ir.abtin
flutter pub get
flutter run
```
Needs `android/local.properties` (flutter.sdk). See TODO.md for status and roadmap.

## Android terminal

The terminal uses Kotlin to manage sessions, a small Java JNI bridge, and an Android NDK C++ `forkpty(3)` backend. The Flutter screen uses `xterm` to render ANSI/VT escape sequences, cursor movement, colours and scrollback. Ctrl+C is sent as ETX to the PTY line discipline, which delivers SIGINT to the foreground process group; terminal dimensions are forwarded to the PTY.

This is a PTY-backed Android shell, **not a complete Termux distribution**. The shell is `/system/bin/sh`; tools are limited to Android's built-ins, app-installed binaries and the app's granted filesystem access. Termux's APT repositories, Linux userspace and root access are not included; instead the app ships its own `pkg` (see below). Interactive programs work only when their executables and any required libraries/data are available to this app. Building the native backend needs Android NDK + CMake; build and device-test on a supported Android host before release.

Run `flutter pub get`, `flutter analyze`, `flutter test`, then `flutter build appbundle --release` on an Android build host. See TODO.md for the current validation results and host-specific build limitation.

v0.3: Word (rich formatting, tables, images, undo, find/replace), legacy .doc (text -> .docx) and PDF (draw/highlight/text/page ops) are editable in-app. See TODO.md.
v0.4: complete media player (background audio + notification, tags/cover art, sleep timer, queue editor; video gestures, PiP, subtitles tools, resume, network streams) and media library screen.

v0.17: tar.gz / 7z (password) creation, extraction & compression progress, ProGuard rules, release signing (`android/key.properties`), CI workflow and unit tests. See TODO.md.

## Package manager (`pkg`)

Available in the terminal as `pkg` (alias `apt`). Prefix: `$HOME/usr` (`$PREFIX`). Implemented in `android/app/src/main/java/ir/abtin/filemanager/PkgCli.java` (pure JDK; started with `app_process`, so it needs no extra binary) and wired up by `PkgEnv.java` (creates the prefix, writes `etc/shrc` through `ENV`, defines the `pkg` function and one alias per command in `$PREFIX/bin`).

Commands: `update`, `search`, `show`, `list-all`, `list-installed`, `install` (names, local files or URLs; dependencies, SHA-256 check, conflict check, rollback), `reinstall`, `remove` (reverse-dependency check), `autoremove`, `upgrade`, `files`, `owns`, `clean`, `repo list|add|remove`, `doctor`. Options: `-y`, `--force`, `--no-deps`, `--reinstall`.

Repositories are Debian `Packages` indexes (flat, or apt layout with `dist component`). Packages: `.deb`, `.tar[.gz/.xz/.bz2]`, `.zip`; `usr/` and `/data/data/com.termux/files/usr` are mapped into the prefix. Build a repo with `python3 tools/mkrepo.py OUT PKGDIR...` and host it anywhere. Built-in offline packages: `tree`, `watch`, `sysinfo`, `abtin-tools`.

Android 10+ forbids `execve` of files in app storage: scripts run with `/system/bin/sh`, native ELF programs through `/system/bin/linker(64)` (aliases are generated automatically). Programs built for the Termux prefix usually do not work unless relocatable.

## Alpine (apk, Python, Node.js) - `alpine`

`alpine setup` downloads the official Alpine minirootfs (index: `latest-stable/releases/<arch>/latest-releases.yaml`, SHA-256 verified, safe extraction, setuid stripped) into `$PREFIX/alpine` and configures apk. `alpine proot <file|url> [loader]` installs a proot binary (not bundled). Then: `alpine bootstrap` (apk update + python3, py3-pip, git, nodejs and npm), `alpine` (shell), `alpine run CMD`, `alpine install|uninstall PKG...`, `alpine update|upgrade|status|remove|doctor`. Commands such as `git`, `python3`, `pip`, `apk`, `node` and `npm` become aliases that run inside Alpine. Mirror override: `ABTIN_ALPINE_MIRROR`.

After `alpine bootstrap` finishes, enter `pip install <package>` for Python libraries and `npm install <package>` for Node packages. Install Python itself with Alpine (`apk add python3 py3-pip`), not with pip; Python syntax is `python3` / `python`, not `py i`.
