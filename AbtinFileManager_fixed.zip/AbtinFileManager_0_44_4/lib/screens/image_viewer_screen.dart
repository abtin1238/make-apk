import 'dart:io';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../widgets/abtin_global_rail.dart';
import 'package:path/path.dart' as p;
import 'package:share_plus/share_plus.dart';
import '../core/l10n.dart';
import 'image_editor_screen.dart';
import 'viewer_delete.dart';

class ImageViewerScreen extends StatefulWidget {
  final List<String> paths;
  final int index;
  const ImageViewerScreen(
      {super.key, required this.paths, required this.index});
  @override
  State<ImageViewerScreen> createState() => _ImageViewerScreenState();
}

class _ImageViewerScreenState extends State<ImageViewerScreen>
    with SingleTickerProviderStateMixin {
  late final PageController pc = PageController(initialPage: widget.index);
  late final List<String> paths = List.of(widget.paths);
  late int cur = widget.index;
  final rot = <String, int>{};
  final _tc = TransformationController();
  late final AnimationController _ac = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 220));
  Animation<Matrix4>? _anim;
  bool zoomed = false;
  Offset _tap = Offset.zero;
  int _rev = 0;

  @override
  void initState() {
    super.initState();
    _tc.addListener(() {
      final z = _tc.value.getMaxScaleOnAxis() > 1.02;
      if (z != zoomed) setState(() => zoomed = z);
    });
  }

  @override
  void dispose() {
    _ac.dispose();
    _tc.dispose();
    pc.dispose();
    super.dispose();
  }

  void _tick() => _tc.value = _anim!.value;

  void _animateTo(Matrix4 end) {
    _anim?.removeListener(_tick);
    _anim = Matrix4Tween(begin: _tc.value, end: end)
        .animate(CurvedAnimation(parent: _ac, curve: Curves.easeOut))
      ..addListener(_tick);
    _ac.forward(from: 0);
  }

  void _doubleTap() {
    if (zoomed) {
      _animateTo(Matrix4.identity());
    } else {
      const s = 2.5;
      _animateTo(Matrix4.diagonal3Values(s, s, 1)
        ..setTranslationRaw(-_tap.dx * (s - 1), -_tap.dy * (s - 1), 0));
    }
  }

  Future<void> _edit() async {
    final r = await Navigator.push<String>(
        context,
        abtinPageRoute((_) => ImageEditorScreen(path: paths[cur]),
            hideRail: true));
    if (r == null || !mounted) return;
    _tc.value = Matrix4.identity();
    if (r == paths[cur]) {
      setState(() {
        rot.remove(r);
        _rev++;
      });
    } else {
      setState(() => paths.insert(cur + 1, r));
      pc.jumpToPage(cur + 1);
    }
  }

  Future<void> _delete() async {
    final path = paths[cur];
    if (!await deleteFromViewer(context, path) || !mounted) return;
    if (paths.length <= 1) {
      Navigator.pop(context);
      return;
    }
    _tc.value = Matrix4.identity();
    setState(() {
      paths.removeAt(cur);
      if (cur >= paths.length) cur = paths.length - 1;
      _rev++;
    });
    pc.jumpToPage(cur);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.black54,
          title: Text(p.basename(paths[cur]),
              style: const TextStyle(fontSize: 15)),
          actions: [
            IconButton(icon: const Icon(Icons.tune_rounded), onPressed: _edit),
            IconButton(
                icon: const Icon(Icons.rotate_right_rounded),
                onPressed: () => setState(
                    () => rot[paths[cur]] = ((rot[paths[cur]] ?? 0) + 1) % 4)),
            IconButton(
                icon: const Icon(Icons.share_rounded),
                onPressed: () => Share.shareXFiles([XFile(paths[cur])])),
            IconButton(
                icon: const Icon(Icons.delete_outline_rounded),
                tooltip: L.t('delete'),
                onPressed: _delete),
          ],
        ),
        body: PageView.builder(
          controller: pc,
          physics: zoomed
              ? const NeverScrollableScrollPhysics()
              : const PageScrollPhysics(),
          itemCount: paths.length,
          onPageChanged: (i) {
            _ac.stop();
            _tc.value = Matrix4.identity();
            setState(() => cur = i);
          },
          itemBuilder: (c, i) => GestureDetector(
            behavior: HitTestBehavior.opaque,
            onDoubleTapDown: (d) => _tap = d.localPosition,
            onDoubleTap: _doubleTap,
            child: InteractiveViewer(
              key: ValueKey('${paths[i]}#$_rev'),
              transformationController: i == cur ? _tc : null,
              minScale: 1,
              maxScale: 8,
              child: SizedBox.expand(
                child: Center(
                  child: RotatedBox(
                    quarterTurns: rot[paths[i]] ?? 0,
                    child: Image.file(
                      File(paths[i]),
                      fit: BoxFit.contain,
                      filterQuality: FilterQuality.medium,
                      gaplessPlayback: true,
                      errorBuilder: (_, __, ___) => const Icon(
                          Icons.broken_image_rounded,
                          size: 64,
                          color: Colors.white54),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      );
}
