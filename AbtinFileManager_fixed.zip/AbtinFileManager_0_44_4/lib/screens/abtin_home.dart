import 'dart:math' as math;

import 'package:flutter/material.dart' hide Icon;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../widgets/app_icon.dart';
import '../widgets/neon_kit.dart';
import '../widgets/ui.dart';
import 'browser_screen.dart';
import 'category_screen.dart';
import 'home_cats.dart';
import 'home_variants.dart' show StorageBuilder;
import 'office_hub_screen.dart';

String tr2(String fa, String en) => L.lang == 'fa' ? fa : en;

/// Reference-inspired Abtin home screen. The artwork and proportions scale with the device.
class AbtinHome extends StatelessWidget {
  const AbtinHome({super.key});

  void _push(BuildContext context, Widget page) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => page));

  void _openCategory(BuildContext context, String key) {
    final category = homeCat(homeCats(), key);
    if (category != null) _push(context, category.page);
  }

  Future<void> _newFolder(BuildContext context) async {
    final name = await promptText(context, tr2('ایجاد پوشه', 'Create folder'));
    if (name == null || name.trim().isEmpty || !context.mounted) return;
    final ok =
        await busy(context, () => FileOps.mkdir(FileOps.root, name.trim()));
    if (ok && context.mounted)
      snack(
          context, '${tr2('پوشه ساخته شد', 'Folder created')}: ${name.trim()}');
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final k = (width / 393).clamp(.86, 1.18).toDouble();
    final roots = FileOps.roots();
    final dark = Theme.of(context).brightness == Brightness.dark;
    final page = Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton:
          _AddFolderButton(k: k, onTap: () => _newFolder(context)),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      body: SafeArea(
        bottom: false,
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: ListView(
            padding: EdgeInsets.fromLTRB(13 * k, 6 * k, 13 * k, 92 * k),
            children: [
              _BrandHeader(k: k, dark: dark),
              SizedBox(height: 11 * k),
              _WelcomeBanner(
                  k: k,
                  dark: dark,
                  onBrowse: () {
                    if (roots.isNotEmpty)
                      _push(
                          context,
                          BrowserScreen(
                              initialPath: roots.first.path, root: true));
                  }),
              SizedBox(height: 11 * k),
              if (roots.isNotEmpty)
                _StorageSummary(
                    roots: roots,
                    k: k,
                    dark: dark,
                    onTap: () => _push(
                        context,
                        BrowserScreen(
                            initialPath: roots.first.path, root: true))),
              SizedBox(height: 42 * k),
              _QuickCategories(
                  k: k,
                  dark: dark,
                  onOpen: (key) {
                    _openCategory(context, key);
                  }),
              SizedBox(height: 15 * k),
              _SectionLabel(
                  text: tr2('مجموعهٔ آفیس و ابزارها', 'Office suite & tools'),
                  k: k,
                  dark: dark),
              SizedBox(height: 8 * k),
              _OfficeGrid(
                  k: k,
                  dark: dark,
                  onOpen: (idx) {
                    switch (idx) {
                      case 0:
                      case 1:
                      case 2:
                      case 7:
                        _push(
                            context, OfficeHubScreen(directory: FileOps.root));
                        break;
                      case 3:
                      case 5:
                        _openCategory(context, 'pdf');
                        break;
                      case 4:
                        _push(context, CategoryScreen(cat: Cat.archives));
                        break;
                      case 6:
                        _openCategory(context, 'text');
                        break;
                      default:
                        _push(context, CategoryScreen(cat: Cat.docs));
                    }
                  }),
            ],
          ),
        ),
      ),
    );
    return Directionality(
        textDirection: TextDirection.ltr, child: NeonBackdrop(child: page));
  }
}

class _BrandHeader extends StatelessWidget {
  final double k;
  final bool dark;
  const _BrandHeader({required this.k, required this.dark});

  @override
  Widget build(BuildContext context) {
    final ink = dark ? const Color(0xFFF2F5FF) : const Color(0xFF172447);
    return SizedBox(
      height: 66 * k,
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          Container(
            width: 51 * k,
            height: 51 * k,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(colors: [
                Color(0xFF1225B8),
                Color(0xFF4A16E8),
                Color(0xFF0C71EF)
              ], begin: Alignment.topLeft, end: Alignment.bottomRight),
              border: Border.all(color: const Color(0xFF398AFF), width: 1.2),
              boxShadow: [
                BoxShadow(
                    color:
                        const Color(0xFF5427FF).withOpacity(dark ? .55 : .22),
                    blurRadius: 15 * k)
              ],
            ),
            child: Icon(Icons.folder_copy_rounded,
                size: 31 * k, color: const Color(0xFF78D8FF)),
          ),
          SizedBox(width: 12 * k),
          Expanded(
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                RichText(
                    text: TextSpan(
                        style: TextStyle(
                            fontSize: 18 * k,
                            fontWeight: FontWeight.w700,
                            color: ink),
                        children: const [
                      TextSpan(text: 'Abtin '),
                      TextSpan(
                          text: 'File Manager',
                          style: TextStyle(color: Color(0xFF17C9EF))),
                    ])),
                SizedBox(height: 2 * k),
                Text(
                    tr2('مدیریت فایل‌های شما',
                        'Your files, beautifully managed'),
                    style: TextStyle(
                        fontSize: 11.5 * k, color: ink.withOpacity(.72))),
              ])),
          Container(
              width: 9 * k,
              height: 9 * k,
              decoration: const BoxDecoration(
                  color: Color(0xFF00DF91),
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(color: Color(0xAA00DF91), blurRadius: 8)
                  ])),
          SizedBox(width: 4 * k),
        ]),
      ),
    );
  }
}

class _WelcomeBanner extends StatelessWidget {
  final double k;
  final bool dark;
  final VoidCallback onBrowse;
  const _WelcomeBanner(
      {required this.k, required this.dark, required this.onBrowse});

  @override
  Widget build(BuildContext context) {
    final ink = dark ? const Color(0xFFF4F5FF) : const Color(0xFF14234B);
    final radius = BorderRadius.circular(22 * k);
    return Container(
      height: 137 * k,
      decoration: BoxDecoration(
        borderRadius: radius,
        gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: dark
                ? const [
                    Color(0xFF121C4A),
                    Color(0xFF071A49),
                    Color(0xFF0A1741)
                  ]
                : const [
                    Color(0xFFE9EFFF),
                    Color(0xFFD8E9FF),
                    Color(0xFFE9E6FF)
                  ]),
        border: Border.all(
            color: const Color(0xFF6241FF).withOpacity(dark ? .94 : .75),
            width: 1.2),
        boxShadow: [
          BoxShadow(
              color: const Color(0xFF801CFF).withOpacity(dark ? .32 : .14),
              blurRadius: 17 * k)
        ],
      ),
      child: Stack(clipBehavior: Clip.hardEdge, children: [
        Positioned(
            right: 5 * k,
            top: -6 * k,
            width: 130 * k,
            height: 130 * k,
            child: CustomPaint(painter: _ServerStackPainter(dark))),
        Padding(
          padding:
              EdgeInsetsDirectional.fromSTEB(18 * k, 17 * k, 12 * k, 14 * k),
          child: SizedBox(
            width: 160 * k,
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(tr2('مدیریت فایل‌ها', 'File Manager'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 20 * k,
                      fontWeight: FontWeight.w700,
                      color: ink)),
              SizedBox(height: 3 * k),
              Text(tr2('سریع، هوشمند و قدرتمند', 'Fast, smart and powerful'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 12.5 * k, color: ink.withOpacity(.78))),
              const Spacer(),
              Material(
                color: Colors.transparent,
                child: InkWell(
                  borderRadius: BorderRadius.circular(28 * k),
                  onTap: onBrowse,
                  child: Container(
                    height: 39 * k,
                    padding: EdgeInsets.symmetric(horizontal: 12 * k),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(28 * k),
                        gradient: const LinearGradient(
                            colors: [Color(0xFF198EFF), Color(0xFF2548ED)]),
                        boxShadow: [
                          BoxShadow(
                              color: const Color(0xFF138AFF).withOpacity(.32),
                              blurRadius: 11 * k)
                        ]),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.pie_chart_rounded,
                          color: Colors.white, size: 21 * k),
                      SizedBox(width: 7 * k),
                      Flexible(
                          child: Text(tr2('مرور حافظه', 'Browse storage'),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13 * k))),
                      SizedBox(width: 3 * k),
                      Icon(Icons.chevron_right_rounded,
                          color: Colors.white, size: 22 * k),
                    ]),
                  ),
                ),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _ServerStackPainter extends CustomPainter {
  final bool dark;
  const _ServerStackPainter(this.dark);

  void _unit(Canvas canvas, double dy) {
    final top = Path()
      ..moveTo(30, 70 + dy)
      ..lineTo(100, 44 + dy)
      ..lineTo(162, 66 + dy)
      ..lineTo(100, 92 + dy)
      ..close();
    final front = Path()
      ..moveTo(30, 78 + dy)
      ..lineTo(100, 52 + dy)
      ..lineTo(162, 74 + dy)
      ..lineTo(162, 96 + dy)
      ..lineTo(100, 122 + dy)
      ..lineTo(30, 96 + dy)
      ..close();
    final leftFace = Path()
      ..moveTo(30, 70 + dy)
      ..lineTo(30, 92 + dy)
      ..lineTo(100, 118 + dy)
      ..lineTo(100, 96 + dy)
      ..close();
    final topPaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFFE8F1FF), Color(0xFF7C93D8)],
      ).createShader(Rect.fromLTWH(30, 44 + dy, 132, 48));
    final facePaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF6A8CF0), Color(0xFF1C2F9A)],
      ).createShader(Rect.fromLTWH(30, 52 + dy, 132, 70));

    canvas.drawPath(front, facePaint);
    canvas.drawPath(top, topPaint);
    canvas.drawPath(leftFace, Paint()..color = const Color(0xFF2E46C0));
    canvas.drawCircle(
        Offset(46, 86 + dy), 3.2, Paint()..color = const Color(0xFF0A1A6A));
    canvas.drawCircle(
        Offset(116, 108 + dy), 3.4, Paint()..color = const Color(0xFF23D3FF));
  }

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 190, size.height / 190);
    canvas.save();
    canvas.translate(95, 110);
    canvas.rotate(-12 * math.pi / 180);
    canvas.translate(-95, -110);
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(95, 110), width: 172, height: 60),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = const Color(0xCC23D3FF),
    );
    canvas.drawOval(
      Rect.fromCenter(center: const Offset(95, 110), width: 152, height: 44),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = const Color(0xCCB25BFF),
    );
    canvas.restore();
    _unit(canvas, 68);
    _unit(canvas, 34);
    _unit(canvas, 0);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _ServerStackPainter oldDelegate) =>
      dark != oldDelegate.dark;
}

class _StorageSummary extends StatelessWidget {
  final List<StorageRoot> roots;
  final double k;
  final bool dark;
  final VoidCallback onTap;
  const _StorageSummary(
      {required this.roots,
      required this.k,
      required this.dark,
      required this.onTap});

  Color get _ink => dark ? const Color(0xFFEAF0FF) : const Color(0xFF18254A);

  @override
  Widget build(BuildContext context) {
    final main = roots.first;
    return Container(
      height: 86 * k,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22 * k),
        gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: dark
                ? const [
                    Color(0xFF111A49),
                    Color(0xFF10245A),
                    Color(0xFF0A1D4A)
                  ]
                : const [
                    Color(0xFFEAF5FF),
                    Color(0xFFDDEBFF),
                    Color(0xFFE9E8FF)
                  ]),
        border: Border.all(
            color: const Color(0xFF506EFF).withOpacity(dark ? .8 : .65),
            width: 1.1),
        boxShadow: [
          BoxShadow(
              color: const Color(0xFF206BFF).withOpacity(dark ? .23 : .12),
              blurRadius: 13 * k)
        ],
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(22 * k),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 12 * k, vertical: 9 * k),
            child: Row(children: [
              Expanded(
                flex: 6,
                child: StorageBuilder(
                    root: main,
                    builder: (total, used) {
                      final ratio = total == 0
                          ? 0.0
                          : (used / total).clamp(0.0, 1.0).toDouble();
                      return Row(children: [
                        SizedBox(
                            width: 55 * k,
                            height: 56 * k,
                            child:
                                CustomPaint(painter: _MiniDiskPainter(dark))),
                        SizedBox(width: 8 * k),
                        Expanded(
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                              Text('${(ratio * 100).round()}%',
                                  style: TextStyle(
                                      color: _ink,
                                      fontSize: 26 * k,
                                      fontWeight: FontWeight.w700,
                                      height: 1.02)),
                              SizedBox(height: 3 * k),
                              FittedBox(
                                  fit: BoxFit.scaleDown,
                                  alignment: AlignmentDirectional.centerStart,
                                  child: Text(
                                      total == 0
                                          ? '…'
                                          : '${FileOps.fmt(used)} / ${FileOps.fmt(total)}',
                                      style: TextStyle(
                                          color: _ink.withOpacity(.84),
                                          fontSize: 11.5 * k,
                                          fontWeight: FontWeight.w500))),
                            ])),
                      ]);
                    }),
              ),
              Container(
                  width: 1,
                  height: 58 * k,
                  margin: EdgeInsets.symmetric(horizontal: 10 * k),
                  color: const Color(0xFFADC8FF).withOpacity(.55)),
              Expanded(
                  flex: 5,
                  child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        _StorageBar(root: main, k: k, dark: dark),
                        if (roots.length > 1)
                          Padding(
                            padding: EdgeInsets.only(top: 4 * k),
                            child: _StorageBar(
                                root: roots[1], k: k, dark: dark),
                          ),
                      ])),
              SizedBox(width: 3 * k),
              Icon(Icons.chevron_right_rounded, color: _ink, size: 21 * k),
            ]),
          ),
        ),
      ),
    );
  }
}

class _StorageBar extends StatelessWidget {
  final StorageRoot root;
  final double k;
  final bool dark;
  const _StorageBar({required this.root, required this.k, required this.dark});
  @override
  Widget build(BuildContext context) => StorageBuilder(
      root: root,
      builder: (total, used) {
        final ratio =
            total == 0 ? 0.0 : (used / total).clamp(0.0, 1.0).toDouble();
        final label = root.sd
            ? tr2('کارت حافظه', 'SD card')
            : tr2('حافظه داخلی', 'Internal storage');
        return Row(children: [
          Icon(root.sd ? Icons.sd_card_rounded : Icons.smartphone_rounded,
              color: dark ? const Color(0xFFDBE6FF) : const Color(0xFF4561A0),
              size: 17 * k),
          SizedBox(width: 6 * k),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        color: dark
                            ? const Color(0xFFF2F4FF)
                            : const Color(0xFF1B2B52),
                        fontSize: 9.2 * k,
                        fontWeight: FontWeight.w500)),
                SizedBox(height: 2 * k),
                ClipRRect(
                    borderRadius: BorderRadius.circular(5 * k),
                    child: LinearProgressIndicator(
                        value: ratio,
                        minHeight: 4 * k,
                        backgroundColor: const Color(0xFF233B88)
                            .withOpacity(dark ? .9 : .25),
                        valueColor: AlwaysStoppedAnimation<Color>(root.sd
                            ? const Color(0xFF09D6E8)
                            : const Color(0xFF923AFF)))),
              ])),
        ]);
      });
}

class _MiniDiskPainter extends CustomPainter {
  final bool dark;
  const _MiniDiskPainter(this.dark);
  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.scale(size.width / 78, size.height / 80);
    final sidePaint = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
        colors: [Color(0xFF2A8BFF), Color(0xFF9BE8FF), Color(0xFF1B50D8)],
        stops: [0, .45, 1],
      ).createShader(const Rect.fromLTWH(6, 0, 66, 80));
    final topPaint = Paint()..color = const Color(0xFFBDF0FF);
    final innerPaint = Paint()..color = const Color(0xFF6FD0FF);
    for (final y in const [50.0, 32.0, 14.0]) {
      final side = Path()
        ..moveTo(6, y)
        ..lineTo(6, y + 14)
        ..cubicTo(6, y + 21, 21, y + 25, 39, y + 25)
        ..cubicTo(57, y + 25, 72, y + 21, 72, y + 14)
        ..lineTo(72, y)
        ..close();
      canvas.drawPath(side, sidePaint);
      canvas.drawOval(
          Rect.fromCenter(center: Offset(39, y), width: 66, height: 22),
          topPaint);
      canvas.drawOval(
          Rect.fromCenter(center: Offset(39, y), width: 28, height: 9),
          innerPaint);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _MiniDiskPainter oldDelegate) =>
      dark != oldDelegate.dark;
}

class _QuickCategories extends StatelessWidget {
  final double k;
  final bool dark;
  final ValueChanged<String> onOpen;
  const _QuickCategories(
      {required this.k, required this.dark, required this.onOpen});
  @override
  Widget build(BuildContext context) {
    const data = [
      ('images', 'images', Color(0xFF22C8D5)),
      ('videos', 'videos', Color(0xFF833BFF)),
      ('music', 'audio', Color(0xFF8D36FF)),
      ('downloads', 'other', Color(0xFF08D3A1)),
    ];
    return Row(children: [
      for (var i = 0; i < data.length; i++) ...[
        if (i > 0) SizedBox(width: 8 * k),
        Expanded(
            child: _QuickTile(
                k: k,
                dark: dark,
                title: L.t(data[i].$1),
                iconKey: data[i].$2,
                accent: data[i].$3,
                onTap: () => onOpen(data[i].$1))),
      ],
    ]);
  }
}

class _QuickTile extends StatelessWidget {
  final double k;
  final bool dark;
  final String title;
  final String iconKey;
  final Color accent;
  final VoidCallback onTap;
  const _QuickTile(
      {required this.k,
      required this.dark,
      required this.title,
      required this.iconKey,
      required this.accent,
      required this.onTap});
  @override
  Widget build(BuildContext context) => Container(
        height: 91 * k,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(17 * k),
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: dark
                  ? [
                      Color.lerp(accent, const Color(0xFF09142E), .45)!,
                      const Color(0xFF0A1431)
                    ]
                  : [
                      Color.lerp(accent, Colors.white, .82)!,
                      const Color(0xFFEDF3FF)
                    ]),
          border: Border.all(
              color: accent.withOpacity(dark ? .7 : .52), width: 1.1),
          boxShadow: [
            BoxShadow(
                color: accent.withOpacity(dark ? .22 : .13), blurRadius: 11 * k)
          ],
        ),
        child: Material(
            color: Colors.transparent,
            child: InkWell(
                borderRadius: BorderRadius.circular(17 * k),
                onTap: onTap,
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                          width: 36 * k,
                          height: 34 * k,
                          decoration: BoxDecoration(
                              color: dark
                                  ? accent.withOpacity(.24)
                                  : Colors.white.withOpacity(.78),
                              borderRadius: BorderRadius.circular(9 * k),
                              boxShadow: [
                                BoxShadow(
                                    color: accent.withOpacity(.25),
                                    blurRadius: 7 * k)
                              ]),
                          child: KeyIcon(iconKey, size: 25 * k)),
                      SizedBox(height: 7 * k),
                      Text(title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              fontSize: 11.5 * k,
                              fontWeight: FontWeight.w600,
                              color: dark
                                  ? const Color(0xFFF3F5FF)
                                  : const Color(0xFF17264D))),
                    ]))),
      );
}

class _SectionLabel extends StatelessWidget {
  final String text;
  final double k;
  final bool dark;
  const _SectionLabel(
      {required this.text, required this.k, required this.dark});
  @override
  Widget build(BuildContext context) => Row(children: [
        Expanded(
            child: Text(text,
                style: TextStyle(
                    color: dark
                        ? const Color(0xFFE4E8FA)
                        : const Color(0xFF17264D),
                    fontSize: 13.5 * k,
                    fontWeight: FontWeight.w600))),
        Icon(
            Directionality.of(context) == TextDirection.rtl
                ? Icons.chevron_left_rounded
                : Icons.chevron_right_rounded,
            color: const Color(0xFF08D5F1),
            size: 22 * k),
      ]);
}

class _OfficeGrid extends StatelessWidget {
  final double k;
  final bool dark;
  final ValueChanged<int> onOpen;
  const _OfficeGrid(
      {required this.k, required this.dark, required this.onOpen});
  static const _apps = [
    ('Word', 'W', Color(0xFF1375E8)),
    ('Excel', 'X', Color(0xFF00A965)),
    ('PowerPoint', 'P', Color(0xFFE95624)),
    ('PDF Reader', 'PDF', Color(0xFFED2339)),
    ('Zip', 'ZIP', Color(0xFFFFB81C)),
    ('Acrobat', 'A', Color(0xFFE72C36)),
    ('Notes', 'N', Color(0xFFFFC928)),
    ('Sheets', '▦', Color(0xFF15B86C)),
  ];
  @override
  Widget build(BuildContext context) => GridView.builder(
        itemCount: _apps.length,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 4,
            crossAxisSpacing: 8 * k,
            mainAxisSpacing: 7 * k,
            childAspectRatio: .94),
        itemBuilder: (context, i) {
          final app = _apps[i];
          final color = app.$3;
          return InkWell(
            borderRadius: BorderRadius.circular(17 * k),
            onTap: () => onOpen(i),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(17 * k),
                gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: dark
                        ? const [Color(0xFF151643), Color(0xFF061637)]
                        : const [Color(0xFFF5F3FF), Color(0xFFE4F2FF)]),
                border: Border.all(
                    color: color.withOpacity(dark ? .7 : .55), width: 1.05),
                boxShadow: [
                  BoxShadow(
                      color: color.withOpacity(dark ? .20 : .11),
                      blurRadius: 10 * k)
                ],
              ),
              child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 43 * k,
                      height: 43 * k,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10 * k),
                          gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [color.withOpacity(.95), color]),
                          boxShadow: [
                            BoxShadow(
                                color: color.withOpacity(.30),
                                blurRadius: 8 * k)
                          ]),
                      child: Text(app.$2,
                          maxLines: 1,
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: app.$2.length > 2 ? 12 * k : 23 * k,
                              fontWeight: FontWeight.w800,
                              letterSpacing: -.4)),
                    ),
                    SizedBox(height: 5 * k),
                    Padding(
                        padding: EdgeInsets.symmetric(horizontal: 2 * k),
                        child: FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Text(app.$1,
                                style: TextStyle(
                                    color: dark
                                        ? const Color(0xFFF4F5FF)
                                        : const Color(0xFF162649),
                                    fontSize: 10.7 * k,
                                    fontWeight: FontWeight.w600)))),
                  ]),
            ),
          );
        },
      );
}

class _AddFolderButton extends StatelessWidget {
  final double k;
  final VoidCallback onTap;
  const _AddFolderButton({required this.k, required this.onTap});
  @override
  Widget build(BuildContext context) => Container(
        width: 58 * k,
        height: 58 * k,
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Color(0xFF00C8E9),
                  Color(0xFF164DF2),
                  Color(0xFFE900D5)
                ]),
            border: Border.all(color: const Color(0xFF55E6FF), width: 1.1),
            boxShadow: const [
              BoxShadow(
                  color: Color(0x994B4DFF), blurRadius: 18, spreadRadius: 1)
            ]),
        child: Material(
            color: Colors.transparent,
            child: InkWell(
                onTap: onTap,
                customBorder: const CircleBorder(),
                child: Icon(Icons.add_rounded,
                    color: Colors.white, size: 34 * k))),
      );
}
