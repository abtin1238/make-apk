import 'dart:io';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:provider/provider.dart';
import '../core/l10n.dart';
import '../core/layouts.dart' show tr2;
import '../core/settings.dart';
import '../services/file_ops.dart';
import '../services/native.dart';
import '../services/player_service.dart';
import '../widgets/adaptive_nav.dart';
import '../widgets/abtin_global_rail.dart';
import '../widgets/layout_shell.dart';
import 'audio_player_screen.dart';
import 'apps_screen.dart';
import 'browser_screen.dart';
import 'home_screen.dart';
import 'more_screen.dart';
import 'opener.dart';
import 'path_list_screen.dart';
import 'trash_screen.dart';
import 'transfer_screen.dart';

class PermissionGate extends StatefulWidget {
  const PermissionGate({super.key});
  @override
  State<PermissionGate> createState() => _PermissionGateState();
}

class _PermissionGateState extends State<PermissionGate>
    with WidgetsBindingObserver {
  bool? ok;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _check();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _check();
  }

  Future<void> _check() async {
    final g = await Permission.manageExternalStorage.isGranted ||
        await Permission.storage.isGranted;
    if (mounted) setState(() => ok = g);
  }

  Future<void> _ask() async {
    var s = await Permission.manageExternalStorage.request();
    if (!s.isGranted) s = await Permission.storage.request();
    await Permission.notification.request();
    _check();
  }

  @override
  Widget build(BuildContext context) {
    if (ok == null)
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    if (ok!) return const Shell();
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.folder_open_rounded, size: 90),
            const SizedBox(height: 16),
            Text(L.t('permission'),
                style: Theme.of(context).textTheme.titleMedium,
                textAlign: TextAlign.center),
            const SizedBox(height: 24),
            FilledButton(onPressed: _ask, child: Text(L.t('grant'))),
          ]),
        ),
      ),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;

  @override
  void initState() {
    super.initState();
    AbtinGlobalNavigation.onNavigate = _navigateFromRail;
    AbtinGlobalNavigation.shellVisible.value = true;
    AbtinGlobalNavigation.rootRailVisible.value = true;
    AbtinGlobalNavigation.railVisible.value = true;
    AbtinGlobalNavigation.active.value = 'home';
    Native.incoming.addListener(_incoming);
    WidgetsBinding.instance.addPostFrameCallback((_) => _incoming());
  }

  @override
  void dispose() {
    AbtinGlobalNavigation.onNavigate = null;
    AbtinGlobalNavigation.shellVisible.value = false;
    Native.incoming.removeListener(_incoming);
    super.dispose();
  }

  void _selectTab(int index) {
    AbtinGlobalNavigation.setRootRailVisible(index == 0 || index == 1);
    AbtinGlobalNavigation.active.value = index == 1 ? 'favorites' : 'home';
    setState(() => tab = index);
  }

  void _navigateFromRail(String destination) {
    final nav = Navigator.of(context);
    nav.popUntil((route) => route.isFirst);
    if (!mounted) return;
    switch (destination) {
      case 'home':
        _selectTab(0);
        break;
      case 'favorites':
        _selectTab(1);
        break;
      case 'recents':
        nav.push(abtinPageRoute(
            (_) => PathListScreen(title: L.t('recents'), fav: false),
            showRail: true));
        break;
      case 'trash':
        nav.push(abtinPageRoute((_) => const TrashScreen(), showRail: true));
        break;
      case 'settings':
        nav.push(abtinPageRoute((_) => const MoreScreen(), showRail: true));
        break;
    }
  }

  Future<void> _incoming() async {
    final p = Native.incoming.value;
    if (p == null || !mounted) return;
    Native.incoming.value = null;
    Navigator.of(context).popUntil((r) => r.isFirst);
    if (Directory(p).existsSync()) {
      // folder intent (e.g. VIEW_DOWNLOADS)
      await Navigator.push(context,
          MaterialPageRoute(builder: (_) => BrowserScreen(initialPath: p)));
      return;
    }
    if (!File(p).existsSync()) return;
    await Opener.open(context, p);
  }

  @override
  Widget build(BuildContext context) {
    final pl = context.watch<PlayerService>();
    final layout = context.select<AppSettings, String>((s) => s.layoutId);
    final look = context.select<AppSettings, String>((s) => s.look);
    final abtin = look == 'abtin';
    // glass look (classic layout): Home / Recents / Starred / More; Files + Network stay reachable
    // from the home card ("See all") and from the More tab.
    final glass = look == 'glass' && layout == 'classic';
    return LayoutShell(
      layout: layout,
      selected: tab,
      onSelect: _selectTab,
      items: abtin
          ? [
              NavItem(Icons.folder_copy_rounded, tr2('فایل‌ها', 'Files')),
              NavItem(Icons.star_rounded, L.t('favorites')),
              NavItem(Icons.android_rounded, L.t('apps')),
              NavItem(Icons.wifi_tethering_rounded,
                  tr2('انتقال شبکه‌ای', 'Network transfer')),
            ]
          : glass
              ? [
                  NavItem(Icons.home_rounded, L.t('home')),
                  NavItem(Icons.folder_rounded, L.t('files')),
                  NavItem(Icons.schedule_rounded, tr2('اخیر', 'Recents')),
                  NavItem(
                      Icons.star_border_rounded, tr2('ستاره‌دار', 'Starred')),
                  NavItem(Icons.menu_rounded, L.t('more')),
                ]
              : [
                  NavItem(Icons.home_rounded, L.t('home')),
                  NavItem(Icons.folder_rounded, L.t('files')),
                  NavItem(Icons.swap_horiz_rounded, L.t('network')),
                  NavItem(Icons.more_horiz_rounded, L.t('more')),
                ],
      body: IndexedStack(
          index: tab,
          children: abtin
              ? [
                  HomeScreen(onOpenFiles: () => _selectTab(0)),
                  PathListScreen(title: L.t('favorites'), fav: true),
                  const AppsScreen(),
                  const TransferScreen(),
                ]
              : glass
                  ? [
                      HomeScreen(onOpenFiles: () => _selectTab(1)),
                      BrowserScreen(
                          initialPath: FileOps.root,
                          root: true,
                          active: tab == 1),
                      PathListScreen(title: L.t('recents'), fav: false),
                      PathListScreen(title: L.t('favorites'), fav: true),
                      const MoreScreen(),
                    ]
                  : [
                      HomeScreen(onOpenFiles: () => _selectTab(1)),
                      BrowserScreen(
                          initialPath: FileOps.root,
                          root: true,
                          active: tab == 1),
                      const TransferScreen(),
                      const MoreScreen(),
                    ]),
      bottom: pl.hasQueue
          ? Material(
              color: Theme.of(context).cardColor,
              child: ListTile(
                dense: true,
                onTap: () => Navigator.push(
                    context,
                    abtinPageRoute((_) => const AudioPlayerScreen(),
                        hideRail: true)),
                leading: pl.meta?.art != null
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: Image.memory(pl.meta!.art!,
                            width: 40,
                            height: 40,
                            fit: BoxFit.cover,
                            gaplessPlayback: true))
                    : const Icon(Icons.music_note_rounded),
                title: Text(pl.title,
                    maxLines: 1, overflow: TextOverflow.ellipsis),
                // mini-player buttons keep the same order in every language
                trailing: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(
                        icon: const Icon(Icons.skip_previous_rounded),
                        onPressed: pl.previous),
                    IconButton(
                        icon: Icon(pl.playing
                            ? Icons.pause_rounded
                            : Icons.play_arrow_rounded),
                        onPressed: pl.player.playOrPause),
                    IconButton(
                        icon: const Icon(Icons.skip_next_rounded),
                        onPressed: pl.next),
                    IconButton(
                        icon: const Icon(Icons.close_rounded),
                        onPressed: pl.stopAll),
                  ]),
                ),
              ),
            )
          : null,
    );
  }
}
