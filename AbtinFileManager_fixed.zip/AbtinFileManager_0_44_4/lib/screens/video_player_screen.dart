import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' show FontFeature;
import 'package:file_picker/file_picker.dart';
import '../widgets/ui.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../widgets/abtin_global_rail.dart';
import 'package:flutter/services.dart';
import 'package:media_kit/media_kit.dart';
import 'package:media_kit_video/media_kit_video.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import 'package:video_thumbnail/video_thumbnail.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../core/l10n.dart';
import '../core/player_theme.dart';
import '../core/settings.dart';
import '../services/cast_service.dart';
import '../services/media_store.dart';
import '../services/native.dart';
import '../services/player_service.dart';
import '../widgets/player_glass.dart';
import 'equalizer_screen.dart';
import 'video_tools.dart';
import 'viewer_delete.dart';

/// Full video player: gestures (seek / brightness / volume / double-tap / long-press 2x),
/// lock, rotate, aspect, PiP, subtitles (delay, size, colour, encoding), audio delay,
/// track picker, playlist, screenshot, resume position, network streams.
class VideoPlayerScreen extends StatefulWidget {
  final List<String> paths; // local paths or http(s)/rtsp URLs
  final int index;
  const VideoPlayerScreen(
      {super.key, required this.paths, required this.index});
  @override
  State<VideoPlayerScreen> createState() => _VideoPlayerScreenState();
}

class _VideoPlayerScreenState extends State<VideoPlayerScreen> {
  late final Player player = Player();
  late final VideoController controller = VideoController(player);
  int cur = 0;
  final PlayerTheme pt = PlayerTheme.I;
  String aspectKey =
      'auto'; // auto | 16:9 | 4:3 | 21:9 | 1:1 | 9:16 | 3:2 | full | stretch
  final Set<String> panels = {}; // open side panels: 'speed', 'aspect'
  double _bri = .5, _vol = .5; // side slider values 0..1
  String vCodec = '';
  bool hdr = false;
  int vFps = 0;
  double vBright = 0,
      vContrast = 0,
      vSat = 0,
      vGamma = 0,
      vHue = 0; // picture adjustments (-100..100)
  List<double> aEq = List.filled(10, 0.0);
  double aBass = 0;
  bool aEqOn = false;
  double rate = 1, subSize = 28, subDelay = 0, audioDelay = 0;
  Color subColor = Colors.white;
  String codepage = 'utf8:cp1256';
  bool visible = true,
      locked = false,
      muted = false,
      buffering = false,
      showRemain = false;
  int orient = 0; // 0 auto, 1 landscape, 2 portrait
  PlaylistMode loop = PlaylistMode.none;
  double? _drag;
  List<(Duration, String)> chapters = [];
  // pinch-zoom (two fingers) and two-finger pan
  double zoom = 1;
  Offset pan = Offset.zero;
  bool _pinch = false;
  final _ptr = <int, Offset>{};
  double _z0 = 1, _d0 = 1;
  Offset _p0 = Offset.zero, _m0 = Offset.zero;
  Duration? abA, abB; // A-B loop
  // seek preview (frame bubble while dragging the slider)
  Uint8List? _prev;
  Duration _prevT = Duration.zero;
  final _prevCache = <String, Uint8List>{};
  Timer? _prevTimer;
  int _prevReq = 0;
  static const _bucketMs = 2000;
  Timer? _sleepT;
  DateTime? _sleepAt;
  bool hwDec = true;
  Timer? _hideT, _hudT, _saveT;
  StreamSubscription? _s1, _s2, _s3, _s4, _s5, _s6;

  // HUD
  IconData? hudIcon;
  String hudText = '';
  double? hudValue;

  // gesture state
  Duration _hStart = Duration.zero;
  double _hAcc = 0, _vAcc = 0, _vBase = 0;
  bool _vLeft = true;
  bool _seeking = false;
  double _prevRate = 1;

  bool _isUrl(String s) =>
      RegExp(r'^[a-z]+://', caseSensitive: false).hasMatch(s);
  String get curPath => widget.paths[cur];
  String get curTitle => _isUrl(curPath)
      ? Uri.decodeFull(p.basename(Uri.parse(curPath).path)).isEmpty
          ? Uri.parse(curPath).host
          : Uri.decodeFull(p.basename(Uri.parse(curPath).path))
      : p.basename(curPath);

  @override
  void initState() {
    super.initState();
    cur = widget.index;
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    Native.keepOn(true);
    Native.brightness().then((v) {
      if (mounted) setState(() => _bri = v);
    });
    Native.sysVolume().then((v) {
      if (mounted) setState(() => _vol = v);
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted)
        context.read<PlayerService>().player.pause(); // stop background music
    });
    _s1 = player.stream.playlist.listen((pl) {
      if (mounted && pl.index != cur) {
        _saveNow();
        setState(() {
          cur = pl.index;
          abA = null;
          abB = null;
          _prev = null;
        });
        _onNewItem();
      }
    });
    _s2 = player.stream.buffering.listen((b) {
      if (mounted) setState(() => buffering = b);
    });
    _s3 = player.stream.error.listen((e) {
      if (mounted && e.isNotEmpty) _hud(Icons.error_outline_rounded, e);
    });
    _s4 = player.stream.height.listen((h) => _autoOrient());
    _s5 = player.stream.playing.listen((pl) {
      if (!mounted) return;
      Native.pipAuto(pl);
      if (pl) {
        _scheduleHide();
      } else {
        _hideT?.cancel();
        setState(() => visible = true);
      }
    });
    _s6 = player.stream.position.listen((pos) {
      final a = abA, b = abB;
      if (a != null && b != null && pos >= b) player.seek(a);
    });
    _startPlayback();
    _saveT = Timer.periodic(const Duration(seconds: 5), (_) => _saveNow());
    Native.inPip.addListener(_pipChanged);
    _onNewItem();
    _scheduleHide();
  }

  Future<void> _startPlayback() async {
    await _loadHw();
    await _prop('sub-codepage', codepage);
    if (!mounted) return;
    try {
      await player.open(
          Playlist(widget.paths.map((e) => Media(e)).toList(), index: cur));
    } catch (e) {
      if (mounted) _hud(Icons.error_outline_rounded, '$e');
    }
  }

  void _pipChanged() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _saveNow();
    for (final s in [_s1, _s2, _s3, _s4, _s5, _s6]) {
      s?.cancel();
    }
    _orientT?.cancel();
    _hideT?.cancel();
    _hudT?.cancel();
    _saveT?.cancel();
    _sleepT?.cancel();
    _prevTimer?.cancel();
    Native.inPip.removeListener(_pipChanged);
    Native.setBrightness(-1);
    Native.keepOn(false);
    Native.pipAuto(false);
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations([]);
    if (CastService.I.active != null) CastService.I.stop();
    player.dispose();
    super.dispose();
  }

  // ---------- helpers ----------
  Future<void> _prop(String k, String v) async {
    try {
      await (player.platform as dynamic).setProperty(k, v);
    } catch (_) {}
  }

  Future<void> _loadHw() async {
    try {
      final sp = await SharedPreferences.getInstance();
      hwDec = sp.getBool('video_hw') ?? true;
      if (!hwDec) await _prop('hwdec', 'no');
      if (mounted) setState(() {});
    } catch (_) {}
  }

  Future<void> _toggleHw() async {
    hwDec = !hwDec;
    await _prop('hwdec', hwDec ? 'auto-safe' : 'no');
    try {
      (await SharedPreferences.getInstance()).setBool('video_hw', hwDec);
    } catch (_) {}
    if (mounted) setState(() {});
    _hud(Icons.memory_rounded,
        '${L.t('hwDecoder')}: ${hwDec ? L.t('on') : L.t('off')}');
  }

  void _preview(double ms) {
    _prevT = Duration(milliseconds: ms.round());
    final b = (ms / _bucketMs).round();
    final path = curPath;
    final key = '$path|$b';
    final hit = _prevCache[key];
    if (hit != null) {
      _prev = hit;
      return;
    }
    final req = ++_prevReq;
    _prevTimer?.cancel();
    _prevTimer = Timer(const Duration(milliseconds: 120), () async {
      try {
        final d = await VideoThumbnail.thumbnailData(
            video: path,
            imageFormat: ImageFormat.JPEG,
            timeMs: b * _bucketMs,
            maxWidth: 320,
            quality: 60);
        if (d == null || d.isEmpty) return;
        if (_prevCache.length > 80) _prevCache.remove(_prevCache.keys.first);
        _prevCache[key] = d;
        if (mounted && req == _prevReq && _drag != null && path == curPath)
          setState(() => _prev = d);
      } catch (_) {}
    });
  }

  void _toggleAB() {
    final pos = player.state.position;
    if (abA == null) {
      setState(() => abA = pos);
      _hud(Icons.repeat_rounded, 'A  ${_fmt(pos)}');
    } else if (abB == null) {
      if (pos <= abA! + const Duration(milliseconds: 500)) return;
      setState(() => abB = pos);
      _hud(Icons.repeat_rounded, 'A-B  ${_fmt(abA!)} → ${_fmt(pos)}');
    } else {
      setState(() {
        abA = null;
        abB = null;
      });
      _hud(Icons.repeat_rounded, '${L.t('abLoop')}: ${L.t('off')}');
    }
  }

  Future<void> _step(bool fwd) async {
    try {
      await player.pause();
      await (player.platform as dynamic)
          .command([fwd ? 'frame-step' : 'frame-back-step']);
    } catch (_) {}
  }

  Future<void> _sleepMenu() async {
    final r = await showModalBottomSheet<int>(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          ListTile(
              title: Text(L.t('sleepTimer'),
                  style: const TextStyle(fontWeight: FontWeight.bold))),
          if (_sleepAt != null)
            ListTile(
                leading: const Icon(Icons.timer_off_rounded),
                title: Text(L.t('off')),
                onTap: () => Navigator.pop(context, -1)),
          for (final m in [15, 30, 45, 60, 90, 120])
            ListTile(
                leading: const Icon(Icons.bedtime_rounded),
                title: Text('$m ${L.t('minutes')}'),
                onTap: () => Navigator.pop(context, m)),
        ]),
      ),
    );
    if (r == null || !mounted) return;
    _sleepT?.cancel();
    if (r < 0) {
      setState(() => _sleepAt = null);
      _hud(Icons.timer_off_rounded, '${L.t('sleepTimer')}: ${L.t('off')}');
      return;
    }
    setState(() => _sleepAt = DateTime.now().add(Duration(minutes: r)));
    _sleepT = Timer(Duration(minutes: r), () {
      if (!mounted) return;
      player.pause();
      setState(() => _sleepAt = null);
    });
    _hud(Icons.bedtime_rounded, '$r ${L.t('minutes')}');
  }

  void _saveNow() {
    try {
      MediaStore.savePos(curPath, player.state.position, player.state.duration);
    } catch (_) {}
  }

  String _fmt(Duration d) {
    final h = d.inHours,
        m = d.inMinutes.remainder(60).toString().padLeft(2, '0'),
        s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  // brightness and volume have their own slider: only the one that is being changed is shown
  bool _briOn = false, _volOn = false;
  Timer? _slT;
  void _pokeSliders(bool bri) {
    if (_briOn != bri || _volOn == bri)
      setState(() {
        _briOn = bri;
        _volOn = !bri;
      });
    _slT?.cancel();
    _slT = Timer(const Duration(milliseconds: 1600), () {
      if (mounted)
        setState(() {
          _briOn = false;
          _volOn = false;
        });
    });
  }

  void _hud(IconData ic, String t, {double? v}) {
    if (v != null &&
        (ic == Icons.brightness_6_rounded ||
            ic == Icons.volume_up_rounded ||
            ic == Icons.volume_off_rounded)) {
      _pokeSliders(ic == Icons.brightness_6_rounded);
      return;
    }
    setState(() {
      hudIcon = ic;
      hudText = t;
      hudValue = v;
    });
    _hudT?.cancel();
    _hudT = Timer(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => hudIcon = null);
    });
  }

  void _scheduleHide() {
    _hideT?.cancel();
    if (!player.state.playing) return;
    _hideT = Timer(const Duration(seconds: 4), () {
      if (mounted && _drag == null && panels.isEmpty)
        setState(() => visible = false);
    });
  }

  void _toggleControls() {
    setState(() => visible = !visible);
    if (visible) _scheduleHide();
  }

  Timer? _orientT;
  int _orientFor = -1;
  void _autoOrient() {
    if (!mounted || orient != 0) return;
    _orientT?.cancel();
    _orientT = Timer(const Duration(milliseconds: 400), () {
      if (!mounted || orient != 0) return;
      final w = player.state.width ?? 0, h = player.state.height ?? 0;
      if (w == 0 || h == 0) return;
      final key = cur * 2 + (w >= h ? 1 : 0);
      if (key == _orientFor) return;
      _orientFor = key;
      SystemChrome.setPreferredOrientations(w >= h
          ? [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]
          : [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
    });
  }

  void _cycleOrient() {
    orient = (orient + 1) % 3;
    if (orient == 0) {
      SystemChrome.setPreferredOrientations(DeviceOrientation.values);
      _autoOrient();
    } else if (orient == 1) {
      SystemChrome.setPreferredOrientations(
          [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]);
    } else {
      SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    }
    _hud(Icons.screen_rotation_rounded,
        [L.t('auto'), L.t('landscape'), L.t('portrait')][orient]);
  }

  Future<void> _loadChapters() async {
    final path = curPath;
    if (mounted) setState(() => chapters = []);
    final out = <(Duration, String)>[];
    try {
      final np = player.platform as dynamic;
      await player.stream.duration
          .firstWhere((d) => d > Duration.zero)
          .timeout(const Duration(seconds: 10));
      final n =
          int.tryParse('${await np.getProperty('chapter-list/count')}') ?? 0;
      for (var i = 0; i < n; i++) {
        final t = double.tryParse(
                '${await np.getProperty('chapter-list/$i/time')}') ??
            0;
        final title = '${await np.getProperty('chapter-list/$i/title')}'.trim();
        out.add((
          Duration(milliseconds: (t * 1000).round()),
          title.isEmpty ? '${L.t('chapter')} ${i + 1}' : title
        ));
      }
    } catch (_) {}
    if (mounted && path == curPath) setState(() => chapters = out);
  }

  String? get _chapterNow {
    if (chapters.length < 2) return null;
    final pos = player.state.position;
    final i = chapters.lastIndexWhere((c) => c.$1 <= pos);
    return chapters[i < 0 ? 0 : i].$2;
  }

  // ---------- pinch zoom ----------
  void _ptrDown(PointerDownEvent e) {
    _ptr[e.pointer] = e.position;
    if (_ptr.length == 2) {
      final v = _ptr.values.toList();
      _pinch = true;
      _z0 = zoom;
      _p0 = pan;
      _d0 = math.max((v[0] - v[1]).distance, 1);
      _m0 = (v[0] + v[1]) / 2;
    }
  }

  void _ptrMove(PointerMoveEvent e, Size size) {
    if (!_ptr.containsKey(e.pointer)) return;
    _ptr[e.pointer] = e.position;
    if (_ptr.length != 2) return;
    final v = _ptr.values.toList();
    final z = (_z0 * (v[0] - v[1]).distance / _d0).clamp(1.0, 5.0).toDouble();
    final m = (v[0] + v[1]) / 2;
    final mx = (z - 1) * size.width / 2, my = (z - 1) * size.height / 2;
    setState(() {
      zoom = z;
      pan = Offset((_p0.dx + m.dx - _m0.dx).clamp(-mx, mx).toDouble(),
          (_p0.dy + m.dy - _m0.dy).clamp(-my, my).toDouble());
    });
  }

  void _ptrUp(PointerEvent e) {
    _ptr.remove(e.pointer);
    if (_ptr.isEmpty) _pinch = false;
  }

  Future<void> _onNewItem() async {
    _loadChapters();
    _loadInfo();
    // external subtitle next to the file
    if (!_isUrl(curPath)) {
      final base = p.withoutExtension(curPath);
      for (final e in ['srt', 'vtt', 'ass', 'ssa', 'sub']) {
        if (File('$base.$e').existsSync()) {
          await Future.delayed(const Duration(milliseconds: 600));
          if (mounted)
            await player.setSubtitleTrack(
                SubtitleTrack.uri('$base.$e', title: p.basename('$base.$e')));
          break;
        }
      }
    }
    // resume
    final st = MediaStore.state(curPath);
    if (st != null) {
      final path = curPath;
      try {
        await player.stream.duration
            .firstWhere((d) => d > Duration.zero)
            .timeout(const Duration(seconds: 8));
        if (mounted && path == curPath) {
          await player.seek(Duration(milliseconds: st[0]));
          _hud(Icons.history_rounded,
              '${L.t('resumed')} ${_fmt(Duration(milliseconds: st[0]))}');
        }
      } catch (_) {}
    }
    Native.pipAuto(true, _aspect);
  }

  double get _aspect {
    final w = player.state.width ?? 16, h = player.state.height ?? 9;
    return h == 0 ? 16 / 9 : w / h;
  }

  // ---------- gestures ----------
  void _doubleTap(Offset pos, double width) {
    if (locked || _pinch) return;
    if (zoom > 1.01) {
      setState(() {
        zoom = 1;
        pan = Offset.zero;
      });
      return;
    }
    if (pos.dx < width / 3) {
      _seekBy(-10);
    } else if (pos.dx > width * 2 / 3) {
      _seekBy(10);
    } else {
      player.playOrPause();
    }
  }

  void _seekBy(int s) {
    var t = player.state.position + Duration(seconds: s);
    final d = player.state.duration;
    if (t < Duration.zero) t = Duration.zero;
    if (d > Duration.zero && t > d) t = d;
    player.seek(t);
    _hud(s < 0 ? Icons.fast_rewind_rounded : Icons.fast_forward_rounded,
        '${s > 0 ? '+' : ''}$s s  ${_fmt(t)}');
  }

  // ---------- menus ----------
  void _tracks() {
    final t = player.state.tracks;
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(children: [
          ListTile(
              title: Text(L.t('subtitles'),
                  style: const TextStyle(fontWeight: FontWeight.bold))),
          ListTile(
              leading: const Icon(Icons.subtitles_off_rounded),
              title: Text(L.t('off')),
              onTap: () {
                player.setSubtitleTrack(SubtitleTrack.no());
                Navigator.pop(context);
              }),
          for (final s
              in t.subtitle.where((e) => e.id != 'auto' && e.id != 'no'))
            ListTile(
                leading: const Icon(Icons.subtitles_rounded),
                title: Text(s.title ?? s.language ?? s.id),
                onTap: () {
                  player.setSubtitleTrack(s);
                  Navigator.pop(context);
                }),
          ListTile(
            leading: const Icon(Icons.cloud_download_rounded),
            title: Text(L.t('subDownload')),
            onTap: () {
              Navigator.pop(context);
              showSubtitleSearch(this.context, player, curPath,
                  onInfo: (m) => _hud(Icons.subtitles_rounded, m));
            },
          ),
          ListTile(
            leading: const Icon(Icons.add_rounded),
            title: Text('${L.t('subtitles')}…'),
            onTap: () async {
              Navigator.pop(context);
              final r = await FilePicker.platform.pickFiles();
              final f = r?.files.single.path;
              if (f != null)
                await player.setSubtitleTrack(
                    SubtitleTrack.uri(f, title: p.basename(f)));
            },
          ),
          ListTile(
              title: Text(L.t('audioTrack'),
                  style: const TextStyle(fontWeight: FontWeight.bold))),
          for (final a in t.audio.where((e) => e.id != 'auto' && e.id != 'no'))
            ListTile(
                leading: const Icon(Icons.audiotrack_rounded),
                title: Text(a.title ?? a.language ?? a.id),
                onTap: () {
                  player.setAudioTrack(a);
                  Navigator.pop(context);
                }),
        ]),
      ),
    );
  }

  Future<void> _delayDialog(
      String title, double value, void Function(double) onSet) async {
    var v = value;
    await showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (c, set) => AlertDialog(
          title: Text('$title: ${v.toStringAsFixed(1)} s'),
          content: Row(children: [
            IconButton(
                icon: const Icon(Icons.remove_circle_outline_rounded),
                onPressed: () => set(() => v = ((v - .1) * 10).round() / 10)),
            Expanded(
                child: LSlider(
                    min: -10,
                    max: 10,
                    divisions: 200,
                    value: v.clamp(-10, 10).toDouble(),
                    onChanged: (x) => set(() => v = (x * 10).round() / 10))),
            IconButton(
                icon: const Icon(Icons.add_circle_outline_rounded),
                onPressed: () => set(() => v = ((v + .1) * 10).round() / 10)),
          ]),
          actions: [
            TextButton(
                onPressed: () => set(() => v = 0), child: Text(L.t('reset'))),
            FilledButton(
                onPressed: () {
                  onSet(v);
                  Navigator.pop(c);
                },
                child: Text(L.t('ok'))),
          ],
        ),
      ),
    );
  }

  void _subStyle() {
    showModalBottomSheet(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (c, set) => SafeArea(
          child: ListView(shrinkWrap: true, children: [
            ListTile(
                title: Text(L.t('subSize'),
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                subtitle: LSlider(
                    min: 14,
                    max: 60,
                    value: subSize,
                    onChanged: (v) {
                      set(() => subSize = v);
                      setState(() {});
                    })),
            ListTile(
              title: Text(L.t('color')),
              trailing: Wrap(spacing: 8, children: [
                for (final col in [
                  Colors.white,
                  Colors.yellow,
                  Colors.cyanAccent,
                  Colors.greenAccent
                ])
                  GestureDetector(
                      onTap: () {
                        set(() => subColor = col);
                        setState(() {});
                      },
                      child: CircleAvatar(
                          radius: 13,
                          backgroundColor: col,
                          child: subColor == col
                              ? const Icon(Icons.check,
                                  size: 16, color: Colors.black)
                              : null)),
              ]),
            ),
            ListTile(
              title: Text(L.t('subEnc')),
              trailing: DropdownButton<String>(
                value: codepage,
                underline: const SizedBox(),
                items: const [
                  DropdownMenuItem(
                      value: 'utf8:cp1256',
                      child: Text('UTF-8 / Arabic-Persian (1256)')),
                  DropdownMenuItem(value: 'utf8', child: Text('UTF-8')),
                  DropdownMenuItem(
                      value: 'utf8:cp1252', child: Text('Latin (1252)')),
                  DropdownMenuItem(
                      value: 'utf8:cp1251', child: Text('Cyrillic (1251)')),
                  DropdownMenuItem(
                      value: 'utf8:cp1254', child: Text('Turkish (1254)')),
                ],
                onChanged: (v) async {
                  set(() => codepage = v!);
                  await _prop('sub-codepage', v!);
                  // reload the current subtitle so the new encoding applies
                  final sub = player.state.track.subtitle;
                  if (sub.id != 'no' && sub.id != 'auto')
                    await player.setSubtitleTrack(sub);
                },
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Future<void> _screenshot() async {
    try {
      final bytes = await player.screenshot(format: 'image/png');
      if (bytes == null) return;
      final dir = Directory('/storage/emulated/0/Pictures/Abtin');
      await dir.create(recursive: true);
      final f = File(
          '${dir.path}/${p.basenameWithoutExtension(curTitle)}_${DateTime.now().millisecondsSinceEpoch}.png');
      await f.writeAsBytes(bytes);
      Native.scan(f.path);
      _hud(
          Icons.photo_camera_rounded, '${L.t('saved')}: ${p.basename(f.path)}');
    } catch (e) {
      _hud(Icons.error_outline_rounded, '$e');
    }
  }

  void _playlist() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => SizedBox(
        height: MediaQuery.of(context).size.height * .6,
        child: ListView.builder(
          itemCount: widget.paths.length,
          itemBuilder: (c, i) => ListTile(
            selected: i == cur,
            leading: Text('${i + 1}'),
            title: Text(Uri.decodeFull(p.basename(widget.paths[i])),
                maxLines: 1, overflow: TextOverflow.ellipsis),
            onTap: () {
              player.jump(i);
              Navigator.pop(c);
            },
          ),
        ),
      ),
    );
  }

  Future<void> _cast() async {
    final started = await showCastSheet(context, player, curPath, curTitle);
    if (started && mounted) {
      player.pause();
      setState(() {});
    }
  }

  Future<void> _stopCast() async {
    final pos = CastService.I.position;
    await CastService.I.stop();
    if (!mounted) return;
    if (pos > Duration.zero) await player.seek(pos);
    player.play();
    setState(() {});
  }

  Future<void> _enterPip() async {
    final ok = await Native.pip(_aspect);
    if (!ok && mounted)
      _hud(Icons.picture_in_picture_alt_rounded, L.t('pipNo'));
  }

  // ---------- theme / info ----------

  BoxFit get fit => aspectKey == 'full'
      ? BoxFit.cover
      : (aspectKey == 'auto' ? BoxFit.contain : BoxFit.fill);

  static const _ratios = <String, double>{
    '16:9': 16 / 9,
    '4:3': 4 / 3,
    '21:9': 21 / 9,
    '1:1': 1,
    '9:16': 9 / 16,
    '3:2': 3 / 2
  };
  static const _speeds = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0];
  static const _videoExt = {
    'mp4',
    'mkv',
    'avi',
    'mov',
    'wmv',
    'flv',
    'webm',
    'm4v',
    '3gp',
    'ts',
    'mpg',
    'mpeg',
    'vob',
    'ogv'
  };

  Future<String> _gp(String k) async {
    try {
      return '${await (player.platform as dynamic).getProperty(k)}';
    } catch (_) {
      return '';
    }
  }

  String _codecName(String raw) {
    final s = raw.toLowerCase();
    if (s.contains('hevc') || s.contains('h265') || s.contains('h.265'))
      return 'HEVC';
    if (s.contains('h264') || s.contains('h.264') || s.contains('avc'))
      return 'H.264';
    if (s.contains('av1')) return 'AV1';
    if (s.contains('vp9')) return 'VP9';
    if (s.contains('vp8')) return 'VP8';
    if (s.contains('mpeg2') || s.contains('mpeg-2')) return 'MPEG-2';
    if (s.contains('mpeg4') || s.contains('mpeg-4')) return 'MPEG-4';
    final w = s.trim().split(RegExp(r'[\s(/]')).first;
    return w.toUpperCase();
  }

  /// Reads codec / HDR / frame-rate from mpv once the file is open.
  Future<void> _loadInfo() async {
    final path = curPath;
    vCodec = '';
    hdr = false;
    vFps = 0;
    try {
      await player.stream.duration
          .firstWhere((d) => d > Duration.zero)
          .timeout(const Duration(seconds: 10));
    } catch (_) {
      return;
    }
    final codec = await _gp('video-codec');
    final gamma = (await _gp('video-params/gamma')).toLowerCase();
    var fps = double.tryParse(await _gp('container-fps')) ?? 0;
    if (fps <= 0) fps = double.tryParse(await _gp('estimated-vf-fps')) ?? 0;
    if (!mounted || path != curPath) return;
    setState(() {
      vCodec = codec.trim().isEmpty ? '' : _codecName(codec);
      hdr = gamma == 'pq' || gamma == 'hlg' || gamma.contains('st2084');
      vFps = fps.round();
    });
  }

  String? get _qLabel {
    final w = player.state.width ?? 0, h = player.state.height ?? 0;
    if (w <= 0 || h <= 0) return null;
    final big = math.max(w, h), small = math.min(w, h);
    if (big >= 7600) return '8K';
    if (big >= 3600) return '4K';
    if (big >= 2500) return '2K';
    if (big >= 1800) return '1080p';
    if (big >= 1200) return '720p';
    return '${small}p';
  }

  List<String> get _infoParts => [
        if (_qLabel != null) _qLabel!,
        if (hdr) 'HDR',
        if (vCodec.isNotEmpty) vCodec,
        if (vFps > 0) '$vFps FPS',
      ];

  // ---------- panels / sliders ----------
  void _togglePanel(String k) {
    final h = MediaQuery.of(context).size.height;
    setState(() {
      if (panels.contains(k)) {
        panels.remove(k);
      } else {
        if (h < 620) panels.clear();
        panels.add(k);
      }
    });
    _hideT?.cancel();
    if (panels.isEmpty) _scheduleHide();
  }

  void _setRate(double v) {
    rate = v;
    player.setRate(v);
    setState(() {});
  }

  void _setAspect(String k) {
    setState(() {
      aspectKey = k;
      zoom = 1;
      pan = Offset.zero;
    });
  }

  void _setBri(double v) {
    _hideT?.cancel();
    _pokeSliders(true);
    setState(() => _bri = v);
    Native.setBrightness(v);
  }

  void _setVol(double v) {
    _hideT?.cancel();
    _pokeSliders(false);
    setState(() {
      _vol = v;
      if (muted && v > 0) {
        muted = false;
        player.setVolume(100);
      }
    });
    Native.setSysVolume(v);
  }

  void _onTap() {
    if (locked) {
      setState(() => visible = !visible);
      if (visible)
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted && locked) setState(() => visible = false);
        });
      return;
    }
    if (panels.isNotEmpty) {
      setState(() => panels.clear());
      _scheduleHide();
      return;
    }
    _toggleControls();
  }

  void _toggleFav() {
    if (_isUrl(curPath)) {
      _hud(Icons.star_border_rounded, L.t('vpFavNo'));
      return;
    }
    final s = context.read<AppSettings>();
    s.toggleFav(curPath);
    setState(() {});
    _hud(s.isFav(curPath) ? Icons.star_rounded : Icons.star_border_rounded,
        s.isFav(curPath) ? L.t('vpFavOn') : L.t('vpFavOff'));
  }

  // ---------- sheets ----------
  Future<void> _darkSheet(Widget Function(BuildContext) b) =>
      showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        backgroundColor: const Color(0xF2101420),
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
        builder: (ctx) =>
            Theme(data: ThemeData.dark(useMaterial3: true), child: b(ctx)),
      );

  Widget _handle() => Center(
      child: Container(
          width: 40,
          height: 4,
          decoration: BoxDecoration(
              color: Colors.white24, borderRadius: BorderRadius.circular(2))));

  void _history() {
    final items = MediaStore.all.entries
        .toList()
        .reversed
        .where((e) =>
            _videoExt.contains(
                p.extension(e.key).replaceFirst('.', '').toLowerCase()) &&
            File(e.key).existsSync())
        .take(40)
        .toList();
    _darkSheet((c) => SafeArea(
          child: SizedBox(
            height: MediaQuery.of(c).size.height * .6,
            child: Column(children: [
              const SizedBox(height: 10),
              _handle(),
              ListTile(
                  leading: Icon(Icons.history_rounded, color: pt.highlight),
                  title: Text(L.t('vpHistory'),
                      style: const TextStyle(fontWeight: FontWeight.bold))),
              Expanded(
                child: items.isEmpty
                    ? Center(
                        child: Text(L.t('vpNoHistory'),
                            style: const TextStyle(color: Colors.white60)))
                    : ListView.builder(
                        itemCount: items.length,
                        itemBuilder: (_, i) {
                          final e = items[i];
                          final frac = e.value[1] <= 0
                              ? 0.0
                              : (e.value[0] / e.value[1])
                                  .clamp(0.0, 1.0)
                                  .toDouble();
                          return ListTile(
                            selected: e.key == curPath,
                            selectedColor: pt.highlight,
                            leading: const Icon(Icons.movie_rounded),
                            title: Text(p.basename(e.key),
                                maxLines: 1, overflow: TextOverflow.ellipsis),
                            subtitle: Padding(
                              padding: const EdgeInsets.only(top: 4),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                        '${_fmt(Duration(milliseconds: e.value[0]))} / ${_fmt(Duration(milliseconds: e.value[1]))}',
                                        style: const TextStyle(fontSize: 11.5)),
                                    const SizedBox(height: 4),
                                    LinearProgressIndicator(
                                        value: frac,
                                        minHeight: 3,
                                        color: pt.highlight,
                                        backgroundColor: Colors.white12),
                                  ]),
                            ),
                            onTap: () {
                              Navigator.pop(c);
                              final idx = widget.paths.indexOf(e.key);
                              if (idx >= 0) {
                                player.jump(idx);
                              } else {
                                Navigator.pushReplacement(
                                    context,
                                    abtinPageRoute(
                                        (_) => VideoPlayerScreen(
                                            paths: [e.key], index: 0),
                                        hideRail: true));
                              }
                            },
                          );
                        },
                      ),
              ),
            ]),
          ),
        ));
  }

  void _qualitySheet() {
    final tr = player.state.tracks.video
        .where((e) => e.id != 'auto' && e.id != 'no')
        .toList();
    if (tr.length < 2) {
      final w = player.state.width, h = player.state.height;
      _hud(Icons.high_quality_rounded,
          '${w ?? '?'}×${h ?? '?'}  •  ${_infoParts.join(' • ')}');
      return;
    }
    final curId = player.state.track.video.id;
    _darkSheet((c) => SafeArea(
          child: ListView(shrinkWrap: true, children: [
            const SizedBox(height: 10),
            _handle(),
            ListTile(
                leading: Icon(Icons.high_quality_rounded, color: pt.highlight),
                title: Text(L.t('vpTracks'),
                    style: const TextStyle(fontWeight: FontWeight.bold))),
            ListTile(
                leading: const Icon(Icons.auto_awesome_rounded),
                title: Text(L.t('auto')),
                selected: curId == 'auto',
                selectedColor: pt.highlight,
                onTap: () {
                  player.setVideoTrack(VideoTrack.auto());
                  Navigator.pop(c);
                }),
            for (final v in tr)
              ListTile(
                leading: const Icon(Icons.videocam_rounded),
                title: Text(v.title ?? v.language ?? v.id),
                selected: v.id == curId,
                selectedColor: pt.highlight,
                onTap: () {
                  player.setVideoTrack(v);
                  Navigator.pop(c);
                },
              ),
          ]),
        ));
  }

  Future<void> _applyAf() async {
    final f = <String>[];
    if (aEqOn) {
      if (aBass != 0) f.add('bass=g=${aBass.toStringAsFixed(1)}');
      for (var i = 0; i < 10; i++) {
        if (aEq[i] != 0)
          f.add(
              'equalizer=f=${PlayerService.eqFreqs[i]}:t=o:w=1:g=${aEq[i].toStringAsFixed(1)}');
      }
    }
    await _prop('af', f.isEmpty ? '' : 'lavfi=[${f.join(',')}]');
  }

  /// Picture adjustments (mpv brightness / contrast / saturation / gamma / hue) and a 10-band audio equalizer.
  void _eqSheet() {
    var tab = 0;
    _darkSheet((c) => StatefulBuilder(builder: (c, set) {
          Widget pic(String label, double v, String prop,
                  void Function(double) save) =>
              Column(children: [
                Row(children: [
                  Expanded(child: Text(label)),
                  Text('${v.round()}',
                      style: TextStyle(
                          color: pt.highlight, fontWeight: FontWeight.w700))
                ]),
                LSlider(
                    min: -100,
                    max: 100,
                    value: v.clamp(-100, 100).toDouble(),
                    activeColor: pt.highlight,
                    onChanged: (x) {
                      set(() => save(x));
                      _prop(prop, x.round().toString());
                    }),
              ]);
          return SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
              child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _handle(),
                    const SizedBox(height: 12),
                    Row(children: [
                      ChoiceChip(
                          label: Text(L.t('vpPicture')),
                          selected: tab == 0,
                          selectedColor: pt.accent.withOpacity(.5),
                          onSelected: (_) => set(() => tab = 0)),
                      const SizedBox(width: 8),
                      ChoiceChip(
                          label: Text(L.t('vpSound')),
                          selected: tab == 1,
                          selectedColor: pt.accent.withOpacity(.5),
                          onSelected: (_) => set(() => tab = 1)),
                      const Spacer(),
                      if (tab == 1)
                        Switch(
                            value: aEqOn,
                            activeColor: pt.highlight,
                            onChanged: (v) {
                              set(() => aEqOn = v);
                              _applyAf();
                            }),
                    ]),
                    const SizedBox(height: 8),
                    if (tab == 0) ...[
                      pic(L.t('brightness'), vBright, 'brightness',
                          (x) => vBright = x),
                      pic(L.t('vpContrast'), vContrast, 'contrast',
                          (x) => vContrast = x),
                      pic(L.t('vpSaturation'), vSat, 'saturation',
                          (x) => vSat = x),
                      pic(L.t('vpGamma'), vGamma, 'gamma', (x) => vGamma = x),
                      pic(L.t('vpHue'), vHue, 'hue', (x) => vHue = x),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          icon: const Icon(Icons.restart_alt_rounded),
                          label: Text(L.t('reset')),
                          onPressed: () {
                            set(() {
                              vBright = vContrast = vSat = vGamma = vHue = 0;
                            });
                            for (final k in const [
                              'brightness',
                              'contrast',
                              'saturation',
                              'gamma',
                              'hue'
                            ]) {
                              _prop(k, '0');
                            }
                          },
                        ),
                      ),
                    ] else ...[
                      Wrap(spacing: 8, children: [
                        for (final e in EqualizerScreen.presets.entries)
                          ActionChip(
                              label: Text(e.key),
                              onPressed: () {
                                set(() {
                                  aEq = List.of(e.value);
                                  aEqOn = true;
                                });
                                _applyAf();
                              }),
                      ]),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 170,
                        child: Directionality(
                          textDirection: TextDirection.ltr,
                          child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                for (var i = 0; i < 10; i++)
                                  Column(children: [
                                    Expanded(
                                      child: RotatedBox(
                                        quarterTurns: 3,
                                        child: LSlider(
                                            min: -12,
                                            max: 12,
                                            value: aEq[i],
                                            activeColor: pt.highlight,
                                            onChanged: (v) => set(() {
                                                  aEq[i] = v;
                                                  aEqOn = true;
                                                }),
                                            onChangeEnd: (_) => _applyAf()),
                                      ),
                                    ),
                                    Text(
                                        PlayerService.eqFreqs[i] >= 1000
                                            ? '${PlayerService.eqFreqs[i] ~/ 1000}k'
                                            : '${PlayerService.eqFreqs[i]}',
                                        style: const TextStyle(fontSize: 10)),
                                  ]),
                              ]),
                        ),
                      ),
                      Text(L.t('vpBass')),
                      LSlider(
                          min: 0,
                          max: 15,
                          value: aBass,
                          activeColor: pt.highlight,
                          onChanged: (v) => set(() {
                                aBass = v;
                                aEqOn = true;
                              }),
                          onChangeEnd: (_) => _applyAf()),
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton.icon(
                          icon: const Icon(Icons.restart_alt_rounded),
                          label: Text(L.t('reset')),
                          onPressed: () {
                            set(() {
                              aEq = List.filled(10, 0.0);
                              aBass = 0;
                            });
                            _applyAf();
                          },
                        ),
                      ),
                    ],
                  ]),
            ),
          );
        }));
  }

  /// Extra tools (A-B loop, sleep timer, delays, screenshot, ...).
  Future<void> _deleteCurrent() async {
    final path = curPath;
    // release the file before deleting it (some phones refuse to delete a file that is still open)
    final wasPlaying = player.state.playing;
    await player.pause();
    if (!mounted) return;
    final ok = await deleteFromViewer(context, path);
    if (!mounted) return;
    if (ok) {
      Navigator.pop(context);
    } else if (wasPlaying) {
      player.play();
    }
  }

  void _moreSheet() {
    final pc = pt.highlight;
    _darkSheet((ctx) {
      Widget tile(IconData i, String t, VoidCallback f, {bool on = false}) =>
          InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () {
              Navigator.pop(ctx);
              f();
            },
            child: Container(
              width: 96,
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
              decoration: BoxDecoration(
                color: on ? pt.accent.withOpacity(.25) : Colors.white10,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: on ? pc : Colors.white12),
              ),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Icon(i, color: on ? pc : Colors.white, size: 24),
                const SizedBox(height: 6),
                Text(t,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 11.5)),
              ]),
            ),
          );
      return SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
          child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _handle(),
                const SizedBox(height: 14),
                Wrap(spacing: 10, runSpacing: 10, children: [
                  tile(
                      Icons.subtitles_rounded,
                      L.t('subDelay'),
                      () => _delayDialog(L.t('subDelay'), subDelay, (x) {
                            subDelay = x;
                            _prop('sub-delay', x.toString());
                          })),
                  tile(
                      Icons.music_note_rounded,
                      L.t('audioDelay'),
                      () => _delayDialog(L.t('audioDelay'), audioDelay, (x) {
                            audioDelay = x;
                            _prop('audio-delay', x.toString());
                          })),
                  tile(Icons.format_size_rounded, L.t('subStyle'), _subStyle),
                  tile(
                      loop == PlaylistMode.single
                          ? Icons.repeat_one_rounded
                          : Icons.repeat_rounded,
                      L.t('loop'),
                      _cycleLoop,
                      on: loop != PlaylistMode.none),
                  tile(Icons.compare_arrows_rounded, L.t('abLoop'), _toggleAB,
                      on: abA != null),
                  tile(Icons.bedtime_rounded, L.t('sleepTimer'), _sleepMenu,
                      on: _sleepAt != null),
                  tile(Icons.memory_rounded, L.t('hwDecoder'), _toggleHw,
                      on: hwDec),
                  tile(
                      muted
                          ? Icons.volume_off_rounded
                          : Icons.volume_up_rounded,
                      muted ? L.t('unmute') : L.t('mute'),
                      _toggleMute,
                      on: muted),
                  tile(Icons.photo_camera_rounded, L.t('screenshot'),
                      _screenshot),
                  tile(Icons.screen_rotation_rounded, L.t('rotate'),
                      _cycleOrient),
                  if (chapters.length > 1)
                    tile(Icons.bookmarks_rounded, L.t('chapters'),
                        () => showChapters(context, player, chapters)),
                  tile(Icons.keyboard_arrow_left_rounded, L.t('framePrev'),
                      () => _step(false)),
                  tile(Icons.keyboard_arrow_right_rounded, L.t('frameNext'),
                      () => _step(true)),
                  if (!_isUrl(curPath))
                    tile(Icons.delete_outline_rounded, L.t('delete'),
                        _deleteCurrent),
                  tile(Icons.brightness_auto_rounded, L.t('vpResetBrightness'),
                      () {
                    Native.setBrightness(-1);
                    Native.brightness().then((v) {
                      if (mounted) setState(() => _bri = v);
                    });
                  }),
                ]),
              ]),
        ),
      );
    });
  }

  // ---------- UI ----------
  /// Player controls are ALWAYS left-to-right (Persian and English), so the seek bar and buttons never flip.
  Widget _ltr(Widget w) => Directionality(
        textDirection: TextDirection.ltr,
        child: DefaultTextStyle.merge(
          style: const TextStyle(color: Colors.white),
          child: IconTheme.merge(
              data: const IconThemeData(color: Colors.white), child: w),
        ),
      );

  String _rt(double r) =>
      r == r.roundToDouble() ? r.toInt().toString() : r.toString();

  void _cycleLoop() {
    loop = loop == PlaylistMode.none
        ? PlaylistMode.single
        : loop == PlaylistMode.single
            ? PlaylistMode.loop
            : PlaylistMode.none;
    player.setPlaylistMode(loop);
    _hud(
        loop == PlaylistMode.single
            ? Icons.repeat_one_rounded
            : Icons.repeat_rounded,
        loop == PlaylistMode.none
            ? L.t('off')
            : loop == PlaylistMode.single
                ? '1'
                : L.t('all'));
  }

  void _toggleMute() {
    setState(() => muted = !muted);
    player.setVolume(muted ? 0 : 100);
    _hud(muted ? Icons.volume_off_rounded : Icons.volume_up_rounded,
        muted ? L.t('mute') : L.t('unmute'));
  }

  Widget _topBar(double w) {
    final tiny = w < 420;
    final ic = tiny ? 22.0 : 24.0, ip = tiny ? 8.0 : 10.0;
    return Container(
      decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xB3000000), Colors.transparent])),
      padding: const EdgeInsets.fromLTRB(12, 6, 12, 22),
      child: SafeArea(
        bottom: false,
        child: Row(children: [
          GlassBtn(pt, Icons.arrow_back_rounded, () => Navigator.pop(context),
              radius: 22),
          const Spacer(),
          GlassBar(t: pt, children: [
            BareIcon(
                pt, Icons.aspect_ratio_rounded, () => _togglePanel('aspect'),
                on: panels.contains('aspect'), size: ic, pad: ip),
            BareIcon(pt, Icons.closed_caption_rounded, _tracks,
                size: ic, pad: ip),
            BareIcon(
                pt,
                Icons.lock_rounded,
                () => setState(() {
                      locked = true;
                      visible = false;
                      panels.clear();
                    }),
                size: ic,
                pad: ip),
            BareIcon(pt, Icons.more_vert_rounded, _moreSheet,
                size: ic, pad: ip),
          ]),
        ]),
      ),
    );
  }

  Widget _sideSliders(EdgeInsets pad, double w, double bh) {
    final sw = MediaQuery.of(context).orientation == Orientation.portrait
        ? 62.0
        : (w < 500 ? 46.0 : 56.0);
    final land = MediaQuery.of(context).orientation == Orientation.landscape;
    final sh = MediaQuery.of(context).size.height;
    // landscape: almost the whole screen height; portrait: above the controls
    final topGap = (land ? 36.0 : 84.0) + pad.top;
    final botGap = (land ? 20.0 : bh + 8) + pad.bottom;
    final maxH =
        math.max(150.0, math.min(land ? 700.0 : 380.0, sh - topGap - botGap));
    final brightness = VertSlider(
      t: pt,
      icon: Icons.wb_sunny_outlined,
      value: _bri,
      c1: pt.highlight,
      c2: pt.accent,
      width: sw,
      onChanged: _setBri,
      onEnd: _scheduleHide,
      onIconTap: () {
        Native.setBrightness(-1);
        Native.brightness().then((v) {
          if (mounted) setState(() => _bri = v);
        });
      },
    );
    final volume = VertSlider(
      t: pt,
      icon: (muted || _vol == 0)
          ? Icons.volume_off_rounded
          : Icons.volume_up_rounded,
      value: _vol,
      c1: Color.lerp(pt.accent2, Colors.white, .35)!,
      c2: pt.accent2,
      width: sw,
      onChanged: _setVol,
      onEnd: _scheduleHide,
      onIconTap: _toggleMute,
    );

    // Keep brightness on the left edge and system volume on the right edge.
    // This mirrors the gesture zones: left half = brightness, right half = volume.
    return Stack(
      children: [
        Positioned(
          left: 12 + pad.left,
          top: topGap,
          bottom: botGap,
          child: Center(
            child: SizedBox(
              height: maxH,
              child: _briOn ? brightness : const SizedBox.shrink(),
            ),
          ),
        ),
        Positioned(
          right: 12 + pad.right,
          top: topGap,
          bottom: botGap,
          child: Center(
            child: SizedBox(
              height: maxH,
              child: _volOn ? volume : const SizedBox.shrink(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _panelHost(EdgeInsets pad, double w, double bh) {
    final pw = math.min(300.0, math.max(w - 170, 210.0));
    final items = <Widget>[];
    if (panels.contains('speed')) {
      final sel =
          _speeds.firstWhere((e) => (e - rate).abs() < .01, orElse: () => rate);
      items.add(GlassPanel(
        t: pt,
        icon: Icons.speed_rounded,
        title: L.t('vpPlaySpeed'),
        width: pw,
        child: ChoiceGrid<double>(
            t: pt,
            items: [for (final v in _speeds) ('${_rt(v)}×', v)],
            selected: sel,
            onPick: _setRate),
      ));
    }
    if (panels.contains('aspect')) {
      if (items.isNotEmpty) items.add(const SizedBox(height: 10));
      final list = <(String, String)>[
        (L.t('auto'), 'auto'),
        ('16:9', '16:9'),
        ('4:3', '4:3'),
        ('21:9', '21:9'),
        ('1:1', '1:1'),
        ('9:16', '9:16'),
        ('3:2', '3:2'),
        (L.t('vpFullScreen'), 'full'),
        (L.t('vpStretch'), 'stretch'),
      ];
      items.add(GlassPanel(
          t: pt,
          icon: Icons.crop_free_rounded,
          title: L.t('vpAspect'),
          width: pw,
          child: ChoiceGrid<String>(
              t: pt, items: list, selected: aspectKey, onPick: _setAspect)));
    }
    return Padding(
      padding: EdgeInsets.fromLTRB(
          0, 76 + pad.top, 12 + pad.right, math.max(bh - 24, 0) + pad.bottom),
      child: Align(
        alignment: Alignment.centerRight,
        child: SingleChildScrollView(
            child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: items)),
      ),
    );
  }

  Widget _seekRow(bool compact) => StreamBuilder<Duration>(
        stream: player.stream.position,
        builder: (_, snap) {
          final pos = snap.data ?? player.state.position;
          final dur = player.state.duration;
          final maxMs = math.max(dur.inMilliseconds, 1).toDouble();
          final curMs = (_drag ?? pos.inMilliseconds.toDouble())
              .clamp(0, maxMs)
              .toDouble();
          final buf = (player.state.buffer.inMilliseconds / maxMs)
              .clamp(0.0, 1.0)
              .toDouble();
          return Column(mainAxisSize: MainAxisSize.min, children: [
            Row(children: [
              Expanded(
                child: NeonSeek(
                  t: pt,
                  value: curMs / maxMs,
                  buffered: buf,
                  ticks: chapters.length > 1 && dur > Duration.zero
                      ? [
                          for (final c in chapters.skip(1))
                            c.$1.inMilliseconds / dur.inMilliseconds
                        ]
                      : const [],
                  active: _drag != null,
                  onStart: () => _hideT?.cancel(),
                  onChanged: (f) => setState(() {
                    _drag = f * maxMs;
                    _preview(_drag!);
                  }),
                  onEnd: () {
                    final x = _drag;
                    if (x != null)
                      player.seek(Duration(milliseconds: x.round()));
                    setState(() {
                      _drag = null;
                      _prev = null;
                    });
                    _scheduleHide();
                  },
                ),
              ),
              BareIcon(pt, Icons.fullscreen_rounded, _cycleOrient,
                  size: compact ? 24 : 28, pad: 6, tip: L.t('rotate')),
            ]),
          ]);
        },
      );

  Widget _controlsRow(bool compact, bool short, bool narrow) {
    final portrait = MediaQuery.of(context).orientation == Orientation.portrait;
    final ic = portrait ? 25.0 : (compact ? 20.0 : 22.0);
    Widget btn(IconData i, VoidCallback f, {bool on = false}) =>
        GlassBtn(pt, i, f, on: on, size: ic, radius: portrait ? 25 : 22);
    final multi = widget.paths.length > 1;
    Widget skip(IconData i, VoidCallback? f) => GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: f,
          child: Padding(
            padding: EdgeInsets.all(portrait ? 10 : (compact ? 8 : 12)),
            child: Icon(i,
                size: portrait ? 36 : (compact ? 32 : 38),
                color: f == null ? Colors.white30 : Colors.white,
                shadows: f != null && pt.glow > 0
                    ? [
                        Shadow(
                            color: pt.highlight.withOpacity(.8 * pt.glow),
                            blurRadius: 14)
                      ]
                    : null),
          ),
        );
    final castOn = CastService.I.active != null;
    final fav = !_isUrl(curPath) && context.read<AppSettings>().isFav(curPath);
    final play = StreamBuilder<bool>(
      stream: player.stream.playing,
      builder: (_, s) => NeonPlay(
          t: pt,
          playing: s.data ?? player.state.playing,
          buffering: buffering,
          onTap: player.playOrPause,
          size: portrait ? 78 : (short || compact ? 62 : 84)),
    );

    if (portrait) {
      // Portrait (compact): left half = utility buttons in two rows, right half = back / play / next.
      Widget sb(IconData i, VoidCallback f, {bool on = false}) =>
          GlassBtn(pt, i, f, on: on, size: 17, radius: 17);
      final left = <Widget>[
        sb(Icons.queue_music_rounded, _playlist),
        sb(Icons.history_rounded, _history),
        sb(Icons.picture_in_picture_alt_rounded, _enterPip),
        sb(Icons.speed_rounded, () => _togglePanel('speed'),
            on: panels.contains('speed')),
        sb(Icons.graphic_eq_rounded, _eqSheet),
        sb(Icons.signal_cellular_alt_rounded, _qualitySheet),
        sb(castOn ? Icons.cast_connected_rounded : Icons.cast_rounded, _cast,
            on: castOn),
        sb(fav ? Icons.star_rounded : Icons.star_border_rounded, _toggleFav,
            on: fav),
      ];
      Widget bigSkip(IconData i, VoidCallback? f) => Opacity(
            opacity: f == null ? .35 : 1,
            child: GlassBtn(pt, i, f, size: 24, radius: 21),
          );
      return Directionality(
        textDirection: TextDirection.ltr,
        child: Row(children: [
          Expanded(
            child: Center(
              child: Wrap(
                  spacing: 5,
                  runSpacing: 5,
                  alignment: WrapAlignment.center,
                  children: left),
            ),
          ),
          Container(
              width: 1,
              height: 56,
              margin: const EdgeInsets.symmetric(horizontal: 5),
              color: Colors.white.withOpacity(.12)),
          Expanded(
            child: Center(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  bigSkip(Icons.skip_previous_rounded,
                      multi ? player.previous : null),
                  const SizedBox(width: 8),
                  StreamBuilder<bool>(
                    stream: player.stream.playing,
                    builder: (_, s) => NeonPlay(
                        t: pt,
                        playing: s.data ?? player.state.playing,
                        buffering: buffering,
                        onTap: player.playOrPause,
                        size: 64),
                  ),
                  const SizedBox(width: 8),
                  bigSkip(Icons.skip_next_rounded, multi ? player.next : null),
                ]),
              ),
            ),
          ),
        ]),
      );
    }

    const gap = SizedBox(width: 8);
    return FittedBox(
      fit: BoxFit.scaleDown,
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        btn(Icons.queue_music_rounded, _playlist),
        gap,
        btn(Icons.history_rounded, _history),
        gap,
        btn(Icons.picture_in_picture_alt_rounded, _enterPip),
        gap,
        btn(Icons.speed_rounded, () => _togglePanel('speed'),
            on: panels.contains('speed')),
        gap,
        skip(Icons.skip_previous_rounded, multi ? player.previous : null),
        play,
        skip(Icons.skip_next_rounded, multi ? player.next : null),
        gap,
        btn(Icons.graphic_eq_rounded, _eqSheet),
        gap,
        btn(Icons.signal_cellular_alt_rounded, _qualitySheet),
        gap,
        btn(castOn ? Icons.cast_connected_rounded : Icons.cast_rounded, _cast,
            on: castOn),
        gap,
        btn(fav ? Icons.star_rounded : Icons.star_border_rounded, _toggleFav,
            on: fav),
      ]),
    );
  }

  Widget _bottomBar(double w, double h) {
    final compact = w < 640, short = h < 480, narrow = w < 520;
    final portrait = h > w;
    return Container(
      decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.bottomCenter,
              end: Alignment.topCenter,
              colors: [
            Color(0xE6000000),
            Color(0x66000000),
            Colors.transparent
          ])),
      padding: EdgeInsets.fromLTRB(
          portrait ? 18 : 14,
          short ? 16 : (portrait ? 18 : 30),
          portrait ? 18 : 14,
          portrait ? 12 : 8),
      child: SafeArea(
        top: false,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          _seekRow(compact),
          SizedBox(height: short ? 0 : 4),
          _controlsRow(compact, short, narrow),
        ]),
      ),
    );
  }

  Widget _mini() => StreamBuilder<Duration>(
        stream: player.stream.position,
        builder: (_, s) {
          final d = player.state.duration.inMilliseconds;
          final v = d <= 0
              ? 0.0
              : ((s.data ?? player.state.position).inMilliseconds / d)
                  .clamp(0.0, 1.0)
                  .toDouble();
          return Align(
            alignment: Alignment.bottomLeft,
            child: FractionallySizedBox(
              widthFactor: v,
              child: Container(
                height: 3,
                decoration: BoxDecoration(
                    gradient: pt.seekGradient,
                    boxShadow: pt.glow > 0
                        ? [
                            BoxShadow(
                                color: pt.highlight.withOpacity(.7 * pt.glow),
                                blurRadius: 8)
                          ]
                        : null),
              ),
            ),
          );
        },
      );

  Widget _hudW() {
    if (hudIcon == null) return const SizedBox.shrink();
    return Center(
      child: Glass(
        t: pt,
        radius: 24,
        glowing: true,
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 16),
        child: ConstrainedBox(
          constraints: const BoxConstraints(minWidth: 112, maxWidth: 300),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(hudIcon, size: 36, color: pt.highlight),
            const SizedBox(height: 6),
            Text(hudText,
                textAlign: TextAlign.center,
                style:
                    const TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            if (hudValue != null)
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: SizedBox(
                      width: 124,
                      height: 5,
                      child: LinearProgressIndicator(
                          value: hudValue!.clamp(0, 1).toDouble(),
                          backgroundColor: Colors.white24,
                          valueColor:
                              AlwaysStoppedAnimation<Color>(pt.highlight))),
                ),
              ),
          ]),
        ),
      ),
    );
  }

  Widget _previewW(double bh) {
    final dur = player.state.duration;
    final x = _drag;
    if (x == null || _prev == null || dur <= Duration.zero)
      return const SizedBox.shrink();
    final f = (x / dur.inMilliseconds).clamp(0.0, 1.0).toDouble();
    return Positioned(
      left: 64,
      right: 64,
      bottom: bh + MediaQuery.of(context).padding.bottom - 20,
      child: IgnorePointer(
        child: _ltr(
          Align(
            alignment: Alignment(f * 2 - 1, 0),
            child: Glass(
              t: pt,
              radius: 16,
              glowing: true,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: SizedBox(
                  width: 176,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Image.memory(_prev!,
                        width: 176, fit: BoxFit.cover, gaplessPlayback: true),
                    Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Text(_fmt(_prevT),
                            style: const TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w700))),
                  ]),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _videoW() {
    final v = Video(
      controller: controller,
      fit: fit,
      controls: NoVideoControls,
      subtitleViewConfiguration: SubtitleViewConfiguration(
        style: TextStyle(
            height: 1.35,
            fontSize: subSize,
            color: subColor,
            fontWeight: FontWeight.w500,
            backgroundColor: const Color(0x99000000)),
        textAlign: TextAlign.center,
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 56),
      ),
    );
    final r = _ratios[aspectKey];
    return r == null ? v : Center(child: AspectRatio(aspectRatio: r, child: v));
  }

  @override
  Widget build(BuildContext context) {
    final pip = Native.inPip.value;
    final pad = MediaQuery.of(context).padding;
    return PopScope(
      canPop: !locked,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: LayoutBuilder(builder: (context, cons) {
          final w = cons.maxWidth, h = cons.maxHeight;
          final portrait = h > w;
          final bh = portrait
              ? 330.0
              : (w < 520
                  ? 276.0
                  : (h < 480 ? 190.0 : 218.0)); // bottom control block
          final ui = !pip && visible && !locked;
          Offset tapPos = Offset.zero;
          return Listener(
            behavior: HitTestBehavior.translucent,
            onPointerDown: _ptrDown,
            onPointerMove: (e) => _ptrMove(e, Size(w, h)),
            onPointerUp: _ptrUp,
            onPointerCancel: _ptrUp,
            child: Stack(fit: StackFit.expand, children: [
              ClipRect(
                child: Transform(
                  alignment: Alignment.center,
                  transform: Matrix4.translationValues(pan.dx, pan.dy, 0)
                    ..scale(zoom, zoom, 1),
                  child: _videoW(),
                ),
              ),
              if (!pip)
                GestureDetector(
                  behavior: HitTestBehavior.translucent,
                  onTap: _onTap,
                  onDoubleTapDown: (d) => tapPos = d.localPosition,
                  onDoubleTap: () => _doubleTap(tapPos, w),
                  onLongPressStart: (_) {
                    if (locked || _pinch) return;
                    _prevRate = rate;
                    player.setRate(2);
                    _hud(Icons.fast_forward_rounded, '2×');
                  },
                  onLongPressEnd: (_) {
                    if (locked) return;
                    player.setRate(_prevRate);
                  },
                  onHorizontalDragStart: (_) {
                    if (locked || _pinch) return;
                    _hStart = player.state.position;
                    _hAcc = 0;
                    _seeking = true;
                  },
                  onHorizontalDragUpdate: (d) {
                    if (locked || _pinch || !_seeking) return;
                    _hAcc += d.delta.dx;
                    final dur = player.state.duration;
                    var t =
                        _hStart + Duration(seconds: (_hAcc / w * 120).round());
                    if (t < Duration.zero) t = Duration.zero;
                    if (dur > Duration.zero && t > dur) t = dur;
                    final diff = t - _hStart;
                    _hud(
                        diff.isNegative
                            ? Icons.fast_rewind_rounded
                            : Icons.fast_forward_rounded,
                        '${_fmt(t)}  (${diff.inSeconds >= 0 ? '+' : ''}${diff.inSeconds}s)');
                    _hStart2 = t;
                  },
                  onHorizontalDragEnd: (_) {
                    if (locked || !_seeking) return;
                    _seeking = false;
                    if (_hStart2 != null) player.seek(_hStart2!);
                    _hStart2 = null;
                  },
                  onVerticalDragStart: (d) {
                    if (locked || _pinch) return;
                    _vLeft = d.localPosition.dx < w / 2;
                    _vAcc = 0;
                    _vBase = _vLeft
                        ? _bri
                        : _vol; // synchronous: updates can arrive right away
                    _pokeSliders(_vLeft);
                  },
                  onVerticalDragUpdate: (d) {
                    if (locked || _pinch) return;
                    _vAcc -= d.delta.dy / h * 1.3;
                    final v = (_vBase + _vAcc).clamp(0.0, 1.0).toDouble();
                    // setState so the slider follows the finger while dragging
                    setState(() {
                      if (_vLeft) {
                        _bri = v;
                      } else {
                        _vol = v;
                      }
                    });
                    if (_vLeft) {
                      Native.setBrightness(v);
                    } else {
                      Native.setSysVolume(v);
                    }
                    _pokeSliders(_vLeft);
                  },
                ),
              if (buffering && !pip && !ui)
                Center(child: CircularProgressIndicator(color: pt.highlight)),
              if (!pip) IgnorePointer(child: _ltr(_hudW())),
              if (!pip && !visible && !locked)
                Positioned(
                    left: 0,
                    right: 0,
                    bottom: 0,
                    child: IgnorePointer(child: _ltr(_mini()))),
              if (ui)
                Positioned(top: 0, left: 0, right: 0, child: _ltr(_topBar(w))),
              if (!pip && !locked && (_briOn || _volOn))
                Positioned.fill(child: _ltr(_sideSliders(pad, w, bh))),
              if (ui && panels.isNotEmpty)
                Positioned.fill(child: _ltr(_panelHost(pad, w, bh))),
              if (ui)
                Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: _ltr(_bottomBar(w, h))),
              if (ui && _drag != null) _previewW(bh),
              if (!pip && locked && visible)
                Positioned(
                  left: 16 + pad.left,
                  top: h / 2 - 26,
                  child: _ltr(GlassBtn(
                      pt,
                      Icons.lock_rounded,
                      () => setState(() {
                            locked = false;
                            visible = true;
                            _scheduleHide();
                          }),
                      on: true,
                      size: 26,
                      radius: 28)),
                ),
              if (!pip && zoom > 1.01)
                Positioned(
                  right: 16,
                  top: h / 2 - 20,
                  child: _ltr(GlassChip(pt, '${zoom.toStringAsFixed(1)}×  ✕',
                      onTap: () => setState(() {
                            zoom = 1;
                            pan = Offset.zero;
                          }))),
                ),
              if (!pip && CastService.I.active != null)
                Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: _ltr(CastBar(onStop: _stopCast))),
            ]),
          );
        }),
      ),
    );
  }

  Duration? _hStart2;
}
