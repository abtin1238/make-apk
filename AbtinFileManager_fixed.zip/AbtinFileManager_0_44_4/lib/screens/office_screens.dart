import 'dart:io';
export 'pptx_screen.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../widgets/abtin_global_rail.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../core/layouts.dart';
import '../core/office_prefs.dart';
import '../widgets/office_chrome.dart';
import '../widgets/office_sheet.dart';
import 'office_new.dart';
import 'xlsx_screen.dart';
export 'xlsx_screen.dart';
import '../services/doc_legacy.dart' show DocPara, DocRun;
import '../services/file_ops.dart';
import '../services/legacy_office.dart';
import '../services/odf_service.dart';
import '../services/rtf_doc.dart';
import '../services/native.dart';
import '../services/office_service.dart';
import '../widgets/ui.dart';

Future<String?> _editDialog(BuildContext c, String initial, {String? title}) {
  final ctl = TextEditingController(text: initial);
  return showDialog<String>(
    context: c,
    builder: (_) => AlertDialog(
      title: title == null ? null : Text(title),
      content: TextField(
          controller: ctl, autofocus: true, minLines: 1, maxLines: 10),
      actions: [
        CancelButton(onPressed: () => Navigator.pop(c)),
        FilledButton(
            onPressed: () => Navigator.pop(c, ctl.text),
            child: Text(L.t('ok'))),
      ],
    ),
  );
}

Future<void> _saved(BuildContext c, String target) async {
  Native.scan(target);
  if (c.mounted) snack(c, '${L.t('saved')}: ${p.basename(target)}');
}

// ====================================================================== shared shells of the other Office screens

bool _rtlText(String t) =>
    RegExp(r'[֐-ࣿﭐ-﻿]').hasMatch(t) && !RegExp(r'[A-Za-z]').hasMatch(t);

/// Three-dot menu of the title bar: new document of [kind] + open with another app.
Widget _officeMenu(BuildContext context, String path, OfficeKind kind) =>
    PopupMenuButton<String>(
      icon: const Icon(Icons.more_vert_rounded, color: Colors.white, size: 26),
      onSelected: (v) {
        if (v == 'open') Native.openWith(path, title: L.t('openWith'));
        if (v == 'new') officeNewFile(context, p.dirname(path), kind);
      },
      itemBuilder: (_) => [
        PopupMenuItem(value: 'new', child: Text(kind.title)),
        PopupMenuItem(value: 'open', child: Text(L.t('openWith'))),
      ],
    );

/// Word-like page: navy title bar, white paper on the workspace background, labelled bottom bar.
Widget _wordShell(BuildContext context,
        {required String path,
        required List<Widget> actions,
        required Widget body,
        List<OfficeBarItem>? items}) =>
    Theme(
      data: officeTheme(context),
      child: Scaffold(
        backgroundColor: kOfficeBg,
        bottomNavigationBar:
            items == null ? null : OfficeBottomBar(items: items),
        body: Column(children: [
          OfficeTopBar(title: p.basename(path), actions: actions),
          Expanded(child: OfficePaper(child: body)),
        ]),
      ),
    );

/// A slide-like white card with a number badge.
Widget _slideCard(int i, int n, List<Widget> children) => Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
          color: OfficePrefs.paper,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: OfficePrefs.line),
          boxShadow: const [
            BoxShadow(
                color: Color(0x1A000000), blurRadius: 4, offset: Offset(0, 1))
          ]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Align(
            alignment: AlignmentDirectional.centerEnd,
            child: Text('${i + 1} / $n',
                style: TextStyle(
                    fontSize: 12, color: OfficePrefs.ink.withOpacity(.6)))),
        ...children,
      ]),
    );

/// .odt: paragraphs and headings; tap to edit (the edited paragraph loses inline formatting).
class OdtScreen extends StatefulWidget {
  final String path;
  const OdtScreen({super.key, required this.path});
  @override
  State<OdtScreen> createState() => _OdtScreenState();
}

class _OdtScreenState extends State<OdtScreen> {
  OdtFile? x;
  double font = 16;

  @override
  void initState() {
    super.initState();
    OdtFile.open(widget.path).then((v) {
      if (mounted) setState(() => x = v);
    }).catchError((e) {
      if (mounted) {
        snack(context, '$e');
        Navigator.pop(context);
      }
    });
  }

  Future<void> _save() async {
    final f = x;
    if (f == null) return;
    if (!await ensureSdAll(context, [f.z.path])) return;
    final t = await f.z.saveCopy();
    if (mounted) await _saved(context, t);
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    return _wordShell(
      context,
      path: widget.path,
      actions: [
        officeAction(
            Icons.save_rounded, f == null || !f.z.changed ? null : _save,
            tip: L.t('saveCopy')),
        _officeMenu(context, widget.path, OfficeKind.docx),
      ],
      items: [
        OfficeBarItem(Icons.text_increase_rounded, tr2('بزرگ‌نمایی', 'Zoom in'),
            () => setState(() => font = (font + 1).clamp(10, 36).toDouble())),
        OfficeBarItem(
            Icons.text_decrease_rounded,
            tr2('کوچک‌نمایی', 'Zoom out'),
            () => setState(() => font = (font - 1).clamp(10, 36).toDouble())),
        OfficeBarItem(Icons.save_rounded, L.t('saveCopy'),
            f == null || !f.z.changed ? null : _save),
        OfficeBarItem(
            Icons.note_add_outlined,
            tr2('سند جدید', 'New document'),
            () => officeNewFile(
                context, p.dirname(widget.path), OfficeKind.docx)),
      ],
      body: f == null
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(18, 24, 18, 40),
              itemCount: f.blocks.length,
              itemBuilder: (_, i) {
                final bl = f.blocks[i];
                if (bl.image != null) {
                  return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 6),
                      child: Image.memory(bl.image!,
                          fit: BoxFit.contain,
                          errorBuilder: (_, __, ___) => const SizedBox()));
                }
                if (bl.table != null) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Table(
                      border:
                          TableBorder.all(color: OfficePrefs.line, width: .8),
                      defaultColumnWidth: const IntrinsicColumnWidth(flex: 1),
                      children: [
                        for (final row in bl.table!)
                          TableRow(children: [
                            for (final cell in row)
                              InkWell(
                                onTap: cell.isEmpty
                                    ? null
                                    : () async {
                                        final t = cell.map(paraText).join('\n');
                                        final r = await _editDialog(context, t);
                                        if (r != null) {
                                          setState(() {
                                            f.setText(cell.first, r);
                                            for (final extra in cell.skip(1)) {
                                              f.setText(extra, '');
                                            }
                                          });
                                        }
                                      },
                                child: Padding(
                                    padding: const EdgeInsets.all(6),
                                    child: Text(cell.map(paraText).join('\n'),
                                        style: TextStyle(fontSize: font - 3))),
                              ),
                          ]),
                      ],
                    ),
                  );
                }
                final para = bl.para!;
                final t = paraText(para);
                final h = f.isHeading(para);
                return Directionality(
                  textDirection:
                      _rtlText(t) ? TextDirection.rtl : TextDirection.ltr,
                  child: InkWell(
                    onTap: () async {
                      final r = await _editDialog(context, t);
                      if (r != null) setState(() => f.setText(para, r));
                    },
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: h ? 10 : 4),
                      child: Text(t.isEmpty ? ' ' : t,
                          style: TextStyle(
                              fontSize: h ? font + 5 : font,
                              fontWeight:
                                  h ? FontWeight.bold : FontWeight.normal,
                              color: h ? kOfficeBlue : OfficePrefs.paperInk,
                              height: 1.5)),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

/// .rtf: formatted view (bold / italic / underline / size / colour / alignment / RTL); tap a paragraph to edit
/// its text (edited paragraph keeps the format of its first run). Saving writes "<name> (edited).rtf".
class RtfScreen extends StatefulWidget {
  final String path;
  const RtfScreen({super.key, required this.path});
  @override
  State<RtfScreen> createState() => _RtfScreenState();
}

class _RtfScreenState extends State<RtfScreen> {
  List<DocPara> paras = [];
  bool loaded = false, dirty = false;
  double font = 16;

  @override
  void initState() {
    super.initState();
    File(widget.path).readAsBytes().then((b) {
      final ps = RtfDoc.parse(String.fromCharCodes(b));
      if (mounted)
        setState(() {
          paras = ps;
          loaded = true;
        });
    }).catchError((e) {
      if (mounted) {
        snack(context, '$e');
        Navigator.pop(context);
      }
    });
  }

  Future<void> _edit(DocPara p) async {
    final r = await _editDialog(context, p.text);
    if (r == null) return;
    final first = p.runs.isEmpty ? DocRun('') : p.runs.first;
    setState(() {
      p.runs
        ..clear()
        ..add(DocRun(r,
            b: first.b,
            i: first.i,
            u: first.u,
            sz: first.sz,
            color: first.color));
      if (RegExp(r'[֐-ࣿﭐ-﻿]').hasMatch(r) && !RegExp(r'[A-Za-z]').hasMatch(r))
        p.rtl = true;
      dirty = true;
    });
  }

  void _addAfter(int i) {
    final src = i >= 0 && i < paras.length
        ? paras[i]
        : (paras.isEmpty ? DocPara(rtl: L.rtl) : paras.last);
    final np = DocPara(rtl: src.rtl)..jc = src.jc;
    final f = src.runs.isEmpty ? DocRun('') : src.runs.last;
    np.runs.add(DocRun(' ', b: f.b, i: f.i, u: f.u, sz: f.sz, color: f.color));
    setState(() {
      paras.insert(i + 1 > paras.length ? paras.length : i + 1, np);
      dirty = true;
    });
  }

  Future<void> _menu(int i) async {
    final a = await showModalBottomSheet<String>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
              leading: const Icon(Icons.add_rounded),
              title: Text(L.t('addParaAfter')),
              onTap: () => Navigator.pop(context, 'add')),
          ListTile(
              leading: const Icon(Icons.delete_outline_rounded),
              title: Text(L.t('delete')),
              onTap: () => Navigator.pop(context, 'del')),
        ]),
      ),
    );
    if (a == 'add') {
      _addAfter(i);
    } else if (a == 'del') {
      setState(() {
        paras.removeAt(i);
        dirty = true;
      });
    }
  }

  Future<void> _save() async {
    if (!await ensureSdAll(context, [widget.path])) return;
    final t = FileOps.unique(p.dirname(widget.path),
        '${p.basenameWithoutExtension(widget.path)} (edited).rtf');
    await Saf.writeString(t, RtfDoc.write(paras));
    if (mounted) {
      setState(() => dirty = false);
      await _saved(context, t);
    }
  }

  @override
  Widget build(BuildContext context) => _wordShell(
        context,
        path: widget.path,
        actions: [
          officeAction(Icons.save_rounded, !dirty ? null : _save,
              tip: L.t('saveCopy'),
              color: dirty ? const Color(0xFFFFD54F) : null),
          _officeMenu(context, widget.path, OfficeKind.docx),
        ],
        items: [
          OfficeBarItem(
              Icons.text_increase_rounded,
              tr2('بزرگ‌نمایی', 'Zoom in'),
              () => setState(() => font = (font + 1).clamp(10, 36).toDouble())),
          OfficeBarItem(
              Icons.text_decrease_rounded,
              tr2('کوچک‌نمایی', 'Zoom out'),
              () => setState(() => font = (font - 1).clamp(10, 36).toDouble())),
          OfficeBarItem(Icons.add_rounded, L.t('addParaAfter'),
              loaded ? () => _addAfter(paras.length - 1) : null),
          OfficeBarItem(
              Icons.note_add_outlined,
              tr2('سند جدید', 'New document'),
              () => officeNewFile(
                  context, p.dirname(widget.path), OfficeKind.docx)),
        ],
        body: !loaded
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(18, 24, 18, 40),
                itemCount: paras.length,
                itemBuilder: (_, i) {
                  final pa = paras[i];
                  final align = switch (pa.jc) {
                    1 => TextAlign.center,
                    2 => TextAlign.end,
                    3 => TextAlign.justify,
                    _ => TextAlign.start
                  };
                  return Directionality(
                    textDirection:
                        pa.rtl ? TextDirection.rtl : TextDirection.ltr,
                    child: InkWell(
                      onTap: () => _edit(pa),
                      onLongPress: () => _menu(i),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: SizedBox(
                          width: double.infinity,
                          child: Text.rich(
                            TextSpan(children: [
                              for (final r in pa.runs)
                                TextSpan(
                                  text: r.text,
                                  style: TextStyle(
                                    fontWeight: r.b ? FontWeight.bold : null,
                                    fontStyle: r.i ? FontStyle.italic : null,
                                    decoration:
                                        r.u ? TextDecoration.underline : null,
                                    fontSize: r.sz > 0
                                        ? r.sz / 2 * (font / 12)
                                        : font,
                                    color: r.color != null
                                        ? (OfficePrefs.visible(
                                            Color(0xFF000000 | r.color!)))
                                        : OfficePrefs.paperInk,
                                  ),
                                ),
                              if (pa.runs.isEmpty) const TextSpan(text: ' '),
                            ], style: TextStyle(fontSize: font, height: 1.5)),
                            textAlign: align,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
      );
}

// ====================================================================== legacy / ODF screens

/// .xls (Excel 97-2003): read-only grid; "convert" writes a .xlsx next to it and opens the editor.
class XlsScreen extends StatefulWidget {
  final String path;
  const XlsScreen({super.key, required this.path});
  @override
  State<XlsScreen> createState() => _XlsScreenState();
}

class _XlsScreenState extends State<XlsScreen> {
  List<XlsSheet>? sheets;
  int cur = 0;
  String selectedRef = 'A1';

  @override
  void initState() {
    super.initState();
    File(widget.path).readAsBytes().then((b) {
      try {
        final s = XlsLegacy.parse(b);
        if (mounted) setState(() => sheets = s);
      } catch (e) {
        if (mounted) {
          snack(context, '$e');
          Navigator.pop(context);
        }
      }
    });
  }

  Future<void> _convert() async {
    if (!await ensureSdAll(context, [widget.path])) return;
    final t = FileOps.unique(p.dirname(widget.path),
        '${p.basenameWithoutExtension(widget.path)}.xlsx');
    await Saf.writeBytes(t, XlsLegacy.toXlsx(sheets!));
    Native.scan(t);
    if (!mounted) return;
    snack(context, '${L.t('saved')}: ${p.basename(t)}');
    Navigator.pushReplacement(
        context, abtinPageRoute((_) => XlsxScreen(path: t), hideRail: true));
  }

  @override
  Widget build(BuildContext context) {
    final f = sheets;
    final sh =
        f == null || f.isEmpty ? null : f[cur.clamp(0, f.length - 1).toInt()];
    return Theme(
      data: officeTheme(context),
      child: Scaffold(
        backgroundColor: OfficePrefs.cell,
        bottomNavigationBar: sh == null
            ? null
            : Column(mainAxisSize: MainAxisSize.min, children: [
                OfficeSheetTabs(
                  names: [for (final s in f!) s.name],
                  current: cur,
                  onSelect: (i) => setState(() {
                    cur = i;
                    selectedRef = 'A1';
                  }),
                  onList: () => officeSheetList(
                      context,
                      [for (final s in f) s.name],
                      cur,
                      (i) => setState(() {
                            cur = i;
                            selectedRef = 'A1';
                          })),
                ),
                OfficeBottomBar(dark: true, items: [
                  OfficeBarItem(
                      Icons.edit_note_rounded, L.t('convertEdit'), _convert),
                  OfficeBarItem(
                      Icons.open_in_new_rounded,
                      L.t('openWith'),
                      () =>
                          Native.openWith(widget.path, title: L.t('openWith'))),
                  OfficeBarItem(
                      Icons.note_add_outlined,
                      tr2('اکسل جدید', 'New Excel'),
                      () => officeNewFile(
                          context, p.dirname(widget.path), OfficeKind.xlsx)),
                ]),
              ]),
        body: Column(children: [
          OfficeTopBar(title: p.basename(widget.path), actions: [
            if (f != null)
              officeAction(Icons.edit_note_rounded, _convert,
                  tip: L.t('convertEdit')),
            _officeMenu(context, widget.path, OfficeKind.xlsx),
          ]),
          if (f == null)
            const Expanded(child: Center(child: CircularProgressIndicator()))
          else if (sh == null)
            Expanded(child: Center(child: Text(L.t('empty'))))
          else ...[
            Container(
                width: double.infinity,
                color: Colors.amber.withOpacity(.18),
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                child: Text(L.t('legacyXlsNote'),
                    style:
                        const TextStyle(fontSize: 12, color: Colors.black87))),
            OfficeFormulaBar(
                refName: selectedRef,
                value: () {
                  final m = RegExp(r'^([A-Z]+)(\d+)$').firstMatch(selectedRef);
                  return m == null
                      ? ''
                      : sh.at(int.parse(m[2]!) - 1, colIndex(m[1]!));
                }()),
            Expanded(
              child: OfficeGrid(
                rows: (sh.rows + 20).clamp(40, 5000).toInt(),
                cols: (sh.cols < 4 ? 4 : sh.cols + 1).clamp(4, 200).toInt(),
                selected: selectedRef,
                text: (c, r) => sh.at(r - 1, c),
                fill: (c, r) => r == 1 && sh.at(0, c).isNotEmpty
                    ? OfficePrefs.rowOne
                    : null,
                bold: (c, r) => r == 1 && sh.at(0, c).isNotEmpty,
                onTap: (c, r) =>
                    setState(() => selectedRef = '${colName(c)}$r'),
              ),
            ),
          ],
        ]),
      ),
    );
  }
}

/// .ppt (PowerPoint 97-2003): read-only text per slide, copy-all.
class PptScreen extends StatefulWidget {
  final String path;
  const PptScreen({super.key, required this.path});
  @override
  State<PptScreen> createState() => _PptScreenState();
}

class _PptScreenState extends State<PptScreen> {
  List<List<String>>? slides;

  @override
  void initState() {
    super.initState();
    File(widget.path).readAsBytes().then((b) {
      try {
        final s = PptLegacy.parse(b);
        if (mounted) setState(() => slides = s);
      } catch (e) {
        if (mounted) {
          snack(context, '$e');
          Navigator.pop(context);
        }
      }
    });
  }

  void _copyAll() {
    final f = slides;
    if (f == null) return;
    Clipboard.setData(ClipboardData(
        text: [
      for (var i = 0; i < f.length; i++) '— ${i + 1} —\n${f[i].join('\n')}'
    ].join('\n\n')));
    snack(context, L.t('copied'));
  }

  @override
  Widget build(BuildContext context) {
    final f = slides;
    return Theme(
      data: officeTheme(context),
      child: Scaffold(
        backgroundColor: kOfficeBg,
        body: Column(children: [
          OfficeTopBar(title: p.basename(widget.path), actions: [
            officeAction(Icons.copy_rounded, f == null ? null : _copyAll,
                tip: L.t('copy')),
            _officeMenu(context, widget.path, OfficeKind.pptx),
          ]),
          Container(
            height: 76,
            decoration: BoxDecoration(
                color: kOfficeStrip,
                border: Border(bottom: BorderSide(color: OfficePrefs.line))),
            child: Directionality(
              textDirection: TextDirection.rtl,
              child: Row(children: [
                for (final it in [
                  (
                    Icons.copy_rounded,
                    L.t('copy'),
                    f == null ? null : _copyAll
                  ),
                  (
                    Icons.open_in_new_rounded,
                    L.t('openWith'),
                    () => Native.openWith(widget.path, title: L.t('openWith'))
                  ),
                  (
                    Icons.add_box_outlined,
                    tr2('ارائهٔ جدید', 'New presentation'),
                    () => officeNewFile(
                        context, p.dirname(widget.path), OfficeKind.pptx)
                  ),
                ])
                  Expanded(
                    child: InkWell(
                      onTap: it.$3,
                      child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(it.$1,
                                size: 30,
                                color: it.$3 == null
                                    ? kOfficeInk.withOpacity(.3)
                                    : kOfficeInk),
                            const SizedBox(height: 3),
                            Text(it.$2,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: 13.5, color: kOfficeInk)),
                          ]),
                    ),
                  ),
              ]),
            ),
          ),
          Expanded(
            child: f == null
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    padding: const EdgeInsets.all(11),
                    itemCount: f.length + 1,
                    itemBuilder: (_, i) {
                      if (i == 0)
                        return Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Text(L.t('legacyPptNote'),
                                style: TextStyle(
                                    fontSize: 12,
                                    color: kOfficeInk.withOpacity(.75))));
                      final s = f[i - 1];
                      return _slideCard(i - 1, f.length, [
                        for (final t in s)
                          Padding(
                              padding: const EdgeInsets.symmetric(vertical: 3),
                              child: Directionality(
                                  textDirection: _rtlText(t)
                                      ? TextDirection.rtl
                                      : TextDirection.ltr,
                                  child: SelectableText(t,
                                      style: const TextStyle(
                                          color: Colors.black87)))),
                        if (s.isEmpty) const Text('…'),
                      ]);
                    },
                  ),
          ),
        ]),
      ),
    );
  }
}

/// .ods: sheet tabs and grid, tap a cell to select, double-tap / keyboard to edit (values; formulas are replaced by the typed value).
class OdsScreen extends StatefulWidget {
  final String path;
  const OdsScreen({super.key, required this.path});
  @override
  State<OdsScreen> createState() => _OdsScreenState();
}

class _OdsScreenState extends State<OdsScreen> {
  OdsFile? x;
  int cur = 0;
  String selectedRef = 'A1';

  @override
  void initState() {
    super.initState();
    OdsFile.open(widget.path).then((v) {
      if (mounted) setState(() => x = v);
    }).catchError((e) {
      if (mounted) {
        snack(context, '$e');
        Navigator.pop(context);
      }
    });
  }

  Future<void> _edit(OdsFile f, OSheet sh, String ref) async {
    setState(() => selectedRef = ref);
    final v = await _editDialog(context, sh.cells[ref] ?? '', title: ref);
    if (v != null && mounted) setState(() => f.setCell(sh, ref, v));
  }

  Future<void> _save() async {
    final f = x;
    if (f == null) return;
    if (!await ensureSdAll(context, [f.z.path])) return;
    final t = await f.z.saveCopy();
    if (mounted) await _saved(context, t);
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    final sh = f == null || f.sheets.isEmpty
        ? null
        : f.sheets[cur.clamp(0, f.sheets.length - 1).toInt()];
    return Theme(
      data: officeTheme(context),
      child: Scaffold(
        backgroundColor: OfficePrefs.cell,
        bottomNavigationBar: sh == null
            ? null
            : Column(mainAxisSize: MainAxisSize.min, children: [
                OfficeSheetTabs(
                  names: [for (final s in f!.sheets) s.name],
                  current: cur,
                  onSelect: (i) => setState(() {
                    cur = i;
                    selectedRef = 'A1';
                  }),
                  onList: () => officeSheetList(
                      context,
                      [for (final s in f.sheets) s.name],
                      cur,
                      (i) => setState(() {
                            cur = i;
                            selectedRef = 'A1';
                          })),
                ),
                OfficeBottomBar(dark: true, items: [
                  OfficeBarItem(
                      Icons.keyboard_alt_outlined,
                      tr2('صفحه‌کلید', 'Keyboard'),
                      () => _edit(f, sh, selectedRef)),
                  OfficeBarItem(Icons.save_rounded, L.t('saveCopy'),
                      f.z.changed ? _save : null),
                  OfficeBarItem(
                      Icons.note_add_outlined,
                      tr2('اکسل جدید', 'New Excel'),
                      () => officeNewFile(
                          context, p.dirname(widget.path), OfficeKind.xlsx)),
                ]),
              ]),
        body: Column(children: [
          OfficeTopBar(title: p.basename(widget.path), actions: [
            officeAction(
                Icons.save_rounded, f == null || !f.z.changed ? null : _save,
                tip: L.t('saveCopy')),
            _officeMenu(context, widget.path, OfficeKind.xlsx),
          ]),
          if (f == null)
            const Expanded(child: Center(child: CircularProgressIndicator()))
          else if (sh == null)
            Expanded(child: Center(child: Text(L.t('empty'))))
          else ...[
            OfficeFormulaBar(
                refName: selectedRef,
                value: sh.cells[selectedRef] ?? '',
                onSubmit: (v) => setState(() => f.setCell(sh, selectedRef, v))),
            Expanded(
              child: OfficeGrid(
                rows: (sh.rows + 20).clamp(40, 5000).toInt(),
                cols: (sh.cols < 4 ? 4 : sh.cols + 1).clamp(4, 200).toInt(),
                selected: selectedRef,
                text: (c, r) => sh.cells['${colName(c)}$r'] ?? '',
                fill: (c, r) => r == 1 && sh.cells['${colName(c)}$r'] != null
                    ? OfficePrefs.rowOne
                    : null,
                bold: (c, r) => r == 1 && sh.cells['${colName(c)}$r'] != null,
                onTap: (c, r) =>
                    setState(() => selectedRef = '${colName(c)}$r'),
                onDouble: (c, r) => _edit(f, sh, '${colName(c)}$r'),
              ),
            ),
          ],
        ]),
      ),
    );
  }
}

/// .odp: pages with images and text; tap a paragraph to edit.
class OdpScreen extends StatefulWidget {
  final String path;
  const OdpScreen({super.key, required this.path});
  @override
  State<OdpScreen> createState() => _OdpScreenState();
}

class _OdpScreenState extends State<OdpScreen> {
  OdpFile? x;

  @override
  void initState() {
    super.initState();
    OdpFile.open(widget.path).then((v) {
      if (mounted) setState(() => x = v);
    }).catchError((e) {
      if (mounted) {
        snack(context, '$e');
        Navigator.pop(context);
      }
    });
  }

  Future<void> _save() async {
    final f = x;
    if (f == null) return;
    if (!await ensureSdAll(context, [f.z.path])) return;
    final t = await f.z.saveCopy();
    if (mounted) await _saved(context, t);
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    return Theme(
      data: officeTheme(context),
      child: Scaffold(
        backgroundColor: kOfficeBg,
        body: Column(children: [
          OfficeTopBar(title: p.basename(widget.path), actions: [
            officeAction(
                Icons.save_rounded, f == null || !f.z.changed ? null : _save,
                tip: L.t('saveCopy')),
            _officeMenu(context, widget.path, OfficeKind.pptx),
          ]),
          Expanded(
            child: f == null
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    padding: const EdgeInsets.all(11),
                    itemCount: f.pages.length,
                    itemBuilder: (_, i) {
                      final pg = f.pages[i];
                      return _slideCard(i, f.pages.length, [
                        for (final im in pg.images)
                          Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              child: Image.memory(im,
                                  height: 180,
                                  fit: BoxFit.contain,
                                  errorBuilder: (_, __, ___) =>
                                      const SizedBox())),
                        for (final para in pg.paras)
                          Directionality(
                            textDirection: _rtlText(paraText(para))
                                ? TextDirection.rtl
                                : TextDirection.ltr,
                            child: InkWell(
                              onTap: () async {
                                final r =
                                    await _editDialog(context, paraText(para));
                                if (r != null)
                                  setState(() => f.setText(para, r));
                              },
                              child: Padding(
                                  padding:
                                      const EdgeInsets.symmetric(vertical: 4),
                                  child: Text(
                                      paraText(para).isEmpty
                                          ? '…'
                                          : paraText(para),
                                      style: const TextStyle(
                                          color: Colors.black87))),
                            ),
                          ),
                      ]);
                    },
                  ),
          ),
        ]),
      ),
    );
  }
}
