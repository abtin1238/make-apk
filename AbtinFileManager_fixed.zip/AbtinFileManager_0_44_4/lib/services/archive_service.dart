import 'dart:io';
import 'dart:isolate';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:archive/archive_io.dart';
import 'package:flutter/services.dart' show PlatformException;
import 'package:path/path.dart' as p;
import 'file_ops.dart' show OpError;
import 'native.dart';

/// One entry of an archive listing. [name] uses '/', folders end with '/'.
class ArchiveEntry {
  final String name;
  final bool dir;
  final int size;
  final bool enc;
  const ArchiveEntry(this.name, this.dir, this.size, this.enc);
}

class ArchiveService {
  static const _exts = ['.zip', '.rar', '.7z', '.tar', '.gz', '.tgz', '.bz2', '.tbz', '.tbz2', '.xz', '.txz', '.jar', '.cbz', '.cbr', '.apk', '.xapk', '.apks', '.epub'];
  static final _rawPart = RegExp(r'\.(\d{3})$');
  static final _zPart = RegExp(r'\.z\d{2,}$', caseSensitive: false);
  static final _oldRar = RegExp(r'\.r\d{2}$', caseSensitive: false);
  static final _partRar = RegExp(r'\.part(\d+)\.rar$', caseSensitive: false);

  static bool isArchive(String path) {
    final l = path.toLowerCase();
    if (_zPart.hasMatch(l) || _oldRar.hasMatch(l)) return true;
    final m = _rawPart.firstMatch(l);
    final base = m == null ? l : l.substring(0, m.start);
    return _exts.any(base.endsWith);
  }

  /// First volume of a multi-part archive (x.7z.002 → x.7z.001, x.z01 → x.zip, x.r00 → x.rar,
  /// x.part2.rar → x.part1.rar); any other path is returned unchanged.
  static String firstVolume(String path) {
    var m = _rawPart.firstMatch(path);
    if (m != null) return '${path.substring(0, m.start)}.001';
    m = _zPart.firstMatch(path);
    if (m != null) {
      final b = path.substring(0, m.start);
      return File('$b.ZIP').existsSync() && !File('$b.zip').existsSync() ? '$b.ZIP' : '$b.zip';
    }
    m = _oldRar.firstMatch(path);
    if (m != null) {
      final b = path.substring(0, m.start);
      return File('$b.RAR').existsSync() && !File('$b.rar').existsSync() ? '$b.RAR' : '$b.rar';
    }
    m = _partRar.firstMatch(path);
    if (m != null) {
      final w = m[1]!.length;
      return '${path.substring(0, m.start)}.part${'1'.padLeft(w, '0')}${path.substring(m.end - 4)}';
    }
    return path;
  }

  /// true for every part of a multi-volume archive (also the first one).
  static bool isMultiPart(String path) =>
      _rawPart.hasMatch(path) || _zPart.hasMatch(path) || _oldRar.hasMatch(path) || _partRar.hasMatch(path) || _hasZ01(path);

  static bool _hasZ01(String path) {
    if (!path.toLowerCase().endsWith('.zip')) return false;
    final b = path.substring(0, path.length - 4);
    return File('$b.z01').existsSync() || File('$b.Z01').existsSync();
  }

  /// x.7z.001, x.7z.002 … that exist in sequence (raw split, as 7-Zip / HJSplit write them).
  static List<String> rawParts(String first) {
    final m = _rawPart.firstMatch(first);
    if (m == null) return [first];
    final base = first.substring(0, m.start);
    final out = <String>[];
    for (var n = 1;; n++) {
      final f = '$base.${n.toString().padLeft(3, '0')}';
      if (!File(f).existsSync()) break;
      out.add(f);
    }
    return out;
  }

  /// Does [name] belong to the selection [only]? Entries ending with '/' select a whole folder.
  static bool matches(String name, List<String>? only) {
    if (only == null) return true;
    for (final o in only) {
      if (o.endsWith('/')) {
        if (name == o || name.startsWith(o) || '$name/' == o) return true;
      } else if (name == o) {
        return true;
      }
    }
    return false;
  }

  static String normName(String n) {
    var s = n.replaceAll('\\', '/');
    while (s.startsWith('./')) {
      s = s.substring(2);
    }
    while (s.startsWith('/')) {
      s = s.substring(1);
    }
    return s;
  }

  static String defaultFolderName(String path) {
    var n = p.basename(path);
    for (final s in ['.tar.gz', '.tar.bz2', '.tar.xz']) {
      if (n.toLowerCase().endsWith(s)) return n.substring(0, n.length - s.length);
    }
    return p.basenameWithoutExtension(n);
  }

  static String _kind(String path) {
    final raf = File(path).openSync();
    final h = raf.readSync(8);
    raf.closeSync();
    bool m(List<int> sig) {
      if (h.length < sig.length) return false;
      for (var i = 0; i < sig.length; i++) {
        if (h[i] != sig[i]) return false;
      }
      return true;
    }
    if (m([0x50, 0x4B])) return 'zip';
    if (m([0x37, 0x7A, 0xBC, 0xAF])) return '7z';
    if (m([0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x01, 0x00])) throw const OpError('rar5Unsupported'); // junrar reads RAR 4 only
    if (m([0x52, 0x61, 0x72, 0x21])) return 'rar';
    if (m([0x1F, 0x8B])) return 'gz';
    if (m([0x42, 0x5A, 0x68])) return 'bz2';
    if (m([0xFD, 0x37, 0x7A, 0x58, 0x5A])) return 'xz';
    if (path.toLowerCase().endsWith('.tar')) return 'tar';
    throw Exception('Unsupported or corrupted archive');
  }

  static Never _nativeError(PlatformException e) {
    if (e.code == 'RAR5') throw const OpError('rar5Unsupported');
    if (e.code == 'PASSWORD') throw const OpError('wrongPassword');
    throw OpError('error', e.message);
  }

  static Future<T> _guard<T>(Future<T> Function() f) async {
    try {
      return await f();
    } on PlatformException catch (e) {
      _nativeError(e);
    }
  }

  /// Joins x.7z.001 + x.7z.002 … into one temp file (streamed), keeping the original name for sniffing.
  static Future<String> _join(String first) async {
    final parts = rawParts(first);
    if (parts.isEmpty) throw OpError('missingVolume', p.basename(first));
    final tmp = p.join(Directory.systemTemp.path, 'abtin_join_${DateTime.now().microsecondsSinceEpoch}_${p.basename(first).replaceAll(_rawPart, '')}');
    await Isolate.run(() {
      final out = File(tmp).openSync(mode: FileMode.write);
      try {
        for (final part in parts) {
          final r = File(part).openSync();
          try {
            while (true) {
              final b = r.readSync(1 << 20);
              if (b.isEmpty) break;
              out.writeFromSync(b);
            }
          } finally {
            r.closeSync();
          }
        }
      } finally {
        out.closeSync();
      }
    });
    return tmp;
  }

  /// Runs [job] on a plain single-file archive: raw-split volumes (.001) are joined first,
  /// other multi-volume sets (.z01, .part1.rar, .r00) are opened from their first volume.
  static Future<T> _withSource<T>(String src, Future<T> Function(String path) job) async {
    final first = firstVolume(src);
    if (_rawPart.hasMatch(first)) {
      final tmp = await _join(first);
      try {
        return await job(tmp);
      } finally {
        try { File(tmp).deleteSync(); } catch (_) {}
      }
    }
    return job(first);
  }

  static bool _isSplitZip(String path) {
    final b = p.withoutExtension(path);
    return File('$b.z01').existsSync() || File('$b.Z01').existsSync();
  }

  /// Entries of an archive (zip / 7z / rar natively, tar / gz / bz2 / xz in Dart).
  static Future<List<ArchiveEntry>> list(String src, {String? password}) => _withSource(src, (path) async {
        final kind = _kind(path);
        if (kind == '7z' || kind == 'rar' || kind == 'zip') {
          final r = await _guard(() => Native.archList(path, password));
          return [
            for (final m in r)
              ArchiveEntry(normName('${m['name']}'), m['dir'] == true, (m['size'] as num?)?.toInt() ?? 0, m['enc'] == true),
          ];
        }
        final r = await _listInIsolate(path, kind);
        return [for (final m in r) ArchiveEntry(m[0] as String, m[1] as bool, m[2] as int, false)];
      });

  /// true when opening / extracting [src] needs a password (zip / 7z / rar only; encrypted names count too).
  static Future<bool> needsPassword(String src) async {
    try {
      final l = await list(src);
      return l.any((e) => e.enc);
    } on OpError catch (e) {
      return e.key == 'wrongPassword';
    } catch (_) {
      return false;
    }
  }

  static List<List<Object>> _listDart(String src, String kind) {
    final Archive a;
    if (kind == 'tar') {
      final input = InputFileStream(src);
      a = TarDecoder().decodeBuffer(input);
      input.close();
    } else {
      final data = _decompress(src, kind);
      if (!_isTar(data) && !_hasTarExtension(src)) {
        return [[p.basenameWithoutExtension(src), false, data.length]];
      }
      a = TarDecoder().decodeBytes(data);
    }
    return [
      for (final f in a.files)
        [f.isFile ? normName(f.name) : '${normName(f.name).replaceAll(RegExp(r'/+$'), '')}/', !f.isFile, f.isFile ? f.size : 0],
    ];
  }

  static Uint8List _decompress(String src, String kind) {
    final raw = File(src).readAsBytesSync();
    if (kind == 'gz') return Uint8List.fromList(GZipDecoder().decodeBytes(raw));
    if (kind == 'bz2') return Uint8List.fromList(BZip2Decoder().decodeBytes(raw));
    return Uint8List.fromList(XZDecoder().decodeBytes(raw));
  }

  // Valid legacy tar archives may omit the ustar magic bytes. A tar-specific
  // filename is still a reliable signal after gzip/bzip2/xz decompression.
  static bool _hasTarExtension(String path) => RegExp(
        r'\.(tar\.(gz|bz2|xz)|tgz|tbz2?|txz)$',
        caseSensitive: false,
      ).hasMatch(path);

  /// [onProgress] gets 0..1. [only] limits the extraction to those entries (folders end with '/').
  /// Volumes: x.7z.001 …, x.z01 + x.zip, x.part1.rar, x.r00 + x.rar are all opened by tapping any part.
  static Future<void> extract(String src, String dst, {String? password, List<String>? only, void Function(double)? onProgress}) =>
      _withSource(src, (path) async {
        await Directory(dst).create(recursive: true);
        final kind = _kind(path);
        if (kind == '7z' || kind == 'rar' || (kind == 'zip' && (password != null || _isSplitZip(path)))) {
          return _guard(() => Native.archExtract(path, dst, password, only: only, onProgress: onProgress));
        }
        final rp = ReceivePort();
        final sub = rp.listen((m) {
          if (m is double) onProgress?.call(m);
        });
        final port = rp.sendPort;
        try {
          await _extractInIsolate(path, dst, kind, password, port, only == null ? null : List<String>.of(only));
        } finally {
          await sub.cancel();
          rp.close();
        }
      });

  /// Runs [_dart] in a background isolate. This MUST stay a separate static function: a closure created inside
  /// [extract] would drag its whole scope (onProgress → widget State, async completers …) into the isolate
  /// message and fail with "unsendable object … SendPort.send()".
  static Future<void> _extractInIsolate(String path, String dst, String kind, String? pw, SendPort port, List<String>? only) =>
      Isolate.run(() => _dart(path, dst, kind, pw, port, only));

  static Future<List<List<Object>>> _listInIsolate(String path, String kind) => Isolate.run(() => _listDart(path, kind));

  static bool _isTar(Uint8List b) => b.length > 262 && String.fromCharCodes(b.sublist(257, 262)) == 'ustar';

  static void _dart(String src, String dst, String kind, String? pw, SendPort? port, List<String>? only) {
    if (kind == 'zip') {
      final input = InputFileStream(src);
      final a = ZipDecoder().decodeBuffer(input, password: pw);
      _write(a, dst, port, only);
      input.close();
      return;
    }
    if (kind == 'tar') {
      final input = InputFileStream(src);
      _write(TarDecoder().decodeBuffer(input), dst, port, only);
      input.close();
      return;
    }
    final data = _decompress(src, kind);
    if (_isTar(data) || _hasTarExtension(src)) {
      _write(TarDecoder().decodeBytes(data), dst, port, only);
    } else {
      File(p.join(dst, p.basenameWithoutExtension(src))).writeAsBytesSync(data);
    }
  }

  static void _write(Archive a, String dst, [SendPort? port, List<String>? only]) {
    final base = p.canonicalize(dst);
    final files = only == null
        ? a.files
        : a.files.where((f) {
            final n = normName(f.name);
            return matches(f.isFile ? n : '${n.replaceAll(RegExp(r'/+$'), '')}/', only);
          }).toList();
    final total = files.length;
    var n = 0;
    var last = -1;
    for (final f in files) {
      n++;
      final pct = total == 0 ? 100 : n * 100 ~/ total;
      if (pct != last) {
        last = pct;
        port?.send(n / total);
      }
      final out = p.canonicalize(p.join(dst, f.name));
      if (out != base && !p.isWithin(base, out)) continue; // zip-slip guard
      if (f.isFile) {
        File(out).parent.createSync(recursive: true);
        final os = OutputFileStream(out);
        f.writeContent(os);
        os.close();
      } else {
        Directory(out).createSync(recursive: true);
      }
    }
  }

  static Future<String> compressZip(List<String> paths, String destZip) async {
    await Isolate.run(() {
      final enc = ZipFileEncoder();
      enc.create(destZip);
      for (final x in paths) {
        if (FileSystemEntity.isDirectorySync(x)) {
          enc.addDirectory(Directory(x));
        } else {
          enc.addFile(File(x));
        }
      }
      enc.close();
    });
    return destZip;
  }

  static String extFor(String format) => format == 'targz' ? '.tar.gz' : (format == '7z' ? '.7z' : '.zip');

  /// [format]: 'zip', 'targz' or '7z'. A zip without password / volumes is built in Dart (no progress);
  /// everything else natively (streaming, with progress). [volumeMB] > 0 splits the result:
  /// zip → x.z01, x.z02 … x.zip (real split zip); 7z / tar.gz → x.7z.001, x.7z.002 … (raw split, join to open).
  static Future<String> compress(List<String> paths, String dest, String format,
      {String? password, int volumeMB = 0, void Function(double)? onProgress}) async {
    final vol = volumeMB * 1024 * 1024;
    await _guard(() => Native.compress(paths, dest, format, password, volumeBytes: format == 'zip' ? vol : 0, onProgress: onProgress));
    if (format != 'zip' && vol > 0) await _splitRaw(dest, vol);
    return dest;
  }

  static Future<void> _splitRaw(String file, int size) => Isolate.run(() {
        final inp = File(file).openSync();
        var left = inp.lengthSync();
        var n = 0;
        while (left > 0) {
          n++;
          final out = File('$file.${n.toString().padLeft(3, '0')}').openSync(mode: FileMode.write);
          var chunk = left < size ? left : size;
          while (chunk > 0) {
            final b = inp.readSync(chunk < (1 << 20) ? chunk : (1 << 20));
            if (b.isEmpty) break;
            out.writeFromSync(b);
            chunk -= b.length;
            left -= b.length;
          }
          out.closeSync();
        }
        inp.closeSync();
        File(file).deleteSync();
      });

  /// Files that [compress] produced for [dest] (one file, or all volumes).
  static List<String> outputParts(String dest, String format, int volumeMB) {
    if (volumeMB <= 0) return [dest];
    final out = <String>[];
    if (format == 'zip') {
      final b = p.withoutExtension(dest);
      for (var n = 1;; n++) {
        final f = '$b.z${n.toString().padLeft(2, '0')}';
        if (!File(f).existsSync()) break;
        out.add(f);
      }
      if (File(dest).existsSync()) out.add(dest);
    } else {
      for (var n = 1;; n++) {
        final f = '$dest.${n.toString().padLeft(3, '0')}';
        if (!File(f).existsSync()) break;
        out.add(f);
      }
    }
    return out;
  }

  /// Name of volume [tmpPart] (made for [tmpDest]) once the archive is called [outDest].
  static String partTarget(String tmpPart, String tmpDest, String outDest) {
    if (tmpPart.startsWith(tmpDest)) return outDest + tmpPart.substring(tmpDest.length);
    return p.withoutExtension(outDest) + p.extension(tmpPart);
  }
}
