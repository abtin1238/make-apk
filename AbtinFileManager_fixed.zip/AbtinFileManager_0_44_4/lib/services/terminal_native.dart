import 'package:flutter/services.dart';

/// Flutter method/event-channel client for the native Android PTY shell.
class TerminalNative {
  static const MethodChannel _methods = MethodChannel('abtin/terminal');
  static const EventChannel _eventChannel = EventChannel(
    'abtin/terminal/events',
  );

  Stream<Map<String, dynamic>> get events => _eventChannel
      .receiveBroadcastStream()
      .map((event) => Map<String, dynamic>.from(event as Map));

  Future<TerminalSession> start(String cwd,
      {int columns = 80, int rows = 24}) async {
    final value = await _methods.invokeMapMethod<String, dynamic>('start', {
      'cwd': cwd,
      'columns': columns,
      'rows': rows,
    });
    if (value == null ||
        value['sessionId'] is! String ||
        value['cwd'] is! String) {
      throw PlatformException(
        code: 'TERMINAL_START',
        message: 'Native shell returned an invalid session',
      );
    }
    return TerminalSession(
      id: value['sessionId'] as String,
      cwd: value['cwd'] as String,
    );
  }

  Future<void> writeLine(String sessionId, String text) async {
    await _methods.invokeMethod<bool>('writeLine', {
      'sessionId': sessionId,
      'text': text,
    });
  }

  /// Writes exactly [text], without appending a line ending.
  Future<void> writeRaw(String sessionId, String text) async {
    await _methods.invokeMethod<bool>('writeRaw', {
      'sessionId': sessionId,
      'text': text,
    });
  }

  /// Writes ETX to the PTY line discipline so the foreground process gets SIGINT.
  Future<void> interrupt(String sessionId) async {
    await _methods.invokeMethod<bool>('interrupt', {'sessionId': sessionId});
  }

  /// Writes EOT (Ctrl+D) to the PTY line discipline.
  Future<void> eof(String sessionId) async {
    await _methods.invokeMethod<bool>('eof', {'sessionId': sessionId});
  }

  Future<void> resize(String sessionId, int columns, int rows) async {
    await _methods.invokeMethod<bool>('resize', {
      'sessionId': sessionId,
      'columns': columns,
      'rows': rows,
    });
  }

  Future<void> close(String sessionId) async {
    await _methods.invokeMethod<bool>('close', {'sessionId': sessionId});
  }

  Future<void> closeAll() async {
    await _methods.invokeMethod<bool>('closeAll');
  }
}

class TerminalSession {
  final String id;
  final String cwd;
  const TerminalSession({required this.id, required this.cwd});
}
