import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/core/color_spec.dart';
import 'package:abtin_file_manager/core/icon_prefs.dart';
import 'package:abtin_file_manager/core/looks.dart';

void main() {
  test('ColorSpec encodes and decodes solid and gradient colours', () {
    const g = ColorSpec(0xFF112233, 0xFF445566, 2);
    final d = ColorSpec.decode(g.encode())!;
    expect(d, g);
    expect(d.isGradient, true);
    final s = ColorSpec.decode(const ColorSpec.solid(0xFFAABBCC).encode())!;
    expect(s.isGradient, false);
    expect(s.c2, null);
    expect(ColorSpec.decode(0xFF010203)!.c1, 0xFF010203); // old plain-int format
    expect(ColorSpec.decode('x'), null);
  });

  test('IconPrefs survives a json round trip and reads the old format', () {
    IconPrefs.specs['folder'] = const ColorSpec(0xFF111111, 0xFF222222);
    IconPrefs.overrides['a:1'] = const ColorSpec.solid(0xFF333333);
    IconPrefs.mode = 2;
    final j = IconPrefs.toJson();
    IconPrefs.fromJson(j);
    expect(IconPrefs.spec('folder').isGradient, true);
    expect(IconPrefs.overrides['a:1']!.c1, 0xFF333333);
    expect(IconPrefs.mode, 2);
    IconPrefs.fromJson({'c': {'images': 0xFF00FF00}});
    expect(IconPrefs.spec('images').c1, 0xFF00FF00);
    expect(IconPrefs.mode, 0);
    IconPrefs.fromJson({});
  });

  test('icon sheet has 63 icons and look ids are unique', () {
    expect(iconPack.length, 63);
    expect(appLooks.map((l) => l.id).toSet().length, appLooks.length);
    expect(lookById('nope').id, 'neon');
  });
}
