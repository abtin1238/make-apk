#!/usr/bin/env python3
"""Build a repository for the Abtin `pkg` tool.

Usage:
  mkrepo.py OUTDIR PKGDIR [PKGDIR...]

Every PKGDIR must contain `control` (Debian style: Package, Version, Architecture, Depends,
Description) and the files to install, laid out relative to the prefix, in a `root/` folder:
    mypkg/control
    mypkg/root/bin/hello          (-> $PREFIX/bin/hello)
    mypkg/postinst                (optional; also prerm / postrm)
Output: OUTDIR/Packages, OUTDIR/pool/<name>_<version>_<arch>.deb
Host OUTDIR on any web server, then in the app terminal:  pkg repo add myrepo https://host/OUTDIR && pkg update
"""
import gzip, hashlib, io, os, sys, tarfile, time


def tar_bytes(entries):
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz", format=tarfile.GNU_FORMAT) as t:
        for name, info in entries:
            t.addfile(info[0], info[1])
    return buf.getvalue()


def add_tree(root, base):
    out = []
    for d, dirs, files in os.walk(root):
        dirs.sort()
        for n in sorted(dirs + files):
            full = os.path.join(d, n)
            rel = "./" + os.path.relpath(full, root).replace(os.sep, "/")
            ti = tarfile.TarInfo(rel)
            ti.mtime = int(time.time())
            if os.path.islink(full):
                ti.type = tarfile.SYMTYPE
                ti.linkname = os.readlink(full)
                out.append((rel, (ti, None)))
            elif os.path.isdir(full):
                ti.type = tarfile.DIRTYPE
                ti.mode = 0o755
                out.append((rel, (ti, None)))
            else:
                data = open(full, "rb").read()
                ti.size = len(data)
                ti.mode = os.stat(full).st_mode & 0o777
                out.append((rel, (ti, io.BytesIO(data))))
    return out


def ar(members):
    out = b"!<arch>\n"
    for name, data in members:
        hdr = ("%-16s%-12d%-6d%-6d%-8s%-10d`\n" % (name + "/", int(time.time()), 0, 0, "100644", len(data))).encode()
        out += hdr + data
        if len(data) % 2:
            out += b"\n"
    return out


def build(pkgdir, outdir):
    ctl = open(os.path.join(pkgdir, "control")).read()
    fields = {}
    for line in ctl.splitlines():
        if ":" in line and not line.startswith(" "):
            k, v = line.split(":", 1)
            fields[k.strip().lower()] = v.strip()
    name, ver, arch = fields["package"], fields["version"], fields.get("architecture", "all")
    data_tar = tar_bytes(add_tree(os.path.join(pkgdir, "root"), "root")) if os.path.isdir(os.path.join(pkgdir, "root")) else tar_bytes([])
    centries = []
    ti = tarfile.TarInfo("./control"); b = ctl.encode(); ti.size = len(b); centries.append(("c", (ti, io.BytesIO(b))))
    for s in ("postinst", "prerm", "postrm"):
        p = os.path.join(pkgdir, s)
        if os.path.exists(p):
            b = open(p, "rb").read(); ti = tarfile.TarInfo("./" + s); ti.size = len(b); ti.mode = 0o755
            centries.append((s, (ti, io.BytesIO(b))))
    deb = ar([("debian-binary", b"2.0\n"), ("control.tar.gz", tar_bytes(centries)), ("data.tar.gz", data_tar)])
    fn = "pool/%s_%s_%s.deb" % (name, ver, arch)
    os.makedirs(os.path.join(outdir, "pool"), exist_ok=True)
    open(os.path.join(outdir, fn), "wb").write(deb)
    stanza = ctl.rstrip("\n") + "\nFilename: %s\nSize: %d\nSHA256: %s\n\n" % (fn, len(deb), hashlib.sha256(deb).hexdigest())
    return stanza


def main():
    if len(sys.argv) < 3:
        print(__doc__); sys.exit(2)
    outdir = sys.argv[1]
    os.makedirs(outdir, exist_ok=True)
    index = "".join(build(p, outdir) for p in sys.argv[2:])
    open(os.path.join(outdir, "Packages"), "w").write(index)
    with gzip.open(os.path.join(outdir, "Packages.gz"), "wb") as g:
        g.write(index.encode())
    print("wrote", os.path.join(outdir, "Packages"))


main()
