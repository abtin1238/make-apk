package ir.abtin.filemanager;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.zip.GZIPInputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Abtin package manager ("pkg"). Pure JDK + java.io so the same class runs inside the
 * Android runtime via app_process (CLASSPATH=base.apk) and on a desktop JVM for tests.
 *
 * Repository format: Debian "Packages" index (flat, or apt layout dists/DIST/COMP/binary-ARCH/).
 * Package format: .deb (data.tar.gz/xz/bz2), .tar(.gz/.xz/.bz2) or .zip. Termux paths
 * (/data/data/com.termux/files/usr) and /usr are mapped into $PREFIX.
 */
public final class PkgCli {
    static final String VERSION = "1.0";
    static final Charset UTF8 = Charset.forName("UTF-8");
    static final String TERMUX_PREFIX = "data/data/com.termux/files/usr";
    static final String TERMUX_HOME = "data/data/com.termux/files/home";

    // ------------------------------------------------------------------ model

    static final class Pkg {
        String name = "", version = "0", arch = "all", depends = "", desc = "", filename = "";
        String sha256 = "", homepage = "", repo = "", section = "";
        long size = 0;
        Builtin builtin;
        boolean manual = true;

        List<String> depNames() {
            List<String> out = new ArrayList<String>();
            for (String[] d : parseDepends(depends)) out.add(d[0]);
            return out;
        }
    }

    /** In-memory package (used by the "builtin" repository). */
    static final class Builtin {
        final Map<String, String> files = new LinkedHashMap<String, String>();
        final Set<String> executable = new HashSet<String>();
    }

    static final class PkgException extends Exception {
        private static final long serialVersionUID = 1L;
        PkgException(String m) { super(m); }
    }

    // ------------------------------------------------------------------ state

    final File prefix;
    final File etcDir, pkgEtc, dbDir, installedDir, listsDir, cacheDir, stageRoot;
    PrintStream out = System.out;
    boolean yes, force, noDeps, reinstall, ansi;
    final String arch;

    PkgCli(File prefix) {
        this.prefix = prefix;
        etcDir = new File(prefix, "etc");
        pkgEtc = new File(etcDir, "pkg");
        dbDir = new File(prefix, "var/lib/pkg");
        installedDir = new File(dbDir, "installed");
        listsDir = new File(dbDir, "lists");
        cacheDir = new File(prefix, "var/cache/pkg");
        stageRoot = new File(dbDir, "staging");
        arch = detectArch();
    }

    static String detectArch() {
        String a = System.getProperty("os.arch", "").toLowerCase(Locale.ROOT);
        if (a.equals("aarch64") || a.equals("arm64") || a.equals("armv8") || a.equals("armv9")) return "aarch64";
        if (a.startsWith("arm")) return "arm";
        if (a.equals("amd64") || a.equals("x86_64")) return "x86_64";
        if (a.equals("x86") || a.equals("i386") || a.equals("i686")) return "i686";
        return a;
    }

    void ensureDirs() throws IOException {
        File[] dirs = {new File(prefix, "bin"), new File(prefix, "lib"), etcDir, pkgEtc, installedDir,
                listsDir, cacheDir, new File(prefix, "tmp"), new File(prefix, "share")};
        for (File d : dirs) mkdirs(d);
        File repos = new File(pkgEtc, "repos.list");
        if (!repos.exists()) {
            writeText(repos,
                    "# Abtin pkg repositories (one per line):  name url [dist component]\n"
                            + "# Flat repository:  myrepo https://example.com/repo\n"
                            + "#   -> https://example.com/repo/Packages(.gz)\n"
                            + "# apt layout:       main https://example.com/apt stable main\n"
                            + "#   -> https://example.com/apt/dists/stable/main/binary-" + arch + "/Packages(.gz)\n"
                            + "# Manage with:  pkg repo add|remove|list\n");
        }
    }

    // ------------------------------------------------------------------ main

    public static void main(String[] args) {
        int code;
        try {
            String p = System.getenv("PREFIX");
            if (p == null || p.length() == 0) {
                System.err.println("pkg: PREFIX is not set (open the app terminal to use pkg)");
                System.exit(2);
                return;
            }
            PkgCli cli = new PkgCli(new File(p));
            cli.out = new PrintStream(new java.io.FileOutputStream(java.io.FileDescriptor.out), true, "UTF-8");
            String term = System.getenv("TERM");
            cli.ansi = term != null && !term.equals("dumb");
            code = cli.run(args);
            cli.out.flush();
        } catch (PkgException e) {
            System.err.println("pkg: " + e.getMessage());
            code = 1;
        } catch (Throwable t) {
            System.err.println("pkg: internal error: " + t);
            code = 1;
        }
        System.exit(code);
    }

    int run(String[] argv) throws Exception {
        ensureDirs();
        List<String> args = new ArrayList<String>();
        for (String a : argv) {
            if (a.equals("-y") || a.equals("--yes") || a.equals("--assume-yes")) yes = true;
            else if (a.equals("--force")) force = true;
            else if (a.equals("--no-deps")) noDeps = true;
            else if (a.equals("--reinstall")) reinstall = true;
            else args.add(a);
        }
        if (args.isEmpty()) { help(); return 0; }
        String cmd = args.remove(0);
        if (cmd.equals("help") || cmd.equals("-h") || cmd.equals("--help")) { help(); return 0; }
        if (cmd.equals("version") || cmd.equals("--version")) { out.println("pkg " + VERSION + " (" + arch + ")"); return 0; }
        if (cmd.equals("update") || cmd.equals("up")) return cmdUpdate();
        if (cmd.equals("search") || cmd.equals("s")) return cmdSearch(args);
        if (cmd.equals("show") || cmd.equals("info")) return cmdShow(args);
        if (cmd.equals("list-all") || cmd.equals("list-available")) return cmdListAll();
        if (cmd.equals("list") || cmd.equals("list-installed") || cmd.equals("ls")) return cmdListInstalled();
        if (cmd.equals("install") || cmd.equals("add") || cmd.equals("i")) return cmdInstall(args);
        if (cmd.equals("reinstall")) { reinstall = true; return cmdInstall(args); }
        if (cmd.equals("remove") || cmd.equals("uninstall") || cmd.equals("purge") || cmd.equals("rm") || cmd.equals("del"))
            return cmdRemove(args);
        if (cmd.equals("autoremove")) return cmdAutoremove();
        if (cmd.equals("upgrade") || cmd.equals("full-upgrade") || cmd.equals("dist-upgrade")) return cmdUpgrade();
        if (cmd.equals("files")) return cmdFiles(args);
        if (cmd.equals("owns") || cmd.equals("which")) return cmdOwns(args);
        if (cmd.equals("clean") || cmd.equals("autoclean")) return cmdClean();
        if (cmd.equals("repo") || cmd.equals("repos") || cmd.equals("repository")) return cmdRepo(args);
        if (cmd.equals("doctor")) return cmdDoctor();
        throw new PkgException("unknown command '" + cmd + "' (try: pkg help)");
    }

    void help() {
        out.println("Abtin pkg " + VERSION + " - package manager for the Abtin terminal");
        out.println("");
        out.println("Usage: pkg <command> [options] [args]");
        out.println("");
        out.println("  update                      refresh package lists from all repositories");
        out.println("  search <text>               search names and descriptions");
        out.println("  show <pkg>                  show package details");
        out.println("  list-all | list-installed   list available / installed packages");
        out.println("  install <pkg|file|url>...   install packages (dependencies are resolved)");
        out.println("  reinstall <pkg>...          reinstall packages");
        out.println("  remove <pkg>...             remove packages");
        out.println("  autoremove                  remove no longer needed dependencies");
        out.println("  upgrade                     upgrade all installed packages");
        out.println("  files <pkg>                 list files of an installed package");
        out.println("  owns <path>                 find the package that owns a file");
        out.println("  clean                       delete downloaded package files");
        out.println("  repo list|add|remove        manage repositories");
        out.println("  doctor                      diagnose the environment");
        out.println("");
        out.println("Options: -y (no questions)  --force  --no-deps  --reinstall");
        out.println("");
        out.println("Prefix: " + prefix.getPath());
        out.println("Note: Android 10+ blocks running programs from app storage, so native");
        out.println("binaries are started through the system linker; scripts run with sh.");
    }

    // ------------------------------------------------------------------ repos

    static final class Repo {
        String name, url, dist, comp;
    }

    List<Repo> loadRepos() throws IOException {
        List<Repo> repos = new ArrayList<Repo>();
        File f = new File(pkgEtc, "repos.list");
        if (!f.exists()) return repos;
        for (String line : readLines(f)) {
            String t = line.trim();
            if (t.length() == 0 || t.startsWith("#")) continue;
            String[] p = t.split("\\s+");
            if (p.length < 2) continue;
            Repo r = new Repo();
            r.name = p[0];
            r.url = stripSlash(p[1]);
            if (p.length >= 4) { r.dist = p[2]; r.comp = p[3]; }
            repos.add(r);
        }
        return repos;
    }

    void saveRepos(List<Repo> repos) throws IOException {
        StringBuilder sb = new StringBuilder("# Abtin pkg repositories: name url [dist component]\n");
        for (Repo r : repos) {
            sb.append(r.name).append(' ').append(r.url);
            if (r.dist != null) sb.append(' ').append(r.dist).append(' ').append(r.comp);
            sb.append('\n');
        }
        writeText(new File(pkgEtc, "repos.list"), sb.toString());
    }

    static String stripSlash(String s) {
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    String indexUrl(Repo r, String suffix) {
        if (r.dist != null) return r.url + "/dists/" + r.dist + "/" + r.comp + "/binary-" + arch + "/Packages" + suffix;
        return r.url + "/Packages" + suffix;
    }

    int cmdRepo(List<String> a) throws Exception {
        String sub = a.isEmpty() ? "list" : a.get(0);
        List<Repo> repos = loadRepos();
        if (sub.equals("list")) {
            out.println("builtin  (offline, bundled)");
            for (Repo r : repos) {
                out.println(r.name + "  " + r.url + (r.dist != null ? "  " + r.dist + " " + r.comp : ""));
            }
            return 0;
        }
        if (sub.equals("add")) {
            if (a.size() != 3 && a.size() != 5) throw new PkgException("usage: pkg repo add <name> <url> [dist component]");
            String name = a.get(1), url = a.get(2);
            if (!name.matches("[A-Za-z0-9._-]+") || name.equals("builtin")) throw new PkgException("invalid repository name");
            if (!url.matches("(?i)(https?|file)://\\S+")) throw new PkgException("url must start with http://, https:// or file://");
            for (Repo r : repos) if (r.name.equals(name)) throw new PkgException("repository '" + name + "' already exists");
            Repo r = new Repo();
            r.name = name; r.url = stripSlash(url);
            if (a.size() == 5) { r.dist = a.get(3); r.comp = a.get(4); }
            repos.add(r);
            saveRepos(repos);
            ok("added repository " + name + " - run: pkg update");
            return 0;
        }
        if (sub.equals("remove") || sub.equals("rm") || sub.equals("del")) {
            if (a.size() != 2) throw new PkgException("usage: pkg repo remove <name>");
            boolean found = false;
            for (int i = repos.size() - 1; i >= 0; i--) {
                if (repos.get(i).name.equals(a.get(1))) { repos.remove(i); found = true; }
            }
            if (!found) throw new PkgException("no such repository: " + a.get(1));
            saveRepos(repos);
            new File(listsDir, a.get(1) + ".Packages").delete();
            ok("removed repository " + a.get(1));
            return 0;
        }
        throw new PkgException("usage: pkg repo list|add|remove");
    }

    int cmdUpdate() throws Exception {
        List<Repo> repos = loadRepos();
        if (repos.isEmpty()) {
            out.println("No remote repositories configured (only the offline 'builtin' one).");
            out.println("Add one with: pkg repo add <name> <url> [dist component]");
            return 0;
        }
        int failed = 0;
        for (Repo r : repos) {
            byte[] data = null;
            String lastErr = "";
            String[] suffixes = {".gz", ""};
            for (String suf : suffixes) {
                String url = indexUrl(r, suf);
                try {
                    ByteArrayOutputStream bos = new ByteArrayOutputStream();
                    download(url, bos, null, false);
                    byte[] raw = bos.toByteArray();
                    data = suf.equals(".gz") ? gunzip(raw) : raw;
                    out.println("Get: " + url);
                    break;
                } catch (Exception e) {
                    lastErr = e.getMessage();
                }
            }
            if (data == null) {
                err("Err: " + r.name + " (" + lastErr + ")");
                failed++;
                continue;
            }
            writeBytes(new File(listsDir, r.name + ".Packages"), data);
            int n = parsePackages(new String(data, UTF8), r.name).size();
            out.println("Hit: " + r.name + " - " + n + " packages");
        }
        return failed == 0 ? 0 : 1;
    }

    // ------------------------------------------------------------------ package index

    static List<Pkg> parsePackages(String text, String repo) {
        List<Pkg> list = new ArrayList<Pkg>();
        Pkg cur = null;
        String lastKey = null;
        String[] lines = text.split("\r?\n", -1);
        for (String line : lines) {
            if (line.length() == 0) {
                if (cur != null && cur.name.length() > 0) list.add(cur);
                cur = null;
                lastKey = null;
                continue;
            }
            if (cur == null) { cur = new Pkg(); cur.repo = repo; }
            if ((line.charAt(0) == ' ' || line.charAt(0) == '\t') && lastKey != null) {
                if (lastKey.equals("description")) cur.desc += "\n" + line.trim();
                continue;
            }
            int i = line.indexOf(':');
            if (i <= 0) continue;
            String k = line.substring(0, i).trim().toLowerCase(Locale.ROOT);
            String v = line.substring(i + 1).trim();
            lastKey = k;
            if (k.equals("package")) cur.name = v;
            else if (k.equals("version")) cur.version = v;
            else if (k.equals("architecture")) cur.arch = v;
            else if (k.equals("depends") || k.equals("pre-depends")) cur.depends = cur.depends.length() == 0 ? v : cur.depends + ", " + v;
            else if (k.equals("description")) cur.desc = v;
            else if (k.equals("filename")) cur.filename = v;
            else if (k.equals("sha256")) cur.sha256 = v.toLowerCase(Locale.ROOT);
            else if (k.equals("homepage")) cur.homepage = v;
            else if (k.equals("section")) cur.section = v;
            else if (k.equals("size")) { try { cur.size = Long.parseLong(v); } catch (NumberFormatException ignored) { } }
        }
        if (cur != null && cur.name.length() > 0) list.add(cur);
        return list;
    }

    boolean archOk(String a) {
        return a == null || a.length() == 0 || a.equals("all") || a.equals("any") || a.equals(arch);
    }

    /** Best (highest version) candidate per package name across all sources. */
    Map<String, Pkg> loadAvailable() throws IOException {
        Map<String, Pkg> best = new TreeMap<String, Pkg>();
        List<Pkg> all = new ArrayList<Pkg>(builtinPackages());
        for (Repo r : loadRepos()) {
            File f = new File(listsDir, r.name + ".Packages");
            if (f.exists()) all.addAll(parsePackages(new String(readBytes(f), UTF8), r.name));
        }
        for (Pkg p : all) {
            if (!archOk(p.arch)) continue;
            Pkg cur = best.get(p.name);
            if (cur == null || compareVersions(p.version, cur.version) > 0) best.put(p.name, p);
        }
        return best;
    }

    Map<String, Pkg> loadInstalled() throws IOException {
        Map<String, Pkg> map = new TreeMap<String, Pkg>();
        File[] files = installedDir.listFiles();
        if (files == null) return map;
        for (File f : files) {
            if (!f.getName().endsWith(".info")) continue;
            List<Pkg> l = parsePackages(new String(readBytes(f), UTF8), "installed");
            if (l.isEmpty()) continue;
            Pkg p = l.get(0);
            String text = new String(readBytes(f), UTF8);
            p.manual = !text.contains("\nManual: no");
            map.put(p.name, p);
        }
        return map;
    }

    // ------------------------------------------------------------------ queries

    int cmdSearch(List<String> a) throws Exception {
        if (a.isEmpty()) throw new PkgException("usage: pkg search <text>");
        String q = a.get(0).toLowerCase(Locale.ROOT);
        Map<String, Pkg> avail = loadAvailable();
        Map<String, Pkg> inst = loadInstalled();
        int n = 0;
        for (Pkg p : avail.values()) {
            if (p.name.toLowerCase(Locale.ROOT).contains(q) || p.desc.toLowerCase(Locale.ROOT).contains(q)) {
                printLine(p, inst.get(p.name));
                n++;
            }
        }
        if (n == 0) out.println("No packages found.");
        return n == 0 ? 1 : 0;
    }

    void printLine(Pkg p, Pkg installed) {
        String mark = installed == null ? "" : (compareVersions(installed.version, p.version) < 0 ? " [upgradable]" : " [installed]");
        out.println(bold(p.name) + "/" + p.repo + " " + p.version + " " + p.arch + mark);
        out.println("  " + firstLine(p.desc));
    }

    int cmdListAll() throws Exception {
        Map<String, Pkg> inst = loadInstalled();
        for (Pkg p : loadAvailable().values()) printLine(p, inst.get(p.name));
        return 0;
    }

    int cmdListInstalled() throws Exception {
        Map<String, Pkg> inst = loadInstalled();
        if (inst.isEmpty()) out.println("No packages installed.");
        for (Pkg p : inst.values()) out.println(p.name + " " + p.version + " " + p.arch + (p.manual ? "" : " [auto]"));
        return 0;
    }

    int cmdShow(List<String> a) throws Exception {
        if (a.isEmpty()) throw new PkgException("usage: pkg show <pkg>");
        Map<String, Pkg> avail = loadAvailable();
        Map<String, Pkg> inst = loadInstalled();
        for (String name : a) {
            Pkg p = avail.get(name);
            Pkg i = inst.get(name);
            if (p == null && i == null) throw new PkgException("package not found: " + name);
            Pkg s = p != null ? p : i;
            out.println("Package: " + s.name);
            out.println("Version: " + s.version);
            out.println("Architecture: " + s.arch);
            if (s.depends.length() > 0) out.println("Depends: " + s.depends);
            if (s.size > 0) out.println("Size: " + humanSize(s.size));
            if (s.homepage.length() > 0) out.println("Homepage: " + s.homepage);
            out.println("Repository: " + s.repo);
            out.println("Installed: " + (i == null ? "no" : i.version));
            out.println("Description: " + s.desc.replace("\n", "\n  "));
            out.println("");
        }
        return 0;
    }

    int cmdFiles(List<String> a) throws Exception {
        if (a.size() != 1) throw new PkgException("usage: pkg files <pkg>");
        File f = new File(installedDir, a.get(0) + ".files");
        if (!f.exists()) throw new PkgException("package not installed: " + a.get(0));
        for (String l : readLines(f)) if (l.length() > 0) out.println(new File(prefix, l).getPath());
        return 0;
    }

    int cmdOwns(List<String> a) throws Exception {
        if (a.size() != 1) throw new PkgException("usage: pkg owns <path>");
        String path = a.get(0);
        String pre = prefix.getPath() + "/";
        String rel = path.startsWith(pre) ? path.substring(pre.length()) : path;
        String owner = ownerMap().get(rel);
        if (owner == null) { out.println("no package owns " + path); return 1; }
        out.println(owner);
        return 0;
    }

    int cmdClean() {
        long freed = 0;
        File[] fs = cacheDir.listFiles();
        if (fs != null) for (File f : fs) { freed += f.length(); f.delete(); }
        ok("cache cleaned (" + humanSize(freed) + ")");
        return 0;
    }

    int cmdDoctor() throws Exception {
        out.println("pkg " + VERSION);
        out.println("prefix:        " + prefix.getPath() + (prefix.isDirectory() ? "" : "  [MISSING]"));
        out.println("architecture:  " + arch + "  (os.arch=" + System.getProperty("os.arch") + ")");
        String linker = new File("/system/bin/linker64").exists() ? "/system/bin/linker64"
                : new File("/system/bin/linker").exists() ? "/system/bin/linker" : "none";
        out.println("linker:        " + linker);
        out.println("shell:         " + (new File("/system/bin/sh").exists() ? "/system/bin/sh" : "none"));
        out.println("repositories:  " + loadRepos().size() + " remote + builtin");
        out.println("installed:     " + loadInstalled().size() + " packages");
        out.println("free space:    " + humanSize(prefix.getUsableSpace()));
        out.println("writable:      " + (prefix.canWrite() ? "yes" : "NO"));
        out.println("xz support:    " + (classExists("org.tukaani.xz.XZInputStream") ? "yes" : "no"));
        out.println("bzip2 support: " + (classExists("org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream") ? "yes" : "no"));
        return 0;
    }

    // ------------------------------------------------------------------ install

    int cmdInstall(List<String> args) throws Exception {
        if (args.isEmpty()) throw new PkgException("usage: pkg install <package|file|url>...");
        List<String> names = new ArrayList<String>();
        List<String> locals = new ArrayList<String>();
        for (String a : args) {
            if (isLocalSpec(a)) locals.add(a); else names.add(a);
        }
        if (!names.isEmpty()) {
            Map<String, Pkg> avail = loadAvailable();
            Map<String, Pkg> inst = loadInstalled();
            List<Pkg> plan = new ArrayList<Pkg>();
            Set<String> planned = new HashSet<String>();
            Set<String> requested = new HashSet<String>(names);
            for (String n : names) {
                Pkg p = avail.get(n);
                if (p == null) {
                    if (inst.containsKey(n)) throw new PkgException(n + " is installed but not in any repository (run: pkg update)");
                    throw new PkgException("package '" + n + "' not found (try: pkg update, pkg search " + n + ")");
                }
                resolve(p, avail, inst, plan, planned, new ArrayList<String>(), requested);
            }
            if (plan.isEmpty()) {
                for (String n : names) out.println(n + " is already the newest version (" + inst.get(n).version + ").");
                if (locals.isEmpty()) return 0;
            } else {
                printPlan(plan, inst, requested);
                if (!confirm("Continue?")) { out.println("Aborted."); return 1; }
                for (Pkg p : plan) {
                    File f = fetch(p);
                    installArchive(f, p, requested.contains(p.name));
                }
            }
        }
        for (String l : locals) {
            File f = l.matches("(?i)(https?|file)://.*") ? fetchUrl(l) : new File(l);
            if (!f.isFile()) throw new PkgException("file not found: " + l);
            installArchive(f, null, true);
        }
        return 0;
    }

    boolean isLocalSpec(String a) {
        if (a.matches("(?i)(https?|file)://.*")) return true;
        if (a.contains("/") || a.endsWith(".deb") || a.endsWith(".tar.gz") || a.endsWith(".tgz")
                || a.endsWith(".tar") || a.endsWith(".zip") || a.endsWith(".tar.xz")) {
            return new File(a).isFile();
        }
        return false;
    }

    /** DFS dependency resolution; adds dependencies before dependents. */
    void resolve(Pkg p, Map<String, Pkg> avail, Map<String, Pkg> inst, List<Pkg> plan, Set<String> planned,
                 List<String> stack, Set<String> requested) throws PkgException {
        if (planned.contains(p.name)) return;
        if (stack.contains(p.name)) return; // dependency cycle: already being resolved
        Pkg have = inst.get(p.name);
        boolean explicit = requested.contains(p.name);
        if (have != null && compareVersions(have.version, p.version) >= 0 && !(reinstall && explicit)) {
            if (explicit && !have.manual) { try { markManual(p.name); } catch (IOException e) { throw new PkgException(e.getMessage()); } }
            return;
        }
        stack.add(p.name);
        if (!noDeps) {
            for (String[] alt : parseDepends(p.depends)) {
                // alt = name, op, version
                String dn = alt[0];
                Pkg di = inst.get(dn);
                if (di != null && versionOk(di.version, alt[1], alt[2])) continue;
                Pkg da = avail.get(dn);
                if (da == null) {
                    if (di != null) continue; // installed (constraint cannot be satisfied by repo): keep going
                    if (force) { err("warning: dependency '" + dn + "' of " + p.name + " not found"); continue; }
                    throw new PkgException("dependency '" + dn + "' of " + p.name + " is not available (use --force to ignore)");
                }
                resolve(da, avail, inst, plan, planned, stack, requested);
            }
        }
        stack.remove(stack.size() - 1);
        planned.add(p.name);
        plan.add(p);
    }

    void printPlan(List<Pkg> plan, Map<String, Pkg> inst, Set<String> requested) {
        StringBuilder add = new StringBuilder(), up = new StringBuilder();
        long dl = 0;
        for (Pkg p : plan) {
            Pkg i = inst.get(p.name);
            String label = p.name + " (" + p.version + ")";
            if (i != null) up.append(' ').append(label); else add.append(' ').append(label);
            if (p.builtin == null) dl += p.size;
        }
        if (add.length() > 0) out.println("New packages:" + add);
        if (up.length() > 0) out.println("Upgraded/reinstalled:" + up);
        if (dl > 0) out.println("Download size: " + humanSize(dl));
    }

    boolean confirm(String q) throws IOException {
        if (yes) return true;
        out.print(q + " [Y/n] ");
        out.flush();
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in, UTF8));
        String line = r.readLine();
        if (line == null) return false;
        line = line.trim().toLowerCase(Locale.ROOT);
        return line.length() == 0 || line.equals("y") || line.equals("yes");
    }

    File fetch(Pkg p) throws Exception {
        if (p.builtin != null) return null;
        Repo repo = null;
        for (Repo r : loadRepos()) if (r.name.equals(p.repo)) repo = r;
        if (repo == null) throw new PkgException("repository '" + p.repo + "' of " + p.name + " no longer configured");
        if (p.filename.length() == 0) throw new PkgException("package " + p.name + " has no Filename in the index");
        String url = p.filename.matches("(?i)(https?|file)://.*") ? p.filename : repo.url + "/" + p.filename;
        String base = url.substring(url.lastIndexOf('/') + 1);
        File dest = new File(cacheDir, safeName(p.name + "_" + p.version + "_" + base));
        if (dest.isFile() && (p.sha256.length() == 0 || p.sha256.equals(sha256(dest)))) return dest;
        File part = new File(cacheDir, dest.getName() + ".part");
        FileOutputStream fos = new FileOutputStream(part);
        try {
            download(url, fos, p.name, true);
        } catch (IOException e) {
            closeQuiet(fos);
            part.delete();
            throw new PkgException("download failed for " + p.name + ": " + e.getMessage());
        }
        fos.close();
        if (p.sha256.length() > 0) {
            String got = sha256(part);
            if (!got.equals(p.sha256)) {
                part.delete();
                throw new PkgException("checksum mismatch for " + p.name + " (expected " + p.sha256 + ", got " + got + ")");
            }
        } else if (!force) {
            err("warning: " + p.name + " has no SHA256 in the index; integrity not verified");
        }
        if (dest.exists()) dest.delete();
        if (!part.renameTo(dest)) throw new PkgException("cannot move download into cache");
        return dest;
    }

    File fetchUrl(String url) throws Exception {
        String base = url.substring(url.lastIndexOf('/') + 1);
        if (base.length() == 0) base = "package.bin";
        File dest = new File(cacheDir, safeName(base));
        FileOutputStream fos = new FileOutputStream(dest);
        try {
            download(url, fos, base, true);
        } catch (IOException e) {
            closeQuiet(fos);
            dest.delete();
            throw new PkgException("download failed: " + e.getMessage());
        }
        fos.close();
        return dest;
    }

    static String safeName(String s) {
        return s.replaceAll("[^A-Za-z0-9._+~-]", "_");
    }

    // ------------------------------------------------------------------ download

    void download(String spec, OutputStream sink, String label, boolean progress) throws IOException {
        String url = spec;
        for (int hop = 0; hop < 6; hop++) {
            URL u = new URL(url);
            if (u.getProtocol().equals("file")) {
                InputStream in = new FileInputStream(new File(u.getPath()));
                try { copy(in, sink, -1, label, progress); } finally { in.close(); }
                return;
            }
            if (!u.getProtocol().equals("http") && !u.getProtocol().equals("https")) throw new IOException("unsupported protocol " + u.getProtocol());
            HttpURLConnection c = (HttpURLConnection) u.openConnection();
            c.setInstanceFollowRedirects(false);
            c.setConnectTimeout(20000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent", "AbtinPkg/" + VERSION);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = c.getHeaderField("Location");
                c.disconnect();
                if (loc == null) throw new IOException("redirect without Location");
                url = new URL(u, loc).toString();
                continue;
            }
            if (code != 200) { c.disconnect(); throw new IOException("HTTP " + code + " for " + url); }
            long len = c.getContentLengthLong();
            InputStream in = c.getInputStream();
            try { copy(in, sink, len, label, progress); } finally { in.close(); c.disconnect(); }
            return;
        }
        throw new IOException("too many redirects");
    }

    void copy(InputStream in, OutputStream sink, long total, String label, boolean progress) throws IOException {
        byte[] buf = new byte[32768];
        long done = 0, lastPrint = 0;
        int n;
        while ((n = in.read(buf)) > 0) {
            sink.write(buf, 0, n);
            done += n;
            if (progress && ansi && System.nanoTime() - lastPrint > 150000000L) {
                lastPrint = System.nanoTime();
                out.print("\r" + label + "  " + humanSize(done) + (total > 0 ? " / " + humanSize(total) + "  " + (done * 100 / total) + "%" : "") + "\u001b[K");
                out.flush();
            }
        }
        if (progress) {
            if (ansi) out.print("\r\u001b[K");
            out.println("Downloaded " + label + " (" + humanSize(done) + ")");
        }
    }

    // ------------------------------------------------------------------ archives

    /** Result of reading a package archive. */
    static final class Extracted {
        File stage;
        List<String> files = new ArrayList<String>();   // relative, files + symlinks
        List<String> dirs = new ArrayList<String>();    // relative dirs (no trailing slash)
        Map<String, String> control = new HashMap<String, String>();
        Map<String, byte[]> scripts = new HashMap<String, byte[]>();
    }

    void installArchive(File archive, Pkg meta, boolean manual) throws Exception {
        File stage = new File(stageRoot, "s" + System.nanoTime());
        mkdirs(stage);
        try {
            Extracted ex;
            if (meta != null && meta.builtin != null) ex = extractBuiltin(meta.builtin, stage);
            else ex = extractFile(archive, stage);
            Pkg p = new Pkg();
            if (meta != null) {
                p.name = meta.name; p.version = meta.version; p.arch = meta.arch; p.depends = meta.depends;
                p.desc = meta.desc; p.homepage = meta.homepage; p.repo = meta.repo;
            }
            String cn = ex.control.get("package");
            if (cn != null && meta == null) {
                p.name = cn;
                p.version = orDefault(ex.control.get("version"), "0");
                p.arch = orDefault(ex.control.get("architecture"), "all");
                p.depends = orDefault(ex.control.get("depends"), "");
                p.desc = orDefault(ex.control.get("description"), "");
                p.repo = "local";
            }
            if (p.name.length() == 0) {
                String base = archive.getName().replaceAll("\\.(deb|tar\\.gz|tgz|tar\\.xz|tar\\.bz2|tar|zip)$", "");
                String[] parts = base.split("_");
                p.name = parts[0].replaceAll("-[0-9][^-]*$", "");
                p.version = parts.length > 1 ? parts[1] : "0";
                p.arch = parts.length > 2 ? parts[2] : "all";
                p.repo = "local";
                p.desc = "Installed from " + archive.getName();
            }
            if (!p.name.matches("[A-Za-z0-9][A-Za-z0-9+._-]*")) throw new PkgException("invalid package name '" + p.name + "'");
            if (!archOk(p.arch) && !force) throw new PkgException(p.name + " is built for " + p.arch + ", this device is " + arch + " (use --force)");
            if (!noDeps && meta == null) {
                Map<String, Pkg> inst = loadInstalled();
                Map<String, Pkg> avail = loadAvailable();
                for (String[] alt : parseDepends(p.depends)) {
                    if (!inst.containsKey(alt[0]) && !avail.containsKey(alt[0]))
                        err("warning: dependency '" + alt[0] + "' of " + p.name + " is not installed");
                }
            }
            commit(p, ex, manual);
        } finally {
            deleteRecursive(stage);
        }
    }

    Extracted extractBuiltin(Builtin b, File stage) throws IOException {
        Extracted ex = new Extracted();
        ex.stage = stage;
        Set<String> madeDirs = new LinkedHashSet<String>();
        for (Map.Entry<String, String> e : b.files.entrySet()) {
            String rel = e.getKey();
            File dest = new File(stage, rel);
            mkdirs(dest.getParentFile());
            writeBytes(dest, e.getValue().getBytes(UTF8));
            chmod(dest, b.executable.contains(rel) ? 0755 : 0644);
            ex.files.add(rel);
            String d = rel;
            int i;
            while ((i = d.lastIndexOf('/')) > 0) { d = d.substring(0, i); madeDirs.add(d); }
        }
        ex.dirs.addAll(madeDirs);
        return ex;
    }

    Extracted extractFile(File f, File stage) throws IOException, PkgException {
        Extracted ex = new Extracted();
        ex.stage = stage;
        InputStream raw = new BufferedInputStream(new FileInputStream(f), 65536);
        try {
            raw.mark(8);
            byte[] magic = new byte[8];
            int n = readUpTo(raw, magic);
            raw.reset();
            if (n >= 8 && new String(magic, 0, 8, UTF8).equals("!<arch>\n")) {
                readDeb(raw, ex);
            } else if (n >= 4 && magic[0] == 'P' && magic[1] == 'K') {
                readZip(raw, ex);
            } else {
                readTar(decompress(raw), ex);
            }
        } finally {
            raw.close();
        }
        return ex;
    }

    void readDeb(InputStream in, Extracted ex) throws IOException, PkgException {
        byte[] sig = new byte[8];
        readFully(in, sig, 8);
        boolean sawData = false;
        byte[] hdr = new byte[60];
        while (true) {
            int got = readUpTo(in, hdr);
            if (got == 0) break;
            if (got < 60) throw new PkgException("corrupt .deb (truncated ar header)");
            String name = new String(hdr, 0, 16, UTF8).trim();
            if (name.endsWith("/")) name = name.substring(0, name.length() - 1);
            long size;
            try { size = Long.parseLong(new String(hdr, 48, 10, UTF8).trim()); }
            catch (NumberFormatException e) { throw new PkgException("corrupt .deb (bad member size)"); }
            BoundedInputStream member = new BoundedInputStream(in, size);
            if (name.startsWith("control.tar")) {
                readControlTar(decompress(new BufferedInputStream(member)), ex);
            } else if (name.startsWith("data.tar")) {
                readTar(decompress(new BufferedInputStream(member)), ex);
                sawData = true;
            }
            member.drain();
            if ((size & 1) == 1) skipFully(in, 1);
        }
        if (!sawData) throw new PkgException("corrupt .deb (no data.tar member)");
    }

    void readControlTar(InputStream in, Extracted ex) throws IOException {
        TarReader tr = new TarReader(in);
        TarEntry e;
        while ((e = tr.next()) != null) {
            if (e.type != '0' && e.type != 0) { tr.skipData(); continue; }
            String n = e.name;
            while (n.startsWith("./")) n = n.substring(2);
            byte[] data = tr.readData();
            if (n.equals("control")) {
                for (Pkg p : parsePackages(new String(data, UTF8) + "\n\n", "local")) {
                    ex.control.put("package", p.name);
                    ex.control.put("version", p.version);
                    ex.control.put("architecture", p.arch);
                    ex.control.put("depends", p.depends);
                    ex.control.put("description", p.desc);
                    break;
                }
            } else if (n.equals("postinst") || n.equals("prerm") || n.equals("postrm")) {
                ex.scripts.put(n, data);
            }
        }
    }

    void readZip(InputStream in, Extracted ex) throws IOException, PkgException {
        ZipInputStream zin = new ZipInputStream(in);
        ZipEntry ze;
        Set<String> dirs = new LinkedHashSet<String>();
        while ((ze = zin.getNextEntry()) != null) {
            String rel = mapPath(ze.getName());
            if (rel == null) continue;
            File dest = new File(ex.stage, rel);
            checkInside(ex.stage, dest);
            if (ze.isDirectory()) { mkdirs(dest); dirs.add(rel); continue; }
            mkdirs(dest.getParentFile());
            FileOutputStream fos = new FileOutputStream(dest);
            try { pipe(zin, fos); } finally { fos.close(); }
            chmod(dest, 0644 | (looksExecutable(rel, dest) ? 0111 : 0));
            ex.files.add(rel);
            addParents(dirs, rel);
        }
        ex.dirs.addAll(dirs);
    }

    static boolean looksExecutable(String rel, File f) {
        if (rel.startsWith("bin/") || rel.startsWith("libexec/")) return true;
        return false;
    }

    static void addParents(Set<String> dirs, String rel) {
        String d = rel;
        int i;
        while ((i = d.lastIndexOf('/')) > 0) { d = d.substring(0, i); dirs.add(d); }
    }

    void readTar(InputStream in, Extracted ex) throws IOException, PkgException {
        TarReader tr = new TarReader(in);
        TarEntry e;
        Set<String> dirs = new LinkedHashSet<String>();
        Set<String> seen = new HashSet<String>();
        while ((e = tr.next()) != null) {
            String rel = mapPath(e.name);
            boolean isControlDir = e.name.startsWith("DEBIAN/") || e.name.startsWith("./DEBIAN/");
            if (isControlDir) {
                String n = e.name.replaceFirst("^(\\./)?DEBIAN/", "");
                if (e.type == '0' || e.type == 0) {
                    byte[] data = tr.readData();
                    if (n.equals("control")) {
                        for (Pkg p : parsePackages(new String(data, UTF8) + "\n\n", "local")) {
                            ex.control.put("package", p.name);
                            ex.control.put("version", p.version);
                            ex.control.put("architecture", p.arch);
                            ex.control.put("depends", p.depends);
                            ex.control.put("description", p.desc);
                            break;
                        }
                    } else if (n.equals("postinst") || n.equals("prerm") || n.equals("postrm")) {
                        ex.scripts.put(n, data);
                    }
                } else tr.skipData();
                continue;
            }
            if (rel == null) { tr.skipData(); continue; }
            File dest = new File(ex.stage, rel);
            checkInside(ex.stage, dest);
            switch (e.type) {
                case '5':
                    mkdirs(dest);
                    chmod(dest, (e.mode & 0777) | 0700);
                    dirs.add(rel);
                    tr.skipData();
                    break;
                case '2': {
                    mkdirs(dest.getParentFile());
                    checkInside(ex.stage, dest.getParentFile());
                    deleteRecursive(dest);
                    symlink(rewriteLink(e.linkName), dest);
                    ex.files.add(rel);
                    addParents(dirs, rel);
                    tr.skipData();
                    break;
                }
                case '1': {
                    String target = mapPath(e.linkName);
                    if (target == null) throw new PkgException("bad hard link target " + e.linkName);
                    File src = new File(ex.stage, target);
                    mkdirs(dest.getParentFile());
                    copyFile(src, dest);
                    chmod(dest, e.mode & 0777);
                    ex.files.add(rel);
                    addParents(dirs, rel);
                    tr.skipData();
                    break;
                }
                case '0':
                case 0: {
                    mkdirs(dest.getParentFile());
                    checkInside(ex.stage, dest.getParentFile());
                    if (dest.exists() || isLink(dest)) dest.delete();
                    FileOutputStream fos = new FileOutputStream(dest);
                    try { tr.copyData(fos); } finally { fos.close(); }
                    fixShebang(dest);
                    chmod(dest, (e.mode & 0777) | 0600);
                    if (seen.add(rel)) ex.files.add(rel);
                    addParents(dirs, rel);
                    break;
                }
                default:
                    tr.skipData(); // devices, fifos, pax globals etc.
            }
        }
        ex.dirs.addAll(dirs);
    }

    /** Map an archive path into a path relative to $PREFIX, or null to skip it. */
    static String mapPath(String raw) throws PkgException {
        String p = raw.replace('\\', '/');
        while (p.startsWith("./") || p.startsWith("/")) p = p.startsWith("./") ? p.substring(2) : p.substring(1);
        while (p.endsWith("/")) p = p.substring(0, p.length() - 1);
        if (p.length() == 0 || p.equals(".")) return null;
        if (p.equals("data") || p.equals("data/data") || p.equals("data/data/com.termux")
                || p.equals("data/data/com.termux/files") || p.equals(TERMUX_PREFIX)) return null;
        if (p.startsWith(TERMUX_PREFIX + "/")) p = p.substring(TERMUX_PREFIX.length() + 1);
        else if (p.startsWith(TERMUX_HOME)) return null;
        else if (p.equals("usr")) return null;
        else if (p.startsWith("usr/")) p = p.substring(4);
        if (p.startsWith("data/data/")) return null;
        for (String seg : p.split("/")) {
            if (seg.equals("..")) throw new PkgException("unsafe path in archive: " + raw);
        }
        return p.length() == 0 ? null : p;
    }

    String rewriteLink(String target) {
        String t = target;
        String tp = "/" + TERMUX_PREFIX;
        if (t.equals(tp)) return prefix.getPath();
        if (t.startsWith(tp + "/")) return prefix.getPath() + t.substring(tp.length());
        return t;
    }

    /** Rewrites a Termux prefix inside the first line (#!) of text scripts. */
    void fixShebang(File f) throws IOException {
        if (f.length() < 4 || f.length() > 4 * 1024 * 1024) return;
        byte[] data = readBytes(f);
        if (data[0] != '#' || data[1] != '!') return;
        int nl = 0;
        while (nl < data.length && data[nl] != '\n') nl++;
        String first = new String(data, 0, nl, UTF8);
        String tp = "/" + TERMUX_PREFIX;
        if (!first.contains(tp)) return;
        String repl = first.replace(tp, prefix.getPath());
        String interp = repl.substring(2).trim().split("\\s+")[0];
        String ib = interp.substring(interp.lastIndexOf('/') + 1);
        if (interp.startsWith(prefix.getPath() + "/") && (ib.equals("sh") || ib.equals("bash") || ib.equals("ash") || ib.equals("dash")))
            repl = "#!/system/bin/sh" + repl.substring(2 + interp.length());
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bos.write(repl.getBytes(UTF8));
        bos.write(data, nl, data.length - nl);
        writeBytes(f, bos.toByteArray());
    }

    // ------------------------------------------------------------------ commit / remove

    Map<String, String> ownerMap() throws IOException {
        Map<String, String> m = new HashMap<String, String>();
        File[] fs = installedDir.listFiles();
        if (fs == null) return m;
        for (File f : fs) {
            if (!f.getName().endsWith(".files")) continue;
            String pkg = f.getName().substring(0, f.getName().length() - 6);
            for (String l : readLines(f)) if (l.length() > 0 && !l.endsWith("/")) m.put(l, pkg);
        }
        return m;
    }

    void commit(Pkg p, Extracted ex, boolean manual) throws Exception {
        Map<String, String> owners = ownerMap();
        List<String> oldFiles = new ArrayList<String>();
        File oldList = new File(installedDir, p.name + ".files");
        if (oldList.exists()) for (String l : readLines(oldList)) if (l.length() > 0) oldFiles.add(l);
        boolean upgrade = new File(installedDir, p.name + ".info").exists();

        // 1. conflict check
        for (String rel : ex.files) {
            String owner = owners.get(rel);
            if (owner != null && !owner.equals(p.name) && !force)
                throw new PkgException("file " + rel + " is already provided by '" + owner + "' (use --force)");
            File dest = new File(prefix, rel);
            if (owner == null && (dest.exists() || isLink(dest)) && !dest.isDirectory() && !force)
                throw new PkgException("file " + rel + " exists and is not owned by any package (use --force)");
            if (dest.isDirectory() && !isLink(dest))
                throw new PkgException("cannot replace directory " + rel + " with a file");
        }

        // maintainer script: prerm of the old version is not run on upgrade (dpkg runs it; we keep it simple)
        out.println((upgrade ? "Upgrading " : "Installing ") + p.name + " (" + p.version + ")");

        // 2. move into place with rollback
        File backup = new File(stage(ex), "backup");
        mkdirs(backup);
        List<String[]> backups = new ArrayList<String[]>(); // rel, backupName
        List<String> placed = new ArrayList<String>();
        try {
            for (String d : ex.dirs) mkdirs(new File(prefix, d));
            int bi = 0;
            for (String rel : ex.files) {
                File src = new File(ex.stage, rel);
                File dest = new File(prefix, rel);
                mkdirs(dest.getParentFile());
                if (dest.exists() || isLink(dest)) {
                    File b = new File(backup, "b" + (bi++));
                    if (!dest.renameTo(b)) throw new IOException("cannot back up " + rel);
                    backups.add(new String[]{rel, b.getName()});
                }
                if (!src.renameTo(dest)) {
                    if (isLink(src)) throw new IOException("cannot move symlink " + rel);
                    copyFile(src, dest);
                    chmod(dest, modeOf(src));
                }
                placed.add(rel);
            }
        } catch (Exception e) {
            for (String rel : placed) new File(prefix, rel).delete();
            for (String[] b : backups) new File(backup, b[1]).renameTo(new File(prefix, b[0]));
            throw new PkgException("install of " + p.name + " failed, rolled back: " + e.getMessage());
        }

        // 3. remove files that belonged to the previous version but not to the new one
        Set<String> newSet = new HashSet<String>(ex.files);
        for (String old : oldFiles) {
            if (old.endsWith("/") || newSet.contains(old)) continue;
            new File(prefix, old).delete();
        }

        // 4. database
        List<String> list = new ArrayList<String>(ex.files);
        for (String d : ex.dirs) list.add(d + "/");
        writeText(new File(installedDir, p.name + ".files"), joinLines(list));
        StringBuilder info = new StringBuilder();
        info.append("Package: ").append(p.name).append('\n');
        info.append("Version: ").append(p.version).append('\n');
        info.append("Architecture: ").append(p.arch).append('\n');
        if (p.depends.length() > 0) info.append("Depends: ").append(p.depends).append('\n');
        if (p.homepage.length() > 0) info.append("Homepage: ").append(p.homepage).append('\n');
        info.append("Description: ").append(p.desc.replace("\n", "\n ")).append('\n');
        info.append("Manual: ").append(manual || (upgrade && isManual(p.name)) ? "yes" : "no").append('\n');
        writeText(new File(installedDir, p.name + ".info"), info.toString());
        for (String s : new String[]{"postinst", "prerm", "postrm"}) {
            File sf = new File(installedDir, p.name + "." + s);
            byte[] data = ex.scripts.get(s);
            if (data != null) { writeBytes(sf, data); } else sf.delete();
        }
        File post = new File(installedDir, p.name + ".postinst");
        if (post.exists()) runScript(post, p.name, "postinst");
        regenAliases(Collections.<String>emptySet());
        ok(p.name + " " + p.version + " installed");
    }

    File stage(Extracted ex) { return ex.stage; }

    boolean isManual(String name) throws IOException {
        File f = new File(installedDir, name + ".info");
        if (!f.exists()) return true;
        return !new String(readBytes(f), UTF8).contains("\nManual: no");
    }

    void markManual(String name) throws IOException {
        File f = new File(installedDir, name + ".info");
        if (!f.exists()) return;
        String t = new String(readBytes(f), UTF8).replace("\nManual: no", "\nManual: yes");
        writeText(f, t);
    }

    void runScript(File script, String pkg, String phase) {
        try {
            String sh = new File("/system/bin/sh").exists() ? "/system/bin/sh" : "sh";
            ProcessBuilder pb = new ProcessBuilder(sh, script.getPath(), phase.equals("postinst") ? "configure" : "remove");
            pb.environment().put("PREFIX", prefix.getPath());
            pb.environment().put("PKG_NAME", pkg);
            pb.redirectErrorStream(true);
            pb.directory(prefix);
            Process pr = pb.start();
            InputStream is = pr.getInputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = is.read(buf)) > 0) out.write(buf, 0, n);
            int rc = pr.waitFor();
            if (rc != 0) err("warning: " + phase + " script of " + pkg + " exited with " + rc);
        } catch (Exception e) {
            err("warning: could not run " + phase + " of " + pkg + ": " + e.getMessage());
        }
    }

    int cmdRemove(List<String> names) throws Exception {
        if (names.isEmpty()) throw new PkgException("usage: pkg remove <package>...");
        Map<String, Pkg> inst = loadInstalled();
        for (String n : names) if (!inst.containsKey(n)) throw new PkgException("package '" + n + "' is not installed");
        Set<String> removing = new LinkedHashSet<String>(names);
        // reverse dependencies
        for (Pkg p : inst.values()) {
            if (removing.contains(p.name)) continue;
            for (String d : p.depNames()) {
                if (removing.contains(d) && !force)
                    throw new PkgException("cannot remove " + d + ": required by " + p.name + " (remove it first or use --force)");
            }
        }
        out.println("Will remove: " + joinSp(removing));
        if (!confirm("Continue?")) { out.println("Aborted."); return 1; }
        for (String n : removing) removeOne(n);
        regenAliases(removedBins);
        removedBins.clear();
        return 0;
    }

    final Set<String> removedBins = new HashSet<String>();

    void removeOne(String name) throws IOException {
        File prerm = new File(installedDir, name + ".prerm");
        if (prerm.exists()) runScript(prerm, name, "prerm");
        File listFile = new File(installedDir, name + ".files");
        List<String> dirs = new ArrayList<String>();
        if (listFile.exists()) {
            for (String l : readLines(listFile)) {
                if (l.length() == 0) continue;
                if (l.endsWith("/")) { dirs.add(l.substring(0, l.length() - 1)); continue; }
                if (l.startsWith("bin/") && l.indexOf('/', 4) < 0) removedBins.add(l.substring(4));
                File f = new File(prefix, l);
                if (f.exists() || isLink(f)) f.delete();
            }
        }
        // remove empty directories, deepest first; never the top-level directories of the prefix
        Collections.sort(dirs, new Comparator<String>() {
            public int compare(String a, String b) { return b.length() - a.length(); }
        });
        for (String d : dirs) {
            if (d.indexOf('/') < 0) continue;
            File df = new File(prefix, d);
            String[] kids = df.list();
            if (df.isDirectory() && !isLink(df) && kids != null && kids.length == 0) df.delete();
        }
        File postrm = new File(installedDir, name + ".postrm");
        if (postrm.exists()) runScript(postrm, name, "postrm");
        listFile.delete();
        new File(installedDir, name + ".info").delete();
        new File(installedDir, name + ".postinst").delete();
        prerm.delete();
        postrm.delete();
        ok("removed " + name);
    }

    int cmdAutoremove() throws Exception {
        Map<String, Pkg> inst = loadInstalled();
        Set<String> needed = new HashSet<String>();
        List<String> work = new ArrayList<String>();
        for (Pkg p : inst.values()) if (p.manual) { needed.add(p.name); work.add(p.name); }
        while (!work.isEmpty()) {
            Pkg p = inst.get(work.remove(work.size() - 1));
            if (p == null) continue;
            for (String d : p.depNames()) if (inst.containsKey(d) && needed.add(d)) work.add(d);
        }
        List<String> drop = new ArrayList<String>();
        for (Pkg p : inst.values()) if (!needed.contains(p.name)) drop.add(p.name);
        if (drop.isEmpty()) { out.println("Nothing to remove."); return 0; }
        out.println("Will remove: " + joinSp(drop));
        if (!confirm("Continue?")) { out.println("Aborted."); return 1; }
        for (String n : drop) removeOne(n);
        regenAliases(removedBins);
        removedBins.clear();
        return 0;
    }

    int cmdUpgrade() throws Exception {
        Map<String, Pkg> avail = loadAvailable();
        Map<String, Pkg> inst = loadInstalled();
        List<Pkg> plan = new ArrayList<Pkg>();
        Set<String> planned = new HashSet<String>();
        Set<String> requested = new HashSet<String>();
        for (Pkg i : inst.values()) {
            Pkg a = avail.get(i.name);
            if (a != null && compareVersions(a.version, i.version) > 0) requested.add(i.name);
        }
        boolean oldReinstall = reinstall;
        reinstall = false;
        for (String n : requested) resolve(avail.get(n), avail, inst, plan, planned, new ArrayList<String>(), requested);
        reinstall = oldReinstall;
        if (plan.isEmpty()) { out.println("All packages are up to date."); return 0; }
        printPlan(plan, inst, requested);
        if (!confirm("Continue?")) { out.println("Aborted."); return 1; }
        for (Pkg p : plan) installArchive(fetch(p), p, inst.containsKey(p.name) ? isManual(p.name) : requested.contains(p.name));
        return 0;
    }

    // ------------------------------------------------------------------ shell integration

    /**
     * Writes $PREFIX/etc/aliases.sh: one alias per installed command in $PREFIX/bin.
     * Native ELF programs are started via the system linker (Android 10+ forbids execve from
     * app storage); scripts are run through their interpreter.
     */
    void regenAliases(Set<String> removed) throws IOException {
        File bin = new File(prefix, "bin");
        StringBuilder sb = new StringBuilder("# generated by pkg - do not edit\n");
        for (String r : removed) {
            if (validCmd(r) && !new File(bin, r).exists()) sb.append("unalias '").append(r).append("' 2>/dev/null\n");
        }
        File[] fs = bin.listFiles();
        if (fs != null) {
            Arrays_sort(fs);
            for (File f : fs) {
                String n = f.getName();
                if (!validCmd(n) || !f.isFile()) continue; // isFile follows symlinks
                String cmd = runnerFor(f);
                if (cmd == null) continue;
                sb.append("alias '").append(n).append("=").append(cmd).append(' ').append(f.getPath()).append("'\n");
            }
        }
        writeText(new File(etcDir, "aliases.sh"), sb.toString());
    }

    static void Arrays_sort(File[] fs) {
        java.util.Arrays.sort(fs, new Comparator<File>() {
            public int compare(File a, File b) { return a.getName().compareTo(b.getName()); }
        });
    }

    static boolean validCmd(String n) {
        return n.matches("[A-Za-z0-9][A-Za-z0-9._+-]*");
    }

    String runnerFor(File f) throws IOException {
        byte[] head = new byte[256];
        InputStream in = new FileInputStream(f);
        int n;
        try { n = readUpTo(in, head); } finally { in.close(); }
        if (n >= 4 && head[0] == 0x7f && head[1] == 'E' && head[2] == 'L' && head[3] == 'F') return "$ABTIN_LINKER";
        if (n >= 2 && head[0] == '#' && head[1] == '!') {
            int nl = 0;
            while (nl < n && head[nl] != '\n') nl++;
            String line = new String(head, 2, nl - 2, UTF8).trim();
            String[] parts = line.split("\\s+");
            String interp = parts.length > 0 ? parts[0] : "";
            if (interp.endsWith("/env") && parts.length > 1) interp = parts[1];
            String base = interp.substring(interp.lastIndexOf('/') + 1);
            if (base.equals("sh") || base.equals("bash") || base.equals("ash") || base.equals("dash") || base.equals("mksh") || base.length() == 0)
                return "/system/bin/sh";
            return base;
        }
        return "/system/bin/sh";
    }

    // ------------------------------------------------------------------ builtin repository

    List<Pkg> builtinPackages() {
        List<Pkg> l = new ArrayList<Pkg>();
        l.add(builtin("tree", "1.0.0", "Display a directory tree (shell implementation)", "",
                "bin/tree", TREE_SH));
        l.add(builtin("watch", "1.0.0", "Run a command repeatedly: watch [-n seconds] command...", "",
                "bin/watch", WATCH_SH));
        l.add(builtin("sysinfo", "1.0.0", "Show device, Android and storage information", "",
                "bin/sysinfo", SYSINFO_SH));
        l.add(builtin("abtin-tools", "1.0.0", "Meta package: tree, watch and sysinfo", "tree, watch, sysinfo",
                "share/doc/abtin-tools/README", "Abtin tools meta package.\n"));
        return l;
    }

    Pkg builtin(String name, String version, String desc, String depends, String path, String content) {
        Pkg p = new Pkg();
        p.name = name; p.version = version; p.desc = desc; p.depends = depends; p.repo = "builtin";
        p.arch = "all";
        Builtin b = new Builtin();
        b.files.put(path, content);
        if (path.startsWith("bin/")) b.executable.add(path);
        p.builtin = b;
        return p;
    }

    static final String TREE_SH =
            "#!/system/bin/sh\n"
                    + "# tree - list directories as a tree\n"
                    + "dir=\"${1:-.}\"\n"
                    + "[ -d \"$dir\" ] || { echo \"tree: $dir: not a directory\" >&2; exit 1; }\n"
                    + "echo \"$dir\"\n"
                    + "walk() {\n"
                    + "  _d=\"$1\"; _p=\"$2\"\n"
                    + "  for _f in \"$_d\"/* \"$_d\"/.[!.]*; do\n"
                    + "    [ -e \"$_f\" ] || [ -L \"$_f\" ] || continue\n"
                    + "    echo \"${_p}|-- ${_f##*/}\"\n"
                    + "    if [ -d \"$_f\" ] && [ ! -L \"$_f\" ]; then walk \"$_f\" \"${_p}|   \"; fi\n"
                    + "  done\n"
                    + "}\n"
                    + "walk \"$dir\" \"\"\n";

    static final String WATCH_SH =
            "#!/system/bin/sh\n"
                    + "# watch [-n seconds] command...\n"
                    + "n=2\n"
                    + "if [ \"$1\" = \"-n\" ]; then n=\"$2\"; shift 2; fi\n"
                    + "[ $# -gt 0 ] || { echo \"usage: watch [-n seconds] command...\" >&2; exit 1; }\n"
                    + "while :; do\n"
                    + "  printf '\\033[2J\\033[H'\n"
                    + "  echo \"Every ${n}s: $*\"\n"
                    + "  echo\n"
                    + "  eval \"$@\"\n"
                    + "  sleep \"$n\"\n"
                    + "done\n";

    static final String SYSINFO_SH =
            "#!/system/bin/sh\n"
                    + "g() { getprop \"$1\" 2>/dev/null; }\n"
                    + "echo \"Device:   $(g ro.product.manufacturer) $(g ro.product.model)\"\n"
                    + "echo \"Android:  $(g ro.build.version.release) (SDK $(g ro.build.version.sdk))\"\n"
                    + "echo \"ABI:      $(g ro.product.cpu.abi)\"\n"
                    + "echo \"Kernel:   $(uname -sr)\"\n"
                    + "echo \"Uptime:   $(uptime 2>/dev/null)\"\n"
                    + "echo \"Prefix:   ${PREFIX:-unset}\"\n"
                    + "df -h \"${HOME:-.}\" 2>/dev/null | tail -n 1 | while read a b c d e f; do echo \"Storage:  $c used of $b ($e)\"; done\n";

    // ------------------------------------------------------------------ versions & depends

    /** Depends field -> list of {name, op, version}; for alternatives the first one is used. */
    static List<String[]> parseDepends(String field) {
        List<String[]> res = new ArrayList<String[]>();
        if (field == null) return res;
        for (String part : field.split(",")) {
            String t = part.trim();
            if (t.length() == 0) continue;
            int bar = t.indexOf('|');
            if (bar >= 0) t = t.substring(0, bar).trim();
            String name = t, op = "", ver = "";
            int paren = t.indexOf('(');
            if (paren >= 0) {
                name = t.substring(0, paren).trim();
                int close = t.indexOf(')', paren);
                String c = t.substring(paren + 1, close > 0 ? close : t.length()).trim();
                int i = 0;
                while (i < c.length() && "<>=".indexOf(c.charAt(i)) >= 0) i++;
                op = c.substring(0, i);
                ver = c.substring(i).trim();
            }
            int colon = name.indexOf(':'); // "libc:any"
            if (colon > 0) name = name.substring(0, colon);
            if (name.length() > 0) res.add(new String[]{name, op, ver});
        }
        return res;
    }

    static boolean versionOk(String have, String op, String req) {
        if (op == null || op.length() == 0 || req == null || req.length() == 0) return true;
        int c = compareVersions(have, req);
        if (op.equals(">=") || op.equals(">>=")) return c >= 0;
        if (op.equals("<=") || op.equals("<<=")) return c <= 0;
        if (op.equals(">>") || op.equals(">")) return c > 0;
        if (op.equals("<<") || op.equals("<")) return c < 0;
        if (op.equals("=")) return c == 0;
        return true;
    }

    /** dpkg version comparison (epoch, upstream, revision). */
    static int compareVersions(String a, String b) {
        int ea = 0, eb = 0;
        int i = a.indexOf(':');
        if (i > 0) { try { ea = Integer.parseInt(a.substring(0, i)); } catch (NumberFormatException ignored) { } a = a.substring(i + 1); }
        i = b.indexOf(':');
        if (i > 0) { try { eb = Integer.parseInt(b.substring(0, i)); } catch (NumberFormatException ignored) { } b = b.substring(i + 1); }
        if (ea != eb) return ea < eb ? -1 : 1;
        String ra = "", rb = "";
        i = a.lastIndexOf('-');
        if (i >= 0) { ra = a.substring(i + 1); a = a.substring(0, i); }
        i = b.lastIndexOf('-');
        if (i >= 0) { rb = b.substring(i + 1); b = b.substring(0, i); }
        int c = verPart(a, b);
        return c != 0 ? c : verPart(ra, rb);
    }

    static int order(char c) {
        if (Character.isDigit(c)) return 0;
        if (Character.isLetter(c)) return c;
        if (c == '~') return -1;
        return c + 256;
    }

    static int verPart(String a, String b) {
        int i = 0, j = 0;
        while (i < a.length() || j < b.length()) {
            int first = 0;
            while ((i < a.length() && !Character.isDigit(a.charAt(i))) || (j < b.length() && !Character.isDigit(b.charAt(j)))) {
                int ac = i < a.length() ? order(a.charAt(i)) : 0;
                int bc = j < b.length() ? order(b.charAt(j)) : 0;
                if (ac != bc) return ac < bc ? -1 : 1;
                i++; j++;
            }
            while (i < a.length() && a.charAt(i) == '0') i++;
            while (j < b.length() && b.charAt(j) == '0') j++;
            while (i < a.length() && j < b.length() && Character.isDigit(a.charAt(i)) && Character.isDigit(b.charAt(j))) {
                if (first == 0) first = a.charAt(i) - b.charAt(j);
                i++; j++;
            }
            if (i < a.length() && Character.isDigit(a.charAt(i))) return 1;
            if (j < b.length() && Character.isDigit(b.charAt(j))) return -1;
            if (first != 0) return first < 0 ? -1 : 1;
        }
        return 0;
    }

    // ------------------------------------------------------------------ tar reader

    static final class TarEntry {
        String name = "", linkName = "";
        char type = '0';
        int mode = 0644;
        long size;
    }

    static final class TarReader {
        final InputStream in;
        long remaining; // bytes of current entry data not yet consumed
        long padding;

        TarReader(InputStream in) { this.in = in; }

        TarEntry next() throws IOException {
            skipData();
            String longName = null, longLink = null;
            Map<String, String> pax = new HashMap<String, String>();
            while (true) {
                byte[] h = new byte[512];
                int n = readUpTo(in, h);
                if (n == 0) return null;
                if (n < 512) throw new EOFException("truncated tar header");
                boolean zero = true;
                for (byte b : h) if (b != 0) { zero = false; break; }
                if (zero) return null;
                TarEntry e = new TarEntry();
                e.name = cstr(h, 0, 100);
                e.mode = (int) octal(h, 100, 8);
                e.size = parseSize(h, 124, 12);
                e.type = h[156] == 0 ? '0' : (char) h[156];
                e.linkName = cstr(h, 157, 100);
                String magic = cstr(h, 257, 6);
                if (magic.startsWith("ustar")) {
                    String prefix = cstr(h, 345, 155);
                    if (prefix.length() > 0) e.name = prefix + "/" + e.name;
                }
                remaining = e.size;
                padding = (512 - (e.size % 512)) % 512;
                if (e.type == 'L') { longName = cstr(readData(), 0, Integer.MAX_VALUE); continue; }
                if (e.type == 'K') { longLink = cstr(readData(), 0, Integer.MAX_VALUE); continue; }
                if (e.type == 'x') { parsePax(readData(), pax); continue; }
                if (e.type == 'g') { skipData(); continue; }
                if (longName != null) e.name = longName;
                if (longLink != null) e.linkName = longLink;
                if (pax.containsKey("path")) e.name = pax.get("path");
                if (pax.containsKey("linkpath")) e.linkName = pax.get("linkpath");
                if (pax.containsKey("size")) {
                    try { long s = Long.parseLong(pax.get("size")); e.size = s; remaining = s; padding = (512 - (s % 512)) % 512; }
                    catch (NumberFormatException ignored) { }
                }
                if (e.type == '0' || e.type == '7') e.type = '0';
                return e;
            }
        }

        static void parsePax(byte[] data, Map<String, String> out) {
            String s = new String(data, UTF8);
            int pos = 0;
            while (pos < s.length()) {
                int sp = s.indexOf(' ', pos);
                if (sp < 0) break;
                int len;
                try { len = Integer.parseInt(s.substring(pos, sp)); } catch (NumberFormatException e) { break; }
                if (len <= 0 || pos + len > s.length()) break;
                String rec = s.substring(sp + 1, pos + len - 1);
                int eq = rec.indexOf('=');
                if (eq > 0) out.put(rec.substring(0, eq), rec.substring(eq + 1));
                pos += len;
            }
        }

        byte[] readData() throws IOException {
            if (remaining > 64L * 1024 * 1024) throw new IOException("tar metadata entry too large");
            ByteArrayOutputStream bos = new ByteArrayOutputStream((int) Math.max(16, remaining));
            copyData(bos);
            return bos.toByteArray();
        }

        void copyData(OutputStream o) throws IOException {
            byte[] buf = new byte[32768];
            while (remaining > 0) {
                int n = in.read(buf, 0, (int) Math.min(buf.length, remaining));
                if (n < 0) throw new EOFException("truncated tar entry");
                o.write(buf, 0, n);
                remaining -= n;
            }
            skipFully(in, padding);
            padding = 0;
        }

        void skipData() throws IOException {
            if (remaining > 0) skipFully(in, remaining);
            remaining = 0;
            if (padding > 0) skipFully(in, padding);
            padding = 0;
        }

        static String cstr(byte[] b, int off, int max) {
            int end = off;
            int limit = Math.min(b.length, off + max);
            while (end < limit && b[end] != 0) end++;
            return new String(b, off, end - off, UTF8);
        }

        static long octal(byte[] b, int off, int len) {
            long v = 0;
            int i = off, end = off + len;
            while (i < end && (b[i] == ' ' || b[i] == 0)) i++;
            while (i < end && b[i] >= '0' && b[i] <= '7') { v = v * 8 + (b[i] - '0'); i++; }
            return v;
        }

        static long parseSize(byte[] b, int off, int len) {
            if ((b[off] & 0x80) != 0) { // base-256 encoding
                long v = b[off] & 0x7f;
                for (int i = 1; i < len; i++) v = (v << 8) | (b[off + i] & 0xff);
                return v;
            }
            return octal(b, off, len);
        }
    }

    // ------------------------------------------------------------------ stream helpers

    static final class BoundedInputStream extends InputStream {
        final InputStream in;
        long left;

        BoundedInputStream(InputStream in, long len) { this.in = in; this.left = len; }

        @Override public int read() throws IOException {
            if (left <= 0) return -1;
            int b = in.read();
            if (b >= 0) left--;
            return b;
        }

        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = in.read(b, off, (int) Math.min(len, left));
            if (n > 0) left -= n;
            return n;
        }

        void drain() throws IOException { if (left > 0) { skipFully(in, left); left = 0; } }

        @Override public void close() { }
    }

    static InputStream decompress(InputStream in) throws IOException, PkgException {
        BufferedInputStream b = in instanceof BufferedInputStream ? (BufferedInputStream) in : new BufferedInputStream(in, 65536);
        b.mark(8);
        byte[] m = new byte[6];
        int n = readUpTo(b, m);
        b.reset();
        if (n >= 2 && (m[0] & 0xff) == 0x1f && (m[1] & 0xff) == 0x8b) return new GZIPInputStream(b, 65536);
        if (n >= 6 && (m[0] & 0xff) == 0xfd && m[1] == '7' && m[2] == 'z' && m[3] == 'X' && m[4] == 'Z')
            return newStream("org.tukaani.xz.XZInputStream", b, "xz");
        if (n >= 3 && m[0] == 'B' && m[1] == 'Z' && m[2] == 'h')
            return newStream("org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream", b, "bzip2");
        if (n >= 4 && (m[0] & 0xff) == 0x28 && (m[1] & 0xff) == 0xb5 && (m[2] & 0xff) == 0x2f && (m[3] & 0xff) == 0xfd)
            throw new PkgException("zstd-compressed packages are not supported (use gz, xz or bz2)");
        return b;
    }

    static InputStream newStream(String cls, InputStream in, String label) throws PkgException {
        try {
            Constructor<?> c = Class.forName(cls).getConstructor(InputStream.class);
            return (InputStream) c.newInstance(in);
        } catch (ClassNotFoundException e) {
            throw new PkgException(label + " support is not available in this build");
        } catch (Exception e) {
            throw new PkgException("cannot open " + label + " stream: " + e);
        }
    }

    static boolean classExists(String n) {
        try { Class.forName(n); return true; } catch (Throwable t) { return false; }
    }

    static int readUpTo(InputStream in, byte[] buf) throws IOException {
        int total = 0;
        while (total < buf.length) {
            int n = in.read(buf, total, buf.length - total);
            if (n < 0) break;
            total += n;
        }
        return total;
    }

    static void readFully(InputStream in, byte[] buf, int len) throws IOException {
        if (readUpTo(in, buf) < len) throw new EOFException();
    }

    static void skipFully(InputStream in, long n) throws IOException {
        byte[] buf = new byte[8192];
        while (n > 0) {
            long s = in.skip(n);
            if (s <= 0) {
                int r = in.read(buf, 0, (int) Math.min(buf.length, n));
                if (r < 0) throw new EOFException("unexpected end of archive");
                s = r;
            }
            n -= s;
        }
    }

    static void pipe(InputStream in, OutputStream o) throws IOException {
        byte[] buf = new byte[32768];
        int n;
        while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
    }

    static byte[] gunzip(byte[] data) throws IOException {
        GZIPInputStream g = new GZIPInputStream(new java.io.ByteArrayInputStream(data));
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        pipe(g, bos);
        return bos.toByteArray();
    }

    // ------------------------------------------------------------------ file helpers

    static void mkdirs(File d) throws IOException {
        if (d == null) return;
        if (d.isDirectory()) return;
        if (!d.mkdirs() && !d.isDirectory()) throw new IOException("cannot create directory " + d);
    }

    static byte[] readBytes(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream((int) Math.max(16, f.length()));
            pipe(in, bos);
            return bos.toByteArray();
        } finally { in.close(); }
    }

    static List<String> readLines(File f) throws IOException {
        List<String> l = new ArrayList<String>();
        for (String s : new String(readBytes(f), UTF8).split("\r?\n")) l.add(s);
        return l;
    }

    /** Atomic-ish write: temp file + rename. */
    static void writeBytes(File f, byte[] data) throws IOException {
        mkdirs(f.getParentFile());
        File tmp = new File(f.getPath() + ".tmp");
        FileOutputStream o = new FileOutputStream(tmp);
        try { o.write(data); } finally { o.close(); }
        if (f.exists() && !f.delete()) { tmp.delete(); throw new IOException("cannot replace " + f); }
        if (!tmp.renameTo(f)) throw new IOException("cannot write " + f);
    }

    static void writeText(File f, String s) throws IOException { writeBytes(f, s.getBytes(UTF8)); }

    static void copyFile(File src, File dest) throws IOException {
        FileInputStream in = new FileInputStream(src);
        try {
            FileOutputStream o = new FileOutputStream(dest);
            try { pipe(in, o); } finally { o.close(); }
        } finally { in.close(); }
    }

    static void deleteRecursive(File f) {
        if (f == null) return;
        if (!isLink(f) && f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) deleteRecursive(k);
        }
        f.delete();
    }

    static boolean isLink(File f) {
        try {
            File parent = f.getParentFile();
            if (parent == null) return false;
            File canonical = new File(parent.getCanonicalFile(), f.getName());
            return !canonical.getCanonicalFile().equals(canonical.getAbsoluteFile());
        } catch (IOException e) {
            return false;
        }
    }

    static void checkInside(File root, File f) throws IOException, PkgException {
        String r = root.getCanonicalPath();
        String c = f.getCanonicalPath();
        if (!c.equals(r) && !c.startsWith(r + File.separator)) throw new PkgException("unsafe path in archive: " + f.getPath());
    }

    static int modeOf(File f) {
        int m = 0600;
        if (f.canExecute()) m |= 0111;
        if (f.canRead()) m |= 0044;
        return m;
    }

    static void closeQuiet(java.io.Closeable c) { try { c.close(); } catch (IOException ignored) { } }

    static String sha256(File f) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            FileInputStream in = new FileInputStream(f);
            try {
                byte[] buf = new byte[32768];
                int n;
                while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
            } finally { in.close(); }
            StringBuilder sb = new StringBuilder();
            for (byte b : md.digest()) sb.append(String.format("%02x", b & 0xff));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            throw new IOException(e);
        }
    }

    // ------------------------------------------------------------------ chmod / symlink

    private static Class<?> osClass;
    private static boolean osChecked;

    private static synchronized Class<?> os() {
        if (!osChecked) {
            osChecked = true;
            try { osClass = Class.forName("android.system.Os"); } catch (Throwable t) { osClass = null; }
        }
        return osClass;
    }

    static void chmod(File f, int mode) throws IOException {
        Class<?> c = os();
        if (c != null) {
            try {
                Method m = c.getMethod("chmod", String.class, int.class);
                m.invoke(null, f.getPath(), Integer.valueOf(mode & 07777));
                return;
            } catch (Exception e) {
                throw new IOException("chmod failed for " + f + ": " + e);
            }
        }
        exec("chmod", Integer.toOctalString(mode & 07777), f.getPath());
    }

    static void symlink(String target, File link) throws IOException {
        Class<?> c = os();
        if (c != null) {
            try {
                Method m = c.getMethod("symlink", String.class, String.class);
                m.invoke(null, target, link.getPath());
                return;
            } catch (Exception e) {
                throw new IOException("symlink failed for " + link + ": " + e);
            }
        }
        exec("ln", "-s", target, link.getPath());
    }

    static void exec(String... cmd) throws IOException {
        try {
            Process p = new ProcessBuilder(cmd).redirectErrorStream(true).start();
            pipe(p.getInputStream(), new ByteArrayOutputStream());
            if (p.waitFor() != 0) throw new IOException(cmd[0] + " failed");
        } catch (InterruptedException e) {
            throw new IOException(e);
        }
    }

    // ------------------------------------------------------------------ misc text helpers

    static String orDefault(String s, String d) { return s == null || s.length() == 0 ? d : s; }

    static String firstLine(String s) {
        int i = s.indexOf('\n');
        return i < 0 ? s : s.substring(0, i);
    }

    static String joinLines(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) sb.append(s).append('\n');
        return sb.toString();
    }

    static String joinSp(java.util.Collection<String> c) {
        StringBuilder sb = new StringBuilder();
        for (String s : c) { if (sb.length() > 0) sb.append(' '); sb.append(s); }
        return sb.toString();
    }

    static String humanSize(long b) {
        if (b < 1024) return b + " B";
        double v = b;
        String[] u = {"KB", "MB", "GB", "TB"};
        int i = -1;
        while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
        return String.format(Locale.US, "%.1f %s", v, u[i]);
    }

    String bold(String s) { return ansi ? "\u001b[1m" + s + "\u001b[0m" : s; }

    void ok(String s) { out.println((ansi ? "\u001b[32m" : "") + s + (ansi ? "\u001b[0m" : "")); }

    void err(String s) {
        out.flush();
        System.err.println((ansi ? "\u001b[33m" : "") + s + (ansi ? "\u001b[0m" : ""));
    }
}
