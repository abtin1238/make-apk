package ir.abtin.filemanager;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * "alpine" command backend: downloads the official Alpine minirootfs, verifies it (SHA-256 from
 * the release index), extracts it safely into $PREFIX/alpine and configures apk. Entering the
 * environment (proot) is done by the shell functions generated in PkgEnv.
 *
 * Subcommands (run through app_process): setup | status | proot | remove | doctor
 */
public final class AlpineCli {
    static final String DEFAULT_MIRROR = "https://dl-cdn.alpinelinux.org/alpine";

    final File prefix;
    final File root;
    final PkgCli cli;
    PrintStream out = System.out;
    boolean yes;

    AlpineCli(File prefix) {
        this.prefix = prefix;
        this.root = new File(prefix, "alpine");
        this.cli = new PkgCli(prefix);
    }

    public static void main(String[] args) {
        int code;
        try {
            String p = System.getenv("PREFIX");
            if (p == null || p.length() == 0) {
                System.err.println("alpine: PREFIX is not set (use the app terminal)");
                System.exit(2);
                return;
            }
            AlpineCli a = new AlpineCli(new File(p));
            a.out = new PrintStream(new FileOutputStream(java.io.FileDescriptor.out), true, "UTF-8");
            a.cli.out = a.out;
            String term = System.getenv("TERM");
            a.cli.ansi = term != null && !term.equals("dumb");
            code = a.run(args);
            a.out.flush();
        } catch (PkgCli.PkgException e) {
            System.err.println("alpine: " + e.getMessage());
            code = 1;
        } catch (Throwable t) {
            System.err.println("alpine: internal error: " + t);
            code = 1;
        }
        System.exit(code);
    }

    int run(String[] argv) throws Exception {
        cli.ensureDirs();
        List<String> args = new ArrayList<String>();
        for (String a : argv) {
            if (a.equals("-y") || a.equals("--yes")) { yes = true; cli.yes = true; }
            else args.add(a);
        }
        if (args.isEmpty()) throw new PkgCli.PkgException("usage: alpine setup|status|proot|remove|doctor");
        String cmd = args.remove(0);
        if (cmd.equals("setup")) return setup(args);
        if (cmd.equals("status")) return status();
        if (cmd.equals("proot")) return installProot(args);
        if (cmd.equals("remove")) return remove();
        if (cmd.equals("doctor")) return doctor();
        throw new PkgCli.PkgException("unknown subcommand '" + cmd + "'");
    }

    static String mirror() {
        String m = System.getenv("ABTIN_ALPINE_MIRROR");
        return PkgCli.stripSlash(m == null || m.length() == 0 ? DEFAULT_MIRROR : m);
    }

    static String alpineArch() {
        String a = PkgCli.detectArch();
        if (a.equals("arm")) return "armv7";
        if (a.equals("i686")) return "x86";
        return a; // aarch64, x86_64
    }

    // ------------------------------------------------------------------ release index

    static final class Release {
        String branch = "", version = "", file = "", sha256 = "", flavor = "";
        long size;
    }

    /** Parses Alpine's latest-releases.yaml and returns the alpine-minirootfs entry. */
    static Release pickMinirootfs(String yaml) throws PkgCli.PkgException {
        List<Map<String, String>> entries = new ArrayList<Map<String, String>>();
        Map<String, String> cur = null;
        for (String line : yaml.split("\r?\n")) {
            if (line.equals("-") || line.startsWith("- ")) {
                cur = new HashMap<String, String>();
                entries.add(cur);
                continue;
            }
            if (cur == null) continue;
            if (line.startsWith("    ")) continue; // block scalar continuation (desc: |)
            String t = line.trim();
            int i = t.indexOf(':');
            if (i <= 0) continue;
            String v = t.substring(i + 1).trim();
            if (v.length() >= 2 && v.startsWith("\"") && v.endsWith("\"")) v = v.substring(1, v.length() - 1);
            cur.put(t.substring(0, i).trim(), v);
        }
        for (Map<String, String> e : entries) {
            if (!"alpine-minirootfs".equals(e.get("flavor"))) continue;
            Release r = new Release();
            r.flavor = e.get("flavor");
            r.branch = e.get("branch") == null ? "" : e.get("branch");
            r.version = e.get("version") == null ? "" : e.get("version");
            r.file = e.get("file") == null ? "" : e.get("file");
            r.sha256 = e.get("sha256") == null ? "" : e.get("sha256").toLowerCase(Locale.ROOT);
            try { r.size = Long.parseLong(e.get("size")); } catch (Exception ignored) { }
            if (r.file.matches("[A-Za-z0-9._-]+\\.tar\\.gz") && r.branch.matches("v[0-9][0-9.]*|edge")
                    && r.sha256.matches("[0-9a-f]{64}")) return r;
        }
        throw new PkgCli.PkgException("no valid alpine-minirootfs entry (with sha256) in the release index");
    }

    // ------------------------------------------------------------------ setup

    int setup(List<String> args) throws Exception {
        if (new File(root, "etc/alpine-release").exists()) {
            out.println("Alpine is already installed in " + root.getPath() + " (use: alpine remove)");
            return 0;
        }
        String arch = alpineArch();
        String idxUrl = mirror() + "/latest-stable/releases/" + arch + "/latest-releases.yaml";
        out.println("Fetching release index: " + idxUrl);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try {
            cli.download(idxUrl, bos, "latest-releases.yaml", false);
        } catch (IOException e) {
            throw new PkgCli.PkgException("cannot download the release index: " + e.getMessage());
        }
        Release rel = pickMinirootfs(new String(bos.toByteArray(), PkgCli.UTF8));
        out.println("Alpine " + rel.version + " (" + rel.branch + ", " + arch + ")");
        if (!yes && !cli.confirm("Download " + rel.file + " (" + PkgCli.humanSize(rel.size) + ") and install?")) {
            out.println("Aborted.");
            return 1;
        }
        File tar = new File(cli.cacheDir, rel.file);
        File part = new File(cli.cacheDir, rel.file + ".part");
        String url = mirror() + "/" + rel.branch + "/releases/" + arch + "/" + rel.file;
        FileOutputStream fos = new FileOutputStream(part);
        try {
            cli.download(url, fos, rel.file, true);
        } catch (IOException e) {
            PkgCli.closeQuiet(fos);
            part.delete();
            throw new PkgCli.PkgException("download failed: " + e.getMessage());
        }
        fos.close();
        String got = PkgCli.sha256(part);
        if (!got.equals(rel.sha256)) {
            part.delete();
            throw new PkgCli.PkgException("SHA-256 mismatch for " + rel.file + " (expected " + rel.sha256 + ", got " + got + ")");
        }
        out.println("SHA-256 verified.");
        if (tar.exists()) tar.delete();
        if (!part.renameTo(tar)) throw new PkgCli.PkgException("cannot move download into cache");

        File staging = new File(prefix, "alpine.staging");
        PkgCli.deleteRecursive(staging);
        PkgCli.mkdirs(staging);
        try {
            int n = extractRootfs(tar, staging);
            out.println("Extracted " + n + " entries.");
            configure(staging, rel);
            if (root.exists()) forceDelete(root);
            if (!staging.renameTo(root)) throw new PkgCli.PkgException("cannot move rootfs into place");
        } catch (Exception e) {
            forceDelete(staging);
            throw e;
        }
        tar.delete();
        cli.ok("Alpine " + rel.version + " installed. Next: alpine proot <file|url>, then: alpine bootstrap");
        return 0;
    }

    /** Safe extraction: no ".." paths, no writes below symlinks, setuid bits stripped. */
    int extractRootfs(File archive, File dest) throws IOException, PkgCli.PkgException {
        int count = 0;
        InputStream raw = new java.io.BufferedInputStream(new FileInputStream(archive), 65536);
        try {
            PkgCli.TarReader tr = new PkgCli.TarReader(PkgCli.decompress(raw));
            PkgCli.TarEntry e;
            while ((e = tr.next()) != null) {
                String rel = clean(e.name);
                if (rel == null) { tr.skipData(); continue; }
                File f = new File(dest, rel);
                checkParents(dest, rel);
                switch (e.type) {
                    case '5':
                        PkgCli.mkdirs(f);
                        PkgCli.chmod(f, (e.mode & 0777) | 0700);
                        tr.skipData();
                        break;
                    case '2':
                        PkgCli.mkdirs(f.getParentFile());
                        PkgCli.deleteRecursive(f);
                        PkgCli.symlink(e.linkName, f);
                        tr.skipData();
                        break;
                    case '1': {
                        String target = clean(e.linkName);
                        if (target == null) throw new PkgCli.PkgException("bad hard link " + e.linkName);
                        checkParents(dest, target);
                        PkgCli.mkdirs(f.getParentFile());
                        PkgCli.deleteRecursive(f);
                        PkgCli.copyFile(new File(dest, target), f);
                        PkgCli.chmod(f, (e.mode & 0777) | 0600);
                        tr.skipData();
                        break;
                    }
                    case '0':
                    case 0: {
                        PkgCli.mkdirs(f.getParentFile());
                        PkgCli.deleteRecursive(f);
                        FileOutputStream o = new FileOutputStream(f);
                        try { tr.copyData(o); } finally { o.close(); }
                        PkgCli.chmod(f, (e.mode & 0777) | 0600); // strips setuid/setgid/sticky
                        break;
                    }
                    default:
                        tr.skipData(); // device nodes, fifos
                }
                count++;
            }
        } finally {
            raw.close();
        }
        return count;
    }

    static String clean(String raw) throws PkgCli.PkgException {
        String p = raw.replace('\\', '/');
        while (p.startsWith("./") || p.startsWith("/")) p = p.startsWith("./") ? p.substring(2) : p.substring(1);
        while (p.endsWith("/")) p = p.substring(0, p.length() - 1);
        if (p.length() == 0 || p.equals(".")) return null;
        for (String seg : p.split("/")) if (seg.equals("..")) throw new PkgCli.PkgException("unsafe path in archive: " + raw);
        return p;
    }

    /** Rejects entries whose parent directories contain a symlink (would escape the rootfs). */
    static void checkParents(File dest, String rel) throws PkgCli.PkgException {
        String[] seg = rel.split("/");
        File cur = dest;
        for (int i = 0; i < seg.length - 1; i++) {
            cur = new File(cur, seg[i]);
            if (cur.exists() && PkgCli.isLink(cur)) throw new PkgCli.PkgException("unsafe path below a symlink: " + rel);
        }
    }

    void configure(File r, Release rel) throws IOException {
        String m = mirror();
        PkgCli.mkdirs(new File(r, "etc/apk"));
        PkgCli.writeText(new File(r, "etc/apk/repositories"),
                m + "/" + rel.branch + "/main\n" + m + "/" + rel.branch + "/community\n");
        PkgCli.writeText(new File(r, "etc/resolv.conf"), "nameserver 1.1.1.1\nnameserver 8.8.8.8\n");
        PkgCli.writeText(new File(r, "etc/hosts"), "127.0.0.1 localhost\n::1 localhost\n");
        PkgCli.mkdirs(new File(r, "root"));
        PkgCli.mkdirs(new File(r, "tmp"));
        PkgCli.chmod(new File(r, "tmp"), 0777);
        for (String d : new String[]{"proc", "sys", "dev", "sdcard", "mnt"}) PkgCli.mkdirs(new File(r, d));
        PkgCli.writeText(new File(r, ".abtin-alpine"), "version=" + rel.version + "\nbranch=" + rel.branch + "\nmirror=" + m + "\n");
    }

    // ------------------------------------------------------------------ proot

    /** alpine proot <file|url> [loader file|url] - installs the proot binary (and optional loader). */
    int installProot(List<String> a) throws Exception {
        if (a.isEmpty() || a.size() > 2) throw new PkgCli.PkgException("usage: alpine proot <proot file|url> [loader file|url]");
        File bin = new File(prefix, "bin/proot");
        fetchTo(a.get(0), bin);
        if (!isElf(bin)) { bin.delete(); throw new PkgCli.PkgException("the file is not an ELF binary"); }
        PkgCli.chmod(bin, 0755);
        out.println("installed " + bin.getPath());
        if (a.size() == 2) {
            File loader = new File(prefix, "libexec/proot-loader");
            PkgCli.mkdirs(loader.getParentFile());
            fetchTo(a.get(1), loader);
            PkgCli.chmod(loader, 0755);
            out.println("installed " + loader.getPath());
        }
        cli.regenAliases(java.util.Collections.<String>emptySet());
        return 0;
    }

    void fetchTo(String spec, File dest) throws Exception {
        File tmp = new File(dest.getPath() + ".part");
        PkgCli.mkdirs(dest.getParentFile());
        if (spec.matches("(?i)(https?|file)://.*")) {
            FileOutputStream o = new FileOutputStream(tmp);
            try { cli.download(spec, o, dest.getName(), true); }
            catch (IOException e) { PkgCli.closeQuiet(o); tmp.delete(); throw new PkgCli.PkgException("download failed: " + e.getMessage()); }
            o.close();
        } else {
            File src = new File(spec);
            if (!src.isFile()) throw new PkgCli.PkgException("file not found: " + spec);
            PkgCli.copyFile(src, tmp);
        }
        if (dest.exists()) dest.delete();
        if (!tmp.renameTo(dest)) throw new PkgCli.PkgException("cannot write " + dest);
    }

    static boolean isElf(File f) throws IOException {
        byte[] h = new byte[4];
        InputStream in = new FileInputStream(f);
        try { return PkgCli.readUpTo(in, h) == 4 && h[0] == 0x7f && h[1] == 'E' && h[2] == 'L' && h[3] == 'F'; }
        finally { in.close(); }
    }

    // ------------------------------------------------------------------ status / remove / doctor

    int status() throws Exception {
        File meta = new File(root, ".abtin-alpine");
        if (!meta.exists()) { out.println("Alpine: not installed (run: alpine setup)"); return 1; }
        out.println("Alpine:   installed at " + root.getPath());
        for (String l : PkgCli.readLines(meta)) if (l.length() > 0) out.println("  " + l);
        File rel = new File(root, "etc/alpine-release");
        if (rel.exists()) out.println("  release=" + new String(PkgCli.readBytes(rel), PkgCli.UTF8).trim());
        File db = new File(root, "lib/apk/db/installed");
        if (db.exists()) {
            int n = 0;
            for (String l : PkgCli.readLines(db)) if (l.startsWith("P:")) n++;
            out.println("  apk packages=" + n);
        }
        out.println("proot:    " + (new File(prefix, "bin/proot").exists() ? "present" : "MISSING (alpine proot <file|url>)"));
        return 0;
    }

    int remove() throws Exception {
        if (!root.exists()) { out.println("Alpine is not installed."); return 0; }
        if (!cli.confirm("Delete " + root.getPath() + " and everything inside?")) { out.println("Aborted."); return 1; }
        forceDelete(root);
        cli.ok("Alpine removed.");
        return 0;
    }

    int doctor() throws Exception {
        out.println("arch:     " + alpineArch());
        out.println("mirror:   " + mirror());
        out.println("rootfs:   " + (new File(root, "etc/alpine-release").exists() ? "installed" : "missing"));
        File proot = new File(prefix, "bin/proot");
        out.println("proot:    " + (proot.exists() ? proot.getPath() : "missing"));
        out.println("loader:   " + (new File(prefix, "libexec/proot-loader").exists() ? "present" : "none"));
        out.println("linker:   " + (new File("/system/bin/linker64").exists() ? "/system/bin/linker64" : "/system/bin/linker"));
        out.println("free:     " + PkgCli.humanSize(prefix.getUsableSpace()));
        return 0;
    }

    static void forceDelete(File f) {
        if (!PkgCli.isLink(f) && f.isDirectory()) {
            try { PkgCli.chmod(f, 0700); } catch (IOException ignored) { }
            File[] kids = f.listFiles();
            if (kids != null) for (File k : kids) forceDelete(k);
        }
        f.delete();
    }
}
