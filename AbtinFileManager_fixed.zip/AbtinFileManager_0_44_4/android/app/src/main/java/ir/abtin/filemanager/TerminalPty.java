package ir.abtin.filemanager;

/** Thin JNI bridge to Android bionic forkpty(3). The process and session lifecycle is managed by Kotlin. */
public final class TerminalPty {
    static {
        System.loadLibrary("terminal_pty");
    }

    private TerminalPty() {}

    /** extraEnv: newline separated KEY=VALUE lines; PATH_PREPEND=dir is prepended to PATH. */
    /** Returns [child pid, PTY master fd], or throws IOException when PTY creation fails. */
    public static native long[] startNative(String cwd, String home, String tmp, int columns, int rows, String extraEnv);
    /** Blocking read; returns bytes read, 0 on EOF, or a negative errno. */
    public static native int readNative(int masterFd, byte[] buffer, int length);
    /** Writes a byte range; returns bytes written or a negative errno. */
    public static native int writeNative(int masterFd, byte[] buffer, int offset, int length);
    /** Sends a terminal control character through the PTY line discipline (3 = Ctrl+C, 4 = Ctrl+D). */
    public static native int sendControlNative(int masterFd, int value);
    /** Updates the PTY window size and notifies the foreground process with SIGWINCH. */
    public static native int resizeNative(int masterFd, int columns, int rows);
    /** Waits for the child process and returns its exit code. */
    public static native int waitForNative(int pid);
    /** Sends SIGHUP to the shell session/process group. */
    public static native int terminateNative(int pid);
    /** Escalates cleanup to SIGKILL for the shell session/process group. */
    public static native int forceKillNative(int pid);
    public static native void closeNative(int masterFd);
}
