#include <jni.h>
#include <pty.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <vector>
#include <string>

extern char** environ;

static void throw_io(JNIEnv* env, const char* message) {
    jclass cls = env->FindClass("java/io/IOException");
    if (cls != nullptr) env->ThrowNew(cls, message);
}

extern "C" JNIEXPORT jlongArray JNICALL
Java_ir_abtin_filemanager_TerminalPty_startNative(
        JNIEnv* env, jclass, jstring cwd_value, jstring home_value,
        jstring tmp_value, jint columns, jint rows, jstring extra_value) {
    if (cwd_value == nullptr || home_value == nullptr || tmp_value == nullptr) {
        throw_io(env, "PTY start arguments cannot be null");
        return nullptr;
    }
    const char* cwd = env->GetStringUTFChars(cwd_value, nullptr);
    const char* home = env->GetStringUTFChars(home_value, nullptr);
    const char* tmp = env->GetStringUTFChars(tmp_value, nullptr);
    if (cwd == nullptr || home == nullptr || tmp == nullptr) {
        if (cwd) env->ReleaseStringUTFChars(cwd_value, cwd);
        if (home) env->ReleaseStringUTFChars(home_value, home);
        if (tmp) env->ReleaseStringUTFChars(tmp_value, tmp);
        throw_io(env, "Could not read PTY start arguments");
        return nullptr;
    }

    // Extra environment ("KEY=VALUE" lines separated by '\n') supplied by Kotlin.
    std::vector<std::string> extra_env;
    std::string extra_path;
    if (extra_value != nullptr) {
        const char* extra = env->GetStringUTFChars(extra_value, nullptr);
        if (extra != nullptr) {
            std::string all(extra);
            env->ReleaseStringUTFChars(extra_value, extra);
            size_t start = 0;
            while (start <= all.size()) {
                size_t end = all.find('\n', start);
                if (end == std::string::npos) end = all.size();
                std::string line = all.substr(start, end - start);
                if (strncmp(line.c_str(), "PATH_PREPEND=", 13) == 0) extra_path = line.substr(13);
                else if (line.find('=') != std::string::npos && line[0] != '=') extra_env.push_back(line);
                start = end + 1;
            }
        }
    }

    struct winsize ws{};
    ws.ws_col = static_cast<unsigned short>(columns > 0 ? columns : 80);
    ws.ws_row = static_cast<unsigned short>(rows > 0 ? rows : 24);

    // Prepare the child environment before fork; a forked multithreaded VM must
    // avoid libc allocation/locking calls between fork() and execve().
    std::vector<std::string> env_storage;
    for (char** item = environ; item != nullptr && *item != nullptr; ++item) {
        if (strncmp(*item, "HOME=", 5) == 0 || strncmp(*item, "TMPDIR=", 7) == 0 ||
            strncmp(*item, "TERM=", 5) == 0 || strncmp(*item, "COLORTERM=", 10) == 0 ||
            strncmp(*item, "PATH=", 5) == 0) continue;
        env_storage.emplace_back(*item);
    }
    env_storage.emplace_back(std::string("HOME=") + home);
    env_storage.emplace_back(std::string("TMPDIR=") + tmp);
    env_storage.emplace_back("TERM=xterm-256color");
    env_storage.emplace_back("COLORTERM=truecolor");
    env_storage.emplace_back(std::string("PATH=") + (extra_path.empty() ? "" : extra_path + ":") +
                             "/system/bin:/system/xbin:/vendor/bin");
    for (const std::string& item : extra_env) env_storage.emplace_back(item);
    std::vector<char*> child_env;
    child_env.reserve(env_storage.size() + 1);
    for (std::string& item : env_storage) child_env.push_back(item.data());
    child_env.push_back(nullptr);
    char* child_argv[] = {const_cast<char*>("sh"), const_cast<char*>("-i"), nullptr};

    int master_fd = -1;
    pid_t pid = forkpty(&master_fd, nullptr, nullptr, &ws);
    int saved_errno = errno;
    if (pid == 0) {
        // forkpty makes this process a session leader and gives it a controlling TTY.
        (void) chdir(cwd);
        execve("/system/bin/sh", child_argv, child_env.data());
        static const char failed[] = "\r\n[terminal] unable to exec /system/bin/sh\r\n";
        (void) write(STDERR_FILENO, failed, sizeof(failed) - 1);
        _exit(127);
    }

    env->ReleaseStringUTFChars(cwd_value, cwd);
    env->ReleaseStringUTFChars(home_value, home);
    env->ReleaseStringUTFChars(tmp_value, tmp);
    if (pid < 0) {
        char message[128];
        snprintf(message, sizeof(message), "forkpty failed (errno %d)", saved_errno);
        throw_io(env, message);
        return nullptr;
    }

    jlong values[2] = {static_cast<jlong>(pid), static_cast<jlong>(master_fd)};
    jlongArray result = env->NewLongArray(2);
    if (result != nullptr) env->SetLongArrayRegion(result, 0, 2, values);
    return result;
}

extern "C" JNIEXPORT jint JNICALL
Java_ir_abtin_filemanager_TerminalPty_readNative(
        JNIEnv* env, jclass, jint fd, jbyteArray buffer, jint length) {
    if (buffer == nullptr || length <= 0) return 0;
    std::vector<jbyte> bytes(static_cast<size_t>(length));
    ssize_t count;
    do { count = read(fd, bytes.data(), static_cast<size_t>(length)); } while (count < 0 && errno == EINTR);
    int saved_errno = errno;
    if (count < 0) return -saved_errno;
    if (count > 0) env->SetByteArrayRegion(buffer, 0, static_cast<jsize>(count), bytes.data());
    return static_cast<jint>(count);
}

extern "C" JNIEXPORT jint JNICALL
Java_ir_abtin_filemanager_TerminalPty_writeNative(
        JNIEnv* env, jclass, jint fd, jbyteArray buffer, jint offset, jint length) {
    if (buffer == nullptr || offset < 0 || length < 0 ||
        offset + length > env->GetArrayLength(buffer)) return -EINVAL;
    jbyte* bytes = env->GetByteArrayElements(buffer, nullptr);
    if (bytes == nullptr) return -ENOMEM;
    ssize_t count;
    do { count = write(fd, bytes + offset, static_cast<size_t>(length)); }
    while (count < 0 && errno == EINTR);
    int saved_errno = errno;
    env->ReleaseByteArrayElements(buffer, bytes, JNI_ABORT);
    if (count < 0) return -saved_errno;
    return static_cast<jint>(count);
}

extern "C" JNIEXPORT jint JNICALL
Java_ir_abtin_filemanager_TerminalPty_sendControlNative(
        JNIEnv*, jclass, jint fd, jint value) {
    unsigned char control = static_cast<unsigned char>(value & 0xff);
    ssize_t count;
    do { count = write(fd, &control, 1); } while (count < 0 && errno == EINTR);
    return count < 0 ? -errno : static_cast<jint>(count);
}

extern "C" JNIEXPORT jint JNICALL
Java_ir_abtin_filemanager_TerminalPty_resizeNative(
        JNIEnv*, jclass, jint fd, jint columns, jint rows) {
    struct winsize ws{};
    ws.ws_col = static_cast<unsigned short>(columns > 0 ? columns : 80);
    ws.ws_row = static_cast<unsigned short>(rows > 0 ? rows : 24);
    if (ioctl(fd, TIOCSWINSZ, &ws) < 0) return -errno;
    return 0;
}

extern "C" JNIEXPORT jint JNICALL
Java_ir_abtin_filemanager_TerminalPty_waitForNative(JNIEnv*, jclass, jint pid_value) {
    int status = 0;
    pid_t pid = static_cast<pid_t>(pid_value);
    pid_t result;
    do { result = waitpid(pid, &status, 0); } while (result < 0 && errno == EINTR);
    if (result < 0) return 128 + (errno & 0x7f);
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return 255;
}

extern "C" JNIEXPORT jint JNICALL
Java_ir_abtin_filemanager_TerminalPty_terminateNative(JNIEnv*, jclass, jint pid_value) {
    pid_t pid = static_cast<pid_t>(pid_value);
    if (kill(-pid, SIGHUP) == 0 || errno == ESRCH) return 0;
    if (kill(pid, SIGHUP) == 0 || errno == ESRCH) return 0;
    return -errno;
}

extern "C" JNIEXPORT jint JNICALL
Java_ir_abtin_filemanager_TerminalPty_forceKillNative(JNIEnv*, jclass, jint pid_value) {
    pid_t pid = static_cast<pid_t>(pid_value);
    if (kill(-pid, SIGKILL) == 0 || errno == ESRCH) return 0;
    if (kill(pid, SIGKILL) == 0 || errno == ESRCH) return 0;
    return -errno;
}

extern "C" JNIEXPORT void JNICALL
Java_ir_abtin_filemanager_TerminalPty_closeNative(JNIEnv*, jclass, jint fd) {
    if (fd >= 0) (void) close(fd);
}
