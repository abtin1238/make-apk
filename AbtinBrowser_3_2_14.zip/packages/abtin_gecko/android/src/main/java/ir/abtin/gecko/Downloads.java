package ir.abtin.gecko;

import android.net.Uri;
import android.util.Log;

import androidx.annotation.Nullable;

import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoWebExecutor;
import org.mozilla.geckoview.WebRequest;
import org.mozilla.geckoview.WebResponse;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Streams Gecko responses (with the browser's cookies/auth) to disk and reports progress to Dart. */
final class Downloads {
    private final Engine e;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Map<String, AtomicBoolean> cancels = new ConcurrentHashMap<>();
    private GeckoWebExecutor executor;
    final Map<String, DlTask> tasks = new ConcurrentHashMap<>();
    volatile int conns = 4;

    Downloads(Engine e) { this.e = e; }

    /** Called when a page navigates to something Gecko can't render (attachment, blob, pdf save...). */
    private final Map<String, Object[]> pendingAsk = new ConcurrentHashMap<>();

    void handle(Tab t, WebResponse r) {
        if (!e.dlAsk) { proceed(t, r); return; }
        long size = -1;
        try { final String len = header(r.headers, "content-length"); if (len != null) size = Long.parseLong(len.trim()); } catch (Exception ignored) { }
        final String id = "ask" + System.nanoTime();
        pendingAsk.put(id, new Object[]{t, r});
        final Map<String, Object> m = Engine.ev("dlConfirm", 0);
        m.put("id", id);
        m.put("url", r.uri == null ? "" : r.uri);
        m.put("name", nameFrom(header(r.headers, "content-disposition"), r.uri, header(r.headers, "content-type")));
        m.put("size", size);
        e.emit(m);
        // nobody answered (Dart side gone): drop the stream instead of leaking it
        e.main.postDelayed(() -> answer(id, false), 120000);
    }

    /** Answer of the in-app confirmation card. */
    void answer(String id, boolean ok) {
        final Object[] p = pendingAsk.remove(id);
        if (p == null) return;
        if (ok) proceed((Tab) p[0], (WebResponse) p[1]); else closeBody((WebResponse) p[1]);
    }

    private static void closeBody(WebResponse r) {
        try { if (r.body != null) r.body.close(); } catch (Exception ignored) { }
    }

    private void proceed(Tab t, WebResponse r) {
        final String ar = header(r.headers, "accept-ranges");
        final String cl = header(r.headers, "content-length");
        if (r.uri != null && r.uri.startsWith("http") && ar != null && ar.toLowerCase().contains("bytes") && cl != null) {
            // Static file that supports ranges: drop this stream and let the segmented manager take over.
            try { if (r.body != null) r.body.close(); } catch (Exception ignored) { }
            startManaged(null, r.uri, null, null, t.privateMode);
            return;
        }
        save(r, null, t.privateMode, r.uri);
    }

    String startManaged(@Nullable String id, String url, @Nullable String referer, @Nullable String name, boolean priv) {
        final String tid = id != null ? id : "n" + System.nanoTime();
        final DlTask t = new DlTask(this, tid, url, referer, priv, name, conns);
        tasks.put(tid, t);
        t.start();
        return tid;
    }

    /** Folder for new downloads. */
    File dir() {
        return new File(e.downloadDir.isEmpty() ? e.app.getFilesDir().getPath() + "/Download" : e.downloadDir);
    }

    @Nullable WebResponse fetchBlocking(String url, @Nullable String referer, @Nullable String range, boolean priv) {
        final CountDownLatch l = new CountDownLatch(1);
        final WebResponse[] out = new WebResponse[1];
        e.main.post(() -> {
            try {
                if (executor == null) executor = new GeckoWebExecutor(e.runtime);
                final WebRequest.Builder b = new WebRequest.Builder(url);
                if (referer != null && !referer.isEmpty()) b.referrer(referer);
                if (range != null) b.addHeader("Range", range);
                executor.fetch(b.build(), priv ? GeckoWebExecutor.FETCH_FLAGS_PRIVATE : GeckoWebExecutor.FETCH_FLAGS_NONE)
                        .accept(r -> { out[0] = r; l.countDown(); }, err -> l.countDown());
            } catch (Throwable t) { Log.w(Engine.TAG, "fetchBlocking", t); l.countDown(); }
        });
        try { if (!l.await(40, TimeUnit.SECONDS)) return null; } catch (InterruptedException ie) { return null; }
        return out[0];
    }

    void emitTask(DlTask t) {
        final Map<String, Object> m = Engine.ev("download", 0);
        m.put("id", t.id);
        m.put("url", t.url);
        m.put("name", t.out != null ? t.out.getName() : (t.name.isEmpty() ? "download" : t.name));
        if (t.out != null) m.put("path", t.out.getAbsolutePath());
        m.put("total", t.total > 0 ? t.total : -1L);
        m.put("received", t.got.get());
        m.put("status", t.status);
        m.put("private", t.priv);
        m.put("speed", t.speed);
        m.put("conns", t.segS == null ? 0 : t.segS.length);
        m.put("resumable", t.ranged);
        e.emit(m);
        if (e.dlNotif != null && t.out != null) e.dlNotif.update(t.id, t.out.getName(), t.got.get(), t.total, t.status, t.out.getAbsolutePath(), t.priv);
    }


    /**
     * Makes a finished image / video / audio file visible to the system gallery (MediaStore), so it also shows in the "Photos" section of
     * other apps' pickers (chat apps) and not only when browsing folders. Files are written as ".part" and renamed, so the system does
     * not index them on its own. A file in the app's private folder can never be indexed for other apps, so an image there is also
     * copied to Pictures/Abtin (not for private tabs).
     */
    void publishMedia(@Nullable File f, boolean priv) {
        try {
            if (f == null || !f.isFile()) return;
            final String nm = f.getName();
            final int dot = nm.lastIndexOf('.');
            final String mime = dot > 0 ? android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(nm.substring(dot + 1).toLowerCase(java.util.Locale.ROOT)) : null;
            if (mime == null || !(mime.startsWith("image/") || mime.startsWith("video/") || mime.startsWith("audio/"))) return;
            final String path = f.getAbsolutePath();
            final boolean appPrivate = path.startsWith(e.app.getFilesDir().getPath()) || path.contains("/Android/data/") || path.contains("/Android/obb/");
            if (!appPrivate) {
                android.media.MediaScannerConnection.scanFile(e.app, new String[]{path}, new String[]{mime}, null);
                return;
            }
            if (!mime.startsWith("image/") || priv || android.os.Build.VERSION.SDK_INT < 29) return;
            final android.content.ContentResolver cr = e.app.getContentResolver();
            final android.content.ContentValues cv = new android.content.ContentValues();
            cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, nm);
            cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime);
            cv.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_PICTURES + "/Abtin");
            cv.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1);
            final Uri u = cr.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv);
            if (u == null) return;
            try (InputStream in = new java.io.FileInputStream(f); OutputStream os = cr.openOutputStream(u)) {
                if (os == null) throw new java.io.IOException("no stream");
                final byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            } catch (Exception ex) {
                try { cr.delete(u, null, null); } catch (Throwable ignored) { }
                return;
            }
            final android.content.ContentValues fin = new android.content.ContentValues();
            fin.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(u, fin, null, null);
        } catch (Throwable t) { Log.w(Engine.TAG, "publishMedia", t); }
    }

    void removeTask(DlTask t) { tasks.remove(t.id); }
    void done(DlTask t) { tasks.remove(t.id); }

    void pause(String id) { final DlTask t = tasks.get(id); if (t != null) t.pause(); }

    /** Continue a paused / failed / app-restarted download from where it stopped (or start over if that's impossible). */
    void resume(final String id, final String url, @Nullable final String referer, @Nullable final String name, @Nullable final String path, final boolean priv) {
        pool.execute(() -> {
            // A task that was just paused is still winding down: wait for it instead of dropping the request.
            final DlTask old = tasks.get(id);
            if (old != null) {
                if (old.want == DlTask.RUN) return;
                for (int i = 0; i < 100 && tasks.containsKey(id); i++) { try { Thread.sleep(100); } catch (InterruptedException ie) { return; } }
                if (tasks.containsKey(id)) return;
            }
            DlTask t = path == null || path.isEmpty() ? null : DlTask.load(this, id, path, conns);
            if (t == null) {
                if (path != null && !path.isEmpty()) { new File(path + ".part").delete(); new File(path + ".part.abtin").delete(); }
                t = new DlTask(this, id, url, referer, priv, name, conns);
            }
            tasks.put(id, t);
            t.start();
        });
    }

    /** Explicit download of a URL (long-press image, retry...). */
    void fetch(String url, @Nullable String referer, @Nullable String name, boolean priv) {
        if (url == null) return;
        if (url.startsWith("http")) { startManaged(null, url, referer, name, priv); return; }
        if (executor == null) executor = new GeckoWebExecutor(e.runtime);
        final WebRequest.Builder b = new WebRequest.Builder(url);
        if (referer != null && !referer.isEmpty()) b.referrer(referer);
        final GeckoResult<WebResponse> res = executor.fetch(b.build(), priv ? GeckoWebExecutor.FETCH_FLAGS_PRIVATE : GeckoWebExecutor.FETCH_FLAGS_NONE);
        res.accept(r -> { if (r != null) save(r, name, priv, url); },
                err -> failed(url, name == null ? "download" : name, priv));
    }

    void cancel(String id, @Nullable String path) {
        final DlTask t = tasks.get(id);
        if (t != null) { t.cancel(); return; }
        final AtomicBoolean f = cancels.get(id);
        if (f != null) { f.set(true); return; }
        if (path != null && !path.isEmpty()) { new File(path + ".part").delete(); new File(path + ".part.abtin").delete(); }
    }

    private void failed(String url, String name, boolean priv) {
        final Map<String, Object> m = Engine.ev("download", 0);
        m.put("id", String.valueOf(System.nanoTime()));
        m.put("url", url);
        m.put("name", name);
        m.put("status", "failed");
        m.put("private", priv);
        e.emit(m);
    }

    private void save(final WebResponse r, @Nullable final String forcedName, final boolean priv, final String url) {
        final String id = String.valueOf(System.nanoTime());
        final String disp = header(r.headers, "content-disposition");
        final String lenH = header(r.headers, "content-length");
        final String mime = header(r.headers, "content-type");
        String nm = forcedName != null && !forcedName.trim().isEmpty() ? forcedName : nameFrom(disp, r.uri, mime);
        nm = clean(nm);
        final String fname = nm;
        long len = -1;
        try { if (lenH != null) len = Long.parseLong(lenH.trim()); } catch (Exception ignored) { }
        final long total = len;
        final AtomicBoolean cancelled = new AtomicBoolean(false);
        cancels.put(id, cancelled);
        pool.execute(() -> {
            final File dir = new File(e.downloadDir.isEmpty() ? e.app.getFilesDir().getPath() + "/Download" : e.downloadDir);
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            final File out = unique(dir, fname);
            long got = 0;
            long lastEmit = 0;
            String status = "done";
            emit(id, url, out, total, 0, "running", priv);
            if (r.body == null) status = "failed";
            else {
                try (InputStream in = r.body; OutputStream os = new FileOutputStream(out)) {
                    final byte[] buf = new byte[256 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        if (cancelled.get()) { status = "canceled"; break; }
                        os.write(buf, 0, n);
                        got += n;
                        final long now = System.currentTimeMillis();
                        if (now - lastEmit > 250) { lastEmit = now; emit(id, url, out, total, got, "running", priv); }
                    }
                } catch (Exception ex) {
                    Log.w(Engine.TAG, "download failed", ex);
                    status = cancelled.get() ? "canceled" : "failed";
                }
            }
            if (!"done".equals(status)) { //noinspection ResultOfMethodCallIgnored
                out.delete();
            }
            cancels.remove(id);
            if ("done".equals(status)) publishMedia(out, priv);
            emit(id, url, out, total < 0 ? got : total, got, status, priv);
        });
    }

    private void emit(String id, String url, File f, long total, long got, String status, boolean priv) {
        final Map<String, Object> m = Engine.ev("download", 0);
        m.put("id", id);
        m.put("url", url);
        m.put("name", f.getName());
        m.put("path", f.getAbsolutePath());
        m.put("total", total);
        m.put("received", got);
        m.put("status", status);
        m.put("private", priv);
        e.emit(m);
        if (e.dlNotif != null) e.dlNotif.update(id, f.getName(), got, total, status, f.getAbsolutePath(), priv);
    }

    static String header(Map<String, String> h, String key) {
        if (h == null) return null;
        for (Map.Entry<String, String> en : h.entrySet()) if (en.getKey() != null && en.getKey().equalsIgnoreCase(key)) return en.getValue();
        return null;
    }

    static String nameFrom(@Nullable String disp, String uri, @Nullable String mime) {
        if (disp != null) {
            Matcher m = Pattern.compile("filename\\*\\s*=\\s*[^']*'[^']*'([^;]+)", Pattern.CASE_INSENSITIVE).matcher(disp);
            if (m.find()) { try { return URLDecoder.decode(m.group(1).trim(), "UTF-8"); } catch (Exception ignored) { } }
            m = Pattern.compile("filename\\s*=\\s*\"?([^\";]+)\"?", Pattern.CASE_INSENSITIVE).matcher(disp);
            if (m.find()) return m.group(1).trim();
        }
        try {
            final String last = Uri.parse(uri).getLastPathSegment();
            if (last != null && !last.isEmpty() && !uri.startsWith("blob:")) return last;
        } catch (Exception ignored) { }
        if (mime != null && mime.contains("/")) {
            String ext = mime.split(";")[0].split("/")[1];
            if (ext.equals("jpeg")) ext = "jpg";
            return "download." + ext.replaceAll("[^a-zA-Z0-9]", "");
        }
        return "download";
    }

    static String clean(String n) {
        String c = n.replaceAll("[\\\\/:*?\"<>|\\x00-\\x1f]", "_").trim();
        if (c.isEmpty()) c = "download";
        return c.length() > 120 ? c.substring(c.length() - 120) : c;
    }

    private static File unique(File dir, String name) {
        File f = new File(dir, name);
        if (!f.exists()) return f;
        final int dot = name.lastIndexOf('.');
        final String base = dot > 0 ? name.substring(0, dot) : name;
        final String ext = dot > 0 ? name.substring(dot) : "";
        for (int i = 1; i < 1000; i++) {
            f = new File(dir, base + " (" + i + ")" + ext);
            if (!f.exists()) return f;
        }
        return new File(dir, System.currentTimeMillis() + "_" + name);
    }
}
