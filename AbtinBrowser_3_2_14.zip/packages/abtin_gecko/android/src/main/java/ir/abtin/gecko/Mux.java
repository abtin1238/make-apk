package ir.abtin.gecko;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.util.Log;

import java.io.File;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Remuxes (no re-encode) one or more media files into a single MP4: first video track + first audio track found. */
final class Mux {
    private Mux() { }

    static boolean run(List<String> inputs, String out) {
        final List<MediaExtractor> exs = new ArrayList<>();
        final List<Map<Integer, Integer>> maps = new ArrayList<>();
        MediaMuxer mm = null;
        boolean started = false;
        try {
            final File of = new File(out);
            //noinspection ResultOfMethodCallIgnored
            if (of.exists()) of.delete();
            mm = new MediaMuxer(out, out.toLowerCase().endsWith(".webm") ? MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM : MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            boolean hasV = false, hasA = false;
            for (String p : inputs) {
                final MediaExtractor ex = new MediaExtractor();
                exs.add(ex);
                final Map<Integer, Integer> map = new HashMap<>();
                maps.add(map);
                ex.setDataSource(p);
                for (int i = 0; i < ex.getTrackCount(); i++) {
                    final MediaFormat f = ex.getTrackFormat(i);
                    final String mime = f.getString(MediaFormat.KEY_MIME);
                    if (mime == null) continue;
                    final boolean v = mime.startsWith("video/"), a = mime.startsWith("audio/");
                    if ((!v && !a) || (v && hasV) || (a && hasA)) continue;
                    ex.selectTrack(i);
                    map.put(i, mm.addTrack(f));
                    if (v) hasV = true; else hasA = true;
                }
            }
            if (!hasV && !hasA) return false;
            mm.start();
            started = true;
            final ByteBuffer buf = ByteBuffer.allocate(8 * 1024 * 1024);
            final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            final int n = exs.size();
            final long[] base = new long[n];
            final boolean[] live = new boolean[n];
            for (int k = 0; k < n; k++) {
                final long t0 = maps.get(k).isEmpty() ? -1 : exs.get(k).getSampleTime();
                live[k] = t0 >= 0;
                base[k] = Math.max(0, t0);
            }
            // Interleave by timestamp so the output is a normal, seekable file (video and audio side by side).
            while (true) {
                int pick = -1;
                long best = Long.MAX_VALUE;
                for (int k = 0; k < n; k++) {
                    if (!live[k]) continue;
                    final long t = exs.get(k).getSampleTime();
                    if (t < 0) { live[k] = false; continue; }
                    if (t - base[k] < best) { best = t - base[k]; pick = k; }
                }
                if (pick < 0) break;
                final MediaExtractor ex = exs.get(pick);
                buf.clear();
                final int size = ex.readSampleData(buf, 0);
                if (size < 0) { live[pick] = false; continue; }
                final Integer mt = maps.get(pick).get(ex.getSampleTrackIndex());
                if (mt != null) {
                    info.offset = 0;
                    info.size = size;
                    info.presentationTimeUs = Math.max(0, ex.getSampleTime() - base[pick]);
                    info.flags = (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                    mm.writeSampleData(mt, buf, info);
                }
                ex.advance();
            }
            return true;
        } catch (Throwable t) {
            Log.w(Engine.TAG, "mux failed", t);
            return false;
        } finally {
            try { if (mm != null) { if (started) mm.stop(); mm.release(); } } catch (Throwable ignored) { }
            for (MediaExtractor ex : exs) { try { ex.release(); } catch (Throwable ignored) { } }
        }
    }
}
