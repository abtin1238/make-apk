package ir.abtin.gecko;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.pdf.PdfRenderer;
import android.media.MediaMetadataRetriever;
import android.os.ParcelFileDescriptor;
import android.util.Log;

import androidx.annotation.Nullable;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Square thumbnails (image / video frame / audio cover / APK icon / first PDF page) for the downloads screen, cached on disk. */
final class Thumbs {
    private static final Set<String> IMG = new HashSet<>(Arrays.asList("jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "avif"));
    private static final Set<String> VID = new HashSet<>(Arrays.asList("mp4", "m4v", "webm", "mkv", "mov", "3gp", "avi", "ts"));
    private static final Set<String> AUD = new HashSet<>(Arrays.asList("mp3", "m4a", "aac", "ogg", "opus", "flac", "wav"));

    private Thumbs() { }

    @Nullable static byte[] make(Context ctx, @Nullable String path, int size) {
        if (path == null || path.isEmpty()) return null;
        try {
            final File f = new File(path);
            if (!f.exists() || f.length() == 0) return null;
            final String n = f.getName().toLowerCase(Locale.ROOT);
            final String ext = n.contains(".") ? n.substring(n.lastIndexOf('.') + 1) : "";
            final boolean known = IMG.contains(ext) || VID.contains(ext) || AUD.contains(ext) || "apk".equals(ext) || "pdf".equals(ext);
            if (!known) return null;
            final File cache = new File(ctx.getCacheDir(), "thumbs");
            //noinspection ResultOfMethodCallIgnored
            cache.mkdirs();
            final File cf = new File(cache, Integer.toHexString((path + f.length() + f.lastModified() + size).hashCode()) + ".jpg");
            if (cf.exists()) return read(cf);
            Bitmap bmp = null;
            if (IMG.contains(ext)) bmp = image(path, size);
            else if (VID.contains(ext)) bmp = video(path, size);
            else if (AUD.contains(ext)) bmp = audio(path, size);
            else if ("apk".equals(ext)) bmp = apk(ctx, path, size);
            else if ("pdf".equals(ext)) bmp = pdf(path, size);
            if (bmp == null) return null;
            final Bitmap sq = square(bmp, size);
            final ByteArrayOutputStream bo = new ByteArrayOutputStream();
            sq.compress(Bitmap.CompressFormat.JPEG, 82, bo);
            final byte[] out = bo.toByteArray();
            try (FileOutputStream os = new FileOutputStream(cf)) { os.write(out); } catch (Throwable ignored) { }
            return out;
        } catch (Throwable t) {
            Log.w(Engine.TAG, "thumb " + path, t);
            return null;
        }
    }

    private static byte[] read(File f) throws Exception {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            final byte[] b = new byte[(int) f.length()];
            int off = 0, r;
            while (off < b.length && (r = in.read(b, off, b.length - off)) > 0) off += r;
            return b;
        }
    }

    @Nullable private static Bitmap image(String path, int size) {
        final BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, o);
        if (o.outWidth <= 0) return null;
        int s = 1;
        while (o.outWidth / (s * 2) >= size && o.outHeight / (s * 2) >= size) s *= 2;
        final BitmapFactory.Options d = new BitmapFactory.Options();
        d.inSampleSize = s;
        return BitmapFactory.decodeFile(path, d);
    }

    @Nullable private static Bitmap video(String path, int size) {
        final MediaMetadataRetriever m = new MediaMetadataRetriever();
        try {
            m.setDataSource(path);
            Bitmap b = m.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (b == null) b = m.getFrameAtTime(0);
            return b;
        } catch (Throwable t) { return null; } finally { try { m.release(); } catch (Throwable ignored) { } }
    }

    @Nullable private static Bitmap audio(String path, int size) {
        final MediaMetadataRetriever m = new MediaMetadataRetriever();
        try {
            m.setDataSource(path);
            final byte[] pic = m.getEmbeddedPicture();
            return pic == null ? null : BitmapFactory.decodeByteArray(pic, 0, pic.length);
        } catch (Throwable t) { return null; } finally { try { m.release(); } catch (Throwable ignored) { } }
    }

    @Nullable private static Bitmap apk(Context ctx, String path, int size) {
        final PackageManager pm = ctx.getPackageManager();
        final PackageInfo pi = pm.getPackageArchiveInfo(path, 0);
        if (pi == null || pi.applicationInfo == null) return null;
        final ApplicationInfo ai = pi.applicationInfo;
        ai.sourceDir = path;
        ai.publicSourceDir = path;
        final Drawable dr = ai.loadIcon(pm);
        if (dr == null) return null;
        final int w = Math.max(size, 64);
        final Bitmap b = Bitmap.createBitmap(w, w, Bitmap.Config.ARGB_8888);
        b.eraseColor(Color.WHITE);
        final Canvas c = new Canvas(b);
        dr.setBounds(0, 0, w, w);
        dr.draw(c);
        return b;
    }

    @Nullable private static Bitmap pdf(String path, int size) {
        try (ParcelFileDescriptor fd = ParcelFileDescriptor.open(new File(path), ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer r = new PdfRenderer(fd)) {
            if (r.getPageCount() == 0) return null;
            try (PdfRenderer.Page p = r.openPage(0)) {
                final int w = size * 2, h = Math.max(1, (int) ((long) w * p.getHeight() / Math.max(1, p.getWidth())));
                final Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
                b.eraseColor(Color.WHITE);
                p.render(b, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                return b;
            }
        } catch (Throwable t) { return null; }
    }

    /** Center-crop to a size x size square. */
    private static Bitmap square(Bitmap src, int size) {
        final int w = src.getWidth(), h = src.getHeight(), side = Math.min(w, h);
        final Bitmap crop = Bitmap.createBitmap(src, (w - side) / 2, (h - side) / 2, side, side);
        final Bitmap flat = Bitmap.createBitmap(side, side, Bitmap.Config.ARGB_8888);
        flat.eraseColor(Color.WHITE);
        new Canvas(flat).drawBitmap(crop, 0, 0, null);
        return side == size ? flat : Bitmap.createScaledBitmap(flat, size, size, true);
    }
}
