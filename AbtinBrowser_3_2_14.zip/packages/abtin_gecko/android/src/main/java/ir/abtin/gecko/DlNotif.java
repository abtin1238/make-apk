package ir.abtin.gecko;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** System notifications with live progress for downloads; tapping a finished one opens the file. */
final class DlNotif {
    private static final String CH = "abtin_downloads";
    private final Engine e;
    private final NotificationManager nm;
    private final Map<String, Long> last = new ConcurrentHashMap<>();
    private boolean asked;
    private static final String ACT = "ir.abtin.gecko.DL_ACTION";
    private final Map<String, String> ids = new ConcurrentHashMap<>(); // notification id -> download id

    private void registerReceiver() {
        final BroadcastReceiver rc = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                final String id = ids.get(String.valueOf(i.getIntExtra("nid", 0)));
                if (id == null) return;
                final Map<String, Object> m = Engine.ev("dlAction", 0);
                m.put("id", id);
                m.put("action", i.getStringExtra("action"));
                e.emit(m); // Dart owns url/path, so it performs pause / resume / cancel
            }
        };
        try {
            if (Build.VERSION.SDK_INT >= 33) e.app.registerReceiver(rc, new IntentFilter(ACT), Context.RECEIVER_NOT_EXPORTED);
            else e.app.registerReceiver(rc, new IntentFilter(ACT));
        } catch (Throwable t) { Log.w(Engine.TAG, "receiver", t); }
    }

    private Notification.Action act(int nid, String action, String label, int icon) {
        final Intent i = new Intent(ACT).setPackage(e.app.getPackageName()).putExtra("nid", nid).putExtra("action", action);
        final PendingIntent pi = PendingIntent.getBroadcast(e.app, (nid + ":" + action).hashCode(), i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Action.Builder(android.graphics.drawable.Icon.createWithResource("android", icon), label, pi).build();
    }

    DlNotif(Engine e) {
        this.e = e;
        nm = (NotificationManager) e.app.getSystemService(Context.NOTIFICATION_SERVICE);
        try {
            final NotificationChannel c = new NotificationChannel(CH, "fa".equals(e.lang) ? "دانلودها" : "Downloads", NotificationManager.IMPORTANCE_LOW);
            c.setShowBadge(false);
            nm.createNotificationChannel(c);
        } catch (Throwable t) { Log.w(Engine.TAG, "channel", t); }
        registerReceiver();
    }

    private boolean allowed() {
        return Build.VERSION.SDK_INT < 33 || e.app.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private void askPermission() {
        if (asked || Build.VERSION.SDK_INT < 33 || e.activity == null || allowed()) return;
        asked = true;
        try { e.activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, Engine.REQ_NOTIF); } catch (Throwable t) { Log.w(Engine.TAG, "notif perm", t); }
    }

    private static String size(long b) {
        if (b < 1024) return b + " B";
        if (b < 1048576) return String.format(java.util.Locale.US, "%.1f KB", b / 1024.0);
        if (b < 1073741824L) return String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0);
        return String.format(java.util.Locale.US, "%.2f GB", b / 1073741824.0);
    }

    void update(String id, String name, long got, long total, String status, String path, boolean priv) {
        if (priv) return;
        try {
            final boolean fa = "fa".equals(e.lang);
            final boolean running = "running".equals(status);
            if (running) {
                askPermission();
                final long now = System.currentTimeMillis();
                final Long prev = last.get(id);
                if (prev != null && now - prev < 700) return;
                last.put(id, now);
            } else last.remove(id);
            final int nid = 1000 + ((id.hashCode() & 0x7fffffff) % 900000);
            ids.put(String.valueOf(nid), id);
            if ("canceled".equals(status)) { nm.cancel(nid); ids.remove(String.valueOf(nid)); return; }
            if (!allowed()) return;
            final Notification.Builder b = new Notification.Builder(e.app, CH).setContentTitle(name).setOnlyAlertOnce(true);
            final Intent launch = e.app.getPackageManager().getLaunchIntentForPackage(e.app.getPackageName());
            PendingIntent pi = launch == null ? null : PendingIntent.getActivity(e.app, nid, launch, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            if (running) {
                final int pct = total > 0 ? (int) Math.min(100, got * 100 / total) : 0;
                b.setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true).setProgress(100, pct, total <= 0)
                        .setContentText(total > 0 ? size(got) + " / " + size(total) + "  (" + pct + "%)" : size(got));
                if (id.startsWith("n")) b.addAction(act(nid, "pause", fa ? "توقف" : "Pause", android.R.drawable.ic_media_pause));
                b.addAction(act(nid, "cancel", fa ? "لغو" : "Cancel", android.R.drawable.ic_menu_close_clear_cancel));
            } else if ("done".equals(status)) {
                b.setSmallIcon(android.R.drawable.stat_sys_download_done).setAutoCancel(true).setOngoing(false)
                        .setContentText(fa ? "دانلود کامل شد؛ برای باز کردن بزنید" : "Download complete - tap to open");
                final Intent view = path == null ? null : e.viewIntent(path, null);
                if (view != null) pi = PendingIntent.getActivity(e.app, nid, view, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            } else if ("paused".equals(status)) {
                final int pct = total > 0 ? (int) Math.min(100, got * 100 / total) : 0;
                b.setSmallIcon(android.R.drawable.ic_media_pause).setOngoing(false).setProgress(100, pct, false)
                        .setContentText((fa ? "متوقف شد · " : "Paused · ") + (total > 0 ? size(got) + " / " + size(total) : size(got)));
                b.addAction(act(nid, "resume", fa ? "ادامه" : "Resume", android.R.drawable.ic_media_play));
                b.addAction(act(nid, "cancel", fa ? "لغو" : "Cancel", android.R.drawable.ic_menu_close_clear_cancel));
            } else {
                b.setSmallIcon(android.R.drawable.stat_sys_warning).setAutoCancel(true).setOngoing(false)
                        .setContentText(fa ? "دانلود ناموفق بود" : "Download failed");
                if (id.startsWith("n")) b.addAction(act(nid, "resume", fa ? "تلاش دوباره" : "Retry", android.R.drawable.ic_media_play));
            }
            if (pi != null) b.setContentIntent(pi);
            nm.notify(nid, b.build());
        } catch (Throwable t) { Log.w(Engine.TAG, "notif", t); }
    }
}
