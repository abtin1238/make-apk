package ir.abtin.gecko;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Encrypted on-device wallet metadata. CVV/CVC values are intentionally never accepted or stored. */
final class PersonalVault {
    private static final String TAG = "AbtinVault";
    private static final String ALIAS = "abtin_personal_vault_v1";
    private final File file;
    private final List<JSONObject> items = new ArrayList<>();
    private boolean loaded;

    PersonalVault(Context context) { file = new File(context.getFilesDir(), "personal_vault.enc"); }

    private static SecretKey key() throws Exception {
        final KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            final KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            g.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build());
            return g.generateKey();
        }
        return (SecretKey) ks.getKey(ALIAS, null);
    }

    private static byte[] encrypt(byte[] plain) throws Exception {
        final Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key());
        final byte[] iv = c.getIV(), encrypted = c.doFinal(plain);
        final byte[] out = new byte[1 + iv.length + encrypted.length];
        out[0] = (byte) iv.length;
        System.arraycopy(iv, 0, out, 1, iv.length);
        System.arraycopy(encrypted, 0, out, 1 + iv.length, encrypted.length);
        return out;
    }

    private static byte[] decrypt(byte[] data) throws Exception {
        final int n = data[0] & 0xff;
        final Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, data, 1, n));
        return c.doFinal(data, 1 + n, data.length - 1 - n);
    }

    private synchronized void load() {
        if (loaded) return;
        loaded = true;
        try {
            if (!file.exists()) return;
            final byte[] buf = new byte[(int) file.length()];
            try (FileInputStream in = new FileInputStream(file)) {
                int off = 0;
                while (off < buf.length) { final int n = in.read(buf, off, buf.length - off); if (n < 0) break; off += n; }
            }
            final JSONArray a = new JSONArray(new String(decrypt(buf), "UTF-8"));
            for (int i = 0; i < a.length(); i++) items.add(a.getJSONObject(i));
        } catch (Throwable t) { Log.e(TAG, "vault load failed", t); }
    }

    private synchronized void persist() {
        try {
            final JSONArray a = new JSONArray();
            for (JSONObject item : items) a.put(item);
            final File tmp = new File(file.getPath() + ".tmp");
            try (FileOutputStream out = new FileOutputStream(tmp)) {
                out.write(encrypt(a.toString().getBytes("UTF-8")));
                out.getFD().sync();
            }
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file); }
        } catch (Throwable t) { Log.e(TAG, "vault save failed", t); }
    }

    synchronized List<java.util.Map<String, Object>> list() {
        load();
        final List<java.util.Map<String, Object>> out = new ArrayList<>();
        for (JSONObject item : items) {
            final java.util.Map<String, Object> row = new java.util.HashMap<>();
            for (String key : new String[]{"id", "kind", "label", "holder", "number", "expiry", "name", "street", "city", "region", "postal", "country", "phone", "email"}) {
                final String value = item.optString(key, "");
                if (!value.isEmpty()) row.put(key, value);
            }
            out.add(row);
        }
        return out;
    }

    synchronized java.util.Map<String, Object> get(String id) {
        load();
        if (id == null) return null;
        for (JSONObject item : items) {
            if (!id.equals(item.optString("id"))) continue;
            final java.util.Map<String, Object> row = new java.util.HashMap<>();
            for (String key : new String[]{"id", "kind", "label", "holder", "number", "expiry", "name", "street", "city", "region", "postal", "country", "phone", "email"}) {
                final String value = item.optString(key, "");
                if (!value.isEmpty()) row.put(key, value);
            }
            return row;
        }
        return null;
    }

    /** Accepts only named fields; no CVV/CVC field is read or persisted. */
    synchronized boolean put(String id, java.util.Map<String, Object> input) {
        load();
        if (input == null) return false;
        final String kind = value(input, "kind");
        if (!"card".equals(kind) && !"address".equals(kind)) return false;
        try {
            final JSONObject item = new JSONObject();
            final String actualId = id == null || id.isEmpty() ? UUID.randomUUID().toString() : id;
            item.put("id", actualId);
            item.put("kind", kind);
            final String[] common = {"label", "holder", "number", "expiry", "name", "street", "city", "region", "postal", "country", "phone", "email"};
            for (String key : common) {
                final String v = value(input, key).trim();
                if (!v.isEmpty()) item.put(key, v);
            }
            if ("card".equals(kind)) {
                final String digits = value(input, "number").replaceAll("[^0-9]", "");
                if (digits.length() < 12 || digits.length() > 19 || !luhn(digits) || value(input, "expiry").trim().isEmpty()) return false;
                item.put("number", digits);
                item.remove("name"); item.remove("street"); item.remove("city"); item.remove("region");
                item.remove("postal"); item.remove("country"); item.remove("phone"); item.remove("email");
            } else {
                if (value(input, "name").trim().isEmpty() || value(input, "street").trim().isEmpty()) return false;
                item.remove("holder"); item.remove("number"); item.remove("expiry");
            }
            for (int i = 0; i < items.size(); i++) {
                if (actualId.equals(items.get(i).optString("id"))) { items.set(i, item); persist(); return true; }
            }
            items.add(item);
            persist();
            return true;
        } catch (Throwable t) { Log.e(TAG, "vault put failed", t); return false; }
    }

    synchronized void delete(String id) {
        load();
        if (id == null) return;
        items.removeIf(item -> id.equals(item.optString("id")));
        persist();
    }

    private static String value(java.util.Map<String, Object> map, String key) {
        final Object v = map.get(key);
        return v == null ? "" : String.valueOf(v);
    }

    private static boolean luhn(String digits) {
        int sum = 0;
        boolean twice = false;
        for (int i = digits.length() - 1; i >= 0; i--) {
            int n = digits.charAt(i) - '0';
            if (twice) { n *= 2; if (n > 9) n -= 9; }
            sum += n;
            twice = !twice;
        }
        return sum % 10 == 0;
    }
}
