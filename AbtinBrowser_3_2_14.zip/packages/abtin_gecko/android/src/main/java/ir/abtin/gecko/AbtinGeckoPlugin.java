package ir.abtin.gecko;

import android.content.Intent;

import androidx.annotation.NonNull;

import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.embedding.engine.plugins.activity.ActivityAware;
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding;
import io.flutter.plugin.common.EventChannel;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugin.common.PluginRegistry;

public final class AbtinGeckoPlugin implements FlutterPlugin, ActivityAware, MethodChannel.MethodCallHandler,
        EventChannel.StreamHandler, PluginRegistry.ActivityResultListener, PluginRegistry.RequestPermissionsResultListener,
        PluginRegistry.NewIntentListener {

    private Engine engine;
    private MethodChannel channel;
    private EventChannel events;
    private ActivityPluginBinding binding;

    @Override
    public void onAttachedToEngine(@NonNull FlutterPluginBinding b) {
        engine = Engine.I != null ? Engine.I : new Engine(b.getApplicationContext());
        channel = new MethodChannel(b.getBinaryMessenger(), "abtin/gecko");
        channel.setMethodCallHandler(this);
        engine.channel = channel;
        events = new EventChannel(b.getBinaryMessenger(), "abtin/gecko/events");
        events.setStreamHandler(this);
        b.getPlatformViewRegistry().registerViewFactory(GeckoPlatformView.VIEW_TYPE, new GeckoPlatformView.Factory(engine));
        // Do not start Gecko while Flutter is attaching plugins. GeckoRuntime startup can
        // be expensive and, on some devices, can stall the first Android frame. The Dart
        // boot screen is shown first; Engine.init is then called explicitly by BootApp.
    }

    @Override
    public void onDetachedFromEngine(@NonNull FlutterPluginBinding b) {
        channel.setMethodCallHandler(null);
        events.setStreamHandler(null);
        if (engine.channel == channel) engine.channel = null;
        engine.sink = null;
    }

    @Override
    public void onMethodCall(@NonNull MethodCall call, @NonNull MethodChannel.Result result) { engine.onCall(call, result); }

    @Override
    public void onListen(Object args, EventChannel.EventSink sink) { engine.sink = sink; }

    @Override
    public void onCancel(Object args) { engine.sink = null; }

    @Override public void onAttachedToActivity(@NonNull ActivityPluginBinding b) { attach(b); }
    @Override public void onReattachedToActivityForConfigChanges(@NonNull ActivityPluginBinding b) { attach(b); }
    @Override public void onDetachedFromActivityForConfigChanges() { detach(); }
    @Override public void onDetachedFromActivity() { detach(); }

    private void attach(ActivityPluginBinding b) {
        binding = b;
        engine.activity = b.getActivity();
        // Text-selection toolbar (copy / select all) must belong to the CURRENT activity: tabs outlive the activity, so rebind them.
        try {
            for (Tab t : new java.util.ArrayList<>(engine.tabs.values())) {
                if (t.session != null) t.session.setSelectionActionDelegate(new org.mozilla.geckoview.BasicSelectionActionDelegate(b.getActivity()));
            }
        } catch (Throwable ignored) {}
        b.addActivityResultListener(this);
        b.addRequestPermissionsResultListener(this);
        b.addOnNewIntentListener(this);
        engine.handleIntent(b.getActivity().getIntent());
    }

    private void detach() {
        if (binding != null) {
            binding.removeActivityResultListener(this);
            binding.removeRequestPermissionsResultListener(this);
            binding.removeOnNewIntentListener(this);
        }
        binding = null;
        engine.activity = null;
    }

    @Override
    public boolean onNewIntent(@NonNull Intent intent) {
        engine.handleIntent(intent);
        return false;
    }

    @Override
    public boolean onActivityResult(int requestCode, int resultCode, Intent data) { return engine.onActivityResult(requestCode, resultCode, data); }

    @Override
    public boolean onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        return engine.onPermissionsResult(requestCode, permissions, grantResults);
    }
}
