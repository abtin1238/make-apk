package ir.abtin.gecko;

import android.net.Uri;

import org.mozilla.geckoview.WebRequestError;

/** Builds the data: URI shown by Gecko for failed loads (Gecko injects document.addCertException etc.). */
final class ErrorPage {
    private ErrorPage() {}

    static String build(String lang, boolean dark, int accent, String uri, WebRequestError e) {
        final boolean fa = "fa".equals(lang);
        String title;
        String body;
        boolean cert = false;
        boolean httpsOnly = false;
        switch (e.code) {
            case WebRequestError.ERROR_SECURITY_BAD_CERT:
            case WebRequestError.ERROR_BAD_HSTS_CERT:
                cert = true;
                title = fa ? "اتصال شما امن نیست" : "Your connection is not secure";
                body = fa ? "گواهی امنیتی این سایت معتبر نیست. ممکن است کسی در حال شنود اطلاعات شما باشد."
                        : "The security certificate of this site is not valid. Someone may be intercepting your data.";
                break;
            case WebRequestError.ERROR_SECURITY_SSL:
                title = fa ? "خطای اتصال امن" : "Secure connection failed";
                body = fa ? "برقراری اتصال امن (TLS) با این سایت ممکن نشد." : "A secure (TLS) connection could not be established.";
                break;
            case WebRequestError.ERROR_HTTPS_ONLY:
                httpsOnly = true;
                title = fa ? "این سایت HTTPS ندارد" : "This site does not support HTTPS";
                body = fa ? "حالت «فقط HTTPS» فعال است و این سایت اتصال امن ارائه نمی‌دهد."
                        : "HTTPS-only mode is on and this site does not offer a secure connection.";
                break;
            case WebRequestError.ERROR_UNKNOWN_HOST:
                title = fa ? "سایت پیدا نشد" : "Server not found";
                body = fa ? "نشانی سایت را بررسی کنید و از اتصال اینترنت مطمئن شوید." : "Check the address and your internet connection.";
                break;
            case WebRequestError.ERROR_CONNECTION_REFUSED:
                title = fa ? "اتصال رد شد" : "Connection refused";
                body = fa ? "سرور اتصال را نپذیرفت." : "The server refused the connection.";
                break;
            case WebRequestError.ERROR_NET_TIMEOUT:
                title = fa ? "زمان اتصال تمام شد" : "Connection timed out";
                body = fa ? "سرور به‌موقع پاسخ نداد." : "The server took too long to respond.";
                break;
            case WebRequestError.ERROR_OFFLINE:
                title = fa ? "اینترنت قطع است" : "You are offline";
                body = fa ? "اتصال اینترنت دستگاه را بررسی کنید." : "Check your device's internet connection.";
                break;
            case WebRequestError.ERROR_SAFEBROWSING_MALWARE_URI:
            case WebRequestError.ERROR_SAFEBROWSING_PHISHING_URI:
            case WebRequestError.ERROR_SAFEBROWSING_UNWANTED_URI:
            case WebRequestError.ERROR_SAFEBROWSING_HARMFUL_URI:
                title = fa ? "سایت خطرناک" : "Deceptive or dangerous site";
                body = fa ? "مرور امن این سایت را مخرب یا فریبنده گزارش کرده است." : "Safe Browsing reports this site as harmful or deceptive.";
                break;
            default:
                title = fa ? "این صفحه در دسترس نیست" : "This page is unavailable";
                body = (fa ? "کد خطا: " : "Error code: ") + e.category + "/" + e.code;
        }
        final String bg = dark ? "#071326" : "#f3f6fc";
        final String fg = dark ? "#e6edf7" : "#1a1a1a";
        final String card = dark ? "#102440" : "#ffffff";
        final String acc = String.format("#%06X", accent & 0xFFFFFF);
        final String js = jsStr(uri == null ? "" : uri);
        final StringBuilder b = new StringBuilder();
        b.append("<!doctype html><html dir=\"").append(fa ? "rtl" : "ltr").append("\"><head><meta charset=\"utf-8\">")
                .append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>")
                .append(esc(title)).append("</title><style>")
                .append("body{margin:0;background:").append(bg).append(";color:").append(fg)
                .append(";font-family:sans-serif;display:flex;min-height:100vh;align-items:center;justify-content:center}")
                .append(".c{max-width:460px;margin:20px;padding:28px;background:").append(card).append(";border-radius:20px;text-align:center}")
                .append("h1{font-size:21px;margin:12px 0}p{opacity:.8;line-height:1.7}.u{direction:ltr;word-break:break-all;font-size:12px;opacity:.6}")
                .append("button{font-size:16px;border:0;border-radius:14px;padding:12px 20px;margin:6px;background:").append(acc).append(";color:#fff}")
                .append("button.o{background:transparent;color:").append(fg).append(";border:1px solid #888}")
                .append("</style></head><body><div class=\"c\"><div style=\"font-size:54px\">").append(cert || httpsOnly ? "&#x26A0;" : "&#x2601;")
                .append("</div><h1>").append(esc(title)).append("</h1><p>").append(esc(body)).append("</p><p class=\"u\">")
                .append(esc(uri == null ? "" : uri)).append("</p>");
        b.append("<button onclick=\"location.replace(").append(js).append(")\">").append(fa ? "تلاش دوباره" : "Retry").append("</button>");
        b.append("<button class=\"o\" onclick=\"history.back()\">").append(fa ? "بازگشت" : "Go back").append("</button>");
        if (cert) {
            b.append("<br><button class=\"o\" onclick=\"document.addCertException(true).then(function(){location.replace(")
                    .append(js).append(")})\">").append(fa ? "ادامه (ناامن)" : "Proceed (unsafe)").append("</button>");
        }
        if (httpsOnly) {
            b.append("<br><button class=\"o\" onclick=\"document.reloadWithHttpsOnlyException()\">")
                    .append(fa ? "ادامه با HTTP" : "Continue with HTTP").append("</button>");
        }
        b.append("</div></body></html>");
        return "data:text/html;charset=utf-8," + Uri.encode(b.toString());
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private static String jsStr(String s) {
        final StringBuilder b = new StringBuilder("&quot;");
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (c == '\\') b.append("\\\\");
            else if (c == '"') b.append("\\u0022");
            else if (c == '&') b.append("&amp;");
            else if (c == '<') b.append("\\u003c");
            else if (c == '\n' || c == '\r') b.append(' ');
            else b.append(c);
        }
        return b.append("&quot;").toString();
    }
}
