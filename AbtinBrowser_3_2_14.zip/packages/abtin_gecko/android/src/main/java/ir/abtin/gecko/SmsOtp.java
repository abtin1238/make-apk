package ir.abtin.gecko;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.provider.Telephony;
import android.telephony.SmsMessage;
import android.util.Log;

import org.json.JSONObject;
import org.mozilla.geckoview.WebExtension;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads the one-time code of an incoming SMS (login / verification codes) and hands it to the page that is on screen.
 *
 * - Needs the RECEIVE_SMS permission (asked once, the first time a page shows a code field, or from Settings).
 * - The SMS text is never stored, logged or sent to a page: only the extracted digits (and the optional "@host" hint of the
 *   Web OTP format) go to the foreground page's content script, which fills the field. A code is kept for 5 minutes.
 */
final class SmsOtp {
    static final int REQ_SMS = 0x4A15;
    private static final String TAG = "AbtinSms";
    private static final long TTL_MS = 5 * 60_000L;

    private final Engine e;
    private final Context app;
    private BroadcastReceiver rx;
    private volatile boolean wanted = true;

    private String code;
    private String host = "";
    private long at;

    SmsOtp(Engine e) {
        this.e = e;
        this.app = e.app;
    }

    // ------------------------------------------------------------------ permission / receiver

    boolean granted() {
        try { return app.checkSelfPermission(Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable t) { return false; }
    }

    void setEnabled(boolean on) {
        wanted = on;
        refresh();
    }

    /** Registers / unregisters the receiver to match the setting and the permission. */
    synchronized void refresh() {
        if (wanted && granted()) start(); else stop();
        if (!wanted) clear();
    }

    private void start() {
        if (rx != null) return;
        try {
            rx = new BroadcastReceiver() {
                @Override public void onReceive(Context c, Intent i) {
                    try {
                        if (i == null || !Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(i.getAction())) return;
                        final SmsMessage[] ms = Telephony.Sms.Intents.getMessagesFromIntent(i);
                        if (ms == null || ms.length == 0) return;
                        final StringBuilder sb = new StringBuilder();
                        for (SmsMessage m : ms) if (m != null && m.getMessageBody() != null) sb.append(m.getMessageBody());
                        onSms(sb.toString());
                    } catch (Throwable t) { Log.w(TAG, "sms", t); }
                }
            };
            // Only the system may send this broadcast (BROADCAST_SMS), hence exported.
            app.registerReceiver(rx, new IntentFilter(Telephony.Sms.Intents.SMS_RECEIVED_ACTION),
                    Manifest.permission.BROADCAST_SMS, null, Context.RECEIVER_EXPORTED);
        } catch (Throwable t) {
            Log.w(TAG, "register", t);
            rx = null;
        }
    }

    private void stop() {
        if (rx == null) return;
        try { app.unregisterReceiver(rx); } catch (Throwable ignored) { }
        rx = null;
    }

    private SharedPreferences prefs() { return app.getSharedPreferences("abtin_sms", Context.MODE_PRIVATE); }

    /** Asks for the permission. [force] = the user turned the setting on; otherwise only once per install. */
    void request(boolean force) {
        if (!wanted && !force) return;
        if (force) wanted = true;
        if (granted()) { refresh(); return; }
        if (!force && prefs().getBoolean("asked", false)) return;
        final Activity a = e.act();
        if (a == null) return;
        prefs().edit().putBoolean("asked", true).apply();
        try { a.requestPermissions(new String[]{Manifest.permission.RECEIVE_SMS}, REQ_SMS); }
        catch (Throwable t) { Log.w(TAG, "perm", t); }
    }

    void onResult() { refresh(); }

    // ------------------------------------------------------------------ incoming codes

    private void onSms(String body) {
        final String[] r = parse(body);
        if (r == null) return;
        synchronized (this) { code = r[0]; host = r[1]; at = System.currentTimeMillis(); }
        e.main.post(this::pushForeground);
    }

    synchronized void clear() { code = null; host = ""; at = 0; }

    private synchronized JSONObject payload() {
        if (code == null || System.currentTimeMillis() - at > TTL_MS) { code = null; return null; }
        try { return new JSONObject().put("cmd", "otp").put("code", code).put("host", host).put("ts", at); }
        catch (Throwable t) { return null; }
    }

    /** A code field got focus in a page: ask for the permission once, or answer with a fresh code if there is one. */
    void onField(WebExtension.Port p) {
        if (!wanted) return;
        if (!granted()) { request(false); return; }
        final JSONObject j = payload();
        if (j == null || p == null) return;
        try { p.postMessage(j); } catch (Throwable t) { Log.w(TAG, "push", t); }
    }

    /** Sends the fresh code (if any) to the page that is on screen: the web app window, else the browser's current tab. */
    void pushForeground() {
        final JSONObject j = payload();
        if (j == null) return;
        final Activity p = e.pwaActivity;
        if (p instanceof PwaActivity) { ((PwaActivity) p).deliverOtp(j); return; }
        final Tab t = e.current;
        boolean ok = false;
        if (t != null && t.contentPort != null) {
            try { t.contentPort.postMessage(j); ok = true; } catch (Throwable ex) { t.contentPort = null; }
        }
        if (!ok && e.extensions != null) e.extensions.relayToActiveTab(j);
    }

    // ------------------------------------------------------------------ parsing

    private static final Pattern WEB_OTP = Pattern.compile("@([a-z0-9.\\-]+)\\s+#(\\d{4,10})", Pattern.CASE_INSENSITIVE);
    private static final Pattern KEYED = Pattern.compile(
            "(?:code|otp|pin|passcode|password|verification|verify|\u06a9\u062f|\u0631\u0645\u0632|\u06af\u0630\u0631\u0648\u0627\u0698\u0647|\u067e\u0633\u0648\u0631\u062f)\\D{0,32}?(?<!\\d)(\\d{4,8})(?!\\d)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern ANY = Pattern.compile("(?<![\\d+\\-])(\\d{4,8})(?![\\d\\-])");
    private static final String[] WORDS = {
            "code", "otp", "pin", "passcode", "password", "verification", "verify", "one-time", "one time", "login", "log in", "sign in",
            "\u06a9\u062f", "\u0631\u0645\u0632", "\u062a\u0627\u06cc\u06cc\u062f", "\u062a\u0623\u06cc\u06cc\u062f", "\u0648\u0631\u0648\u062f", "\u0641\u0639\u0627\u0644", "\u06cc\u06a9\u0628\u0627\u0631", "\u06cc\u06a9 \u0628\u0627\u0631"};

    /** Returns {code, hostHint} or null when the text does not look like a verification message. */
    static String[] parse(String raw) {
        if (raw == null || raw.isEmpty()) return null;
        final String s = digits(raw);
        Matcher m = WEB_OTP.matcher(s);
        if (m.find()) return new String[]{m.group(2), m.group(1).toLowerCase(Locale.ROOT)};
        m = KEYED.matcher(s);
        if (m.find()) return new String[]{m.group(1), ""};
        final String low = s.toLowerCase(Locale.ROOT);
        boolean word = false;
        for (String w : WORDS) if (low.contains(w)) { word = true; break; }
        if (!word) return null; // balances, delivery codes, chats...: not a login code
        m = ANY.matcher(s);
        return m.find() ? new String[]{m.group(1), ""} : null;
    }

    /** Persian (U+06F0..) and Arabic-Indic (U+0660..) digits to ASCII. */
    private static String digits(String s) {
        final StringBuilder b = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            final char c = s.charAt(i);
            if (c >= '\u06f0' && c <= '\u06f9') b.append((char) ('0' + (c - '\u06f0')));
            else if (c >= '\u0660' && c <= '\u0669') b.append((char) ('0' + (c - '\u0660')));
            else b.append(c);
        }
        return b.toString();
    }
}
