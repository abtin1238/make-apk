// Runs in the PAGE's own JS world at document_start. Only when the session really sends a Chrome user agent (per-site, see Engine.chromeFor),
// the identity fields that are derived from the UA string (navigator.vendor, navigator.userAgentData brands / mobile / platform) agree with it.
// Nothing else is faked: no window.chrome object and no other Chrome-only API (Gecko does not implement them).
(function () {
  'use strict';
  try {
    var ua = navigator.userAgent || '';
    if (!/ Chrome\/(\d+)/.test(ua) || /Firefox\//.test(ua)) return;
    var ver = RegExp.$1, mobile = /Mobile/.test(ua), plat = /Android/.test(ua) ? 'Android' : 'Linux';
    var def = function (o, k, g) { try { Object.defineProperty(o, k, { get: g, configurable: true, enumerable: true }); } catch (e) {} };
    def(Navigator.prototype, 'vendor', function () { return 'Google Inc.'; });
    if (!navigator.userAgentData) {
      var brands = [{ brand: 'Chromium', version: ver }, { brand: 'Google Chrome', version: ver }, { brand: 'Not_A Brand', version: '24' }];
      var uad = {
        brands: brands, mobile: mobile, platform: plat,
        getHighEntropyValues: function (h) {
          var r = { brands: brands, mobile: mobile, platform: plat, platformVersion: '10.0.0', architecture: mobile ? '' : 'x86', model: '', uaFullVersion: ver + '.0.0.0', fullVersionList: brands };
          return Promise.resolve(r);
        },
        toJSON: function () { return { brands: brands, mobile: mobile, platform: plat }; }
      };
      def(Navigator.prototype, 'userAgentData', function () { return uad; });
    }
  } catch (e) {}
})();
