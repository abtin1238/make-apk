// Runs in the PAGE's own JS world (manifest "world":"MAIN") at document_start.
// Feeds the inspector's Console tab: records console.* calls, uncaught errors, failed resource loads and promise rejections
// into window.__abtinCon (array of JSON strings, newest last, max 400) and runs code typed in the Console tab.
(function () {
  'use strict';
  try {
    if (window.__abtinCon) return;
    var buf = window.__abtinCon = [];

    function fmt(v, d) {
      d = d || 0;
      try {
        if (v === null) return 'null';
        if (v === undefined) return 'undefined';
        var t = typeof v;
        if (t === 'string') return d ? JSON.stringify(v.length > 120 ? v.slice(0, 120) + '…' : v) : v;
        if (t === 'number' || t === 'boolean' || t === 'bigint') return String(v);
        if (t === 'symbol') return v.toString();
        if (t === 'function') return 'ƒ ' + (v.name || '');
        if (v instanceof Error) return (v.stack ? String(v.stack).split('\n').slice(0, 4).join('\n') : v.name + ': ' + v.message);
        if (v.nodeType === 1) return '<' + v.tagName.toLowerCase() + (v.id ? '#' + v.id : '') + (typeof v.className === 'string' && v.className.trim() ? '.' + v.className.trim().split(/\s+/).slice(0, 2).join('.') : '') + '>';
        if (v.nodeType) return '[Node ' + v.nodeName + ']';
        if (d > 2) return Array.isArray(v) ? '[…]' : '{…}';
        if (Array.isArray(v)) return '[' + v.slice(0, 12).map(function (x) { return fmt(x, d + 1); }).join(', ') + (v.length > 12 ? ', …' + (v.length - 12) : '') + ']';
        var ks = Object.keys(v), out = [];
        for (var i = 0; i < ks.length && i < 12; i++) out.push(ks[i] + ': ' + fmt(v[ks[i]], d + 1));
        var nm = v.constructor && v.constructor.name && v.constructor.name !== 'Object' ? v.constructor.name + ' ' : '';
        return nm + '{' + out.join(', ') + (ks.length > 12 ? ', …' : '') + '}';
      } catch (e) { return '[unprintable]'; }
    }

    function push(l, args) {
      var m = '';
      try { m = args.map(function (a) { return fmt(a, 0); }).join(' '); } catch (e) {}
      if (m.length > 2000) m = m.slice(0, 2000) + '…';
      var s = JSON.stringify({ l: l, t: Date.now(), m: m });
      buf.push(s);
      if (buf.length > 400) buf.shift();
      try { document.dispatchEvent(new CustomEvent('abtin-con', { detail: s })); } catch (e) {}
    }

    ['log', 'info', 'warn', 'error', 'debug'].forEach(function (k) {
      var o = console[k];
      if (typeof o !== 'function') return;
      console[k] = function () {
        try { push(k, Array.prototype.slice.call(arguments)); } catch (e) {}
        return o.apply(this, arguments);
      };
    });

    window.addEventListener('error', function (e) {
      try {
        var tg = e.target;
        if (tg && tg !== window && tg.nodeType === 1) { push('error', ['Failed to load <' + tg.tagName.toLowerCase() + '> ' + (tg.currentSrc || tg.src || tg.href || '')]); return; }
        push('error', [(e.message || 'Error') + (e.filename ? '  (' + String(e.filename).split('/').pop() + ':' + e.lineno + ':' + e.colno + ')' : '')]);
      } catch (x) {}
    }, true);
    window.addEventListener('unhandledrejection', function (e) {
      try { push('error', ['Uncaught (in promise)', e.reason]); } catch (x) {}
    });

    document.addEventListener('abtin-cmd', function (e) {
      var c;
      try { c = JSON.parse(e.detail); } catch (x) { return; }
      if (!c) return;
      if (c.c === 'clear') { buf.length = 0; return; }
      if (c.c === 'eval' && typeof c.code === 'string') {
        push('in', [c.code]);
        try {
          var r = (0, eval)(c.code);
          if (r && typeof r.then === 'function') {
            push('res', ['Promise {…}']);
            r.then(function (v) { push('res', ['→', v]); }, function (er) { push('error', ['Promise rejected:', er]); });
          } else push('res', [r]);
        } catch (er) { push('error', [er && er.message ? er.name + ': ' + er.message : String(er)]); }
      }
    });
  } catch (e) {}
})();
