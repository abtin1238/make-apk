// Dart side lives in the app (lib/engine/gecko.dart); this package only ships the Android implementation.
library abtin_gecko;
