# آبتین v3 — مرورگر فلاتر با موتور GeckoView (Firefox)

مرورگر فارسی مبتنی بر Flutter و GeckoView. کد اصلی برنامه در `lib/`، افزونهٔ Android در `packages/abtin_gecko/` و نسخهٔ محلی `file_picker` در `packages/file_picker/` قرار دارد.

## ساخت APK امضاشده

نیازمندی‌های پیشنهادی: Flutter 3.47 یا جدیدتر، JDK 21، Android SDK Platform 37، Android Gradle Plugin 9.1.0 و Gradle 9.3.1.

```bash
flutter pub get
flutter build apk --release --target-platform android-arm64 --split-debug-info=build/symbols
```

این پیکربندی برای ARM64 است. خروجی در `build/app/outputs/flutter-apk/app-release.apk` قرار می‌گیرد. برای نصب روی دستگاه‌های معمولی 64 بیتی Android (arm64-v8a) مناسب است؛ برای ABIهای دیگر باید فیلترها و build جداگانه تنظیم شوند.

امضا از `android/key.properties` و کلید `android/keystore/abtin-release.jks` خوانده می‌شود. کلید پروژه با alias `abtin` ساخته شده است. مسیر keystore در فایل properties نسبت به پوشهٔ `android/` است.

## حفاظت از کلید

این بسته شامل کلید خصوصی keystore و رمز آن است تا بتوانید همین پروژه را مستقیماً با همان کلید build کنید. آن‌ها را محرمانه نگه دارید و در مخزن عمومی یا برای دیگران منتشر نکنید. یک نسخهٔ پشتیبان امن و رمزگذاری‌شده نگه دارید؛ برای انتشار نسخه‌های بعدی همین اپ، باید کلید امضای یکسان استفاده شود. اگر این کلید برای انتشار عمومی نیست، پیش از انتشار عمومی یک keystore اختصاصی جدید بسازید و مقادیر `android/key.properties` را به‌روزرسانی کنید.

## ساختار

- `lib/` — رابط و منطق Flutter (فارسی/RTL)
- `packages/abtin_gecko/` — افزونهٔ داخلی GeckoView
- `packages/file_picker/` — نسخهٔ محلی افزونه با `compileSdk 37`
- `android/` — تنظیمات Gradle، امضا و پروژهٔ Android


## طراحی گلس‌مورفیسم و تم‌ها
- فایل‌های جدید: `lib/palettes.dart` (۹ تم: اقیانوس، شفق، غروب، جنگل، نئون، نیمه‌شب، یخ، شکوفه، نعنا + حالت خودکار) و `lib/ui/glass.dart` (ویجت‌های شیشه‌ای).
- انتخاب تم: تنظیمات ← ظاهر. همان‌جا شدت بلور و پس‌زمینهٔ متحرک هم قابل تنظیم است.
- منوی سه‌نقطه کاملاً رنگی و شیشه‌ای بازنویسی شده (`lib/ui/browser_menu.dart`).
- برای افزودن تم جدید فقط یک مورد به `palettes` اضافه کنید.


## v2ray (نسخهٔ ۳٫۱)
تنظیمات > «v2ray / VPN»: هستهٔ PattNG (Xray) داخل برنامه است. با زدن «اتصال»، کل گوشی (همهٔ برنامه‌ها) از VPN رد می‌شود و مرورگر آبتین هم از همان هسته استفاده می‌کند.
- افزودن: چسباندن لینک (vless / vmess / trojan / ss / hysteria2 / socks)، اسکن QR، اشتراک (Subscription) یا JSON کامل Xray.
- پشتیبانی از پارامترهای ویژهٔ PattNG: cipherSuites (cs)، فینگرپرینت unsafe، finalMask (fm)، dialMode، ech، vcn / pcs و Reality.
- دور زدن سایت‌ها و آی‌پی‌های ایران، مسدودکردن QUIC و تبلیغات از همان صفحه قابل تنظیم است.
- هنوز نیست: Aether، Psiphon، WireGuard، زنجیرهٔ پروکسی، پروکسی به‌ازای هر برنامه.


## ساخت همهٔ معماری‌ها (v21)
- معماری‌ها: `arm64-v8a`، `armeabi-v7a` (armv7)، `x86_64`. برای هر کدام یک APK جدا ساخته می‌شود و هر APK جداگانه بسته می‌شود (۷z چندتکه‌ای یا zip).
- GitHub Actions: `.github/workflows/build-apk.yml` (دستی با workflow_dispatch یا با تگ `v*`) — سه job موازی، هر کدام یک artifact: `AbtinBrowser-<نسخه>-<abi>.zip`. با تگ، زیپ‌ها به Release هم اضافه می‌شوند.
- محلی: `tools/build_all.sh` (خروجی در `dist/`).
- موتور GeckoView (`geckoview-omni`) هر چهار ABI را دارد؛ `--split-per-abi` فقط ABI همان APK را نگه می‌دارد و workflow بررسی می‌کند که `libxul.so` همان ABI داخل APK باشد.
- هستهٔ v2ray (`libgojni.so`) داخل پروژه فقط arm64-v8a است. PattNG همین هسته را برای همهٔ ABIها داخل `libv2ray.aar` (ریلیز `patterniha/AndroidLibXrayLite`) می‌دهد؛ workflow برای armv7 / x86_64 آن را دانلود می‌کند و فقط وقتی استفاده می‌کند که خروجی‌های JNI آن با هستهٔ arm64 داخل پروژه یکی باشد (`tools/jni_syms.py`)، وگرنه هشدار می‌دهد و آن ABI بدون v2ray ساخته می‌شود (`unsupported_abi`). اگر یکی نبود، ورودی `xray_tag` را روی تگ هم‌نسخهٔ PattNG 2.3.13 بگذارید. ساخت محلی: `libgojni.so` هر ABI را دستی در `android/app/src/main/jniLibs/<abi>/` بگذارید.
- زیپ کردن APK حجم را تقریباً کم نمی‌کند (APK از قبل فشرده است)؛ فقط بسته‌بندی جدا می‌دهد.
- محدودیت حجم پیام‌رسان: خروجی هر معماری پیش‌فرض در تکه‌های ۴۰ مگ ساخته می‌شود: `AbtinBrowser-<نسخه>-<abi>.7z.001`, `.7z.002`, … (همه را در یک پوشه بگذارید و `.001` را با ZArchiver یا 7-Zip باز کنید). `part_mb=0` یعنی یک `.zip` کامل. universal APK حدود ۱۵۰ مگ است چون هر چهار معماری GeckoView را دارد؛ APKهای جدا کوچک‌ترند.

## نسخهٔ ۵۱: کم‌رم، هویت Chrome، وب‌اپ‌ها
- **حالت کم‌رم:** حداکثر تعداد تب زنده از RAM واقعی گوشی تعیین می‌شود (۲ گیگ: ۳ تب، ۳ گیگ: ۴، ۴ گیگ: ۶). هنگام کمبود حافظه یا بیش‌بودن تب‌ها، قدیمی‌ترین تب‌های پس‌زمینه آزاد می‌شوند و با تاریخچه‌شان برمی‌گردند. تب فعال و تب خصوصی هرگز آزاد نمی‌شود. تنظیمات ← تب‌های خوابیده.
- **هویت Chrome:** خودکار و برای هر سایت جدا (فهرست داخلی، تشخیص صفحهٔ «فقط Chrome»، منوی «هویت Chrome برای این سایت»، فهرست قابل ویرایش در تنظیمات). شیء `window.chrome` جعل نمی‌شود.
- **وب‌اپ‌ها:** تنظیمات ← وب‌اپ‌های نصب‌شده (باز کردن، تغییر نام، حذف). هنگام نصب مشخص می‌شود PWA واقعی (Manifest + Service Worker) است یا فقط میان‌بر وب. نصب تکراری یک سایت انجام نمی‌شود.
- توجه: این نسخه با Flutter / Android SDK ساخته و آزمایش نشده است؛ ابتدا `flutter analyze` و بیلد را اجرا کنید.

