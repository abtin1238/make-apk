# Abtin Browser 3.2.12

- رفع خطای بیلد در همهٔ معماری‌ها: `Undefined name 'dnsPresets'` در browser_chrome.dart (ایمپورت dns_manager.dart در browser_page.dart اضافه شد).
- بدون تغییر در PWA، DNS، VPN و کلید امضا.
