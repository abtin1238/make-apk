import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';

/// Native -> Dart request (prompt, permission, ...). Return value is sent back to Gecko.
typedef AskHandler = Future<dynamic> Function(String method, Map<String, dynamic> args);

/// Thin wrapper around the `abtin_gecko` Android plugin (GeckoView / Firefox engine).
class Gecko {
  static const MethodChannel _m = MethodChannel('abtin/gecko');
  static const EventChannel _e = EventChannel('abtin/gecko/events');

  final StreamController<Map<String, dynamic>> _events = StreamController<Map<String, dynamic>>.broadcast();
  StreamSubscription<dynamic>? _sub;
  AskHandler? onAsk;
  String defaultUA = '';
  bool ready = false;
  String? error;

  Stream<Map<String, dynamic>> get events => _events.stream;

  Future<void> init(Map<String, dynamic> settings) async {
    _m.setMethodCallHandler(_incoming);
    _sub ??= _e.receiveBroadcastStream().listen((dynamic d) {
      if (d is Map) _events.add(Map<String, dynamic>.from(d));
    }, onError: (Object _) {});
    try {
      defaultUA = (await _m.invokeMethod<String>('init', settings).timeout(const Duration(seconds: 30))) ?? '';
      ready = true;
      error = null;
    } catch (e) {
      error = '$e';
      debugPrint('gecko init failed: $e');
    }
  }

  Future<dynamic> _incoming(MethodCall c) async {
    final h = onAsk;
    if (h == null) return null;
    final a = c.arguments is Map ? Map<String, dynamic>.from(c.arguments as Map) : <String, dynamic>{};
    try {
      return await h(c.method, a);
    } catch (e) {
      debugPrint('gecko ask ${c.method}: $e');
      return null;
    }
  }

  Future<T?> call<T>(String method, [Map<String, dynamic>? args]) async {
    try {
      return await _m.invokeMethod<T>(method, args);
    } catch (e) {
      debugPrint('gecko $method: $e');
      return null;
    }
  }

  Future<List<Map<String, dynamic>>> extList() async {
    final r = await call<List<dynamic>>('extList');
    if (r == null) return [];
    return r.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }
}

/// The single GeckoView; the native side swaps the selected tab's session into it.
class GeckoViewWidget extends StatelessWidget {
  const GeckoViewWidget({super.key});
  static const String viewType = 'abtin/geckoview';

  @override
  Widget build(BuildContext context) {
    return PlatformViewLink(
      viewType: viewType,
      surfaceFactory: (BuildContext context, PlatformViewController controller) {
        return AndroidViewSurface(
          controller: controller as AndroidViewController,
          gestureRecognizers: <Factory<OneSequenceGestureRecognizer>>{
            Factory<OneSequenceGestureRecognizer>(() => EagerGestureRecognizer()),
          },
          hitTestBehavior: PlatformViewHitTestBehavior.opaque,
        );
      },
      onCreatePlatformView: (PlatformViewCreationParams params) {
        return PlatformViewsService.initExpensiveAndroidView(
          id: params.id,
          viewType: viewType,
          layoutDirection: TextDirection.ltr,
          creationParams: null,
          creationParamsCodec: const StandardMessageCodec(),
          onFocus: () => params.onFocusChanged(true),
        )
          ..addOnPlatformViewCreatedListener(params.onPlatformViewCreated)
          ..create();
      },
    );
  }
}
