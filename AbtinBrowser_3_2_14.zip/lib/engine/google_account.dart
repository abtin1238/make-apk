import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import '../app_state.dart';

/// One-tap Google sign-in through Android's Credential Manager (native side: MainActivity.kt).
/// Google shows the list of accounts on the phone and its own confirmation UI; the user just taps one.
/// Only the public profile (email / name / photo) is persisted. The ID token lives in memory only.
class GoogleAccount extends ChangeNotifier {
  static const MethodChannel _m = MethodChannel('abtin/google');

  String email = '', name = '', photo = '';
  /// Latest Google ID token (JWT). Memory only: never written to disk.
  String? idToken;
  bool busy = false;
  bool get signedIn => email.isNotEmpty;

  void load(AppState app) {
    try {
      final j = jsonDecode(app.prefs.getString('google_profile_v1') ?? '{}') as Map;
      email = (j['email'] as String?) ?? '';
      name = (j['name'] as String?) ?? '';
      photo = (j['photo'] as String?) ?? '';
    } catch (_) {}
  }

  /// Returns null on success, otherwise an error code:
  /// no_client_id | cancelled | no_account | failed | unavailable
  Future<String?> signIn(AppState app, String clientId) async {
    if (busy) return null;
    busy = true;
    notifyListeners();
    try {
      final r = await _m.invokeMapMethod<String, dynamic>('signIn', {'clientId': clientId});
      if (r == null) return 'failed';
      idToken = r['idToken'] as String?;
      email = (r['email'] as String?) ?? '';
      name = (r['name'] as String?) ?? '';
      photo = (r['photo'] as String?) ?? '';
      await app.prefs.setString('google_profile_v1', jsonEncode({'email': email, 'name': name, 'photo': photo}));
      return null;
    } on PlatformException catch (e) {
      return e.code;
    } on MissingPluginException {
      return 'unavailable';
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<void> signOut(AppState app) async {
    try { await _m.invokeMethod<bool>('signOut'); } catch (_) {}
    idToken = null; email = ''; name = ''; photo = '';
    await app.prefs.remove('google_profile_v1');
    notifyListeners();
  }
}
