import 'dart:convert';
import 'dart:typed_data';

/// One subtitle line (SRT / WebVTT). Times are in milliseconds.
class SubCue {
  SubCue(this.start, this.end, this.text);
  final int start, end;
  final String text;
}

// Windows-1256 (Arabic / Persian) bytes 0x80..0xFF -> Unicode. Old Persian .srt files are very often in this encoding.
const _cp1256 = <int>[0x20AC, 0x067E, 0x201A, 0x0192, 0x201E, 0x2026, 0x2020, 0x2021, 0x02C6, 0x2030, 0x0679, 0x2039, 0x0152, 0x0686, 0x0698, 0x0688, 0x06AF, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014, 0x06A9, 0x2122, 0x0691, 0x203A, 0x0153, 0x200C, 0x200D, 0x06BA, 0x00A0, 0x060C, 0x00A2, 0x00A3, 0x00A4, 0x00A5, 0x00A6, 0x00A7, 0x00A8, 0x00A9, 0x06BE, 0x00AB, 0x00AC, 0x00AD, 0x00AE, 0x00AF, 0x00B0, 0x00B1, 0x00B2, 0x00B3, 0x00B4, 0x00B5, 0x00B6, 0x00B7, 0x00B8, 0x00B9, 0x061B, 0x00BB, 0x00BC, 0x00BD, 0x00BE, 0x061F, 0x06C1, 0x0621, 0x0622, 0x0623, 0x0624, 0x0625, 0x0626, 0x0627, 0x0628, 0x0629, 0x062A, 0x062B, 0x062C, 0x062D, 0x062E, 0x062F, 0x0630, 0x0631, 0x0632, 0x0633, 0x0634, 0x0635, 0x0636, 0x00D7, 0x0637, 0x0638, 0x0639, 0x063A, 0x0640, 0x0641, 0x0642, 0x0643, 0x00E0, 0x0644, 0x00E2, 0x0645, 0x0646, 0x0647, 0x0648, 0x00E7, 0x00E8, 0x00E9, 0x00EA, 0x00EB, 0x0649, 0x064A, 0x00EE, 0x00EF, 0x064B, 0x064C, 0x064D, 0x064E, 0x00F4, 0x064F, 0x0650, 0x00F7, 0x0651, 0x00F9, 0x0652, 0x00FB, 0x00FC, 0x200E, 0x200F, 0x06D2];

/// UTF-8 (with or without BOM) and UTF-16 are detected first; anything that is not valid UTF-8 is read as Windows-1256.
String decodeSubtitleBytes(List<int> raw) {
  final b = raw is Uint8List ? raw : Uint8List.fromList(raw);
  if (b.length >= 2 && b[0] == 0xFF && b[1] == 0xFE) return _utf16(b, 2, true);
  if (b.length >= 2 && b[0] == 0xFE && b[1] == 0xFF) return _utf16(b, 2, false);
  var start = 0;
  if (b.length >= 3 && b[0] == 0xEF && b[1] == 0xBB && b[2] == 0xBF) start = 3;
  try {
    return utf8.decode(b.sublist(start), allowMalformed: false);
  } catch (_) {
    final sb = StringBuffer();
    for (var i = start; i < b.length; i++) {
      final c = b[i];
      sb.writeCharCode(c < 0x80 ? c : _cp1256[c - 0x80]);
    }
    return sb.toString();
  }
}

String _utf16(Uint8List b, int from, bool le) {
  final u = <int>[];
  for (var i = from; i + 1 < b.length; i += 2) {
    u.add(le ? (b[i] | (b[i + 1] << 8)) : ((b[i] << 8) | b[i + 1]));
  }
  return String.fromCharCodes(u);
}

final _timeRe = RegExp(r'((?:\d+:)?\d{1,2}:\d{2}[,.]\d{1,3})\s*-->\s*((?:\d+:)?\d{1,2}:\d{2}[,.]\d{1,3})');

int _ms(String s) {
  final p = s.replaceAll(',', '.').split(':');
  final sec = double.parse(p.last);
  final m = int.parse(p[p.length - 2]);
  final h = p.length > 2 ? int.parse(p[0]) : 0;
  return ((h * 3600 + m * 60 + sec) * 1000).round();
}

String _clean(String t) => t
    .replaceAll(RegExp(r'<[^>]*>'), '')
    .replaceAll(RegExp(r'\{\\[^}]*\}'), '')
    .replaceAll('&nbsp;', ' ').replaceAll('&lt;', '<').replaceAll('&gt;', '>').replaceAll('&amp;', '&')
    .trim();

/// Parses SRT or WebVTT text (both use "start --> end" lines) into cues sorted by start time.
List<SubCue> parseSubtitles(String text) {
  final lines = text.replaceAll('\r\n', '\n').replaceAll('\r', '\n').replaceAll('\uFEFF', '').split('\n');
  final out = <SubCue>[];
  var i = 0;
  while (i < lines.length) {
    final m = _timeRe.firstMatch(lines[i]);
    if (m == null) { i++; continue; }
    int s, e;
    try { s = _ms(m.group(1)!); e = _ms(m.group(2)!); } catch (_) { i++; continue; }
    i++;
    final buf = <String>[];
    while (i < lines.length && lines[i].trim().isNotEmpty && !_timeRe.hasMatch(lines[i])) { buf.add(lines[i]); i++; }
    final t = _clean(buf.join('\n'));
    if (t.isNotEmpty) out.add(SubCue(s, e, t));
  }
  out.sort((a, b) => a.start.compareTo(b.start));
  return out;
}

/// Cue showing at [ms] (binary search, so it is cheap to call on every frame).
SubCue? cueAt(List<SubCue> cues, int ms) {
  var lo = 0, hi = cues.length - 1, best = -1;
  while (lo <= hi) {
    final mid = (lo + hi) >> 1;
    if (cues[mid].start <= ms) { best = mid; lo = mid + 1; } else { hi = mid - 1; }
  }
  for (var k = best; k >= 0 && k > best - 4; k--) {
    if (ms >= cues[k].start && ms <= cues[k].end) return cues[k];
  }
  return null;
}

final _rtlRe = RegExp(r'[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]');
bool hasRtl(String s) => _rtlRe.hasMatch(s);
