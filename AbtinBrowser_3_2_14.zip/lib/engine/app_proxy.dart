import 'dart:io';

import 'package:dio/dio.dart';
import 'package:dio/io.dart';

import 'v2ray/v2ray_config.dart';

/// While the v2ray tunnel is up, every request the app itself makes (extensions, media downloads, favicons...)
/// goes through the core's local HTTP inbound, like the pages of the browser engine and the system-wide VPN.
class AppProxy {
  static bool on = false;

  static String _find(Uri u) {
    if (!on) return 'DIRECT';
    final h = u.host;
    if (h == 'localhost' || h == '127.0.0.1' || h == '::1') return 'DIRECT';
    return 'PROXY 127.0.0.1:${V2Config.httpPort}';
  }

  static Dio dio([BaseOptions? options]) {
    final d = Dio(options);
    d.httpClientAdapter = IOHttpClientAdapter(createHttpClient: () => HttpClient()..findProxy = _find);
    return d;
  }
}
