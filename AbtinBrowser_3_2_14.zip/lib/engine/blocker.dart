/// Domain lists + cosmetic CSS. Matching runs inside the built-in Gecko extension (core@abtin.ir);
/// Gecko's own Enhanced Tracking Protection runs in addition.
class Blocker {
  static const ads = [
    'doubleclick.net', 'googlesyndication.com', 'googleadservices.com', 'adservice.google.com', 'adnxs.com', 'adsrvr.org',
    'taboola.com', 'outbrain.com', 'criteo.com', 'criteo.net', 'pubmatic.com', 'rubiconproject.com', 'openx.net',
    'casalemedia.com', 'advertising.com', 'moatads.com', 'amazon-adsystem.com', 'smartadserver.com', 'yieldmo.com',
    'teads.tv', 'adform.net', 'media.net', '33across.com', 'bidswitch.net', 'sharethrough.com', '3lift.com',
    'indexww.com', 'lijit.com', 'mgid.com', 'revcontent.com', 'popads.net', 'propellerads.com', 'exoclick.com',
    'adsterra.com', 'juicyads.com', 'tapad.com', 'yandexadexchange.net', 'adcolony.com', 'applovin.com', 'unityads.unity3d.com',
  ];
  static const trackers = [
    'google-analytics.com', 'scorecardresearch.com', 'quantserve.com', 'hotjar.com', 'mixpanel.com', 'segment.io',
    'segment.com', 'fullstory.com', 'mouseflow.com', 'crazyegg.com', 'omtrdc.net', 'demdex.net', 'krxd.net',
    'bluekai.com', 'chartbeat.com', 'parsely.com', 'analytics.twitter.com', 'ads-twitter.com', 'px.ads.linkedin.com',
    'analytics.tiktok.com', 'clarity.ms', 'mc.yandex.ru', 'adjust.com', 'branch.io', 'amplitude.com', 'heap.io',
  ];
  // Host-only entries (path rules such as facebook.com/tr cannot be expressed as a host list).
  static const strict = [
    'googletagmanager.com', 'connect.facebook.net', 'platform.twitter.com', 'snap.licdn.com',
    'static.ads-twitter.com', 'bat.bing.com', 'sentry.io', 'newrelic.com', 'nr-data.net',
    'datadoghq.com', 'optimizely.com', 'hs-analytics.net', 'intercom.io',
  ];

  static const cosmeticCss =
      '.adsbygoogle,ins.adsbygoogle,[id^="google_ads"],[id^="div-gpt-ad"],[class*="ad-banner"],[class*="adbox"],[id*="ad-slot"],'
      '.ad-container,.sponsored-ad,iframe[src*="doubleclick"],iframe[src*="googlesyndication"],.taboola,.OUTBRAIN{display:none!important}';

  /// Config pushed to the native engine (`apply.core`).
  static Map<String, dynamic> config({required bool adblock, required String level}) => {
        'adblock': adblock,
        'level': level,
        'ads': ads,
        'trackers': trackers,
        'strict': strict,
        'cosmetic': cosmeticCss,
        'extra': <String>[],
      };
}
