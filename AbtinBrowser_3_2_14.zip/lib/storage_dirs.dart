import 'dart:io';
import 'dart:typed_data';
import 'services.dart';

Future<Directory> _resolve(String key) async {
  final p = app.str(key);
  if (p.isNotEmpty) {
    try {
      final d = Directory(p);
      if (!await d.exists()) await d.create(recursive: true);
      return d;
    } catch (_) {}
  }
  return dlMgr.dir();
}

Future<Directory> screenshotDir() => _resolve('screenshotDir');

/// Writes to the chosen folder; falls back to the default downloads folder if it isn't writable.
Future<File?> saveScreenshot(Uint8List b) async {
  final name = 'abtin_${DateTime.now().millisecondsSinceEpoch}.png';
  for (final d in [await screenshotDir(), await dlMgr.dir()]) {
    try {
      final f = File('${d.path}/$name');
      await f.writeAsBytes(b, flush: true);
      return f;
    } catch (_) {}
  }
  return null;
}
