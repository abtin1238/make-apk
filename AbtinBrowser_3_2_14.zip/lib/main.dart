import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'services.dart';
import 'ui/browser_page.dart';
import 'ui/splash.dart';

void main() {
  runZonedGuarded(() {
    WidgetsFlutterBinding.ensureInitialized();
    FlutterError.onError = (d) => debugPrint('FlutterError: ${d.exceptionAsString()}');
    runApp(const BootApp());
  }, (e, s) => debugPrint('uncaught: $e\n$s'));
}

/// Paints immediately, then initialises storage + engine so a slow/failed engine can never leave a black screen.
class BootApp extends StatefulWidget {
  const BootApp({super.key});
  @override
  State<BootApp> createState() => _BootAppState();
}

class _BootAppState extends State<BootApp> with WidgetsBindingObserver {
  bool _ready = false, _busy = true, _appInit = false;
  String? _err;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _boot();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didHaveMemoryPressure() {
    PaintingBinding.instance.imageCache..clear()..clearLiveImages();
  }

  Future<void> _boot() async {
    setState(() { _busy = true; _err = null; });
    try {
      if (!_appInit) { await app.init(); googleAccount.load(app); _appInit = true; v2ray.onProxyChanged = () { if (gecko.ready) gecko.call('apply', app.geckoSettings()); }; unawaited(v2ray.init()); unawaited(dnsMgr.init()); }
      final dir = await dlMgr.dir().timeout(const Duration(seconds: 10));
      await gecko.init({
        ...app.geckoSettings(),
        'downloadDir': dir.path,
        'visited': app.history.take(2000).map((h) => h.url).toList(),
      });
      unawaited(extMgr.load()); // not needed to show the first screen
      if (gecko.ready) {
        final memory = await gecko.call<Map<Object?, Object?>>('memInfo');
        final totalMb = (memory?['totalMb'] as num?)?.toInt() ?? 4096;
        app.configureDeviceProfile(totalMb);
        _ready = true;
      } else {
        _err = 'Gecko: ${gecko.error ?? 'unknown'}';
      }
    } catch (e, s) {
      debugPrint('boot failed: $e\n$s');
      _err = '$e';
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    if (_ready) return const AbtinApp();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(brightness: Brightness.dark, useMaterial3: true, scaffoldBackgroundColor: const Color(0xFF071326)),
      home: Scaffold(
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const AbtinLogo(size: 120),
              const SizedBox(height: 20),
              const Text('آبتین', style: TextStyle(fontSize: 38, fontWeight: FontWeight.bold)),
              const SizedBox(height: 28),
              if (_busy) const SizedBox(width: 28, height: 28, child: CircularProgressIndicator(strokeWidth: 3)),
              if (!_busy && _err != null) ...[
                Text(_err!, textAlign: TextAlign.center, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 12, color: Colors.white70)),
                const SizedBox(height: 16),
                Row(mainAxisSize: MainAxisSize.min, children: [
                  FilledButton(onPressed: _boot, child: const Text('تلاش دوباره')),
                  const SizedBox(width: 12),
                  if (_appInit) OutlinedButton(onPressed: () => setState(() => _ready = true), child: const Text('ادامه')),
                ]),
              ],
            ]),
          ),
        ),
      ),
    );
  }
}

class AbtinApp extends StatelessWidget {
  const AbtinApp({super.key});
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: app,
        builder: (_, __) => MaterialApp(
          title: 'Abtin Browser',
          debugShowCheckedModeBanner: false,
          theme: app.themeData(),
          builder: (c, child) => AnnotatedRegion<SystemUiOverlayStyle>(
            value: SystemUiOverlayStyle(
              statusBarColor: Colors.transparent, systemNavigationBarColor: Colors.transparent, systemNavigationBarContrastEnforced: false,
              statusBarIconBrightness: app.dark ? Brightness.light : Brightness.dark, systemNavigationBarIconBrightness: app.dark ? Brightness.light : Brightness.dark,
            ),
            child: MediaQuery(
              data: MediaQuery.of(c).copyWith(disableAnimations: MediaQuery.of(c).disableAnimations || !app.flag('uiAnim')),
              child: Directionality(textDirection: app.lang == 'fa' ? TextDirection.rtl : TextDirection.ltr, child: child!),
            ),
          ),
          home: app.flag('onboarded') ? const BrowserPage() : const SplashPage(),
        ),
      );
}
