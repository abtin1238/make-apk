import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../app_state.dart';
import '../services.dart';
import 'glass.dart';

/// Installed web apps (home-screen shortcuts made from the browser menu): open, rename, copy link, remove.
/// "PWA" = the site has a web manifest and a service worker; "Web shortcut" = anything else, shown in its own window.
class WebAppsPage extends StatefulWidget {
  const WebAppsPage({super.key});
  @override
  State<WebAppsPage> createState() => _WebAppsPageState();
}

class _WebAppsPageState extends State<WebAppsPage> {
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await gecko.call<List<dynamic>>('webappsList');
    final l = (r ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    l.sort((a, b) => '${a['title']}'.toLowerCase().compareTo('${b['title']}'.toLowerCase()));
    if (!mounted) return;
    setState(() { _items = l; _loading = false; });
  }

  Future<void> _rename(Map<String, dynamic> it) async {
    final c = TextEditingController(text: '${it['title']}');
    final ok = await showGlassDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('نام برنامه', 'App name'), style: const TextStyle(fontSize: 16)),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))),
          TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('ذخیره', 'Save'))),
        ],
      ),
    );
    if (ok != true || c.text.trim().isEmpty) return;
    await gecko.call<bool>('webappEdit', {'id': it['id'], 'title': c.text.trim()});
    await _load();
  }

  Future<void> _remove(Map<String, dynamic> it) async {
    final ok = await showGlassDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('حذف وب‌اپ؟', 'Remove web app?'), style: const TextStyle(fontSize: 16)),
        content: Text(tr('«${it['title']}» از فهرست حذف می‌شود. اندروید اجازه نمی‌دهد برنامه آیکن را از صفحهٔ اصلی پاک کند؛ آیکن خاکستری می‌شود و باید آن را خودتان حذف کنید.', '"${it['title']}" is removed from this list. Android does not let an app delete its icon from the home screen: the icon turns grey and you remove it yourself.')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))),
          TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('حذف', 'Remove'))),
        ],
      ),
    );
    if (ok != true) return;
    await gecko.call<bool>('webappRemove', {'id': it['id']});
    await _load();
  }

  Widget _tile(Map<String, dynamic> it) {
    final pwaKind = it['kind'] == 'pwa';
    final real = it['real'] == true;
    final label = !pwaKind ? tr('میان‌بر ساده (در مرورگر)', 'Plain shortcut (in browser)') : real ? tr('PWA واقعی', 'Real PWA') : tr('میان‌بر وب (PWA نیست)', 'Web shortcut (not a PWA)');
    final color = !pwaKind ? Colors.blueGrey : real ? const Color(0xFF84CC16) : const Color(0xFFF59E0B);
    final icon = it['icon'];
    return ListTile(
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: SizedBox(width: 40, height: 40, child: icon is Uint8List ? Image.memory(icon, fit: BoxFit.contain) : const Icon(Icons.public)),
      ),
      title: Text('${it['title']}', maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${it['host']}', maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 2),
        Text(label, style: TextStyle(fontSize: 11.5, color: color, fontWeight: FontWeight.w600)),
      ]),
      onTap: () async {
        final ok = await gecko.call<bool>('webappOpen', {'id': it['id']});
        if (ok != true && mounted) snackTop(context, tr('باز نشد', 'Could not open'));
      },
      trailing: PopupMenuButton<String>(
        onSelected: (v) async {
          if (v == 'rename') await _rename(it);
          if (v == 'copy') { await Clipboard.setData(ClipboardData(text: '${it['url']}')); if (mounted) snackTop(context, tr('کپی شد', 'Copied')); }
          if (v == 'remove') await _remove(it);
        },
        itemBuilder: (c) => [
          PopupMenuItem(value: 'rename', child: Text(tr('تغییر نام', 'Rename'))),
          PopupMenuItem(value: 'copy', child: Text(tr('کپی آدرس', 'Copy link'))),
          PopupMenuItem(value: 'remove', child: Text(tr('حذف', 'Remove'))),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(tr('وب‌اپ‌های نصب‌شده', 'Installed web apps'))),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _items.isEmpty
              ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(tr('هنوز وب‌اپی نصب نشده. در هر سایت: منو ← افزودن برنامه به صفحهٔ اصلی', 'No web apps yet. On any site: menu > Add app to home screen'), textAlign: TextAlign.center)))
              : RefreshIndicator(onRefresh: _load, child: ListView(children: [for (final it in _items) _tile(it)])),
    );
  }
}
