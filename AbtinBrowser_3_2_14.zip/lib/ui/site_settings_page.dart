import 'package:flutter/material.dart';
import '../app_state.dart';
import '../services.dart';
import 'glass.dart';

/// Site settings: the list of sites with saved permissions, and the settings of one site.
class SiteSettingsPage extends StatefulWidget {
  const SiteSettingsPage({super.key, this.host});

  /// null = list of all sites; otherwise the settings of this site.
  final String? host;

  @override
  State<SiteSettingsPage> createState() => _SiteSettingsPageState();
}

class _SiteSettingsPageState extends State<SiteSettingsPage> {
  Future<void> _addSite() async {
    final c = TextEditingController();
    final ok = await showGlassDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('افزودن سایت', 'Add a site'), style: const TextStyle(fontSize: 16)),
        content: TextField(controller: c, autofocus: true, keyboardType: TextInputType.url, textDirection: TextDirection.ltr, decoration: const InputDecoration(hintText: 'example.com')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))),
          TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('باز کردن', 'Open'))),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    var h = c.text.trim().toLowerCase();
    h = h.replaceFirst(RegExp(r'^[a-z]+://'), '').split('/').first;
    if (h.isEmpty) return;
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteSettingsPage(host: h)));
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final host = widget.host;
    return host == null ? _list() : _detail(host);
  }

  Widget _list() {
    final hosts = app.perms.keys.toList()..sort();
    return GlassScaffold(
      appBar: AppBar(title: Text(tr('تنظیمات سایت‌ها', 'Site settings')), actions: [IconButton(icon: const Icon(Icons.add), tooltip: tr('افزودن سایت', 'Add a site'), onPressed: _addSite)]),
      body: hosts.isEmpty
          ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(tr('هنوز برای هیچ سایتی تنظیمی ذخیره نشده.\nبا دکمهٔ + یک سایت اضافه کن یا از «اطلاعات سایت» در همان صفحه تنظیم کن.', 'No site has saved settings yet.\nAdd one with + or use “Site info” on the page itself.'), textAlign: TextAlign.center)))
          : ListView(children: [
              for (final h in hosts)
                ListTile(
                  leading: const Icon(Icons.language),
                  title: Text(h, textDirection: TextDirection.ltr),
                  subtitle: Text(_summary(h)),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () async {
                    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => SiteSettingsPage(host: h)));
                    if (mounted) setState(() {});
                  },
                ),
            ]),
    );
  }

  String _label(String key) => switch (key) {
        'camera' => tr('دوربین', 'Camera'),
        'microphone' => tr('میکروفون', 'Microphone'),
        'geolocation' => tr('موقعیت مکانی', 'Location'),
        'storage' => tr('دسترسی به داده‌های سایت', 'Site data access'),
        _ => key,
      };

  String _value(String v) => switch (v) {
        'allow' => tr('اجازه', 'Allow'),
        'block' => tr('مسدود', 'Block'),
        _ => tr('پرسیدن', 'Ask'),
      };

  String _summary(String h) {
    final m = (app.perms[h] as Map?) ?? const {};
    return m.entries.map((e) => '${_label('${e.key}')}: ${_value('${e.value}')}').join('  •  ');
  }

  Widget _detail(String host) {
    Widget perm(String key, IconData icon) => ListTile(
          leading: Icon(icon),
          title: Text(_label(key)),
          trailing: DropdownButton<String>(
            value: app.sitePerm(host, key),
            underline: const SizedBox(),
            items: [
              for (final v in const ['ask', 'allow', 'block']) DropdownMenuItem(value: v, child: Text(_value(v))),
            ],
            onChanged: (v) {
              if (v == null) return;
              app.setSitePerm(host, key, v);
              gecko.call('resetPermissions', {'host': host});
              setState(() {});
            },
          ),
        );
    return GlassScaffold(
      appBar: AppBar(title: Text(host, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 17))),
      body: ListView(children: [
        perm('camera', Icons.videocam_outlined),
        perm('microphone', Icons.mic_none),
        perm('geolocation', Icons.location_on_outlined),
        perm('storage', Icons.storage_outlined),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.cookie_outlined),
          title: Text(tr('پاک کردن کوکی‌های این سایت', 'Clear cookies for this site')),
          onTap: () async {
            await gecko.call('clearHost', {'host': host});
            if (mounted) snackTop(context, tr('کوکی‌های این سایت پاک شد', 'Cookies for this site cleared'));
          },
        ),
        ListTile(
          leading: const Icon(Icons.restart_alt),
          title: Text(tr('بازنشانی تنظیمات این سایت', 'Reset this site’s settings')),
          onTap: () {
            for (final k in const ['camera', 'microphone', 'geolocation', 'storage']) {
              app.setSitePerm(host, k, 'ask');
            }
            gecko.call('resetPermissions', {'host': host});
            if (mounted) Navigator.of(context).pop();
          },
        ),
      ]),
    );
  }
}
