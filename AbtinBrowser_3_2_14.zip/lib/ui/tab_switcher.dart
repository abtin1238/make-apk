part of 'browser_page.dart';
// ignore_for_file: invalid_use_of_protected_member

class _TabSwitcher extends StatefulWidget {
  const _TabSwitcher({required this.host});
  final _BrowserPageState host;
  @override
  State<_TabSwitcher> createState() => _TabSwitcherState();
}

class _TabSwitcherState extends State<_TabSwitcher> {
  bool private = false;
  _BrowserPageState get h => widget.host;

  @override
  void initState() { super.initState(); private = h.current.private; }

  Future<void> _newGroup(BrowserTab? move) async {
    final ctl = TextEditingController();
    var color = groupColors[app.groups.length % groupColors.length];
    final ok = await showGlassDialog<bool>(
      context: context,
      builder: (d) => StatefulBuilder(builder: (d, set) => AlertDialog(
        title: Text(tr('گروه جدید', 'New group')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: ctl, autofocus: true, decoration: InputDecoration(labelText: tr('نام گروه', 'Group name'))),
          const SizedBox(height: 14),
          Wrap(spacing: 8, children: [for (final c in groupColors) GestureDetector(onTap: () => set(() => color = c), child: CircleAvatar(radius: 14, backgroundColor: Color(c), child: color == c ? const Icon(Icons.check, size: 16, color: Colors.white) : null))]),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('ایجاد', 'Create')))],
      )),
    );
    if (ok != true || ctl.text.trim().isEmpty) return;
    final g = TabGroup('g${DateTime.now().microsecondsSinceEpoch}', ctl.text.trim(), color);
    app.groups.add(g);
    app.saveGroups();
    if (move != null) move.groupId = g.id;
    setState(() {});
    h.setState(() {});
  }

  void _groupMenu(BrowserTab t) {
    showGlassSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          ListTile(leading: const Icon(Icons.folder_off_outlined), title: Text(tr('بدون گروه', 'No group')), onTap: () { Navigator.pop(ctx); t.groupId = null; setState(() {}); h.setState(() {}); }),
          for (final g in app.groups) ListTile(leading: CircleAvatar(radius: 8, backgroundColor: Color(g.color)), title: Text(g.name), onTap: () { Navigator.pop(ctx); t.groupId = g.id; setState(() {}); h.setState(() {}); }),
          ListTile(leading: const Icon(Icons.create_new_folder_outlined), title: Text(tr('گروه جدید…', 'New group…')), onTap: () { Navigator.pop(ctx); _newGroup(t); }),
        ]),
      ),
    );
  }

  Widget _card(BrowserTab t) {
    final sel = t == h.current;
    final cs = Theme.of(context).colorScheme;
    return Glass(
      margin: const EdgeInsets.symmetric(vertical: 4), radius: 16,
      borderColor: sel ? cs.primary : null, borderWidth: sel ? 1.8 : 1,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () { h.selectTab(t); Navigator.pop(context); },
        onLongPress: () => _groupMenu(t),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(children: [
            if (t.thumb != null) ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.memory(t.thumb!, width: 56, height: 56, cacheWidth: 168, gaplessPlayback: true, fit: BoxFit.cover, alignment: Alignment.topCenter, errorBuilder: (_, __, ___) => h._fav(t, size: 36)))
            else h._fav(t, size: 36),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t.isNewTab ? tr('تب جدید', 'New tab') : t.displayTitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
              Text(t.isNewTab ? '' : t.url.isNotEmpty ? t.url : (t.lazyUrl ?? ''), maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr, style: TextStyle(fontSize: 11, color: cs.onSurface.withValues(alpha: .6))),
            ])),
            IconButton(icon: const Icon(Icons.close), onPressed: () { h.closeTab(t); if (mounted) setState(() {}); }),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final list = h.tabs.where((t) => t.private == private).toList();
    final sections = <Widget>[];
    for (final g in app.groups) {
      final gt = list.where((t) => t.groupId == g.id).toList();
      if (gt.isEmpty) continue;
      sections.add(Padding(
        padding: const EdgeInsets.only(top: 10, bottom: 2),
        child: Row(children: [CircleAvatar(radius: 6, backgroundColor: Color(g.color)), const SizedBox(width: 8), Text('${g.name}  •  ${gt.length} ${tr('تب', 'tabs')}', style: const TextStyle(fontWeight: FontWeight.bold))]),
      ));
      sections.addAll(gt.map(_card));
    }
    final rest = list.where((t) => t.groupId == null || !app.groups.any((g) => g.id == t.groupId)).toList();
    if (rest.isNotEmpty) {
      if (sections.isNotEmpty) sections.add(Padding(padding: const EdgeInsets.only(top: 10, bottom: 2), child: Text(tr('بدون گروه', 'Ungrouped'), style: const TextStyle(fontWeight: FontWeight.bold))));
      sections.addAll(rest.map(_card));
    }
    return GlassScaffold(
      appBar: AppBar(
        title: Text(tr('مدیریت تب‌ها', 'Tabs')),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'close') { for (final t in h.tabs.where((t) => t.private == private).toList()) { h.closeTab(t); } setState(() {}); if (h.tabs.every((t) => t.private != private) && mounted && !private) Navigator.pop(context); }
              if (v == 'group') _newGroup(null);
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'group', child: Text(tr('گروه جدید', 'New group'))),
              PopupMenuItem(value: 'close', child: Text(tr('بستن همهٔ تب‌ها', 'Close all tabs'))),
            ],
          ),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: SegmentedButton<bool>(
            segments: [
              ButtonSegment(value: false, icon: const Icon(Icons.tab), label: Text('${tr('عادی', 'Normal')} (${h.tabs.where((t) => !t.private).length})')),
              ButtonSegment(value: true, icon: const Icon(Icons.visibility_off_outlined), label: Text('${tr('خصوصی', 'Private')} (${h.tabs.where((t) => t.private).length})')),
            ],
            selected: {private}, onSelectionChanged: (s) => setState(() => private = s.first),
          ),
        ),
        Expanded(child: list.isEmpty ? Center(child: Text(tr('تبی وجود ندارد', 'No tabs'))) : ListView(padding: const EdgeInsets.all(14), children: sections)),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: FilledButton.icon(
            onPressed: () { h.openTab('', private: private); Navigator.pop(context); },
            icon: const Icon(Icons.add), label: Text(private ? tr('تب خصوصی جدید', 'New private tab') : tr('تب جدید', 'New tab')),
            style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
          ),
        ),
      ),
    );
  }
}
