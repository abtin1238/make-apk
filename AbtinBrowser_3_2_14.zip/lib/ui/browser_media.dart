part of 'browser_page.dart';
// ignore_for_file: invalid_use_of_protected_member

/// Audio stream of the video whose button was just tapped (set only during that tap).
String _audioHintUrl = '';

extension _Media on _BrowserPageState {
  // ---------------- detected streams ----------------
  void _onMedia(BrowserTab t, Map<String, dynamic> e) {
    final kind = '${e['kind'] ?? ''}';
    if (kind == 'blob') {
      if (!t.mediaBlob) setState(() => t.mediaBlob = true);
      return;
    }
    final url = '${e['url'] ?? ''}';
    if (!url.startsWith('http')) return;
    final incomingSize = (e['size'] as num?)?.toInt() ?? -1;
    final existing = t.media.where((m) => m.url == url).firstOrNull;
    if (existing != null) {
      // A stream is often first reported without Content-Length and later with
      // MIME/size metadata. Keep the same item but refresh its useful fields.
      final nextKind = kind.isEmpty ? existing.kind : kind;
      final nextPart = '${e['part'] ?? existing.part}';
      final nextMime = '${e['mime'] ?? existing.mime}';
      final nextPage = '${e['page'] ?? existing.page}';
      final nextTitle = '${e['title'] ?? existing.title}';
      final nextPoster = '${e['poster'] ?? existing.poster}';
      final changed = incomingSize > existing.size || nextKind != existing.kind ||
          nextPart != existing.part || nextMime != existing.mime || nextPage != existing.page || nextTitle != existing.title || nextPoster != existing.poster;
      if (!changed) return;
      setState(() {
        if (incomingSize > existing.size) existing.size = incomingSize;
        existing.kind = nextKind; existing.part = nextPart; existing.mime = nextMime;
        existing.page = nextPage; existing.title = nextTitle; existing.poster = nextPoster;
      });
      return;
    }
    setState(() {
      t.media.add(MediaItem(
        url: url, kind: kind.isEmpty ? 'video' : kind, part: '${e['part'] ?? ''}', mime: '${e['mime'] ?? ''}',
        size: incomingSize, page: '${e['page'] ?? ''}', title: '${e['title'] ?? ''}', poster: '${e['poster'] ?? ''}', ts: (e['ts'] as num?)?.toInt() ?? 0,
      ));
      if (t.media.length > 60) t.media.removeAt(0);
    });
  }


  /// Buttons drawn on the page's video (content script): act = download | play.
  void _onMediaAct(BrowserTab t, Map<String, dynamic> e) {
    if (!identical(t, current)) return;
    final act = '${e['act'] ?? ''}';
    final u = '${e['url'] ?? ''}';
    MediaItem? m;
    if (u.startsWith('http')) {
      m = t.media.where((x) => x.url == u).firstOrNull;
      if (m == null) {
        final path = u.split('#').first.split('?').first.toLowerCase();
        m = MediaItem(url: u, kind: path.endsWith('.m3u8') ? 'hls' : 'video', page: '${e['page'] ?? ''}', title: '${e['title'] ?? ''}', poster: '${e['poster'] ?? ''}');
        t.media.add(m);
        if (t.media.length > 60) t.media.removeAt(0);
        if (mounted) setState(() {});
      }
    } else {
      final hint = ((e['hint'] as List?) ?? const []).map((x) => '$x').toSet();
      if (hint.isNotEmpty) {
        // streams the page really fed into this very <video> (see mse.js): exact match, no guessing by time
        final mine = t.media.where((x) => hint.contains(x.url)).toList();
        final vids = mine.where((x) => x.kind != 'audio' && x.part != 'audio').toList();
        if (vids.isNotEmpty) {
          vids.sort((a, b) => b.size.compareTo(a.size));
          m = vids.first;
          _audioHintUrl = mine.where((x) => x.kind == 'audio' || x.part == 'audio').map((x) => x.url).firstOrNull ?? '';
        }
      }
      m ??= _videoFor(t, (e['t0'] as num?)?.toInt() ?? 0);
    }
    if (m == null) {
      toast(t.mediaBlob
          ? tr('این ویدیو را چند ثانیه پخش کنید تا لینک دانلودش شناسایی شود', 'Play the video for a few seconds so its link can be detected')
          : tr('لینک ویدیو هنوز شناسایی نشد؛ ویدیو را پخش کنید', 'Video link not detected yet; start playing it'));
      return;
    }
    if (act == 'play') {
      _playMedia(m);
    } else {
      _downloadMedia(m); // its synchronous part picks the audio track; the hint is only valid for this call
    }
    _audioHintUrl = '';
  }

  /// Best candidate when the <video> itself has no readable URL (blob / MSE): complete files first, then HLS, then video-only tracks.
  MediaItem? _bestVideo(BrowserTab t) {
    MediaItem? best;
    int rank(MediaItem m) {
      if (m.kind == 'audio' || m.part == 'audio') return -1;
      if (m.kind == 'video' && m.part.isEmpty) return 3;
      if (m.kind == 'hls') return 2;
      return 1;
    }
    for (final m in t.media) {
      final r = rank(m);
      if (r < 0) continue;
      if (best == null || r > rank(best) || (r == rank(best) && m.size >= best.size)) best = m;
    }
    return best;
  }

  /// The stream that belongs to the tapped <video>: the one first requested when that element started loading.
  MediaItem? _videoFor(BrowserTab t, int t0) {
    if (t0 <= 0) return _bestVideo(t);
    final c = t.media.where((m) => m.ts > 0 && m.kind != 'audio' && m.part != 'audio').toList();
    if (c.isEmpty) return _bestVideo(t);
    final near = c.where((m) => m.ts >= t0 - 2000 && m.ts <= t0 + 8000).toList();
    if (near.isNotEmpty) {
      int rank(MediaItem m) => m.kind == 'hls' ? 2 : (m.part.isEmpty ? 3 : 1);
      near.sort((a, b) => rank(b) != rank(a) ? rank(b).compareTo(rank(a)) : a.ts.compareTo(b.ts));
      return near.first;
    }
    c.sort((a, b) => (a.ts - t0).abs().compareTo((b.ts - t0).abs()));
    return c.first;
  }

  /// Audio track of the same video: the audio stream requested closest in time to [refTs].
  MediaItem? _bestAudio(BrowserTab t, [int refTs = 0]) {
    if (_audioHintUrl.isNotEmpty) {
      final h = t.media.where((m) => m.url == _audioHintUrl).firstOrNull;
      if (h != null) return h;
    }
    MediaItem? best;
    for (final m in t.media) {
      if (m.part != 'audio' && m.kind != 'audio') continue;
      if (best == null) { best = m; continue; }
      if (refTs > 0 && m.ts > 0 && best.ts > 0) {
        final dm = (m.ts - refTs).abs(), db = (best.ts - refTs).abs();
        if (dm < db || (dm == db && m.size > best.size)) best = m;
      } else if (m.size > best.size) {
        best = m;
      }
    }
    return best;
  }

  String _fmtSize(int b) {
    if (b <= 0) return '';
    if (b < 1048576) return '${(b / 1024).toStringAsFixed(0)} KB';
    if (b < 1073741824) return '${(b / 1048576).toStringAsFixed(1)} MB';
    return '${(b / 1073741824).toStringAsFixed(2)} GB';
  }

  String _mediaKindLabel(MediaItem m) {
    if (m.kind == 'hls') return tr('پخش زنده/HLS', 'HLS stream');
    if (m.part == 'audio' || m.kind == 'audio') return tr('فقط صدا', 'Audio only');
    if (m.part == 'video') return tr('تصویر (بدون صدا)', 'Video (no audio)');
    return tr('ویدیو', 'Video');
  }

  void _openMediaSheet() {
    final t = current;
    final items = t.media.reversed.toList();
    final hasAudioTrack = _bestAudio(t) != null;
    showGlassSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        final cs = Theme.of(ctx).colorScheme;
        return SafeArea(
          child: Material(
            type: MaterialType.transparency,
            child: ConstrainedBox(
              constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * .72),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Padding(
                  padding: const EdgeInsetsDirectional.fromSTEB(20, 16, 20, 8),
                  child: Row(children: [
                    const Icon(Icons.smart_display_outlined),
                    const SizedBox(width: 10),
                    Expanded(child: Text('${tr('ویدیوها و صداهای صفحه', 'Videos & audio on this page')} (${items.length})', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
                  ]),
                ),
                if (items.isEmpty)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(24, 12, 24, 28),
                    child: Text(
                      t.mediaBlob
                          ? tr('این سایت ویدیو را به صورت blob پخش می‌کند. ویدیو را چند ثانیه پخش کنید تا لینک‌های قابل دانلود شناسایی شوند.', 'This site plays the video from a blob. Play it for a few seconds so downloadable links can be detected.')
                          : tr('هنوز ویدیویی شناسایی نشد. ویدیو را پخش کنید تا لینک‌ها پیدا شوند.', 'No video detected yet. Start playing it so its links can be found.'),
                      style: TextStyle(color: alpha(cs.onSurface, .75)),
                    ),
                  )
                else
                  Flexible(
                    child: ListView.builder(
                      shrinkWrap: true,
                      itemCount: items.length,
                      itemBuilder: (_, i) {
                        final m = items[i];
                        final sub = [_mediaKindLabel(m), _fmtSize(m.size), if (m.part == 'video' && hasAudioTrack) tr('با صدا ترکیب می‌شود', 'merged with audio')].where((x) => x.isNotEmpty).join(' · ');
                        return ListTile(
                          leading: Icon(m.kind == 'audio' || m.part == 'audio' ? Icons.audiotrack_rounded : Icons.movie_outlined),
                          title: Text(m.label, maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr, textAlign: TextAlign.start),
                          subtitle: Text(sub, style: const TextStyle(fontSize: 12)),
                          onLongPress: () { Clipboard.setData(ClipboardData(text: m.url)); toast(tr('لینک کپی شد', 'Link copied')); },
                          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                            IconButton(tooltip: tr('پخش', 'Play'), icon: const Icon(Icons.play_circle_outline_rounded), onPressed: () { Navigator.of(ctx).pop(); _playMedia(m); }),
                            IconButton(tooltip: tr('دانلود', 'Download'), icon: const Icon(Icons.download_rounded), onPressed: () { Navigator.of(ctx).pop(); _downloadMedia(m); }),
                          ]),
                        );
                      },
                    ),
                  ),
                const SizedBox(height: 6),
              ]),
            ),
          ),
        );
      },
    );
  }

  Future<void> _playMedia(MediaItem m) async {
    final t = current;
    // DASH-style sites (Instagram ...) serve picture and sound as two files: join them first, otherwise the player is silent.
    final wantAudio = m.kind != 'hls' && (_audioHintUrl.isNotEmpty || m.part == 'video');
    final a = wantAudio ? _bestAudio(t, m.ts) : null;
    if (a != null && a.url != m.url && !(m.size > 0 && a.size > 0 && m.size + a.size > 150 * 1048576)) {
      toast(tr('در حال آماده‌سازی تصویر و صدا...', 'Preparing picture and sound...'));
      final f = await mediaDl.mergeForPlay(m, a, referer: t.url);
      if (!mounted) return;
      if (f != null) {
        _push(PlayerPage(file: f, title: t.title.isNotEmpty ? t.title : hostOf(m.url)));
        return;
      }
      toast(tr('ترکیب صدا ناموفق بود؛ ویدیو بدون صدا پخش می‌شود', 'Could not add the sound; playing without sound'));
    }
    _push(PlayerPage(
      url: m.url,
      hls: m.kind == 'hls',
      title: t.title.isNotEmpty ? t.title : hostOf(m.url),
      headers: {
        if (t.url.startsWith('http')) 'Referer': t.url,
        if (gecko.defaultUA.isNotEmpty) 'User-Agent': gecko.defaultUA,
      },
    ));
  }

  Future<void> _downloadMedia(MediaItem m) async {
    final t = current;
    final base = t.title.isNotEmpty ? t.title : hostOf(m.url);
    if (m.kind == 'hls') {
      toast(tr('در حال بررسی لینک...', 'Checking the stream...'));
      List<HlsVariant> vs;
      try {
        vs = await mediaDl.variants(m.url, referer: t.url);
      } catch (_) {
        toast(tr('خواندن لینک ناموفق بود', 'Could not read the stream'));
        return;
      }
      HlsVariant? pick = vs.first;
      if (vs.length > 1 && mounted) {
        pick = await showGlassSheet<HlsVariant>(
          context: context,
          builder: (ctx) => SafeArea(
            child: Material(
              type: MaterialType.transparency,
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 6), child: Text(tr('کیفیت را انتخاب کنید', 'Choose quality'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
                for (final v in vs.take(8)) ListTile(leading: const Icon(Icons.high_quality_outlined), title: Text(v.label), onTap: () => Navigator.of(ctx).pop(v)),
                const SizedBox(height: 6),
              ]),
            ),
          ),
        );
      }
      if (pick == null) return;
      unawaited(mediaDl.hls(pick, referer: t.url, title: base, private: t.private));
      return;
    }
    if (m.part == 'video' || _audioHintUrl.isNotEmpty) {
      final a = _bestAudio(t, m.ts);
      if (a != null && a.url != m.url) {
        unawaited(mediaDl.merge(m, a, referer: t.url, title: base, private: t.private).then((ok) {
          if (!ok && mounted) toast(tr('ترکیب صدا و تصویر ناموفق بود؛ ویدیو بدون صدا ذخیره شد', 'Could not add the sound; saved without sound'));
        }));
        return;
      }
    }
    await dlMgr.start(m.url, name: '${dlMgr.cleanName(base)}.${m.ext}', referer: t.url, private: t.private);
  }

  // ---------------- QR scanner ----------------
  Future<void> _scanQr() async {
    final r = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => const QrScannerPage()));
    if (r == null || r.isEmpty || !mounted) return;
    _qrResult(r.trim());
  }

  bool _qrLooksLikeUrl(String s) =>
      RegExp(r'^(https?://|www\.)', caseSensitive: false).hasMatch(s) || RegExp(r'^[\w-]+(\.[\w-]+)+(:\d+)?(/\S*)?$').hasMatch(s);

  bool _qrIsAppLink(String s) => RegExp(r'^(tel|mailto|sms|smsto|geo|market|intent):', caseSensitive: false).hasMatch(s);

  void _qrResult(String text) {
    final isUrl = _qrLooksLikeUrl(text);
    final isApp = _qrIsAppLink(text);
    showGlassSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => SafeArea(
        child: Material(
          type: MaterialType.transparency,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 14),
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row(children: [
                const Icon(Icons.qr_code_2_rounded),
                const SizedBox(width: 10),
                Text(tr('نتیجهٔ اسکن', 'Scan result'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              ]),
              const SizedBox(height: 12),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(ctx).size.height * .3),
                child: SingleChildScrollView(child: SelectableText(text, textDirection: TextDirection.ltr, textAlign: TextAlign.start)),
              ),
              const SizedBox(height: 14),
              Wrap(spacing: 8, runSpacing: 8, children: [
                if (isUrl)
                  FilledButton.icon(onPressed: () { Navigator.of(ctx).pop(); navigate(current, text); }, icon: const Icon(Icons.open_in_browser), label: Text(tr('باز کردن', 'Open'))),
                if (isUrl)
                  FilledButton.tonalIcon(onPressed: () { Navigator.of(ctx).pop(); openTab(text.startsWith('http') ? text : 'https://$text'); }, icon: const Icon(Icons.add), label: Text(tr('تب جدید', 'New tab'))),
                if (isApp)
                  FilledButton.icon(onPressed: () { Navigator.of(ctx).pop(); launchUrl(Uri.parse(text), mode: LaunchMode.externalApplication); }, icon: const Icon(Icons.launch), label: Text(tr('باز کردن با برنامه', 'Open with app'))),
                if (!isUrl && !isApp)
                  FilledButton.icon(onPressed: () { Navigator.of(ctx).pop(); navigate(current, text); }, icon: const Icon(Icons.search), label: Text(tr('جست‌وجو', 'Search'))),
                OutlinedButton.icon(onPressed: () { Clipboard.setData(ClipboardData(text: text)); toast(tr('کپی شد', 'Copied')); }, icon: const Icon(Icons.copy), label: Text(tr('کپی', 'Copy'))),
                OutlinedButton.icon(onPressed: () => Share.share(text), icon: const Icon(Icons.share_outlined), label: Text(tr('اشتراک', 'Share'))),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}
