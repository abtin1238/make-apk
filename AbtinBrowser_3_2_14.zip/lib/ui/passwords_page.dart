import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../app_state.dart';
import '../services.dart';
import 'glass.dart';

/// Saved passwords (stored encrypted by the native side: AES-GCM, key in the Android Keystore).
class PasswordsPage extends StatefulWidget {
  const PasswordsPage({super.key});
  @override
  State<PasswordsPage> createState() => _PasswordsPageState();
}

class _PasswordsPageState extends State<PasswordsPage> {
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;
  String _q = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await gecko.call<List<dynamic>>('loginsList');
    final l = (r ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    l.sort((a, b) => '${a['host']}'.compareTo('${b['host']}'));
    if (!mounted) return;
    setState(() { _items = l; _loading = false; });
  }

  void _snack(String m) => snackTop(context, m);

  List<Map<String, dynamic>> get _shown {
    final q = _q.trim().toLowerCase();
    if (q.isEmpty) return _items;
    return _items.where((e) => '${e['host']}'.toLowerCase().contains(q) || '${e['user']}'.toLowerCase().contains(q)).toList();
  }

  Future<void> _edit([Map<String, dynamic>? it]) async {
    final site = TextEditingController(text: it == null ? '' : '${it['origin']}');
    final user = TextEditingController(text: it == null ? '' : '${it['user']}');
    final pass = TextEditingController(text: it == null ? '' : '${it['pass']}');
    var hide = true;
    final ok = await showGlassDialog<bool>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, set) => AlertDialog(
          title: Text(it == null ? tr('افزودن رمز عبور', 'Add password') : tr('ویرایش رمز عبور', 'Edit password'), style: const TextStyle(fontSize: 16)),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: site, enabled: it == null, textDirection: TextDirection.ltr, keyboardType: TextInputType.url, decoration: InputDecoration(labelText: tr('آدرس سایت', 'Website'), hintText: 'https://example.com')),
            TextField(controller: user, textDirection: TextDirection.ltr, keyboardType: TextInputType.visiblePassword, decoration: InputDecoration(labelText: tr('نام کاربری', 'Username'))),
            TextField(
              controller: pass, obscureText: hide, textDirection: TextDirection.ltr, keyboardType: TextInputType.visiblePassword,
              decoration: InputDecoration(labelText: tr('رمز عبور', 'Password'), suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility_outlined : Icons.visibility_off_outlined), onPressed: () => set(() => hide = !hide))),
            ),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))),
            TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('ذخیره', 'Save'))),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final r = await gecko.call<bool>('loginsPut', {'guid': it == null ? '' : '${it['guid']}', 'origin': site.text, 'user': user.text, 'pass': pass.text});
    if (r != true) _snack(tr('آدرس سایت و رمز عبور را وارد کنید', 'Enter the website and a password'));
    await _load();
  }

  Future<void> _view(Map<String, dynamic> it) async {
    var hide = true;
    await showGlassDialog<void>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, set) => AlertDialog(
          title: Text('${it['host']}', textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 16)),
          content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(tr('نام کاربری', 'Username'), style: const TextStyle(fontSize: 12)),
            Row(children: [
              Expanded(child: SelectableText('${it['user']}'.isEmpty ? '—' : '${it['user']}', textDirection: TextDirection.ltr)),
              if ('${it['user']}'.isNotEmpty) IconButton(tooltip: tr('کپی', 'Copy'), icon: const Icon(Icons.copy_rounded, size: 18), onPressed: () { Clipboard.setData(ClipboardData(text: '${it['user']}')); _snack(tr('نام کاربری کپی شد', 'Username copied')); }),
            ]),
            const SizedBox(height: 6),
            Text(tr('رمز عبور', 'Password'), style: const TextStyle(fontSize: 12)),
            Row(children: [
              Expanded(child: Text(hide ? '•' * ('${it['pass']}'.length.clamp(6, 16)) : '${it['pass']}', textDirection: TextDirection.ltr)),
              IconButton(tooltip: tr('نمایش', 'Show'), icon: Icon(hide ? Icons.visibility_outlined : Icons.visibility_off_outlined, size: 18), onPressed: () => set(() => hide = !hide)),
              IconButton(tooltip: tr('کپی', 'Copy'), icon: const Icon(Icons.copy_rounded, size: 18), onPressed: () { Clipboard.setData(ClipboardData(text: '${it['pass']}')); _snack(tr('رمز عبور کپی شد', 'Password copied')); }),
            ]),
          ]),
          actions: [
            TextButton(onPressed: () { Navigator.pop(d); _delete(it); }, child: Text(tr('حذف', 'Delete'), style: const TextStyle(color: Colors.redAccent))),
            TextButton(onPressed: () { Navigator.pop(d); _edit(it); }, child: Text(tr('ویرایش', 'Edit'))),
            TextButton(onPressed: () => Navigator.pop(d), child: Text(tr('بستن', 'Close'))),
          ],
        ),
      ),
    );
  }

  Future<void> _delete(Map<String, dynamic> it) async {
    final ok = await _confirm(tr('حذف این رمز؟', 'Delete this password?'), '${it['host']}${'${it['user']}'.isEmpty ? '' : '\n${it['user']}'}');
    if (!ok) return;
    await gecko.call('loginsDelete', {'guid': '${it['guid']}'});
    await _load();
  }

  Future<void> _clearAll() async {
    final ok = await _confirm(tr('حذف همهٔ رمزها؟', 'Delete all passwords?'), tr('این کار قابل بازگشت نیست.', 'This cannot be undone.'));
    if (!ok) return;
    await gecko.call('loginsClear');
    await _load();
  }

  Future<bool> _confirm(String title, String body) async {
    final r = await showGlassDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(title, style: const TextStyle(fontSize: 16)),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))),
          TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('حذف', 'Delete'), style: const TextStyle(color: Colors.redAccent))),
        ],
      ),
    );
    return r == true;
  }

  Future<void> _never() async {
    final r = await gecko.call<List<dynamic>>('loginsNever');
    final hosts = (r ?? const []).map((e) => '$e').toList()..sort();
    if (!mounted) return;
    await showGlassDialog<void>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, set) => AlertDialog(
          title: Text(tr('سایت‌هایی که «هرگز» ذخیره نمی‌شوند', 'Never saved sites'), style: const TextStyle(fontSize: 16)),
          content: SizedBox(
            width: double.maxFinite,
            child: hosts.isEmpty
                ? Padding(padding: const EdgeInsets.all(8), child: Text(tr('موردی نیست', 'None')))
                : ListView(shrinkWrap: true, children: [
                    for (final h in hosts)
                      ListTile(
                        dense: true, title: Text(h, textDirection: TextDirection.ltr),
                        trailing: IconButton(icon: const Icon(Icons.close_rounded, size: 18), onPressed: () async { await gecko.call('loginsNeverRemove', {'host': h}); set(() => hosts.remove(h)); }),
                      ),
                  ]),
          ),
          actions: [TextButton(onPressed: () => Navigator.pop(d), child: Text(tr('بستن', 'Close')))],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final l = _shown;
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('رمزهای عبور', 'Passwords')),
        actions: [
          IconButton(tooltip: tr('افزودن', 'Add'), icon: const Icon(Icons.add_rounded), onPressed: () => _edit()),
          PopupMenuButton<String>(
            onSelected: (v) { if (v == 'never') { _never(); } else if (v == 'clear') { _clearAll(); } },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'never', child: Text(tr('سایت‌های «هرگز ذخیره نکن»', 'Never saved sites'))),
              if (_items.isNotEmpty) PopupMenuItem(value: 'clear', child: Text(tr('حذف همهٔ رمزها', 'Delete all'), style: const TextStyle(color: Colors.redAccent))),
            ],
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : Column(children: [
              if (_items.length > 6)
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
                  child: TextField(onChanged: (v) => setState(() => _q = v), decoration: InputDecoration(prefixIcon: const Icon(Icons.search_rounded), hintText: tr('جست‌وجو', 'Search'), isDense: true)),
                ),
              Expanded(
                child: l.isEmpty
                    ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_items.isEmpty ? tr('هنوز رمزی ذخیره نشده است.\nبعد از ورود به یک سایت، پیشنهاد ذخیره نشان داده می‌شود.', 'No saved passwords yet.\nAfter you sign in to a site, you will be offered to save it.') : tr('نتیجه‌ای نیست', 'No results'), textAlign: TextAlign.center)))
                    : ListView.separated(
                        itemCount: l.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (_, i) {
                          final it = l[i];
                          final u = '${it['user']}';
                          return ListTile(
                            leading: const Icon(Icons.key_rounded),
                            title: Text('${it['host']}', textDirection: TextDirection.ltr, maxLines: 1, overflow: TextOverflow.ellipsis),
                            subtitle: Text(u.isEmpty ? tr('(بدون نام کاربری)', '(no username)') : u, textDirection: TextDirection.ltr, maxLines: 1, overflow: TextOverflow.ellipsis),
                            trailing: IconButton(tooltip: tr('کپی رمز', 'Copy password'), icon: const Icon(Icons.copy_rounded, size: 20), onPressed: () { Clipboard.setData(ClipboardData(text: '${it['pass']}')); _snack(tr('رمز عبور کپی شد', 'Password copied')); }),
                            onTap: () => _view(it),
                          );
                        },
                      ),
              ),
            ]),
    );
  }
}
