import 'package:flutter/material.dart';
import '../app_state.dart';
import '../services.dart';

/// Apps that must NOT go through the VPN (Iranian banks, messengers, shops): they keep the normal network and never see a VPN.
class V2rayAppsPage extends StatefulWidget {
  const V2rayAppsPage({super.key});
  @override
  State<V2rayAppsPage> createState() => _V2rayAppsPageState();
}

class _V2rayAppsPageState extends State<V2rayAppsPage> {
  List<Map<String, dynamic>>? _apps;
  String _q = '';

  @override
  void initState() {
    super.initState();
    v2ray.listApps().then((l) { if (mounted) setState(() => _apps = l); });
  }

  bool _outside(Map<String, dynamic> a, Map<String, bool> over) {
    final o = over[a['pkg']];
    if (o != null) return o;
    return app.flag('v2SkipIranApps') && a['iran'] == true;
  }

  @override
  Widget build(BuildContext context) {
    final over = v2ray.appOverrides;
    final all = _apps;
    final q = _q.trim().toLowerCase();
    final list = all == null
        ? <Map<String, dynamic>>[]
        : all.where((a) => q.isEmpty || '${a['label']}'.toLowerCase().contains(q) || '${a['pkg']}'.toLowerCase().contains(q)).toList()
      ..sort((a, b) {
        final x = _outside(a, over) ? 0 : 1, y = _outside(b, over) ? 0 : 1;
        return x != y ? x - y : '${a['label']}'.toLowerCase().compareTo('${b['label']}'.toLowerCase());
      });
    return Scaffold(
      appBar: AppBar(title: Text(tr('برنامه‌های خارج از VPN', 'Apps outside the VPN'))),
      body: Column(children: [
        SwitchListTile(
          value: app.flag('v2SkipIranApps'),
          onChanged: (v) => setState(() => app.set('v2SkipIranApps', v)),
          title: Text(tr('تشخیص خودکار برنامه‌های ایرانی', 'Auto-detect Iranian apps')),
          subtitle: Text(tr('بانک‌ها و برنامه‌های فارسی از VPN رد نمی‌شوند', 'Banks and Persian apps stay out of the VPN'), style: const TextStyle(fontSize: 12)),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: TextField(
            decoration: InputDecoration(prefixIcon: const Icon(Icons.search), hintText: tr('جستجو', 'Search')),
            onChanged: (v) => setState(() => _q = v),
          ),
        ),
        Expanded(
          child: all == null
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) {
                    final a = list[i];
                    final pkg = a['pkg'] as String;
                    return SwitchListTile(
                      value: _outside(a, over),
                      onChanged: (v) => setState(() => v2ray.setAppOverride(pkg, v)),
                      title: Text('${a['label']}'),
                      subtitle: Text(pkg, style: const TextStyle(fontSize: 11), textDirection: TextDirection.ltr),
                      secondary: a['iran'] == true ? const Icon(Icons.flag_rounded, size: 18) : null,
                    );
                  },
                ),
        ),
        Padding(
          padding: const EdgeInsets.all(12),
          child: Text(tr('روشن = بدون VPN. تغییرات با اتصال بعدی اعمال می‌شود.', 'On = no VPN. Changes apply on the next connection.'), style: const TextStyle(fontSize: 12)),
        ),
      ]),
    );
  }
}
