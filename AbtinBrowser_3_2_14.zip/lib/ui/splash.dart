import 'package:flutter/material.dart';
import '../app_state.dart';
import '../services.dart';
import 'browser_page.dart';
import 'glass.dart';

class AbtinLogo extends StatelessWidget {
  const AbtinLogo({super.key, this.size = 110});
  final double size;
  @override
  Widget build(BuildContext context) => Image.asset('assets/icon/abtin_logo.png', width: size, height: size, filterQuality: FilterQuality.medium);
}

class SplashPage extends StatelessWidget {
  const SplashPage({super.key});
  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    Widget feat(IconData i, String t) => Column(children: [
          Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(16)), child: Icon(i, color: cs.primary)),
          const SizedBox(height: 8), Text(t, style: const TextStyle(fontSize: 12)),
        ]);
    return GlassScaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(children: [
            const Spacer(),
            const AbtinLogo(),
            const SizedBox(height: 20),
            const Text('آبتین', style: TextStyle(fontSize: 42, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(tr('مرورگر سریع، امن، قدرتمند', 'Fast, secure, powerful browser')),
            const SizedBox(height: 36),
            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
              feat(Icons.shield_outlined, tr('حریم خصوصی', 'Privacy')),
              feat(Icons.extension_outlined, tr('افزونه‌ها', 'Extensions')),
              feat(Icons.speed, tr('عملکرد بالا', 'Performance')),
            ]),
            const Spacer(),
            SizedBox(
              width: double.infinity, height: 52,
              child: FilledButton(
                onPressed: () {
                  app.set('onboarded', true);
                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => const BrowserPage()));
                },
                child: Text(tr('شروع', 'Start'), style: const TextStyle(fontSize: 18)),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}
