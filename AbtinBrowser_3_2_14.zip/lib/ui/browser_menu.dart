part of 'browser_page.dart';

// ignore_for_file: invalid_use_of_protected_member

extension _Menu on _BrowserPageState {
  void _push(Widget w) =>
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => w));

  void _openBookmarks() => _push(
        BookmarksPage(
          onOpen: (u, {bool newTab = false}) {
            newTab ? openTab(u) : navigate(current, u);
          },
        ),
      );
  void _openHistory() => _push(
        HistoryPage(
          onOpen: (u, {bool newTab = false}) {
            newTab ? openTab(u) : navigate(current, u);
          },
        ),
      );
  void _openDownloads() => _push(const DownloadsPage());

  Future<void> _openLocalProject() async {
    try {
      final url = await const MethodChannel('abtin/local_project')
          .invokeMethod<String>('pickProjectFolder');
      if (!mounted || url == null || url.isEmpty) return;
      // A folder picker must return the local HTTP bridge URL. A content:// URI is
      // a SAF tree handle, not a URL GeckoView can navigate to.
      final parsed = Uri.tryParse(url);
      if (parsed == null ||
          (parsed.scheme != 'http' && parsed.scheme != 'https') ||
          parsed.host.isEmpty) {
        throw PlatformException(
          code: 'invalid_project_url',
          message: tr(
            'آدرس پوشه به‌درستی تبدیل نشد. دوباره پوشه را انتخاب کنید.',
            'The selected folder could not be converted to a local project URL. Please select it again.',
          ),
        );
      }
      navigate(current, parsed.toString());
      toast(tr('پروژهٔ محلی باز شد', 'Local project opened'));
    } on PlatformException catch (e) {
      if (mounted)
        toast(
          e.message ?? tr('بازکردن پوشه ناموفق بود', 'Could not open folder'),
        );
    } catch (_) {
      if (mounted)
        toast(tr('بازکردن پوشه ناموفق بود', 'Could not open folder'));
    }
  }

  void _openExtensions() => _push(ExtensionsPage(host: this));
  void _openSettings() => _push(
        SettingsPage(onClear: clearBrowsingData, onOpen: (u) => openTab(u)),
      );

  Future<void> _takeScreenshot() async {
    final b = await gecko.call<Uint8List>('capture', {'width': 0, 'png': true});
    if (b == null) {
      toast(tr('عکس‌گرفتن ممکن نشد', 'Could not capture'));
      return;
    }
    final f = await saveScreenshot(b);
    toast(
      f == null
          ? tr('ذخیرهٔ عکس ناموفق بود', 'Could not save the screenshot')
          : '${tr('ذخیره شد', 'Saved')}: ${f.path}',
    );
  }

  void _openSwitcher() async {
    await _snap(current, force: true);
    if (!mounted) return;
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => _TabSwitcher(host: this)));
    _syncAddr();
  }

  // ---------------- menu ----------------
  /// Chrome-style dropdown: a floating card anchored to the top corner (under the ⋮ button) that
  /// grows out of it, with a row of quick icons on top and a plain list of items below.
  void _openMenu() =>
      app.str('menuStyle') == 'chrome' ? _openMenuChrome() : _openMenuFirefox();

  void _openMenuChrome() {
    final cs = Theme.of(context).colorScheme;
    showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'menu',
      barrierColor: Colors.black26,
      transitionDuration: app.flag('uiAnim')
          ? const Duration(milliseconds: 160)
          : Duration.zero,
      pageBuilder: (ctx, _, __) {
        final t = current;
        void run(VoidCallback f) {
          Navigator.pop(ctx);
          f();
        }

        final page = t.started && !t.showHome;
        final web = page && t.url.startsWith('http');
        final bookmarked = app.isBookmarked(t.url);
        final exts = extMgr.list.toList();
        final mq = MediaQuery.of(ctx);

        Widget quick(IconData i, String tip, VoidCallback? f, {Color? c}) =>
            Expanded(
              child: IconButton(
                tooltip: tip,
                onPressed: f == null ? null : () => run(f),
                icon: Icon(i, size: 22, color: f == null ? null : c),
              ),
            );

        Widget item(
          IconData i,
          String s,
          VoidCallback? f, {
          bool? check,
          Color? c,
        }) =>
            InkWell(
              onTap: f == null ? null : () => run(f),
              child: Opacity(
                opacity: f == null ? .38 : 1,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                  child: Row(
                    children: [
                      Icon(i, size: 21, color: c ?? alpha(cs.onSurface, .78)),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Text(
                          s,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontSize: 14.5),
                        ),
                      ),
                      if (check != null)
                        Icon(
                          check
                              ? Icons.check_box
                              : Icons.check_box_outline_blank,
                          size: 20,
                          color: check ? cs.primary : alpha(cs.onSurface, .5),
                        ),
                    ],
                  ),
                ),
              ),
            );

        Widget divider() =>
            Divider(height: 8, thickness: 1, color: alpha(cs.onSurface, .1));

        final card = Material(
          color: Colors.transparent,
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: 300,
              maxHeight:
                  mq.size.height - mq.padding.top - mq.padding.bottom - 16,
            ),
            child: Glass(
              radius: 16,
              strong: true,
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(vertical: 6),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                      child: Row(
                        children: [
                          quick(
                            Icons.arrow_forward,
                            tr('جلو', 'Forward'),
                            page && t.canForward
                                ? () => gecko.call('forward', {'id': t.nid})
                                : null,
                          ),
                          quick(
                            bookmarked ? Icons.star : Icons.star_border,
                            tr('نشانک', 'Bookmark'),
                            web
                                ? () {
                                    setState(
                                      () => app.toggleBookmark(t.url, t.title),
                                    );
                                    toast(
                                      app.isBookmarked(t.url)
                                          ? tr(
                                              'به نشانک‌ها افزوده شد',
                                              'Bookmarked',
                                            )
                                          : tr(
                                              'از نشانک‌ها حذف شد',
                                              'Bookmark removed',
                                            ),
                                    );
                                  }
                                : null,
                            c: bookmarked ? const Color(0xFFFBBF24) : null,
                          ),
                          quick(
                            Icons.download_outlined,
                            tr('دانلودها', 'Downloads'),
                            _openDownloads,
                          ),
                          quick(
                            Icons.share_outlined,
                            tr('اشتراک', 'Share'),
                            page ? () => Share.share(t.url) : null,
                          ),
                          quick(
                            t.loading ? Icons.close : Icons.refresh,
                            tr('بازخوانی', 'Reload'),
                            page
                                ? () => gecko.call(
                                      t.loading ? 'stop' : 'reload',
                                      {'id': t.nid},
                                    )
                                : null,
                          ),
                        ],
                      ),
                    ),
                    divider(),
                    item(
                      Icons.folder_open,
                      tr('بازکردن پروژه از حافظه', 'Open local project'),
                      _openLocalProject,
                    ),
                    item(
                      Icons.add_rounded,
                      tr('تب جدید', 'New tab'),
                      () => openTab(''),
                    ),
                    item(
                      Icons.visibility_off_outlined,
                      tr('تب خصوصی جدید', 'New private tab'),
                      () => openTab('', private: true),
                    ),
                    item(
                      Icons.tab_rounded,
                      tr('تب‌ها (${tabs.length})', 'Tabs (${tabs.length})'),
                      _openSwitcher,
                    ),
                    divider(),
                    item(
                      Icons.star_outline_rounded,
                      tr('نشانک‌ها', 'Bookmarks'),
                      _openBookmarks,
                    ),
                    item(
                      Icons.history_rounded,
                      tr('تاریخچه', 'History'),
                      _openHistory,
                    ),
                    item(
                      Icons.extension_outlined,
                      tr('افزونه‌ها', 'Extensions'),
                      _openExtensions,
                    ),
                    for (final e in exts)
                      _extRow(e, run, iconSize: 22, fontSize: 14, pad: const EdgeInsetsDirectional.only(start: 16, end: 16, top: 4, bottom: 4)),
                    divider(),
                    item(
                      Icons.smart_display_outlined,
                      '${tr('ویدیوهای صفحه', 'Page videos')}${t.media.isEmpty ? '' : ' (${t.media.length})'}',
                      page ? _openMediaSheet : null,
                    ),
                    item(
                      Icons.qr_code_scanner_rounded,
                      tr('اسکن QR', 'Scan QR code'),
                      _scanQr,
                    ),
                    item(
                      Icons.find_in_page_outlined,
                      tr('جست‌وجو در صفحه', 'Find in page'),
                      page ? () => setState(() => finding = true) : null,
                    ),
                    item(
                      Icons.translate,
                      tr('ترجمه', 'Translate'),
                      web
                          ? () => navigate(
                                t,
                                'https://translate.google.com/translate?sl=auto&tl=${app.lang}&u=${Uri.encodeComponent(t.url)}',
                              )
                          : null,
                    ),
                    item(
                      Icons.desktop_windows_outlined,
                      tr('نسخهٔ دسکتاپ', 'Desktop site'),
                      page
                          ? () {
                              setState(() => t.desktop = !t.desktop);
                              gecko.call('setDesktop', {
                                'id': t.nid,
                                'desktop': t.desktop,
                              });
                            }
                          : null,
                      check: t.desktop,
                    ),
                    item(
                      Icons.chrome_reader_mode_outlined,
                      tr('حالت خواندن', 'Reader mode'),
                      page && !t.failed ? _toggleReader : null,
                    ),
                    item(
                      Icons.public,
                      tr(
                        'هویت Chrome برای این سایت',
                        'Chrome identity for this site',
                      ),
                      web && app.flag('chromeUa') ? _toggleChromeSite : null,
                      check: web && app.chromeOn(hostOf(t.url)),
                    ),
                    item(
                      Icons.code,
                      tr('بازرسی المنت', 'Inspect element'),
                      page && !t.failed ? _inspectElement : null,
                    ),
                    item(
                      Icons.save_alt_outlined,
                      tr('دانلود صفحه (HTML)', 'Download page (HTML)'),
                      page && !t.failed ? () => savePage(t, pdf: false) : null,
                    ),
                    item(
                      Icons.picture_as_pdf_outlined,
                      tr('دانلود صفحه (PDF)', 'Download page (PDF)'),
                      page && !t.failed ? () => savePage(t, pdf: true) : null,
                    ),
                    item(
                      Icons.print_outlined,
                      tr('چاپ / PDF', 'Print / PDF'),
                      page && !t.failed
                          ? () async {
                              if (await gecko.call<bool>('print', {
                                    'id': t.nid,
                                  }) !=
                                  true)
                                toast(tr('چاپ ممکن نشد', 'Could not print'));
                            }
                          : null,
                    ),
                    item(
                      Icons.photo_camera_outlined,
                      tr('عکس از صفحه', 'Screenshot'),
                      page ? _takeScreenshot : null,
                    ),
                    divider(),
                    item(
                      Icons.add_to_home_screen,
                      tr('افزودن به صفحهٔ اصلی گوشی', 'Add to home screen'),
                      web ? () => _chooseHomeScreenMode(t) : null,
                    ),
                    item(
                      Icons.dashboard_customize_outlined,
                      tr('افزودن به صفحهٔ شروع', 'Add to start page'),
                      web ? () => _addToStartPage(t) : null,
                    ),
                    item(
                      Icons.link,
                      tr('کپی لینک', 'Copy link'),
                      page
                          ? () {
                              Clipboard.setData(ClipboardData(text: t.url));
                              toast(tr('لینک کپی شد', 'Link copied'));
                            }
                          : null,
                    ),
                    item(
                      Icons.shield_outlined,
                      tr('اطلاعات سایت', 'Site info'),
                      web ? _siteInfo : null,
                    ),
                    divider(),
                    item(
                      Icons.delete_sweep_outlined,
                      tr('پاک‌سازی داده‌ها', 'Clear data'),
                      _openSettings,
                    ),
                    item(
                      Icons.settings_outlined,
                      tr('تنظیمات', 'Settings'),
                      _openSettings,
                    ),
                  ],
                ),
              ),
            ),
          ),
        );

        return SafeArea(
          child: Align(
            alignment: AlignmentDirectional.topEnd,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
              child: card,
            ),
          ),
        );
      },
      transitionBuilder: (ctx, anim, _, child) {
        final c = CurvedAnimation(
          parent: anim,
          curve: Curves.easeOutCubic,
          reverseCurve: Curves.easeIn,
        );
        return FadeTransition(
          opacity: c,
          child: ScaleTransition(
            scale: Tween<double>(begin: .85, end: 1).animate(c),
            alignment: AlignmentDirectional.topEnd.resolve(
              Directionality.of(ctx),
            ),
            child: child,
          ),
        );
      },
    );
  }

  /// Firefox-style bottom sheet: icon row on top, rounded list, collapsible "More", tiles, Settings.
  void _openMenuFirefox() {
    final cs = Theme.of(context).colorScheme;
    bool more = false, extOpen = false;
    showGlassSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) {
          final t = current;
          void run(VoidCallback f) {
            Navigator.pop(ctx);
            f();
          }

          final page = t.started && !t.showHome;
          final web = page && t.url.startsWith('http');
          final bookmarked = app.isBookmarked(t.url);
          final exts = extMgr.list.toList();
          final rowBg = alpha(cs.onSurface, .07);

          Widget top(IconData i, String s, VoidCallback? f) => Expanded(
                child: InkWell(
                  onTap: f == null ? null : () => run(f),
                  borderRadius: BorderRadius.circular(16),
                  child: Opacity(
                    opacity: f == null ? .38 : 1,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(i, size: 26),
                          const SizedBox(height: 6),
                          Text(
                            s,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );

          Widget pill(Widget child) => Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: alpha(cs.onSurface, .12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: child,
              );

          // one row of a rounded group; `r` gives the outer-corner rounding for first / last rows
          Widget Function(BorderRadius) row(
            IconData i,
            String s,
            VoidCallback? f, {
            String? sub,
            Widget? trailing,
            bool closeAfter = true,
          }) =>
              (r) => Padding(
                    padding: const EdgeInsets.only(bottom: 2),
                    child: Material(
                      color: rowBg,
                      borderRadius: r,
                      child: InkWell(
                        borderRadius: r,
                        onTap:
                            f == null ? null : (closeAfter ? () => run(f) : f),
                        child: Opacity(
                          opacity: f == null ? .38 : 1,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 14,
                            ),
                            child: Row(
                              children: [
                                Icon(i, size: 24),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        s,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w600,
                                        ),
                                      ),
                                      if (sub != null)
                                        Text(
                                          sub,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(
                                            fontSize: 13,
                                            color: alpha(cs.onSurface, .7),
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                                if (trailing != null) trailing,
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  );

          Widget grp(List<Widget Function(BorderRadius)> rows) {
            const big = Radius.circular(22), small = Radius.circular(6);
            return Column(
              children: [
                for (var k = 0; k < rows.length; k++)
                  rows[k](
                    BorderRadius.vertical(
                      top: k == 0 ? big : small,
                      bottom: k == rows.length - 1 ? big : small,
                    ),
                  ),
              ],
            );
          }

          Widget tile(
            IconData i,
            String s,
            VoidCallback f,
            BorderRadiusGeometry rg,
          ) =>
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 1),
                  child: Builder(
                    builder: (_) {
                      final r = rg.resolve(Directionality.of(ctx));
                      return Material(
                        color: rowBg,
                        borderRadius: r,
                        child: InkWell(
                          borderRadius: r,
                          onTap: () => run(f),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 16),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(i, size: 26),
                                const SizedBox(height: 8),
                                Text(
                                  s,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                    fontSize: 13.5,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              );

          final extNames = exts.map((e) => e.name).join(', ');
          final extRows = <Widget Function(BorderRadius)>[
            for (final e in exts)
              (r) => _extRow(e, run, iconSize: 26, fontSize: 15, pad: const EdgeInsets.symmetric(horizontal: 16, vertical: 4), r: r, bg: rowBg),
          ];

          return SafeArea(
            top: false,
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Center(
                    child: Container(
                      width: 44,
                      height: 5,
                      decoration: BoxDecoration(
                        color: alpha(cs.onSurface, .3),
                        borderRadius: BorderRadius.circular(5),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      top(
                        Icons.arrow_back,
                        tr('عقب', 'Back'),
                        page && t.canBack
                            ? () => gecko.call('back', {'id': t.nid})
                            : null,
                      ),
                      top(
                        Icons.arrow_forward,
                        tr('جلو', 'Forward'),
                        page && t.canForward
                            ? () => gecko.call('forward', {'id': t.nid})
                            : null,
                      ),
                      top(
                        Icons.share_outlined,
                        tr('اشتراک‌گذاری', 'Share'),
                        page ? () => Share.share(t.url) : null,
                      ),
                      top(
                        t.loading ? Icons.close : Icons.refresh,
                        tr('بازخوانی', 'Reload'),
                        page
                            ? () => gecko.call(t.loading ? 'stop' : 'reload', {
                                  'id': t.nid,
                                })
                            : null,
                      ),
                    ],
                  ),
                  Divider(height: 8, color: alpha(cs.onSurface, .15)),
                  const SizedBox(height: 6),
                  grp([
                    row(
                      Icons.folder_open,
                      tr('بازکردن پروژه از حافظه', 'Open local project'),
                      _openLocalProject,
                      sub: tr(
                        'اجرای پوشهٔ کامل HTML و CSS و JavaScript',
                        'Run a complete HTML/CSS/JavaScript folder',
                      ),
                    ),
                    row(
                      bookmarked ? Icons.star : Icons.star_border,
                      tr('نشانک‌گذاری صفحه', 'Bookmark this page'),
                      web
                          ? () {
                              setState(
                                () => app.toggleBookmark(t.url, t.title),
                              );
                              toast(
                                app.isBookmarked(t.url)
                                    ? tr('به نشانک‌ها افزوده شد', 'Bookmarked')
                                    : tr(
                                        'از نشانک‌ها حذف شد',
                                        'Bookmark removed',
                                      ),
                              );
                            }
                          : null,
                    ),
                    row(
                      Icons.search,
                      tr('پیدا کردن در صفحه', 'Find in page'),
                      page ? () => setState(() => finding = true) : null,
                    ),
                    row(
                      Icons.laptop,
                      tr('وبگاه رومیزی', 'Desktop site'),
                      page
                          ? () {
                              setState(() => t.desktop = !t.desktop);
                              gecko.call('setDesktop', {
                                'id': t.nid,
                                'desktop': t.desktop,
                              });
                              setS(() {});
                            }
                          : null,
                      closeAfter: false,
                      trailing: pill(
                        Text(
                          t.desktop ? tr('روشن', 'On') : tr('خاموش', 'Off'),
                          style: const TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                    row(
                      Icons.smart_display_outlined,
                      tr('ویدیوهای صفحه', 'Page videos'),
                      page ? _openMediaSheet : null,
                      sub: t.media.isEmpty ? null : '${t.media.length}',
                    ),
                    row(
                      Icons.qr_code_scanner_rounded,
                      tr('اسکن QR', 'Scan QR code'),
                      _scanQr,
                    ),
                    if (exts.isNotEmpty)
                      row(
                        Icons.extension_outlined,
                        tr('افزونه‌ها', 'Extensions'),
                        () => setS(() => extOpen = !extOpen),
                        sub: extNames,
                        closeAfter: false,
                        trailing: pill(
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(
                                extOpen ? Icons.expand_less : Icons.expand_more,
                                size: 20,
                              ),
                              const SizedBox(width: 6),
                              Text(
                                '${exts.length}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                      )
                    else
                      row(
                        Icons.extension_outlined,
                        tr('افزونه‌ها', 'Extensions'),
                        _openExtensions,
                      ),
                    if (extOpen) ...extRows,
                    if (!more)
                      row(
                        Icons.more_horiz,
                        tr('بیشتر', 'More'),
                        () => setS(() => more = true),
                        closeAfter: false,
                        trailing: Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: alpha(cs.onSurface, .12),
                          ),
                          child: const Icon(Icons.expand_more),
                        ),
                      )
                    else ...[
                      row(
                        Icons.translate,
                        tr('ترجمهٔ صفحه', 'Translate page'),
                        web
                            ? () => navigate(
                                  t,
                                  'https://translate.google.com/translate?sl=auto&tl=${app.lang}&u=${Uri.encodeComponent(t.url)}',
                                )
                            : null,
                      ),
                      row(
                        Icons.add_to_home_screen,
                        tr(
                          'افزودن برنامه به صفحهٔ اصلی',
                          'Add app to home screen',
                        ),
                        web ? () => _chooseHomeScreenMode(t) : null,
                      ),
                      row(
                        Icons.dashboard_customize_outlined,
                        tr('افزودن به صفحهٔ شروع', 'Add to start page'),
                        web ? () => _addToStartPage(t) : null,
                      ),
                      row(
                        Icons.chrome_reader_mode_outlined,
                        tr('حالت خواندن', 'Reader mode'),
                        page && !t.failed ? _toggleReader : null,
                      ),
                      row(
                        Icons.photo_camera_outlined,
                        tr('عکس از صفحه', 'Screenshot'),
                        page ? _takeScreenshot : null,
                      ),
                      row(
                        Icons.public,
                        tr(
                          'هویت Chrome برای این سایت',
                          'Chrome identity for this site',
                        ),
                        web && app.flag('chromeUa') ? _toggleChromeSite : null,
                      ),
                      row(
                        Icons.code,
                        tr('بازرسی المنت', 'Inspect element'),
                        page && !t.failed ? _inspectElement : null,
                      ),
                      row(
                        Icons.save_alt_outlined,
                        tr('دانلود صفحه (HTML)', 'Download page (HTML)'),
                        page && !t.failed
                            ? () => savePage(t, pdf: false)
                            : null,
                      ),
                      row(
                        Icons.picture_as_pdf_outlined,
                        tr('دانلود صفحه (PDF)', 'Download page (PDF)'),
                        page && !t.failed ? () => savePage(t, pdf: true) : null,
                      ),
                      row(
                        Icons.print_outlined,
                        tr('چاپ', 'Print'),
                        page && !t.failed
                            ? () async {
                                if (await gecko.call<bool>('print', {
                                      'id': t.nid,
                                    }) !=
                                    true)
                                  toast(tr('چاپ ممکن نشد', 'Could not print'));
                              }
                            : null,
                      ),
                      row(
                        Icons.link,
                        tr('کپی لینک', 'Copy link'),
                        page
                            ? () {
                                Clipboard.setData(ClipboardData(text: t.url));
                                toast(tr('لینک کپی شد', 'Link copied'));
                              }
                            : null,
                      ),
                      row(
                        Icons.shield_outlined,
                        tr('اطلاعات سایت', 'Site info'),
                        web ? _siteInfo : null,
                      ),
                    ],
                  ]),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      tile(
                        Icons.history_rounded,
                        tr('تاریخچه', 'History'),
                        _openHistory,
                        const BorderRadiusDirectional.only(
                          topStart: Radius.circular(22),
                          bottomStart: Radius.circular(22),
                          topEnd: Radius.circular(6),
                          bottomEnd: Radius.circular(6),
                        ),
                      ),
                      tile(
                        Icons.star_rounded,
                        tr('نشانک‌ها', 'Bookmarks'),
                        _openBookmarks,
                        BorderRadius.circular(6),
                      ),
                      tile(
                        Icons.download_rounded,
                        tr('بارگیری‌ها', 'Downloads'),
                        _openDownloads,
                        BorderRadius.circular(6),
                      ),
                      tile(
                        Icons.tab_rounded,
                        tr('تب‌ها', 'Tabs'),
                        _openSwitcher,
                        const BorderRadiusDirectional.only(
                          topEnd: Radius.circular(22),
                          bottomEnd: Radius.circular(22),
                          topStart: Radius.circular(6),
                          bottomStart: Radius.circular(6),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  grp([
                    row(
                      Icons.add_rounded,
                      tr('تب جدید', 'New tab'),
                      () => openTab(''),
                    ),
                    row(
                      Icons.visibility_off_outlined,
                      tr('تب خصوصی جدید', 'New private tab'),
                      () => openTab('', private: true),
                    ),
                    row(
                      Icons.delete_sweep_outlined,
                      tr('پاک‌سازی داده‌ها', 'Clear data'),
                      _openSettings,
                    ),
                    row(
                      Icons.settings_outlined,
                      tr('تنظیمات', 'Settings'),
                      _openSettings,
                    ),
                  ]),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  /// Per-site "Identify as Chrome": on <-> off for the current site, then reload so the site sees the new identity.
  Future<void> _toggleChromeSite() async {
    final t = current;
    final h = hostOf(t.url);
    if (h.isEmpty) return;
    final turnOn = !app.chromeOn(h);
    app.setChromeHost(h, on: turnOn);
    await gecko.call('apply', app.geckoSettings());
    gecko.call('reload', {'id': t.nid});
    toast(
      turnOn
          ? tr('هویت Chrome برای $h روشن شد', 'Chrome identity on for $h')
          : tr('هویت Chrome برای $h خاموش شد', 'Chrome identity off for $h'),
    );
  }

  /// One extension in the menu: tapping the row switches it on / off (the switch shows the state). The extension's own popup /
  /// options page opens from the small button (or a long press), for extensions that have one.
  Widget _extRow(ExtInfo e0, void Function(VoidCallback) run,
      {required double iconSize, required double fontSize, required EdgeInsetsGeometry pad, BorderRadius? r, Color? bg}) {
    return AnimatedBuilder(
      animation: extMgr,
      builder: (ctx, _) {
        final e = extMgr.list.where((x) => x.id == e0.id).firstOrNull ?? e0;
        final cs = Theme.of(ctx).colorScheme;
        final hasUi = e.enabled && (e.hasAction || e.optionsUrl != null);
        void openUi() => run(() async {
              if (e.hasAction && await extMgr.clickAction(e)) return;
              if (e.optionsUrl != null) {
                await extMgr.openOptions(e);
              } else {
                toast(tr('این افزونه رابط کاربری ندارد', 'This extension has no UI'));
              }
            });
        final row = InkWell(
          borderRadius: r,
          onTap: () => extMgr.setEnabled(e, !e.enabled),
          onLongPress: hasUi ? openUi : null,
          child: Padding(
            padding: pad,
            child: Row(children: [
              Opacity(opacity: e.enabled ? 1 : .4, child: extIcon(e, iconSize)),
              const SizedBox(width: 16),
              Expanded(
                child: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: fontSize, color: e.enabled ? null : cs.onSurface.withAlpha(120))),
              ),
              if (e.enabled && e.badge.isNotEmpty)
                Container(
                  margin: const EdgeInsets.only(left: 4, right: 4),
                  padding: const EdgeInsets.symmetric(horizontal: 5),
                  decoration: BoxDecoration(color: Colors.redAccent, borderRadius: BorderRadius.circular(8)),
                  child: Text(e.badge, style: const TextStyle(fontSize: 10, color: Colors.white)),
                ),
              if (hasUi)
                IconButton(
                  tooltip: tr('باز کردن افزونه', 'Open extension'),
                  visualDensity: VisualDensity.compact,
                  icon: Icon(Icons.open_in_new_rounded, size: 19, color: cs.onSurface.withAlpha(170)),
                  onPressed: openUi,
                ),
              Switch(value: e.enabled, onChanged: (v) => extMgr.setEnabled(e, v)),
            ]),
          ),
        );
        if (r == null) return row;
        return Padding(padding: const EdgeInsets.only(bottom: 2), child: Material(color: bg, borderRadius: r, child: row));
      },
    );
  }

  // ---------------- add to home screen / start page ----------------
  /// Real Android launcher shortcut that opens this page in Abtin.
  /// Lets the user pick between an installed web app (PWA, no browser UI) and a plain shortcut.
  Future<void> _chooseHomeScreenMode(BrowserTab t) async {
    final defTitle = t.displayTitle.isEmpty ? hostOf(t.url) : t.displayTitle;
    final nameCtl = TextEditingController(text: defTitle);
    final host = hostOf(t.url);
    final realPwa = t.hasSw && t.swHost == host;
    // mode: 'pwa' | 'shortcut' | 'start'
    final mode = await showGlassSheet<String>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        final cs = Theme.of(ctx).colorScheme;
        Widget option(String mode, IconData icon, Color color, String title, String sub, {String? badge}) => InkWell(
              onTap: () => Navigator.pop(ctx, mode),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Row(children: [
                  IconChip(icon, color, size: 48),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Row(children: [
                        Flexible(child: Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700))),
                        if (badge != null) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                            decoration: BoxDecoration(color: alpha(const Color(0xFF34C759), .18), borderRadius: BorderRadius.circular(8)),
                            child: Text(badge, style: const TextStyle(fontSize: 11, color: Color(0xFF34C759), fontWeight: FontWeight.w600)),
                          ),
                        ],
                      ]),
                      const SizedBox(height: 3),
                      Text(sub, style: TextStyle(fontSize: 12.5, height: 1.35, color: cs.onSurface.withAlpha(165))),
                    ]),
                  ),
                  Icon(Icons.chevron_right_rounded, color: cs.onSurface.withAlpha(120)),
                ]),
              ),
            );
        return SafeArea(
          child: Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
            child: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const SizedBox(height: 10),
                Container(width: 42, height: 4, decoration: BoxDecoration(color: cs.onSurface.withAlpha(60), borderRadius: BorderRadius.circular(8))),
                Padding(
                  padding: const EdgeInsets.fromLTRB(18, 16, 18, 4),
                  child: Row(children: [
                    SiteIcon(t.url, title: defTitle, size: 34),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(tr('افزودن به صفحهٔ اصلی گوشی', 'Add to home screen'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
                        Text(host, textDirection: TextDirection.ltr, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12, color: cs.onSurface.withAlpha(150))),
                      ]),
                    ),
                  ]),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 10, 16, 6),
                  child: TextField(
                    controller: nameCtl,
                    textInputAction: TextInputAction.done,
                    decoration: InputDecoration(
                      labelText: tr('نام زیر آیکن', 'Name under the icon'),
                      prefixIcon: const Icon(Icons.edit_rounded, size: 20),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
                      isDense: true,
                    ),
                  ),
                ),
                option('pwa', Icons.install_mobile_rounded, const Color(0xFF1687F8),
                    tr('نصب به‌عنوان برنامه', 'Install as an app'),
                    tr('در پنجرهٔ جدا و تمام‌صفحه، بدون نوار آدرس و تب‌ها باز می‌شود؛ مثل یک برنامهٔ واقعی',
                        'Opens in its own full-screen window, without address bar or tabs, like a real app'),
                    badge: realPwa ? tr('PWA واقعی', 'Real PWA') : null),
                option('shortcut', Icons.bookmark_add_rounded, const Color(0xFF7357D8),
                    tr('میان‌بر مرورگر', 'Browser shortcut'),
                    tr('آیکن و نام روی صفحهٔ اصلی؛ صفحه در یک تب معمولی آبتین باز می‌شود',
                        'Icon and name on the home screen; the page opens in a normal Abtin tab')),
                option('start', Icons.dashboard_customize_rounded, const Color(0xFFF59E0B),
                    tr('صفحهٔ شروع آبتین', 'Abtin start page'),
                    tr('فقط به شبکهٔ میان‌برهای صفحهٔ شروع مرورگر افزوده می‌شود',
                        'Only added to the speed-dial grid on the browser start page')),
                const SizedBox(height: 10),
              ]),
            ),
          ),
        );
      },
    );
    final name = nameCtl.text.trim();
    nameCtl.dispose();
    if (mode == null) return;
    if (mode == 'start') {
      _addToStartPage(t, name: name.isEmpty ? null : name);
      return;
    }
    await _pinToHomeScreen(t, pwa: mode == 'pwa', customName: name.isEmpty || name == defTitle ? null : name);
  }

  Future<void> _pinToHomeScreen(BrowserTab t, {bool pwa = false, String? customName}) async {
    var title = customName ?? (t.displayTitle.isEmpty ? hostOf(t.url) : t.displayTitle);
    toast(tr('در حال آماده‌سازی آیکن…', 'Preparing the icon…'));
    // 1) what is at hand: the tab's icon, then the icon remembered for this site
    Uint8List? small;
    final fav = t.faviconUrl ?? app.faviconFor(t.url);
    if (fav != null && fav.startsWith('data:image')) {
      try {
        small = base64Decode(fav.substring(fav.indexOf(',') + 1));
      } catch (_) {}
    } else if (fav != null && fav.startsWith('http')) {
      small = await _fetchIcon(fav);
    }
    // 2) the site's own best icon (manifest, apple-touch-icon, sized icons, defaults); a small favicon is only the fallback
    _siteManifestOk = false;
    _siteIconMaskable = false;
    _siteStartUrl = null;
    _siteManifestName = null;
    final big = await _bestSiteIcon(t.url);
    if (pwa &&
        customName == null &&
        _siteManifestName != null &&
        _siteManifestName!.trim().isNotEmpty) title = _siteManifestName!.trim();
    // The tab icon is now rasterized by Gecko at 512px (including SVG manifest icons).
    // Do not replace it with a smaller PNG/ICO fallback returned by the direct HTTP probe.
    Future<int> resolution(Uint8List? bytes) async {
      if (bytes == null || bytes.isEmpty) return 0;
      try {
        final codec = await dui.instantiateImageCodec(bytes);
        final frame = await codec.getNextFrame();
        final result = frame.image.width < frame.image.height
            ? frame.image.width : frame.image.height;
        frame.image.dispose();
        codec.dispose();
        return result;
      } catch (_) { return 0; }
    }
    final smallSize = await resolution(small);
    final bigSize = await resolution(big);
    final useSmall = small != null && (big == null || smallSize > bigSize);
    final icon = useSmall ? small : big;
    final maskable = !useSmall && big != null && _siteIconMaskable;
    // A real PWA has a web manifest AND a service worker; anything else is only a web shortcut shown in its own window.
    final manifest = pwa && _siteManifestOk;
    final sw = pwa && t.swHost == hostOf(t.url) && t.hasSw;
    final real = manifest && sw;
    if (!mounted) return;
    // The installed app opens at the manifest's start_url (like Chrome), not at whatever page this tab happens to show.
    var url = t.url;
    if (pwa && manifest && _siteStartUrl != null) {
      final su = Uri.tryParse(_siteStartUrl!), cu = Uri.tryParse(t.url);
      if (su != null &&
          cu != null &&
          su.scheme.startsWith('http') &&
          su.host == cu.host) url = su.toString();
    }
    final r = await gecko.call<String>('pinShortcut', {
      'title': title,
      'url': url,
      'icon': icon,
      'pwa': pwa,
      'real': real,
      'manifest': manifest,
      'sw': sw,
      'maskable': maskable,
    });
    switch (r) {
      case 'ok':
        break;
      case 'exists':
        toast(
          tr(
            'این سایت قبلاً نصب شده است؛ نام و آیکن به‌روز شد',
            'This site is already installed: name and icon updated',
          ),
        );
        break;
      case 'unsupported':
        toast(
          tr(
            'لانچر گوشی افزودن میان‌بر را پشتیبانی نمی‌کند',
            'Your launcher does not support pinned shortcuts',
          ),
        );
        break;
      case 'refused':
        toast(
          tr(
            'سیستم درخواست را نپذیرفت. در تنظیمات برنامه › مجوزها، «ایجاد میان‌بر / Home screen shortcuts» را فعال کنید',
            'The system refused the request. In app settings › permissions, allow “Home screen shortcuts”',
          ),
        );
        break;
      default:
        toast(
          '${tr('نصب ناموفق بود', 'Install failed')}${(r ?? '').startsWith('error:') ? ' (${r!.substring(6)})' : ''}',
        );
    }
  }

  Future<Uint8List?> _fetchIcon(String url) async {
    try {
      final r = await _dio.get<List<int>>(
        url,
        options: Options(
          responseType: ResponseType.bytes,
          receiveTimeout: const Duration(seconds: 3),
          sendTimeout: const Duration(seconds: 3),
        ),
      );
      if (r.data != null && r.data!.isNotEmpty)
        return Uint8List.fromList(r.data!);
    } catch (_) {}
    return null;
  }

  /// Best usable icon of the site, in the order Chrome uses for installed web apps: manifest icons (maskable first: they are
  /// full-bleed and look sharp in the launcher), apple-touch-icons, `<link rel=icon sizes>`, then /apple-touch-icon.png and
  /// /favicon.ico. PNG / JPEG / WebP / ICO only (no SVG). The top candidates are downloaded at the same time (4 s each, 9 s in all)
  /// and checked (decodes, size), so a blocked or slow icon never holds the install for long. Also sets [_siteManifestOk],
  /// [_siteIconMaskable] and [_siteStartUrl].
  Future<Uint8List?> _bestSiteIcon(String pageUrl) async {
    try {
      return await _bestSiteIconRun(pageUrl)
          .timeout(const Duration(seconds: 16), onTimeout: () => null);
    } catch (_) {
      return null;
    }
  }

  Future<Uint8List?> _bestSiteIconRun(String pageUrl) async {
    final base = Uri.tryParse(pageUrl);
    if (base == null || !base.scheme.startsWith('http')) return null;
    final opt = Options(
      responseType: ResponseType.bytes,
      receiveTimeout: const Duration(seconds: 4),
      sendTimeout: const Duration(seconds: 4),
      followRedirects: true,
      // Many sites refuse requests that do not look like a browser.
      headers: {
        'User-Agent':
            'Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36',
        'Accept': '*/*',
      },
    );
    final cands = <(int, Uri, bool)>[]; // (priority, url, maskable)
    int sizeOf(String? s) {
      if (s == null) return 0;
      var best = 0;
      for (final m in RegExp(r'(\d+)\s*[xX]\s*(\d+)').allMatches(s)) {
        final v = int.parse(m.group(1)!);
        if (v > best) best = v;
      }
      return best;
    }

    bool okUrl(Uri u) {
      final p = u.path.toLowerCase();
      return u.scheme.startsWith('http') && !p.endsWith('.svg');
    }

    try {
      final r = await _dio.get<List<int>>(pageUrl, options: opt);
      final html = utf8.decode(r.data ?? const [], allowMalformed: true);
      final manifestCandidates = <Uri>[];
      for (final m in RegExp(
        r'<link\b[^>]*>',
        caseSensitive: false,
      ).allMatches(html)) {
        final tag = m.group(0)!;
        String? attr(String n) {
          final x = RegExp(
            n + r'''\s*=\s*("([^"]*)"|'([^']*)'|([^\s>]+))''',
            caseSensitive: false,
          ).firstMatch(tag);
          return x == null ? null : (x.group(2) ?? x.group(3) ?? x.group(4));
        }

        final rel = (attr('rel') ?? '').toLowerCase();
        final href = attr('href');
        if (rel.contains('manifest')) {
          if (href != null && href.isNotEmpty)
            manifestCandidates.add(base.resolve(href.replaceAll('&amp;', '&')));
          else
            manifestCandidates.add(base.resolve('site.webmanifest'));
          continue;
        }
        if (href == null || href.isEmpty) continue;
        final u = base.resolve(href.replaceAll('&amp;', '&'));
        if (!rel.contains('icon')) continue;
        if (!okUrl(u) || (attr('type') ?? '').contains('svg')) continue;
        final sz = sizeOf(attr('sizes'));
        // apple-touch-icon is 180 px by default and has no transparent padding of its own
        cands.add((rel.contains('apple') ? (sz > 0 ? sz : 180) : sz, u, false));
      }
      final origin = base.replace(path: '', query: '', fragment: '');
      // Probe common manifest locations even if the page's app bundle assigns link[rel=manifest] at runtime.
      manifestCandidates.addAll([
        base.resolve('manifest.webmanifest'),
        base.resolve('manifest.json'),
        origin.resolve('/site.webmanifest'),
        origin.resolve('/manifest.webmanifest'),
        origin.resolve('/manifest.json'),
      ]);
      final seenManifests = <String>{};
      Uri? manifest;
      Map? manifestData;
      final uniqueCandidates = manifestCandidates
          .where((candidate) => seenManifests.add(candidate.toString()))
          .toList();
      final probes = await Future.wait(
        uniqueCandidates.map<Future<(Uri, Map)?>>((candidate) async {
          try {
            final mr = await _dio.get<List<int>>(
              candidate.toString(),
              options: opt,
            );
            final j = jsonDecode(
              utf8.decode(mr.data ?? const [], allowMalformed: true),
            );
            if (j is Map &&
                (j['icons'] is List ||
                    j['name'] != null ||
                    j['short_name'] != null ||
                    j['start_url'] != null ||
                    j['display'] != null)) {
              return (candidate, j);
            }
          } catch (_) {}
          return null;
        }),
      );
      for (final result in probes) {
        if (result != null) {
          manifest = result.$1;
          manifestData = result.$2;
          break;
        }
      }
      if (manifest != null && manifestData is Map) {
        final j = manifestData;
        _siteManifestOk = true;
        final name = j['name'] ?? j['short_name'];
        if (name is String && name.trim().isNotEmpty)
          _siteManifestName = name.trim();
        if (j['start_url'] is String && '${j['start_url']}'.isNotEmpty)
          _siteStartUrl = manifest.resolve('${j['start_url']}').toString();
        if (j['icons'] is List) {
          for (final i in j['icons'] as List) {
            if (i is! Map || i['src'] == null) continue;
            final purpose = '${i['purpose'] ?? 'any'}'.toLowerCase();
            final mask = purpose.contains('maskable');
            final u = manifest.resolve('${i['src']}');
            if (!okUrl(u) || '${i['type'] ?? ''}'.contains('svg')) continue;
            final s = sizeOf('${i['sizes'] ?? ''}');
            // Prefer the sharpest available source first; use maskable only as a tie-breaker at equal resolution.
            final pr = s * 10 + (mask ? 5 : 0);
            cands.add((pr, u, mask));
          }
        }
      }
    } catch (_) {}
    // Well-known default locations: sites without any <link rel=icon> / manifest still serve these.
    final origin = base.replace(path: '', query: '', fragment: '');
    cands.add((180, origin.resolve('/apple-touch-icon.png'), false));
    cands.add((
      179,
      origin.resolve('/apple-touch-icon-precomposed.png'),
      false,
    ));
    cands.add((1, origin.resolve('/favicon.ico'), false));
    cands.sort((a, b) => b.$1.compareTo(a.$1));
    final seen = <String>{};
    final list = <(int, Uri, bool)>[];
    for (final c in cands) {
      if (seen.add(c.$2.toString())) list.add(c);
      if (list.length >= 6) break;
    }

    // download the candidates together; keep the order of the priority list
    final got = await Future.wait(
      list.map<Future<(Uint8List, int, bool)?>>((c) async {
        try {
          final r = await _dio.get<List<int>>(c.$2.toString(), options: opt);
          final d = r.data;
          final ct = (r.headers.value('content-type') ?? '').toLowerCase();
          // An HTML error page answered with 200 is not an icon.
          if (d == null ||
              d.length <= 100 ||
              d.length >= 4 * 1024 * 1024 ||
              ct.contains('text/html')) return null;
          final bytes = Uint8List.fromList(d);
          var dim = 0;
          try {
            final codec = await dui.instantiateImageCodec(bytes);
            final f = await codec.getNextFrame();
            dim =
                f.image.width < f.image.height ? f.image.width : f.image.height;
            f.image.dispose();
            codec.dispose();
          } catch (_) {
            dim = 1;
          } // e.g. .ico: Flutter cannot decode it, the phone's own decoder still can
          return (bytes, dim, c.$3);
        } catch (_) {
          return null;
        }
      }),
    );
    // first in priority order that is sharp enough (>= 128 px; a maskable one >= 96); otherwise the biggest we got
    (Uint8List, int, bool)? fallback;
    for (final g in got) {
      if (g == null) continue;
      if (g.$2 >= (g.$3 ? 96 : 128)) {
        _siteIconMaskable = g.$3;
        return g.$1;
      }
      if (fallback == null || g.$2 > fallback.$2) fallback = g;
    }
    if (fallback != null) {
      _siteIconMaskable = false;
      return fallback.$1;
    }
    return null;
  }

  /// Adds the page to the speed-dial grid on Abtin's start page.
  void _addToStartPage(BrowserTab t, {String? name}) {
    if (app.dials.any((d) => d.url == t.url)) {
      toast(tr('قبلاً در صفحهٔ شروع هست', 'Already on the start page'));
      return;
    }
    final title = name ?? (t.displayTitle.isEmpty ? hostOf(t.url) : t.displayTitle);
    setState(() => app.dials.add(SpeedDial(title, t.url)));
    app.saveDials();
    toast(tr('به صفحهٔ شروع افزوده شد', 'Added to the start page'));
  }

  // ---------------- site info ----------------
  void _siteInfo() {
    final t = current;
    final host = hostOf(t.url);
    showGlassSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, refresh) {
          Widget perm(String key, String label, IconData icon) => ListTile(
                dense: true,
                leading: Icon(icon),
                title: Text(label),
                trailing: DropdownButton<String>(
                  value: app.sitePerm(host, key),
                  underline: const SizedBox(),
                  items: [
                    DropdownMenuItem(
                      value: 'ask',
                      child: Text(tr('پرسیدن', 'Ask')),
                    ),
                    DropdownMenuItem(
                      value: 'allow',
                      child: Text(tr('اجازه', 'Allow')),
                    ),
                    DropdownMenuItem(
                      value: 'block',
                      child: Text(tr('مسدود', 'Block')),
                    ),
                  ],
                  onChanged: (v) {
                    app.setSitePerm(host, key, v!);
                    gecko.call('resetPermissions', {'host': host});
                    refresh(() {});
                  },
                ),
              );
          return SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    host,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                    textDirection: TextDirection.ltr,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Icon(
                        t.secure ? Icons.lock : Icons.lock_open,
                        size: 16,
                        color: t.secure
                            ? const Color(0xFF34C759)
                            : Colors.redAccent,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        t.secure
                            ? tr(
                                'اتصال امن (HTTPS)',
                                'Secure connection (HTTPS)',
                              )
                            : tr('اتصال ناامن', 'Connection is not secure'),
                      ),
                    ],
                  ),
                  const Divider(),
                  perm(
                    'camera',
                    tr('دوربین', 'Camera'),
                    Icons.videocam_outlined,
                  ),
                  perm(
                    'microphone',
                    tr('میکروفون', 'Microphone'),
                    Icons.mic_none,
                  ),
                  perm(
                    'geolocation',
                    tr('موقعیت مکانی', 'Location'),
                    Icons.location_on_outlined,
                  ),
                  if (t.blocked > 0)
                    ListTile(
                      dense: true,
                      leading: const Icon(Icons.shield_outlined),
                      title: Text(
                        '${tr('مسدودشده در این صفحه', 'Blocked on this page')}: ${t.blocked}',
                      ),
                    ),
                  const Divider(),
                  TextButton.icon(
                    onPressed: () {
                      Navigator.pop(ctx);
                      _push(SiteSettingsPage(host: host));
                    },
                    icon: const Icon(Icons.tune),
                    label: Text(tr('تنظیمات این سایت', 'Site settings')),
                  ),
                  TextButton.icon(
                    onPressed: () async {
                      await gecko.call('clearHost', {'host': host});
                      if (ctx.mounted) Navigator.pop(ctx);
                      toast(
                        tr(
                          'کوکی‌های این سایت پاک شد',
                          'Cookies for this site cleared',
                        ),
                      );
                    },
                    icon: const Icon(Icons.cookie_outlined),
                    label: Text(
                      tr(
                        'پاک کردن کوکی‌های این سایت',
                        'Clear cookies for this site',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // ---------------- link / image long-press ----------------
  void _hitMenu(BrowserTab t, Map<String, dynamic> r) {
    final link = r['link'] as String?;
    final src = r['src'] as String?;
    final type = (r['type'] as num?)?.toInt() ?? 0; // 1 image, 2 video, 3 audio
    final url = (link != null && link.isNotEmpty) ? link : (src ?? '');
    if (url.isEmpty) return;
    final isLink = link != null && link.isNotEmpty;
    final linkText = ((r['text'] as String?) ?? '').trim();
    final media = src != null && src.isNotEmpty && type > 0;
    final isImg = media && type == 1;
    showGlassSheet<void>(
      context: context,
      builder: (ctx) {
        Widget item(IconData i, String s, VoidCallback f) => ListTile(
              leading: Icon(i),
              title: Text(s),
              onTap: () {
                Navigator.pop(ctx);
                f();
              },
            );
        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.all(14),
                child: Text(
                  url,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  textDirection: TextDirection.ltr,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
              if (isLink)
                item(
                  Icons.open_in_new,
                  tr('باز کردن در تب جدید', 'Open in new tab'),
                  () => openTab(url, private: t.private),
                ),
              if (isLink)
                item(
                  Icons.visibility_off_outlined,
                  tr('باز کردن در تب خصوصی', 'Open in private tab'),
                  () => openTab(url, private: true),
                ),
              item(Icons.copy, tr('کپی نشانی', 'Copy address'), () {
                Clipboard.setData(ClipboardData(text: url));
                toast(tr('کپی شد', 'Copied'));
              }),
              if (isLink && linkText.isNotEmpty)
                item(
                  Icons.text_fields,
                  tr('کپی متن لینک', 'Copy link text'),
                  () {
                    Clipboard.setData(ClipboardData(text: linkText));
                    toast(tr('کپی شد', 'Copied'));
                  },
                ),
              if (media)
                item(
                  Icons.download_outlined,
                  isImg
                      ? tr('دانلود تصویر', 'Download image')
                      : tr('دانلود رسانه', 'Download media'),
                  () => dlMgr.start(src, referer: t.url, private: t.private),
                ),
              if (media && isLink)
                item(
                  Icons.copy,
                  tr('کپی نشانی رسانه', 'Copy media address'),
                  () {
                    Clipboard.setData(ClipboardData(text: src));
                    toast(tr('کپی شد', 'Copied'));
                  },
                ),
              if (isLink)
                item(
                  Icons.share_outlined,
                  tr('اشتراک‌گذاری', 'Share'),
                  () => Share.share(url),
                ),
            ],
          ),
        );
      },
    );
  }
}

/// Set by [_bestSiteIcon]: the page links a usable web app manifest.
bool _siteManifestOk = false;

/// Set by [_bestSiteIcon]: the icon it returned is a maskable one (drawn as an adaptive launcher icon).
bool _siteIconMaskable = false;

/// Set by [_bestSiteIcon]: the manifest's start_url (absolute), the page an installed web app opens.
String? _siteStartUrl;

/// Set by [_bestSiteIcon]: the app label declared in its manifest.
String? _siteManifestName;
