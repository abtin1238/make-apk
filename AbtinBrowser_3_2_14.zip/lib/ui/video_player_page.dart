import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';
import 'package:wakelock_plus/wakelock_plus.dart';
import '../app_state.dart';
import 'package:file_picker/file_picker.dart';
import '../services.dart';
import '../engine/subtitles.dart';

const _videoExt = {'mp4', 'm4v', 'webm', 'mkv', 'mov', '3gp', 'avi', 'ts', 'm3u8'};
const _audioExt = {'mp3', 'm4a', 'aac', 'ogg', 'oga', 'opus', 'flac', 'wav', 'weba'};

bool isPlayableFile(String path) {
  final dot = path.lastIndexOf('.');
  if (dot < 0) return false;
  final e = path.substring(dot + 1).toLowerCase();
  return _videoExt.contains(e) || _audioExt.contains(e);
}

/// Full-screen player. Gestures: tap = controls, double-tap sides = -/+10s, horizontal drag = scrub,
/// vertical drag (right = volume, left = brightness), long-press = 2x speed.
class PlayerPage extends StatefulWidget {
  const PlayerPage({super.key, this.url, this.file, required this.title, this.headers = const {}, this.hls = false});
  final String? url, file;
  final bool hls;
  final String title;
  final Map<String, String> headers;

  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  // video_player's Android ExoPlayer release is asynchronous. When users close one
  // stream and immediately open another, creating the next ExoPlayer before the old
  // platform player is released can leave the second item stuck on some devices.
  static Future<void> _previousControllerRelease = Future<void>.value();
  late final VideoPlayerController c;
  bool ready = false, show = true, locked = false, landscape = false, looping = false, muted = false;
  String? error;
  double speed = 1, vol = 1, dim = 1;
  BoxFit fit = BoxFit.contain;
  Timer? _hideT, _hudT;
  Duration? _dragPos;
  String? _hud;
  double _doubleTapX = 0, _dragStartX = 0;
  double _speedBefore = 1;
  List<SubCue> _subs = [];
  String? _subName;

  @override
  void initState() {
    super.initState();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    // The dedicated full-screen player always opens in landscape, even for portrait videos.
    _setLandscape(true);
    WakelockPlus.enable();
    final u = widget.url ?? '';
    final isHls = widget.hls || u.split('#').first.split('?').first.toLowerCase().endsWith('.m3u8');
    c = widget.file != null
        ? VideoPlayerController.file(File(_safePath(widget.file!)))
        : VideoPlayerController.networkUrl(Uri.parse(u), httpHeaders: widget.headers, formatHint: isHls ? VideoFormat.hls : null);
    c.addListener(_tick);
    _init();
    _autoSub();
  }

  /// Looks next to a local video for movie.srt / movie.fa.srt / movie.vtt ...
  Future<void> _autoSub() async {
    final f = widget.file;
    if (f == null) return;
    final dot = f.lastIndexOf('.');
    if (dot < 0) return;
    final base = f.substring(0, dot);
    for (final suf in const ['.fa.srt', '.fa.vtt', '.per.srt', '.srt', '.vtt', '.fa.SRT', '.SRT', '.VTT']) {
      final sf = File('$base$suf');
      try {
        if (await sf.exists()) { await _loadSub(sf.path); return; }
      } catch (_) {}
    }
  }

  Future<void> _loadSub(String path) async {
    try {
      final cues = parseSubtitles(decodeSubtitleBytes(await File(path).readAsBytes()));
      if (!mounted) return;
      setState(() { _subs = cues; _subName = path.split('/').last; });
      if (cues.isEmpty) _flash(tr('زیرنویس خالی یا نامعتبر است', 'Subtitle file is empty or invalid'));
    } catch (_) {
      if (mounted) _flash(tr('خواندن زیرنویس ممکن نشد', 'Could not read the subtitle'));
    }
  }

  Future<void> _pickSub() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    final p = r?.files.single.path;
    if (p != null) await _loadSub(p);
  }

  /// ExoPlayer can fail on paths with Persian / non-ASCII letters or characters like # % ? in the name.
  /// For such files we play through an ASCII-named symlink in the app cache (no copy, instant).
  String _safePath(String path) {
    final name = path.split('/').last;
    if (RegExp(r'^[A-Za-z0-9._ \-]+$').hasMatch(name)) return path;
    try {
      final dot = name.lastIndexOf('.');
      final ext = dot >= 0 && name.length - dot <= 6 ? name.substring(dot).replaceAll(RegExp(r'[^A-Za-z0-9.]'), '') : '';
      final dir = Directory('${Directory.systemTemp.path}/abtin_play')..createSync(recursive: true);
      final link = Link('${dir.path}/v${path.hashCode.abs()}$ext');
      if (link.existsSync()) link.deleteSync();
      link.createSync(path);
      return link.path;
    } catch (_) {
      return path;
    }
  }

  /// Checks a downloaded file first (empty file / saved web page instead of a video) so the error is clear.
  Future<String?> _checkFile() async {
    final f = File(widget.file!);
    try {
      if (!await f.exists()) return tr('فایل پیدا نشد؛ شاید حذف یا جابه‌جا شده.', 'File not found; it may have been moved or deleted.');
      final len = await f.length();
      if (len < 1024) return tr('فایل دانلودشده خالی یا ناقص است. دوباره دانلود کنید.', 'The downloaded file is empty or incomplete. Download it again.');
      final raf = await f.open();
      final head = await raf.read(64);
      await raf.close();
      final t = String.fromCharCodes(head.map((b) => b < 9 || b > 126 ? 0x2e : b)).trimLeft().toLowerCase();
      if (t.startsWith('<') || t.startsWith('{') || t.startsWith('[') || t.startsWith('#extm3u')) {
        return t.startsWith('#extm3u')
            ? tr('این فایل یک لیست پخش (m3u8) است نه ویدیو. از دانلود HLS استفاده کنید.', 'This file is a playlist (m3u8), not a video. Use the HLS download.')
            : tr('سرور به‌جای ویدیو یک صفحهٔ وب برگرداند (لینک منقضی یا نیازمند ورود). دوباره از خود صفحه دانلود کنید.', 'The server returned a web page instead of the video (expired link or login needed). Download it again from the page.');
      }
    } catch (_) {}
    return null;
  }

  Future<void> _init() async {
    // Serialize native player teardown/creation across consecutive PlayerPage routes.
    try { await _previousControllerRelease; } catch (_) {}
    if (!mounted) return;
    if (widget.file != null) {
      final bad = await _checkFile();
      if (bad != null) {
        if (mounted) setState(() => error = bad);
        return;
      }
    }
    try {
      await c.initialize();
      if (!mounted) return;
      final s = c.value.size;
      setState(() => ready = true);
      if (s.width > s.height) _setLandscape(true);
      await c.play();
      _autoHide();
    } catch (e) {
      if (mounted) setState(() => error = widget.file != null ? tr('پخش این فایل با پلیر داخلی ممکن نشد؛ با برنامهٔ دیگر باز کنید.', 'The built-in player could not play this file; open it with another app.') : '$e');
    }
  }

  void _tick() {
    if (!mounted) return;
    if (c.value.hasError && error == null) {
      error = widget.file != null ? tr('پخش این فایل با پلیر داخلی ممکن نشد؛ با برنامهٔ دیگر باز کنید.', 'The built-in player could not play this file; open it with another app.') : (c.value.errorDescription ?? 'error');
    }
    setState(() {});
  }

  @override
  void dispose() {
    _hideT?.cancel();
    _hudT?.cancel();
    c.removeListener(_tick);
    _previousControllerRelease = c.dispose();
    WakelockPlus.disable();
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
    SystemChrome.setPreferredOrientations(DeviceOrientation.values);
    super.dispose();
  }

  void _setLandscape(bool on) {
    landscape = on;
    SystemChrome.setPreferredOrientations(on
        ? [DeviceOrientation.landscapeLeft, DeviceOrientation.landscapeRight]
        : [DeviceOrientation.portraitUp]);
    if (mounted) setState(() {});
  }

  void _autoHide() {
    _hideT?.cancel();
    if (!c.value.isPlaying) return;
    _hideT = Timer(const Duration(seconds: 3), () {
      if (mounted) setState(() => show = false);
    });
  }

  void _toggleControls() {
    setState(() => show = !show);
    if (show) _autoHide();
  }

  void _flash(String s) {
    _hudT?.cancel();
    setState(() => _hud = s);
    _hudT = Timer(const Duration(milliseconds: 900), () {
      if (mounted) setState(() => _hud = null);
    });
  }

  Future<void> _seekBy(int sec) async {
    final d = c.value.duration;
    var t = c.value.position + Duration(seconds: sec);
    if (t < Duration.zero) t = Duration.zero;
    if (t > d) t = d;
    await c.seekTo(t);
    _flash(sec > 0 ? '+${sec}s' : '${sec}s');
  }

  void _playPause() {
    if (c.value.isPlaying) {
      c.pause();
      _hideT?.cancel();
    } else {
      if (c.value.position >= c.value.duration && c.value.duration > Duration.zero) c.seekTo(Duration.zero);
      c.play();
      _autoHide();
    }
    setState(() {});
  }

  String _fmt(Duration d) {
    final h = d.inHours, m = d.inMinutes.remainder(60), s = d.inSeconds.remainder(60);
    final mm = m.toString().padLeft(2, '0'), ss = s.toString().padLeft(2, '0');
    return h > 0 ? '$h:$mm:$ss' : '$mm:$ss';
  }

  Future<void> _external() async {
    if (widget.file != null) {
      await dlMgr.openPath(widget.file!);
    } else if (widget.url != null) {
      await launchUrl(Uri.parse(widget.url!), mode: LaunchMode.externalApplication);
    }
  }

  Widget _btn(IconData i, VoidCallback f, {double size = 24, Color? color}) => IconButton(
        onPressed: f, icon: Icon(i, size: size, color: color ?? Colors.white), visualDensity: VisualDensity.compact,
      );

  @override
  Widget build(BuildContext context) {
    final v = c.value;
    final dur = v.duration.inMilliseconds.toDouble();
    final pos = (_dragPos ?? v.position).inMilliseconds.toDouble().clamp(0.0, dur > 0 ? dur : 1.0).toDouble();
    final isAudio = widget.file != null ? _audioExt.contains(widget.file!.split('.').last.toLowerCase()) : false;

    final video = ready && v.size.width > 0
        ? SizedBox.expand(
            child: FittedBox(
              fit: fit, clipBehavior: Clip.hardEdge,
              child: SizedBox(width: v.size.width, height: v.size.height, child: VideoPlayer(c)),
            ),
          )
        : const SizedBox.shrink();

    return Directionality(
      textDirection: TextDirection.ltr,
      child: PopScope(
        canPop: true,
        child: Scaffold(
          backgroundColor: Colors.black,
          body: LayoutBuilder(builder: (ctx, box) {
            return Stack(fit: StackFit.expand, children: [
              if (isAudio && ready) const Center(child: Icon(Icons.music_note_rounded, size: 120, color: Colors.white24)) else video,
              if (error != null)
                Center(
                  child: Padding(
                    padding: const EdgeInsets.all(28),
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.error_outline, color: Colors.redAccent, size: 48),
                      const SizedBox(height: 12),
                      Text(widget.file != null ? (error ?? '') : tr('پخش این ویدیو ممکن نشد (قالب پشتیبانی نمی‌شود یا لینک منقضی شده).', 'Could not play this video (unsupported format or expired link).'),
                          textAlign: TextAlign.center, style: const TextStyle(color: Colors.white)),
                      const SizedBox(height: 16),
                      Wrap(spacing: 10, children: [
                        FilledButton.tonal(onPressed: _external, child: Text(tr('باز کردن با برنامهٔ دیگر', 'Open with another app'))),
                        OutlinedButton(onPressed: () => Navigator.of(context).maybePop(), child: Text(tr('بازگشت', 'Back'))),
                      ]),
                    ]),
                  ),
                )
              else if (!ready)
                const Center(child: CircularProgressIndicator())
              else if (v.isBuffering)
                const Center(child: CircularProgressIndicator()),
              if (dim < 1) IgnorePointer(child: ColoredBox(color: Colors.black.withValues(alpha: 1 - dim))),

              // gesture layer
              if (error == null)
                Positioned.fill(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: _toggleControls,
                    onDoubleTapDown: locked ? null : (d) => _doubleTapX = d.localPosition.dx,
                    onDoubleTap: locked || !ready ? null : () => _seekBy(_doubleTapX < box.maxWidth / 2 ? -10 : 10),
                    onLongPressStart: locked || !ready ? null : (_) { _speedBefore = speed; c.setPlaybackSpeed(2); _flash('2x'); },
                    onLongPressEnd: locked || !ready ? null : (_) { c.setPlaybackSpeed(_speedBefore); },
                    onHorizontalDragStart: locked || !ready ? null : (d) { _dragPos = c.value.position; },
                    onHorizontalDragUpdate: locked || !ready ? null : (d) {
                      final total = c.value.duration.inMilliseconds;
                      final delta = (d.delta.dx / box.maxWidth * total * 0.25).round();
                      var t = (_dragPos ?? c.value.position).inMilliseconds + delta;
                      t = t.clamp(0, total);
                      setState(() => _dragPos = Duration(milliseconds: t));
                      _flash(_fmt(_dragPos!));
                    },
                    onHorizontalDragEnd: locked || !ready ? null : (_) {
                      final t = _dragPos;
                      _dragPos = null;
                      if (t != null) c.seekTo(t);
                    },
                    onVerticalDragStart: locked ? null : (d) => _dragStartX = d.localPosition.dx,
                    onVerticalDragUpdate: locked ? null : (d) {
                      final dy = -d.delta.dy / box.maxHeight * 1.4;
                      if (_dragStartX < box.maxWidth / 2) {
                        setState(() => dim = (dim + dy).clamp(0.08, 1.0));
                        _flash('${tr('روشنایی', 'Brightness')} ${(dim * 100).round()}%');
                      } else {
                        setState(() { vol = (vol + dy).clamp(0.0, 1.0); muted = vol == 0; });
                        c.setVolume(vol);
                        _flash('${tr('صدا', 'Volume')} ${(vol * 100).round()}%');
                      }
                    },
                  ),
                ),

              if (_hud != null)
                Center(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(14)),
                    child: Text(_hud!, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w600)),
                  ),
                ),

              // subtitles (Persian / RTL aware)
              if (_subs.isNotEmpty && ready)
                Builder(builder: (_) {
                  final cue = cueAt(_subs, v.position.inMilliseconds);
                  if (cue == null) return const SizedBox.shrink();
                  return Positioned(
                    left: 24, right: 24, bottom: show ? 96 : 28,
                    child: IgnorePointer(
                      child: Center(
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(8)),
                          child: Text(cue.text, textAlign: TextAlign.center,
                              textDirection: hasRtl(cue.text) ? TextDirection.rtl : TextDirection.ltr,
                              style: const TextStyle(color: Colors.white, fontSize: 17, height: 1.5, fontWeight: FontWeight.w600)),
                        ),
                      ),
                    ),
                  );
                }),

              // locked: only an unlock button
              if (locked)
                Positioned(
                  left: 0, right: 0, bottom: 28,
                  child: Center(
                    child: AnimatedOpacity(
                      opacity: show ? 1 : 0, duration: const Duration(milliseconds: 200),
                      child: IgnorePointer(
                        ignoring: !show,
                        child: FilledButton.tonalIcon(
                          onPressed: () { setState(() => locked = false); _autoHide(); },
                          icon: const Icon(Icons.lock_open), label: Text(tr('باز کردن قفل', 'Unlock')),
                        ),
                      ),
                    ),
                  ),
                )
              else
                Positioned.fill(
                  child: AnimatedOpacity(
                    opacity: show ? 1 : 0, duration: const Duration(milliseconds: 200),
                    child: IgnorePointer(
                      ignoring: !show,
                      child: Column(children: [
                        // top bar
                        Container(
                          decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.black87, Colors.transparent])),
                          padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top + 4, left: 4, right: 4, bottom: 18),
                          child: Row(children: [
                            _btn(Icons.arrow_back, () => Navigator.of(context).maybePop()),
                            Expanded(child: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: hasRtl(widget.title) ? TextDirection.rtl : TextDirection.ltr, textAlign: TextAlign.start, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600))),
                            PopupMenuButton<int>(
                              tooltip: tr('زیرنویس', 'Subtitles'),
                              icon: Icon(Icons.subtitles_outlined, color: _subs.isEmpty ? Colors.white : Theme.of(context).colorScheme.primary),
                              onSelected: (x) { if (x == 1) { _pickSub(); } else { setState(() { _subs = []; _subName = null; }); } },
                              itemBuilder: (_) => [
                                PopupMenuItem(value: 1, child: Text(tr('انتخاب فایل زیرنویس (srt / vtt)…', 'Choose subtitle file (srt / vtt)…'))),
                                if (_subs.isNotEmpty) PopupMenuItem(value: 0, child: Text('${tr('خاموش', 'Off')}  ($_subName)', maxLines: 1, overflow: TextOverflow.ellipsis)),
                              ],
                            ),
                            PopupMenuButton<double>(
                              tooltip: tr('سرعت', 'Speed'),
                              icon: const Icon(Icons.speed, color: Colors.white),
                              onSelected: (s) { setState(() => speed = s); c.setPlaybackSpeed(s); _flash('${s}x'); },
                              itemBuilder: (_) => [for (final s in const [0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0]) CheckedPopupMenuItem<double>(value: s, checked: s == speed, child: Text('${s}x'))],
                            ),
                            _btn(Icons.open_in_new, _external, size: 22),
                          ]),
                        ),
                        const Spacer(),
                        // centre controls
                        if (ready && error == null)
                          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                            _btn(Icons.replay_10_rounded, () => _seekBy(-10), size: 38),
                            const SizedBox(width: 22),
                            Container(
                              decoration: const BoxDecoration(color: Colors.black45, shape: BoxShape.circle),
                              child: _btn(v.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded, _playPause, size: 52),
                            ),
                            const SizedBox(width: 22),
                            _btn(Icons.forward_10_rounded, () => _seekBy(10), size: 38),
                          ]),
                        const Spacer(),
                        // bottom bar
                        Container(
                          decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.bottomCenter, end: Alignment.topCenter, colors: [Colors.black87, Colors.transparent])),
                          padding: EdgeInsets.only(bottom: MediaQuery.of(context).padding.bottom + 6, left: 10, right: 10, top: 18),
                          child: Column(mainAxisSize: MainAxisSize.min, children: [
                            Row(children: [
                              Text(_fmt(Duration(milliseconds: pos.round())), style: const TextStyle(color: Colors.white, fontSize: 12)),
                              Expanded(
                                child: SliderTheme(
                                  data: SliderTheme.of(context).copyWith(trackHeight: 3, thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7), overlayShape: const RoundSliderOverlayShape(overlayRadius: 14)),
                                  child: Slider(
                                    value: pos, min: 0, max: dur > 0 ? dur : 1,
                                    onChangeStart: (_) => _hideT?.cancel(),
                                    onChanged: ready ? (x) => setState(() => _dragPos = Duration(milliseconds: x.round())) : null,
                                    onChangeEnd: (x) async {
                                      await c.seekTo(Duration(milliseconds: x.round()));
                                      _dragPos = null;
                                      _autoHide();
                                    },
                                  ),
                                ),
                              ),
                              Text(_fmt(v.duration), style: const TextStyle(color: Colors.white, fontSize: 12)),
                            ]),
                            Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                              _btn(Icons.lock_outline, () => setState(() { locked = true; show = true; _autoHide(); }), size: 22),
                              _btn(looping ? Icons.repeat_one_rounded : Icons.repeat_rounded, () { setState(() => looping = !looping); c.setLooping(looping); _flash(looping ? tr('تکرار روشن', 'Loop on') : tr('تکرار خاموش', 'Loop off')); },
                                  size: 22, color: looping ? Theme.of(context).colorScheme.primary : Colors.white),
                              _btn(muted ? Icons.volume_off_rounded : Icons.volume_up_rounded, () {
                                setState(() => muted = !muted);
                                c.setVolume(muted ? 0 : (vol == 0 ? 1 : vol));
                                if (!muted && vol == 0) vol = 1;
                              }, size: 22),
                              _btn(
                                fit == BoxFit.contain ? Icons.fit_screen_rounded : fit == BoxFit.cover ? Icons.crop_free_rounded : Icons.aspect_ratio_rounded,
                                () {
                                  setState(() => fit = fit == BoxFit.contain ? BoxFit.cover : fit == BoxFit.cover ? BoxFit.fill : BoxFit.contain);
                                  _flash(fit == BoxFit.contain ? tr('اصلی', 'Fit') : fit == BoxFit.cover ? tr('پر کردن صفحه', 'Fill screen') : tr('کشیده', 'Stretch'));
                                },
                                size: 22,
                              ),
                              _btn(landscape ? Icons.screen_lock_portrait_outlined : Icons.screen_rotation_rounded, () => _setLandscape(!landscape), size: 22),
                            ]),
                          ]),
                        ),
                      ]),
                    ),
                  ),
                ),
            ]);
          }),
        ),
      ),
    );
  }
}
