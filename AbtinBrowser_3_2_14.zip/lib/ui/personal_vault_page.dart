import 'package:flutter/material.dart';

import '../app_state.dart';
import '../services.dart';

/// Encrypted on-device wallet for payment metadata and address profiles. CVV/CVC is never stored.
class PersonalVaultPage extends StatefulWidget {
  const PersonalVaultPage({super.key});
  @override
  State<PersonalVaultPage> createState() => _PersonalVaultPageState();
}

class _PersonalVaultPageState extends State<PersonalVaultPage> {
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;
  bool _unlocked = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final r = await gecko.call<List<dynamic>>('vaultList');
    if (!mounted) return;
    setState(() {
      _items = (r ?? const [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList();
      _unlocked = r != null;
      _loading = false;
    });
  }

  void _acceptList(dynamic r) {
    if (r is List) {
      setState(() {
        _items = r.map((e) => Map<String, dynamic>.from(e as Map)).toList();
        _unlocked = true;
      });
    }
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text), behavior: SnackBarBehavior.floating),
    );
  }

  Future<void> _edit({bool card = true, Map<String, dynamic>? item}) async {
    final values = <String, TextEditingController>{
      for (final key
          in (card
              ? const ['label', 'holder', 'number', 'expiry']
              : const [
                  'label',
                  'name',
                  'street',
                  'city',
                  'region',
                  'postal',
                  'country',
                  'phone',
                  'email',
                ]))
        key: TextEditingController(text: '${item?[key] ?? ''}'),
    };
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(
          card
              ? tr('ذخیرهٔ کارت بانکی', 'Save payment card')
              : tr('ذخیرهٔ نشانی', 'Save address'),
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _field(
                  values['label']!,
                  tr('نام دلخواه (مثلاً شخصی)', 'Label (e.g. Personal)'),
                ),
                if (card) ...[
                  _field(
                    values['holder']!,
                    tr('نام صاحب کارت', 'Cardholder name'),
                  ),
                  _field(
                    values['number']!,
                    tr('شمارهٔ کارت', 'Card number'),
                    keyboard: TextInputType.number,
                  ),
                  _field(
                    values['expiry']!,
                    tr('تاریخ انقضا (MM/YY)', 'Expiry (MM/YY)'),
                    keyboard: TextInputType.datetime,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(
                      tr(
                        'CVV ذخیره نمی‌شود. اطلاعات فقط رمزنگاری‌شده روی این گوشی نگهداری می‌شود.',
                        'CVV is not stored. Data is encrypted and kept only on this phone.',
                      ),
                      style: const TextStyle(fontSize: 12),
                    ),
                  ),
                ] else ...[
                  _field(values['name']!, tr('نام کامل', 'Full name')),
                  _field(
                    values['street']!,
                    tr('نشانی خیابان', 'Street address'),
                  ),
                  _field(values['city']!, tr('شهر', 'City')),
                  _field(
                    values['region']!,
                    tr('استان / منطقه', 'State / region'),
                  ),
                  _field(values['postal']!, tr('کد پستی', 'Postal code')),
                  _field(values['country']!, tr('کشور', 'Country')),
                  _field(
                    values['phone']!,
                    tr('تلفن', 'Phone'),
                    keyboard: TextInputType.phone,
                  ),
                  _field(
                    values['email']!,
                    tr('ایمیل', 'Email'),
                    keyboard: TextInputType.emailAddress,
                  ),
                ],
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(d, false),
            child: Text(tr('لغو', 'Cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.pop(d, true),
            child: Text(tr('ذخیره', 'Save')),
          ),
        ],
      ),
    );
    if (ok == true) {
      final fields = <String, dynamic>{'kind': card ? 'card' : 'address'};
      for (final e in values.entries) {
        fields[e.key] = e.value.text.trim();
      }
      final r = await gecko.call<dynamic>('vaultPut', {
        'id': item?['id'] ?? '',
        'fields': fields,
      });
      if (r is List) {
        _acceptList(r);
        _message(tr('با رمزنگاری ذخیره شد', 'Saved encrypted on this device'));
      } else {
        _message(
          card
              ? tr(
                  'اطلاعات کارت را بررسی کنید؛ شماره باید معتبر و تاریخ انقضا تکمیل باشد. CVV ذخیره نمی‌شود.',
                  'Check the card details: the number must be valid and expiry is required. CVV is not stored.',
                )
              : tr(
                  'نام و نشانی خیابان را وارد کنید.',
                  'Enter a name and street address.',
                ),
        );
      }
    }
    for (final c in values.values) {
      c.dispose();
    }
  }

  Widget _field(
    TextEditingController c,
    String label, {
    TextInputType? keyboard,
  }) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: TextField(
      controller: c,
      keyboardType: keyboard,
      decoration: InputDecoration(labelText: label, isDense: true),
    ),
  );

  Future<void> _remove(Map<String, dynamic> item) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('حذف مورد؟', 'Delete item?')),
        content: Text('${item['label'] ?? ''}'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(d, false),
            child: Text(tr('لغو', 'Cancel')),
          ),
          TextButton(
            onPressed: () => Navigator.pop(d, true),
            child: Text(tr('حذف', 'Delete')),
          ),
        ],
      ),
    );
    if (yes != true) return;
    _acceptList(await gecko.call<dynamic>('vaultDelete', {'id': item['id']}));
  }

  Future<void> _fill(Map<String, dynamic> item) async {
    final ok = await gecko.call<bool>('vaultFill', {'id': item['id']});
    _message(
      ok == true
          ? tr(
              'فیلدهای شناسایی‌شده پر شدند؛ پیش از ارسال صفحه را بررسی کنید.',
              'Matching fields were filled. Review the page before submitting.',
            )
          : tr(
              'صفحهٔ HTTPS باز نیست یا فیلد سازگاری پیدا نشد.',
              'No HTTPS page is open, or no matching fields were found.',
            ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cards = _items.where((x) => x['kind'] == 'card').toList();
    final addresses = _items.where((x) => x['kind'] == 'address').toList();
    return Scaffold(
      appBar: AppBar(
        title: Text(tr('کارت‌ها و نشانی‌ها', 'Cards & addresses')),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) => _edit(card: v == 'card'),
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'card',
                child: Text(tr('افزودن کارت', 'Add card')),
              ),
              PopupMenuItem(
                value: 'address',
                child: Text(tr('افزودن نشانی', 'Add address')),
              ),
            ],
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : !_unlocked
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  tr(
                    'برای دسترسی به کیف پول، اثر انگشت را تأیید کنید و دوباره وارد شوید.',
                    'Biometric verification is required to access the wallet. Reopen this page and try again.',
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : _items.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  tr(
                    'هنوز کارت یا نشانی ذخیره نشده است. از منوی بالا مورد جدید اضافه کنید.',
                    'No saved cards or addresses. Use the menu above to add one.',
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView(
              children: [
                if (cards.isNotEmpty)
                  _section(tr('کارت‌های بانکی', 'Payment cards')),
                for (final it in cards) _tile(it),
                if (addresses.isNotEmpty) _section(tr('نشانی‌ها', 'Addresses')),
                for (final it in addresses) _tile(it),
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    tr(
                      'داده‌ها رمزنگاری‌شده و محلی هستند. CVV ذخیره نمی‌شود؛ پرکردن فقط در صفحهٔ HTTPS و پس از اثر انگشت انجام می‌شود.',
                      'Data is encrypted and local. CVV is never stored; fill works only on HTTPS and requires biometric verification.',
                    ),
                    style: const TextStyle(fontSize: 12),
                  ),
                ),
              ],
            ),
    );
  }

  Widget _section(String title) => Padding(
    padding: const EdgeInsets.fromLTRB(16, 18, 16, 6),
    child: Text(
      title,
      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
    ),
  );

  Widget _tile(Map<String, dynamic> item) {
    final card = item['kind'] == 'card';
    final number = '${item['number'] ?? ''}';
    final subtitle = card
        ? '${item['holder'] ?? ''}  •••• ${number.length >= 4 ? number.substring(number.length - 4) : ''}  ${item['expiry'] ?? ''}'
        : [
            '${item['street'] ?? ''}',
            '${item['city'] ?? ''}',
            '${item['postal'] ?? ''}',
          ].where((s) => s.isNotEmpty).join(' · ');
    return ListTile(
      leading: Icon(
        card ? Icons.credit_card_rounded : Icons.location_on_outlined,
      ),
      title: Text(
        '${item['label'] ?? (card ? tr('کارت', 'Card') : tr('نشانی', 'Address'))}',
      ),
      subtitle: Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis),
      trailing: PopupMenuButton<String>(
        onSelected: (v) {
          if (v == 'fill')
            _fill(item);
          else if (v == 'edit')
            _edit(card: card, item: item);
          else if (v == 'delete')
            _remove(item);
        },
        itemBuilder: (_) => [
          PopupMenuItem(
            value: 'fill',
            child: Text(tr('پرکردن در سایت فعلی', 'Fill current site')),
          ),
          PopupMenuItem(value: 'edit', child: Text(tr('ویرایش', 'Edit'))),
          PopupMenuItem(value: 'delete', child: Text(tr('حذف', 'Delete'))),
        ],
      ),
    );
  }
}
