// ignore_for_file: invalid_use_of_protected_member
import 'dart:async';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import '../engine/ext_manager.dart';
import '../services.dart';
import '../app_state.dart';
import 'glass.dart';

Color _tintFor(String s) => HSLColor.fromAHSL(1, (s.hashCode.abs() % 360).toDouble(), .5, .4).toColor();

Widget _letterBox(String name, double size) => Container(
      width: size, height: size, alignment: Alignment.center,
      decoration: BoxDecoration(color: _tintFor(name), borderRadius: BorderRadius.circular(size / 4)),
      child: Text(name.isEmpty ? '?' : name.characters.first.toUpperCase(), style: TextStyle(color: Colors.white, fontSize: size * .5, fontWeight: FontWeight.bold)),
    );

Widget extIcon(ExtInfo e, double size) => ExtIconView(e, size, key: ValueKey('exticon_${e.id}_${e.icon?.length ?? 0}'));

/// Extension icon: the bytes from the engine, else the icon on addons.mozilla.org, else a coloured letter tile.
class ExtIconView extends StatefulWidget {
  const ExtIconView(this.e, this.size, {super.key});
  final ExtInfo e;
  final double size;
  @override
  State<ExtIconView> createState() => _ExtIconViewState();
}

class _ExtIconViewState extends State<ExtIconView> {
  String? _url;
  bool _bytesFailed = false;

  @override
  void initState() { super.initState(); _maybeLookup(); }

  void _maybeLookup() {
    if (widget.e.icon != null && !_bytesFailed) return;
    extMgr.amoIconUrl(widget.e).then((u) { if (mounted && u.isNotEmpty) setState(() => _url = u); });
  }

  @override
  Widget build(BuildContext context) {
    final e = widget.e, size = widget.size;
    final letter = _letterBox(e.name, size);
    Widget net() => _url == null
        ? letter
        : ClipRRect(borderRadius: BorderRadius.circular(size / 4), child: Image.network(_url!, width: size, height: size, errorBuilder: (_, __, ___) => letter));
    final b = e.icon;
    if (b == null || _bytesFailed) return net();
    return ClipRRect(
      borderRadius: BorderRadius.circular(size / 4),
      child: Image.memory(b, width: size, height: size, errorBuilder: (_, __, ___) {
        WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted && !_bytesFailed) { setState(() => _bytesFailed = true); _maybeLookup(); } });
        return letter;
      }),
    );
  }
}

class ExtensionsPage extends StatefulWidget {
  const ExtensionsPage({super.key, required this.host});
  final BrowserApi host;
  @override
  State<ExtensionsPage> createState() => _ExtensionsPageState();
}

class _ExtensionsPageState extends State<ExtensionsPage> {
  String cat = 'all', q = '';
  final busy = <String>{};
  List<AmoItem> found = [];
  bool searching = false;
  Timer? _searchT;

  @override
  void initState() { super.initState(); extMgr.addListener(_r); extMgr.refresh(); }
  @override
  void dispose() { extMgr.removeListener(_r); _searchT?.cancel(); super.dispose(); }
  void _r() { if (mounted) setState(() {}); }

  Future<void> _guard(String key, Future<String?> Function() f) async {
    setState(() => busy.add(key));
    String? err;
    try { err = await f(); } catch (e) { err = '$e'; }
    if (!mounted) return;
    setState(() => busy.remove(key));
    widget.host.toast(err == null ? tr('نصب شد', 'Installed') : '${tr('نصب ناموفق بود', 'Install failed')}: $err');
  }

  Future<void> _pickFile() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any, withData: false);
    final path = r?.files.single.path;
    if (path == null) return;
    await _guard('file', () => extMgr.installFile(path));
  }

  Future<void> _fromUrl() async {
    final ctl = TextEditingController();
    final ok = await showGlassDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('نصب از لینک', 'Install from link')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: ctl, textDirection: TextDirection.ltr, decoration: const InputDecoration(hintText: 'https://…')),
          const SizedBox(height: 8),
          Text(tr('لینک Chrome Web Store / Edge Add-ons (نسخهٔ Firefox همان افزونه نصب می‌شود)، لینک addons.mozilla.org یا .xpi امضاشده', 'Chrome Web Store / Edge Add-ons link (the Firefox build is installed), addons.mozilla.org link, or signed .xpi URL'), style: const TextStyle(fontSize: 12)),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('نصب', 'Install')))],
      ),
    );
    if (ok != true || ctl.text.trim().isEmpty) return;
    final input = ctl.text.trim();
    final isChrome = RegExp(r'chromewebstore\.google\.com|chrome\.google\.com/webstore|microsoftedge\.microsoft\.com|^[a-p]{32}$').hasMatch(input);
    if (!isChrome) {
      if (input.toLowerCase().contains('.crx')) { widget.host.toast(tr('فایل .crx روی Firefox اجرا نمی‌شود؛ لینک فروشگاه Chrome را بدهید', '.crx cannot run on Firefox; paste the Chrome Web Store link instead')); return; }
      await _guard('url', () => extMgr.installUrl(input));
      return;
    }
    setState(() => busy.add('url'));
    final hit = await extMgr.resolveChrome(input);
    if (!mounted) return;
    setState(() => busy.remove('url'));
    if (hit == null) { widget.host.toast(tr('معادل Firefox این افزونه پیدا نشد', 'No Firefox equivalent found for this extension')); return; }
    final go = await showGlassDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('نسخهٔ Firefox پیدا شد', 'Firefox version found')),
        content: Text(tr('افزونه‌های Chrome مستقیم اجرا نمی‌شوند. «${hit.name}» از Mozilla نصب شود؟\n${hit.summary}', 'Chrome extensions cannot run directly. Install "${hit.name}" from Mozilla instead?\n${hit.summary}')),
        actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('نصب', 'Install')))],
      ),
    );
    if (go == true) await _guard('url', () => extMgr.installUrl(hit.installUrl));
  }

  void _onQuery(String v) {
    setState(() => q = v);
    _searchT?.cancel();
    if (v.trim().length < 2) { setState(() { found = []; searching = false; }); return; }
    _searchT = Timer(const Duration(milliseconds: 450), () async {
      setState(() => searching = true);
      try {
        final r = await extMgr.searchAmo(v.trim());
        if (mounted && q == v) setState(() => found = r);
      } catch (_) {
        if (mounted) widget.host.toast(tr('جست‌وجو در addons.mozilla.org ناموفق بود', 'Search on addons.mozilla.org failed'));
      }
      if (mounted) setState(() => searching = false);
    });
  }

  static const _cats = {'all': ['همه', 'All'], 'privacy': ['حریم خصوصی', 'Privacy'], 'security': ['امنیت', 'Security'], 'tools': ['ابزارها', 'Tools'], 'appearance': ['ظاهر', 'Appearance']};

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final searchMode = q.trim().length >= 2;
    final items = catalog.where((c) => cat == 'all' || c.category == cat).toList();
    final installedNames = extMgr.list.map((e) => e.name.toLowerCase()).toSet();
    return GlassScaffold(
      appBar: AppBar(title: Text(tr('افزونه‌ها', 'Extensions')), actions: [
        IconButton(tooltip: tr('نصب از لینک', 'From link'), onPressed: busy.contains('url') ? null : _fromUrl, icon: const Icon(Icons.link)),
        IconButton(tooltip: tr('نصب از فایل', 'From file'), onPressed: busy.contains('file') ? null : _pickFile, icon: const Icon(Icons.upload_file)),
      ]),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        if (busy.isNotEmpty) const Padding(padding: EdgeInsets.only(bottom: 10), child: LinearProgressIndicator()),
        Text(tr('نصب‌شده', 'Installed'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 6),
        if (extMgr.list.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(tr('هنوز افزونه‌ای نصب نشده است.', 'No extensions installed yet.'))),
        for (final e in extMgr.list)
          GlassCard(
            margin: const EdgeInsets.symmetric(vertical: 4),
            child: ListTile(
              leading: extIcon(e, 40),
              title: Text(e.name, maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text('v${e.version}', style: const TextStyle(fontSize: 11)),
              trailing: Switch(value: e.enabled, onChanged: (v) => extMgr.setEnabled(e, v)),
              onTap: () => Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => ExtensionDetailPage(ext: e, host: widget.host))),
            ),
          ),
        const SizedBox(height: 18),
        Text(tr('فروشگاه افزونه‌ها (Mozilla Add-ons)', 'Extension store (Mozilla Add-ons)'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        TextField(onChanged: _onQuery, decoration: InputDecoration(hintText: tr('جست‌وجو در addons.mozilla.org', 'Search addons.mozilla.org'), prefixIcon: const Icon(Icons.search), filled: true, fillColor: Theme.of(context).cardColor, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none))),
        const SizedBox(height: 8),
        if (searchMode) ...[
          if (searching) const Padding(padding: EdgeInsets.all(12), child: Center(child: CircularProgressIndicator())),
          for (final a in found)
            GlassCard(
              margin: const EdgeInsets.symmetric(vertical: 4),
              child: ListTile(
                leading: a.iconUrl.isEmpty
                    ? _letterBox(a.name, 40)
                    : ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.network(a.iconUrl, width: 40, height: 40, errorBuilder: (_, __, ___) => _letterBox(a.name, 40))),
                title: Text(a.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text(a.summary, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                trailing: installedNames.contains(a.name.toLowerCase())
                    ? Icon(Icons.check_circle, color: cs.primary)
                    : busy.contains(a.slug)
                        ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                        : FilledButton(onPressed: () => _guard(a.slug, () => extMgr.installUrl(a.installUrl)), child: Text(tr('نصب', 'Install'))),
              ),
            ),
          if (!searching && found.isEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(tr('نتیجه‌ای پیدا نشد', 'No results'))),
        ] else ...[
          SizedBox(height: 40, child: ListView(scrollDirection: Axis.horizontal, children: [
            for (final c in _cats.entries) Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ChoiceChip(label: Text(tr(c.value[0], c.value[1])), selected: cat == c.key, onSelected: (_) => setState(() => cat = c.key))),
          ])),
          for (final c in items)
            GlassCard(
              margin: const EdgeInsets.symmetric(vertical: 4),
              child: ListTile(
                leading: _letterBox(c.name, 40),
                title: Text(c.name), subtitle: Text(tr(c.fa, c.en), maxLines: 1, overflow: TextOverflow.ellipsis),
                trailing: installedNames.contains(c.name.toLowerCase())
                    ? Icon(Icons.check_circle, color: cs.primary)
                    : busy.contains(c.slug)
                        ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
                        : FilledButton(onPressed: () => _guard(c.slug, () => extMgr.installCatalog(c)), child: Text(tr('نصب', 'Install'))),
              ),
            ),
        ],
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: cs.onSurface.withValues(alpha: .06), borderRadius: BorderRadius.circular(12)),
          child: Text(tr(
              'آبتین با موتور GeckoView (Firefox) افزونه‌های واقعی WebExtension را اجرا می‌کند، از جمله uBlock Origin با پشتیبانی کامل webRequest. فقط افزونه‌های امضاشدهٔ Mozilla نصب می‌شوند؛ فایل‌های Chrome (.crx) پشتیبانی نمی‌شوند.',
              'Abtin runs real WebExtensions on GeckoView (Firefox), including uBlock Origin with full blocking webRequest. Only Mozilla-signed add-ons install; Chrome .crx files are not supported.'),
              style: const TextStyle(fontSize: 12)),
        ),
      ]),
    );
  }
}

class ExtensionDetailPage extends StatefulWidget {
  const ExtensionDetailPage({super.key, required this.ext, required this.host});
  final ExtInfo ext;
  final BrowserApi host;
  @override
  State<ExtensionDetailPage> createState() => _ExtensionDetailPageState();
}

class _ExtensionDetailPageState extends State<ExtensionDetailPage> {
  @override
  void initState() { super.initState(); extMgr.addListener(_r); }
  @override
  void dispose() { extMgr.removeListener(_r); super.dispose(); }
  void _r() { if (mounted) setState(() {}); }

  ExtInfo get ext => extMgr.list.where((e) => e.id == widget.ext.id).firstOrNull ?? widget.ext;

  @override
  Widget build(BuildContext context) {
    final e = ext;
    Widget row(String k, String v) => Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(k), const SizedBox(width: 12), Flexible(child: Text(v, textDirection: TextDirection.ltr, overflow: TextOverflow.ellipsis))]));
    final perms = [...e.permissions, ...e.origins];
    return GlassScaffold(
      appBar: AppBar(title: Text(tr('جزئیات افزونه', 'Extension details'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [extIcon(e, 64), const SizedBox(width: 14), Expanded(child: Text(e.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)))]),
        const SizedBox(height: 12),
        if (e.description.isNotEmpty) Text(e.description),
        const Divider(height: 28),
        row(tr('نسخه', 'Version'), e.version),
        if (e.creator != null && e.creator!.isNotEmpty) row(tr('سازنده', 'Author'), e.creator!),
        row(tr('شناسه', 'ID'), e.id),
        SwitchListTile(contentPadding: EdgeInsets.zero, value: e.enabled, onChanged: (v) => extMgr.setEnabled(e, v), title: Text(tr('فعال', 'Enabled'))),
        SwitchListTile(contentPadding: EdgeInsets.zero, value: e.privateAllowed, onChanged: (v) => extMgr.setPrivate(e, v), title: Text(tr('اجرا در تب خصوصی', 'Run in private tabs'))),
        const Divider(height: 28),
        Text(tr('مجوزها', 'Permissions'), style: const TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 6),
        perms.isEmpty ? Text(tr('بدون مجوز ویژه', 'No special permissions')) : Wrap(spacing: 6, runSpacing: 6, children: [for (final p in perms.take(40)) Chip(label: Text(p, style: const TextStyle(fontSize: 11), textDirection: TextDirection.ltr), visualDensity: VisualDensity.compact)]),
        const SizedBox(height: 18),
        Wrap(spacing: 10, runSpacing: 8, children: [
          if (e.hasAction) FilledButton.icon(onPressed: () async { Navigator.of(context).popUntil((r) => r.isFirst); await extMgr.clickAction(e); }, icon: const Icon(Icons.open_in_new), label: Text(tr('باز کردن', 'Open'))),
          if (e.optionsUrl != null) OutlinedButton.icon(onPressed: () async { Navigator.of(context).popUntil((r) => r.isFirst); await extMgr.openOptions(e); }, icon: const Icon(Icons.tune), label: Text(tr('گزینه‌ها', 'Options'))),
          OutlinedButton.icon(onPressed: () async { await extMgr.update(e); widget.host.toast(tr('بررسی به‌روزرسانی انجام شد', 'Update check done')); }, icon: const Icon(Icons.system_update_alt), label: Text(tr('به‌روزرسانی', 'Update'))),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(foregroundColor: Colors.redAccent),
            onPressed: () async { await extMgr.remove(e); if (context.mounted) Navigator.pop(context); },
            icon: const Icon(Icons.delete_outline), label: Text(tr('حذف', 'Remove')),
          ),
        ]),
      ]),
    );
  }
}
