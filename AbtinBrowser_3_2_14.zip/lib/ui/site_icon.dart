import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import '../models.dart';
import '../services.dart';

final _siteFavBytes = <String, Uint8List>{};

Color _siteTint(String s) => HSLColor.fromAHSL(1, (s.hashCode.abs() % 360).toDouble(), .70, .50).toColor();

Widget siteLetter(String s, double size) => Container(
      width: size, height: size, alignment: Alignment.center,
      decoration: BoxDecoration(color: _siteTint(s), borderRadius: BorderRadius.circular(size / 3)),
      child: Text(s.isEmpty ? '?' : s.characters.first.toUpperCase(), style: TextStyle(color: Colors.white, fontSize: size * .6, fontWeight: FontWeight.bold)),
    );

/// Favicon from a data: URI or http URL; falls back to a coloured letter.
Widget siteIconFrom(String f, String title, double size) {
  Widget err(BuildContext _, Object __, StackTrace? ___) => siteLetter(title, size);
  final r = BorderRadius.circular(size * .22);
  if (f.startsWith('data:image')) {
    Uint8List? b = _siteFavBytes[f];
    if (b == null) {
      try { b = base64Decode(f.substring(f.indexOf(',') + 1)); } catch (_) { return siteLetter(title, size); }
      if (_siteFavBytes.length > 200) _siteFavBytes.clear();
      _siteFavBytes[f] = b;
    }
    return ClipRRect(borderRadius: r, child: Image.memory(b, width: size, height: size, cacheWidth: (size * 3).round(), gaplessPlayback: true, errorBuilder: err));
  }
  return ClipRRect(borderRadius: r, child: Image.network(f, width: size, height: size, gaplessPlayback: true, errorBuilder: err));
}

/// Site icon for a URL on a light tile: remembered favicon, else /favicon.ico, else a letter.
/// Used by the start page (speed dials, most visited), history and bookmarks.
class SiteIcon extends StatelessWidget {
  const SiteIcon(this.url, {super.key, this.title = '', this.size = 36});
  final String url, title;
  final double size;

  @override
  Widget build(BuildContext context) {
    final host = hostOf(url);
    final label = title.isEmpty ? host : title;
    final f = app.faviconFor(url) ?? (host.isEmpty ? null : 'https://$host/favicon.ico');
    return Container(
      width: size, height: size, alignment: Alignment.center,
      decoration: BoxDecoration(color: Colors.white.withValues(alpha: .92), borderRadius: BorderRadius.circular(size * .3)),
      padding: EdgeInsets.all(size * .16),
      child: f == null ? siteLetter(label, size) : siteIconFrom(f, label, size),
    );
  }
}
