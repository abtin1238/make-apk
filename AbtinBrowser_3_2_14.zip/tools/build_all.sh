#!/usr/bin/env bash
# Builds one APK per CPU and zips each one separately (max compression): dist/AbtinBrowser-<version>-<abi>.zip
set -euo pipefail
cd "$(dirname "$0")/.."
ver=$(grep -m1 '^version:' pubspec.yaml | sed 's/version: *//; s/+.*//')
mkdir -p dist
flutter pub get
for pair in "arm64-v8a android-arm64" "armeabi-v7a android-arm" "x86_64 android-x64"; do
  set -- $pair; abi=$1; plat=$2
  flutter build apk --release --split-per-abi --target-platform "$plat" --split-debug-info=build/symbols
  name="AbtinBrowser-$ver-$abi"
  tmp=$(mktemp -d)
  cp "build/app/outputs/flutter-apk/app-$abi-release.apk" "$tmp/$name.apk"
  rm -f "dist/$name.zip"
  (cd "$tmp" && zip -9 -X "$OLDPWD/dist/$name.zip" "$name.apk")
  rm -rf "$tmp"
done
ls -l dist
