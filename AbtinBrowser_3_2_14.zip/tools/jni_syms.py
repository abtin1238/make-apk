#!/usr/bin/env python3
"""Prints a stable fingerprint (sha256 of all Java_* JNI export names) of a libgojni.so. Same names = same Java bindings."""
import hashlib, re, sys
data = open(sys.argv[1], 'rb').read()
names = sorted(set(re.findall(rb'Java_[A-Za-z0-9_]+', data)))
if len(sys.argv) > 2 and sys.argv[2] == '-v':
    print('\n'.join(n.decode() for n in names))
print(len(names), hashlib.sha256(b'\n'.join(names)).hexdigest())
