# Flutter / plugin glue
-dontwarn com.google.android.play.core.**
-keep class ir.abtin.** { *; }
# GeckoView ships its own consumer rules (JNI / @WrapForJNI), nothing extra needed here.
# v2ray core (gomobile JNI bindings, called by name from libgojni.so)
-keep class go.** { *; }
-keep class libv2ray.** { *; }
