package ir.abtin.abtin_browser.v2ray

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Crash evidence for the :v2ray processes, readable from inside the app (no adb needed):
 *  - a Java crash handler writes the stack to files/v2ray_crash.txt,
 *  - report() adds Android's own record of why those processes died (ApplicationExitInfo) and the app's own logcat lines
 *    (native "Fatal signal" / fdsan / Go panic messages are logged by the dying process under this app's UID).
 */
object V2rayDiag {
    private const val CRASH_FILE = "v2ray_crash.txt"

    fun installCrashHandler(ctx: Context, tag: String) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val f = File(ctx.filesDir, CRASH_FILE)
                val head = "[" + stamp(System.currentTimeMillis()) + "] $tag thread=${t.name}\n"
                f.writeText(head + Log.getStackTraceString(e) + "\n")
            } catch (_: Throwable) {}
            previous?.uncaughtException(t, e)
        }
    }

    private fun stamp(ms: Long) = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date(ms))

    private fun reasonName(r: Int): String = when (r) {
        1 -> "EXIT_SELF"; 2 -> "SIGNALED"; 3 -> "LOW_MEMORY"; 4 -> "CRASH (Java)"; 5 -> "CRASH_NATIVE"; 6 -> "ANR"
        7 -> "INITIALIZATION_FAILURE"; 8 -> "PERMISSION_CHANGE"; 9 -> "EXCESSIVE_RESOURCE_USAGE"; 10 -> "USER_REQUESTED"
        11 -> "USER_STOPPED"; 12 -> "DEPENDENCY_DIED"; 13 -> "OTHER"; else -> "UNKNOWN($r)"
    }

    fun report(ctx: Context): String {
        val sb = StringBuilder()
        sb.append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}, ${Build.SUPPORTED_ABIS.firstOrNull()}\n")
        try {
            val f = File(ctx.filesDir, CRASH_FILE)
            if (f.exists()) sb.append("\n--- Java crash file ---\n").append(f.readText().take(2500)).append('\n')
        } catch (_: Throwable) {}
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                val am = ctx.getSystemService(ActivityManager::class.java)
                val list = am?.getHistoricalProcessExitReasons(ctx.packageName, 0, 12) ?: emptyList()
                val mine = list.filter { it.processName.contains(":v2ray") }.take(5)
                sb.append("\n--- Why the VPN process died (Android) ---\n")
                if (mine.isEmpty()) sb.append("(no record)\n")
                for (i in mine) {
                    sb.append(stamp(i.timestamp)).append(' ').append(i.processName).append(": ").append(reasonName(i.reason))
                        .append(" status=").append(i.status).append(" desc=").append(i.description ?: "").append('\n')
                }
            } catch (t: Throwable) {
                sb.append("exit info failed: ").append(t.javaClass.simpleName).append('\n')
            }
        }
        sb.append("\n--- logcat (this app) ---\n").append(logcat())
        return sb.toString().take(9000)
    }

    private fun logcat(): String {
        return try {
            val p = ProcessBuilder("logcat", "-d", "-v", "time", "-t", "1500", "-b", "main,crash").redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readLines()
            if (!p.waitFor(3, TimeUnit.SECONDS)) p.destroy()
            val key = Regex("AbtinV2ray|Fatal signal|fdsan|FATAL|AndroidRuntime|panic|goroutine|libv2ray|gojni|Go ?Log|xray|SIGABRT|SIGSEGV|abort|tombstone|process is bad|ActivityManager.*v2ray", RegexOption.IGNORE_CASE)
            val hits = out.filter { key.containsMatchIn(it) }.takeLast(45)
            if (hits.isEmpty()) "(nothing relevant; log may be hidden by the phone)" else hits.joinToString("\n") { it.take(300) }
        } catch (t: Throwable) {
            "logcat unavailable: " + t.javaClass.simpleName
        }
    }
}
