package ir.abtin.abtin_browser.v2ray

import android.content.Context
import android.util.Log
import java.io.File

/**
 * Iranian IP ranges read from the bundled geoip.dat (country "IR"). They are kept OUT of the TUN, so traffic to Iranian
 * addresses never enters the VPN at all (not only "routed direct" by Xray).
 */
object IranRoutes {
    private const val TAG = "AbtinIranRoutes"
    private const val CACHE = "iran_cidrs_v1.txt"

    class Ranges(val v4: List<LongArray>, val v6: List<Pair<ByteArray, Int>>)

    @Volatile private var mem: Ranges? = null

    @Synchronized fun load(ctx: Context): Ranges? {
        mem?.let { return it }
        val size = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).lastUpdateTime } catch (_: Exception) { -1L }
        val cache = File(ctx.filesDir, CACHE)
        try {
            if (cache.exists()) {
                val lines = cache.readLines()
                if (lines.isNotEmpty() && lines[0] == "size=$size") {
                    val r = fromLines(lines.drop(1))
                    if (r.v4.isNotEmpty()) { mem = r; return r }
                }
            }
        } catch (_: Exception) {}
        return try {
            val data = ctx.assets.open("v2ray/geoip.dat").use { it.readBytes() }
            val lines = parseIr(data)
            if (lines.isEmpty()) return null
            try { cache.writeText("size=$size\n" + lines.joinToString("\n")) } catch (_: Exception) {}
            fromLines(lines).also { mem = it }
        } catch (t: Throwable) {
            Log.w(TAG, "geoip parse failed", t)
            null
        }
    }

    private fun fromLines(lines: List<String>): Ranges {
        val v4 = ArrayList<LongArray>()
        val v6 = ArrayList<Pair<ByteArray, Int>>()
        for (l in lines) {
            val i = l.indexOf('/')
            if (i < 0) continue
            val ip = l.substring(0, i)
            val p = l.substring(i + 1).toIntOrNull() ?: continue
            val b = java.net.InetAddress.getByName(ip).address
            if (b.size == 4) {
                val a = ((b[0].toLong() and 255) shl 24) or ((b[1].toLong() and 255) shl 16) or ((b[2].toLong() and 255) shl 8) or (b[3].toLong() and 255)
                v4.add(longArrayOf(a, a + (1L shl (32 - p)) - 1))
            } else {
                v6.add(Pair(b, p))
            }
        }
        return Ranges(merge(v4), v6)
    }

    private fun merge(list: List<LongArray>): List<LongArray> {
        val s = list.sortedBy { it[0] }
        val out = ArrayList<LongArray>()
        for (r in s) {
            val last = out.lastOrNull()
            if (last != null && r[0] <= last[1] + 1) { if (r[1] > last[1]) last[1] = r[1] } else out.add(longArrayOf(r[0], r[1]))
        }
        return out
    }

    // ---- minimal protobuf reader (GeoIPList { repeated GeoIP = 1 }, GeoIP { code = 1; repeated CIDR = 2 }, CIDR { ip = 1; prefix = 2 }) ----
    private class Rd(val b: ByteArray) {
        var p = 0
        fun varint(): Long {
            var r = 0L
            var s = 0
            while (true) {
                val c = b[p++].toInt() and 255
                r = r or ((c and 127).toLong() shl s)
                if (c < 128) return r
                s += 7
            }
        }
    }

    private fun parseIr(b: ByteArray): List<String> {
        val out = ArrayList<String>()
        val top = Rd(b)
        while (top.p < b.size) {
            val tag = top.varint()
            val f = (tag shr 3).toInt()
            val w = (tag and 7).toInt()
            when (w) {
                0 -> top.varint()
                1 -> top.p += 8
                5 -> top.p += 4
                2 -> {
                    val len = top.varint().toInt()
                    val s = top.p
                    val e = s + len
                    top.p = e
                    if (f == 1 && entryIsIr(b, s, e)) readCidrs(b, s, e, out)
                }
                else -> return out
            }
        }
        return out
    }

    private fun entryIsIr(b: ByteArray, s: Int, e: Int): Boolean {
        val r = Rd(b)
        r.p = s
        while (r.p < e) {
            val tag = r.varint()
            val f = (tag shr 3).toInt()
            when ((tag and 7).toInt()) {
                0 -> r.varint()
                1 -> r.p += 8
                5 -> r.p += 4
                2 -> {
                    val len = r.varint().toInt()
                    if (f == 1) return String(b, r.p, len, Charsets.UTF_8).equals("IR", ignoreCase = true)
                    r.p += len
                }
                else -> return false
            }
        }
        return false
    }

    private fun readCidrs(b: ByteArray, s: Int, e: Int, out: MutableList<String>) {
        val r = Rd(b)
        r.p = s
        while (r.p < e) {
            val tag = r.varint()
            val f = (tag shr 3).toInt()
            when ((tag and 7).toInt()) {
                0 -> r.varint()
                1 -> r.p += 8
                5 -> r.p += 4
                2 -> {
                    val len = r.varint().toInt()
                    val cs = r.p
                    r.p += len
                    if (f == 2) readCidr(b, cs, cs + len)?.let { out.add(it) }
                }
                else -> return
            }
        }
    }

    private fun readCidr(b: ByteArray, s: Int, e: Int): String? {
        val r = Rd(b)
        r.p = s
        var ip: ByteArray? = null
        var prefix = 0
        while (r.p < e) {
            val tag = r.varint()
            val f = (tag shr 3).toInt()
            when ((tag and 7).toInt()) {
                0 -> { val v = r.varint(); if (f == 2) prefix = v.toInt() }
                1 -> r.p += 8
                5 -> r.p += 4
                2 -> {
                    val len = r.varint().toInt()
                    if (f == 1) ip = b.copyOfRange(r.p, r.p + len)
                    r.p += len
                }
                else -> return null
            }
        }
        val a = ip ?: return null
        if (a.size != 4 && a.size != 16) return null
        return java.net.InetAddress.getByAddress(a).hostAddress + "/" + prefix
    }

    // ---- interval math (IPv4) ----
    private val FULL = longArrayOf(0L, 0xFFFFFFFFL)

    fun toCidrs(start: Long, end: Long, out: MutableList<Pair<String, Int>>) {
        var s = start
        while (s <= end) {
            val maxSize = if (s == 0L) (1L shl 32) else (s and -s)
            val rem = end - s + 1
            val size = minOf(maxSize, java.lang.Long.highestOneBit(rem))
            val prefix = 32 - java.lang.Long.numberOfTrailingZeros(size)
            out.add(Pair(ip4(s), prefix))
            s += size
        }
    }

    private fun ip4(a: Long) = "${(a shr 24) and 255}.${(a shr 16) and 255}.${(a shr 8) and 255}.${a and 255}"

    private fun parseBase(cidrs: List<String>?): List<LongArray> {
        if (cidrs == null) return listOf(FULL)
        return merge(cidrs.map {
            val p = it.split('/')
            val b = java.net.InetAddress.getByName(p[0]).address
            val a = ((b[0].toLong() and 255) shl 24) or ((b[1].toLong() and 255) shl 16) or ((b[2].toLong() and 255) shl 8) or (b[3].toLong() and 255)
            longArrayOf(a, a + (1L shl (32 - p[1].toInt())) - 1)
        })
    }

    /** IPv4 routes = [base] (null = everything) minus the Iranian ranges. */
    fun v4Complement(r: Ranges, base: List<String>?): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        for (b in parseBase(base)) {
            var cur = b[0]
            for (x in r.v4) {
                if (x[1] < cur) continue
                if (x[0] > b[1]) break
                if (x[0] > cur) toCidrs(cur, x[0] - 1, out)
                cur = x[1] + 1
                if (cur > b[1]) break
            }
            if (cur <= b[1]) toCidrs(cur, b[1], out)
        }
        return out
    }

    /** The Iranian IPv4 ranges as CIDRs (for VpnService.Builder.excludeRoute, Android 13+). */
    fun v4Excluded(r: Ranges): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        for (x in r.v4) toCidrs(x[0], x[1], out)
        return out
    }
}
