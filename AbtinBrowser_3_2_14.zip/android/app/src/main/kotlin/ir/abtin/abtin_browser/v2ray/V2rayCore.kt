package ir.abtin.abtin_browser.v2ray

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.util.Base64
import android.util.Log
import go.Seq
import libv2ray.CoreCallbackHandler
import libv2ray.CoreController
import libv2ray.Libv2ray
import java.io.File

object V2rayConst {
    const val ACTION_START = "ir.abtin.abtin_browser.v2ray.START"
    const val ACTION_STOP = "ir.abtin.abtin_browser.v2ray.STOP"
    const val ACTION_QUERY = "ir.abtin.abtin_browser.v2ray.QUERY"
    const val ACTION_EVENT = "ir.abtin.abtin_browser.v2ray.EVENT"
    const val CONFIG_FILE = "v2ray_active.json"
    const val SOCKS_PORT = 10808

    /** Same routed list as PattNG: everything except private/LAN ranges (used when "bypass LAN" is on). */
    val ROUTED_IP_LIST = listOf(
        "0.0.0.0/5", "8.0.0.0/7", "11.0.0.0/8", "12.0.0.0/6", "16.0.0.0/4", "32.0.0.0/3", "64.0.0.0/2",
        "128.0.0.0/3", "160.0.0.0/5", "168.0.0.0/6", "172.0.0.0/12", "172.32.0.0/11", "172.64.0.0/10",
        "172.128.0.0/9", "173.0.0.0/8", "174.0.0.0/7", "176.0.0.0/4", "192.0.0.0/9", "192.128.0.0/11",
        "192.160.0.0/13", "192.169.0.0/16", "192.170.0.0/15", "192.172.0.0/14", "192.176.0.0/12",
        "192.192.0.0/10", "193.0.0.0/8", "194.0.0.0/7", "196.0.0.0/6", "200.0.0.0/5", "208.0.0.0/4", "240.0.0.0/4",
    )
}

/** Sends state / stats / ping results from the :v2ray processes to the UI process (explicit-package broadcast). */
object V2rayEvents {
    fun send(ctx: Context, fill: Intent.() -> Unit) {
        val i = Intent(V2rayConst.ACTION_EVENT).setPackage(ctx.packageName)
        i.fill()
        ctx.sendBroadcast(i)
    }

    fun state(ctx: Context, state: String, error: String = "") = send(ctx) {
        putExtra("type", "state")
        putExtra("state", state)
        putExtra("error", error)
    }
}

/**
 * Thin wrapper over PattNG's libv2ray (Xray core). Only ever touched in the :v2ray / :v2raytest processes, so the
 * Go runtime never shares a process with GeckoView and the UI.
 */
object V2rayCore {
    private const val TAG = "AbtinV2ray"

    @Volatile var state = "disconnected"
    @Volatile var lastError = ""

    private val lock = Any()
    @Volatile private var envReady = false
    @Volatile private var controller: CoreController? = null

    private class Handler : CoreCallbackHandler {
        override fun onEmitStatus(code: Long, message: String?): Long {
            Log.i(TAG, "core status: $message")
            return 0
        }
        override fun shutdown(): Long = 0
        override fun startup(): Long = 0
    }

    @Synchronized
    fun ensureEnv(ctx: Context) {
        if (envReady) return
        val app = ctx.applicationContext
        val dir = app.getDir("assets", Context.MODE_PRIVATE)
        copyGeoData(app, dir)
        Seq.setContext(app)
        val androidId = Settings.Secure.getString(app.contentResolver, Settings.Secure.ANDROID_ID) ?: "abtin"
        val deviceId = Base64.encodeToString(androidId.toByteArray(Charsets.UTF_8).copyOf(32), Base64.NO_PADDING or Base64.URL_SAFE)
        Libv2ray.initCoreEnv(dir.absolutePath, deviceId)
        envReady = true
    }

    /** geoip.dat / geosite.dat ship in the APK (PattNG's Iran-aware files); copied once per app version. */
    private fun copyGeoData(app: Context, dir: File) {
        val version = try {
            @Suppress("DEPRECATION")
            app.packageManager.getPackageInfo(app.packageName, 0).versionCode.toString()
        } catch (_: Exception) { "0" }
        val marker = File(dir, ".geo_version")
        val current = if (marker.exists()) marker.readText() else ""
        for (n in arrayOf("geoip.dat", "geosite.dat")) {
            val target = File(dir, n)
            if (current == version && target.length() > 0) continue
            app.assets.open("v2ray/$n").use { input -> target.outputStream().use { out -> input.copyTo(out, 256 * 1024) } }
        }
        marker.writeText(version)
    }

    fun start(ctx: Context, config: String, tunFd: Int) {
        ensureEnv(ctx)
        val c = controller ?: Libv2ray.newCoreController(Handler()).also { controller = it }
        c.startLoop(config, tunFd)
        if (!c.isRunning) throw IllegalStateException("Core failed to start")
    }

    fun stop() {
        synchronized(lock) {
            try {
                controller?.let { if (it.isRunning) it.stopLoop() }
            } catch (t: Throwable) {
                Log.e(TAG, "stopLoop failed", t)
            }
        }
    }

    /** Bytes moved since the last call (the core resets its counters on query): (uplink, downlink) of all outbounds. */
    fun queryStats(): Pair<Long, Long> {
        synchronized(lock) {
            val c = controller ?: return Pair(0L, 0L)
            // The stats manager is freed when the core stops: never query a stopped core.
            if (!c.isRunning) return Pair(0L, 0L)
            var up = 0L
            var down = 0L
            try {
                val payload = c.queryAllOutboundTrafficStats() ?: return Pair(0L, 0L)
                for (entry in payload.split(';')) {
                    if (entry.isBlank()) continue
                    val parts = entry.split(',', limit = 3)
                    if (parts.size != 3) continue
                    val v = parts[2].toLongOrNull() ?: continue
                    if (parts[0] != "proxy") continue
                    if (parts[1].startsWith("up")) up += v else if (parts[1].startsWith("down")) down += v
                }
            } catch (t: Throwable) {
                Log.e(TAG, "stats failed", t)
            }
            return Pair(up, down)
        }
    }

    fun measureDelay(ctx: Context, config: String, url: String): Long {
        ensureEnv(ctx)
        return Libv2ray.measureOutboundDelay(config, url)
    }
}
