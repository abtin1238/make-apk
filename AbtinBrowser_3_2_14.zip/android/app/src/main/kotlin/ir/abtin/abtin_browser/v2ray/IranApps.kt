package ir.abtin.abtin_browser.v2ray

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/** Launcher apps on the phone, with a guess whether each one is an Iranian app (banks, messengers, shops...). */
object IranApps {
    private val KNOWN = listOf(
        "ir.", "com.samanpr.", "com.farsitel.bazaar", "cab.snapp.", "com.digikala", "app.eitaa", "org.eitaa", "com.aparat",
        "com.sadadpsp", "com.pasargad", "com.parsian", "com.mellat", "com.bsi.", "com.tejaratbank", "com.refah",
    )

    private fun persian(s: String) = s.any { it in '\u0600'..'\u06FF' }

    fun isIran(pkg: String, label: String): Boolean {
        val p = pkg.lowercase()
        return KNOWN.any { p.startsWith(it) } || p.endsWith(".ir") || p.contains(".ir.") || persian(label)
    }

    fun list(ctx: Context): List<Map<String, Any>> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val seen = HashSet<String>()
        val out = ArrayList<Map<String, Any>>()
        for (ri in pm.queryIntentActivities(i, PackageManager.MATCH_ALL)) {
            val pkg = ri.activityInfo.packageName
            if (pkg == ctx.packageName || !seen.add(pkg)) continue
            val label = ri.loadLabel(pm).toString()
            out.add(mapOf("pkg" to pkg, "label" to label, "iran" to isIran(pkg, label)))
        }
        return out.sortedBy { (it["label"] as String).lowercase() }
    }
}
