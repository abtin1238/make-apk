package ir.abtin.abtin_browser.v2ray

import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/**
 * Real-delay test of a config through a temporary Xray instance, in its own process (":v2raytest").
 *
 * All state is process-wide (companion), not per service instance: Android destroys and re-creates the Service object
 * between batches, and a per-instance counter let an OLD instance's delayed "kill the process" fire in the middle of
 * the NEXT batch (second ping within a few seconds -> every running test lost, Go core killed mid-flight).
 */
class V2rayTestService : Service() {
    companion object {
        private const val TAG = "AbtinV2rayTest"
        private const val IDLE_KILL_MS = 8000L
        private val pool = Executors.newFixedThreadPool(3)
        private val pending = AtomicInteger(0)
        private val handler = Handler(Looper.getMainLooper())

        /** Ends the process (fresh Go runtime next time) only when it has been idle the whole delay. */
        private val idleKill = Runnable {
            if (pending.get() == 0) android.os.Process.killProcess(android.os.Process.myPid())
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        V2rayDiag.installCrashHandler(applicationContext, "v2raytest")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra("id")
        val path = intent?.getStringExtra("path")
        val url = intent?.getStringExtra("url") ?: "https://www.gstatic.com/generate_204"
        // New work (or a stray start): the process must not be killed under it.
        handler.removeCallbacks(idleKill)
        if (id == null || path == null) {
            if (pending.get() == 0) handler.postDelayed(idleKill, IDLE_KILL_MS)
            return START_NOT_STICKY
        }
        pending.incrementAndGet()
        val app = applicationContext
        pool.execute {
            var ms = -1L
            try {
                val f = File(path)
                val config = f.readText()
                f.delete()
                ms = V2rayCore.measureDelay(app, config, url)
            } catch (t: Throwable) {
                Log.e(TAG, "delay test failed", t)
            }
            V2rayEvents.send(app) {
                putExtra("type", "ping")
                putExtra("id", id)
                putExtra("ms", ms)
            }
            if (pending.decrementAndGet() == 0) {
                // Batch over: free the Go runtime after a quiet period. Any new request cancels this.
                handler.removeCallbacks(idleKill)
                handler.postDelayed(idleKill, IDLE_KILL_MS)
            }
        }
        return START_NOT_STICKY
    }
}
