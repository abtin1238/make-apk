package ir.abtin.abtin_browser.v2ray

import android.content.Context
import android.content.Intent
import android.os.PowerManager

/**
 * Helps the VPN survive task killers (MIUI / HyperOS security centre, battery savers):
 *  - the start parameters are saved, so when Android restarts the sticky service with a null intent it reconnects by itself
 *    (only while `wanted`, i.e. the user did not press Disconnect);
 *  - a partial wake lock keeps the CPU running for the tunnel while connected.
 */
object V2rayKeepAlive {
    private const val PREFS = "v2ray_keepalive"
    private var wake: PowerManager.WakeLock? = null

    fun save(ctx: Context, i: Intent, wanted: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("wanted", wanted)
            .putString("name", i.getStringExtra("name") ?: "VPN")
            .putInt("mtu", i.getIntExtra("mtu", 1500))
            .putBoolean("ipv6", i.getBooleanExtra("ipv6", true))
            .putBoolean("bypassLan", i.getBooleanExtra("bypassLan", true))
            .putBoolean("bypassIranIp", i.getBooleanExtra("bypassIranIp", true))
            .putString("dns", i.getStringExtra("dns") ?: "8.8.8.8")
            .putString("skip", i.getStringExtra("skip") ?: "")
            .apply()
    }

    fun setWanted(ctx: Context, wanted: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("wanted", wanted).apply()
    }

    /** The saved start intent, or null when the user disconnected / nothing was saved (or the config file is gone). */
    fun restoreIntent(ctx: Context): Intent? {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!p.getBoolean("wanted", false)) return null
        if (!java.io.File(ctx.filesDir, V2rayConst.CONFIG_FILE).exists()) return null
        return Intent(V2rayConst.ACTION_START)
            .putExtra("name", p.getString("name", "VPN"))
            .putExtra("mtu", p.getInt("mtu", 1500))
            .putExtra("ipv6", p.getBoolean("ipv6", true))
            .putExtra("bypassLan", p.getBoolean("bypassLan", true))
            .putExtra("bypassIranIp", p.getBoolean("bypassIranIp", true))
            .putExtra("dns", p.getString("dns", "8.8.8.8"))
            .putExtra("skip", p.getString("skip", ""))
    }

    @Synchronized fun holdWake(ctx: Context) {
        try {
            if (wake?.isHeld == true) return
            val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "abtin:v2ray").also { it.setReferenceCounted(false); it.acquire(12 * 60 * 60 * 1000L) }
        } catch (_: Throwable) {}
    }

    @Synchronized fun releaseWake() {
        try { wake?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
        wake = null
    }
}
