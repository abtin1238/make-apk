package go;

import java.lang.ref.PhantomReference;
import java.lang.ref.ReferenceQueue;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.logging.Logger;

/**
 * gomobile sequence/ref runtime for libgojni.so (the Go side calls back into getRef, decRef, incRef,
 * incGoObjectRef and incRefnum by name, and reads Ref.obj / Ref.refnum). Same members as the class
 * generated into PattNG's libv2ray.aar.
 */
public class Seq {
    private static Logger log = Logger.getLogger("GoSeq");

    // also known to bind/seq/ref.go and bind/objc/seq_darwin.m
    private static final int NULL_REFNUM = 41;

    // use single Ref for null Object
    public static final Ref nullRef = new Ref(NULL_REFNUM, null);

    // The singleton GoRefQueue
    private static final GoRefQueue goRefQueue = new GoRefQueue();

    static {
        System.loadLibrary("gojni");
        init();
        Universe.touch();
    }

    // Call Seq.touch() to force load of libgojni.so
    public static void touch() {}

    private Seq() {}

    // ctx is an android.content.Context.
    public static void setContext(android.content.Context ctx) {
        setContext((java.lang.Object) ctx);
    }

    // ctx is an android.content.Context.
    static native void setContext(java.lang.Object ctx);

    public static void incRefnum(int refnum) {
        tracker.incRefnum(refnum);
    }

    // incRef increments the reference count of Java objects.
    public static int incRef(Object o) {
        return tracker.inc(o);
    }

    public static int incGoObjectRef(GoObject o) {
        return o.incRefnum();
    }

    // trackGoRef tracks a Go reference and decrements its refcount when the given GoObject wrapper is GC'd.
    public static void trackGoRef(int refnum, GoObject obj) {
        if (refnum > 0) {
            throw new RuntimeException("trackGoRef called with Java refnum " + refnum);
        }
        goRefQueue.track(refnum, obj);
    }

    public static Ref getRef(int refnum) {
        return tracker.get(refnum);
    }

    // decRef is called from seq.FinalizeRef
    static void decRef(int refnum) {
        tracker.dec(refnum);
    }

    public static native void destroyRef(int refnum);

    public static native void incGoRef(int refnum, GoObject o);

    private static native void init();

    public interface GoObject {
        int incRefnum();
    }

    public interface Proxy extends GoObject {}

    // Ref represents a Java or Go object in the object tracker.
    public static final class Ref {
        public final int refnum;
        private int refcnt; // for Java obj: number of Java refs. Not used for Go.
        public final Object obj; // for Go obj: null.

        Ref(int refnum, Object o) {
            this.refnum = refnum;
            this.refcnt = 0;
            this.obj = o;
        }

        void inc() {
            // Count how many times this ref's Java object is passed to Go.
            if (refcnt == Integer.MAX_VALUE) {
                throw new RuntimeException("refnum " + refnum + " overflow");
            }
            refcnt++;
        }
    }

    static final RefTracker tracker = new RefTracker();

    static final class RefTracker {
        private static final int REF_OFFSET = 42;

        // Next Java object reference number.
        private int next = REF_OFFSET;

        // Java objects that have been passed to Go. refnum -> Ref. Pins them against GC.
        private final RefMap javaObjs = new RefMap();

        // Java objects to refnum
        private final IdentityHashMap<Object, Integer> javaRefs = new IdentityHashMap<Object, Integer>();

        // inc increments the reference count of a Java object when it is sent to Go.
        synchronized int inc(Object o) {
            if (o == null) {
                return NULL_REFNUM;
            }
            if (o instanceof Proxy) {
                return ((Proxy) o).incRefnum();
            }
            Integer refnumObj = javaRefs.get(o);
            if (refnumObj == null) {
                if (next == Integer.MAX_VALUE) {
                    throw new RuntimeException("createRef overflow for " + o);
                }
                refnumObj = next++;
                javaRefs.put(o, refnumObj);
            }
            int refnum = refnumObj;
            Ref ref = javaObjs.get(refnum);
            if (ref == null) {
                ref = new Ref(refnum, o);
                javaObjs.put(refnum, ref);
            }
            ref.inc();
            return refnum;
        }

        synchronized void incRefnum(int refnum) {
            Ref ref = javaObjs.get(refnum);
            if (ref == null) {
                throw new RuntimeException("referenced Java object is not found: refnum=" + refnum);
            }
            ref.inc();
        }

        // dec decrements the reference count of a Java object when Go signals its proxy is finalized.
        synchronized void dec(int refnum) {
            if (refnum <= 0) {
                // We don't keep track of the Go object. This must not happen.
                log.severe("dec request for Go object " + refnum);
                return;
            }
            if (refnum == Seq.nullRef.refnum) {
                return;
            }
            // Java objects are removed on request of Go.
            Ref obj = javaObjs.get(refnum);
            if (obj == null) {
                throw new RuntimeException("referenced Java object is not found: refnum=" + refnum);
            }
            obj.refcnt--;
            if (obj.refcnt <= 0) {
                javaObjs.remove(refnum);
                javaRefs.remove(obj.obj);
            }
        }

        // get returns an existing Ref to a Java object.
        synchronized Ref get(int refnum) {
            if (refnum == NULL_REFNUM) {
                return nullRef;
            }
            Ref ref = javaObjs.get(refnum);
            if (ref == null) {
                throw new RuntimeException("unknown java Ref: " + refnum);
            }
            return ref;
        }
    }

    // GoRefQueue is a queue of GoRefs that are no longer live. A daemon thread processes the queue
    // and decrements the reference count on the Go side.
    static class GoRefQueue extends ReferenceQueue<GoObject> {
        // The set of tracked GoRefs. Without it the GC would collect the refs and Go would never be told.
        private final Collection<GoRef> refs = Collections.synchronizedCollection(new HashSet<GoRef>());

        void track(int refnum, GoObject obj) {
            refs.add(new GoRef(refnum, obj, this));
        }

        GoRefQueue() {
            Thread daemon = new Thread(new Runnable() {
                @Override
                public void run() {
                    while (true) {
                        try {
                            GoRef ref = (GoRef) remove();
                            refs.remove(ref);
                            destroyRef(ref.refnum);
                            ref.clear();
                        } catch (InterruptedException e) {
                            // Ignore
                        }
                    }
                }
            });
            daemon.setDaemon(true);
            daemon.setName("GoRefQueue Finalizer Thread");
            daemon.start();
        }
    }

    // A GoRef is a PhantomReference to a Java proxy for a Go object.
    static final class GoRef extends PhantomReference<GoObject> {
        final int refnum;

        GoRef(int refnum, GoObject obj, GoRefQueue q) {
            super(obj, q);
            if (refnum > 0) {
                throw new RuntimeException("GoRef instantiated with a Java refnum");
            }
            this.refnum = refnum;
        }
    }

    // RefMap is a mapping of integers to Ref objects (in Go this would be a map[int]*Ref).
    static final class RefMap {
        private int next = 0;
        private int live = 0;
        private int[] keys = new int[16];
        private Ref[] objs = new Ref[16];

        RefMap() {}

        Ref get(int key) {
            int i = Arrays.binarySearch(keys, 0, next, key);
            if (i >= 0) {
                return objs[i];
            }
            return null;
        }

        void remove(int key) {
            int i = Arrays.binarySearch(keys, 0, next, key);
            if (i >= 0) {
                if (objs[i] != null) {
                    objs[i] = null;
                    live--;
                }
            }
        }

        void put(int key, Ref obj) {
            if (obj == null) {
                throw new RuntimeException("put a null ref (with key " + key + ")");
            }
            int i = Arrays.binarySearch(keys, 0, next, key);
            if (i >= 0) {
                if (objs[i] == null) {
                    objs[i] = obj;
                    live++;
                }
                if (objs[i] != obj) {
                    throw new RuntimeException("replacing an existing ref (with key " + key + ")");
                }
                return;
            }
            if (next >= keys.length) {
                grow();
                i = Arrays.binarySearch(keys, 0, next, key);
            }
            i = ~i;
            if (i < next) {
                // Insert, shift everything afterwards down.
                System.arraycopy(keys, i, keys, i + 1, next - i);
                System.arraycopy(objs, i, objs, i + 1, next - i);
            }
            keys[i] = key;
            objs[i] = obj;
            live++;
            next++;
        }

        private void grow() {
            // Compact and (if necessary) grow backing store.
            int[] newKeys;
            Ref[] newObjs;
            int len = roundPow2(live);
            if (len > keys.length) {
                newKeys = new int[keys.length * 2];
                newObjs = new Ref[objs.length * 2];
            } else {
                newKeys = keys;
                newObjs = objs;
            }

            int j = 0;
            for (int i = 0; i < keys.length; i++) {
                if (objs[i] != null) {
                    newKeys[j] = keys[i];
                    newObjs[j] = objs[i];
                    j++;
                }
            }
            for (int i = j; i < newKeys.length; i++) {
                newKeys[i] = 0;
                newObjs[i] = null;
            }

            keys = newKeys;
            objs = newObjs;
            next = j;

            if (live != next) {
                throw new RuntimeException("bad state: live=" + live + ", next=" + next);
            }
        }

        private static int roundPow2(int x) {
            int p = 1;
            while (p < x) {
                p *= 2;
            }
            return p;
        }
    }
}
