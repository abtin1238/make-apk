package go;

/** gomobile universe bindings (Go builtin types). Mirrors the generated class of libv2ray.aar. */
public abstract class Universe {
    static {
        Seq.touch();
        _init();
    }

    private Universe() {}

    private static native void _init();

    public static void touch() {}

    private static final class proxyerror extends Exception implements Seq.Proxy, error {
        private final int refnum;

        @Override
        public final int incRefnum() {
            Seq.incGoRef(refnum, this);
            return refnum;
        }

        proxyerror(final int refnum) {
            this.refnum = refnum;
            Seq.trackGoRef(refnum, this);
        }

        @Override
        public String getMessage() {
            return error();
        }

        @Override
        public native String error();
    }
}
