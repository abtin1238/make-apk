package go;

/** gomobile binding of Go's builtin error interface. */
public interface error {
    String error();
}
