package libv2ray;

import go.Seq;

/** gomobile package class of PattNG's libv2ray (static entry points). */
public abstract class Libv2ray {
    static {
        Seq.touch();
        _init();
    }

    private Libv2ray() {}

    private static native void _init();

    private static final class proxyCoreCallbackHandler implements Seq.Proxy, CoreCallbackHandler {
        private final int refnum;

        @Override
        public final int incRefnum() {
            Seq.incGoRef(refnum, this);
            return refnum;
        }

        proxyCoreCallbackHandler(final int refnum) {
            this.refnum = refnum;
            Seq.trackGoRef(refnum, this);
        }

        @Override
        public native long onEmitStatus(long code, String message);

        @Override
        public native long shutdown();

        @Override
        public native long startup();
    }

    private static final class proxyProcessFinder implements Seq.Proxy, ProcessFinder {
        private final int refnum;

        @Override
        public final int incRefnum() {
            Seq.incGoRef(refnum, this);
            return refnum;
        }

        proxyProcessFinder(final int refnum) {
            this.refnum = refnum;
            Seq.trackGoRef(refnum, this);
        }

        @Override
        public native long findProcessByConnection(String network, String srcIP, long srcPort, String destIP, long destPort);
    }

    public static native void cancelOutboundDelays(String batch) throws Exception;

    public static native String checkVersionX() throws Exception;

    public static native void closeExit() throws Exception;

    public static native String fetchQuicCertSha256(String arg) throws Exception;

    public static native String fetchTlsCertSha256(String arg) throws Exception;

    public static native void initCoreEnv(String assetPath, String deviceId) throws Exception;

    public static native long measureOutboundDelay(String config, String url) throws Exception;

    public static native long measureOutboundDelayInBatch(String batch, String config, String url) throws Exception;

    public static native CoreController newCoreController(CoreCallbackHandler handler) throws Exception;

    public static native long openExit(String configuration) throws Exception;

    public static native void reconcileBrowserDialer(String dialerAddr) throws Exception;

    public static void touch() {}
}
