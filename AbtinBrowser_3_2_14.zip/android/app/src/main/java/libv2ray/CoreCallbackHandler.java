package libv2ray;

public interface CoreCallbackHandler {
    long onEmitStatus(long code, String message);

    long shutdown();

    long startup();
}
