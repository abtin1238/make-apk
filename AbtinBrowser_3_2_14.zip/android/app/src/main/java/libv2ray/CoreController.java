package libv2ray;

import go.Seq;

/** gomobile proxy of the Go CoreController of PattNG's AndroidLibXrayLite. */
public final class CoreController implements Seq.Proxy {
    static {
        Libv2ray.touch();
    }

    private final int refnum;

    @Override
    public final int incRefnum() {
        Seq.incGoRef(refnum, this);
        return refnum;
    }

    CoreController(final int refnum) {
        this.refnum = refnum;
        Seq.trackGoRef(refnum, this);
    }

    public CoreController(CoreCallbackHandler handler) {
        this(__NewCoreController(handler));
    }

    private static native int __NewCoreController(CoreCallbackHandler handler);

    public final native CoreCallbackHandler getCallbackHandler();

    public final native void setCallbackHandler(CoreCallbackHandler v);

    public final native boolean getIsRunning();

    public final native void setIsRunning(boolean v);

    public native long measureDelay(String url) throws Exception;

    public native String queryAllOutboundTrafficStats() throws Exception;

    public native void registerProcessFinder(ProcessFinder finder);

    public native void startLoop(String config, int tunFd) throws Exception;

    public native void stopLoop() throws Exception;

    @Override
    public boolean equals(Object o) {
        if (o == null || !(o instanceof CoreController)) {
            return false;
        }
        return refnum == ((CoreController) o).refnum;
    }

    @Override
    public int hashCode() {
        return refnum;
    }

    @Override
    public String toString() {
        return "CoreController{}";
    }
}
