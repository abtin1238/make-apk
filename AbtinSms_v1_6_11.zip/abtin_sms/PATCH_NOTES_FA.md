# تغییرات نسخهٔ 1.6.3

- زمان‌بندی ارسال: دکمه‌های بالا/پایین «دقیقه» حالا ۱ دقیقه‌ای حرکت می‌کنند (قبلاً ۵ دقیقه‌ای). فایل: `Send.kt`
- USSD: فیلتر `ACTION_CALL` از `PhoneActivity` حذف شد (مسیر قدیمی USSD ممکن بود به خود برنامه برسد و نادیده گرفته شود)؛ ارسال با `placeCall` مثل تماس عادی انجام می‌شود، صفحهٔ تماس آبتین روی پنجرهٔ پاسخ USSD باز نمی‌شود و `sendUssdRequest` آخرین راه است. فایل‌ها: `AndroidManifest.xml`, `Call.kt`
- اعلان پیامک: کانال جدید (v2) با صدا و لرزش پیش‌فرض خود اندروید (بدون صدا یا الگوی لرزش اختصاصی برنامه)؛ فقط اگر در تنظیمات صدایی انتخاب شده باشد همان استفاده می‌شود. اعلان ساده همیشه ساخته می‌شود و خطا در اعلان گیرندهٔ پیامک را متوقف نمی‌کند. فایل: `Core.kt`
- versionCode=24 / versionName=1.6.2 (برای نصب روی نسخهٔ قبلی)
- تماس ورودی: وقتی گوشی در حال استفاده و باز است فقط اعلان بالای صفحه (heads-up) نمایش داده می‌شود و صفحهٔ تماس روی برنامهٔ دیگر باز نمی‌شود؛ با لمس اعلان باز می‌شود. در حالت قفل/خاموش بودن صفحه همان تمام‌صفحه قبلی می‌ماند. فایل: `Call.kt`, `Settings.kt`
- انیمیشن صفحهٔ تماس: در حالت «کشیدنی» دکمهٔ وسط آرام کمی به راست (پاسخ) و بعد چپ (رد) تکان می‌خورد؛ در حالت دو دکمه‌ای هر دکمه کمی به سمت خودش حرکت می‌کند. فایل‌ها: `Call.kt`, `CallTheme.kt`
- versionCode=25 / versionName=1.6.3

## 1.6.4
- In-app debug log (Settings > Notifications > Debug log): state dump + receiver/notifier trace, copy/share.
- Notification channel v3 with explicit default sound + vibration; manual sound/vibrate fallback; plain-notification fallback.
- Real back stack: phone Back / arrow returns exactly one step (chat -> previous screen).

## 1.6.5
- SMS app: Contacts tab hidden by default (contacts still shown in New message picker). Settings > General > Sections > "Show Contacts section" brings it back.

## 1.6.6
- Xiaomi/MIUI: "Guaranteed sound & vibration" (default on for Xiaomi): silent channel + app plays tone/vibration itself. Button to Xiaomi special permissions.

## 1.6.7 - 1.6.9
- Play Protect: removed SYSTEM_ALERT_WINDOW and REQUEST_IGNORE_BATTERY_OPTIMIZATIONS permissions, allowBackup=false.
- Location permission kept: the app asks for it at runtime only when the user taps "share location" in a chat.
- Signing key lives in GitHub secrets; no keystore / key.properties in the project (build.gradle.kts reads key.properties only if the CI creates it).

## 1.6.10
- Call recording restored (direct call stream first, opt-in mic fallback). The microphone permission is no longer asked at startup: it is asked in-app when the user turns on auto-record or taps record in a call.

## 1.6.11
- Call recording: mic/speaker fallback dialog removed; only direct call-stream recording. Failure reason is written to the in-app debug log. RECORD_AUDIO asked in-app at startup again.
