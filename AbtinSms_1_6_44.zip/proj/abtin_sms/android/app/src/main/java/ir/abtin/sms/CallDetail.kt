package ir.abtin.sms

import android.provider.CallLog
import android.provider.ContactsContract
import androidx.activity.ComponentActivity
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Contact id for a phone number, or 0 when the number is not a saved contact. */
fun SmsRepo.contactIdForNumber(number: String): Long {
    if (number.none { it.isDigit() }) return 0
    if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED) return 0
    return runCatching {
        val uri = android.net.Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, android.net.Uri.encode(number))
        cr.query(uri, arrayOf(ContactsContract.PhoneLookup._ID), null, null, null)?.use { if (it.moveToFirst()) it.getLong(0) else 0L } ?: 0L
    }.getOrDefault(0L)
}

private fun callTypeLabel(t: Int) = when (t) {
    CallLog.Calls.INCOMING_TYPE -> tr("ورودی", "Incoming")
    CallLog.Calls.OUTGOING_TYPE -> tr("خروجی", "Outgoing")
    CallLog.Calls.MISSED_TYPE -> tr("بی‌پاسخ", "Missed")
    CallLog.Calls.REJECTED_TYPE -> tr("ردشده", "Rejected")
    else -> tr("تماس", "Call")
}

private fun callTypeIcon(t: Int): ImageVector = when (t) {
    CallLog.Calls.OUTGOING_TYPE -> Icons.Default.CallMade
    CallLog.Calls.INCOMING_TYPE -> Icons.Default.CallReceived
    else -> Icons.Default.CallMissed
}

@Composable
private fun DetailAction(icon: ImageVector, label: String, primary: Boolean, tint: Color? = null, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(18.dp)
    Column(modifier.clip(shape)
        .then(if (primary) Modifier.background(Brush.linearGradient(listOf(p.primary, p.primary2))) else Modifier.background(p.surface).border(1.dp, p.line, shape))
        .clickable(onClick = onClick).padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = if (primary) Color.White else tint ?: p.text, modifier = Modifier.size(24.dp))
        Spacer(Modifier.height(4.dp))
        Text(label, color = if (primary) Color.White else tint ?: p.sub, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun CallDetailScreen(repo: SmsRepo, act: ComponentActivity, s: Screen.CallDetail, nav: MutableState<Screen>) {
    val p = LocalPal.current
    val tick = Bus.tick.intValue
    val number = s.number
    var rows by remember { mutableStateOf<List<CallRow>>(emptyList()) }
    var contactId by remember { mutableLongStateOf(0L) }
    var contactName by remember { mutableStateOf<String?>(null) }
    var blocked by remember { mutableStateOf(isBlockedNumber(number)) }
    LaunchedEffect(number, tick) {
        withContext(Dispatchers.IO) {
            val key = norm(number)
            rows = runCatching { repo.callLog() }.getOrDefault(emptyList()).filter { norm(it.number) == key }.sortedByDescending { it.date }
            contactId = repo.contactIdForNumber(number)
            contactName = if (contactId > 0) repo.name(number) else null
        }
        blocked = isBlockedNumber(number)
    }
    val isContact = contactId > 0L
    val title = contactName ?: if (number.isBlank()) tr("ناشناس", "Unknown") else tr("شماره ناشناس", "Unknown number")
    val shown = normalizePhoneNumber(number)

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 20.dp, vertical = 12.dp)) {
            CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, { Bus.back.value.invoke() })
            Spacer(Modifier.weight(1f))
            if (isContact) CircleBtn(Icons.Default.Person, { nav.value = Screen.ContactDetail(contactId) })
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Avatar(repo, number, contactName ?: number, 96.dp)
            Spacer(Modifier.height(12.dp))
            Text(fixNum(title), color = p.text, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content, textAlign = TextAlign.Center))
            if (shown.isNotBlank()) Text(ltr(shown), color = p.primary, fontSize = 15.sp, modifier = Modifier.padding(top = 4.dp).clickable { copyPhoneNumber(act, number) }, style = TextStyle(textDirection = TextDirection.Ltr))
            Box(Modifier.padding(top = 8.dp).clip(RoundedCornerShape(99.dp)).background(if (isContact) p.surface else p.danger.copy(alpha = .16f)).padding(horizontal = 12.dp, vertical = 3.dp)) {
                Text(if (isContact) tr("مخاطب ذخیره‌شده", "Saved contact") else tr("مخاطب نیست", "Not in contacts"), color = if (isContact) p.sub else p.danger, fontSize = 13.sp)
            }
            Spacer(Modifier.height(18.dp))

            if (!isContact && shown.any { it.isDigit() }) {
                val addShape = RoundedCornerShape(18.dp)
                Row(Modifier.fillMaxWidth().clip(addShape).background(p.surface).border(1.dp, p.primary.copy(alpha = .6f), addShape)
                    .clickable { nav.value = Screen.ContactForm(0, "", shown) }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(38.dp).clip(CircleShape).background(p.primary), contentAlignment = Alignment.Center) { Icon(Icons.Default.PersonAdd, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(tr("افزودن به مخاطبین", "Add to contacts"), color = p.text, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(tr("ذخیره این شماره به‌عنوان مخاطب جدید", "Save this number as a new contact"), color = p.sub, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(14.dp))
            }

            if (number.isNotBlank()) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DetailAction(Icons.Default.Call, tr("تماس", "Call"), true, modifier = Modifier.weight(1f)) { dial(act, number) }
                    DetailAction(Icons.Default.ChatBubble, tr("پیام", "Message"), false, modifier = Modifier.weight(1f)) { openChat(act, number) }
                    DetailAction(Icons.Default.ContentCopy, tr("کپی", "Copy"), false, modifier = Modifier.weight(1f)) { copyPhoneNumber(act, number) }
                    DetailAction(Icons.Default.Block, if (blocked) tr("رفع مسدودی", "Unblock") else tr("مسدود", "Block"), false, tint = if (blocked) p.danger else null, modifier = Modifier.weight(1f)) {
                        blockNumber(number, !blocked); blocked = isBlockedNumber(number)
                    }
                }
                Spacer(Modifier.height(20.dp))
            }

            Text(tr("سابقه تماس‌ها", "Call history") + " · " + listNum(rows.size.toString()), color = p.primary, fontSize = 15.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp, start = 4.dp), style = TextStyle(textDirection = TextDirection.Content, textAlign = TextAlign.Start))
            val cardShape = RoundedCornerShape(20.dp)
            Column(Modifier.fillMaxWidth().clip(cardShape).background(p.surface).border(1.dp, p.line, cardShape)) {
                if (rows.isEmpty()) Text(tr("سابقه‌ای ثبت نشده", "No call records"), color = p.sub, modifier = Modifier.padding(20.dp))
                rows.forEachIndexed { i, r ->
                    val bad = r.type == CallLog.Calls.MISSED_TYPE || r.type == CallLog.Calls.REJECTED_TYPE
                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).clip(CircleShape).background(if (bad) p.danger.copy(alpha = .18f) else p.nav), contentAlignment = Alignment.Center) {
                            Icon(callTypeIcon(r.type), null, tint = if (bad) p.danger else p.sub, modifier = Modifier.size(22.dp))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(callTypeLabel(r.type), color = if (bad) p.danger else p.text, fontWeight = FontWeight.Bold, fontSize = 17.sp, style = TextStyle(textDirection = TextDirection.Content))
                            Text(fmtCallDateTime(r.date), color = p.sub, fontSize = 15.sp, modifier = Modifier.padding(top = 2.dp), style = TextStyle(textDirection = TextDirection.Content))
                        }
                        Text(if (r.dur > 0) listNum(fmtDur(r.dur)) else "—", color = p.sub, fontSize = 15.sp, style = TextStyle(textDirection = TextDirection.Ltr))
                    }
                    if (i < rows.lastIndex) HorizontalDivider(color = p.line.copy(alpha = .6f))
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
