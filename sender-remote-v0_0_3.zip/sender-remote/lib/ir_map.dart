import 'package:flutter/material.dart';

import 'ir.dart';
import 'theme.dart';

/// ویرایشگر «تخصیص دکمه‌ها»: برای هر دکمه‌ی ریموت انتخاب می‌کنید کدام کد IR ارسال شود.
Future<void> showIrMapDialog(BuildContext context, IrController ir) {
  return showDialog<void>(
    context: context,
    builder: (_) => Dialog(
      backgroundColor: const Color(0xff0c1124),
      insetPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: kBlue.withOpacity(0.6)),
      ),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 560, maxHeight: MediaQuery.of(context).size.height * 0.85),
        child: Padding(padding: const EdgeInsets.all(14), child: IrMapPanel(ir: ir)),
      ),
    ),
  );
}

class IrMapPanel extends StatelessWidget {
  final IrController ir;
  const IrMapPanel({super.key, required this.ir});

  Future<void> _pick(BuildContext context, String target) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => Dialog(
        backgroundColor: const Color(0xff0c1124),
        insetPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 24),
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 520, maxHeight: MediaQuery.of(ctx).size.height * 0.8),
          child: ListenableBuilder(
            listenable: ir,
            builder: (_, __) {
              final keys = <String>[
                for (final e in kIrButtons)
                  if (ir.codes.containsKey(e.key)) e.key,
                for (final k in ir.codes.keys)
                  if (k.startsWith('x:')) k,
              ];
              return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 4),
                  child: Text('دکمه‌ی «${irButtonLabel(target)}» کدام کد را بفرستد؟',
                      textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
                ),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 14),
                  child: Text('▶ تست • روی ردیف بزنید تا انتخاب شود • ⇄ جابه‌جایی دو دکمه',
                      textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: kHint)),
                ),
                Flexible(
                  child: ListView(shrinkWrap: true, children: [
                    ListTile(
                      dense: true,
                      leading: const Icon(Icons.block, size: 20),
                      title: const Text('بدون کد (خالی)'),
                      onTap: () {
                        ir.assignCode(target, null);
                        Navigator.of(ctx).pop();
                      },
                    ),
                    for (final k in keys)
                      ListTile(
                        dense: true,
                        selected: k == target,
                        title: Text(irButtonLabel(k)),
                        subtitle: Text(ir.codes[k]!.label, style: const TextStyle(fontSize: 10)),
                        onTap: () {
                          if (k != target) ir.assignCode(target, ir.codes[k]);
                          Navigator.of(ctx).pop();
                        },
                        trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                          IconButton(
                            tooltip: 'تست',
                            icon: const Icon(Icons.play_arrow),
                            onPressed: () => ir.sendCode(ir.codes[k]!),
                          ),
                          if (!k.startsWith('x:') && k != target)
                            IconButton(
                              tooltip: 'جابه‌جایی با این دکمه',
                              icon: const Icon(Icons.swap_horiz),
                              onPressed: () {
                                ir.swapCodes(target, k);
                                Navigator.of(ctx).pop();
                              },
                            ),
                        ]),
                      ),
                  ]),
                ),
                TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('بستن')),
              ]);
            },
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: ir,
      builder: (context, _) {
        return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('تخصیص دکمه‌ها — ${ir.active.name}',
              textAlign: TextAlign.center, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
          const SizedBox(height: 4),
          const Text(
            'روی هر دکمه بزنید تا یکی از کدهای این پروفایل را برایش انتخاب کنید (با تست). می‌توانید دو دکمه را هم جابه‌جا کنید.',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 11, color: kHint),
          ),
          const SizedBox(height: 6),
          Flexible(
            child: ListView(shrinkWrap: true, children: [
              for (final e in kIrButtons)
                ListTile(
                  dense: true,
                  title: Text(e.value),
                  subtitle: Text(ir.codes[e.key]?.label ?? 'کد ندارد',
                      style: TextStyle(fontSize: 10, color: ir.codes.containsKey(e.key) ? null : const Color(0xffffa23c))),
                  onTap: () => _pick(context, e.key),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(
                      tooltip: 'تست',
                      icon: const Icon(Icons.play_arrow),
                      onPressed: ir.codes.containsKey(e.key) ? () => ir.sendCode(ir.codes[e.key]!) : null,
                    ),
                    const Icon(Icons.chevron_right, size: 18),
                  ]),
                ),
            ]),
          ),
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('بستن')),
        ]);
      },
    );
  }
}
