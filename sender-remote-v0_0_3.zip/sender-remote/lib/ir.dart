import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// برای نمایش پیام (مثلاً «برای این دکمه کد IR ذخیره نشده») از هرجا.
final GlobalKey<ScaffoldMessengerState> irMessengerKey = GlobalKey<ScaffoldMessengerState>();

/// دکمه‌هایی که می‌شود برایشان کد IR ذخیره کرد (نام‌ها همان کلیدهای Wi-Fi هستند).
const List<MapEntry<String, String>> kIrButtons = [
  MapEntry('POWER', 'پاور (خاموش / اصلی)'),
  MapEntry('POWER_ON', 'روشن‌کردن (Wake) — نگه‌داشتن پاور'),
  MapEntry('MUTE', 'بی‌صدا'),
  MapEntry('HOME', 'خانه'),
  MapEntry('BACK', 'برگشت'),
  MapEntry('RECENTS', 'منو'),
  MapEntry('QUICK_SETTINGS', 'تنظیمات'),
  MapEntry('NOTIFICATIONS', 'ورودی / TV'),
  MapEntry('UP', 'بالا'),
  MapEntry('DOWN', 'پایین'),
  MapEntry('LEFT', 'چپ'),
  MapEntry('RIGHT', 'راست'),
  MapEntry('ENTER', 'OK'),
  MapEntry('VOL_UP', 'صدا +'),
  MapEntry('VOL_DOWN', 'صدا −'),
  MapEntry('CH_UP', 'کانال +'),
  MapEntry('CH_DOWN', 'کانال −'),
  MapEntry('PLAY_PAUSE', 'پخش / مکث'),
  MapEntry('PREV', 'قبلی'),
  MapEntry('NEXT', 'بعدی'),
  MapEntry('MIC', 'میکروفون'),
  MapEntry('RED', 'قرمز'),
  MapEntry('GREEN', 'سبز'),
  MapEntry('YELLOW', 'زرد'),
  MapEntry('BLUE', 'آبی'),
  MapEntry('INFO', 'INFO'),
  MapEntry('TEXT', 'TEXT'),
  MapEntry('EPG', 'EPG'),
  MapEntry('BACKSPACE', 'DEL'),
  MapEntry('0', '0'),
  MapEntry('1', '1'),
  MapEntry('2', '2'),
  MapEntry('3', '3'),
  MapEntry('4', '4'),
  MapEntry('5', '5'),
  MapEntry('6', '6'),
  MapEntry('7', '7'),
  MapEntry('8', '8'),
  MapEntry('9', '9'),
];

String irButtonLabel(String key) {
  if (key.startsWith('x:')) return 'Mi · ${key.substring(2)}';
  for (final e in kIrButtons) {
    if (e.key == key) return e.value;
  }
  return key;
}

/// یک کد IR. proto یکی از:
/// 'nec' (آدرس ۸بیتی + معکوس) • 'necx' (آدرس ۱۶بیتی) • 'rc5' • 'rc6'
/// 'nec32' (NEC کامل ۳۲بیتی: آدرس ۱۶بیتی + دستور ۱۶بیتی بدون محاسبه‌ی معکوس) • 'raw' (الگوی زمانی خام، مثل کدهای Mi Remote)
/// 'samsung' (Samsung32) • 'sony12' / 'sony15' / 'sony20' (Sony SIRC) • 'panasonic' (Kaseikyo، آدرس ۱۶بیتی = دو بایت دستگاه)
class IrCode {
  final String proto;
  final int addr;
  final int cmd;

  /// فقط برای proto == 'raw': الگوی زمانی (µs: روشن، خاموش، ...) و نسخه‌ی toggle (اختیاری) و فرکانس.
  final List<int>? raw;
  final List<int>? rawAlt;
  final int? rawFreq;
  const IrCode(this.proto, this.addr, this.cmd, {this.raw, this.rawAlt, this.rawFreq});

  bool get isRaw => proto == 'raw';

  Map<String, Object> toJson() => isRaw
      ? {'p': 'raw', 'f': rawFreq ?? 38000, 'r': raw ?? const <int>[], if (rawAlt != null) 'r2': rawAlt!}
      : {'p': proto, 'a': addr, 'c': cmd};

  static List<int>? _ints(Object? v) => v is List ? [for (final x in v) (x as num).toInt()] : null;

  static IrCode? fromJson(Object? j) {
    if (j is! Map) return null;
    if (j['p'] == 'raw') {
      final r = _ints(j['r']);
      if (r == null || r.isEmpty) return null;
      return IrCode('raw', 0, 0, raw: r, rawAlt: _ints(j['r2']), rawFreq: (j['f'] as num?)?.toInt() ?? 38000);
    }
    final p = j['p'];
    final a = j['a'];
    final c = j['c'];
    if (p is! String || a is! int || c is! int) return null;
    return IrCode(p, a, c);
  }

  bool get isRc => proto == 'rc5' || proto == 'rc6';

  bool get isSony => proto == 'sony12' || proto == 'sony15' || proto == 'sony20';

  /// فرکانس حامل: RC5/RC6 = ۳۶kHz ، Sony = ۴۰kHz ، Panasonic = ۳۷kHz ، بقیه (NEC/Samsung) = ۳۸kHz
  int get freq {
    if (isRaw) return rawFreq ?? 38000;
    if (isRc) return 36000;
    if (isSony) return 40000;
    if (proto == 'panasonic') return 37000;
    return 38000;
  }

  String get protoName => switch (proto) {
        'necx' => 'NECx',
        'nec32' => 'NEC 32bit',
        'raw' => 'Raw',
        'rc5' => 'RC5',
        'rc6' => 'RC6',
        'samsung' => 'Samsung32',
        'sony12' => 'Sony SIRC-12',
        'sony15' => 'Sony SIRC-15',
        'sony20' => 'Sony SIRC-20',
        'panasonic' => 'Panasonic',
        _ => 'NEC',
      };

  /// تعداد رقم hex آدرس برای نمایش
  int get addrWidth => (proto == 'necx' || proto == 'nec32' || proto == 'panasonic' || proto == 'sony20') ? 4 : 2;

  String get label {
    if (isRaw) return 'Raw  ${(freq / 1000).toStringAsFixed(1)}kHz  ${raw?.length ?? 0} پالس';
    final a = addr.toRadixString(16).toUpperCase().padLeft(addrWidth, '0');
    final c = cmd.toRadixString(16).toUpperCase().padLeft(proto == 'nec32' ? 4 : 2, '0');
    return '$protoName  A=0x$a  C=0x$c';
  }

  /// الگوی زمانی (میکروثانیه): روشن، خاموش، روشن، ... ([toggle] فقط برای RC5/RC6)
  List<int> pattern({bool toggle = false}) {
    if (isRaw) return (toggle && rawAlt != null) ? rawAlt! : (raw ?? const <int>[]);
    if (proto == 'rc5') return _rc5(toggle);
    if (proto == 'rc6') return _rc6(toggle);
    if (proto == 'samsung') return _samsung();
    if (isSony) return _sony();
    if (proto == 'panasonic') return _panasonic();
    return _nec();
  }

  // Samsung32: رهبر ۴۵۰۰/۴۵۰۰، بایت‌ها LSB-اول: [آدرس، آدرس، دستور، ~دستور]
  List<int> _samsung() {
    final bytes = [addr & 0xff, addr & 0xff, cmd & 0xff, (~cmd) & 0xff];
    final p = <int>[4500, 4500];
    for (final b in bytes) {
      for (var i = 0; i < 8; i++) {
        p.add(560);
        p.add(((b >> i) & 1) == 1 ? 1690 : 560);
      }
    }
    p.add(560);
    p.add(40000);
    return p;
  }

  // Sony SIRC (۴۰kHz): رهبر ۲۴۰۰/۶۰۰، بیت ۱ = ۱۲۰۰ روشن، بیت ۰ = ۶۰۰ روشن، فاصله ۶۰۰.
  // ۷ بیت دستور و بعد آدرس (۵، ۸ یا ۱۳ بیت)، LSB-اول. هر فریم ۴۵ms و سه بار تکرار می‌شود.
  List<int> _sony() {
    final addrBits = switch (proto) { 'sony12' => 5, 'sony15' => 8, _ => 13 };
    final bits = <int>[
      for (var i = 0; i < 7; i++) (cmd >> i) & 1,
      for (var i = 0; i < addrBits; i++) (addr >> i) & 1,
    ];
    final frame = <int>[2400, 600];
    for (final b in bits) {
      frame.add(b == 1 ? 1200 : 600);
      frame.add(600);
    }
    final used = frame.fold<int>(0, (a, b) => a + b) - 600;
    frame[frame.length - 1] = 45000 - used;
    return [...frame, ...frame, ...frame];
  }

  static int _rev8(int v) {
    var r = 0;
    for (var i = 0; i < 8; i++) {
      r = (r << 1) | ((v >> i) & 1);
    }
    return r;
  }

  // Panasonic (Kaseikyo، ۴۸ بیت، ~۳۷kHz): رهبر ۳۴۵۶/۱۷۲۸، بیت: ۴۳۲ + (۱۲۹۶ یا ۴۳۲).
  // بایت‌ها: ۴۰ ۰۴ D1 D2 CMD CHK (MSB-اول). addr = D1<<8|D2 (تی‌وی پاناسونیک معمولاً ۰۱۰۰)،
  // دستور به شکل IRremote (مثلاً پاور = ۳D) ذخیره می‌شود و روی هوا بیت‌معکوس می‌رود؛ CHK = D1^D2^CMD.
  List<int> _panasonic() {
    final d1 = (addr >> 8) & 0xff;
    final d2 = addr & 0xff;
    final c = _rev8(cmd & 0xff);
    final bytes = [0x40, 0x04, d1, d2, c, d1 ^ d2 ^ c];
    final p = <int>[3456, 1728];
    for (final b in bytes) {
      for (var i = 7; i >= 0; i--) {
        p.add(432);
        p.add(((b >> i) & 1) == 1 ? 1296 : 432);
      }
    }
    p.add(432);
    p.add(40000);
    return p;
  }

  // RC5: ۱۴ بیت منچستر، هر بیت ۱۷۷۸µs. [۱، ~بیت۶ دستور، toggle، آدرس ۵ بیت، دستور ۶ بیت]
  List<int> _rc5(bool toggle) {
    final bits = <int>[1, ((cmd >> 6) & 1) == 1 ? 0 : 1, toggle ? 1 : 0];
    for (var i = 4; i >= 0; i--) {
      bits.add((addr >> i) & 1);
    }
    for (var i = 5; i >= 0; i--) {
      bits.add((cmd >> i) & 1);
    }
    final levels = <bool>[];
    for (final b in bits) {
      if (b == 1) {
        levels.add(false);
        levels.add(true);
      } else {
        levels.add(true);
        levels.add(false);
      }
    }
    return _runs(levels, 889);
  }

  // RC6 حالت ۰: رهبر ۶t/۲t، بیت شروع، حالت ۰۰۰، toggle (دوبرابر)، آدرس ۸ بیت، دستور ۸ بیت (t=444µs)
  List<int> _rc6(bool toggle) {
    final levels = <bool>[];
    for (var i = 0; i < 6; i++) {
      levels.add(true);
    }
    levels.add(false);
    levels.add(false);
    void bit(int b, [int w = 1]) {
      for (var i = 0; i < w; i++) {
        levels.add(b == 1);
      }
      for (var i = 0; i < w; i++) {
        levels.add(b != 1);
      }
    }

    bit(1);
    bit(0);
    bit(0);
    bit(0);
    bit(toggle ? 1 : 0, 2);
    for (var i = 7; i >= 0; i--) {
      bit((addr >> i) & 1);
    }
    for (var i = 7; i >= 0; i--) {
      bit((cmd >> i) & 1);
    }
    return _runs(levels, 444);
  }

  /// سطح‌های پشت‌سرهم (true = روشن) را به مدت‌های زمانی تبدیل می‌کند؛ همیشه با «روشن» شروع و زوج‌تعداد.
  static List<int> _runs(List<bool> levels, int unit) {
    final runs = <MapEntry<bool, int>>[];
    var cur = levels.first;
    var n = 0;
    for (final l in levels) {
      if (l == cur) {
        n++;
      } else {
        runs.add(MapEntry(cur, n * unit));
        cur = l;
        n = 1;
      }
    }
    runs.add(MapEntry(cur, n * unit));
    if (!runs.first.key) runs.removeAt(0);
    final p = <int>[for (final r in runs) r.value];
    if (p.length.isOdd) {
      p.add(40000);
    } else {
      p[p.length - 1] += 40000;
    }
    return p;
  }

  List<int> _nec() {
    final bytes = <int>[];
    if (proto == 'necx' || proto == 'nec32') {
      bytes.addAll([addr & 0xff, (addr >> 8) & 0xff]);
    } else {
      bytes.addAll([addr & 0xff, (~addr) & 0xff]);
    }
    if (proto == 'nec32') {
      bytes.addAll([cmd & 0xff, (cmd >> 8) & 0xff]); // NEC کامل: بدون معکوس
    } else {
      bytes.addAll([cmd & 0xff, (~cmd) & 0xff]);
    }
    final p = <int>[9000, 4500];
    for (final b in bytes) {
      for (var i = 0; i < 8; i++) {
        p.add(560);
        p.add(((b >> i) & 1) == 1 ? 1690 : 560);
      }
    }
    p.add(560);
    p.add(40000); // فاصله‌ی پایانی (الگو زوج می‌ماند)
    return p;
  }
}

/// یک پروفایل دستگاه (مثلاً «تی‌وی اتاق»، «Android Box») با کدهای IR خودش.
class IrProfile {
  String name;

  /// true = دستگاه Wi-Fi ندارد (مثلاً تی‌وی معمولی)؛ همیشه با IR ارسال شود.
  bool irOnly;
  final Map<String, IrCode> codes;
  IrProfile(this.name, {this.irOnly = false, Map<String, IrCode>? codes}) : codes = codes ?? {};

  Map<String, Object> toJson() => {
        'n': name,
        'o': irOnly,
        'k': {for (final e in codes.entries) e.key: e.value.toJson()},
      };

  static IrProfile? fromJson(Object? j) {
    if (j is! Map) return null;
    final n = j['n'];
    if (n is! String) return null;
    final pr = IrProfile(n, irOnly: j['o'] == true);
    final k = j['k'];
    if (k is Map) {
      for (final e in k.entries) {
        final c = IrCode.fromJson(e.value);
        if (c != null) pr.codes[e.key.toString()] = c;
      }
    }
    return pr;
  }
}

/// کنترل ارسال IR + ذخیره‌ی کدها + انتخاب حالت (خودکار / فقط Wi-Fi / فقط IR).
class IrController extends ChangeNotifier {
  static const MethodChannel _ch = MethodChannel('abtin/ir');

  bool hasEmitter = false;

  /// 0 = خودکار (Wi-Fi وصل بود Wi-Fi، وگرنه IR) ، 1 = فقط Wi-Fi ، 2 = فقط IR
  int mode = 0;

  /// پاور (در صورت داشتن کد) همیشه با IR فرستاده شود تا از حالت خاموش هم روشن کند.
  bool powerViaIr = true;

  // وضعیت اسکن (تا با بستن پنجره از صفر شروع نشود)
  String scanTarget = 'POWER';
  String scanProto = 'nec';
  bool scanCommon = true;
  double scanInterval = 350;
  int scanIdx = 0;
  String scanAddr = '00';
  String scanCmd = '00';

  final List<IrProfile> profiles = [];
  int activeIdx = 0;
  IrProfile get active => profiles[activeIdx];
  Map<String, IrCode> get codes => active.codes;
  DateTime _lastToast = DateTime.fromMillisecondsSinceEpoch(0);

  IrController() {
    _load();
  }

  Future<void> _load() async {
    try {
      hasEmitter = (await _ch.invokeMethod<bool>('hasIr')) ?? false;
    } catch (_) {
      hasEmitter = false;
    }
    try {
      final p = await SharedPreferences.getInstance();
      mode = p.getInt('ir_mode') ?? 0;
      powerViaIr = p.getBool('ir_power') ?? true;
      scanTarget = p.getString('scan_target') ?? 'POWER';
      scanProto = p.getString('scan_proto') ?? 'nec';
      scanCommon = p.getBool('scan_common') ?? true;
      scanInterval = p.getDouble('scan_interval') ?? 350;
      scanIdx = p.getInt('scan_idx') ?? 0;
      scanAddr = p.getString('scan_addr') ?? '00';
      scanCmd = p.getString('scan_cmd') ?? '00';
      final rawP = p.getString('ir_profiles');
      if (rawP != null) {
        final j = jsonDecode(rawP);
        if (j is List) {
          for (final e in j) {
            final pr = IrProfile.fromJson(e);
            if (pr != null) profiles.add(pr);
          }
        }
      } else {
        // مهاجرت از نسخه‌ی ۲.۷.۰ (یک مجموعه کد)
        final raw = p.getString('ir_codes');
        final pr = IrProfile('Android Box');
        if (raw != null) {
          final j = jsonDecode(raw);
          if (j is Map) {
            for (final e in j.entries) {
              final c = IrCode.fromJson(e.value);
              if (c != null) pr.codes[e.key.toString()] = c;
            }
          }
        }
        profiles.add(pr);
      }
      activeIdx = p.getInt('ir_active') ?? 0;
    } catch (_) {}
    if (profiles.isEmpty) profiles.add(IrProfile('Android Box'));
    if (activeIdx < 0 || activeIdx >= profiles.length) activeIdx = 0;
    notifyListeners();
  }

  Future<void> _save() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setInt('ir_mode', mode);
      await p.setBool('ir_power', powerViaIr);
      await p.setString('ir_profiles', jsonEncode([for (final pr in profiles) pr.toJson()]));
      await p.setInt('ir_active', activeIdx);
    } catch (_) {}
  }

  Future<void> saveScan() async {
    try {
      final p = await SharedPreferences.getInstance();
      await p.setString('scan_target', scanTarget);
      await p.setString('scan_proto', scanProto);
      await p.setBool('scan_common', scanCommon);
      await p.setDouble('scan_interval', scanInterval);
      await p.setInt('scan_idx', scanIdx);
      await p.setString('scan_addr', scanAddr);
      await p.setString('scan_cmd', scanCmd);
    } catch (_) {}
  }

  void setMode(int m) {
    mode = m;
    notifyListeners();
    _save();
  }

  void setPowerViaIr(bool v) {
    powerViaIr = v;
    notifyListeners();
    _save();
  }

  void selectProfile(int i) {
    if (i < 0 || i >= profiles.length) return;
    activeIdx = i;
    notifyListeners();
    _save();
  }

  void addProfile(String name, {bool irOnly = false}) {
    final n = name.trim().isEmpty ? 'دستگاه ${profiles.length + 1}' : name.trim();
    profiles.add(IrProfile(n, irOnly: irOnly));
    activeIdx = profiles.length - 1;
    notifyListeners();
    _save();
  }

  void renameActive(String name) {
    final n = name.trim();
    if (n.isEmpty) return;
    active.name = n;
    notifyListeners();
    _save();
  }

  void setActiveIrOnly(bool v) {
    active.irOnly = v;
    notifyListeners();
    _save();
  }

  /// حذف پروفایل فعال (حداقل یکی می‌ماند).
  void deleteActive() {
    if (profiles.length <= 1) return;
    profiles.removeAt(activeIdx);
    activeIdx = 0;
    notifyListeners();
    _save();
  }

  /// پروفایل آماده‌ی فیلیپس با کدهای استاندارد (آدرس ۰ = تی‌وی). دکمه‌های ناوبری را با اسکنر پیدا کنید.
  void addPhilips(String proto) {
    final pr = IrProfile(proto == 'rc6' ? 'Philips RC6' : 'Philips RC5', irOnly: true);
    const m = <String, int>{
      'POWER': 12,
      'POWER_ON': 12,
      'MUTE': 13,
      'INFO': 15,
      'VOL_UP': 16,
      'VOL_DOWN': 17,
      'CH_UP': 32,
      'CH_DOWN': 33,
      '0': 0,
      '1': 1,
      '2': 2,
      '3': 3,
      '4': 4,
      '5': 5,
      '6': 6,
      '7': 7,
      '8': 8,
      '9': 9,
    };
    for (final e in m.entries) {
      pr.codes[e.key] = IrCode(proto, 0, e.value);
    }
    profiles.add(pr);
    activeIdx = profiles.length - 1;
    notifyListeners();
    _save();
  }

  void _addPreset(String name, String proto, int addr, Map<String, int> m) {
    final pr = IrProfile(name, irOnly: true);
    for (final e in m.entries) {
      pr.codes[e.key] = IrCode(proto, addr, e.value);
    }
    profiles.add(pr);
    activeIdx = profiles.length - 1;
    notifyListeners();
    _save();
  }

  /// پروفایل آماده‌ی سامسونگ (Samsung32، آدرس ۰x07 = تی‌وی). بسته به مدل ممکن است چند دکمه فرق کند.
  void addSamsung() => _addPreset('Samsung TV', 'samsung', 0x07, const {
        'POWER': 0x02,
        'MUTE': 0x0F,
        'HOME': 0x79,
        'BACK': 0x58,
        'RECENTS': 0x1A,
        'NOTIFICATIONS': 0x01,
        'UP': 0x60,
        'DOWN': 0x61,
        'LEFT': 0x65,
        'RIGHT': 0x62,
        'ENTER': 0x68,
        'VOL_UP': 0x07,
        'VOL_DOWN': 0x0B,
        'CH_UP': 0x12,
        'CH_DOWN': 0x10,
        'INFO': 0x1F,
        'RED': 0x6C,
        'GREEN': 0x14,
        'YELLOW': 0x15,
        'BLUE': 0x16,
        '1': 0x04,
        '2': 0x05,
        '3': 0x06,
        '4': 0x08,
        '5': 0x09,
        '6': 0x0A,
        '7': 0x0C,
        '8': 0x0D,
        '9': 0x0E,
        '0': 0x11,
      });

  /// پروفایل آماده‌ی سونی (SIRC ۱۲بیتی، دستگاه ۱ = تی‌وی).
  void addSony() => _addPreset('Sony TV', 'sony12', 1, const {
        'POWER': 0x15,
        'POWER_ON': 0x2E,
        'MUTE': 0x14,
        'HOME': 0x60,
        'BACK': 0x23,
        'NOTIFICATIONS': 0x25,
        'UP': 0x74,
        'DOWN': 0x75,
        'LEFT': 0x34,
        'RIGHT': 0x33,
        'ENTER': 0x65,
        'VOL_UP': 0x12,
        'VOL_DOWN': 0x13,
        'CH_UP': 0x10,
        'CH_DOWN': 0x11,
        'INFO': 0x3A,
        '1': 0,
        '2': 1,
        '3': 2,
        '4': 3,
        '5': 4,
        '6': 5,
        '7': 6,
        '8': 7,
        '9': 8,
        '0': 9,
      });

  /// پروفایل آماده‌ی پاناسونیک (Kaseikyo، آدرس ۰x0100 = تی‌وی). فقط دکمه‌های پایه؛ بقیه را با اسکنر پیدا کنید.
  void addPanasonic() => _addPreset('Panasonic TV', 'panasonic', 0x0100, const {
        'POWER': 0x3D,
        'MUTE': 0x32,
        'VOL_UP': 0x20,
        'VOL_DOWN': 0x21,
        'CH_UP': 0x34,
        'CH_DOWN': 0x35,
      });

  /// پروفایل ساخته‌شده از کتابخانه‌ی Mi (کدهای خام؛ همیشه IR).
  void addMiProfile(String name, Map<String, IrCode> codes) {
    final pr = IrProfile(name, irOnly: true);
    pr.codes.addAll(codes);
    profiles.add(pr);
    activeIdx = profiles.length - 1;
    notifyListeners();
    _save();
  }

  /// کد دکمه‌ی [key] را عوض می‌کند (null = حذف).
  void assignCode(String key, IrCode? c) {
    if (c == null) {
      codes.remove(key);
    } else {
      codes[key] = c;
    }
    notifyListeners();
    _save();
  }

  /// جابه‌جایی کد دو دکمه.
  void swapCodes(String a, String b) {
    final ca = codes[a];
    final cb = codes[b];
    if (cb == null) {
      codes.remove(a);
    } else {
      codes[a] = cb;
    }
    if (ca == null) {
      codes.remove(b);
    } else {
      codes[b] = ca;
    }
    notifyListeners();
    _save();
  }

  /// پروفایل آماده‌ی ال‌جی (NEC، آدرس ۰x04).
  void addLg() => _addPreset('LG TV', 'nec', 0x04, const {
        'POWER': 0x08,
        'MUTE': 0x09,
        'HOME': 0x7C,
        'BACK': 0x28,
        'RECENTS': 0x43,
        'NOTIFICATIONS': 0x0B,
        'UP': 0x40,
        'DOWN': 0x41,
        'LEFT': 0x07,
        'RIGHT': 0x06,
        'ENTER': 0x44,
        'VOL_UP': 0x02,
        'VOL_DOWN': 0x03,
        'CH_UP': 0x00,
        'CH_DOWN': 0x01,
        'INFO': 0xAA,
        '0': 0x10,
        '1': 0x11,
        '2': 0x12,
        '3': 0x13,
        '4': 0x14,
        '5': 0x15,
        '6': 0x16,
        '7': 0x17,
        '8': 0x18,
        '9': 0x19,
      });

  void setCode(String key, IrCode c) {
    codes[key] = c;
    notifyListeners();
    _save();
  }

  void removeCode(String key) {
    codes.remove(key);
    notifyListeners();
    _save();
  }

  void clearCodes() {
    codes.clear();
    notifyListeners();
    _save();
  }

  /// این کلید با IR فرستاده شود یا Wi-Fi؟
  bool useIrFor(String key, bool wifiConnected) {
    if (!hasEmitter) return false;
    if (active.irOnly) return true;
    if (key == 'POWER' && powerViaIr && codes.containsKey('POWER') && mode != 1) return true;
    if (mode == 1) return false;
    if (mode == 2) return true;
    return !wifiConnected;
  }

  bool _tog = false;

  Future<bool> sendCode(IrCode c) async {
    try {
      final t = _tog;
      _tog = !_tog; // RC5/RC6: با هر فشار toggle عوض می‌شود
      final ok = await _ch.invokeMethod<bool>('transmit', {'freq': c.freq, 'pattern': c.pattern(toggle: t)});
      return ok ?? false;
    } catch (_) {
      return false;
    }
  }

  /// ارسال کد ذخیره‌شده‌ی یک دکمه. اگر کدی نباشد پیام می‌دهد.
  Future<void> sendKey(String key) async {
    final c = codes[key];
    if (c == null) {
      _toast('برای «${irButtonLabel(key)}» هنوز کد IR ذخیره نشده');
      return;
    }
    final ok = await sendCode(c);
    if (!ok) _toast('ارسال IR انجام نشد؛ گوشی فرستنده‌ی IR ندارد؟');
  }

  void _toast(String msg) {
    final now = DateTime.now();
    if (now.difference(_lastToast).inMilliseconds < 1500) return;
    _lastToast = now;
    irMessengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 2)));
  }
}
