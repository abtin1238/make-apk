import 'package:flutter/material.dart';

import 'bt.dart';
import 'theme.dart';

Future<void> showBtDialog(BuildContext context, BtHidLink bt, {String initialPin = ''}) {
  return showDialog<void>(
    context: context,
    builder: (_) => Dialog(
      backgroundColor: const Color(0xff0c1124),
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: kBlue.withOpacity(0.6)),
      ),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 520),
        child: Padding(padding: const EdgeInsets.all(14), child: _BtPanel(bt: bt, initialPin: initialPin)),
      ),
    ),
  );
}

class _BtPanel extends StatefulWidget {
  final BtHidLink bt;
  final String initialPin;
  const _BtPanel({required this.bt, required this.initialPin});
  @override
  State<_BtPanel> createState() => _BtPanelState();
}

class _BtPanelState extends State<_BtPanel> {
  bool busy = false;
  late final TextEditingController receiverPin = TextEditingController(text: widget.initialPin);

  BtHidLink get bt => widget.bt;

  @override
  void initState() { super.initState(); WidgetsBinding.instance.addPostFrameCallback((_) => bt.refreshRfcommBonded()); }

  @override
  void dispose() { receiverPin.dispose(); super.dispose(); }

  Future<void> _prepare() async {
    setState(() => busy = true);
    await bt.init();
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: bt,
      builder: (context, _) {
        return SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('اتصال بلوتوث', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(
                bt.status,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: bt.connected ? const Color(0xff3dff8f) : kHint),
              ),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: const Color(0xff17233d), borderRadius: BorderRadius.circular(12), border: Border.all(color: kCyan.withOpacity(0.55))),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  const Text('بلوتوث (گیرنده) — بدون HID', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold, color: kCyan)),
                  const SizedBox(height: 4),
                  Text(bt.rfcommStatus, textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: bt.rfcommAuthenticated ? const Color(0xff3dff8f) : kHint)),
                  const SizedBox(height: 4),
                  const Text('در اپ تلویزیون دکمه «فعال‌سازی بلوتوث گیرنده» را بزنید و گوشی و تلویزیون را Pair کنید. سپس دستگاه تلویزیون را انتخاب کنید.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: kHint)),
                  const SizedBox(height: 6),
                  TextField(controller: receiverPin, keyboardType: TextInputType.number, maxLength: 4, decoration: const InputDecoration(labelText: 'PIN گیرنده (۴ رقم)', counterText: '', isDense: true)),
                  if (bt.rfcommAuthenticated)
                    OutlinedButton.icon(onPressed: bt.disconnectRfcomm, icon: const Icon(Icons.link_off), label: const Text('قطع بلوتوث گیرنده'))
                  else ...[
                    OutlinedButton.icon(onPressed: bt.refreshRfcommBonded, icon: const Icon(Icons.refresh), label: const Text('تازه‌سازی دستگاه‌های Pair شده')),
                    for (final d in bt.bonded)
                      ListTile(dense: true, contentPadding: EdgeInsets.zero, leading: const Icon(Icons.tv), title: Text(d.name.isEmpty ? d.address : d.name), subtitle: Text(d.address, style: const TextStyle(fontSize: 10)), trailing: const Icon(Icons.bluetooth_connected, color: kCyan), onTap: bt.rfcommConnecting ? null : () async { await bt.connectRfcomm(d.address, receiverPin.text); }),
                    TextButton.icon(onPressed: bt.openSettings, icon: const Icon(Icons.settings_bluetooth, size: 16), label: const Text('Pair کردن / تنظیمات بلوتوث')),
                  ],
                ]),
              ),
              const SizedBox(height: 10),
              const Text('Bluetooth HID — اتصال مستقیم به‌عنوان موس و کیبورد', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              if (!bt.supported)
                const Text(
                  'این گوشی از حالت «دستگاه HID بلوتوث» پشتیبانی نمی‌کند (نیاز به Android 9 یا بالاتر و بلوتوث روشن).',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xffffa23c), fontSize: 12),
                )
              else ...[
                const Text(
                  'گوشی خودش را به‌صورت کیبورد + موس + ریموت + دسته‌ی بازی بلوتوث نشان می‌دهد؛ روی باکس/تی‌وی اپ گیرنده لازم نیست.',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: kHint),
                ),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: busy ? null : _prepare,
                  icon: const Icon(Icons.bluetooth),
                  label: Text(bt.ready ? 'آماده است (دوباره ثبت)' : '۱) آماده‌سازی بلوتوث'),
                ),
                const SizedBox(height: 6),
                const Text(
                  'همه‌ی مراحل داخل همین اپ است: ۱) آماده‌سازی ← ۲) جستجو و انتخاب تی‌وی (جفت و وصل می‌شود). روی تی‌وی فقط صفحه‌ی تنظیمات بلوتوث را باز نگه دارید و اگر پیام تأیید آمد، تأیید کنید. اگر قبلاً از تنظیمات سیستم جفت کرده بودید، اول با سطل زباله‌ی پایین حذفش کنید.',
                  style: TextStyle(fontSize: 12, color: kHint),
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: (!bt.ready) ? null : (bt.scanning ? bt.stopScan : bt.scan),
                  icon: bt.scanning
                      ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.search, size: 18),
                  label: Text(bt.scanning ? 'در حال جستجو... (توقف)' : '۲) جستجوی دستگاه‌ها'),
                ),
                for (final d in bt.found.where((f) => !bt.bonded.any((b) => b.address == f.address)))
                  ListTile(
                    dense: true,
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.tv),
                    title: Text(d.name),
                    subtitle: Text(d.address, style: const TextStyle(fontSize: 11)),
                    trailing: const Text('جفت و وصل', style: TextStyle(fontSize: 12, color: kCyan)),
                    onTap: () => bt.pair(d.address),
                  ),
                const SizedBox(height: 4),
                Wrap(spacing: 8, runSpacing: 4, alignment: WrapAlignment.center, children: [
                  TextButton.icon(
                    onPressed: bt.makeDiscoverable,
                    icon: const Icon(Icons.visibility, size: 16),
                    label: const Text('قابل‌مشاهده برای تی‌وی', style: TextStyle(fontSize: 12)),
                  ),
                  TextButton.icon(
                    onPressed: bt.openSettings,
                    icon: const Icon(Icons.settings_bluetooth, size: 16),
                    label: const Text('تنظیمات بلوتوث', style: TextStyle(fontSize: 12)),
                  ),
                ]),
                const Divider(height: 18),
                Row(children: [
                  const Expanded(
                    child: Text('دستگاه‌های جفت‌شده (برای وصل شدن بزنید)', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                  ),
                  IconButton(onPressed: bt.refreshBonded, icon: const Icon(Icons.refresh), tooltip: 'تازه‌سازی'),
                ]),
                if (bt.bonded.isEmpty)
                  const Text('هنوز دستگاهی جفت نشده. مرحله‌ی ۲ را انجام دهید.',
                      style: TextStyle(fontSize: 12, color: kHint))
                else
                  for (final d in bt.bonded)
                    ListTile(
                      dense: true,
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.bluetooth),
                      title: Text(d.name),
                      subtitle: Text(d.address, style: const TextStyle(fontSize: 11)),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        if (bt.connected && bt.hostName == d.name)
                          const Icon(Icons.check_circle, color: Color(0xff3dff8f)),
                        IconButton(
                          icon: const Icon(Icons.delete_outline, size: 20),
                          tooltip: 'حذف جفت‌سازی',
                          onPressed: () => bt.unpair(d.address),
                        ),
                      ]),
                      onTap: bt.ready ? () => bt.connect(d.address) : null,
                    ),
                if (bt.connected)
                  TextButton(onPressed: bt.disconnect, child: const Text('قطع اتصال بلوتوث')),
                SwitchListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  title: const Text('اگر Wi-Fi هم وصل بود، بلوتوث استفاده شود', style: TextStyle(fontSize: 13)),
                  value: bt.preferBt,
                  onChanged: bt.setPreferBt,
                ),
                const Text(
                  'در حالت HID، قابلیت‌ها به پشتیبانی تلویزیون وابسته است. در حالت «بلوتوث (گیرنده)» متن فارسی و همه‌ی فرمان‌های Wi-Fi از طریق اپ گیرنده اجرا می‌شوند.',
                  style: TextStyle(fontSize: 11, color: kHint),
                ),
              ],
              const SizedBox(height: 6),
              TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('بستن')),
            ],
          ),
        );
      },
    );
  }
}
