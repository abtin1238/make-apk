/// How to run one language inside the Alpine (proot) environment of the app terminal.
class LangRunner {
  final String lang;
  final String title;

  /// Binary that must exist inside Alpine (checked with `command -v`).
  final String probe;

  /// Alpine packages to install when [probe] is missing ('' = nothing to install).
  final String pkgs;

  /// Shell command template: {f} = quoted file name, {out} = build output path.
  final String cmd;

  /// Rough download size of [pkgs] in MB (shown before installing).
  final int mb;
  const LangRunner(this.lang, this.title, this.probe, this.pkgs, this.cmd, {this.mb = 0});
}

/// What to do before running.
enum RunPre { none, install, bootstrap }

/// Pure-Dart parts of "Run code": runner table, shell script builder and the
/// filter that removes the script's control markers from the PTY output.
class CodeRunner {
  static const out = '/tmp/abtin_run.out';

  static const runners = <LangRunner>[
    LangRunner('python', 'Python', 'python3', 'python3', 'python3 -u {f}', mb: 40),
    LangRunner('js', 'JavaScript (Node.js)', 'node', 'nodejs', 'node {f}', mb: 40),
    LangRunner('ts', 'TypeScript (Node.js)', 'node', 'nodejs', 'node --experimental-strip-types --no-warnings {f}', mb: 40),
    LangRunner('c', 'C', 'gcc', 'gcc musl-dev', 'gcc -O1 -Wall {f} -o {out} -lm && {out}', mb: 150),
    LangRunner('cpp', 'C++', 'g++', 'g++ musl-dev', 'g++ -std=c++17 -O1 -Wall {f} -o {out} && {out}', mb: 160),
    LangRunner('java', 'Java', 'java', 'openjdk17', 'java {f}', mb: 200),
    LangRunner('go', 'Go', 'go', 'go', 'CGO_ENABLED=0 go run {f}', mb: 250),
    LangRunner('rust', 'Rust', 'rustc', 'rust gcc musl-dev', 'rustc -O {f} -o {out} && {out}', mb: 400),
    LangRunner('ruby', 'Ruby', 'ruby', 'ruby', 'ruby {f}', mb: 30),
    LangRunner('php', 'PHP', 'php83', 'php83', 'php83 {f}', mb: 20),
    LangRunner('perl', 'Perl', 'perl', 'perl', 'perl {f}', mb: 15),
    LangRunner('lua', 'Lua', 'lua5.4', 'lua5.4', 'lua5.4 {f}', mb: 2),
    LangRunner('bash', 'Shell', 'sh', '', 'sh {f}'),
    LangRunner('awk', 'AWK', 'awk', '', 'awk -f {f}'),
    LangRunner('haskell', 'Haskell', 'runghc', 'ghc', 'runghc {f}', mb: 500),
    LangRunner('elixir', 'Elixir', 'elixir', 'elixir', 'elixir {f}', mb: 100),
    LangRunner('fortran', 'Fortran', 'gfortran', 'gfortran musl-dev', 'gfortran {f} -o {out} && {out}', mb: 120),
    LangRunner('ocaml', 'OCaml', 'ocaml', 'ocaml', 'ocaml {f}', mb: 120),
    LangRunner('nim', 'Nim', 'nim', 'nim gcc musl-dev', 'nim c -r --hints:off -o:{out} {f}', mb: 200),
    LangRunner('zig', 'Zig', 'zig', 'zig', 'zig run {f}', mb: 250),
    LangRunner('tcl', 'Tcl', 'tclsh', 'tcl', 'tclsh {f}', mb: 5),
  ];

  static final Map<String, LangRunner> _byLang = {for (final r in runners) r.lang: r};

  /// Runner for a language id (null when the language cannot be run).
  static LangRunner? runnerFor(String lang) => _byLang[lang];

  static bool supports(String lang) => _byLang.containsKey(lang);

  /// Single-quotes [s] for a POSIX shell.
  static String shq(String s) => "'${s.replaceAll("'", "'\\''")}'";

  /// Exit code of the inner command meaning "the toolchain is not installed".
  static const missingCode = 199;

  static const _mark = r"printf '\037ABTIN_";

  /// Script sourced by the app terminal's shell (so `alpine`/`_alpine_run` exist).
  /// It prints control markers that [RunOutputFilter] understands.
  static String buildScript({required LangRunner runner, required String fileName, String args = '', RunPre pre = RunPre.none}) {
    final b = StringBuffer();
    b.writeln("${_mark}RUN\\037'");
    String exitWith(String rc) => "{ _rc=$rc; ${_mark}EXIT:%s\\037' \"\$_rc\"; exit \"\$_rc\"; }";
    if (pre == RunPre.bootstrap) {
      b.writeln('alpine bootstrap || ${exitWith(r'$?')}');
    } else {
      b.writeln(r'[ -f "$PREFIX/alpine/etc/alpine-release" ] && { [ -x "$ABTIN_NATIVE/libproot.so" ] || [ -x "$PREFIX/bin/proot" ]; } || '
          "{ ${_mark}NEED_ALPINE\\037'; exit 3; }");
      if (pre == RunPre.install && runner.pkgs.isNotEmpty) {
        b.writeln('_alpine_run apk add --no-cache ${runner.pkgs} || ${exitWith(r'$?')}');
      }
    }
    final cmd = runner.cmd.replaceAll('{f}', shq(fileName)).replaceAll('{out}', out);
    final a = args.trim().isEmpty ? '' : ' ${args.trim()}';
    final inner = StringBuffer();
    if (runner.probe.isNotEmpty) inner.write('command -v ${runner.probe} >/dev/null 2>&1 || exit $missingCode; ');
    inner.write('$cmd$a');
    b.writeln('_alpine_run sh -c ${shq(inner.toString())}');
    b.writeln(r'_rc=$?');
    b.writeln('if [ "\$_rc" = $missingCode ]; then ${_mark}NEED:%s\\037\' ${shq(runner.pkgs)}; exit 4; fi');
    b.writeln("${_mark}EXIT:%s\\037' \"\$_rc\"");
    b.writeln(r'exit "$_rc"');
    return b.toString();
  }
}

/// Removes the control markers written by [CodeRunner.buildScript] from the
/// raw PTY stream: everything before the start marker (shell banner, echoed
/// command line) is dropped and the exit / "need install" markers are parsed.
class RunOutputFilter {
  static const start = '\u001fABTIN_RUN\u001f';
  static final _evt = RegExp('\u001fABTIN_(EXIT|NEED_ALPINE|NEED)(?::([^\u001f]*))?\u001f');

  bool started = false;
  bool needAlpine = false;
  int? exitCode;
  String? need;

  String _pending = '';
  String _carry = '';
  String _raw = '';

  /// Raw output seen before the start marker (shown when the script never started).
  String get unstarted => started ? '' : _raw;

  String feed(String chunk) {
    if (!started) {
      _raw += chunk;
      if (_raw.length > 8000) _raw = _raw.substring(_raw.length - 8000);
      _pending += chunk;
      final i = _pending.indexOf(start);
      if (i < 0) {
        if (_pending.length > start.length) _pending = _pending.substring(_pending.length - start.length);
        return '';
      }
      started = true;
      chunk = _pending.substring(i + start.length);
      _pending = '';
    }
    var text = _carry + chunk;
    _carry = '';
    text = text.replaceAllMapped(_evt, (m) {
      final kind = m.group(1);
      if (kind == 'EXIT') {
        exitCode = int.tryParse(m.group(2) ?? '');
      } else if (kind == 'NEED') {
        need = (m.group(2) ?? '').trim();
      } else {
        needAlpine = true;
      }
      return '';
    });
    final cut = text.lastIndexOf('\u001f');
    if (cut >= 0 && text.length - cut < 200) {
      _carry = text.substring(cut);
      text = text.substring(0, cut);
    }
    return text;
  }
}
