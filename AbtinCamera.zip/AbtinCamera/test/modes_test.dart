import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_camera/modes.dart';

void main() {
  test('all twelve camera modes remain registered exactly once', () {
    expect(Mode.values, hasLength(12));
    expect(modeLabels.keys.toSet(), Mode.values.toSet());
    expect(modeLabels.values.toSet(), hasLength(12));
  });

  test('main and additional mode groups cover all modes without overlap', () {
    expect(mainModes.toSet().intersection(moreModes.toSet()), isEmpty);
    expect({...mainModes, ...moreModes}.toSet(), Mode.values.toSet());
  });
}
