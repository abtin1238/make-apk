import 'package:flutter/material.dart';
import 'modes.dart';
import 'settings.dart';
import 'theme.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  static const Map<Mode, IconData?> _icons = {
    Mode.hires: null,
    Mode.shortVideo: Icons.play_circle_outline,
    Mode.pano: Icons.panorama_horizontal,
    Mode.slowmo: Icons.slow_motion_video,
    Mode.timelapse: Icons.timelapse,
  };

  Widget _circle(Widget child, bool filled) => Container(
        width: 68,
        height: 68,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: filled ? const Color(0xFF48484A) : Colors.transparent,
          border: filled ? null : Border.all(color: const Color(0xFF48484A), width: 2.5),
        ),
        child: child,
      );

  Widget _tile(String label, Widget icon, bool filled, VoidCallback onTap) => GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          _circle(icon, filled),
          const SizedBox(height: 10),
          Text(label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white70)),
        ]),
      );

  void _edit(BuildContext context) {
    final s = AppSettings.I;
    showModalBottomSheet(
      context: context,
      backgroundColor: AT.panel,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => StatefulBuilder(
        builder: (ctx, setM) => SafeArea(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('Modes shown in the bar', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            ),
            for (final m in mainModes)
              if (m != Mode.photo)
                SwitchListTile(
                  title: Text(modeLabels[m]!),
                  value: !s.hidden.contains(m.name),
                  activeColor: AT.purple,
                  onChanged: (v) => setM(() => s.update(() {
                        if (v) {
                          s.hidden.remove(m.name);
                        } else {
                          s.hidden.add(m.name);
                        }
                      })),
                ),
            const SizedBox(height: 8),
          ]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF3C4043), Color(0xFF1E1E20), Color(0xFF070707)],
          ),
        ),
        child: SafeArea(
          child: Column(children: [
            Align(
              alignment: Alignment.topRight,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: IconButton(icon: const Icon(Icons.close, size: 28), onPressed: () => Navigator.pop(context)),
              ),
            ),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: GridView.count(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisCount: 3,
                mainAxisSpacing: 28,
                childAspectRatio: 0.95,
                children: [
                  for (final m in moreModes)
                    _tile(
                      modeLabels[m]!,
                      _icons[m] == null
                          ? const Text('MAX', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600))
                          : Icon(_icons[m], size: 32),
                      m == Mode.hires || m == Mode.slowmo || m == Mode.timelapse,
                      () => Navigator.pop(context, m),
                    ),
                  _tile('Edit', const Icon(Icons.tune, size: 30), false, () => _edit(context)),
                ],
              ),
            ),
            const SizedBox(height: 56),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Back', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: Color(0xFFFFC928))),
            ),
            const SizedBox(height: 36),
          ]),
        ),
      ),
    );
  }
}
