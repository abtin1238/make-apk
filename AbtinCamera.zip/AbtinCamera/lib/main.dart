import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'camera_screen.dart';
import 'settings.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.black,
  ));
  await AppSettings.I.load();
  runApp(const AbtinCameraApp());
}

class AbtinCameraApp extends StatelessWidget {
  const AbtinCameraApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Abtin Camera',
        debugShowCheckedModeBanner: false,
        theme: AT.theme(),
        home: const CameraScreen(),
      );
}
