import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;

// ───────────────────────── Photo jobs ─────────────────────────

class PhotoJob {
  final List<Uint8List> frames;
  final String mode; // photo | moon | night | hdr | portrait
  final bool ai, mirror, moonCrop, watermark;
  final double beauty, blur, temp, contrast, sat, sharp;
  final int quality, maxSide;
  const PhotoJob({
    required this.frames,
    required this.mode,
    required this.ai,
    required this.mirror,
    required this.moonCrop,
    required this.watermark,
    required this.beauty,
    required this.blur,
    required this.temp,
    required this.contrast,
    required this.sat,
    required this.sharp,
    required this.quality,
    required this.maxSide,
  });
}

Future<Uint8List> processPhoto(PhotoJob j) => compute(_processPhoto, j);

Uint8List _processPhoto(PhotoJob j) {
  final multi = j.mode == 'night' || j.mode == 'hdr';
  final ms = multi ? math.min(j.maxSide, 3072) : j.maxSide;
  _Rgb r;
  if (j.mode == 'night') {
    r = _night([for (final f in j.frames) _decode(f, ms)]);
  } else if (j.mode == 'hdr') {
    r = _hdr([for (final f in j.frames) _decode(f, ms)]);
  } else {
    r = _decode(j.frames.first, ms);
  }
  if (j.mode == 'moon') r = _moon(r, j.moonCrop);
  if (j.mode == 'portrait') _portrait(r, j.blur);
  if (j.beauty > 0 && j.mode != 'moon' && j.mode != 'night') _beauty(r, j.beauty);
  if (j.ai && j.mode != 'moon') {
    _stretch(r, lo: 0.004, hi: 0.996, sat: 1.1);
    _unsharp(r, 2, 0.7);
  }
  _adjust(r, temp: j.temp, contrast: j.contrast, sat: j.sat);
  if (j.sharp > 0) _unsharp(r, 2, j.sharp * 1.5);
  if (j.mirror) _flipH(r);
  return _finish(r, j.quality, j.watermark);
}

// ───────────────────────── Core helpers ─────────────────────────

class _Rgb {
  final int w, h;
  Uint8List d;
  _Rgb(this.w, this.h, this.d);
}

int _cl(int v, int n) => v < 0 ? 0 : (v >= n ? n - 1 : v);
int _luma(Uint8List d, int o) => (d[o] * 77 + d[o + 1] * 150 + d[o + 2] * 29) >> 8;

_Rgb _fromImage(img.Image im) {
  final rgb = im.convert(numChannels: 3);
  return _Rgb(rgb.width, rgb.height, Uint8List.fromList(rgb.getBytes(order: img.ChannelOrder.rgb)));
}

_Rgb _decode(Uint8List bytes, int maxSide) {
  var im = img.decodeImage(bytes);
  if (im == null) throw Exception('Cannot decode image');
  im = img.bakeOrientation(im);
  if (math.max(im.width, im.height) > maxSide) {
    im = im.width >= im.height
        ? img.copyResize(im, width: maxSide, interpolation: img.Interpolation.linear)
        : img.copyResize(im, height: maxSide, interpolation: img.Interpolation.linear);
  }
  return _fromImage(im);
}

_Rgb _resize(_Rgb r, int side) {
  final im = img.Image.fromBytes(width: r.w, height: r.h, bytes: r.d.buffer, numChannels: 3);
  final big = r.w >= r.h
      ? img.copyResize(im, width: side, interpolation: img.Interpolation.cubic)
      : img.copyResize(im, height: side, interpolation: img.Interpolation.cubic);
  return _fromImage(big);
}

Uint8List _encode(_Rgb r, int q) {
  final im = img.Image.fromBytes(width: r.w, height: r.h, bytes: r.d.buffer, numChannels: 3);
  return Uint8List.fromList(img.encodeJpg(im, quality: q));
}

Uint8List _finish(_Rgb r, int q, bool wm) {
  final im = img.Image.fromBytes(width: r.w, height: r.h, bytes: r.d.buffer, numChannels: 3);
  if (wm) {
    final f = r.w > 2400 ? img.arial48 : img.arial24;
    img.drawString(im, 'Abtin Camera',
        font: f, x: 28, y: im.height - f.lineHeight - 28, color: img.ColorRgb8(255, 255, 255));
  }
  return Uint8List.fromList(img.encodeJpg(im, quality: q));
}

Uint8List _boxBlur(Uint8List s, int w, int h, int r, [int ch = 3]) {
  if (r < 1) return Uint8List.fromList(s);
  final t = Uint8List(s.length);
  final o = Uint8List(s.length);
  final d = 2 * r + 1;
  for (var y = 0; y < h; y++) {
    final row = y * w * ch;
    for (var c = 0; c < ch; c++) {
      var sum = 0;
      for (var x = -r; x <= r; x++) {
        sum += s[row + _cl(x, w) * ch + c];
      }
      for (var x = 0; x < w; x++) {
        t[row + x * ch + c] = sum ~/ d;
        sum += s[row + _cl(x + r + 1, w) * ch + c] - s[row + _cl(x - r, w) * ch + c];
      }
    }
  }
  final rw = w * ch;
  final sums = Int32List(rw);
  for (var y = -r; y <= r; y++) {
    final ro = _cl(y, h) * rw;
    for (var i = 0; i < rw; i++) {
      sums[i] += t[ro + i];
    }
  }
  for (var y = 0; y < h; y++) {
    final ro = y * rw;
    for (var i = 0; i < rw; i++) {
      o[ro + i] = sums[i] ~/ d;
    }
    final add = _cl(y + r + 1, h) * rw, sub = _cl(y - r, h) * rw;
    for (var i = 0; i < rw; i++) {
      sums[i] += t[add + i] - t[sub + i];
    }
  }
  return o;
}

void _stretch(_Rgb r, {double lo = 0.005, double hi = 0.995, double gamma = 1.0, double sat = 1.0}) {
  final d = r.d, n = r.w * r.h;
  final hist = List<int>.filled(256, 0);
  for (var i = 0; i < n; i++) {
    hist[_luma(d, i * 3)]++;
  }
  var acc = 0, l = 0, h = 255;
  final tl = (n * lo).round();
  for (l = 0; l < 255; l++) {
    acc += hist[l];
    if (acc >= tl) break;
  }
  acc = 0;
  final th = (n * (1 - hi)).round();
  for (h = 255; h > 0; h--) {
    acc += hist[h];
    if (acc >= th) break;
  }
  if (h - l < 16) return;
  final lut = Uint8List(256);
  for (var i = 0; i < 256; i++) {
    final v = ((i - l) / (h - l)).clamp(0.0, 1.0).toDouble();
    lut[i] = (math.pow(v, gamma) * 255).round();
  }
  for (var i = 0; i < n; i++) {
    final o = i * 3;
    var rr = lut[d[o]], gg = lut[d[o + 1]], bb = lut[d[o + 2]];
    if (sat != 1.0) {
      final y = (rr * 77 + gg * 150 + bb * 29) >> 8;
      rr = _c255(y + (rr - y) * sat);
      gg = _c255(y + (gg - y) * sat);
      bb = _c255(y + (bb - y) * sat);
    }
    d[o] = rr;
    d[o + 1] = gg;
    d[o + 2] = bb;
  }
}

int _c255(num v) => v < 0 ? 0 : (v > 255 ? 255 : v.round());

void _unsharp(_Rgb r, int radius, double amount) {
  final b = _boxBlur(r.d, r.w, r.h, radius);
  final d = r.d;
  for (var i = 0; i < d.length; i++) {
    d[i] = _c255(d[i] + (d[i] - b[i]) * amount);
  }
}

void _adjust(_Rgb r, {double temp = 0, double contrast = 0, double sat = 0}) {
  if (temp == 0 && contrast == 0 && sat == 0) return;
  final lr = Uint8List(256), lg = Uint8List(256), lb = Uint8List(256);
  final cf = 1 + contrast * 0.5;
  for (var i = 0; i < 256; i++) {
    final v = (i - 128) * cf + 128;
    lr[i] = _c255(v + temp * 30);
    lg[i] = _c255(v);
    lb[i] = _c255(v - temp * 30);
  }
  final sf = 1 + sat * 0.8;
  final d = r.d, n = r.w * r.h;
  for (var i = 0; i < n; i++) {
    final o = i * 3;
    var rr = lr[d[o]], gg = lg[d[o + 1]], bb = lb[d[o + 2]];
    if (sat != 0) {
      final y = (rr * 77 + gg * 150 + bb * 29) >> 8;
      rr = _c255(y + (rr - y) * sf);
      gg = _c255(y + (gg - y) * sf);
      bb = _c255(y + (bb - y) * sf);
    }
    d[o] = rr;
    d[o + 1] = gg;
    d[o + 2] = bb;
  }
}

void _flipH(_Rgb r) {
  final d = r.d, w = r.w;
  for (var y = 0; y < r.h; y++) {
    final row = y * w * 3;
    for (var x = 0; x < w ~/ 2; x++) {
      final a = row + x * 3, b = row + (w - 1 - x) * 3;
      for (var c = 0; c < 3; c++) {
        final t = d[a + c];
        d[a + c] = d[b + c];
        d[b + c] = t;
      }
    }
  }
}

_Rgb _rot90(_Rgb r) {
  final nw = r.h;
  final o = Uint8List(r.d.length);
  for (var y = 0; y < r.h; y++) {
    for (var x = 0; x < r.w; x++) {
      final nx = r.h - 1 - y, ny = x;
      final s = (y * r.w + x) * 3, t = (ny * nw + nx) * 3;
      o[t] = r.d[s];
      o[t + 1] = r.d[s + 1];
      o[t + 2] = r.d[s + 2];
    }
  }
  return _Rgb(nw, r.w, o);
}

// ───────────────────────── Modes ─────────────────────────

_Rgb _moon(_Rgb r, bool crop) {
  var out = r;
  if (crop) {
    final step = math.max(2, math.min(r.w, r.h) ~/ 300);
    var maxL = 0;
    for (var y = 0; y < r.h; y += step) {
      for (var x = 0; x < r.w; x += step) {
        final l = _luma(r.d, (y * r.w + x) * 3);
        if (l > maxL) maxL = l;
      }
    }
    if (maxL > 90) {
      final thr = maxL * 0.5;
      var minX = r.w, maxX = 0, minY = r.h, maxY = 0, cnt = 0, total = 0;
      for (var y = 0; y < r.h; y += step) {
        for (var x = 0; x < r.w; x += step) {
          total++;
          if (_luma(r.d, (y * r.w + x) * 3) > thr) {
            cnt++;
            if (x < minX) minX = x;
            if (x > maxX) maxX = x;
            if (y < minY) minY = y;
            if (y > maxY) maxY = y;
          }
        }
      }
      if (cnt > total * 0.0008 && cnt < total * 0.5) {
        final mn = math.min(r.w, r.h);
        var side = (math.max(maxX - minX, maxY - minY) * 1.9).round();
        side = math.min(math.max(side, math.min(512, mn)), mn);
        final cx = (minX + maxX) ~/ 2, cy = (minY + maxY) ~/ 2;
        final x0 = math.min(math.max(cx - side ~/ 2, 0), r.w - side);
        final y0 = math.min(math.max(cy - side ~/ 2, 0), r.h - side);
        final o = Uint8List(side * side * 3);
        for (var y = 0; y < side; y++) {
          o.setRange(y * side * 3, (y + 1) * side * 3, r.d, ((y0 + y) * r.w + x0) * 3);
        }
        out = _Rgb(side, side, o);
        if (side < 1600) out = _resize(out, 1800);
      }
    }
  }
  _stretch(out, lo: 0.02, hi: 0.9995, gamma: 0.85, sat: 0.85);
  _unsharp(out, 2, 1.1);
  _unsharp(out, 8, 0.5);
  return out;
}

_Rgb _night(List<_Rgb> fs) {
  final base = fs.first;
  final acc = Uint16List(base.d.length);
  var cnt = 0;
  for (final f in fs) {
    if (f.w != base.w || f.h != base.h) continue;
    cnt++;
    for (var i = 0; i < acc.length; i++) {
      acc[i] += f.d[i];
    }
  }
  final o = Uint8List(acc.length);
  for (var i = 0; i < acc.length; i++) {
    o[i] = acc[i] ~/ cnt;
  }
  final r = _Rgb(base.w, base.h, o);
  _stretch(r, lo: 0.001, hi: 0.999, gamma: 0.7, sat: 1.15);
  _denoise(r, 0.6);
  _unsharp(r, 1, 0.6);
  return r;
}

void _denoise(_Rgb r, double amt) {
  final b = _boxBlur(r.d, r.w, r.h, 2);
  final d = r.d, n = r.w * r.h;
  for (var i = 0; i < n; i++) {
    final o = i * 3;
    final w = amt * (1 - _luma(d, o) / 255.0);
    for (var c = 0; c < 3; c++) {
      d[o + c] = _c255(d[o + c] * (1 - w) + b[o + c] * w);
    }
  }
}

_Rgb _hdr(List<_Rgb> fs) {
  final base = fs.first;
  final n = base.w * base.h;
  final out = Uint8List(n * 3);
  for (var i = 0; i < n; i++) {
    final o = i * 3;
    double ws = 0, sr = 0, sg = 0, sb = 0;
    for (final f in fs) {
      if (f.d.length != out.length) continue;
      final l = _luma(f.d, o) / 255.0;
      final dd = l - 0.5;
      final w = math.exp(-dd * dd / 0.08) + 1e-4;
      ws += w;
      sr += w * f.d[o];
      sg += w * f.d[o + 1];
      sb += w * f.d[o + 2];
    }
    out[o] = _c255(sr / ws);
    out[o + 1] = _c255(sg / ws);
    out[o + 2] = _c255(sb / ws);
  }
  final r = _Rgb(base.w, base.h, out);
  _stretch(r, lo: 0.002, hi: 0.998, sat: 1.12);
  _unsharp(r, 2, 0.5);
  return r;
}

void _portrait(_Rgb r, double amt) {
  final rad = math.max(4, (math.max(r.w, r.h) * (0.004 + 0.012 * amt)).round());
  var b = _boxBlur(r.d, r.w, r.h, rad);
  b = _boxBlur(b, r.w, r.h, rad);
  b = _boxBlur(b, r.w, r.h, rad);
  final cx = r.w * 0.5, cy = r.h * 0.46, rx = r.w * 0.36, ry = r.h * 0.34;
  final d = r.d;
  for (var y = 0; y < r.h; y++) {
    final dy = (y - cy) / ry;
    for (var x = 0; x < r.w; x++) {
      final dx = (x - cx) / rx;
      final dist = math.sqrt(dx * dx + dy * dy);
      var t = ((dist - 0.85) / 0.5).clamp(0.0, 1.0).toDouble();
      if (t <= 0) continue;
      t = t * t * (3 - 2 * t);
      final o = (y * r.w + x) * 3;
      for (var c = 0; c < 3; c++) {
        d[o + c] = _c255(d[o + c] * (1 - t) + b[o + c] * t);
      }
    }
  }
}

void _beauty(_Rgb r, double amt) {
  final b = _boxBlur(r.d, r.w, r.h, math.max(2, (math.min(r.w, r.h) * 0.004).round()));
  final d = r.d, n = r.w * r.h;
  for (var i = 0; i < n; i++) {
    final o = i * 3;
    final rr = d[o], gg = d[o + 1], bb = d[o + 2];
    final cb = 128 - 0.168736 * rr - 0.331264 * gg + 0.5 * bb;
    final cr = 128 + 0.5 * rr - 0.418688 * gg - 0.081312 * bb;
    if (cb >= 77 && cb <= 127 && cr >= 133 && cr <= 173) {
      final w = amt * 0.65;
      final lift = amt * 10;
      d[o] = _c255(rr * (1 - w) + b[o] * w + lift);
      d[o + 1] = _c255(gg * (1 - w) + b[o + 1] * w + lift);
      d[o + 2] = _c255(bb * (1 - w) + b[o + 2] * w + lift);
    }
  }
}

// ───────────────────────── Document scanner ─────────────────────────

class DocJob {
  final Uint8List bytes;
  final List<double> corners; // tlx,tly,trx,try,brx,bry,blx,bly (normalized)
  final String filter; // normal | bw | advanced
  final int rotation; // quarter turns clockwise
  const DocJob({required this.bytes, required this.corners, required this.filter, required this.rotation});
}

class DocOut {
  final Uint8List jpg;
  final int w, h;
  const DocOut(this.jpg, this.w, this.h);
}

Future<DocOut> processDoc(DocJob j) => compute(_processDoc, j);
Future<List<double>> detectDocument(Uint8List b) => compute(_detectDoc, b);

int _ci(int v, int n) => v < 0 ? 0 : (v >= n ? n - 1 : v);

DocOut _processDoc(DocJob j) {
  final src = _decode(j.bytes, 3200);
  final c = j.corners;
  final w = src.w.toDouble(), h = src.h.toDouble();
  final tl = [c[0] * w, c[1] * h], tr = [c[2] * w, c[3] * h];
  final br = [c[4] * w, c[5] * h], bl = [c[6] * w, c[7] * h];
  double dist(List<double> a, List<double> b) =>
      math.sqrt((a[0] - b[0]) * (a[0] - b[0]) + (a[1] - b[1]) * (a[1] - b[1]));
  var ow = math.max(dist(tl, tr), dist(bl, br)).round();
  var oh = math.max(dist(tl, bl), dist(tr, br)).round();
  ow = math.min(math.max(ow, 100), 3200);
  oh = math.min(math.max(oh, 100), 3200);
  final out = Uint8List(ow * oh * 3);
  final sd = src.d, sw = src.w, sh = src.h;
  for (var y = 0; y < oh; y++) {
    final v = oh > 1 ? y / (oh - 1) : 0.0;
    for (var x = 0; x < ow; x++) {
      final u = ow > 1 ? x / (ow - 1) : 0.0;
      final sx = (1 - u) * (1 - v) * tl[0] + u * (1 - v) * tr[0] + (1 - u) * v * bl[0] + u * v * br[0];
      final sy = (1 - u) * (1 - v) * tl[1] + u * (1 - v) * tr[1] + (1 - u) * v * bl[1] + u * v * br[1];
      final fxI = sx.floor(), fyI = sy.floor();
      final fx = sx - fxI, fy = sy - fyI;
      final x0 = _ci(fxI, sw), x1 = _ci(fxI + 1, sw), y0 = _ci(fyI, sh), y1 = _ci(fyI + 1, sh);
      final a = (y0 * sw + x0) * 3, b = (y0 * sw + x1) * 3;
      final cc = (y1 * sw + x0) * 3, dd = (y1 * sw + x1) * 3;
      final o = (y * ow + x) * 3;
      for (var k = 0; k < 3; k++) {
        final top = sd[a + k] * (1 - fx) + sd[b + k] * fx;
        final bot = sd[cc + k] * (1 - fx) + sd[dd + k] * fx;
        out[o + k] = _c255(top * (1 - fy) + bot * fy);
      }
    }
  }
  var r = _Rgb(ow, oh, out);
  final turns = ((j.rotation % 4) + 4) % 4;
  for (var i = 0; i < turns; i++) {
    r = _rot90(r);
  }
  _docFilter(r, j.filter);
  return DocOut(_encode(r, 90), r.w, r.h);
}

double _curve(double v) {
  var t = v / 255.0;
  t = (t - 0.5) * 1.3 + 0.5 + 0.04;
  return t < 0 ? 0 : (t > 1 ? 255 : t * 255);
}

void _docFilter(_Rgb r, String f) {
  if (f == 'original') return;
  if (f == 'normal') {
    _stretch(r, lo: 0.003, hi: 0.997, sat: 1.05);
    return;
  }
  final rad = math.max(10, math.min(r.w, r.h) ~/ 14);
  final bg = _boxBlur(r.d, r.w, r.h, rad);
  final d = r.d, n = r.w * r.h;
  for (var i = 0; i < n; i++) {
    final o = i * 3;
    final nr = math.min(255.0, d[o] * 255 / math.max(bg[o], 30));
    final ng = math.min(255.0, d[o + 1] * 255 / math.max(bg[o + 1], 30));
    final nb = math.min(255.0, d[o + 2] * 255 / math.max(bg[o + 2], 30));
    if (f == 'advanced') {
      d[o] = _c255(_curve(nr));
      d[o + 1] = _c255(_curve(ng));
      d[o + 2] = _c255(_curve(nb));
    } else {
      final y = 0.299 * nr + 0.587 * ng + 0.114 * nb;
      int v;
      if (f == 'bw') {
        final s = (((y / 255.0) - 0.52) / 0.28).clamp(0.0, 1.0).toDouble();
        v = _c255(s * s * (3 - 2 * s) * 255);
      } else {
        v = _c255(_curve(y));
      }
      d[o] = v;
      d[o + 1] = v;
      d[o + 2] = v;
    }
  }
  if (f == 'advanced') _unsharp(r, 2, 0.8);
}

int _otsu(List<int> hist, int total) {
  double sum = 0;
  for (var i = 0; i < 256; i++) {
    sum += i * hist[i];
  }
  double sumB = 0, wB = 0, best = -1;
  var thr = 127;
  for (var t = 0; t < 256; t++) {
    wB += hist[t];
    if (wB == 0) continue;
    final wF = total - wB;
    if (wF == 0) break;
    sumB += t * hist[t];
    final mB = sumB / wB, mF = (sum - sumB) / wF;
    final between = wB * wF * (mB - mF) * (mB - mF);
    if (between > best) {
      best = between;
      thr = t;
    }
  }
  return thr;
}

List<double> _detectDoc(Uint8List bytes) {
  const fallback = [0.08, 0.08, 0.92, 0.08, 0.92, 0.92, 0.08, 0.92];
  try {
    final r = _decode(bytes, 320);
    final w = r.w, h = r.h, n = w * h;
    final bl = _boxBlur(r.d, w, h, 2);
    final lum = Uint8List(n);
    final hist = List<int>.filled(256, 0);
    for (var i = 0; i < n; i++) {
      final l = _luma(bl, i * 3);
      lum[i] = l;
      hist[l]++;
    }
    final thr = _otsu(hist, n);
    var cs = 0, cc = 0;
    for (var y = (h * 0.4).round(); y < (h * 0.6).round(); y++) {
      for (var x = (w * 0.4).round(); x < (w * 0.6).round(); x++) {
        cs += lum[y * w + x];
        cc++;
      }
    }
    final bright = cc > 0 && cs / cc > thr;
    final mask = Uint8List(n);
    var fg = 0;
    for (var i = 0; i < n; i++) {
      final isFg = bright ? lum[i] > thr : lum[i] <= thr;
      if (isFg) {
        mask[i] = 255;
        fg++;
      }
    }
    final ratio = fg / n;
    if (ratio < 0.12 || ratio > 0.97) return fallback;
    final m = _boxBlur(mask, w, h, 3, 1);
    var tlS = 1 << 30, brS = -(1 << 30), trD = -(1 << 30), blD = 1 << 30;
    var tlX = 0, tlY = 0, brX = 0, brY = 0, trX = 0, trY = 0, blX = 0, blY = 0;
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        if (m[y * w + x] <= 200) continue;
        final s = x + y, df = x - y;
        if (s < tlS) {
          tlS = s;
          tlX = x;
          tlY = y;
        }
        if (s > brS) {
          brS = s;
          brX = x;
          brY = y;
        }
        if (df > trD) {
          trD = df;
          trX = x;
          trY = y;
        }
        if (df < blD) {
          blD = df;
          blX = x;
          blY = y;
        }
      }
    }
    final px = [tlX, trX, brX, blX], py = [tlY, trY, brY, blY];
    double area = 0;
    for (var i = 0; i < 4; i++) {
      final j = (i + 1) % 4;
      area += px[i] * py[j] - px[j] * py[i];
    }
    area = area.abs() / 2 / n;
    if (area < 0.15) return fallback;
    final dx = (w - 1).toDouble(), dy = (h - 1).toDouble();
    return [
      tlX / dx, tlY / dy, trX / dx, trY / dy,
      brX / dx, brY / dy, blX / dx, blY / dy,
    ];
  } catch (_) {
    return fallback;
  }
}

// ───────────────────────── Panorama ─────────────────────────

class PanoJob {
  final List<Uint8List> frames;
  final double strip; // fraction of frame width used per shot
  final bool reverse;
  final int quality;
  const PanoJob({required this.frames, required this.strip, required this.reverse, required this.quality});
}

Future<Uint8List> processPano(PanoJob j) => compute(_processPano, j);

Uint8List _processPano(PanoJob j) {
  final order = j.reverse ? j.frames.reversed.toList() : j.frames;
  final all = [for (final f in order) _decode(f, 1600)];
  final base = all.first;
  final rs = all.where((r) => r.w == base.w && r.h == base.h).toList();
  final w = base.w, h = base.h;
  final cx = w ~/ 2;
  final sw = math.max(8, (w * j.strip).round());
  final crop = (h * 0.04).round();
  final oh = h - crop * 2;
  final xs = <List<int>>[];
  for (var i = 0; i < rs.length; i++) {
    var x0 = cx - sw ~/ 2, x1 = x0 + sw;
    if (i == 0) x0 = 0;
    if (i == rs.length - 1) x1 = w;
    xs.add([math.max(0, x0), math.min(w, x1)]);
  }
  var total = 0;
  for (final x in xs) {
    total += x[1] - x[0];
  }
  final out = Uint8List(total * oh * 3);
  var off = 0;
  for (var i = 0; i < rs.length; i++) {
    final cw = xs[i][1] - xs[i][0];
    for (var y = 0; y < oh; y++) {
      final src = ((y + crop) * w + xs[i][0]) * 3;
      out.setRange((y * total + off) * 3, (y * total + off + cw) * 3, rs[i].d, src);
    }
    off += cw;
  }
  return _encode(_Rgb(total, oh, out), j.quality);
}
