enum Mode { pro, photo, video, portrait, night, moon, doc, hires, shortVideo, pano, slowmo, timelapse }

const modeLabels = {
  Mode.pro: 'Pro',
  Mode.photo: 'Photo',
  Mode.video: 'Video',
  Mode.portrait: 'Portrait',
  Mode.night: 'Night',
  Mode.moon: 'Moon',
  Mode.doc: 'Document',
  Mode.hires: 'Hi-Res',
  Mode.shortVideo: 'Short video',
  Mode.pano: 'Panorama',
  Mode.slowmo: 'Slow motion',
  Mode.timelapse: 'Time-lapse',
};

const mainModes = [Mode.pro, Mode.photo, Mode.video, Mode.portrait, Mode.night, Mode.moon, Mode.doc];
const moreModes = [Mode.hires, Mode.shortVideo, Mode.pano, Mode.slowmo, Mode.timelapse];
