import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import 'gallery.dart';
import 'processing.dart';
import 'theme.dart';

class DocPage {
  final Uint8List original;
  final List<double> corners;
  final String filter;
  final int rotation;
  final Uint8List processed;
  final int w, h;
  DocPage({
    required this.original,
    required this.corners,
    required this.filter,
    required this.rotation,
    required this.processed,
    required this.w,
    required this.h,
  });
}

class DocSession extends ChangeNotifier {
  final List<DocPage> pages = [];
  void add(DocPage p) {
    pages.add(p);
    notifyListeners();
  }

  void replace(int i, DocPage p) {
    pages[i] = p;
    notifyListeners();
  }

  void removeAt(int i) {
    pages.removeAt(i);
    notifyListeners();
  }

  void clear() {
    pages.clear();
    notifyListeners();
  }
}

final docSession = DocSession();

class DocEditResult {
  final DocPage page;
  final bool finish;
  DocEditResult(this.page, this.finish);
}

// ───────────────────────── Editor ─────────────────────────

class DocEditorScreen extends StatefulWidget {
  final Uint8List bytes;
  final DocPage? existing;
  const DocEditorScreen({super.key, required this.bytes, this.existing});
  @override
  State<DocEditorScreen> createState() => _DocEditorScreenState();
}

class _DocEditorScreenState extends State<DocEditorScreen> {
  List<Offset> _pts = [];
  String _filter = 'advanced';
  int _rot = 0;
  Size? _imgSize;
  bool _loading = true, _working = false;
  Uint8List? _preview;
  int _drag = -1;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final im = await decodeImageFromList(widget.bytes);
    _imgSize = Size(im.width.toDouble(), im.height.toDouble());
    final ex = widget.existing;
    List<double> c;
    if (ex != null) {
      c = ex.corners;
      _filter = ex.filter;
      _rot = ex.rotation;
    } else {
      c = await detectDocument(widget.bytes);
    }
    _pts = [for (var i = 0; i < 4; i++) Offset(c[i * 2], c[i * 2 + 1])];
    if (mounted) setState(() => _loading = false);
  }

  Future<DocPage> _build() async {
    final c = <double>[for (final q in _pts) ...[q.dx, q.dy]];
    final out = await processDoc(DocJob(bytes: widget.bytes, corners: c, filter: _filter, rotation: _rot));
    return DocPage(
        original: widget.bytes,
        corners: c,
        filter: _filter,
        rotation: _rot,
        processed: out.jpg,
        w: out.w,
        h: out.h);
  }

  Future<void> _refreshPreview() async {
    setState(() => _working = true);
    try {
      final pg = await _build();
      if (mounted) setState(() => _preview = pg.processed);
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  Future<void> _togglePreview() async {
    if (_preview != null) {
      setState(() => _preview = null);
    } else {
      await _refreshPreview();
    }
  }

  Future<void> _finish(bool finish) async {
    setState(() => _working = true);
    try {
      final pg = await _build();
      if (mounted) Navigator.of(context).pop(DocEditResult(pg, finish));
    } catch (_) {
      if (mounted) setState(() => _working = false);
    }
  }

  void _setFilter(String f) {
    setState(() => _filter = f);
    if (_preview != null) _refreshPreview();
  }

  void _rotate() {
    setState(() => _rot = (_rot + 1) % 4);
    if (_preview != null) _refreshPreview();
  }

  void _resetCorners() => setState(() {
        _pts = const [Offset(0.02, 0.02), Offset(0.98, 0.02), Offset(0.98, 0.98), Offset(0.02, 0.98)];
      });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Adjust document'),
        actions: [
          IconButton(icon: const Icon(Icons.crop_free), tooltip: 'Full frame', onPressed: _resetCorners),
          TextButton(onPressed: _loading || _working ? null : _togglePreview, child: Text(_preview == null ? 'Preview' : 'Edit')),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AT.purple))
          : Stack(children: [
              Column(children: [
                Expanded(
                    child: _preview != null
                        ? InteractiveViewer(maxScale: 6, child: Center(child: Image.memory(_preview!)))
                        : _editArea()),
                _filterRow(),
                _actions(),
              ]),
              if (_working)
                Positioned.fill(
                    child: Container(
                        color: Colors.black54,
                        child: const Center(child: CircularProgressIndicator(color: AT.purple)))),
            ]),
    );
  }

  Widget _editArea() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: LayoutBuilder(builder: (ctx, cons) {
        final iw = _imgSize!.width, ih = _imgSize!.height;
        final sc = math.min(cons.maxWidth / iw, cons.maxHeight / ih);
        final dw = iw * sc, dh = ih * sc;
        final ox = (cons.maxWidth - dw) / 2, oy = (cons.maxHeight - dh) / 2;
        Offset toPx(Offset n) => Offset(ox + n.dx * dw, oy + n.dy * dh);
        return SizedBox(
          width: cons.maxWidth,
          height: cons.maxHeight,
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onPanStart: (d) {
              var best = -1;
              var bd = 56.0;
              for (var i = 0; i < 4; i++) {
                final dist = (toPx(_pts[i]) - d.localPosition).distance;
                if (dist < bd) {
                  bd = dist;
                  best = i;
                }
              }
              _drag = best;
            },
            onPanUpdate: (d) {
              if (_drag < 0) return;
              final lp = d.localPosition;
              setState(() {
                _pts[_drag] = Offset(((lp.dx - ox) / dw).clamp(0.0, 1.0).toDouble(),
                    ((lp.dy - oy) / dh).clamp(0.0, 1.0).toDouble());
              });
            },
            onPanEnd: (_) => _drag = -1,
            child: Stack(children: [
              Positioned(
                  left: ox,
                  top: oy,
                  width: dw,
                  height: dh,
                  child: Image.memory(widget.bytes, fit: BoxFit.fill)),
              Positioned.fill(
                  child: CustomPaint(painter: _QuadPainter([for (final q in _pts) toPx(q)], _drag))),
            ]),
          ),
        );
      }),
    );
  }

  Widget _filterRow() {
    const items = {'normal': 'Normal', 'bw': 'Black & White', 'advanced': 'Advanced'};
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: Row(children: [
        for (final e in items.entries)
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: ChoiceChip(
              label: Text(e.value),
              selected: _filter == e.key,
              selectedColor: AT.purple,
              onSelected: (_) => _setFilter(e.key),
            ),
          ),
        IconButton(onPressed: _rotate, icon: const Icon(Icons.rotate_right), tooltip: 'Rotate'),
      ]),
    );
  }

  Widget _actions() {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
        child: Row(children: [
          Expanded(
              child: OutlinedButton(
                  onPressed: _working ? null : () => Navigator.of(context).pop(), child: const Text('Retake'))),
          const SizedBox(width: 8),
          Expanded(
              child: OutlinedButton(
                  onPressed: _working ? null : () => _finish(false), child: const Text('Add page'))),
          const SizedBox(width: 8),
          Expanded(
              child: FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: AT.purple),
                  onPressed: _working ? null : () => _finish(true),
                  child: const Text('Done'))),
        ]),
      ),
    );
  }
}

class _QuadPainter extends CustomPainter {
  final List<Offset> pts;
  final int active;
  _QuadPainter(this.pts, this.active);
  @override
  void paint(Canvas c, Size s) {
    final path = Path()..moveTo(pts[0].dx, pts[0].dy);
    for (var i = 1; i < 4; i++) {
      path.lineTo(pts[i].dx, pts[i].dy);
    }
    path.close();
    c.drawPath(path, Paint()..color = AT.purple.withOpacity(0.18));
    c.drawPath(
        path,
        Paint()
          ..color = AT.purple
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3);
    for (var i = 0; i < 4; i++) {
      c.drawCircle(pts[i], i == active ? 17 : 13, Paint()..color = Colors.white);
      c.drawCircle(
          pts[i],
          i == active ? 17 : 13,
          Paint()
            ..color = AT.purple
            ..style = PaintingStyle.stroke
            ..strokeWidth = 3);
    }
  }

  @override
  bool shouldRepaint(covariant _QuadPainter old) => true;
}

// ───────────────────────── Pages + PDF ─────────────────────────

class DocPagesScreen extends StatefulWidget {
  const DocPagesScreen({super.key});
  @override
  State<DocPagesScreen> createState() => _DocPagesScreenState();
}

class _DocPagesScreenState extends State<DocPagesScreen> {
  bool _busy = false;

  void _toast(String m) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m), duration: const Duration(seconds: 3)));

  Future<File> _makePdf() async {
    final doc = pw.Document(title: 'Abtin Scan', author: 'Abtin Camera');
    for (final pg in docSession.pages) {
      final im = pw.MemoryImage(pg.processed);
      final aspect = pg.w / pg.h;
      final fmt = (aspect - 0.7071).abs() < 0.08
          ? PdfPageFormat.a4
          : PdfPageFormat(595.28, 595.28 / aspect);
      doc.addPage(pw.Page(
        pageFormat: fmt,
        margin: pw.EdgeInsets.zero,
        build: (ctx) => pw.Image(im, fit: pw.BoxFit.fill),
      ));
    }
    final bytes = await doc.save();
    Directory? base;
    try {
      base = await getExternalStorageDirectory();
    } catch (_) {}
    base ??= await getApplicationDocumentsDirectory();
    final dir = Directory(p.join(base.path, 'AbtinScans'));
    await dir.create(recursive: true);
    final f = File(p.join(dir.path, 'Scan_${DateTime.now().millisecondsSinceEpoch}.pdf'));
    await f.writeAsBytes(bytes, flush: true);
    return f;
  }

  Future<void> _run(Future<void> Function() job) async {
    if (docSession.pages.isEmpty || _busy) return;
    setState(() => _busy = true);
    try {
      await job();
    } catch (e) {
      _toast('Failed: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _savePdf() => _run(() async {
        final f = await _makePdf();
        _toast('PDF saved: ${f.path}');
      });

  Future<void> _sharePdf() => _run(() async {
        final f = await _makePdf();
        await Share.shareXFiles([XFile(f.path)], text: 'Scanned with Abtin Camera');
      });

  Future<void> _saveImages() => _run(() async {
        for (final pg in docSession.pages) {
          await saveJpeg(pg.processed);
        }
        _toast('Images saved to gallery');
      });

  Future<void> _edit(int i) async {
    final pg = docSession.pages[i];
    final res = await Navigator.of(context)
        .push<DocEditResult>(MaterialPageRoute(builder: (_) => DocEditorScreen(bytes: pg.original, existing: pg)));
    if (res != null) docSession.replace(i, res.page);
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: docSession,
      builder: (context, _) {
        final pages = docSession.pages;
        return Scaffold(
          appBar: AppBar(
            title: Text('Pages (${pages.length})'),
            actions: [
              IconButton(
                  icon: const Icon(Icons.delete_sweep_outlined),
                  tooltip: 'Clear all',
                  onPressed: pages.isEmpty
                      ? null
                      : () {
                          docSession.clear();
                          Navigator.of(context).pop();
                        }),
            ],
          ),
          body: Stack(children: [
            pages.isEmpty
                ? const Center(child: Text('No pages', style: TextStyle(color: Colors.white54)))
                : GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 0.72),
                    itemCount: pages.length,
                    itemBuilder: (c, i) => GestureDetector(
                      onTap: () => _edit(i),
                      child: Stack(children: [
                        Positioned.fill(
                            child: Container(
                          decoration: BoxDecoration(
                              color: AT.panel, borderRadius: BorderRadius.circular(12)),
                          clipBehavior: Clip.antiAlias,
                          child: Image.memory(pages[i].processed, fit: BoxFit.contain, cacheWidth: 600),
                        )),
                        Positioned(
                            left: 8,
                            top: 8,
                            child: CircleAvatar(
                                radius: 12,
                                backgroundColor: AT.purple,
                                child: Text('${i + 1}', style: const TextStyle(fontSize: 12)))),
                        Positioned(
                            right: 0,
                            top: 0,
                            child: IconButton(
                                icon: const Icon(Icons.cancel, color: Colors.white70),
                                onPressed: () {
                                  docSession.removeAt(i);
                                  if (docSession.pages.isEmpty) Navigator.of(context).pop();
                                })),
                      ]),
                    ),
                  ),
            if (_busy)
              Positioned.fill(
                  child: Container(
                      color: Colors.black54,
                      child: const Center(child: CircularProgressIndicator(color: AT.purple)))),
          ]),
          bottomNavigationBar: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
              child: Row(children: [
                Expanded(
                    child: OutlinedButton.icon(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.add_a_photo_outlined),
                        label: const Text('Add'))),
                const SizedBox(width: 8),
                Expanded(
                    child: OutlinedButton.icon(
                        onPressed: pages.isEmpty ? null : _saveImages,
                        icon: const Icon(Icons.photo_library_outlined),
                        label: const Text('Images'))),
                const SizedBox(width: 8),
                Expanded(
                    child: OutlinedButton.icon(
                        onPressed: pages.isEmpty ? null : _savePdf,
                        icon: const Icon(Icons.picture_as_pdf_outlined),
                        label: const Text('PDF'))),
                const SizedBox(width: 8),
                IconButton.filled(
                    style: IconButton.styleFrom(backgroundColor: AT.purple),
                    onPressed: pages.isEmpty ? null : _sharePdf,
                    icon: const Icon(Icons.share)),
              ]),
            ),
          ),
        );
      },
    );
  }
}
