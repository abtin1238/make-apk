import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings extends ChangeNotifier {
  AppSettings._();
  static final AppSettings I = AppSettings._();
  SharedPreferences? _p;

  int resolution = 2; // 0 HD, 1 FHD, 2 4K, 3 MAX
  int jpegQuality = 95;
  bool grid = false, level = true, ai = false, hdr = false;
  bool autoSave = true, mirrorFront = true, moonCrop = true, watermark = false;
  double beauty = 0, portraitBlur = 0.6;
  int timer = 0;
  Set<String> hidden = {};

  static const resLabels = [
    ['HD', '720p'],
    ['FHD', '1080p'],
    ['4K', 'UHD'],
    ['MAX', 'FULL'],
  ];

  Future<void> load() async {
    final p = _p = await SharedPreferences.getInstance();
    resolution = p.getInt('res') ?? 2;
    jpegQuality = p.getInt('q') ?? 95;
    grid = p.getBool('grid') ?? false;
    level = p.getBool('level') ?? true;
    ai = p.getBool('ai') ?? false;
    hdr = p.getBool('hdr') ?? false;
    autoSave = p.getBool('autosave') ?? true;
    mirrorFront = p.getBool('mirror') ?? true;
    moonCrop = p.getBool('mooncrop') ?? true;
    watermark = p.getBool('wm') ?? false;
    beauty = p.getDouble('beauty') ?? 0;
    portraitBlur = p.getDouble('pblur') ?? 0.6;
    timer = p.getInt('timer') ?? 0;
    hidden = (p.getStringList('hidden') ?? <String>[]).toSet();
  }

  void update(VoidCallback f) {
    f();
    _save();
    notifyListeners();
  }

  Future<void> _save() async {
    final p = _p;
    if (p == null) return;
    await p.setInt('res', resolution);
    await p.setInt('q', jpegQuality);
    await p.setBool('grid', grid);
    await p.setBool('level', level);
    await p.setBool('ai', ai);
    await p.setBool('hdr', hdr);
    await p.setBool('autosave', autoSave);
    await p.setBool('mirror', mirrorFront);
    await p.setBool('mooncrop', moonCrop);
    await p.setBool('wm', watermark);
    await p.setDouble('beauty', beauty);
    await p.setDouble('pblur', portraitBlur);
    await p.setInt('timer', timer);
    await p.setStringList('hidden', hidden.toList());
  }
}
