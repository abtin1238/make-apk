import 'package:flutter/material.dart';

class AT {
  static const bg = Color(0xFF05050F);
  static const panel = Color(0xFF15112E);
  static const purple = Color(0xFFB44CFF);
  static const blue = Color(0xFF2F7BFF);

  static ThemeData theme() => ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(primary: purple, secondary: blue, surface: panel),
        appBarTheme: const AppBarTheme(backgroundColor: bg, elevation: 0),
        sliderTheme: const SliderThemeData(
          activeTrackColor: purple,
          inactiveTrackColor: Colors.white24,
          thumbColor: Colors.white,
        ),
      );
}
