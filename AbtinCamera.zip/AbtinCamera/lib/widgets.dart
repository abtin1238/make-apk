import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'theme.dart';

class GridPainter extends CustomPainter {
  const GridPainter();
  @override
  void paint(Canvas c, Size s) {
    final p = Paint()
      ..color = Colors.white30
      ..strokeWidth = 1;
    for (var i = 1; i < 3; i++) {
      c.drawLine(Offset(s.width * i / 3, 0), Offset(s.width * i / 3, s.height), p);
      c.drawLine(Offset(0, s.height * i / 3), Offset(s.width, s.height * i / 3), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class LevelPainter extends CustomPainter {
  final double roll;
  LevelPainter(this.roll);
  @override
  void paint(Canvas c, Size s) {
    final ok = roll.abs() < 0.035;
    final col = ok ? const Color(0xFFFFD60A) : Colors.white70;
    final p = Paint()
      ..color = col
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;
    c.save();
    c.translate(s.width / 2, s.height / 2);
    final f = Paint()
      ..color = Colors.white38
      ..strokeWidth = 2
      ..strokeCap = StrokeCap.round;
    c.drawLine(const Offset(-96, 0), const Offset(-76, 0), f);
    c.drawLine(const Offset(76, 0), const Offset(96, 0), f);
    c.rotate(roll);
    c.drawLine(const Offset(-56, 0), const Offset(56, 0), p);
    c.restore();
  }

  @override
  bool shouldRepaint(covariant LevelPainter old) => old.roll != roll;
}

class ReticlePainter extends CustomPainter {
  const ReticlePainter();
  @override
  void paint(Canvas c, Size s) {
    final ctr = Offset(s.width / 2, s.height / 2);
    final r = math.min(s.width, s.height) * 0.22;
    final p = Paint()
      ..color = Colors.white54
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    c.drawCircle(ctr, r, p);
    final t = Paint()
      ..color = AT.purple
      ..strokeWidth = 2;
    c.drawLine(Offset(ctr.dx - r - 12, ctr.dy), Offset(ctr.dx - r + 8, ctr.dy), t);
    c.drawLine(Offset(ctr.dx + r - 8, ctr.dy), Offset(ctr.dx + r + 12, ctr.dy), t);
    c.drawLine(Offset(ctr.dx, ctr.dy - r - 12), Offset(ctr.dx, ctr.dy - r + 8), t);
    c.drawLine(Offset(ctr.dx, ctr.dy + r - 8), Offset(ctr.dx, ctr.dy + r + 12), t);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class DocGuidePainter extends CustomPainter {
  const DocGuidePainter();
  @override
  void paint(Canvas c, Size s) {
    final l = Rect.fromLTRB(s.width * 0.08, s.height * 0.1, s.width * 0.92, s.height * 0.9);
    final p = Paint()
      ..color = AT.purple
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round;
    const k = 30.0;
    final corners = [
      [l.left, l.top, 1.0, 1.0],
      [l.right, l.top, -1.0, 1.0],
      [l.left, l.bottom, 1.0, -1.0],
      [l.right, l.bottom, -1.0, -1.0],
    ];
    for (final q in corners) {
      c.drawLine(Offset(q[0], q[1]), Offset(q[0] + q[2] * k, q[1]), p);
      c.drawLine(Offset(q[0], q[1]), Offset(q[0], q[1] + q[3] * k), p);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

class FocusRing extends StatelessWidget {
  const FocusRing({super.key});
  @override
  Widget build(BuildContext context) => Container(
        width: 64,
        height: 64,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(color: const Color(0xFFFFD60A), width: 2),
        ),
      );
}
