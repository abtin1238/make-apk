import 'package:flutter/material.dart';
import 'settings.dart';
import 'theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = AppSettings.I;
    return ListenableBuilder(
      listenable: s,
      builder: (context, _) => Scaffold(
        appBar: AppBar(title: const Text('Settings')),
        body: ListView(children: [
          _header('Capture'),
          ListTile(
            title: const Text('Resolution'),
            trailing: DropdownButton<int>(
              value: s.resolution,
              underline: const SizedBox(),
              items: [
                for (var i = 0; i < 4; i++)
                  DropdownMenuItem(value: i, child: Text('${AppSettings.resLabels[i][0]} ${AppSettings.resLabels[i][1]}')),
              ],
              onChanged: (v) => s.update(() => s.resolution = v ?? 2),
            ),
          ),
          ListTile(
            title: Text('JPEG quality: ${s.jpegQuality}'),
            subtitle: Slider(
              min: 80,
              max: 100,
              divisions: 20,
              value: s.jpegQuality.toDouble(),
              onChanged: (v) => s.update(() => s.jpegQuality = v.round()),
            ),
          ),
          SwitchListTile(
            title: const Text('Save to gallery automatically'),
            value: s.autoSave,
            activeColor: AT.purple,
            onChanged: (v) => s.update(() => s.autoSave = v),
          ),
          SwitchListTile(
            title: const Text('Mirror front camera photos'),
            value: s.mirrorFront,
            activeColor: AT.purple,
            onChanged: (v) => s.update(() => s.mirrorFront = v),
          ),
          SwitchListTile(
            title: const Text('Watermark "Abtin Camera"'),
            value: s.watermark,
            activeColor: AT.purple,
            onChanged: (v) => s.update(() => s.watermark = v),
          ),
          _header('Viewfinder'),
          SwitchListTile(
            title: const Text('Grid lines'),
            value: s.grid,
            activeColor: AT.purple,
            onChanged: (v) => s.update(() => s.grid = v),
          ),
          SwitchListTile(
            title: const Text('Level indicator'),
            value: s.level,
            activeColor: AT.purple,
            onChanged: (v) => s.update(() => s.level = v),
          ),
          _header('Smart modes'),
          SwitchListTile(
            title: const Text('AI Enhance by default'),
            value: s.ai,
            activeColor: AT.purple,
            onChanged: (v) => s.update(() => s.ai = v),
          ),
          SwitchListTile(
            title: const Text('Auto-crop Moon'),
            subtitle: const Text('Centers and enlarges the Moon after capture'),
            value: s.moonCrop,
            activeColor: AT.purple,
            onChanged: (v) => s.update(() => s.moonCrop = v),
          ),
          SwitchListTile(
            title: const Text('HDR+'),
            value: s.hdr,
            activeColor: AT.purple,
            onChanged: (v) => s.update(() => s.hdr = v),
          ),
          _header('About'),
          const ListTile(
            leading: SizedBox(width: 40, height: 40, child: Image(image: AssetImage('assets/icon.png'))),
            title: Text('Abtin Camera'),
            subtitle: Text('Version 1.0.0 · Capture More... In Higher Quality'),
          ),
        ]),
      ),
    );
  }

  Widget _header(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 20, 16, 6),
        child: Text(t, style: const TextStyle(color: AT.purple, fontWeight: FontWeight.w700, fontSize: 13)),
      );
}
