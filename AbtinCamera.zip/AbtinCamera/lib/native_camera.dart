import 'package:flutter/services.dart';

class CamLens {
  final String id;
  final String? physical;
  final bool front;
  final String label;
  const CamLens(this.id, this.physical, this.front, this.label);

  factory CamLens.from(Map m) =>
      CamLens(m['id'] as String, m['physical'] as String?, m['front'] as bool, m['label'] as String);

  bool same(CamLens o) => id == o.id && physical == o.physical;
}

class CamCaps {
  final int textureId, previewW, previewH, photoW, photoH, sensorOrientation;
  final bool front;
  final int isoMin, isoMax, expMin, expMax;
  final double evMin, evMax, evStep, zoomMin, zoomMax, focusMin;

  const CamCaps({
    required this.textureId,
    required this.previewW,
    required this.previewH,
    required this.photoW,
    required this.photoH,
    required this.sensorOrientation,
    required this.front,
    required this.isoMin,
    required this.isoMax,
    required this.expMin,
    required this.expMax,
    required this.evMin,
    required this.evMax,
    required this.evStep,
    required this.zoomMin,
    required this.zoomMax,
    required this.focusMin,
  });

  factory CamCaps.from(Map m) => CamCaps(
        textureId: (m['textureId'] as num).toInt(),
        previewW: (m['previewW'] as num).toInt(),
        previewH: (m['previewH'] as num).toInt(),
        photoW: (m['photoW'] as num).toInt(),
        photoH: (m['photoH'] as num).toInt(),
        sensorOrientation: (m['sensorOrientation'] as num).toInt(),
        front: m['front'] as bool,
        isoMin: (m['isoMin'] as num).toInt(),
        isoMax: (m['isoMax'] as num).toInt(),
        expMin: (m['expMin'] as num).toInt(),
        expMax: (m['expMax'] as num).toInt(),
        evMin: (m['evMin'] as num).toDouble(),
        evMax: (m['evMax'] as num).toDouble(),
        evStep: (m['evStep'] as num).toDouble(),
        zoomMin: (m['zoomMin'] as num).toDouble(),
        zoomMax: (m['zoomMax'] as num).toDouble(),
        focusMin: (m['focusMin'] as num).toDouble(),
      );

  CamCaps withPreview(int w, int h) => CamCaps(
        textureId: textureId,
        previewW: w,
        previewH: h,
        photoW: photoW,
        photoH: photoH,
        sensorOrientation: sensorOrientation,
        front: front,
        isoMin: isoMin,
        isoMax: isoMax,
        expMin: expMin,
        expMax: expMax,
        evMin: evMin,
        evMax: evMax,
        evStep: evStep,
        zoomMin: zoomMin,
        zoomMax: zoomMax,
        focusMin: focusMin,
      );
}

/// Dart side of the native Camera2 engine (android/app/src/main/kotlin/.../NativeCamera.kt).
class NativeCamera {
  static const MethodChannel _ch = MethodChannel('abtin/camera');
  static const EventChannel _ev = EventChannel('abtin/camera/events');

  Stream<Map> get events => _ev.receiveBroadcastStream().where((e) => e is Map).cast<Map>();

  Future<void> _soft(String method, [Map<String, dynamic>? args]) async {
    try {
      await _ch.invokeMethod<void>(method, args);
    } catch (_) {}
  }

  Future<List<CamLens>> list() async {
    final r = await _ch.invokeMethod<List<dynamic>>('list') ?? const [];
    return [for (final e in r) CamLens.from(e as Map)];
  }

  Future<CamCaps> open(CamLens l, {required int res, required bool video}) async {
    final r = await _ch.invokeMethod<Map>('open', {
      'id': l.id,
      'physical': l.physical,
      'res': res,
      'video': video,
    });
    return CamCaps.from(r!);
  }

  Future<void> close() => _soft('close');

  Future<String> capture(int quality) async =>
      (await _ch.invokeMethod<String>('capture', {'quality': quality})) ?? '';

  Future<Map> startVideo({
    required String kind,
    required int res,
    required bool audio,
    double captureFps = 1.0,
  }) async {
    final r = await _ch.invokeMethod<Map>('startVideo', {
      'kind': kind,
      'res': res,
      'audio': audio,
      'captureFps': captureFps,
    });
    return r ?? const {};
  }

  Future<String> stopVideo() async => (await _ch.invokeMethod<String>('stopVideo')) ?? '';

  Future<void> setZoom(double v) => _soft('setZoom', {'v': v});
  Future<void> setEv(double v) => _soft('setEv', {'v': v});
  Future<void> setIso(int? v) => _soft('setIso', {'v': v});
  Future<void> setShutter(int? ns) => _soft('setShutter', {'v': ns});
  Future<void> setFocus(double? diopter) => _soft('setFocus', {'v': diopter});
  Future<void> setWb(int mode, int? kelvin) => _soft('setWb', {'mode': mode, 'kelvin': kelvin});
  Future<void> setFlash(int mode) => _soft('setFlash', {'v': mode});
  Future<void> tap(double x, double y) => _soft('tap', {'x': x, 'y': y});
  Future<void> setLocks(bool af, bool ae) => _soft('setLocks', {'af': af, 'ae': ae});
  Future<void> setAnalysis(bool on) => _soft('setAnalysis', {'v': on});

  Future<Map> getAuto() async {
    try {
      return (await _ch.invokeMethod<Map>('getAuto')) ?? const {};
    } catch (_) {
      return const {};
    }
  }
}
