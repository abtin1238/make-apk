import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:gal/gal.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:video_player/video_player.dart';
import 'theme.dart';

Future<Directory> capDir() async {
  final d = await getApplicationDocumentsDirectory();
  final c = Directory(p.join(d.path, 'captures'));
  if (!await c.exists()) await c.create(recursive: true);
  return c;
}

bool isVideoFile(File f) => f.path.toLowerCase().endsWith('.mp4');

Future<List<File>> listCaptures() async {
  final d = await capDir();
  final files = d
      .listSync()
      .whereType<File>()
      .where((f) => f.path.toLowerCase().endsWith('.jpg') || f.path.toLowerCase().endsWith('.mp4'))
      .toList();
  files.sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
  return files;
}

Future<void> _toGallery(String path, bool video) async {
  try {
    if (!await Gal.hasAccess(toAlbum: true)) {
      await Gal.requestAccess(toAlbum: true);
    }
    if (video) {
      await Gal.putVideo(path, album: 'Abtin Camera');
    } else {
      await Gal.putImage(path, album: 'Abtin Camera');
    }
  } catch (_) {}
}

Future<File> saveJpeg(Uint8List bytes, {bool toGallery = true}) async {
  final d = await capDir();
  final f = File(p.join(d.path, 'ABT_${DateTime.now().millisecondsSinceEpoch}.jpg'));
  await f.writeAsBytes(bytes, flush: true);
  if (toGallery) await _toGallery(f.path, false);
  return f;
}

Future<File> saveVideo(String src, {bool toGallery = true, String tag = ''}) async {
  final d = await capDir();
  final f = await File(src).copy(p.join(d.path, 'ABT_${tag.isEmpty ? '' : '${tag}_'}${DateTime.now().millisecondsSinceEpoch}.mp4'));
  if (toGallery) await _toGallery(f.path, true);
  return f;
}

class GalleryScreen extends StatefulWidget {
  const GalleryScreen({super.key});
  @override
  State<GalleryScreen> createState() => _GalleryScreenState();
}

class _GalleryScreenState extends State<GalleryScreen> {
  List<File> _files = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final l = await listCaptures();
    if (mounted) {
      setState(() {
        _files = l;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gallery')),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AT.purple))
          : _files.isEmpty
              ? const Center(child: Text('No photos yet', style: TextStyle(color: Colors.white54)))
              : GridView.builder(
                  padding: const EdgeInsets.all(2),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3, mainAxisSpacing: 2, crossAxisSpacing: 2),
                  itemCount: _files.length,
                  itemBuilder: (c, i) {
                    final f = _files[i];
                    return GestureDetector(
                      onTap: () async {
                        await Navigator.of(context).push(
                            MaterialPageRoute(builder: (_) => ViewerScreen(files: _files, index: i)));
                        _load();
                      },
                      child: isVideoFile(f)
                          ? Container(
                              color: AT.panel,
                              child: const Center(
                                  child: Icon(Icons.play_circle_fill, size: 40, color: Colors.white70)))
                          : Image.file(f, fit: BoxFit.cover, cacheWidth: 360),
                    );
                  },
                ),
    );
  }
}

class ViewerScreen extends StatefulWidget {
  final List<File> files;
  final int index;
  const ViewerScreen({super.key, required this.files, required this.index});
  @override
  State<ViewerScreen> createState() => _ViewerScreenState();
}

class _ViewerScreenState extends State<ViewerScreen> {
  late final PageController _pc = PageController(initialPage: widget.index);
  late List<File> _files = List<File>.of(widget.files);
  late int _i = widget.index;

  @override
  void dispose() {
    _pc.dispose();
    super.dispose();
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Delete this item?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;
    final f = _files[_i];
    try {
      await f.delete();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _files.removeAt(_i);
      if (_i >= _files.length) _i = _files.length - 1;
    });
    if (_files.isEmpty) Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(_files.isEmpty ? '' : '${_i + 1} / ${_files.length}'),
        actions: [
          IconButton(
              icon: const Icon(Icons.share),
              onPressed: () => Share.shareXFiles([XFile(_files[_i].path)])),
          IconButton(icon: const Icon(Icons.delete_outline), onPressed: _delete),
        ],
      ),
      body: PageView.builder(
        controller: _pc,
        itemCount: _files.length,
        onPageChanged: (i) => setState(() => _i = i),
        itemBuilder: (c, i) {
          final f = _files[i];
          return isVideoFile(f)
              ? _VideoPage(key: ValueKey(f.path), file: f)
              : InteractiveViewer(maxScale: 8, child: Center(child: Image.file(f)));
        },
      ),
    );
  }
}

class _VideoPage extends StatefulWidget {
  final File file;
  const _VideoPage({super.key, required this.file});
  @override
  State<_VideoPage> createState() => _VideoPageState();
}

class _VideoPageState extends State<_VideoPage> {
  late final VideoPlayerController _c = VideoPlayerController.file(widget.file);
  bool _ready = false;
  late double _speed = widget.file.path.contains('_SLO_')
      ? 0.25
      : widget.file.path.contains('_TLP_')
          ? 8.0
          : 1.0;

  @override
  void initState() {
    super.initState();
    _c.initialize().then((_) async {
      try {
        await _c.setPlaybackSpeed(_speed);
      } catch (_) {}
      if (mounted) setState(() => _ready = true);
    });
    _c.addListener(() {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  Future<void> _setSpeed(double v) async {
    setState(() => _speed = v);
    try {
      await _c.setPlaybackSpeed(v);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    if (!_ready) return const Center(child: CircularProgressIndicator(color: AT.purple));
    return Stack(alignment: Alignment.center, children: [
      GestureDetector(
        onTap: () => _c.value.isPlaying ? _c.pause() : _c.play(),
        child: Stack(alignment: Alignment.center, children: [
          Center(child: AspectRatio(aspectRatio: _c.value.aspectRatio, child: VideoPlayer(_c))),
          if (!_c.value.isPlaying) const Icon(Icons.play_circle_fill, size: 72, color: Colors.white70),
        ]),
      ),
      Positioned(
        bottom: 16,
        left: 0,
        right: 0,
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          for (final v in const [0.25, 0.5, 1.0, 2.0, 4.0, 8.0])
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: ChoiceChip(
                label: Text('${v == v.roundToDouble() ? v.round() : v}x', style: const TextStyle(fontSize: 12)),
                selected: _speed == v,
                selectedColor: AT.purple,
                visualDensity: VisualDensity.compact,
                onSelected: (_) => _setSpeed(v),
              ),
            ),
        ]),
      ),
    ]);
  }
}
