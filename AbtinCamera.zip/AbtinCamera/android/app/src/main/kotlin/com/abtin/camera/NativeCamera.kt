package com.abtin.camera

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraConstrainedHighSpeedCaptureSession
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureFailure
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.ColorSpaceTransform
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.RggbChannelVector
import android.hardware.camera2.params.SessionConfiguration
import android.hardware.camera2.params.StreamConfigurationMap
import android.media.ImageReader
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.Range
import android.util.Size
import android.view.Surface
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.view.TextureRegistry
import java.io.File
import java.util.concurrent.Executor
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Native Camera2 engine for Abtin Camera.
 * Gives Flutter: texture preview, JPEG capture, video / slow-motion / time-lapse recording and
 * full manual control (ISO, shutter, focus distance, white balance, EV, zoom, lens selection).
 */
class NativeCamera(
    private val activity: Activity,
    private val textures: TextureRegistry,
    messenger: BinaryMessenger,
) : MethodChannel.MethodCallHandler, EventChannel.StreamHandler {

    private class Sizes(val photo: Size?, val preview: Size, val analysis: Size?)

    private val ctx: Context = activity.applicationContext
    private val manager = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var bg: Handler? = null
    private var events: EventChannel.EventSink? = null

    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var highSpeed = false
    private var recHsRange: Range<Int>? = null
    private var chars: CameraCharacteristics? = null
    private var sizeChars: CameraCharacteristics? = null
    private var physId: String? = null
    private var entry: TextureRegistry.SurfaceTextureEntry? = null
    private var previewSurface: Surface? = null
    private var jpegReader: ImageReader? = null
    private var analysisReader: ImageReader? = null
    private var previewSize = Size(1280, 960)
    private var photoSize: Size? = null
    private var isVideoSession = false

    private var recorder: MediaRecorder? = null
    private var recordSurface: Surface? = null
    private var recordFile: File? = null
    @Volatile private var recording = false

    private var sensorOrientation = 90
    private var front = false

    private var pendingOpen: MethodChannel.Result? = null
    private var pendingCapture: MethodChannel.Result? = null

    // ---- user controls ----
    private var zoom = 1f
    private var evIndex = 0
    private var iso: Int? = null
    private var shutterNs: Long? = null
    private var focusDiopter: Float? = null
    private var awbMode = CaptureRequest.CONTROL_AWB_MODE_AUTO
    private var kelvin: Int? = null
    private var refGains: RggbChannelVector? = null
    private var refTransform: ColorSpaceTransform? = null
    private var flashMode = 0 // 0 off, 1 auto, 2 on, 3 torch
    private var afLock = false
    private var aeLock = false
    private var analysis = false
    private var afRegion: MeteringRectangle? = null

    // ---- last auto values ----
    @Volatile private var lastIso = 100
    @Volatile private var lastExp = 10_000_000L
    @Volatile private var lastGains: RggbChannelVector? = null
    @Volatile private var lastTransform: ColorSpaceTransform? = null
    private var lastSceneAt = 0L

    init {
        MethodChannel(messenger, "abtin/camera").setMethodCallHandler(this)
        EventChannel(messenger, "abtin/camera/events").setStreamHandler(this)
    }

    override fun onListen(arguments: Any?, sink: EventChannel.EventSink?) {
        events = sink
    }

    override fun onCancel(arguments: Any?) {
        events = null
    }

    fun dispose() {
        closeAll()
    }

    // ───────────────────────── method channel ─────────────────────────

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "list" -> result.success(listLenses())
                "open" -> openCamera(call, result)
                "close" -> {
                    closeAll()
                    result.success(null)
                }
                "capture" -> capture(call.argument<Int>("quality") ?: 95, result)
                "startVideo" -> startVideo(call, result)
                "stopVideo" -> stopVideo(result)
                "setZoom" -> {
                    zoom = (call.argument<Double>("v") ?: 1.0).toFloat()
                    refresh()
                    result.success(null)
                }
                "setEv" -> {
                    setEvStops(call.argument<Double>("v") ?: 0.0)
                    refresh()
                    result.success(null)
                }
                "setIso" -> {
                    iso = call.argument<Number>("v")?.toInt()
                    refresh()
                    result.success(null)
                }
                "setShutter" -> {
                    shutterNs = call.argument<Number>("v")?.toLong()
                    refresh()
                    result.success(null)
                }
                "setFocus" -> {
                    focusDiopter = call.argument<Double>("v")?.toFloat()
                    refresh()
                    result.success(null)
                }
                "setWb" -> {
                    val m = call.argument<Int>("mode") ?: 0
                    kelvin = call.argument<Number>("kelvin")?.toInt()
                    awbMode = when (m) {
                        1 -> CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT
                        2 -> CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT
                        3 -> CaptureRequest.CONTROL_AWB_MODE_SHADE
                        4 -> CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT
                        5 -> CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT
                        else -> CaptureRequest.CONTROL_AWB_MODE_AUTO
                    }
                    if (kelvin == null) {
                        refGains = null
                        refTransform = null
                    } else if (refGains == null) {
                        refGains = lastGains
                        refTransform = lastTransform
                    }
                    refresh()
                    result.success(null)
                }
                "setFlash" -> {
                    flashMode = call.argument<Int>("v") ?: 0
                    refresh()
                    result.success(null)
                }
                "tap" -> {
                    tapFocus(call.argument<Double>("x") ?: 0.5, call.argument<Double>("y") ?: 0.5)
                    result.success(null)
                }
                "setLocks" -> {
                    afLock = call.argument<Boolean>("af") ?: false
                    aeLock = call.argument<Boolean>("ae") ?: false
                    refresh()
                    result.success(null)
                }
                "setAnalysis" -> {
                    analysis = call.argument<Boolean>("v") ?: false
                    refresh()
                    result.success(null)
                }
                "getAuto" -> result.success(mapOf("iso" to lastIso, "exp" to lastExp))
                else -> result.notImplemented()
            }
        } catch (e: Exception) {
            result.error("cam", e.message, null)
        }
    }

    // ───────────────────────── lenses ─────────────────────────

    private fun equivFocal(c: CameraCharacteristics): Double {
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull() ?: return 0.0
        val size = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE) ?: return 0.0
        val diag = sqrt((size.width * size.width + size.height * size.height).toDouble())
        return f * 43.27 / diag
    }

    private fun lensLabel(c: CameraCharacteristics, isFront: Boolean): String {
        if (isFront) return "FRONT"
        val eq = equivFocal(c)
        return when {
            eq <= 0.0 -> "WIDE"
            eq < 21 -> "ULTRA"
            eq < 36 -> "WIDE"
            eq < 75 -> "TELE"
            else -> "ZOOM"
        }
    }

    private fun listLenses(): List<Map<String, Any?>> {
        val out = ArrayList<Map<String, Any?>>()
        val ids = manager.cameraIdList
        for (id in ids) {
            val c = manager.getCameraCharacteristics(id)
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: intArrayOf()
            if (!caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)) continue
            val isFront = c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
            out.add(mapOf("id" to id, "physical" to null, "front" to isFront, "label" to lensLabel(c, isFront)))
            if (Build.VERSION.SDK_INT >= 28 && !isFront) {
                for (pid in c.physicalCameraIds) {
                    if (ids.contains(pid)) continue
                    val pc = try {
                        manager.getCameraCharacteristics(pid)
                    } catch (e: Exception) {
                        continue
                    }
                    out.add(mapOf("id" to id, "physical" to pid, "front" to false, "label" to lensLabel(pc, false)))
                }
            }
        }
        return out
    }

    // ───────────────────────── open / close ─────────────────────────

    private fun startThread() {
        val t = HandlerThread("abtin-cam")
        t.start()
        thread = t
        bg = Handler(t.looper)
    }

    private fun bestPreview(list: List<Size>, ar: Double): Size {
        val m = list.filter { abs(it.width.toDouble() / it.height - ar) < 0.02 && max(it.width, it.height) <= 1920 }
        return m.maxByOrNull { it.width * it.height }
            ?: list.filter { max(it.width, it.height) <= 1920 }.maxByOrNull { it.width * it.height }
            ?: list.first()
    }

    private fun pickSizes(sc: CameraCharacteristics, res: Int, video: Boolean): Sizes {
        val map = sc.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            ?: throw IllegalStateException("No stream configuration map")
        val prevAll = (map.getOutputSizes(SurfaceTexture::class.java) ?: emptyArray()).toList()
        if (video) return Sizes(null, bestPreview(prevAll, 16.0 / 9), null)
        val jpegs = (map.getOutputSizes(ImageFormat.JPEG) ?: emptyArray()).toList()
        val r43 = jpegs.filter { abs(it.width.toDouble() / it.height - 4.0 / 3) < 0.02 }
        val cand = if (r43.isNotEmpty()) r43 else jpegs
        val target = intArrayOf(1280, 1920, 3840, Int.MAX_VALUE)[res.coerceIn(0, 3)]
        val photo: Size = if (res >= 3) {
            cand.maxByOrNull { it.width.toLong() * it.height }!!
        } else {
            (cand.filter { max(it.width, it.height) <= target }.maxByOrNull { it.width.toLong() * it.height }
                ?: cand.minByOrNull { it.width.toLong() * it.height })!!
        }
        val ar = photo.width.toDouble() / photo.height
        val preview = bestPreview(prevAll, ar)
        val yuv = (map.getOutputSizes(ImageFormat.YUV_420_888) ?: emptyArray()).toList()
            .filter { abs(it.width.toDouble() / it.height - ar) < 0.02 && max(it.width, it.height) <= 640 }
        val analysisSize = yuv.minByOrNull { abs(max(it.width, it.height) - 320) }
        return Sizes(photo, preview, analysisSize)
    }

    private fun openCamera(call: MethodCall, result: MethodChannel.Result) {
        if (ctx.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            result.error("perm", "Camera permission missing", null)
            return
        }
        closeAll()
        val id = call.argument<String>("id")
        if (id == null) {
            result.error("arg", "id missing", null)
            return
        }
        val phys = call.argument<String>("physical")
        val res = call.argument<Int>("res") ?: 2
        val video = call.argument<Boolean>("video") ?: false
        physId = phys
        isVideoSession = video
        startThread()

        val c = manager.getCameraCharacteristics(id)
        chars = c
        sizeChars = if (phys != null) manager.getCameraCharacteristics(phys) else c
        sensorOrientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        front = c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT

        zoom = 1f
        evIndex = 0
        iso = null
        shutterNs = null
        focusDiopter = null
        awbMode = CaptureRequest.CONTROL_AWB_MODE_AUTO
        kelvin = null
        refGains = null
        refTransform = null
        afLock = false
        aeLock = false
        afRegion = null

        val sizes = pickSizes(sizeChars!!, res, video)
        photoSize = sizes.photo
        previewSize = sizes.preview
        val e = textures.createSurfaceTexture()
        entry = e
        val st = e.surfaceTexture()
        st.setDefaultBufferSize(sizes.preview.width, sizes.preview.height)
        previewSurface = Surface(st)

        if (!video && sizes.photo != null) {
            val jr = ImageReader.newInstance(sizes.photo.width, sizes.photo.height, ImageFormat.JPEG, 2)
            jr.setOnImageAvailableListener(ImageReader.OnImageAvailableListener { r ->
                val img = r.acquireNextImage()
                if (img == null) return@OnImageAvailableListener
                try {
                    val buf = img.planes[0].buffer
                    val bytes = ByteArray(buf.remaining())
                    buf.get(bytes)
                    val f = File(ctx.cacheDir, "abt_${System.currentTimeMillis()}.jpg")
                    f.writeBytes(bytes)
                    val res2 = pendingCapture
                    pendingCapture = null
                    main.post { res2?.success(f.absolutePath) }
                } catch (ex: Exception) {
                    val res2 = pendingCapture
                    pendingCapture = null
                    main.post { res2?.error("capture", ex.message, null) }
                } finally {
                    img.close()
                }
            }, bg)
            jpegReader = jr
            val asz = sizes.analysis
            if (asz != null) {
                val ar = ImageReader.newInstance(asz.width, asz.height, ImageFormat.YUV_420_888, 2)
                ar.setOnImageAvailableListener(ImageReader.OnImageAvailableListener { r -> analyze(r) }, bg)
                analysisReader = ar
            }
        }

        pendingOpen = result
        manager.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(cd: CameraDevice) {
                device = cd
                createPreviewSession()
            }

            override fun onDisconnected(cd: CameraDevice) {
                cd.close()
                device = null
                failOpen("Camera disconnected")
            }

            override fun onError(cd: CameraDevice, error: Int) {
                cd.close()
                device = null
                failOpen("Camera error $error")
            }
        }, bg)
    }

    private fun failOpen(msg: String) {
        val r = pendingOpen
        pendingOpen = null
        if (r != null) main.post { r.error("open", msg, null) }
    }

    private fun createPreviewSession() {
        val dev = device ?: return
        val surfaces = ArrayList<Surface>()
        previewSurface?.let { surfaces.add(it) }
        jpegReader?.let { surfaces.add(it.surface) }
        analysisReader?.let { surfaces.add(it.surface) }
        makeSession(dev, surfaces, false, { s ->
            session = s
            highSpeed = false
            updatePreview()
            completeOpen()
        }, { msg -> failOpen(msg) })
    }

    private fun makeSession(
        dev: CameraDevice,
        surfaces: List<Surface>,
        high: Boolean,
        ok: (CameraCaptureSession) -> Unit,
        fail: (String) -> Unit,
    ) {
        val cb = object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                ok(s)
            }

            override fun onConfigureFailed(s: CameraCaptureSession) {
                fail("Session configuration failed")
            }
        }
        val h = bg ?: return
        try {
            if (high) {
                dev.createConstrainedHighSpeedCaptureSession(surfaces, cb, h)
            } else if (Build.VERSION.SDK_INT >= 28) {
                val cfgs = surfaces.map { sf ->
                    val oc = OutputConfiguration(sf)
                    physId?.let { p -> oc.setPhysicalCameraId(p) }
                    oc
                }
                dev.createCaptureSession(
                    SessionConfiguration(SessionConfiguration.SESSION_REGULAR, cfgs, Executor { r -> h.post(r) }, cb)
                )
            } else {
                @Suppress("DEPRECATION")
                dev.createCaptureSession(surfaces, cb, h)
            }
        } catch (e: Exception) {
            fail(e.message ?: "createCaptureSession failed")
        }
    }

    private fun zoomRange(): Range<Float> {
        val c = chars ?: return Range(1f, 1f)
        if (Build.VERSION.SDK_INT >= 30) {
            val r = c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
            if (r != null) return r
        }
        return Range(1f, c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f)
    }

    private fun completeOpen() {
        val r = pendingOpen ?: return
        pendingOpen = null
        val c = chars ?: return
        val isoR = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        val expR = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val evR = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
        val evStep = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toDouble() ?: 0.0
        val zr = zoomRange()
        val ps = photoSize
        val map = mapOf(
            "textureId" to entry!!.id(),
            "previewW" to previewSize.width,
            "previewH" to previewSize.height,
            "photoW" to (ps?.width ?: 0),
            "photoH" to (ps?.height ?: 0),
            "sensorOrientation" to sensorOrientation,
            "front" to front,
            "isoMin" to (isoR?.lower ?: 100),
            "isoMax" to (isoR?.upper ?: 100),
            "expMin" to (expR?.lower ?: 0L),
            "expMax" to (expR?.upper ?: 0L),
            "evMin" to (evR?.lower ?: 0) * evStep,
            "evMax" to (evR?.upper ?: 0) * evStep,
            "evStep" to evStep,
            "zoomMin" to zr.lower.toDouble(),
            "zoomMax" to zr.upper.toDouble(),
            "focusMin" to (c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f).toDouble(),
        )
        main.post { r.success(map) }
    }

    private fun releaseRecorder() {
        try {
            recorder?.reset()
            recorder?.release()
        } catch (e: Exception) {
        }
        recorder = null
        try {
            recordSurface?.release()
        } catch (e: Exception) {
        }
        recordSurface = null
    }

    private fun closeAll() {
        try {
            if (recording) recorder?.stop()
        } catch (e: Exception) {
        }
        recording = false
        releaseRecorder()
        try {
            session?.close()
        } catch (e: Exception) {
        }
        session = null
        try {
            device?.close()
        } catch (e: Exception) {
        }
        device = null
        try {
            jpegReader?.close()
            analysisReader?.close()
        } catch (e: Exception) {
        }
        jpegReader = null
        analysisReader = null
        try {
            previewSurface?.release()
        } catch (e: Exception) {
        }
        previewSurface = null
        try {
            entry?.release()
        } catch (e: Exception) {
        }
        entry = null
        thread?.quitSafely()
        thread = null
        bg = null
        val pc = pendingCapture
        pendingCapture = null
        if (pc != null) main.post { pc.error("capture", "Camera closed", null) }
        val po = pendingOpen
        pendingOpen = null
        if (po != null) main.post { po.error("open", "Camera closed", null) }
    }

    // ───────────────────────── controls ─────────────────────────

    private fun refresh() {
        val h = bg ?: return
        h.post {
            if (session != null) {
                if (recording) updateRecordRequest() else updatePreview()
            }
        }
    }

    private fun setEvStops(v: Double) {
        val c = chars ?: return
        val step = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toDouble() ?: 0.0
        val r = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
        evIndex = if (step > 0 && r != null) (v / step).roundToInt().coerceIn(r.lower, r.upper) else 0
    }

    private fun applyZoom(b: CaptureRequest.Builder) {
        val c = chars ?: return
        val zr = zoomRange()
        val z = zoom.coerceIn(zr.lower, zr.upper)
        if (Build.VERSION.SDK_INT >= 30) {
            b.set(CaptureRequest.CONTROL_ZOOM_RATIO, z)
        } else {
            val r = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
            val w = (r.width() / z).toInt()
            val h = (r.height() / z).toInt()
            b.set(
                CaptureRequest.SCALER_CROP_REGION,
                Rect(r.centerX() - w / 2, r.centerY() - h / 2, r.centerX() + w / 2, r.centerY() + h / 2)
            )
        }
    }

    private fun applyControls(b: CaptureRequest.Builder, still: Boolean) {
        val c = chars ?: return
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        applyZoom(b)

        // focus
        val minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        val fd = focusDiopter
        if (fd != null && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, fd.coerceIn(0f, minFocus))
        } else if (afLock) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
        } else {
            b.set(
                CaptureRequest.CONTROL_AF_MODE,
                if (recording) CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO else CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE
            )
        }
        val rect = afRegion
        if (rect != null) {
            if ((c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0) > 0) {
                b.set(CaptureRequest.CONTROL_AF_REGIONS, arrayOf(rect))
            }
            if ((c.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0) > 0) {
                b.set(CaptureRequest.CONTROL_AE_REGIONS, arrayOf(rect))
            }
        }

        // exposure
        val torch = flashMode == 3
        val manual = iso != null || shutterNs != null
        if (manual) {
            val isoR = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 800)
            val expR = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(100_000L, 1_000_000_000L)
            val i = iso
            val s = shutterNs
            var isoV = i ?: lastIso
            var expV = s ?: lastExp
            if (i != null && s == null) expV = (lastExp.toDouble() * lastIso / i).toLong()
            if (i == null && s != null) isoV = (lastIso.toDouble() * lastExp / s).roundToInt()
            isoV = isoV.coerceIn(isoR.lower, isoR.upper)
            expV = expV.coerceIn(expR.lower, expR.upper)
            b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, isoV)
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, expV)
            b.set(CaptureRequest.SENSOR_FRAME_DURATION, max(expV, 33_333_333L))
        } else {
            val aeMode = when {
                flashMode == 1 && still -> CaptureRequest.CONTROL_AE_MODE_ON_AUTO_FLASH
                flashMode == 2 && still -> CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH
                else -> CaptureRequest.CONTROL_AE_MODE_ON
            }
            b.set(CaptureRequest.CONTROL_AE_MODE, aeMode)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIndex)
            if (aeLock && c.get(CameraCharacteristics.CONTROL_AE_LOCK_AVAILABLE) == true) {
                b.set(CaptureRequest.CONTROL_AE_LOCK, true)
            }
        }
        b.set(CaptureRequest.FLASH_MODE, if (torch) CaptureRequest.FLASH_MODE_TORCH else CaptureRequest.FLASH_MODE_OFF)

        // white balance
        val k = kelvin
        val rg = refGains
        if (k != null && rg != null) {
            val f = (k / 5500.0).pow(0.6)
            b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_OFF)
            b.set(CaptureRequest.COLOR_CORRECTION_MODE, CaptureRequest.COLOR_CORRECTION_MODE_TRANSFORM_MATRIX)
            b.set(
                CaptureRequest.COLOR_CORRECTION_GAINS,
                RggbChannelVector((rg.red * f).toFloat(), rg.greenEven, rg.greenOdd, (rg.blue / f).toFloat())
            )
            refTransform?.let { b.set(CaptureRequest.COLOR_CORRECTION_TRANSFORM, it) }
        } else {
            b.set(CaptureRequest.CONTROL_AWB_MODE, awbMode)
        }
    }

    private val previewCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            val aeMode = res.get(CaptureResult.CONTROL_AE_MODE)
            if (aeMode != null && aeMode != CaptureRequest.CONTROL_AE_MODE_OFF) {
                res.get(CaptureResult.SENSOR_SENSITIVITY)?.let { lastIso = it }
                res.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { lastExp = it }
            }
            res.get(CaptureResult.COLOR_CORRECTION_GAINS)?.let { lastGains = it }
            res.get(CaptureResult.COLOR_CORRECTION_TRANSFORM)?.let { lastTransform = it }
        }
    }

    private fun updatePreview() {
        val dev = device ?: return
        val s = session ?: return
        if (recording) {
            updateRecordRequest()
            return
        }
        if (highSpeed) return
        try {
            val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            previewSurface?.let { b.addTarget(it) }
            if (analysis) analysisReader?.let { b.addTarget(it.surface) }
            applyControls(b, false)
            s.setRepeatingRequest(b.build(), previewCb, bg)
        } catch (e: Exception) {
        }
    }

    private fun updateRecordRequest() {
        val dev = device ?: return
        val s = session ?: return
        val rs = recordSurface ?: return
        val ps = previewSurface ?: return
        try {
            val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
            b.addTarget(ps)
            b.addTarget(rs)
            val hs = recHsRange
            if (highSpeed && hs != null && s is CameraConstrainedHighSpeedCaptureSession) {
                b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, hs)
                b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO)
                s.setRepeatingBurst(s.createHighSpeedRequestList(b.build()), null, bg)
            } else {
                applyControls(b, false)
                s.setRepeatingRequest(b.build(), previewCb, bg)
            }
        } catch (e: Exception) {
        }
    }

    private fun tapFocus(nx0: Double, ny: Double) {
        val c = chars ?: return
        val dev = device ?: return
        val s = session ?: return
        if (highSpeed) return
        val r = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
        val z = zoom.coerceAtLeast(1f)
        val cw = (r.width() / z).toInt()
        val ch = (r.height() / z).toInt()
        val left = r.centerX() - cw / 2
        val top = r.centerY() - ch / 2
        val nx = if (front) 1.0 - nx0 else nx0
        val sx: Double
        val sy: Double
        when (sensorOrientation) {
            0 -> { sx = nx; sy = ny }
            90 -> { sx = ny; sy = 1.0 - nx }
            180 -> { sx = 1.0 - nx; sy = 1.0 - ny }
            else -> { sx = 1.0 - ny; sy = nx }
        }
        val half = (min(cw, ch) * 0.08).toInt().coerceAtLeast(8)
        val cx = left + (sx * cw).toInt()
        val cy = top + (sy * ch).toInt()
        val x = (cx - half).coerceIn(r.left, r.right - 2 * half)
        val y = (cy - half).coerceIn(r.top, r.bottom - 2 * half)
        afRegion = MeteringRectangle(x, y, 2 * half, 2 * half, MeteringRectangle.METERING_WEIGHT_MAX - 1)
        bg?.post {
            try {
                val b = dev.createCaptureRequest(if (recording) CameraDevice.TEMPLATE_RECORD else CameraDevice.TEMPLATE_PREVIEW)
                previewSurface?.let { b.addTarget(it) }
                if (recording) recordSurface?.let { b.addTarget(it) }
                applyControls(b, false)
                if (focusDiopter == null) {
                    b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_AUTO)
                    b.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START)
                }
                s.capture(b.build(), null, bg)
            } catch (e: Exception) {
            }
            if (recording) updateRecordRequest() else updatePreview()
        }
    }

    // ───────────────────────── capture ─────────────────────────

    private fun capture(quality: Int, result: MethodChannel.Result) {
        val dev = device
        val s = session
        val reader = jpegReader
        if (dev == null || s == null || reader == null || recording || highSpeed) {
            result.error("capture", "Camera not ready for photos", null)
            return
        }
        if (pendingCapture != null) {
            result.error("capture", "Capture in progress", null)
            return
        }
        pendingCapture = result
        val hasFlash = chars?.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        val manual = iso != null || shutterNs != null
        val needPre = hasFlash && !manual && (flashMode == 1 || flashMode == 2)
        val doCapture = Runnable {
            try {
                val b = dev.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
                b.addTarget(reader.surface)
                applyControls(b, true)
                b.set(CaptureRequest.JPEG_QUALITY, quality.coerceIn(50, 100).toByte())
                b.set(CaptureRequest.JPEG_ORIENTATION, sensorOrientation)
                s.capture(b.build(), object : CameraCaptureSession.CaptureCallback() {
                    override fun onCaptureFailed(sess: CameraCaptureSession, req: CaptureRequest, f: CaptureFailure) {
                        val r = pendingCapture
                        pendingCapture = null
                        if (r != null) main.post { r.error("capture", "Capture failed", null) }
                    }
                }, bg)
            } catch (e: Exception) {
                val r = pendingCapture
                pendingCapture = null
                if (r != null) main.post { r.error("capture", e.message, null) }
            }
        }
        if (needPre) {
            try {
                val p = dev.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                previewSurface?.let { p.addTarget(it) }
                applyControls(p, false)
                p.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER_START)
                s.capture(p.build(), null, bg)
            } catch (e: Exception) {
            }
            bg?.postDelayed(doCapture, 700)
        } else {
            bg?.post(doCapture)
        }
    }

    // ───────────────────────── scene analysis ─────────────────────────

    private fun analyze(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        try {
            val now = SystemClock.elapsedRealtime()
            if (!analysis || now - lastSceneAt < 700) return
            lastSceneAt = now
            val plane = img.planes[0]
            val buf = plane.buffer
            val rs = plane.rowStride
            val w = img.width
            val h = img.height
            val step = 4
            var sum = 0L
            var n = 0
            var bright = 0
            var minX = w
            var maxX = 0
            var minY = h
            var maxY = 0
            var y = 0
            while (y < h) {
                var x = 0
                while (x < w) {
                    val v = buf.get(y * rs + x).toInt() and 0xFF
                    sum += v
                    n++
                    if (v > 200) {
                        bright++
                        if (x < minX) minX = x
                        if (x > maxX) maxX = x
                        if (y < minY) minY = y
                        if (y > maxY) maxY = y
                    }
                    x += step
                }
                y += step
            }
            if (n == 0) return
            val mean = sum.toDouble() / n
            var scene = "Auto"
            if (mean < 70 && bright >= 3) {
                val area = ((maxX - minX) / step + 1.0) * ((maxY - minY) / step + 1.0)
                val fill = bright / area
                val frac = bright.toDouble() / n
                if (frac > 0.001 && frac < 0.12 && fill > 0.45) scene = "Moon"
            }
            if (scene == "Auto" && mean < 50) scene = "Night"
            main.post { events?.success(mapOf("scene" to scene)) }
        } finally {
            img.close()
        }
    }

    // ───────────────────────── video ─────────────────────────

    private fun pickVideoSize(map: StreamConfigurationMap, res: Int): Size {
        val sizes = (map.getOutputSizes(MediaRecorder::class.java) ?: emptyArray()).toList()
        val targetH = intArrayOf(720, 1080, 2160, 2160)[res.coerceIn(0, 3)]
        val c16 = sizes.filter { abs(it.width.toDouble() / it.height - 16.0 / 9) < 0.02 && it.height <= targetH }
        return c16.maxByOrNull { it.width * it.height }
            ?: sizes.filter { it.height <= targetH }.maxByOrNull { it.width * it.height }
            ?: sizes.first()
    }

    private fun startVideo(call: MethodCall, result: MethodChannel.Result) {
        val dev = device
        val c = chars
        if (dev == null || c == null || !isVideoSession || recording) {
            result.error("video", "Camera not ready for video", null)
            return
        }
        val kind = call.argument<String>("kind") ?: "normal"
        val res = call.argument<Int>("res") ?: 2
        val wantAudio = (call.argument<Boolean>("audio") ?: false) && kind == "normal" &&
            ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val captureFps = call.argument<Double>("captureFps") ?: 1.0
        val map = sizeChars?.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        if (map == null) {
            result.error("video", "No stream map", null)
            return
        }

        var vSize = pickVideoSize(map, res)
        var fps = 30
        var hs: Range<Int>? = null
        if (kind == "slowmo") {
            try {
                val hsSizes = map.highSpeedVideoSizes?.toList() ?: emptyList()
                val pick = hsSizes.firstOrNull { it.width == 1920 && it.height == 1080 }
                    ?: hsSizes.firstOrNull { it.width == 1280 && it.height == 720 }
                    ?: hsSizes.maxByOrNull { it.width * it.height }
                if (pick != null) {
                    val ranges = map.getHighSpeedVideoFpsRangesFor(pick).toList().filter { it.lower == it.upper && it.upper >= 120 }
                    val r = ranges.firstOrNull { it.upper == 120 } ?: ranges.minByOrNull { it.upper }
                    if (r != null) {
                        vSize = pick
                        fps = r.upper
                        hs = r
                    }
                }
            } catch (e: Exception) {
                hs = null
            }
        }

        val file = File(ctx.cacheDir, "abt_${System.currentTimeMillis()}.mp4")
        recordFile = file
        val mr = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(ctx) else @Suppress("DEPRECATION") MediaRecorder()
        try {
            if (wantAudio) mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setOutputFile(file.absolutePath)
            val px = vSize.width.toLong() * vSize.height
            var bitrate = when {
                px >= 3840L * 2160 -> 45_000_000
                px >= 1920L * 1080 -> 18_000_000
                else -> 9_000_000
            }
            if (fps > 60) bitrate *= 2
            mr.setVideoEncodingBitRate(bitrate)
            mr.setVideoFrameRate(fps)
            if (kind == "timelapse") mr.setCaptureRate(captureFps)
            mr.setVideoSize(vSize.width, vSize.height)
            mr.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (wantAudio) {
                mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                mr.setAudioEncodingBitRate(128_000)
                mr.setAudioSamplingRate(44_100)
            }
            mr.setOrientationHint(sensorOrientation)
            mr.prepare()
        } catch (e: Exception) {
            try {
                mr.release()
            } catch (x: Exception) {
            }
            result.error("video", "Recorder setup failed: ${e.message}", null)
            return
        }
        recorder = mr
        recordSurface = mr.surface

        try {
            session?.stopRepeating()
        } catch (e: Exception) {
        }
        try {
            session?.close()
        } catch (e: Exception) {
        }
        session = null
        if (hs != null) {
            entry?.surfaceTexture()?.setDefaultBufferSize(vSize.width, vSize.height)
            previewSize = vSize
        }
        val ps = previewSurface
        val rsf = recordSurface
        if (ps == null || rsf == null) {
            releaseRecorder()
            result.error("video", "Surfaces not ready", null)
            return
        }
        val useHigh = hs != null
        makeSession(dev, listOf(ps, rsf), useHigh, { s ->
            session = s
            highSpeed = useHigh
            recHsRange = hs
            recording = true
            updateRecordRequest()
            try {
                recorder?.start()
                val m = mapOf(
                    "previewW" to previewSize.width,
                    "previewH" to previewSize.height,
                    "fps" to fps,
                    "highSpeed" to useHigh,
                )
                main.post { result.success(m) }
            } catch (e: Exception) {
                recording = false
                releaseRecorder()
                main.post { result.error("video", "Could not start recording: ${e.message}", null) }
            }
        }, { msg ->
            releaseRecorder()
            createPreviewSessionVideoOnly()
            main.post { result.error("video", msg, null) }
        })
    }

    private fun createPreviewSessionVideoOnly() {
        val dev = device ?: return
        val ps = previewSurface ?: return
        makeSession(dev, listOf(ps), false, { s ->
            session = s
            highSpeed = false
            updatePreview()
        }, { })
    }

    private fun stopVideo(result: MethodChannel.Result) {
        if (!recording) {
            result.error("video", "Not recording", null)
            return
        }
        val file = recordFile
        recording = false
        try {
            session?.stopRepeating()
            session?.abortCaptures()
        } catch (e: Exception) {
        }
        var ok = true
        try {
            recorder?.stop()
        } catch (e: RuntimeException) {
            ok = false
            file?.delete()
        }
        releaseRecorder()
        try {
            session?.close()
        } catch (e: Exception) {
        }
        session = null
        highSpeed = false
        recHsRange = null
        val dev = device
        val ps = previewSurface
        if (dev == null || ps == null) {
            result.error("video", "Camera closed", null)
            return
        }
        makeSession(dev, listOf(ps), false, { s ->
            session = s
            updatePreview()
            main.post {
                if (ok && file != null) result.success(file.absolutePath)
                else result.error("video", "Recording too short", null)
            }
        }, { msg -> main.post { result.error("video", msg, null) } })
    }
}
