package com.abtin.camera

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : FlutterActivity() {
    private var cam: NativeCamera? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        cam = NativeCamera(this, flutterEngine.renderer, flutterEngine.dartExecutor.binaryMessenger)
    }

    override fun onDestroy() {
        cam?.dispose()
        super.onDestroy()
    }
}
