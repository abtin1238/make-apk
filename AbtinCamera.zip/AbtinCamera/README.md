# Abtin Camera

Abtin Camera is an Android-first Flutter camera app. The repository contains the Flutter UI,
image-processing and document-scanner code, plus a native Android Camera2 engine source module.

## Requirements

- Flutter 3.29.3 (Dart 3.7.x)
- Java 17
- Android SDK platform/build-tools compatible with the Flutter SDK
- Android device with camera hardware for runtime validation

## Local setup

```bash
flutter --version
flutter pub get
flutter analyze
flutter test
flutter build apk --release
flutter build appbundle --release
```

The camera screen is driven by the native Camera2 engine (`android/app/src/main/kotlin/com/abtin/camera/NativeCamera.kt`),
registered by `MainActivity` on the `abtin/camera` and `abtin/camera/events` channels and used from Dart through
`lib/native_camera.dart`. It provides texture preview, JPEG capture, video recording, real time-lapse
(`MediaRecorder.setCaptureRate`), constrained high-speed (120 fps) slow motion when the device supports it, and manual
ISO, shutter, focus distance, white balance, EV, zoom and lens selection. Available ranges depend on the device.

Release signing uses `ANDROID_KEYSTORE_PATH`, `ANDROID_KEY_ALIAS`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_PASSWORD`
if set, otherwise `android/key.properties` (local keystore `android/app/abtin-release.jks`), otherwise debug signing.

## GitHub Actions

Workflow: `.github/workflows/android-build.yml`

Every push, pull request and manual dispatch runs dependency resolution, analyzer, tests, and
release APK/AAB builds. The runner installs Gradle 8.10.2 and generates the official wrapper
before invoking Flutter, because the supplied archive did not contain the wrapper scripts/JAR. Artifacts are uploaded as `abtin-camera-android`.

## Release signing

Never commit a keystore or signing passwords. Add these GitHub repository secrets:

- `ANDROID_KEYSTORE_BASE64`: Base64-encoded JKS/PKCS12 keystore
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_PASSWORD`

When all four secrets exist, the workflow decodes the keystore into the runner's temporary
workspace and supplies environment variables to Gradle. When secrets are absent, Gradle uses
the Android debug signing config for CI artifacts. Debug-signed artifacts are for testing only
and cannot be used as seamless updates to a store-signed installation.

Generate a Base64 value locally with:
```bash
base64 -w 0 your-upload-key.jks
```
On PowerShell:
```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("your-upload-key.jks"))
```

## Implemented project functionality

- Existing twelve-mode selector and camera UI retained.
- Flutter camera preview, still capture, recording, zoom, exposure compensation, flash,
  tap-to-focus, sensor level, and front/back camera switching through the `camera` plugin.
- Multi-frame bracket capture path for HDR and multi-frame night capture path.
- Image adjustment and document perspective/filter processing in Dart isolates.
- Local capture gallery, playback, deletion, sharing, and PDF generation in the scanner.
- Native Camera2 source included for future Dart-side integration; see limitation above.

## Known technical limitations

- Portrait blur currently uses a geometric/oval blur mask, not semantic subject segmentation.
- Panorama currently uses a center-strip stitch, not feature matching, homography or seam optimization.
- Night/HDR processing does not currently provide robust optical-flow alignment or ghost removal.
- Slow-motion mode currently records through the standard camera plugin path; it does not guarantee
  high-frame-rate Camera2 capture. It must not be treated as native high-FPS slow motion.
- Time-lapse playback is a viewing-speed treatment, not interval-based capture.
- Moon mode can optimize crop/exposure but cannot create optical telephoto reach or real detail.
- Actual sensor controls, physical lens identification, high-FPS modes and image quality require
  testing on specific Android hardware.

These limitations are documented rather than represented as completed computational-photography
features. No application can guarantee clear Moon photographs independently of the phone's optics,
sensor, stabilization and atmospheric conditions.
