package ir.abtin.sms

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.ContentProviderOperation
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.ColorDrawable
import android.database.ContentObserver
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.CallLog
import android.provider.ContactsContract
import android.telecom.Call as TCall
import android.telecom.CallAudioState
import android.telecom.PhoneAccountHandle
import android.telecom.PhoneAccount
import android.telecom.InCallService
import android.telecom.TelecomManager
import android.widget.RemoteViews
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.app.NotificationCompat
import androidx.core.app.Person
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private val GREEN = Color(0xFF34C77B)
private val RED = Color(0xFFFF4D5E)

// =====================================================================
// Placing calls
// =====================================================================
private fun normalizePhoneNumber(number: String): String = number.trim().map { ch ->
    when (ch) {
        in '۰'..'۹' -> ('0'.code + (ch.code - '۰'.code)).toChar()
        in '٠'..'٩' -> ('0'.code + (ch.code - '٠'.code)).toChar()
        else -> ch
    }
}.joinToString("")

private fun placePhoneCall(ctx: Context, number: String, account: PhoneAccountHandle?) {
    val tm = ctx.getSystemService(TelecomManager::class.java)
    val uri = Uri.fromParts("tel", number, null)
    val extras = Bundle().apply {
        if (account != null) putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, account)
    }
    if (ctx.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
        val placed = runCatching { tm.placeCall(uri, extras); true }.getOrDefault(false)
        if (placed) return
        val callIntent = Intent(Intent.ACTION_CALL, uri).putExtras(extras)
        if (ctx !is Activity) callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (runCatching { ctx.startActivity(callIntent); true }.getOrDefault(false)) return
    }
    val dialIntent = Intent(Intent.ACTION_DIAL, uri)
    if (ctx !is Activity) dialIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if (account != null) dialIntent.putExtra(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, account)
    runCatching { ctx.startActivity(dialIntent) }
}

/** Starts a call, showing the custom SIM sheet when more than one account is available. */
fun callWithAccountChoice(ctx: Context, number: String) {
    val normalized = normalizePhoneNumber(number)
    if (normalized.isBlank()) return
    val tm = ctx.getSystemService(TelecomManager::class.java)
    val accounts = runCatching { tm.callCapablePhoneAccounts }.getOrDefault(emptyList())
    if (accounts.size > 1) {
        val picker = Intent(ctx, SimPickerActivity::class.java)
            .putExtra(SimPickerActivity.EXTRA_NUMBER, normalized)
            .putParcelableArrayListExtra(SimPickerActivity.EXTRA_ACCOUNTS, ArrayList(accounts))
        if (ctx !is Activity) picker.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { ctx.startActivity(picker) }
            .onFailure { placePhoneCall(ctx, normalized, null) }
    } else placePhoneCall(ctx, normalized, accounts.firstOrNull())
}

class SimPickerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(android.graphics.Color.TRANSPARENT))
        val number = intent.getStringExtra(EXTRA_NUMBER).orEmpty()
        val accounts = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableArrayListExtra(EXTRA_ACCOUNTS, PhoneAccountHandle::class.java).orEmpty()
        } else {
            @Suppress("DEPRECATION")
            (intent.getParcelableArrayListExtra<PhoneAccountHandle>(EXTRA_ACCOUNTS) ?: arrayListOf())
        }
        if (number.isBlank() || accounts.isEmpty()) { finish(); return }
        setContent {
            AbtinTheme {
                SimPickerOverlay(accounts) { account ->
                    placePhoneCall(this, number, account)
                    finish()
                }
            }
        }
    }

    companion object {
        const val EXTRA_NUMBER = "sim_picker_number"
        const val EXTRA_ACCOUNTS = "sim_picker_accounts"
    }
}

@Composable
private fun SimPickerOverlay(accounts: List<PhoneAccountHandle>, onChoose: (PhoneAccountHandle) -> Unit) {
    val context = LocalContext.current
    val telecom = remember { context.getSystemService(TelecomManager::class.java) }
    val palette = LocalPal.current
    val defaultAccount = remember(accounts) {
        runCatching { telecom.getDefaultOutgoingPhoneAccount(PhoneAccount.SCHEME_TEL) }.getOrNull()
    }
    val initiallySelected = accounts.indexOfFirst { it == defaultAccount }.let { if (it >= 0) it else 0 }
    BackHandler { (context as? Activity)?.finish() }

    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .72f)), contentAlignment = Alignment.Center) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Column(
                Modifier.fillMaxWidth(.90f)
                    .clip(RoundedCornerShape(34.dp))
                    .background(Color(0xFF101A2A))
                    .border(1.dp, palette.primary.copy(alpha = .48f), RoundedCornerShape(34.dp))
                    .padding(horizontal = 22.dp, vertical = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(Modifier.width(70.dp).height(5.dp).clip(CircleShape).background(Color(0xFF586579)))
                Spacer(Modifier.height(24.dp))
                Text(tr("انتخاب سیم‌کارت برای تماس", "Choose a SIM for this call"), color = palette.text,
                    fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(8.dp))
                Text(tr("سیم‌کارت مورد استفاده برای این تماس را انتخاب کنید", "Choose which SIM to use for this call"),
                    color = palette.sub, fontSize = 14.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(24.dp))

                accounts.forEachIndexed { index, account ->
                    val phoneAccount = remember(account) { runCatching { telecom.getPhoneAccount(account) }.getOrNull() }
                    val operator = phoneAccount?.label?.toString()?.trim().orEmpty()
                    val detail = phoneAccount?.shortDescription?.toString()?.trim().orEmpty()
                    val carrier = when {
                        operator.isNotBlank() -> operator
                        detail.isNotBlank() -> detail
                        else -> tr("سیم‌کارت ${index + 1}", "SIM ${index + 1}")
                    }
                    val info = listOf(operator, detail).filter { it.isNotBlank() }.distinct().joinToString(" · ")
                        .ifBlank { tr("برای این تماس", "For this call") }
                    val highlighted = index == initiallySelected
                    val irancell = "$operator $detail".contains("ایرانسل", true) || "$operator $detail".contains("irancell", true)
                    val badge = if (irancell) Color(0xFFB78200) else Color(0xFF08795F)

                    Row(
                        Modifier.fillMaxWidth()
                            .clip(RoundedCornerShape(22.dp))
                            .background(if (highlighted) Color(0xFF111F31) else Color(0xFF0C1523))
                            .border(1.dp, if (highlighted) palette.primary else palette.line, RoundedCornerShape(22.dp))
                            .clickable { onChoose(account) }
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            Modifier.size(width = 80.dp, height = 66.dp).clip(RoundedCornerShape(15.dp)).background(badge),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(Icons.Default.SimCard, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                            Text(carrier.take(13), color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                            Text("${tr("سیم‌کارت", "SIM card")} ${index + 1}", color = palette.text,
                                fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                            Spacer(Modifier.height(5.dp))
                            Text(info, color = palette.sub, fontSize = 12.sp, textAlign = TextAlign.End,
                                maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Spacer(Modifier.width(12.dp))
                        Box(Modifier.size(22.dp).clip(CircleShape).border(2.dp,
                            if (highlighted) palette.primary else palette.sub.copy(alpha = .8f), CircleShape),
                            contentAlignment = Alignment.Center) {
                            if (highlighted) Box(Modifier.size(12.dp).clip(CircleShape).background(palette.primary))
                        }
                    }
                    if (index != accounts.lastIndex) Spacer(Modifier.height(14.dp))
                }

                Spacer(Modifier.height(22.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                    TextButton(onClick = { (context as? Activity)?.finish() }) {
                        Text(tr("لغو", "Cancel"), color = Color(0xFF62D3C4), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(Modifier.height(6.dp))
                Text(tr("این انتخاب فقط برای همین تماس است", "This choice applies to this call only"),
                    color = palette.sub, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

fun dial(ctx: Context, number: String) = callWithAccountChoice(ctx, number)

fun fmtDur(s: Long): String = String.format(Locale.US, "%d:%02d", s / 60, s % 60)

// =====================================================================
// Call hub (shared state between InCallService and the UI) + recording
// =====================================================================
class EndedInfo(val name: String, val number: String, val seconds: Long)

object CallHub {
    val calls = mutableStateListOf<TCall>()
    val tick = mutableIntStateOf(0)
    val audio = mutableStateOf<CallAudioState?>(null)
    val recording = mutableStateOf(false)
    val recViaMic = mutableStateOf(false)
    var service: InCallService? = null
    lateinit var ctx: Context
    private var recorder: MediaRecorder? = null
    private var recFile: File? = null
    private var restoreAudioRoute: Int? = null

    const val CH_RING = "abtin_calls_ring"
    const val CH_ONGOING = "abtin_calls_ongoing_v2"
    const val NOTIF_ID = 4711
    const val MISSED_NOTIF_ID = 4712
    const val NOTIF_ONGOING_ID = 4713
    const val NOTIF_PREVIEW_ID = 4714
    const val ACT_PREVIEW_CLOSE = "ir.abtin.sms.CALL_PREVIEW_CLOSE"
    val ended = mutableStateOf<EndedInfo?>(null)
    const val ACT_DISMISSED = "ir.abtin.sms.CALL_NOTIF_DISMISSED"
    const val ACT_HANGUP = "ir.abtin.sms.CALL_HANGUP"
    const val ACT_ANSWER = "ir.abtin.sms.CALL_ANSWER"
    const val ACT_DECLINE = "ir.abtin.sms.CALL_DECLINE"

    @Suppress("DEPRECATION")
    fun stateOf(c: TCall): Int = c.state

    fun current(): TCall? = calls.firstOrNull { stateOf(it) == TCall.STATE_RINGING }
        ?: calls.firstOrNull { stateOf(it) != TCall.STATE_DISCONNECTED } ?: calls.firstOrNull()

    fun numberOf(c: TCall): String = c.details?.handle?.schemeSpecificPart ?: ""

    val cb = object : TCall.Callback() {
        override fun onStateChanged(call: TCall, state: Int) {
            tick.intValue++
            Prefs.withProfile(true) {
                if (state == TCall.STATE_ACTIVE && Prefs.autoRecordCalls.value && !recording.value) startRec(call)
            }
            if (state == TCall.STATE_DISCONNECTED) stopRec()
            notifyCall(call)
        }
        override fun onDetailsChanged(call: TCall, details: TCall.Details) { tick.intValue++ }
    }

    // ---- notifications ----
    private fun ringChannelId(): String {
        val sound = Prefs.callNotifSound.value
        return "${CH_RING}_v3_${if (Prefs.callSoundEnabled.value) "sound" else "silent"}_${if (Prefs.callVibrate.value) "vib" else "novib"}_${sound.hashCode().toUInt().toString(16)}"
    }

    private fun channels(c: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = c.getSystemService(NotificationManager::class.java)
        val ringId = ringChannelId()
        if (nm.getNotificationChannel(ringId) == null) {
            val soundEnabled = Prefs.callSoundEnabled.value
            // Fall back to the system ringtone (not the short notification beep) like a real dialer.
            val soundUri = Prefs.callNotifSound.value.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
                ?: android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_RINGTONE)
            val channel = NotificationChannel(ringId, tr("تماس ورودی", "Incoming calls"), NotificationManager.IMPORTANCE_HIGH).apply {
                if (!soundEnabled) setSound(null, null)
                else setSound(soundUri, android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                enableVibration(Prefs.callVibrate.value)
                if (Prefs.callVibrate.value) vibrationPattern = longArrayOf(0, 500, 250, 500)
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                setShowBadge(false)
            }
            nm.createNotificationChannel(channel)
        }
        if (nm.getNotificationChannel(CH_ONGOING) == null) {
            nm.createNotificationChannel(NotificationChannel(CH_ONGOING, tr("تماس جاری", "Ongoing call"), NotificationManager.IMPORTANCE_LOW).apply {
                lockscreenVisibility = android.app.Notification.VISIBILITY_PUBLIC
                setShowBadge(false)
            })
        }
    }

    private fun immutableFlags() = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

    /** Activity PendingIntent that opens (or re-targets) the in-call screen, optionally with an action. */
    private fun callActivityPi(c: Context, requestCode: Int, action: String? = null): PendingIntent {
        val i = Intent(c, InCallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NO_USER_ACTION)
        if (action != null) i.setAction(action)
        return PendingIntent.getActivity(c, requestCode, i, immutableFlags())
    }

    private fun receiverPi(c: Context, requestCode: Int, action: String): PendingIntent =
        PendingIntent.getBroadcast(c, requestCode, Intent(c, CallActionReceiver::class.java).setAction(action), immutableFlags())

    /** Compact single-row card (fits the 64dp collapsed/heads-up limit, so nothing is clipped). */
    private fun cardViews(
        c: Context, look: CallLook, title: String, subtitle: String, missed: Boolean,
        openPi: PendingIntent, answerPi: PendingIntent?, declinePi: PendingIntent?, answerLabel: String? = null
    ): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.notification_call_card)
        v.setImageViewBitmap(R.id.call_bg, CallNotifArt.card(look.notifBg.toArgb()))
        v.setImageViewBitmap(R.id.call_badge, CallNotifArt.badge(c, look, missed))
        v.setTextViewText(R.id.call_title, title)
        v.setTextViewText(R.id.call_sub, subtitle)
        v.setTextColor(R.id.call_title, look.notifText.toArgb())
        v.setTextColor(R.id.call_sub, look.notifText.copy(alpha = .72f).toArgb())
        if (declinePi != null) {
            v.setViewVisibility(R.id.call_decline, android.view.View.VISIBLE)
            v.setImageViewBitmap(R.id.call_decline, CallNotifArt.button(c, look, false))
            v.setOnClickPendingIntent(R.id.call_decline, declinePi)
        } else v.setViewVisibility(R.id.call_decline, android.view.View.GONE)
        if (answerPi != null) {
            v.setViewVisibility(R.id.call_answer, android.view.View.VISIBLE)
            v.setImageViewBitmap(R.id.call_answer, CallNotifArt.button(c, look, true, answerLabel))
            v.setOnClickPendingIntent(R.id.call_answer, answerPi)
        } else v.setViewVisibility(R.id.call_answer, android.view.View.GONE)
        v.setOnClickPendingIntent(R.id.call_card, openPi)
        return v
    }

    /** auto = system CallStyle while the phone is locked, themed card otherwise. */
    private fun useSystemStyle(c: Context, preview: Boolean): Boolean = when (Prefs.callNotifStyle.value) {
        "system" -> true
        "card" -> false
        else -> !preview && c.getSystemService(android.app.KeyguardManager::class.java)?.isKeyguardLocked == true
    }

    private fun incomingNotification(c: Context, look: CallLook, title: String, preview: Boolean): android.app.Notification {
        val accent = Prefs.callAccentColor.value.takeIf { it != 0 } ?: look.t.accent.toArgb()
        val openPi = callActivityPi(c, 77)
        val declinePi = receiverPi(c, 78, if (preview) ACT_PREVIEW_CLOSE else ACT_DECLINE)
        // Answer goes through the activity (not a broadcast): Android 12+ blocks notification
        // trampolines, and it also puts the call screen over the lock screen.
        val answerPi = if (preview) receiverPi(c, 79, ACT_PREVIEW_CLOSE) else callActivityPi(c, 79, ACT_ANSWER)
        val system = useSystemStyle(c, preview)
        val b = NotificationCompat.Builder(c, ringChannelId())
            .setSmallIcon(android.R.drawable.sym_action_call)
            .setColor(accent)
            .setContentTitle(title)
            .setContentText(look.subtitle)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(openPi)
        if (system) {
            // Real system call notification: always shown on the lock screen, like Google Phone.
            val person = Person.Builder().setName(title).setImportant(true).build()
            b.setStyle(NotificationCompat.CallStyle.forIncomingCall(person, declinePi, answerPi)).addPerson(person)
        } else {
            val views = cardViews(c, look, title, look.subtitle, false, openPi, answerPi, declinePi)
            b.setStyle(NotificationCompat.DecoratedCustomViewStyle())
                .setCustomContentView(views)
                .setCustomBigContentView(views)
                .setCustomHeadsUpContentView(views)
        }
        fun build(): android.app.Notification = runCatching { b.build() }.getOrElse {
            b.setStyle(null).addAction(0, look.declineText, declinePi).addAction(0, look.answerText, answerPi).build()
        }
        if (Build.VERSION.SDK_INT < 26) {
            if (Prefs.callSoundEnabled.value) {
                b.setSound(Prefs.callNotifSound.value.takeIf { it.isNotBlank() }?.let { Uri.parse(it) }
                    ?: android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_RINGTONE))
            } else b.setSound(null)
            if (Prefs.callVibrate.value) b.setVibrate(longArrayOf(0, 500, 250, 500)) else b.setVibrate(longArrayOf(0))
        }
        if (preview) {
            b.setOngoing(false).setAutoCancel(true).setTimeoutAfter(20_000)
            return build()
        }
        b.setOngoing(true).setAutoCancel(false).setOnlyAlertOnce(false)
            .setFullScreenIntent(callActivityPi(c, 80), true)
            .setDeleteIntent(receiverPi(c, 81, ACT_DISMISSED))
        val n = build()
        // Keep ringing until answered / declined / missed, like a real phone app.
        n.flags = n.flags or android.app.Notification.FLAG_INSISTENT or android.app.Notification.FLAG_NO_CLEAR
        return n
    }

    fun notifyCall(call: TCall) {
        val c = ctx
        Prefs.init(c)
        Prefs.withProfile(true) {
            if (!Prefs.callNotifications.value) { cancelNotif(); return@withProfile }
            runCatching {
                channels(c)
                val nm = c.getSystemService(NotificationManager::class.java)
                val state = stateOf(call)
                val num = numberOf(call)
                val title = SmsRepo(c).name(num) ?: num.ifEmpty { tr("ناشناس", "Unknown") }
                val look = CallLooks.resolve()
                if (state == TCall.STATE_RINGING) {
                    nm.cancel(NOTIF_ONGOING_ID)
                    nm.notify(NOTIF_ID, incomingNotification(c, look, title, false))
                } else {
                    nm.cancel(NOTIF_ID)
                    val connect = call.details?.connectTimeMillis ?: 0L
                    val b = NotificationCompat.Builder(c, CH_ONGOING)
                        .setSmallIcon(android.R.drawable.sym_action_call)
                        .setColor(Prefs.callAccentColor.value.takeIf { it != 0 } ?: look.t.accent.toArgb())
                        .setContentTitle(title)
                        .setContentText(if (state == TCall.STATE_HOLDING) tr("در انتظار", "On hold") else tr("تماس جاری", "Ongoing call"))
                        .setCategory(NotificationCompat.CATEGORY_CALL)
                        .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                        .setOngoing(true)
                        .setAutoCancel(false)
                        .setOnlyAlertOnce(true)
                        .setContentIntent(callActivityPi(c, 77))
                        .addAction(0, look.declineText.takeIf { Prefs.callDeclineText.value.isNotBlank() } ?: tr("پایان تماس", "Hang up"), receiverPi(c, 82, ACT_HANGUP))
                    if (state == TCall.STATE_ACTIVE && connect > 0) b.setUsesChronometer(true).setWhen(connect).setShowWhen(true)
                    nm.notify(NOTIF_ONGOING_ID, b.build())
                }
            }
        }
    }

    /** Posts a sample incoming-call card (no real call) so the user can test their theme. */
    fun showPreview(context: Context) {
        val app = context.applicationContext
        if (!::ctx.isInitialized) ctx = app
        Prefs.init(app)
        Prefs.withProfile(true) {
            runCatching {
                channels(app)
                val look = CallLooks.resolve()
                app.getSystemService(NotificationManager::class.java)
                    .notify(NOTIF_PREVIEW_ID, incomingNotification(app, look, tr("سارا احمدی", "Sara Ahmadi"), true))
            }
        }
    }

    fun cancelNotif() {
        runCatching {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.cancel(NOTIF_ID); nm.cancel(NOTIF_ONGOING_ID)
        }
    }

    fun notifyMissed(number: String) {
        val c = ctx
        Prefs.init(c)
        Prefs.withProfile(true) {
            if (!Prefs.callNotifications.value) return@withProfile
            runCatching {
                channels(c)
                val title = SmsRepo(c).name(number) ?: number.ifBlank { tr("شماره ناشناس", "Unknown number") }
                val look = CallLooks.resolve()
                val open = PendingIntent.getActivity(c, 4720,
                    Intent(c, MissedCallActivity::class.java).putExtra(MissedCallActivity.EXTRA_NUMBER, number)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                val back = PendingIntent.getActivity(c, 4721,
                    Intent(c, MissedCallActivity::class.java).putExtra(MissedCallActivity.EXTRA_NUMBER, number)
                        .putExtra(MissedCallActivity.EXTRA_DIAL, true),
                    PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                val nb = NotificationCompat.Builder(c, CH_ONGOING)
                    .setSmallIcon(android.R.drawable.sym_call_missed)
                    .setColor(look.decline.toArgb())
                    .setContentTitle(tr("تماس ازدست‌رفته", "Missed call"))
                    .setContentText(title)
                    .setCategory(NotificationCompat.CATEGORY_MISSED_CALL)
                    .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                    // The notification remains until the user opens the missed-call details.
                    .setAutoCancel(true)
                    .setOngoing(false)
                    .setContentIntent(open)
                if (useSystemStyle(c, false)) {
                    nb.addAction(0, tr("تماس مجدد", "Call back"), back)
                } else {
                    val views = cardViews(c, look, title, tr("تماس ازدست‌رفته", "Missed call"), true, open, back, null,
                        answerLabel = tr("تماس مجدد", "Call back"))
                    nb.setStyle(NotificationCompat.DecoratedCustomViewStyle())
                        .setCustomContentView(views)
                        .setCustomBigContentView(views)
                        .setCustomHeadsUpContentView(views)
                }
                val n = nb.build()
                c.getSystemService(NotificationManager::class.java).notify(MISSED_NOTIF_ID, n)
            }
        }
    }

    // ---- direct call-audio recording ----
    // Never substitute the handset microphone: the requested feature is the
    // actual call stream. Android normally reserves VOICE_CALL capture for
    // privileged/system apps; on devices that deny it we fail explicitly.
    @Suppress("DEPRECATION")
    private fun newRec(c: Context): MediaRecorder =
        if (Build.VERSION.SDK_INT >= 31) MediaRecorder(c) else MediaRecorder()

    private fun tryCallAudioRec(file: File): MediaRecorder? {
        val r = runCatching { newRec(ctx) }.getOrNull() ?: return null
        return try {
            r.setAudioSource(MediaRecorder.AudioSource.VOICE_CALL)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setAudioEncodingBitRate(128_000)
            r.setAudioSamplingRate(44_100)
            r.setOutputFile(file.absolutePath)
            r.prepare()
            r.start()
            r
        } catch (_: Exception) {
            runCatching { r.reset() }
            runCatching { r.release() }
            file.delete()
            null
        }
    }

    fun startRec(call: TCall?): Boolean {
        if (recording.value) return true
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
        if (service == null) return false

        val baseDir = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        val dir = File(baseDir, "calls")
        if ((!dir.exists() && !dir.mkdirs()) || !dir.isDirectory) return false
        val number = (call?.let { numberOf(it) } ?: "")
            .filter { it.isDigit() || it == '+' }
            .ifEmpty { "unknown" }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val file = File(dir, "${stamp}_${number}.m4a")
        if (file.exists() && !file.delete()) return false

        val started = tryCallAudioRec(file) ?: return false
        recorder = started
        recFile = file
        recViaMic.value = false
        recording.value = true
        return true
    }

    fun stopRec() {
        val activeRecorder = recorder
        recorder = null
        val stopped = activeRecorder?.let { runCatching { it.stop() }.isSuccess } ?: false
        activeRecorder?.let { runCatching { it.reset() }; runCatching { it.release() } }
        recording.value = false
        recViaMic.value = false
        recFile?.let { file ->
            if (!stopped || !file.isFile || file.length() < 2_048L) file.delete()
        }
        recFile = null
        Bus.tick.intValue++
    }

}

class CallActionReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val call = CallHub.current()
        when (i.action) {
            CallHub.ACT_ANSWER -> {
                if (call != null && CallHub.stateOf(call) == TCall.STATE_RINGING) {
                    runCatching { call.answer(0) }
                    runCatching { c.startActivity(Intent(c, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) }
                }
            }
            CallHub.ACT_DECLINE -> if (call != null && CallHub.stateOf(call) == TCall.STATE_RINGING) {
                runCatching { call.reject(false, null) }
                CallHub.cancelNotif()
            }
            CallHub.ACT_HANGUP -> if (call != null) runCatching { call.disconnect() }
            CallHub.ACT_PREVIEW_CLOSE -> runCatching { c.getSystemService(NotificationManager::class.java).cancel(CallHub.NOTIF_PREVIEW_ID) }
            // The user swiped the ringing notification away: bring it straight back while the call still rings.
            CallHub.ACT_DISMISSED -> if (call != null && CallHub.stateOf(call) == TCall.STATE_RINGING) CallHub.notifyCall(call)
        }
    }
}

class AbtinInCallService : InCallService() {
    override fun onCreate() { super.onCreate(); Prefs.init(this); CallHub.ctx = applicationContext; CallHub.service = this }
    override fun onDestroy() { CallHub.service = null; super.onDestroy() }

    override fun onCallAdded(call: TCall) {
        call.registerCallback(CallHub.cb)
        CallHub.ended.value = null
        CallHub.calls.add(call); CallHub.tick.intValue++
        CallHub.notifyCall(call)
        // Ringing calls reach the lock screen through the notification's full-screen intent.
        // If call notifications are turned off, fall back to opening the call screen directly.
        val ringing = CallHub.stateOf(call) == TCall.STATE_RINGING
        val notifOff = Prefs.withProfile(true) { !Prefs.callNotifications.value }
        if (!ringing || notifOff)
            runCatching { startActivity(Intent(this, InCallActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    }

    override fun onCallRemoved(call: TCall) {
        call.unregisterCallback(CallHub.cb)
        val missedIncoming = Build.VERSION.SDK_INT >= 29 &&
            call.details?.callDirection == TCall.Details.DIRECTION_INCOMING &&
            call.details?.disconnectCause?.code == android.telecom.DisconnectCause.MISSED
        val missedNumber = CallHub.numberOf(call)
        val connectedAt = call.details?.connectTimeMillis ?: 0L
        CallHub.ended.value = if (!missedIncoming && connectedAt > 0) {
            val secs = ((System.currentTimeMillis() - connectedAt) / 1000).coerceAtLeast(0)
            EndedInfo(runCatching { SmsRepo(this).name(missedNumber) }.getOrNull() ?: missedNumber.ifEmpty { tr("ناشناس", "Unknown") }, missedNumber, secs)
        } else null
        CallHub.calls.remove(call)
        if (missedIncoming) CallHub.notifyMissed(missedNumber)
        if (CallHub.calls.isEmpty()) { CallHub.stopRec(); CallHub.cancelNotif() }
        CallHub.tick.intValue++; Bus.tick.intValue++
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState?) { CallHub.audio.value = audioState }
}

// =====================================================================
// In-call screen
// =====================================================================
class InCallActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Prefs.init(this)
        Prefs.useProfile(true)
        showOverLock()
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT), navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent { AbtinTheme { InCallRoot(this) } }
        handleCallAction(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        showOverLock()
        handleCallAction(intent)
    }

    /** "Answer" tapped on the notification (works from the lock screen too). */
    private fun handleCallAction(i: Intent?) {
        if (i?.action != CallHub.ACT_ANSWER) return
        i.action = null
        CallHub.calls.firstOrNull { CallHub.stateOf(it) == TCall.STATE_RINGING }?.let { runCatching { it.answer(0) } }
    }

    @Suppress("DEPRECATION")
    private fun showOverLock() {
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true) }
        else window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON)
    }
}

@Composable
private fun CallToggle(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, on: Boolean, look: CallLook, tint: Color? = null, onClick: () -> Unit) {
    val accent = look.t.accent
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(84.dp)) {
        Box(Modifier.size(64.dp).clip(CircleShape)
            .background(if (on) accent.copy(alpha = .30f) else Color.White.copy(alpha = .10f))
            .border(1.dp, if (on) accent else Color.White.copy(alpha = .14f), CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint ?: if (on) accent else look.t.text, modifier = Modifier.size(28.dp))
        }
        Text(label, color = look.t.sub, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun InCallRoot(act: ComponentActivity) {
    val look = CallLooks.resolve()
    CallBackground(look) { InCallUI(act) }
}

@Composable
private fun CallEndedBody(e: EndedInfo, look: CallLook, act: ComponentActivity) {
    LaunchedEffect(Unit) { delay(1800); act.finish() }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.size(96.dp).clip(CircleShape).border(2.dp, look.t.text.copy(alpha = .75f), CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Check, null, tint = look.t.text, modifier = Modifier.size(48.dp))
            }
            Text(tr("تماس پایان یافت", "Call ended"), color = look.t.text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 22.dp))
            Text(listNum(fmtDur(e.seconds)), color = look.t.sub, fontSize = 18.sp, modifier = Modifier.padding(top = 8.dp))
            Text(e.name, color = look.t.sub, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
fun InCallUI(act: ComponentActivity) {
    val look = CallLooks.resolve()
    val tick = CallHub.tick.intValue
    val n = CallHub.calls.size
    val call = remember(tick, n) { CallHub.current() }
    if (call == null) {
        val ended = CallHub.ended.value
        if (ended != null) CallEndedBody(ended, look, act) else LaunchedEffect(Unit) { delay(300); act.finish() }
        return
    }

    val repo = remember { SmsRepo(act) }
    val number = CallHub.numberOf(call)
    val name by produceState(number.ifEmpty { tr("ناشناس", "Unknown") }, number) { value = withContext(Dispatchers.IO) { runCatching { repo.name(number) }.getOrNull() } ?: number.ifEmpty { tr("ناشناس", "Unknown") } }
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    val st = CallHub.stateOf(call)
    var isResumed by remember { mutableStateOf(act.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) }
    DisposableEffect(act) {
        val lifecycleObserver = LifecycleEventObserver { _, _ ->
            isResumed = act.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
        }
        act.lifecycle.addObserver(lifecycleObserver)
        onDispose { act.lifecycle.removeObserver(lifecycleObserver) }
    }
    LaunchedEffect(call, st, isResumed) {
        if (st == TCall.STATE_ACTIVE && isResumed) {
            while (true) { now = System.currentTimeMillis(); delay(1000) }
        }
    }
    val connect = call.details?.connectTimeMillis ?: 0L
    val label = when (st) {
        TCall.STATE_RINGING -> look.subtitle
        TCall.STATE_DIALING, TCall.STATE_CONNECTING -> tr("در حال برقراری تماس…", "Calling…")
        TCall.STATE_HOLDING -> tr("در انتظار", "On hold")
        TCall.STATE_ACTIVE -> if (connect > 0) listNum(fmtDur(((now - connect) / 1000).coerceAtLeast(0))) else tr("برقرار شد", "Connected")
        else -> tr("پایان تماس", "Call ended")
    }
    val au = CallHub.audio.value
    val muted = au?.isMuted == true
    val speaker = au?.route == CallAudioState.ROUTE_SPEAKER
    val rec = CallHub.recording.value
    var showDtmf by remember(call) { mutableStateOf(false) }
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) CallHub.startRec(call) }
    fun toggleRec() {
        if (rec) CallHub.stopRec()
        else if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) micPerm.launch(Manifest.permission.RECORD_AUDIO)
        else if (!CallHub.startRec(call)) Toast.makeText(act, tr("اندروید اجازه ضبط مستقیم صدای تماس را به این برنامه نمی‌دهد؛ ضبط میکروفونی انجام نمی‌شود", "Android does not allow this app to capture the direct call audio. Microphone fallback is disabled."), Toast.LENGTH_LONG).show()
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(if (st == TCall.STATE_RINGING) 28.dp else 8.dp))
            CallAvatar(repo, number, name, look, if (showDtmf) 84.dp else 120.dp, pulse = st == TCall.STATE_RINGING)
            Text(name, color = look.t.text, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content))
            if (name != number && number.isNotEmpty()) Text(number, color = look.t.sub, fontSize = 16.sp, style = TextStyle(textDirection = TextDirection.Ltr), modifier = Modifier.padding(top = 4.dp))
            Text(label, color = if (st == TCall.STATE_ACTIVE) look.t.text else look.t.sub, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp))
            if (rec) Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.FiberManualRecord, null, tint = RED, modifier = Modifier.size(14.dp))
                Text(" " + tr("در حال ضبط تماس", "Recording call"), color = RED, fontSize = 14.sp)
            }
            Spacer(Modifier.weight(1f))

            if (st == TCall.STATE_RINGING) {
                RingControls(look, onDecline = { call.reject(false, null) }, onAnswer = { call.answer(0) })
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        CallToggle(if (muted) Icons.Default.MicOff else Icons.Default.Mic, tr("بی‌صدا", "Mute"), muted, look) { CallHub.service?.setMuted(!muted) }
                        CallToggle(Icons.Default.VolumeUp, tr("بلندگو", "Speaker"), speaker, look) { CallHub.service?.setAudioRoute(if (speaker) CallAudioState.ROUTE_EARPIECE else CallAudioState.ROUTE_SPEAKER) }
                        CallToggle(Icons.Default.Dialpad, tr("صفحه‌کلید", "Keypad"), showDtmf, look) { showDtmf = !showDtmf }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        CallToggle(
                            if (st == TCall.STATE_HOLDING) Icons.Default.PlayArrow else Icons.Default.Pause,
                            if (st == TCall.STATE_HOLDING) tr("ادامه تماس", "Resume") else tr("انتظار", "Hold"),
                            st == TCall.STATE_HOLDING, look
                        ) {
                            when (st) {
                                TCall.STATE_HOLDING -> runCatching { call.unhold() }
                                TCall.STATE_ACTIVE -> runCatching { call.hold() }
                            }
                        }
                        CallToggle(Icons.Default.FiberManualRecord, tr("ضبط", "Record"), rec, look, if (rec) RED else null) { toggleRec() }
                        CallToggle(Icons.Default.Person, tr("مخاطب", "Contact"), false, look) {
                            runCatching { act.startActivity(Intent(act, MainActivity::class.java).putExtra("address", number).putExtra("thread", 0L)) }
                        }
                    }
                }
                if (showDtmf) InCallDtmfPad(call)
                Spacer(Modifier.height(24.dp))
                CallActionButton(false, look, { call.disconnect() }, noLabel = true, sizeOverride = 74.dp * look.scale)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}


@Composable
fun SwipeCallControl(look: CallLook, onDecline: () -> Unit, onAnswer: () -> Unit) {
    val density = LocalDensity.current
    var drag by remember { mutableFloatStateOf(0f) }
    val shown = look.labels
    Column(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        BoxWithConstraints(Modifier.fillMaxWidth().height(94.dp)) {
            val maxDrag = with(density) { (maxWidth - 92.dp).toPx() }
            Box(Modifier.fillMaxWidth().height(66.dp).align(Alignment.Center)
                .clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(look.decline.copy(alpha = .22f), Color.Black.copy(alpha = .25f), look.answer.copy(alpha = .22f))))
                .border(1.dp, Color.White.copy(alpha = .16f), RoundedCornerShape(50)))
            Row(Modifier.fillMaxWidth().height(66.dp).align(Alignment.Center).padding(horizontal = 22.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CallEnd, null, tint = look.decline, modifier = Modifier.size(22.dp))
                    if (shown) Text(look.declineText, color = look.decline, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Call, null, tint = look.answer, modifier = Modifier.size(22.dp))
                    if (shown) Text(look.answerText, color = look.answer, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Box(Modifier.align(Alignment.Center).offset { IntOffset(drag.roundToInt(), 0) }
                .size(82.dp).shadow(10.dp, CircleShape).clip(CircleShape)
                .background(look.t.accent)
                .pointerInput(maxDrag) {
                    detectHorizontalDragGestures(onHorizontalDrag = { change, amount ->
                        change.consume()
                        drag = (drag + amount).coerceIn(-maxDrag / 2f, maxDrag / 2f)
                    }, onDragEnd = {
                        when {
                            drag > maxDrag * .24f -> onAnswer()
                            drag < -maxDrag * .24f -> onDecline()
                        }
                        drag = 0f
                    })
                }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Call, null, tint = Color.White, modifier = Modifier.size(34.dp))
            }
        }
        Text(tr("برای پاسخ به راست و برای رد به چپ بکشید", "Swipe right to answer, left to decline"),
            color = look.t.sub, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
    }
}

@Composable
private fun InCallDtmfPad(call: TCall) {
    val p = LocalPal.current
    val keys = listOf("1","2","3","4","5","6","7","8","9","*","0","#")
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(p.nav).padding(8.dp)) {
        keys.chunked(3).forEach { row -> Row(Modifier.fillMaxWidth()) { row.forEach { key ->
            Box(Modifier.weight(1f).padding(3.dp).height(43.dp).clip(RoundedCornerShape(14.dp)).background(p.surface)
                .pointerInput(key) { detectTapGestures(onPress = { call.playDtmfTone(key.first()); tryAwaitRelease(); call.stopDtmfTone() }) }, contentAlignment=Alignment.Center) {
                Text(key, color=p.text, fontSize=20.sp, fontWeight=FontWeight.SemiBold)
            }
        } } }
    }
}

class MissedCallActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        Prefs.useProfile(true)
        // Dismiss the missed-call alert only after its dedicated details screen opens.
        runCatching { getSystemService(NotificationManager::class.java).cancel(CallHub.MISSED_NOTIF_ID) }
        val number = intent.getStringExtra(EXTRA_NUMBER).orEmpty()
        // The notification's "Call back" button goes straight to dialing.
        if (intent.getBooleanExtra(EXTRA_DIAL, false) && number.isNotBlank()) { dial(this, number); finish(); return }
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT), navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        setContent { AbtinTheme {
            val look = CallLooks.resolve()
            CallBackground(look) {
                val shown = number.ifBlank { tr("شماره ناشناس", "Unknown number") }
                Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(28.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Icon(Icons.Default.CallMissed, null, tint = look.decline, modifier = Modifier.size(84.dp))
                    Text(tr("تماس ازدست‌رفته", "Missed call"), color = look.t.text, fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
                    Text(shown, color = look.t.sub, fontSize = 19.sp, modifier = Modifier.padding(top = 8.dp))
                    Spacer(Modifier.height(32.dp))
                    Row(Modifier.clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = .35f)).border(1.dp, Color.White.copy(alpha = .2f), RoundedCornerShape(50))
                        .clickable { if (number.isNotBlank()) dial(this@MissedCallActivity, number) }.padding(horizontal = 28.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Call, null, tint = look.answer)
                        Spacer(Modifier.width(10.dp))
                        Text(tr("تماس مجدد", "Call back"), color = look.t.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    }
                    TextButton(onClick = { finish() }) { Text(tr("بستن", "Close"), color = look.t.sub) }
                }
            }
        } }
    }
    companion object { const val EXTRA_NUMBER = "missed_call_number"; const val EXTRA_DIAL = "missed_call_dial" }
}

// =====================================================================
// Calls tab: recents + recordings + dial pad
// =====================================================================
class CallRow(val id: Long, val number: String, val name: String, val type: Int, val date: Long, val dur: Long)
class RecItem(val file: File, val name: String, val number: String)

private fun callGroupKey(row: CallRow): String {
    val digits = normalizePhoneNumber(row.number).filter(Char::isDigit)
    // Strip varying country/trunk prefixes for the common local-vs-international
    // representations of the same subscriber number.
    return when {
        digits.length >= 10 -> digits.takeLast(10)
        digits.isNotEmpty() -> digits
        else -> "unknown:${row.id}"
    }
}

fun SmsRepo.deleteCallLogs(ids: List<Long>): Int {
    if (ctx.checkSelfPermission(Manifest.permission.WRITE_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return 0
    val unique = ids.distinct()
    if (unique.isEmpty()) return 0
    val selection = "${CallLog.Calls._ID} IN (${unique.joinToString(",") { "?" }})"
    return runCatching { cr.delete(CallLog.Calls.CONTENT_URI, selection, unique.map { it.toString() }.toTypedArray()) }.getOrDefault(0)
}

fun SmsRepo.callLog(): List<CallRow> {
    if (ctx.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return emptyList()
    val l = ArrayList<CallRow>()
    cr.query(CallLog.Calls.CONTENT_URI,
        arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE, CallLog.Calls.DURATION, CallLog.Calls._ID),
        null, null, CallLog.Calls.DATE + " DESC")?.use { c ->
        var n = 0
        while (c.moveToNext() && n++ < 300) {
            val num = c.getString(0) ?: ""
            l += CallRow(c.getLong(4), num, if (num.isBlank()) tr("ناشناس", "Unknown") else (name(num) ?: num), c.getInt(1), c.getLong(2), c.getLong(3))
        }
    }
    return l
}

fun SmsRepo.recordings(): List<RecItem> {
    val dir = File(ctx.getExternalFilesDir(null), "calls")
    return (dir.listFiles() ?: emptyArray()).filter { it.isFile && it.length() > 0 }.sortedByDescending { it.lastModified() }.map {
        val number = it.name.removeSuffix(".m4a").split("_", limit = 3).getOrNull(2) ?: ""
        RecItem(it, if (number == "unknown" || number.isEmpty()) tr("ناشناس", "Unknown") else (name(number) ?: number), number)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CallsScreen(repo: SmsRepo, act: ComponentActivity, nav: MutableState<Screen>) {
    val p = LocalPal.current
    var tab by remember { mutableIntStateOf(0) }
    var pad by remember { mutableStateOf(false) }
    var num by remember { mutableStateOf("") }
    var log by remember { mutableStateOf<List<CallRow>>(emptyList()) }
    var recs by remember { mutableStateOf<List<RecItem>>(emptyList()) }
    var playing by remember { mutableStateOf<String?>(null) }
    var expandedHistory by remember { mutableStateOf(emptySet<String>()) }
    var selectedCallIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var confirmDeleteCalls by remember { mutableStateOf(false) }
    var refreshRequested by remember { mutableIntStateOf(0) }
    var roleRefresh by remember { mutableIntStateOf(0) }
    val scope = rememberCoroutineScope()
    val player = remember { arrayOfNulls<MediaPlayer>(1) }
    val tm = remember { act.getSystemService(TelecomManager::class.java) }
    val isDef = remember(roleRefresh) { runCatching { tm.defaultDialerPackage == act.packageName }.getOrDefault(false) }
    val roleL = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        roleRefresh++; refreshRequested++
    }
    fun askDialer() {
        val i = if (Build.VERSION.SDK_INT >= 29) act.getSystemService(RoleManager::class.java).let { rm -> if (rm.isRoleAvailable(RoleManager.ROLE_DIALER)) rm.createRequestRoleIntent(RoleManager.ROLE_DIALER) else null }
        else Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER).putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, act.packageName)
        i?.let { roleL.launch(it) }
    }
    // Incoming-call UI is delivered only to the system's selected default dialer.
    // Ask for that role as soon as the Phone screen is opened; the banner remains
    // available if the user dismisses the system dialog.
    var requestedDialerRole by remember { mutableStateOf(false) }
    LaunchedEffect(isDef) {
        if (!isDef && !requestedDialerRole) {
            requestedDialerRole = true
            askDialer()
        }
    }
    // Android 14+: full-screen incoming-call UI on the lock screen needs this special access.
    LaunchedEffect(isDef) {
        if (isDef && Build.VERSION.SDK_INT >= 34) {
            val nm = act.getSystemService(NotificationManager::class.java)
            if (!nm.canUseFullScreenIntent()) runCatching {
                act.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${act.packageName}")))
            }
        }
    }
    LaunchedEffect(Bus.dial.value) { if (Bus.dial.value.isNotEmpty()) { num = Bus.dial.value; pad = true; Bus.dial.value = "" } }
    DisposableEffect(act) {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) { refreshRequested++ }
        }
        var observing = false
        fun startObserving() {
            if (observing) return
            runCatching { act.contentResolver.registerContentObserver(CallLog.Calls.CONTENT_URI, true, observer) }
                .onSuccess { observing = true }
        }
        fun stopObserving() {
            if (!observing) return
            runCatching { act.contentResolver.unregisterContentObserver(observer) }
            observing = false
        }
        val lifecycleObserver = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> { startObserving(); refreshRequested++ }
                Lifecycle.Event.ON_PAUSE -> stopObserving()
                else -> Unit
            }
        }
        act.lifecycle.addObserver(lifecycleObserver)
        if (act.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) startObserving()
        onDispose {
            stopObserving()
            act.lifecycle.removeObserver(lifecycleObserver)
        }
    }
    LaunchedEffect(refreshRequested, tab) {
        val (l, r) = withContext(Dispatchers.IO) { Pair(runCatching { repo.callLog() }.getOrDefault(emptyList()), runCatching { repo.recordings() }.getOrDefault(emptyList())) }
        log = l; recs = r
        selectedCallIds = selectedCallIds.intersect(l.mapTo(HashSet()) { it.id })
    }
    DisposableEffect(Unit) { onDispose { runCatching { player[0]?.release() } } }
    fun toggle(f: File) {
        runCatching { player[0]?.stop() }; runCatching { player[0]?.release() }; player[0] = null
        if (playing == f.name) { playing = null; return }
        runCatching {
            val mp = MediaPlayer().apply { setDataSource(f.absolutePath); setOnCompletionListener { playing = null }; prepare(); start() }
            player[0] = mp; playing = f.name
        }.onFailure { playing = null }
    }
    val callGroups = remember(log) {
        log.groupBy(::callGroupKey).values
            .map { it.sortedByDescending(CallRow::date) }
            .sortedByDescending { it.first().date }
    }
    fun toggleCallGroup(ids: List<Long>) {
        val groupIds = ids.toSet()
        selectedCallIds = if (groupIds.all { it in selectedCallIds }) selectedCallIds - groupIds else selectedCallIds + groupIds
    }
    fun toggleCallRecord(id: Long) {
        selectedCallIds = if (id in selectedCallIds) selectedCallIds - id else selectedCallIds + id
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("تماس‌ها", "Calls"), color = p.text, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
        }
        if (!isDef) Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp).clip(RoundedCornerShape(18.dp)).background(Brush.horizontalGradient(listOf(p.primary, p.primary2)))
            .clickable { askDialer() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(tr("برای مدیریت تماس‌ها، آبتین را برنامه پیش‌فرض تماس کنید", "Set Abtin as your default phone app to manage calls"), color = p.onPrimary, modifier = Modifier.weight(1f), fontSize = 14.sp)
            Text(tr("تنظیم", "Set"), color = p.onPrimary, fontWeight = FontWeight.Bold)
        }
        Row(Modifier.padding(horizontal = 20.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChipX(tr("اخیر", "Recents"), null, tab == 0) { tab = 0; selectedCallIds = emptySet() }
            FilterChipX(tr("ضبط‌شده‌ها", "Recordings"), null, tab == 1) { tab = 1; selectedCallIds = emptySet() }
        }
        if (tab == 0 && selectedCallIds.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${listNum(selectedCallIds.size.toString())} ${tr("انتخاب‌شده", "selected")}", color = p.primary, modifier = Modifier.weight(1f), fontSize = 14.sp)
                TextButton(onClick = {
                    val allIds = log.map { it.id }.toSet()
                    selectedCallIds = if (allIds.isNotEmpty() && allIds.all { it in selectedCallIds }) selectedCallIds - allIds else selectedCallIds + allIds
                }) { Text(tr("همه", "All"), color = p.primary) }
                IconButton(onClick = { confirmDeleteCalls = true }) { Icon(Icons.Default.Delete, tr("حذف", "Delete"), tint = p.danger) }
                IconButton(onClick = { selectedCallIds = emptySet() }) { Icon(Icons.Default.Close, tr("لغو انتخاب", "Cancel selection"), tint = p.sub) }
            }
        } else if (tab == 0) {
            Text(tr("برای انتخاب چندتایی، روی تماس نگه دارید", "Long-press a call to select multiple"),
                color = p.sub, fontSize = 12.sp, modifier = Modifier.padding(start = 22.dp, end = 22.dp, bottom = 4.dp))
        }
        val shape = RoundedCornerShape(20.dp)
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
            if (tab == 0) {
                if (log.isEmpty()) item { Text(tr("تماسی ثبت نشده یا مجوز دسترسی به تاریخچه تماس داده نشده است", "No calls, or call log permission not granted"), color = p.sub, modifier = Modifier.padding(24.dp)) }
                items(callGroups.size) { i ->
                    val rows = callGroups[i]
                    val latest = rows.first()
                    val key = callGroupKey(latest)
                    val isExpanded = key in expandedHistory
                    val missed = latest.type == CallLog.Calls.MISSED_TYPE || latest.type == CallLog.Calls.REJECTED_TYPE
                    val groupAllSelected = rows.all { it.id in selectedCallIds }
                    val groupPartSelected = rows.any { it.id in selectedCallIds }
                    var dragX by remember(key) { mutableFloatStateOf(0f) }
                    val density = LocalDensity.current
                    val limitPx = with(density) { 148.dp.toPx() }
                    Box(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 3.5.dp)
                        .pointerInput(key, rows, selectedCallIds.isNotEmpty()) {
                            if (selectedCallIds.isEmpty()) detectHorizontalDragGestures(
                                    onHorizontalDrag = { change, amount ->
                                        change.consume()
                                        dragX = (dragX + amount).coerceIn(-limitPx, limitPx)
                                    },
                                    onDragEnd = {
                                        if (abs(dragX) > with(density) { 88.dp.toPx() }) {
                                            val ids = rows.map { it.id }
                                            dragX = 0f
                                            scope.launch(Dispatchers.IO) {
                                                val deleted = runCatching { repo.deleteCallLogs(ids) }.getOrDefault(0)
                                                withContext(Dispatchers.Main) {
                                                    if (deleted > 0) {
                                                        log = log.filterNot { it.id in ids }
                                                        expandedHistory = expandedHistory - key
                                                        refreshRequested++
                                                    } else Toast.makeText(act, tr("حذف سابقه تماس ممکن نشد", "Could not delete call history"), Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        } else dragX = 0f
                                    }
                                )
                        }) {
                        Box(Modifier.matchParentSize().clip(shape).background(p.danger.copy(alpha = .88f)),
                            contentAlignment = if (dragX < 0) Alignment.CenterEnd else Alignment.CenterStart) {
                            Row(Modifier.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Delete, null, tint = Color.White)
                                Text(" " + tr("حذف", "Delete"), color = Color.White, fontWeight = FontWeight.Bold)
                            }
                        }
                        Row(Modifier.fillMaxWidth().offset { IntOffset(dragX.roundToInt(), 0) }.clip(shape)
                            .background(if (groupPartSelected) p.primary.copy(alpha = .14f) else p.surface)
                            .border(1.dp, if (groupPartSelected) p.primary else p.line, shape)
                            .combinedClickable(
                                onClick = { if (selectedCallIds.isNotEmpty()) toggleCallGroup(rows.map { it.id }) else dial(act, latest.number) },
                                onLongClick = { toggleCallGroup(rows.map { it.id }) }
                            ).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(repo, latest.number, latest.name, 47.dp); Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(latest.name, color = if (missed) p.danger else p.text, fontWeight = FontWeight.Bold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                        Icon(when (latest.type) { CallLog.Calls.OUTGOING_TYPE -> Icons.Default.CallMade; CallLog.Calls.INCOMING_TYPE -> Icons.Default.CallReceived; else -> Icons.Default.CallMissed },
                                            null, tint = if (missed) p.danger else p.sub, modifier = Modifier.size(15.dp))
                                    }
                                    Text(" " + fmtList(latest.date) + (if (latest.dur > 0) " · " + listNum(fmtDur(latest.dur)) else ""), color = p.sub, fontSize = 13.sp)
                                }
                                Text(latest.number, color = p.sub, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Ltr))
                            }
                            if (selectedCallIds.isNotEmpty()) {
                                Icon(if (groupAllSelected) Icons.Default.CheckCircle else if (groupPartSelected) Icons.Default.IndeterminateCheckBox else Icons.Default.RadioButtonUnchecked,
                                    null, tint = if (groupPartSelected) p.primary else p.sub, modifier = Modifier.size(28.dp))
                            } else if (latest.number.isNotBlank()) {
                                CircleBtn(Icons.Default.ChatBubble, { openChat(act, latest.number) }, size = 38.dp)
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth().padding(start = 78.dp, end = 22.dp, top = 0.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { expandedHistory = if (isExpanded) expandedHistory - key else expandedHistory + key }) {
                            Icon(if (isExpanded) Icons.Default.ExpandLess else Icons.Default.History, null, tint = p.primary, modifier = Modifier.size(18.dp))
                            Text(" ${tr("سابقه", "History")} · ${listNum(rows.size.toString())}", color = p.primary, fontSize = 12.sp)
                        }
                    }
                    if (isExpanded) rows.drop(1).forEach { old ->
                        val oldSelected = old.id in selectedCallIds
                        Row(Modifier.fillMaxWidth().padding(start = 88.dp, end = 24.dp, bottom = 4.dp).clip(RoundedCornerShape(12.dp))
                            .background(if (oldSelected) p.primary.copy(alpha = .14f) else p.nav)
                            .combinedClickable(
                                onClick = { if (selectedCallIds.isNotEmpty()) toggleCallRecord(old.id) else dial(act, old.number) },
                                onLongClick = { toggleCallRecord(old.id) }
                            ).padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (oldSelected) Icons.Default.CheckCircle else when (old.type) { CallLog.Calls.OUTGOING_TYPE -> Icons.Default.CallMade; CallLog.Calls.INCOMING_TYPE -> Icons.Default.CallReceived; else -> Icons.Default.CallMissed }, null,
                                tint = if (oldSelected) p.primary else if (old.type == CallLog.Calls.MISSED_TYPE || old.type == CallLog.Calls.REJECTED_TYPE) p.danger else p.sub, modifier = Modifier.size(16.dp))
                            Text("  ${fmtList(old.date)}${if (old.dur > 0) " · ${listNum(fmtDur(old.dur))}" else ""}", color = p.sub, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        }
                    }
                }
            } else {
                if (recs.isEmpty()) item { Text(tr("هنوز تماسی ضبط نشده. در صفحه تماس دکمه ضبط را بزنید یا ضبط خودکار را در تنظیمات روشن کنید", "No recordings yet. Tap Record during a call or enable auto-record in Settings"), color = p.sub, modifier = Modifier.padding(24.dp)) }
                items(recs.size) { i ->
                    val r = recs[i]
                    Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 3.5.dp).clip(shape).background(p.surface).border(1.dp, p.line, shape).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(47.dp).clip(CircleShape).background(Brush.linearGradient(listOf(p.primary, p.primary2))).clickable { toggle(r.file) }, contentAlignment = Alignment.Center) {
                            Icon(if (playing == r.file.name) Icons.Default.Stop else Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(26.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.name, color = p.text, fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content))
                            Text(fmtList(r.file.lastModified()) + " · " + listNum(fmtSize(r.file.length())), color = p.sub, fontSize = 13.sp)
                        }
                        CircleBtn(Icons.Default.Share, {
                            runCatching {
                                val u = FileProvider.getUriForFile(act, act.packageName + ".files", r.file)
                                act.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("audio/mp4").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), null))
                            }
                        }, size = 40.dp); Spacer(Modifier.width(6.dp))
                        CircleBtn(Icons.Default.Delete, {
                            if (playing == r.file.name) { runCatching { player[0]?.release() }; player[0] = null; playing = null }
                            r.file.delete(); recs = recs.filterNot { it.file == r.file }
                        }, size = 40.dp, tint = p.danger)
                    }
                }
            }
        }
        if (!pad) Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 6.dp), horizontalArrangement = Arrangement.End) {
            CircleBtn(Icons.Default.Dialpad, { pad = true }, size = 52.dp, tint = p.primary)
        }
        if (pad) {
            val sh = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
            val keys = listOf("1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO", "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to "")
            Column(Modifier.fillMaxWidth().clip(sh).background(p.nav).border(1.dp, p.line, sh).padding(horizontal = 24.dp).padding(top = 14.dp, bottom = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(num.ifEmpty { tr("شماره را وارد کنید", "Enter number") }, color = if (num.isEmpty()) p.sub else p.text, fontSize = if (num.isEmpty()) 17.sp else 30.sp, fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Ltr), modifier = Modifier.weight(1f))
                    if (num.isNotEmpty()) Icon(Icons.Default.Backspace, null, tint = p.sub, modifier = Modifier.size(34.dp).clip(CircleShape)
                        .pointerInput(Unit) { detectTapGestures(onTap = { num = num.dropLast(1) }, onLongPress = { num = "" }) }.padding(5.dp))
                }
                keys.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { (k, sub) ->
                            Box(Modifier.weight(1f).height(60.dp).padding(4.dp).clip(RoundedCornerShape(20.dp)).background(p.surface)
                                .pointerInput(k) { detectTapGestures(onTap = { num += k }, onLongPress = { if (k == "0") num += "+" }) },
                                contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(k, color = p.text, fontSize = 24.sp, fontWeight = FontWeight.SemiBold)
                                    if (sub.isNotEmpty()) Text(sub, color = p.sub, fontSize = 9.sp)
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    CircleBtn(Icons.Default.PersonAdd, { nav.value = Screen.ContactForm(0, "", num) }, size = 52.dp)
                    Box(Modifier.size(68.dp).shadow(12.dp, CircleShape, ambientColor = GREEN, spotColor = GREEN).clip(CircleShape).background(GREEN)
                        .clickable { if (num.isNotBlank()) { dial(act, num); num = ""; pad = false } }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Call, null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                    CircleBtn(Icons.Default.KeyboardArrowDown, { pad = false }, size = 52.dp)
                }
            }
        }
    }
    if (confirmDeleteCalls) AlertDialog(
        onDismissRequest = { confirmDeleteCalls = false },
        containerColor = p.surface, titleContentColor = p.text, textContentColor = p.sub,
        title = { Text(tr("حذف سابقه تماس", "Delete call history")) },
        text = { Text(tr("${listNum(selectedCallIds.size.toString())} سابقه انتخاب‌شده حذف شود؟", "Delete ${selectedCallIds.size} selected call records?")) },
        confirmButton = {
            TextButton(onClick = {
                val ids = selectedCallIds.toList()
                confirmDeleteCalls = false
                scope.launch(Dispatchers.IO) {
                    val deleted = runCatching { repo.deleteCallLogs(ids) }.getOrDefault(0)
                    withContext(Dispatchers.Main) {
                        if (deleted > 0) {
                            log = log.filterNot { it.id in ids }
                            selectedCallIds = emptySet()
                            expandedHistory = emptySet()
                            refreshRequested++
                            Toast.makeText(act, tr("$deleted سابقه حذف شد", "$deleted records deleted"), Toast.LENGTH_SHORT).show()
                        } else Toast.makeText(act, tr("حذف سابقه تماس ممکن نشد", "Could not delete call history"), Toast.LENGTH_SHORT).show()
                    }
                }
            }) { Text(tr("حذف", "Delete"), color = p.danger) }
        },
        dismissButton = { TextButton(onClick = { confirmDeleteCalls = false }) { Text(tr("لغو", "Cancel"), color = p.text) } }
    )
}

// =====================================================================
// Contacts: create / edit / delete
// =====================================================================
fun SmsRepo.deleteContact(id: Long): Boolean = try {
    ctx.checkSelfPermission(Manifest.permission.WRITE_CONTACTS) == PackageManager.PERMISSION_GRANTED &&
        cr.delete(ContentUris.withAppendedId(ContactsContract.Contacts.CONTENT_URI, id), null, null) > 0
} catch (e: Exception) { false }

fun SmsRepo.deleteContacts(ids: List<Long>): Int {
    if (ctx.checkSelfPermission(Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED) return 0
    return ids.distinct().count { deleteContact(it) }
}

fun SmsRepo.contactFromUri(u: Uri): ContactItem? {
    var id = 0L; var nm = ""
    cr.query(u, arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) { id = it.getLong(0); nm = it.getString(1) ?: "" } }
    if (id == 0L) return null
    var num = ""
    cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER), ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?", arrayOf(id.toString()), null)
        ?.use { if (it.moveToFirst()) num = it.getString(0) ?: "" }
    return ContactItem(nm, num, id)
}

// =====================================================================
// Voice message recorder (used from the attach panel)
// =====================================================================
@Composable
fun VoiceRecorderDialog(act: ComponentActivity, onDone: (Attach) -> Unit, onClose: () -> Unit) {
    val p = LocalPal.current
    val file = remember { File(File(act.cacheDir, "mms").apply { mkdirs() }, "voice_${System.currentTimeMillis()}.amr") }
    var rec by remember { mutableStateOf<MediaRecorder?>(null) }
    var ms by remember { mutableLongStateOf(0L) }
    var bars by remember { mutableStateOf(List(28) { 0.06f }) }
    var failed by remember { mutableStateOf(false) }
    val recorderPermissionState = remember { mutableIntStateOf(if (act.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) 1 else 0) }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) recorderPermissionState.intValue = 1 else { recorderPermissionState.intValue = -1; failed = true }
    }

    fun release(): Boolean {
        val r = rec ?: return false
        rec = null
        val ok = runCatching { r.stop() }.isSuccess
        runCatching { r.release() }
        return ok
    }
    LaunchedEffect(recorderPermissionState.intValue) {
        if (recorderPermissionState.intValue == 0) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return@LaunchedEffect
        }
        if (recorderPermissionState.intValue < 0) return@LaunchedEffect
        val r = runCatching {
            (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(act) else voiceLegacy()).apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.AMR_NB)
                setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB)
                setOutputFile(file.absolutePath)
                prepare(); start()
            }
        }.getOrNull()
        if (r == null) { failed = true; return@LaunchedEffect }
        rec = r
        val t0 = System.currentTimeMillis()
        while (rec === r && ms < 120_000) {
            delay(500)
            ms = System.currentTimeMillis() - t0
            val a = runCatching { r.maxAmplitude }.getOrDefault(0)
            bars = (bars + (a / 16000f).coerceIn(0.06f, 1f)).takeLast(28)
        }
    }
    DisposableEffect(Unit) { onDispose { release(); file.delete() } }

    Dialog(onDismissRequest = { release(); file.delete(); onClose() }) {
        val shape = RoundedCornerShape(32.dp)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(Modifier.fillMaxWidth().clip(shape).background(Brush.verticalGradient(listOf(p.bg2, p.bg))).border(1.dp, p.line, shape).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (failed) tr("ضبط ممکن نشد", "Cannot record") else tr("در حال ضبط ویس…", "Recording voice…"), color = p.sub, fontSize = 15.sp)
                val inf = rememberInfiniteTransition(label = "pulse")
                val sc by inf.animateFloat(1f, 1.12f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "scale")
                Box(Modifier.size(130.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(86.dp).scale(sc).clip(CircleShape).background(p.primary.copy(alpha = .14f)))
                    Box(Modifier.size(72.dp).shadow(14.dp, CircleShape, ambientColor = p.primary, spotColor = p.primary).clip(CircleShape).background(Brush.linearGradient(listOf(p.primary, p.primary2))), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Mic, null, tint = Color.White, modifier = Modifier.size(34.dp))
                    }
                }
                Text(listNum(String.format(Locale.US, "%02d:%02d", ms / 60000, (ms / 1000) % 60)), color = p.text, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    bars.forEach { b -> Box(Modifier.weight(1f).fillMaxHeight(b).clip(RoundedCornerShape(50)).background(Brush.verticalGradient(listOf(p.primary, p.primary2)))) }
                }
                Spacer(Modifier.height(24.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    CircleBtn(Icons.Default.Close, { release(); file.delete(); onClose() }, size = 58.dp, tint = p.danger)
                    Box(Modifier.size(74.dp).shadow(14.dp, CircleShape, ambientColor = p.primary, spotColor = p.primary).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(p.primary, p.primary2)))
                        .clickable {
                            if (failed) return@clickable
                            val ok = release()
                            val bytes = if (ok) runCatching { file.readBytes() }.getOrNull() else null
                            file.delete()
                            if (bytes != null && bytes.size > 600) onDone(Attach(bytes, "audio/amr", "voice_${System.currentTimeMillis() / 1000}.amr"))
                            else { Toast.makeText(act, tr("ضبط خیلی کوتاه بود", "Recording too short"), Toast.LENGTH_SHORT).show(); onClose() }
                        }, contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.White, modifier = Modifier.size(30.dp))
                    }
                }
            }
        }
    }
}

@Suppress("DEPRECATION")
private fun voiceLegacy(): MediaRecorder = MediaRecorder()
