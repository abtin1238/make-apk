'use strict';
// Abtin Core - content script (top frame only; isolated from the page's JS world).
(function () {
  if (window.top !== window) return;

  // ---- cosmetic ad hiding ------------------------------------------------
  browser.runtime.sendMessage({ t: 'getConfig' }).then(function (c) {
    if (!c) return;
    mbCfg(c);
    if (!c.adblock || !c.cosmetic) return;
    var s = document.createElement('style');
    s.textContent = c.cosmetic;
    var add = function () { (document.head || document.documentElement).appendChild(s); };
    if (document.documentElement) add(); else document.addEventListener('readystatechange', add, { once: true });
  }).catch(function () {});


  // ---- native port (retries: the app may attach its delegate a moment after the page started) ----
  var port = null, tries = 0;

  function sendPage() {
    if (!port) return;
    var icon = '', theme = '';
    var l = document.querySelector('link[rel~="icon"],link[rel="shortcut icon"],link[rel="apple-touch-icon"]');
    if (l && l.href) icon = l.href; else if (location.protocol.indexOf('http') === 0) icon = location.origin + '/favicon.ico';
    var m = document.querySelector('meta[name="theme-color"]');
    if (m) theme = m.content || '';
    lastTheme = theme;
    try { port.postMessage({ t: 'page', icon: icon, theme: theme, iconData: iconDone[icon] || '' }); } catch (e) {}
    wantIcon(icon);
  }

  var iconDone = {}, iconAsked = {}, lastTheme = '';
  function wantIcon(icon) {
    if (!icon || iconDone[icon] || iconAsked[icon]) return;
    iconAsked[icon] = 1;
    browser.runtime.sendMessage({ t: 'icon', url: icon }).then(function (d) {
      if (!d) { iconAsked[icon] = 0; return; }
      iconDone[icon] = d;
      if (port) try { port.postMessage({ t: 'page', icon: icon, theme: lastTheme, iconData: d }); } catch (e) {}
    }).catch(function () { iconAsked[icon] = 0; });
  }

  function retry() {
    port = null;
    if (tries++ < 8) setTimeout(connect, 500 * tries);
  }

  function connect() {
    try {
      var p = browser.runtime.connectNative('abtin');
      port = p;
      p.onMessage.addListener(onCmd);
      p.onDisconnect.addListener(function () { if (port === p) retry(); });
      sendPage();
      flushMedia();
    } catch (e) { retry(); }
  }
  connect();

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', sendPage); else sendPage();
  window.addEventListener('load', sendPage);
  window.addEventListener('pageshow', function (e) { if (e.persisted && !port) { tries = 0; connect(); } });

  // commands can also arrive through the background page (tabs.sendMessage) when the port is missing
  browser.runtime.onMessage.addListener(function (m) { onCmd(m); });

  // ---- Touch-and-hold video previews ----------------------------------------------------------------------------
  // Many sites start a preview (a muted <video>, or frames swapped in an <img>) while a thumbnail is held. After ~0.5 s the
  // browser's long-press menu / text selection used to take the touch over and the preview stopped after a few frames.
  // While a preview is running under the finger, the long-press menu and the selection are suppressed.
  var tpEl = null, tpMut = 0, tpMo = null, tpStyle = null, tpAt = 0;
  function tpRoot(t) {
    if (!t || !t.closest) return null;
    return t.closest('a, [class*=thumb i], [class*=preview i], [class*=video i], li, article') || t.parentElement;
  }
  function tpPlaying(root) {
    var vs = root ? root.querySelectorAll('video') : [];
    for (var i = 0; i < vs.length; i++) {
      var v = vs[i];
      if (!v.controls && !v.paused && !v.ended) return true;
    }
    return false;
  }
  function tpEnd() {
    if (tpMo) { try { tpMo.disconnect(); } catch (e) {} tpMo = null; }
    if (tpEl && tpStyle !== null) { try { tpEl.style.setProperty('-moz-user-select', tpStyle || '', ''); if (!tpStyle) tpEl.style.removeProperty('-moz-user-select'); } catch (e) {} }
    tpStyle = null;
    setTimeout(function () { tpEl = null; tpMut = 0; }, 400); // a late contextmenu after touchend is still ours
  }
  document.addEventListener('touchstart', function (e) {
    if (e.touches && e.touches.length > 1) return;
    var root = tpRoot(e.target);
    if (!root || root === document.body || root === document.documentElement) return;
    tpEnd();
    tpEl = root; tpMut = 0; tpAt = Date.now();
    try { tpStyle = root.style.getPropertyValue('-moz-user-select') || ''; root.style.setProperty('-moz-user-select', 'none', 'important'); } catch (x) { tpStyle = null; }
    try {
      tpMo = new MutationObserver(function (ms) { tpMut += ms.length; });
      tpMo.observe(root, { subtree: true, childList: true, attributes: true, attributeFilter: ['src', 'srcset', 'style', 'class', 'poster'] });
    } catch (x) {}
  }, { passive: true, capture: true });
  ['touchend', 'touchcancel'].forEach(function (n) { document.addEventListener(n, function () { if (tpMo || tpStyle !== null) tpEnd(); }, { passive: true, capture: true }); });
  document.addEventListener('contextmenu', function (e) {
    if (!tpEl || !tpEl.contains(e.target) || Date.now() - tpAt > 15000) return;
    if (tpMut >= 3 || tpPlaying(tpEl)) { e.preventDefault(); }
  }, true);

  // ---- SMS login codes: the app reads the SMS (RECEIVE_SMS) and sends only the digits; we put them in the code box ----
  var otpCode = '', otpHost = '', otpAt = 0, otpChip = null, otpAsked = 0;
  var OTP_NAME = /otp|one[-_ ]?time|sms|verif|vcode|v-code|passcode|confirm.?code|auth.?code|activation|\u06a9\u062f|\u062a\u0627\u06cc\u06cc\u062f|\u062a\u0623\u06cc\u06cc\u062f|\u0631\u0645\u0632 \u06cc\u06a9/i;

  function otpOk(el) {
    if (!el || el.tagName !== 'INPUT' || el.disabled || el.readOnly) return false;
    var ty = (el.getAttribute('type') || 'text').toLowerCase();
    if (ty !== 'text' && ty !== 'tel' && ty !== 'number' && ty !== 'search') return false;
    var ac = (el.getAttribute('autocomplete') || '').toLowerCase();
    if (ac.indexOf('one-time-code') >= 0) return true;
    var ml = parseInt(el.getAttribute('maxlength') || '0', 10);
    var im = (el.getAttribute('inputmode') || '').toLowerCase();
    var txt = [el.name, el.id, el.placeholder, el.getAttribute('aria-label'), el.getAttribute('data-testid'), typeof el.className === 'string' ? el.className : ''].join(' ');
    if (OTP_NAME.test(txt)) return true;
    // split boxes: several 1-character numeric inputs side by side
    if (ml === 1 && (im === 'numeric' || ty === 'tel' || ty === 'number' || /digit|num|pin|code/i.test(txt))) return otpBoxes(el).length >= 4;
    // a 4-8 digit numeric box
    return ml >= 4 && ml <= 8 && (im === 'numeric' || ty === 'tel' || ty === 'number');
  }

  function otpBoxes(el) {
    var p = el.parentElement, i = 0, list = [];
    while (p && i++ < 3) {
      list = Array.prototype.filter.call(p.querySelectorAll('input'), function (x) {
        return !x.disabled && !x.readOnly && parseInt(x.getAttribute('maxlength') || '0', 10) === 1;
      });
      if (list.length >= 4) return list;
      p = p.parentElement;
    }
    return [];
  }

  function otpSet(el, v) {
    try { el.focus(); } catch (e) {}
    try { el.value = v; } catch (e) { return; }
    ['keydown', 'keypress'].forEach(function (t) { try { el.dispatchEvent(new KeyboardEvent(t, { key: v.slice(-1), bubbles: true })); } catch (e) {} });
    try { el.dispatchEvent(new InputEvent('input', { bubbles: true, data: v, inputType: 'insertText' })); } catch (e) { el.dispatchEvent(new Event('input', { bubbles: true })); }
    try { el.dispatchEvent(new KeyboardEvent('keyup', { key: v.slice(-1), bubbles: true })); } catch (e) {}
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function otpFill(el, code) {
    var boxes = parseInt(el.getAttribute('maxlength') || '0', 10) === 1 ? otpBoxes(el) : [];
    if (boxes.length >= 4) {
      for (var i = 0; i < boxes.length && i < code.length; i++) otpSet(boxes[i], code.charAt(i));
      try { boxes[Math.min(code.length, boxes.length) - 1].focus(); } catch (e) {}
    } else {
      var ml = parseInt(el.getAttribute('maxlength') || '0', 10);
      otpSet(el, ml > 0 && ml < code.length ? code.slice(0, ml) : code);
    }
  }

  function otpTarget() {
    var a = document.activeElement;
    if (otpOk(a)) return a;
    var list = document.querySelectorAll('input');
    for (var i = 0; i < list.length && i < 300; i++) {
      var el = list[i];
      if (!otpOk(el)) continue;
      var r = el.getBoundingClientRect();
      if (r.width > 4 && r.height > 4 && getComputedStyle(el).visibility !== 'hidden') return el;
    }
    return null;
  }

  function otpHideChip() { if (otpChip) { try { otpChip.remove(); } catch (e) {} otpChip = null; } }

  // Fallback when no code box is on the page (or the SMS names another site): a small pill with the code; tap = copy.
  function otpShowChip(code, why) {
    otpHideChip();
    var host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;left:0;right:0;bottom:calc(env(safe-area-inset-bottom,0px) + 72px);z-index:2147483647;display:flex;justify-content:center;pointer-events:none';
    var sh = host.attachShadow({ mode: 'closed' });
    var fa = (document.documentElement.lang || navigator.language || '').indexOf('fa') === 0 || /[\u0600-\u06ff]/.test(document.title || '');
    var b = document.createElement('button');
    b.style.cssText = 'pointer-events:auto;font:600 15px system-ui,sans-serif;background:#1f2937;color:#fff;border:0;border-radius:22px;padding:10px 18px;box-shadow:0 4px 16px rgba(0,0,0,.35);direction:ltr';
    b.textContent = (fa ? '\u06a9\u062f \u067e\u06cc\u0627\u0645\u06a9: ' : 'SMS code: ') + code + (why ? '  \u00b7  ' : '  \u00b7  ') + (fa ? '\u06a9\u067e\u06cc' : 'Copy');
    b.addEventListener('click', function () {
      try { navigator.clipboard.writeText(code); b.textContent = fa ? '\u06a9\u067e\u06cc \u0634\u062f' : 'Copied'; } catch (e) {}
      setTimeout(otpHideChip, 900);
    });
    sh.appendChild(b);
    (document.body || document.documentElement).appendChild(host);
    otpChip = host;
    setTimeout(function () { if (otpChip === host) otpHideChip(); }, 25000);
  }

  function otpTry(auto) {
    if (!otpCode || Date.now() - otpAt > 5 * 60000) { otpCode = ''; return false; }
    var el = otpTarget();
    // The SMS carries "@site #code" (Web OTP format): never put it into another site's box.
    var wrong = otpHost && location.hostname !== otpHost && location.hostname.slice(-otpHost.length - 1) !== '.' + otpHost;
    if (el && !wrong) {
      otpFill(el, otpCode);
      try { port && port.postMessage({ t: 'otpUsed' }); } catch (e) {}
      otpCode = '';
      otpHideChip();
      return true;
    }
    if (!auto || !wrong) otpShowChip(otpCode, wrong);
    return false;
  }

  function onOtp(m) {
    if (!m.code) return;
    otpCode = String(m.code); otpHost = String(m.host || '').toLowerCase(); otpAt = Date.now();
    // wait a moment so a code box that is just being built can appear
    if (!otpTry(true)) setTimeout(function () { if (otpCode) otpTry(false); }, 1200);
  }

  document.addEventListener('focusin', function (e) {
    if (!otpOk(e.target)) return;
    if (otpCode && otpTry(true)) return;
    // tell the app a code box is focused: it asks for the SMS permission once, or answers with a fresh code
    if (port && Date.now() - otpAsked > 3000) { otpAsked = Date.now(); try { port.postMessage({ t: 'otpField' }); } catch (x) {} }
  }, true);

  // ---- Back inside a web app (PWA): close the open chat / dialog / panel. Reports {t:'backDone', id, handled} ----
  function pwaBack(id) {
    var changed = false, done = false;
    var mo = new MutationObserver(function () { changed = true; });
    try { mo.observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: false }); } catch (e) {}
    function reply(h) {
      if (done) return;
      done = true;
      try { mo.disconnect(); } catch (e) {}
      try { port && port.postMessage({ t: 'backDone', id: id, handled: !!h }); } catch (e) {}
    }
    function esc() {
      var t = document.activeElement || document.body;
      ['keydown', 'keyup'].forEach(function (type) {
        var ev = new KeyboardEvent(type, { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true });
        try { t.dispatchEvent(ev); } catch (e) {}
        if (t !== document.body) try { document.body.dispatchEvent(new KeyboardEvent(type, { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true })); } catch (e) {}
      });
    }
    var RX = /(^|[\s_\-])(back|go-?back|arrow-?back|tgico-back|btn-back|navigate-back|close-?button|sidebar-close|nav-back)([\s_\-]|$)|بازگشت|برگشت|بستن|^back$|^close$/i;
    function visible(el) {
      var r = el.getBoundingClientRect();
      if (r.width < 8 || r.height < 8 || r.bottom < 0 || r.top > innerHeight * 0.35) return false;
      var cs = getComputedStyle(el);
      return cs.visibility !== 'hidden' && cs.display !== 'none' && cs.opacity !== '0';
    }
    function backButton() {
      var list = document.querySelectorAll('button, [role=button], a, [class*=back i], [class*=close i], [aria-label], [title]');
      var best = null;
      for (var i = 0; i < list.length && i < 4000; i++) {
        var el = list[i];
        var txt = (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '') + ' ' + (typeof el.className === 'string' ? el.className : '');
        if (!RX.test(txt.trim()) && !RX.test((el.getAttribute('aria-label') || '').trim())) continue;
        if (!visible(el)) continue;
        var r = el.getBoundingClientRect();
        // header-like: prefer the highest element; leftmost / rightmost corners are where back buttons live
        if (!best || r.top < best.r.top - 4) best = { el: el, r: r };
      }
      return best && best.el;
    }
    esc();
    setTimeout(function () {
      if (changed) return reply(true);
      var b = backButton();
      if (!b) return reply(false);
      changed = false;
      try { b.click(); } catch (e) { return reply(false); }
      setTimeout(function () { reply(changed); }, 200);
    }, 180);
    setTimeout(function () { reply(changed); }, 900);
  }

  function onCmd(m) {
    if (!m) return;
    if (m.cmd === 'reader') toggleReader(!!m.dark, m.lang);
    else if (m.cmd === 'uiCfg') { mbCfg(m); }
    else if (m.cmd === 'savePage') savePage();
    else if (m.cmd === 'back') pwaBack(m.id);
    else if (m.cmd === 'otp') onOtp(m);
    else if (m.cmd === 'media') reportMedia({ url: m.url, mime: m.mime, size: m.size, kind: m.kind, part: m.part, ts: m.ts });
  }


  // ======================================================================
  //  Save page: one self-contained .html (styles + images inlined, scripts removed)
  // ======================================================================
  function savePage() {
    var TOTAL = 24 * 1024 * 1024, IMG = 1536 * 1024, used = 0;
    function send(o) {
      if (!port) { tries = 0; connect(); }
      try { port.postMessage(o); } catch (e) {}
    }
    function abs(u) { try { return new URL(u, document.baseURI).href; } catch (e) { return ''; } }
    function toData(url) {
      return fetch(url, { credentials: 'include' }).then(function (r) {
        if (!r.ok) throw 0;
        return r.blob();
      }).then(function (b) {
        if (b.size > IMG || used + b.size > TOTAL) throw 0;
        used += b.size;
        return new Promise(function (ok, no) {
          var fr = new FileReader();
          fr.onload = function () { ok(fr.result); };
          fr.onerror = no;
          fr.readAsDataURL(b);
        });
      });
    }
    var root = document.documentElement.cloneNode(true);
    var jobs = [];
    root.querySelectorAll('script, noscript, iframe, object, embed, link[rel=preload], link[rel=modulepreload], link[rel=prefetch]').forEach(function (n) { n.remove(); });
    root.querySelectorAll('[onclick],[onload],[onerror]').forEach(function (n) { n.removeAttribute('onclick'); n.removeAttribute('onload'); n.removeAttribute('onerror'); });
    root.querySelectorAll('link[rel~=stylesheet][href]').forEach(function (l) {
      var u = abs(l.getAttribute('href'));
      if (!u) return;
      jobs.push(fetch(u, { credentials: 'include' }).then(function (r) { return r.ok ? r.text() : Promise.reject(); }).then(function (css) {
        if (used + css.length > TOTAL) throw 0;
        used += css.length;
        // make relative url() / @import in the stylesheet absolute, so images still resolve when online
        css = css.replace(/url\(\s*(['"]?)(?!data:|https?:|#|\/\/)([^'")]+)\1\s*\)/gi, function (_, q, rel) {
          try { return 'url("' + new URL(rel, u).href + '")'; } catch (e) { return _; }
        });
        var st = document.createElement('style');
        st.textContent = css;
        l.replaceWith(st);
      }).catch(function () {}));
    });
    root.querySelectorAll('img[src], source[srcset], img[srcset]').forEach(function (im) {
      im.removeAttribute('srcset'); im.removeAttribute('loading');
      var u = im.getAttribute('src');
      if (!u || /^data:/i.test(u)) return;
      u = abs(u);
      if (!u) return;
      im.setAttribute('src', u);
      jobs.push(toData(u).then(function (d) { im.setAttribute('src', d); }).catch(function () {}));
    });
    root.querySelectorAll('a[href]').forEach(function (a) { var h = abs(a.getAttribute('href')); if (h) a.setAttribute('href', h); });
    var head = root.querySelector('head');
    if (head) {
      var b = document.createElement('base');
      b.setAttribute('href', document.baseURI);
      head.insertBefore(b, head.firstChild);
      head.insertBefore(document.createComment(' Saved by Abtin Browser from ' + location.href + ' on ' + new Date().toISOString() + ' '), head.firstChild);
    }
    Promise.all(jobs).then(function () {
      var html = '<!DOCTYPE html>\n' + root.outerHTML;
      send({ t: 'pageSaved', url: location.href, title: document.title || '', html: html });
    }).catch(function () { send({ t: 'pageSaved', url: location.href, title: '', html: '' }); });
  }

  // ======================================================================
  //  Media detection (the app shows a download / play button when something is found)
  // ======================================================================
  var seenMedia = {}, pendingMedia = [], blobSent = false;
  function posterUrl() {
    var v = document.querySelector('video[poster]');
    return v && v.poster ? v.poster : '';
  }
  function sendMedia(m) {
    try {
      port.postMessage({ t: 'media', url: m.url || '', mime: m.mime || '', size: typeof m.size === 'number' ? m.size : -1, kind: m.kind || 'video',
        part: m.part || '', ts: m.ts || Date.now(), page: location.href, title: document.title || '', poster: m.poster || posterUrl() });
    } catch (e) {}
  }
  function reportMedia(m) {
    if (!m) return;
    var key = m.url || ('#' + m.kind);
    if (seenMedia[key]) return;
    seenMedia[key] = 1;
    if (!port) { pendingMedia.push(m); return; }
    sendMedia(m);
  }
  function flushMedia() {
    if (!port || !pendingMedia) return;   // connect() can run before this block initialised the queue
    pendingMedia.splice(0).forEach(sendMedia);
  }
  function mediaKindOf(url, el) {
    var path = url.split('#')[0].split('?')[0].toLowerCase();
    if (/\.m3u8$/.test(path)) return 'hls';
    if (/\.(mp3|m4a|ogg|oga|opus|flac|wav)$/.test(path)) return 'audio';
    return el && el.tagName === 'AUDIO' ? 'audio' : 'video';
  }
  function cleanMediaUrl(u) {
    try {
      var o = new URL(u, location.href);
      if (/(^|\.)(fbcdn\.net|cdninstagram\.com)$/.test(o.hostname)) { o.searchParams.delete('bytestart'); o.searchParams.delete('byteend'); }
      return o.toString();
    } catch (e) { return u; }
  }
  var scanN = 0;
  function scanMedia() {
    if (document.visibilityState === 'hidden') return;
    try {
      var els = document.querySelectorAll('video,audio,video source,audio source');
      for (var i = 0; i < els.length; i++) {
        var el = els[i], src = el.currentSrc || el.src || '';
        if (/^https?:/i.test(src)) {
          var u = cleanMediaUrl(src);
          reportMedia({ url: u, kind: mediaKindOf(u, el), mime: el.type || '', size: -1, poster: el.poster || '' });
        } else if (/^blob:/i.test(src) && !blobSent) {
          blobSent = true;
          reportMedia({ url: '', kind: 'blob' });
        }
      }
      var metas = document.querySelectorAll('meta[property="og:video"],meta[property="og:video:url"],meta[property="og:video:secure_url"],meta[name="twitter:player:stream"]');
      for (var j = 0; j < metas.length; j++) {
        var c = metas[j].content;
        if (/^https?:/i.test(c) && /\.(mp4|m3u8|webm|mov)(\?|$)/i.test(c)) reportMedia({ url: cleanMediaUrl(c), kind: mediaKindOf(c, null), size: -1 });
      }
      var as = (document.querySelector('video,audio') || (scanN++ % 3 === 0)) ? document.querySelectorAll('a[href]') : [];
      for (var k = 0; k < as.length && k < 400; k++) {
        var h = as[k].href;
        if (/\.(mp4|webm|mkv|mov|m4v|mp3|m4a)(\?|#|$)/i.test(h)) reportMedia({ url: h, kind: mediaKindOf(h, null), size: -1 });
      }
    } catch (e) {}
  }
  setInterval(scanMedia, 5000);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scanMedia); else scanMedia();
  browser.runtime.sendMessage({ t: 'recentMedia' }).then(function (l) {
    (l || []).forEach(reportMedia);
  }).catch(function () {});


  // ======================================================================
  //  In-page video buttons (download / player), like Samsung Internet's video assistant.
  //  The X hides them for the whole site (remembered); they can be re-enabled in Settings.
  // ======================================================================
  var prOn = true, sbOn = true, mbOn = true, mbFa = true, mbOff = {}, mbHost = null, mbShadow = null, mbBox = null, mbRaf = 0, mbTarget = null;
  function mbCfg(c) {
    if (typeof c.mediaBtn === 'boolean') mbOn = c.mediaBtn;
    if (typeof c.pullRefresh === 'boolean') prOn = c.pullRefresh;
    if (typeof c.scrollBtn === 'boolean') sbOn = c.scrollBtn;
    sbTick();
    if (c.lang) mbFa = c.lang !== 'en';
    if (c.resetOff) mbOff = {};
    try {
      browser.storage.local.get('mbOff').then(function (r) { if (!c.resetOff) mbOff = (r && r.mbOff) || {}; mbTick(); }).catch(function () {});
    } catch (e) {}
    mbTick();
  }
  // The X closes the buttons on this site; turning the video buttons off and on again in the settings brings them back everywhere.
  function mbDismissed() { return !!mbOff[location.hostname]; }
  function mbDismiss() {
    mbOff[location.hostname] = 1;
    try { browser.storage.local.set({ mbOff: mbOff }).catch(function () {}); } catch (e) {}
    mbTick();
  }
  function mbPickVideo() {
    var best = null, bestA = 0, vh = window.innerHeight || 0, vw = window.innerWidth || 0;
    var vs = document.getElementsByTagName('video');
    for (var i = 0; i < vs.length; i++) {
      var v = vs[i], r = v.getBoundingClientRect();
      if (r.width < 150 || r.height < 90) continue;
      var w = Math.min(r.right, vw) - Math.max(r.left, 0), h = Math.min(r.bottom, vh) - Math.max(r.top, 0);
      if (w < 120 || h < 70) continue;
      if (v.readyState < 1 && !v.currentSrc && !v.src && !v.querySelector('source')) continue;
      var cs = getComputedStyle(v);
      if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) === 0) continue;
      var a = w * h * (v.paused ? 1 : 2);
      if (a > bestA) { bestA = a; best = v; }
    }
    return best;
  }
  // when each <video> started loading its current source: used to tell which sniffed stream belongs to which video (blob/MSE players)
  function mbMark(ev) {
    var v = ev.target;
    if (!v || v.tagName !== 'VIDEO') return;
    if (ev.type === 'loadstart' || !v.__abT) v.__abT = Date.now();
  }
  ['loadstart', 'play', 'playing'].forEach(function (n) { document.addEventListener(n, mbMark, true); });
  function mbBuild() {
    if (mbHost) return;
    mbHost = document.createElement('div');
    mbHost.id = '__abtin_mb';
    mbHost.style.cssText = 'all:initial;position:fixed;left:0;top:0;width:0;height:0;z-index:2147483646;';
    mbShadow = mbHost.attachShadow({ mode: 'closed' });
    var st0 = document.createElement('style');
    st0.textContent = '.b{position:fixed;display:none;gap:2px;align-items:center;padding:3px;border-radius:22px;background:rgba(18,18,22,.72);' +
      'backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);box-shadow:0 2px 10px rgba(0,0,0,.45);direction:ltr;font:600 12px/1 sans-serif;color:#fff;touch-action:manipulation}' +
      '.b button{all:unset;box-sizing:border-box;display:flex;align-items:center;gap:5px;height:34px;min-width:34px;padding:0 10px;border-radius:17px;color:#fff;cursor:pointer;justify-content:center;-webkit-tap-highlight-color:transparent}' +
      '.b button:active{background:rgba(255,255,255,.25)}.b .x{padding:0;width:30px;min-width:30px;opacity:.8}.b svg{width:18px;height:18px;fill:#fff;flex:none}' +
      '.b .d{background:#2f7df6}';
    mbShadow.appendChild(st0);
    mbBox = document.createElement('div');
    mbBox.className = 'b';
    var ic = {
      dl: '<svg viewBox="0 0 24 24"><path d="M5 20h14v-2H5v2zM12 4v9.2l3.6-3.6L17 11l-5 5-5-5 1.4-1.4L11 13.2V4h1z"/></svg>',
      pl: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',
      x: '<svg viewBox="0 0 24 24"><path d="M18.3 5.7 12 12l6.3 6.3-1.4 1.4L10.6 13.4 4.3 19.7 2.9 18.3 9.2 12 2.9 5.7 4.3 4.3l6.3 6.3 6.3-6.3z" transform="translate(1.2 0) scale(.9)"/></svg>'
    };
    function mk(cls, svg, label, act) {
      var b = document.createElement('button');
      b.className = cls;
      b.innerHTML = svg + (label ? '<span>' + label + '</span>' : '');
      ['pointerdown', 'pointerup', 'touchstart', 'touchend', 'mousedown', 'mouseup'].forEach(function (n) {
        b.addEventListener(n, function (ev) { ev.stopPropagation(); }, true);
      });
      b.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); act(); }, true);
      return b;
    }
    mbBox.appendChild(mk('d', ic.dl, mbFa ? 'دانلود' : 'Download', function () { mbAct('download'); }));
    mbBox.appendChild(mk('p', ic.pl, mbFa ? 'پلیر' : 'Player', function () { mbAct('play'); }));
    mbBox.appendChild(mk('x', ic.x, '', mbDismiss));
    mbShadow.appendChild(mbBox);
    (document.documentElement || document.body).appendChild(mbHost);
  }
  function mbAct(act) {
    var v = mbTarget, u = v ? (v.currentSrc || v.src || '') : '';
    var o = { t: 'mediaAct', act: act, url: /^https?:/i.test(u) ? cleanMediaUrl(u) : '', page: location.href, title: document.title || '', poster: (v && v.poster) || '', t0: (v && v.__abT) || 0 };
    if (!port) { tries = 0; connect(); }
    try { port.postMessage(o); } catch (e) {}
  }
  function mbTick() {
    if (mbRaf) return;
    mbRaf = requestAnimationFrame(function () {
      mbRaf = 0;
      try {
        if (!mbOn || mbDismissed() || document.visibilityState === 'hidden') { if (mbBox) mbBox.style.display = 'none'; mbTarget = null; return; }
        var v = mbPickVideo();
        if (!v) { if (mbBox) mbBox.style.display = 'none'; mbTarget = null; return; }
        mbBuild();
        mbTarget = v;
        var r = v.getBoundingClientRect(), vw = window.innerWidth || 0;
        mbBox.style.display = 'flex';
        var w = mbBox.offsetWidth || 150;
        var left = Math.max(6, Math.min(r.right - w - 8, vw - w - 6));
        var top = Math.max(6, r.top + 8);
        mbBox.style.left = left + 'px';
        mbBox.style.top = top + 'px';
      } catch (e) {}
    });
  }
  setInterval(function () { if (document.visibilityState !== 'hidden' && document.querySelector('video')) mbTick(); }, 800);
  window.addEventListener('scroll', mbTick, { passive: true, capture: true });
  window.addEventListener('resize', mbTick, { passive: true });
  document.addEventListener('play', mbTick, true);
  document.addEventListener('loadedmetadata', mbTick, true);


  // ======================================================================
  //  Pull down to refresh + Opera-style jump-to-top / jump-to-bottom button
  // ======================================================================
  var prHost = null, prDot = null, prY0 = 0, prX0 = 0, prDy = 0, prActive = false, PR_MAX = 150, PR_GO = 95;
  function prAtTop(el) {
    if ((window.pageYOffset || document.documentElement.scrollTop || 0) > 0) return false;
    for (var n = el; n && n !== document.body && n !== document.documentElement; n = n.parentElement) {
      if (n.scrollTop > 0) return false;
    }
    return true;
  }
  function prBuild() {
    if (prHost) return;
    prHost = document.createElement('div');
    prHost.style.cssText = 'all:initial;position:fixed;left:0;top:0;width:100%;height:0;z-index:2147483646;pointer-events:none;';
    var sh = prHost.attachShadow({ mode: 'closed' });
    prDot = document.createElement('div');
    prDot.style.cssText = 'position:absolute;left:50%;top:0;width:40px;height:40px;margin-left:-20px;border-radius:50%;background:#fff;box-shadow:0 2px 10px rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center;transform:translateY(-60px);will-change:transform';
    prDot.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" style="transition:transform .15s"><path fill="#2f7df6" d="M17.65 6.35A7.96 7.96 0 0 0 12 4a8 8 0 1 0 7.73 10h-2.08A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>';
    sh.appendChild(prDot);
    (document.documentElement || document.body).appendChild(prHost);
  }
  function prSet(dy) {
    prBuild();
    var y = Math.min(dy, PR_MAX) * .75 - 50;
    prDot.style.transition = 'none';
    prDot.style.transform = 'translateY(' + y + 'px)';
    prDot.firstChild.style.transform = 'rotate(' + (dy * 3) + 'deg)';
  }
  function prHide(spin) {
    if (!prDot) return;
    prDot.style.transition = 'transform .2s';
    prDot.style.transform = 'translateY(-60px)';
  }
  window.addEventListener('touchstart', function (e) {
    prActive = false; prDy = 0;
    if (!prOn || e.touches.length !== 1 || document.fullscreenElement) return;
    if (!prAtTop(e.target)) return;
    prY0 = e.touches[0].clientY; prX0 = e.touches[0].clientX; prActive = true;
  }, { passive: true, capture: true });
  window.addEventListener('touchmove', function (e) {
    if (!prActive) return;
    var dy = e.touches[0].clientY - prY0, dx = Math.abs(e.touches[0].clientX - prX0);
    if (dy <= 0 || (window.pageYOffset || 0) > 0) { if (prDy > 0) prHide(); prActive = dy > 0 && prActive; prDy = 0; if (dy <= 0) prActive = false; return; }
    if (dx > dy) { prActive = false; prHide(); return; }
    prDy = dy;
    if (dy > 12) prSet(dy);
  }, { passive: true, capture: true });
  function prEnd() {
    if (!prActive) return;
    var go = prDy >= PR_GO;
    prActive = false; prDy = 0;
    if (go) {
      if (prDot) { prDot.style.transition = 'transform .15s'; prDot.style.transform = 'translateY(' + (PR_GO * .75 - 50) + 'px)'; prDot.firstChild.style.animation = 'none'; }
      setTimeout(function () { try { location.reload(); } catch (e) {} }, 120);
    } else prHide();
  }
  window.addEventListener('touchend', prEnd, { passive: true, capture: true });
  window.addEventListener('touchcancel', function () { prActive = false; prDy = 0; prHide(); }, { passive: true, capture: true });

  var sbHost = null, sbBtn = null, sbLast = 0, sbDir = 0, sbHideT = 0, sbRaf = 0;
  function sbBuild() {
    if (sbHost) return;
    sbHost = document.createElement('div');
    sbHost.style.cssText = 'all:initial;position:fixed;right:0;bottom:0;width:0;height:0;z-index:2147483645;';
    var sh = sbHost.attachShadow({ mode: 'closed' });
    sbBtn = document.createElement('button');
    sbBtn.style.cssText = 'all:initial;position:fixed;right:14px;bottom:84px;width:44px;height:44px;border-radius:50%;background:rgba(30,30,36,.78);box-shadow:0 2px 10px rgba(0,0,0,.4);display:none;align-items:center;justify-content:center;opacity:0;transition:opacity .2s;-webkit-tap-highlight-color:transparent;cursor:pointer';
    sbBtn.innerHTML = '<svg viewBox="0 0 24 24" width="26" height="26"><path fill="#fff" d="M12 8l6 6-1.4 1.4L12 10.8l-4.6 4.6L6 14z"/></svg>';
    ['touchstart', 'touchend', 'pointerdown', 'pointerup', 'mousedown', 'mouseup'].forEach(function (n) { sbBtn.addEventListener(n, function (ev) { ev.stopPropagation(); }, true); });
    sbBtn.addEventListener('click', function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      var top = sbDir < 0;
      try { window.scrollTo({ top: top ? 0 : Math.max(document.documentElement.scrollHeight, document.body ? document.body.scrollHeight : 0), behavior: 'smooth' }); } catch (e) {}
      sbShow(false);
    }, true);
    sh.appendChild(sbBtn);
    (document.documentElement || document.body).appendChild(sbHost);
  }
  function sbShow(on) {
    if (!sbBtn) return;
    clearTimeout(sbHideT);
    if (!on) { sbBtn.style.opacity = '0'; sbHideT = setTimeout(function () { sbBtn.style.display = 'none'; }, 220); return; }
    sbBtn.style.display = 'flex';
    requestAnimationFrame(function () { sbBtn.style.opacity = '1'; });
    sbHideT = setTimeout(function () { sbShow(false); }, 3000);
  }
  function sbTick() { if (!sbOn && sbBtn) sbShow(false); }
  window.addEventListener('scroll', function () {
    if (!sbOn || sbRaf) return;
    sbRaf = requestAnimationFrame(function () {
      sbRaf = 0;
      try {
        var y = window.pageYOffset || document.documentElement.scrollTop || 0;
        var h = Math.max(document.documentElement.scrollHeight, document.body ? document.body.scrollHeight : 0) - (window.innerHeight || 0);
        var d = y - sbLast;
        sbLast = y;
        if (Math.abs(d) < 14 || h < (window.innerHeight || 600) * 1.5) return;
        var dir = d > 0 ? 1 : -1;
        if ((dir < 0 && y < 120) || (dir > 0 && y > h - 120)) { if (sbBtn) sbShow(false); return; }
        sbBuild();
        sbDir = dir;
        sbBtn.firstChild.style.transform = dir < 0 ? 'none' : 'rotate(180deg)';
        sbShow(true);
      } catch (e) {}
    });
  }, { passive: true, capture: true });

  // ======================================================================
  //  Reader mode
  // ======================================================================
  var RDR = { size: 19, theme: null };
  var THEMES = {
    light: { bg: '#fbfbf8', fg: '#1b1b1b', sub: '#6b6b6b', link: '#0a58d6', bar: '#eeeeea', line: '#d9d9d2' },
    sepia: { bg: '#f4ecd8', fg: '#3a2f1d', sub: '#7a6a4f', link: '#8a4b08', bar: '#e9dfc6', line: '#d8c9a6' },
    dark: { bg: '#0d1b30', fg: '#e6edf7', sub: '#97a8c2', link: '#7db4ff', bar: '#16294a', line: '#243b63' }
  };
  var UNLIKELY = /(^|[\s_-])(banner|breadcrumb|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legend|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|share|newsletter|subscribe|cookie|nav|toolbar|widget|promo|advert|ads?)([\s_-]|$)/i;
  var MAYBE = /(article|body|column|content|main|shadow|post|entry|story)/i;
  var POSITIVE = /article|body|content|entry|hentry|h-entry|main|page|post|text|blog|story/i;
  var NEGATIVE = /hidden|banner|combx|comment|com-|contact|foot|footer|footnote|gdpr|masthead|media|meta|outbrain|promo|related|scroll|share|shoutbox|sidebar|skyscraper|sponsor|shopping|tags|tool|widget/i;
  var DROP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, IFRAME: 1, FORM: 1, NAV: 1, ASIDE: 1, FOOTER: 1, BUTTON: 1, INPUT: 1, SELECT: 1, TEXTAREA: 1, SVG: 1, CANVAS: 1, OBJECT: 1, EMBED: 1, AUDIO: 1, VIDEO: 1, LINK: 1, META: 1, TEMPLATE: 1, DIALOG: 1 };
  var KEEP = { P: 1, H1: 1, H2: 1, H3: 1, H4: 1, H5: 1, H6: 1, UL: 1, OL: 1, LI: 1, BLOCKQUOTE: 1, PRE: 1, CODE: 1, EM: 1, STRONG: 1, B: 1, I: 1, A: 1, BR: 1, IMG: 1, FIGURE: 1, FIGCAPTION: 1, TABLE: 1, THEAD: 1, TBODY: 1, TR: 1, TD: 1, TH: 1, HR: 1, SUP: 1, SUB: 1 };

  function txt(el) { return (el.textContent || '').replace(/\s+/g, ' ').trim(); }
  function weight(el) {
    var w = 0, s = (el.className && el.className.baseVal === undefined ? el.className : '') + ' ' + (el.id || '');
    if (typeof s !== 'string') return 0;
    if (POSITIVE.test(s)) w += 25;
    if (NEGATIVE.test(s)) w -= 25;
    return w;
  }
  function linkDensity(el) {
    var t = txt(el).length;
    if (!t) return 0;
    var n = 0;
    [].forEach.call(el.getElementsByTagName('a'), function (a) { n += txt(a).length; });
    return n / t;
  }
  function visible(el) {
    try { var cs = getComputedStyle(el); return cs.display !== 'none' && cs.visibility !== 'hidden'; } catch (e) { return true; }
  }

  // Readability-style scoring: paragraphs vote for their parent and grandparent.
  function findArticle() {
    var scores = new Map(), order = [];
    function init(el) {
      if (scores.has(el)) return;
      var s = 0;
      switch (el.tagName) {
        case 'DIV': s = 5; break;
        case 'PRE': case 'TD': case 'BLOCKQUOTE': s = 3; break;
        case 'ADDRESS': case 'OL': case 'UL': case 'DL': case 'DD': case 'DT': case 'LI': case 'FORM': s = -3; break;
        case 'H1': case 'H2': case 'H3': case 'H4': case 'H5': case 'H6': case 'TH': s = -5; break;
      }
      scores.set(el, s + weight(el));
      order.push(el);
    }
    var paras = document.querySelectorAll('p,pre,td,blockquote,div,li');
    for (var i = 0; i < paras.length && i < 6000; i++) {
      var p = paras[i];
      if (p.tagName === 'DIV' || p.tagName === 'LI') {
        // only "text divs": direct text, no block children
        if (p.querySelector('p,div,ul,ol,table,blockquote,pre,h1,h2,h3,h4,h5,h6')) continue;
      }
      var t = txt(p);
      if (t.length < 25) continue;
      var par = p.parentElement;
      if (!par || !visible(p)) continue;
      var gp = par.parentElement;
      init(par); if (gp) init(gp);
      var add = 1 + (t.match(/[,،،]/g) || []).length + Math.min(Math.floor(t.length / 100), 3);
      scores.set(par, scores.get(par) + add);
      if (gp) scores.set(gp, scores.get(gp) + add / 2);
    }
    var best = null, bestScore = 0;
    order.forEach(function (el) {
      var sc = scores.get(el) * (1 - linkDensity(el));
      if (sc > bestScore) { bestScore = sc; best = el; }
    });
    // hop up one level while the parent holds nearly all of the same text (avoids picking one half of a post)
    while (best && best.parentElement && best.parentElement !== document.body && best.parentElement !== document.documentElement) {
      var pt = txt(best.parentElement).length, bt = txt(best).length;
      if (bt > 0 && pt < bt * 1.15 && !UNLIKELY.test((best.parentElement.className || '') + ' ' + (best.parentElement.id || ''))) best = best.parentElement; else break;
    }
    return best;
  }

  function absUrl(u) { try { return new URL(u, document.baseURI).href; } catch (e) { return ''; } }

  function pickImg(img) {
    var src = img.getAttribute('src') || '';
    var lazy = img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || img.getAttribute('data-original') || '';
    if (lazy && (!src || /^data:/.test(src))) src = lazy;
    if (!src) {
      var ss = img.getAttribute('srcset') || img.getAttribute('data-srcset') || '';
      if (ss) src = ss.split(',')[0].trim().split(/\s+/)[0];
    }
    return src && !/^data:image\/(gif|svg)/.test(src) ? absUrl(src) : '';
  }

  function st(el, css) { el.style.cssText = css; return el; }

  // Copy only whitelisted tags into the overlay; everything else is unwrapped or dropped.
  function clean(src, out, th) {
    for (var n = src.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 3) { out.appendChild(document.createTextNode(n.nodeValue)); continue; }
      if (n.nodeType !== 1) continue;
      var tag = n.tagName;
      if (DROP[tag] || n.hidden || n.getAttribute('aria-hidden') === 'true') continue;
      var idc = (n.className && typeof n.className === 'string' ? n.className : '') + ' ' + (n.id || '');
      if (UNLIKELY.test(idc) && !MAYBE.test(idc)) continue;
      if (!KEEP[tag]) { clean(n, out, th); continue; }
      if ((tag === 'UL' || tag === 'OL' || tag === 'TABLE' || tag === 'FIGURE') && linkDensity(n) > .6 && txt(n).length < 600) continue;
      if (tag === 'IMG') {
        var u = pickImg(n);
        if (!u) continue;
        var w = parseInt(n.getAttribute('width') || '0', 10);
        if (w && w < 80) continue;
        var im = document.createElement('img');
        im.src = u; im.alt = n.getAttribute('alt') || '';
        st(im, 'display:block;max-width:100%;height:auto;margin:14px auto;border-radius:10px');
        out.appendChild(im);
        continue;
      }
      if (tag === 'BR' || tag === 'HR') { out.appendChild(document.createElement(tag.toLowerCase())); continue; }
      var e = document.createElement(tag.toLowerCase());
      if (tag === 'A') {
        var h = n.getAttribute('href');
        if (h && !/^javascript:/i.test(h)) { e.href = absUrl(h); e.rel = 'noopener noreferrer'; }
        st(e, 'color:' + th.link + ';text-decoration:underline');
      } else if (/^H[1-6]$/.test(tag)) {
        st(e, 'margin:1.4em 0 .5em;line-height:1.4;font-weight:700;font-size:' + ({ H1: 1.5, H2: 1.35, H3: 1.2, H4: 1.1, H5: 1.05, H6: 1 }[tag]) + 'em');
        e.setAttribute('dir', 'auto');
      } else if (tag === 'P' || tag === 'LI' || tag === 'BLOCKQUOTE' || tag === 'FIGCAPTION') {
        e.setAttribute('dir', 'auto');
        if (tag === 'P') st(e, 'margin:0 0 1em');
        if (tag === 'LI') st(e, 'margin:0 0 .5em');
        if (tag === 'BLOCKQUOTE') st(e, 'margin:1em 0;padding:.2em 1em;border-inline-start:4px solid ' + th.line + ';color:' + th.sub);
        if (tag === 'FIGCAPTION') st(e, 'font-size:.85em;color:' + th.sub + ';text-align:center;margin:-6px 0 14px');
      } else if (tag === 'UL' || tag === 'OL') {
        st(e, 'margin:0 0 1em;padding-inline-start:1.4em');
      } else if (tag === 'PRE' || tag === 'CODE') {
        st(e, 'direction:ltr;text-align:left;font-family:monospace;font-size:.88em;background:' + th.bar + ';border-radius:8px;' + (tag === 'PRE' ? 'padding:10px;overflow:auto;margin:0 0 1em' : 'padding:1px 5px'));
      } else if (tag === 'TABLE') {
        st(e, 'border-collapse:collapse;max-width:100%;display:block;overflow:auto;margin:0 0 1em');
      } else if (tag === 'TD' || tag === 'TH') {
        st(e, 'border:1px solid ' + th.line + ';padding:5px 8px');
      }
      clean(n, e, th);
      // drop empty shells (e.g. paragraphs that only held an ad)
      if (!e.firstChild && tag !== 'A') continue;
      if ((tag === 'P' || tag === 'LI') && !txt(e) && !e.querySelector('img')) continue;
      out.appendChild(e);
    }
  }

  function pageTitle() {
    var m = document.querySelector('meta[property="og:title"]');
    var t = (m && m.content) || '';
    if (!t) { var h = document.querySelector('article h1, main h1, h1'); t = h ? txt(h) : ''; }
    return (t || document.title || '').trim();
  }

  function isRtl(s) {
    var r = (s.match(/[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/g) || []).length;
    var l = (s.match(/[A-Za-z]/g) || []).length;
    return r > l;
  }

  function note(msg, rtl) {
    var d = document.createElement('div');
    st(d, 'position:fixed;left:50%;bottom:28px;transform:translateX(-50%);max-width:86vw;z-index:2147483647;background:#222;color:#fff;padding:10px 16px;border-radius:14px;font:14px/1.6 sans-serif;box-shadow:0 4px 18px rgba(0,0,0,.4)');
    d.setAttribute('dir', rtl ? 'rtl' : 'ltr');
    d.textContent = msg;
    document.documentElement.appendChild(d);
    setTimeout(function () { d.remove(); }, 2800);
  }

  function toggleReader(dark, lang) {
    var old = document.getElementById('__abtin_reader');
    if (old) { old.remove(); document.documentElement.style.overflow = old.__prevOverflow || ''; return; }
    var fa = lang !== 'en';
    var art = null;
    try { art = findArticle(); } catch (e) { art = null; }
    if (!art || txt(art).length < 200) {
      note(fa ? 'محتوای قابل‌خواندن در این صفحه پیدا نشد' : 'No readable content found on this page', fa);
      return;
    }
    if (!RDR.theme) RDR.theme = dark ? 'dark' : 'light';
    build(art, fa);
  }

  function build(art, fa) {
    var title = pageTitle();
    var body = document.createElement('div');
    clean(art, body, THEMES[RDR.theme]);
    // the page title is shown separately: drop a duplicate leading heading
    var f = body.firstElementChild;
    if (f && /^H[1-3]$/.test(f.tagName) && txt(f) && title.indexOf(txt(f).slice(0, 25)) !== -1) f.remove();
    if (txt(body).length < 150) { note(fa ? 'محتوای قابل‌خواندن در این صفحه پیدا نشد' : 'No readable content found on this page', fa); return; }

    var rtl = isRtl(txt(body).slice(0, 500));
    var th = THEMES[RDR.theme];

    var root = document.createElement('div');
    root.id = '__abtin_reader';
    root.__prevOverflow = document.documentElement.style.overflow;
    document.documentElement.style.overflow = 'hidden';
    st(root, 'all:initial;position:fixed;top:0;left:0;right:0;bottom:0;z-index:2147483647;overflow:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;background:' + th.bg + ';color:' + th.fg + ';display:block');

    var bar = document.createElement('div');
    st(bar, 'position:sticky;top:0;z-index:2;display:flex;align-items:center;gap:6px;padding:6px 10px;background:' + th.bar + ';border-bottom:1px solid ' + th.line + ';direction:ltr;font:15px sans-serif');
    function btn(label, fn, wide) {
      var b = document.createElement('button');
      b.textContent = label;
      st(b, 'all:unset;box-sizing:border-box;min-width:' + (wide ? 46 : 38) + 'px;height:34px;padding:0 10px;text-align:center;line-height:34px;border-radius:17px;background:' + th.bg + ';color:' + th.fg + ';font:600 15px/34px sans-serif;border:1px solid ' + th.line);
      b.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); fn(); });
      return b;
    }
    function rebuild() { var p = root.parentNode; if (p) { p.removeChild(root); } document.documentElement.style.overflow = root.__prevOverflow || ''; build(art, fa); }
    var spacer = document.createElement('div'); st(spacer, 'flex:1');
    bar.appendChild(btn('✕', function () { root.remove(); document.documentElement.style.overflow = root.__prevOverflow || ''; }));
    bar.appendChild(spacer);
    bar.appendChild(btn('A−', function () { RDR.size = Math.max(14, RDR.size - 2); wrapSize(); }));
    bar.appendChild(btn('A+', function () { RDR.size = Math.min(34, RDR.size + 2); wrapSize(); }));
    bar.appendChild(btn(RDR.theme === 'light' ? '☀' : RDR.theme === 'sepia' ? '☕' : '☾', function () {
      RDR.theme = RDR.theme === 'light' ? 'sepia' : RDR.theme === 'sepia' ? 'dark' : 'light';
      rebuild();
    }, true));
    root.appendChild(bar);

    var wrap = document.createElement('div');
    function wrapSize() { st(wrap, 'box-sizing:border-box;max-width:720px;margin:0 auto;padding:18px 18px 80px;font-family:Vazirmatn,"Noto Naskh Arabic","Segoe UI",Roboto,sans-serif;font-size:' + RDR.size + 'px;line-height:1.95;word-wrap:break-word;overflow-wrap:anywhere'); }
    wrapSize();
    wrap.setAttribute('dir', rtl ? 'rtl' : 'ltr');

    var h1 = document.createElement('h1');
    h1.setAttribute('dir', 'auto');
    st(h1, 'margin:.6em 0 .2em;font-size:1.55em;line-height:1.5;font-weight:800');
    h1.textContent = title;
    var site = document.createElement('div');
    st(site, 'direction:ltr;font-size:.7em;color:' + th.sub + ';margin-bottom:1.2em');
    site.textContent = location.hostname;
    wrap.appendChild(h1); wrap.appendChild(site); wrap.appendChild(body);
    root.appendChild(wrap);
    document.documentElement.appendChild(root);
  }
})();

// Keyboard: after the soft keyboard opens (viewport shrinks) make sure the focused field is visible.
// Only act when the field is really outside the visible area. The old rule (scroll whenever the field sat in the lower
// half of the screen) also fired for chat composers pinned to the bottom (Telegram / Eitaa web): the page scroll made the
// site blur the field, so the keyboard closed right after opening.
(function () {
  var kt = null;
  function isEdit(e) { return e && (e.tagName === 'INPUT' || e.tagName === 'TEXTAREA' || e.isContentEditable); }
  // fixed / sticky bars (chat composers, bottom sheets) follow the viewport: scrolling the page cannot reveal them
  function pinned(e) {
    for (var n = e; n && n.nodeType === 1 && n !== document.documentElement; n = n.parentElement) {
      var p = '';
      try { p = getComputedStyle(n).position; } catch (x) {}
      if (p === 'fixed' || p === 'sticky') return true;
    }
    return false;
  }
  function reveal() {
    clearTimeout(kt);
    kt = setTimeout(function () {
      var e = document.activeElement;
      if (!isEdit(e)) return;
      try {
        var r = e.getBoundingClientRect();
        var vh = (window.visualViewport && window.visualViewport.height) || window.innerHeight;
        if (r.bottom <= vh + 1 && r.top >= 0) return; // already visible
        if (pinned(e)) return;
        e.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'auto' });
      } catch (x) {}
    }, 300);
  }
  document.addEventListener('focusin', reveal, true);
  if (window.visualViewport) window.visualViewport.addEventListener('resize', reveal);
})();
