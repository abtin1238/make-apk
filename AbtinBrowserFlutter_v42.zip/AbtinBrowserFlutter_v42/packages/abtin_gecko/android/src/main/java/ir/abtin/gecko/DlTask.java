package ir.abtin.gecko;

import android.util.Log;

import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONObject;
import org.mozilla.geckoview.WebResponse;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicLongArray;

/**
 * One managed download: split into N byte-range segments fetched in parallel, written at their offsets into
 * "<file>.part", with pause / resume (state kept in "<file>.part.abtin") and per-segment retry.
 */
final class DlTask implements Runnable {
    static final int RUN = 0, PAUSE = 1, CANCEL = 2;
    private static final long MIN_SEG = 256 * 1024;

    final Downloads d;
    final String id, url, referer;
    final boolean priv;
    String name;
    File out, part, meta;
    long total = -1;
    boolean ranged;
    int conns;
    volatile int want = RUN;
    volatile String status = "running";
    volatile double speed;
    long[] segS, segE;
    AtomicLongArray segP;
    final AtomicLong got = new AtomicLong();
    private final List<InputStream> open = Collections.synchronizedList(new ArrayList<>());
    private final AtomicBoolean failedFlag = new AtomicBoolean(false);
    private FileChannel ch;
    private RandomAccessFile raf;
    @Nullable private InputStream firstBody;
    private volatile Thread runner;

    DlTask(Downloads d, String id, String url, @Nullable String referer, boolean priv, @Nullable String name, int conns) {
        this.d = d; this.id = id; this.url = url; this.referer = referer == null ? "" : referer; this.priv = priv;
        this.name = name == null ? "" : name; this.conns = conns;
    }

    /** Rebuilds a task from its saved state; null if there is none (or the partial file is gone). */
    @Nullable static DlTask load(Downloads d, String id, String path, int conns) {
        try {
            final File meta = new File(path + ".part.abtin");
            final File part = new File(path + ".part");
            if (!meta.exists() || !part.exists()) return null;
            final StringBuilder sb = new StringBuilder();
            try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.FileReader(meta))) {
                String ln; while ((ln = br.readLine()) != null) sb.append(ln);
            }
            final JSONObject j = new JSONObject(sb.toString());
            final DlTask t = new DlTask(d, id, j.getString("url"), j.optString("ref", ""), j.optBoolean("priv", false), j.optString("name", ""), conns);
            t.out = new File(j.getString("out"));
            t.part = part; t.meta = meta;
            t.total = j.optLong("total", -1);
            t.ranged = j.optBoolean("ranged", false);
            final JSONArray a = j.getJSONArray("s"), b = j.getJSONArray("e"), p = j.getJSONArray("p");
            t.segS = new long[a.length()]; t.segE = new long[a.length()]; t.segP = new AtomicLongArray(a.length());
            long g = 0;
            for (int i = 0; i < a.length(); i++) {
                t.segS[i] = a.getLong(i); t.segE[i] = b.getLong(i); t.segP.set(i, p.getLong(i));
                g += p.getLong(i) - t.segS[i];
            }
            t.got.set(g);
            if (!t.ranged && g > 0) return null; // a non-seekable server can't continue a half-done file
            return t;
        } catch (Throwable t) { Log.w(Engine.TAG, "dl meta", t); return null; }
    }

    void start() {
        final Thread th = new Thread(this, "abtin-dl-" + id);
        runner = th;
        th.start();
    }

    void pause() { if (want == RUN) { want = PAUSE; closeStreams(); } }
    void cancel() { want = CANCEL; closeStreams(); }

    private void closeStreams() {
        synchronized (open) { for (InputStream s : open) { try { s.close(); } catch (Throwable ignored) { } } open.clear(); }
    }

    @Override public void run() {
        try {
            if (segS == null && !probe()) return;
            transfer();
        } catch (Throwable t) {
            Log.w(Engine.TAG, "dl task", t);
            finish("failed");
        }
    }

    // ------------------------------------------------------------------ first contact

    private boolean probe() throws Exception {
        WebResponse r = d.fetchBlocking(url, referer, "bytes=0-0", priv);
        // Some CDNs refuse (or mishandle) a ranged first request: retry as a plain GET and download as one stream.
        if (r != null && r.statusCode != 206 && !(r.statusCode >= 200 && r.statusCode < 300)) {
            if (r.body != null) try { r.body.close(); } catch (Exception ignored) { }
            r = d.fetchBlocking(url, referer, null, priv);
        }
        if (r == null) { status = "failed"; d.emitTask(this); d.removeTask(this); return false; }
        final int sc = r.statusCode;
        final String disp = Downloads.header(r.headers, "content-disposition");
        final String mime = Downloads.header(r.headers, "content-type");
        if (sc >= 200 && sc < 300 && expectsMedia() && mime != null && isTextMime(mime)) {
            // a login / error / expired-link page, not the video
            if (r.body != null) try { r.body.close(); } catch (Exception ignored) { }
            status = "failed"; d.emitTask(this); d.removeTask(this); return false;
        }
        if (sc == 206) {
            final String cr = Downloads.header(r.headers, "content-range");
            try { if (cr != null && cr.contains("/")) total = Long.parseLong(cr.substring(cr.indexOf('/') + 1).trim()); } catch (Exception ignored) { }
            ranged = total > 0;
            if (r.body != null) try { r.body.close(); } catch (Exception ignored) { }
        } else if (sc >= 200 && sc < 300) {
            try { final String l = Downloads.header(r.headers, "content-length"); if (l != null) total = Long.parseLong(l.trim()); } catch (Exception ignored) { }
            ranged = false;
            firstBody = r.body;
        } else {
            if (r.body != null) try { r.body.close(); } catch (Exception ignored) { }
            status = "failed"; d.emitTask(this); d.removeTask(this); return false;
        }
        String nm = name.trim().isEmpty() ? Downloads.nameFrom(disp, r.uri == null ? url : r.uri, mime) : name;
        name = Downloads.clean(nm);
        final File dir = d.dir();
        out = freeName(dir, name);
        part = new File(out.getPath() + ".part");
        meta = new File(out.getPath() + ".part.abtin");
        name = out.getName();
        int n = 1;
        if (ranged && total >= 2 * MIN_SEG) n = (int) Math.max(1, Math.min(conns, total / MIN_SEG));
        segS = new long[n]; segE = new long[n]; segP = new AtomicLongArray(n);
        if (total > 0) {
            final long chunk = total / n;
            for (int i = 0; i < n; i++) { segS[i] = i * chunk; segE[i] = i == n - 1 ? total - 1 : (i + 1) * chunk - 1; segP.set(i, segS[i]); }
        } else { segS[0] = 0; segE[0] = Long.MAX_VALUE; segP.set(0, 0); }
        status = "running";
        d.emitTask(this);
        return true;
    }

    private boolean expectsMedia() {
        final String n = (name == null ? "" : name).toLowerCase();
        return n.matches(".*\\.(mp4|m4v|webm|mkv|mov|3gp|avi|ts|mp3|m4a|aac|ogg|oga|opus|flac|wav|weba)$");
    }

    private static boolean isTextMime(String m) {
        final String x = m.toLowerCase();
        return x.startsWith("text/") || x.contains("json") || x.contains("xml") || x.contains("html");
    }

    /** First bytes look like a web page / JSON instead of media. */
    private static boolean looksLikeText(File f) {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) {
            final byte[] b = new byte[64];
            final int n = in.read(b);
            for (int i = 0; i < n; i++) {
                final int c = b[i] & 0xff;
                if (c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == 0xEF || c == 0xBB || c == 0xBF) continue;
                return c == '<' || c == '{' || c == '[';
            }
        } catch (Throwable ignored) { }
        return false;
    }

    private static File freeName(File dir, String nm) {
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();
        File f = new File(dir, nm);
        if (!f.exists() && !new File(f.getPath() + ".part").exists()) return f;
        final int dot = nm.lastIndexOf('.');
        final String base = dot > 0 ? nm.substring(0, dot) : nm, ext = dot > 0 ? nm.substring(dot) : "";
        for (int i = 1; i < 1000; i++) {
            f = new File(dir, base + " (" + i + ")" + ext);
            if (!f.exists() && !new File(f.getPath() + ".part").exists()) return f;
        }
        return new File(dir, System.currentTimeMillis() + "_" + nm);
    }

    // ------------------------------------------------------------------ transfer

    private void transfer() throws Exception {
        raf = new RandomAccessFile(part, "rw");
        ch = raf.getChannel();
        if (total > 0 && raf.length() != total) raf.setLength(total);
        final int n = segS.length;
        final CountDownLatch latch = new CountDownLatch(n);
        final ExecutorService ex = Executors.newFixedThreadPool(n);
        status = "running";
        d.emitTask(this);
        for (int i = 0; i < n; i++) {
            final int idx = i;
            ex.execute(() -> { try { segment(idx); } catch (Throwable t) { failedFlag.set(true); } finally { latch.countDown(); } });
        }
        long lastGot = got.get(), lastT = System.currentTimeMillis(), lastSave = lastT;
        while (latch.getCount() > 0) {
            if (latch.await(300, TimeUnit.MILLISECONDS)) break;
            if (want != RUN || failedFlag.get()) { closeStreams(); break; }
            final long now = System.currentTimeMillis(), g = got.get();
            final double inst = (g - lastGot) * 1000.0 / Math.max(1, now - lastT);
            speed = speed == 0 ? inst : speed * 0.6 + inst * 0.4;
            lastGot = g; lastT = now;
            d.emitTask(this);
            if (now - lastSave > 3000) { lastSave = now; saveMeta(); }
        }
        ex.shutdownNow();
        try { latch.await(2, TimeUnit.SECONDS); } catch (InterruptedException ignored) { }
        try { ch.close(); raf.close(); } catch (Throwable ignored) { }
        speed = 0;
        if (want == CANCEL) { finish("canceled"); return; }
        if (want == PAUSE) { finish("paused"); return; }
        if (failedFlag.get()) { finish("failed"); return; }
        boolean complete = true;
        for (int i = 0; i < n; i++) if (segE[i] != Long.MAX_VALUE && segP.get(i) <= segE[i]) complete = false;
        if (!complete) { finish("failed"); return; }
        if (total < 0) total = got.get();
        if (total > 0 && part.length() != total) { finish("failed"); return; }
        if (expectsMedia() && looksLikeText(part)) { part.delete(); meta.delete(); status = "failed"; d.emitTask(this); d.removeTask(this); return; }
        if (out.exists()) //noinspection ResultOfMethodCallIgnored
            out.delete();
        if (!part.renameTo(out)) { finish("failed"); return; }
        //noinspection ResultOfMethodCallIgnored
        meta.delete();
        status = "done";
        d.emitTask(this);
        d.done(this);
    }

    private void segment(int i) throws Exception {
        final byte[] buf = new byte[256 * 1024];
        int tries = 0;
        if (!ranged) { // single plain stream: no way to resume it
            final InputStream in = firstBody != null ? firstBody : null;
            if (in == null) throw new IllegalStateException("no body");
            open.add(in);
            long pos = 0;
            try (InputStream s = in) {
                int n;
                while (want == RUN && (n = s.read(buf)) > 0) { write(buf, n, pos); pos += n; segP.set(i, pos); got.addAndGet(n); }
            } catch (java.io.IOException io) {
                if (want == RUN) throw io; // stream broke mid-way: fail (a half file must not be marked done)
            }
            return;
        }
        while (want == RUN && segP.get(i) <= segE[i]) {
            InputStream in = null;
            try {
                final long pos = segP.get(i);
                final WebResponse r = d.fetchBlocking(url, referer, "bytes=" + pos + "-" + segE[i], priv);
                if (r == null || r.body == null) throw new java.io.IOException("no response");
                if (r.statusCode != 206 && !(r.statusCode == 200 && pos == 0 && segS.length == 1)) {
                    try { r.body.close(); } catch (Exception ignored) { }
                    throw new java.io.IOException("status " + r.statusCode);
                }
                in = r.body;
                open.add(in);
                int n;
                while (want == RUN && segP.get(i) <= segE[i] && (n = in.read(buf)) > 0) {
                    final long p = segP.get(i);
                    final int w = (int) Math.min(n, segE[i] - p + 1);
                    write(buf, w, p);
                    segP.set(i, p + w);
                    got.addAndGet(w);
                    tries = 0;
                }
                if (want == RUN && segP.get(i) <= segE[i]) throw new java.io.IOException("stream ended early");
            } catch (Throwable t) {
                if (want != RUN) return;
                if (++tries > 5) throw new Exception(t);
                Log.w(Engine.TAG, "segment " + i + " retry " + tries + ": " + t);
                try { Thread.sleep(1000L * tries); } catch (InterruptedException ie) { return; }
            } finally {
                if (in != null) { open.remove(in); try { in.close(); } catch (Throwable ignored) { } }
            }
        }
    }

    private void write(byte[] b, int n, long pos) throws java.io.IOException {
        final ByteBuffer bb = ByteBuffer.wrap(b, 0, n);
        long p = pos;
        while (bb.hasRemaining()) p += ch.write(bb, p);
    }

    // ------------------------------------------------------------------ state

    void saveMeta() {
        if (meta == null || segS == null) return;
        try {
            final JSONObject j = new JSONObject();
            j.put("url", url); j.put("ref", referer); j.put("priv", priv); j.put("name", name);
            j.put("out", out.getPath()); j.put("total", total); j.put("ranged", ranged);
            final JSONArray a = new JSONArray(), b = new JSONArray(), p = new JSONArray();
            for (int i = 0; i < segS.length; i++) { a.put(segS[i]); b.put(segE[i]); p.put(segP.get(i)); }
            j.put("s", a); j.put("e", b); j.put("p", p);
            try (FileOutputStream os = new FileOutputStream(meta)) { os.write(j.toString().getBytes("UTF-8")); }
        } catch (Throwable t) { Log.w(Engine.TAG, "saveMeta", t); }
    }

    private void finish(String st) {
        speed = 0;
        try { if (ch != null) ch.close(); } catch (Throwable ignored) { }
        if ("canceled".equals(st)) {
            if (part != null) //noinspection ResultOfMethodCallIgnored
                part.delete();
            if (meta != null) //noinspection ResultOfMethodCallIgnored
                meta.delete();
        } else saveMeta();
        status = st;
        d.emitTask(this);
        d.removeTask(this);
    }
}
