package ir.abtin.gecko;

import android.content.Context;
import android.os.SystemClock;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.mozilla.geckoview.GeckoView;

import io.flutter.plugin.common.StandardMessageCodec;
import io.flutter.plugin.platform.PlatformView;
import io.flutter.plugin.platform.PlatformViewFactory;

/** Hosts the single GeckoView; tabs are swapped in/out by Engine.attach(). */
final class GeckoPlatformView implements PlatformView {
    static final String VIEW_TYPE = "abtin/geckoview";

    static final class Factory extends PlatformViewFactory {
        private final Engine engine;

        Factory(Engine engine) {
            super(StandardMessageCodec.INSTANCE);
            this.engine = engine;
        }

        @NonNull @Override
        public PlatformView create(Context context, int viewId, @Nullable Object args) {
            return new GeckoPlatformView(context, engine);
        }
    }

    private final GeckoView gv;
    private final Engine engine;

    GeckoPlatformView(Context context, Engine engine) {
        this.engine = engine;
        gv = new GeckoView(context);
        gv.setViewBackend(GeckoView.BACKEND_TEXTURE_VIEW);
        engine.view = gv;
        gv.setFocusable(true);
        gv.setFocusableInTouchMode(true);
        installFocusKeeper();
        if (engine.current != null) engine.attach(engine.current, 0);
    }

    // When the soft keyboard opens the window shrinks, Flutter re-lays out this hybrid-composition view and Android
    // can move focus away from GeckoView for a moment. That kills the page's input connection: the numeric keyboard
    // flips to the full one and closes. If focus is lost right around a resize (and no Flutter text field wants it),
    // give it straight back.
    private boolean hadFocus;
    private long lostAt, resizedAt;
    private static final long WINDOW_MS = 900;

    private void refocus() {
        if (engine.chromeEditing) return;
        gv.post(new Runnable() {
            @Override public void run() {
                if (engine.chromeEditing || gv.hasFocus()) return;
                gv.requestFocus();
            }
        });
    }

    private void installFocusKeeper() {
        gv.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean focus) {
                if (focus) { hadFocus = true; return; }
                lostAt = SystemClock.uptimeMillis();
                if (hadFocus && lostAt - resizedAt < WINDOW_MS) refocus();
            }
        });
        gv.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                if ((r - l) == (or - ol) && (b - t) == (ob - ot)) return;
                resizedAt = SystemClock.uptimeMillis();
                if (hadFocus && !gv.hasFocus() && resizedAt - lostAt < WINDOW_MS) refocus();
            }
        });
    }

    @Nullable @Override
    public View getView() { return gv; }

    @Override
    public void dispose() {
        if (engine.view == gv) {
            if (gv.getSession() != null) gv.releaseSession();
            engine.view = null;
        }
    }
}
