import 'package:flutter/material.dart';
import '../app_state.dart';
import '../engine/dns_manager.dart';
import '../services.dart';
import 'glass.dart';

/// DNS changer for the whole phone (local VPN carrying only DNS queries).
class DnsPage extends StatefulWidget {
  const DnsPage({super.key});
  @override
  State<DnsPage> createState() => _DnsPageState();
}

class _DnsPageState extends State<DnsPage> {

  void _r() { if (mounted) setState(() {}); }

  @override
  void initState() {
    super.initState();
    dnsMgr.addListener(_r);
  }

  @override
  void dispose() {
    dnsMgr.removeListener(_r);
    super.dispose();
  }

  Future<void> _add() async {
    final n = TextEditingController(), a = TextEditingController();
    final ok = await showGlassDialog<bool>(context: context, builder: (d) => AlertDialog(
      title: Text(tr('افزودن DNS', 'Add DNS')),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: n, decoration: InputDecoration(labelText: tr('نام', 'Name'))),
        const SizedBox(height: 8),
        TextField(controller: a, textDirection: TextDirection.ltr, keyboardType: TextInputType.visiblePassword, decoration: const InputDecoration(labelText: 'IPv4', hintText: '1.1.1.1, 1.0.0.1')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('ذخیره', 'Save')))],
    ));
    if (ok == true && !dnsMgr.addCustom(n.text, a.text)) _snack(tr('آدرس IPv4 معتبر وارد کنید', 'Enter a valid IPv4 address'));
  }

  void _snack(String m) => snackTop(context, m);

  Future<void> _toggle() async {
    if (dnsMgr.on || dnsMgr.busy) { await dnsMgr.disconnect(); return; }
    if (v2ray.connected || v2ray.connecting) {
      await v2ray.disconnect();
      await Future<void>.delayed(const Duration(milliseconds: 800));
      _snack(tr('v2ray قطع شد (اندروید فقط یک VPN را هم‌زمان اجازه می‌دهد)', 'v2ray stopped (Android allows one VPN at a time)'));
    }
    final e = await dnsMgr.connect();
    if (e == 'no_servers') _snack(tr('آدرس DNS معتبر وارد کنید', 'Enter a valid DNS address'));
    else if (e != null) _snack(tr('شروع اتصال ناموفق بود', 'Could not start'));
  }

  @override
  Widget build(BuildContext context) {
    final on = dnsMgr.on, busy = dnsMgr.busy && !on;
    final cs = Theme.of(context).colorScheme;
    return GlassScaffold(
      appBar: AppBar(title: Text(tr('تغییر DNS', 'DNS changer')), actions: [IconButton(tooltip: tr('افزودن DNS', 'Add DNS'), icon: const Icon(Icons.add_rounded), onPressed: _add)]),
      body: ListView(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Column(children: [
            Icon(on ? Icons.dns_rounded : Icons.dns_outlined, size: 54, color: on ? Colors.greenAccent : null),
            const SizedBox(height: 8),
            Text(on ? tr('فعال برای کل گوشی', 'Active for the whole phone') : busy ? tr('در حال اتصال…', 'Connecting…') : tr('خاموش', 'Off'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            if (dnsMgr.error.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(dnsMgr.error == 'vpn_denied' ? tr('مجوز VPN داده نشد', 'VPN permission was denied') : dnsMgr.error, style: const TextStyle(color: Colors.redAccent, fontSize: 12))),
            const SizedBox(height: 12),
            SizedBox(width: double.infinity, height: 48, child: FilledButton.icon(
              onPressed: _toggle,
              icon: Icon(on || busy ? Icons.stop_rounded : Icons.play_arrow_rounded),
              label: Text(on || busy ? tr('قطع', 'Stop') : tr('اتصال', 'Connect')),
            )),
          ]),
        ),
        if (dnsMgr.customs.isNotEmpty)
          Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 0), child: Text(tr('من', 'Mine'), style: TextStyle(fontWeight: FontWeight.bold, color: cs.primary))),
        for (final e in dnsMgr.customs)
          RadioListTile<String>(
            value: 'c:${e['n']}', groupValue: dnsMgr.selected, onChanged: (v) => dnsMgr.select(v!),
            title: Text(e['n']!),
            subtitle: Text(e['s']!.replaceAll(',', '  ·  '), textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 12)),
            secondary: IconButton(icon: const Icon(Icons.delete_outline_rounded), onPressed: () => dnsMgr.removeCustom(e['n']!)),
          ),
        Padding(padding: const EdgeInsets.fromLTRB(16, 12, 16, 0), child: Text(tr('پیش‌فرض‌ها', 'Presets'), style: TextStyle(fontWeight: FontWeight.bold, color: cs.primary))),
        for (final p in dnsPresets)
          RadioListTile<String>(
            value: p.id, groupValue: dnsMgr.selected, onChanged: (v) => dnsMgr.select(v!),
            title: Text(tr(p.fa, p.en)),
            subtitle: Text(p.servers.join('  ·  '), textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 12)),
          ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
            tr('فقط درخواست‌های DNS تمام برنامه‌ها عوض می‌شود و بقیهٔ ترافیک مستقیم می‌رود. اندروید هم‌زمان فقط یک VPN را اجازه می‌دهد، پس با روشن شدن v2ray این قطع می‌شود. اگر «DNS خصوصی» گوشی روی یک سرور مشخص تنظیم است، آن را روی خودکار یا خاموش بگذارید.',
                'Only DNS queries of every app are changed; other traffic goes direct. Android allows one VPN at a time, so v2ray and this stop each other. If the phone\'s "Private DNS" is set to a fixed host, set it to Automatic or Off.'),
            style: const TextStyle(fontSize: 11), textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 30),
      ]),
    );
  }
}
