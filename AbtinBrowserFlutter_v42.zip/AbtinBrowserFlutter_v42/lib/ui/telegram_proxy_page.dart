import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../app_state.dart';
import '../services.dart';
import 'glass.dart';

/// A Telegram proxy: MTProto (tg://proxy) or SOCKS5 (tg://socks). These are applied by the Telegram APP, not by this browser,
/// so the list only stores them and hands them over with the "Connect in Telegram" button.
class TgProxy {
  TgProxy({required this.socks, required this.server, required this.port, this.secret = '', this.user = '', this.pass = '', this.name = ''});
  final bool socks;
  final String server;
  final int port;
  final String secret, user, pass;
  String name;

  String get id => '${socks ? 's' : 'm'}|$server|$port|$secret|$user';
  String get title => name.isNotEmpty ? name : '$server:$port';

  Map<String, String> get _q => {
        'server': server,
        'port': '$port',
        if (socks && user.isNotEmpty) 'user': user,
        if (socks && pass.isNotEmpty) 'pass': pass,
        if (!socks) 'secret': secret,
      };
  Uri get tgUri => Uri(scheme: 'tg', host: socks ? 'socks' : 'proxy', queryParameters: _q);
  Uri get webUri => Uri.https('t.me', socks ? '/socks' : '/proxy', _q);

  Map<String, dynamic> toJson() => {'s': socks, 'h': server, 'p': port, 'k': secret, 'u': user, 'w': pass, 'n': name};
  static TgProxy fromJson(Map<String, dynamic> j) => TgProxy(
      socks: j['s'] == true, server: '${j['h']}', port: (j['p'] as num).toInt(), secret: '${j['k'] ?? ''}', user: '${j['u'] ?? ''}', pass: '${j['w'] ?? ''}', name: '${j['n'] ?? ''}');

  static final RegExp _link = RegExp(r'(?:tg://|https?://(?:www\.)?t\.me/)(proxy|socks)\?[^\s"<>]+', caseSensitive: false);

  /// Every tg://proxy, tg://socks, t.me/proxy and t.me/socks link found in [text].
  static List<TgProxy> parseAll(String text) {
    final out = <TgProxy>[];
    for (final m in _link.allMatches(text.replaceAll('&amp;', '&'))) {
      try {
        final q = Uri.parse(m.group(0)!).queryParameters;
        final server = (q['server'] ?? '').trim();
        final port = int.tryParse((q['port'] ?? '').trim()) ?? 0;
        final socks = m.group(1)!.toLowerCase() == 'socks';
        if (server.isEmpty || port < 1 || port > 65535) continue;
        final secret = (q['secret'] ?? '').trim();
        if (!socks && secret.isEmpty) continue;
        out.add(TgProxy(socks: socks, server: server, port: port, secret: secret, user: q['user'] ?? '', pass: q['pass'] ?? ''));
      } catch (_) {}
    }
    return out;
  }

  /// Opens the proxy in the Telegram app (tg:// first, https://t.me/... as a fallback). Returns false if nothing handled it.
  Future<bool> openInTelegram() async {
    for (final u in [tgUri, webUri]) {
      try {
        if (await launchUrl(u, mode: LaunchMode.externalApplication)) return true;
      } catch (_) {}
    }
    return false;
  }
}

class TgProxyStore extends ChangeNotifier {
  final List<TgProxy> items = [];
  bool _loaded = false;

  void load() {
    if (_loaded) return;
    _loaded = true;
    try {
      final l = jsonDecode(app.prefs.getString('tg_proxies_v1') ?? '[]') as List;
      items.addAll(l.map((e) => TgProxy.fromJson(Map<String, dynamic>.from(e as Map))));
    } catch (_) {}
  }

  void _save() {
    app.prefs.setString('tg_proxies_v1', jsonEncode(items.map((e) => e.toJson()).toList()));
    notifyListeners();
  }

  /// Adds every proxy link found in [text]; returns how many were new.
  int addText(String text) {
    load();
    var n = 0;
    for (final p in TgProxy.parseAll(text)) {
      if (items.any((x) => x.id == p.id)) continue;
      items.add(p);
      n++;
    }
    if (n > 0) _save();
    return n;
  }

  bool add(TgProxy p) {
    load();
    if (items.any((x) => x.id == p.id)) return false;
    items.add(p);
    _save();
    return true;
  }

  void remove(TgProxy p) {
    items.remove(p);
    _save();
  }

  void rename(TgProxy p, String name) {
    p.name = name;
    _save();
  }
}

final TgProxyStore tgProxies = TgProxyStore();

class TelegramProxyPage extends StatefulWidget {
  const TelegramProxyPage({super.key});
  @override
  State<TelegramProxyPage> createState() => _TelegramProxyPageState();
}

class _TelegramProxyPageState extends State<TelegramProxyPage> {
  void _r() => setState(() {});

  @override
  void initState() {
    super.initState();
    tgProxies.load();
    tgProxies.addListener(_r);
  }

  @override
  void dispose() {
    tgProxies.removeListener(_r);
    super.dispose();
  }

  void _snack(String m) => snackTop(context, m);

  Future<void> _paste() async {
    final d = await Clipboard.getData('text/plain');
    final n = tgProxies.addText(d?.text ?? '');
    _snack(n > 0 ? tr('$n پراکسی اضافه شد', '$n prox(ies) added') : tr('لینک پراکسی تلگرام در کلیپ‌بورد پیدا نشد', 'No Telegram proxy link in the clipboard'));
  }

  Future<void> _connect(TgProxy p) async {
    final ok = await p.openInTelegram();
    if (!ok && mounted) _snack(tr('تلگرام پیدا نشد. لینک را کپی کنید.', 'Telegram not found. Copy the link instead.'));
  }

  Future<void> _add() async {
    var socks = false;
    final host = TextEditingController(), port = TextEditingController(), secret = TextEditingController(), user = TextEditingController(), pass = TextEditingController(), name = TextEditingController();
    String? err;
    await showDialog<void>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: Text(tr('افزودن پراکسی تلگرام', 'Add Telegram proxy')),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              SegmentedButton<bool>(
                segments: const [ButtonSegment(value: false, label: Text('MTProto')), ButtonSegment(value: true, label: Text('SOCKS5'))],
                selected: {socks},
                onSelectionChanged: (s) => set(() => socks = s.first),
              ),
              TextField(controller: name, decoration: InputDecoration(labelText: tr('نام (اختیاری)', 'Name (optional)'))),
              TextField(controller: host, keyboardType: TextInputType.url, textDirection: TextDirection.ltr, decoration: InputDecoration(labelText: tr('سرور', 'Server'))),
              TextField(controller: port, keyboardType: TextInputType.number, textDirection: TextDirection.ltr, decoration: InputDecoration(labelText: tr('پورت', 'Port'))),
              if (!socks) TextField(controller: secret, textDirection: TextDirection.ltr, decoration: InputDecoration(labelText: tr('سکرت', 'Secret'))),
              if (socks) ...[
                TextField(controller: user, textDirection: TextDirection.ltr, decoration: InputDecoration(labelText: tr('نام کاربری (اختیاری)', 'Username (optional)'))),
                TextField(controller: pass, textDirection: TextDirection.ltr, decoration: InputDecoration(labelText: tr('رمز (اختیاری)', 'Password (optional)'))),
              ],
              if (err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err!, style: const TextStyle(color: Colors.redAccent, fontSize: 12))),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr('انصراف', 'Cancel'))),
            FilledButton(
              onPressed: () {
                final pt = int.tryParse(port.text.trim()) ?? 0;
                if (host.text.trim().isEmpty || pt < 1 || pt > 65535) return set(() => err = tr('سرور و پورت را درست وارد کنید', 'Enter a valid server and port'));
                if (!socks && secret.text.trim().isEmpty) return set(() => err = tr('سکرت لازم است', 'The secret is required'));
                final added = tgProxies.add(TgProxy(socks: socks, server: host.text.trim(), port: pt, secret: secret.text.trim(), user: user.text.trim(), pass: pass.text.trim(), name: name.text.trim()));
                Navigator.pop(ctx);
                if (!added) _snack(tr('این پراکسی از قبل هست', 'This proxy is already in the list'));
              },
              child: Text(tr('افزودن', 'Add')),
            ),
          ],
        ),
      ),
    );
  }

  Widget _card(TgProxy p) => Padding(
        padding: const EdgeInsets.fromLTRB(12, 6, 12, 6),
        child: GlassCard(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(p.socks ? Icons.lan_outlined : Icons.send_rounded, size: 20),
                const SizedBox(width: 8),
                Expanded(child: Text(p.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600))),
                Text(p.socks ? 'SOCKS5' : 'MTProto', style: const TextStyle(fontSize: 11)),
              ]),
              const SizedBox(height: 4),
              Text('${p.server}:${p.port}', textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 12)),
              const SizedBox(height: 8),
              Row(children: [
                Expanded(child: FilledButton.icon(onPressed: () => _connect(p), icon: const Icon(Icons.send_rounded, size: 18), label: Text(tr('اتصال در تلگرام', 'Connect in Telegram')))),
                IconButton(
                  tooltip: tr('کپی لینک', 'Copy link'),
                  icon: const Icon(Icons.copy_rounded, size: 20),
                  onPressed: () async { await Clipboard.setData(ClipboardData(text: p.webUri.toString())); _snack(tr('کپی شد', 'Copied')); },
                ),
                IconButton(tooltip: tr('اشتراک‌گذاری', 'Share'), icon: const Icon(Icons.ios_share_rounded, size: 20), onPressed: () => Share.share(p.webUri.toString())),
                IconButton(tooltip: tr('حذف', 'Delete'), icon: const Icon(Icons.delete_outline_rounded, size: 20), onPressed: () => tgProxies.remove(p)),
              ]),
            ]),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => GlassScaffold(
        appBar: AppBar(
          title: Text(tr('پراکسی تلگرام', 'Telegram proxy')),
          backgroundColor: Colors.transparent,
          actions: [IconButton(tooltip: tr('چسباندن لینک', 'Paste link'), icon: const Icon(Icons.content_paste_rounded), onPressed: _paste)],
        ),
        body: ListView(padding: const EdgeInsets.only(bottom: 96), children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: Text(
              tr('پراکسی MTProto و SOCKS5 را اینجا نگه دارید و با «اتصال در تلگرام» در برنامه‌ی تلگرام فعال کنید. این پراکسی‌ها فقط برای خود تلگرام هستند؛ مرورگر و VPN را تغییر نمی‌دهند.',
                  'Keep MTProto and SOCKS5 proxies here and apply them in the Telegram app with "Connect in Telegram". They only affect Telegram itself, not the browser or the VPN.'),
              style: const TextStyle(fontSize: 12),
            ),
          ),
          if (tgProxies.items.isEmpty)
            Padding(
              padding: const EdgeInsets.all(32),
              child: Center(child: Text(tr('هنوز پراکسی‌ای نیست. لینک tg://proxy یا t.me/proxy را کپی و دکمه‌ی چسباندن را بزنید، یا با + دستی اضافه کنید.', 'No proxies yet. Copy a tg://proxy or t.me/proxy link and tap paste, or add one with +.'), textAlign: TextAlign.center)),
            ),
          for (final p in tgProxies.items) _card(p),
        ]),
      ).wrapFab(_add);
}

extension on GlassScaffold {
  /// GlassScaffold has no floating button slot: stack one over it.
  Widget wrapFab(VoidCallback onTap) => Stack(children: [
        Positioned.fill(child: this),
        Positioned(
          right: 16,
          bottom: 16,
          child: Material(type: MaterialType.transparency, child: SafeArea(child: FloatingActionButton(onPressed: onTap, tooltip: 'Add', child: const Icon(Icons.add_rounded)))),
        ),
      ]);
}
