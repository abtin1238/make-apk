part of 'browser_page.dart';
// ignore_for_file: invalid_use_of_protected_member

/// Dialogs and the native -> Dart request handlers (JS dialogs, permissions, auth, pickers).
extension _Dialogs on _BrowserPageState {
  Future<dynamic> _onAsk(String method, Map<String, dynamic> a) async {
    if (!mounted) return null;
    switch (method) {
      case 'prompt': return _prompt(a);
      case 'permission': return _permission(a);
      case 'mediaPermission': return _media(a);
      case 'external': {
        final u = '${a['url']}';
        if (await _ask(tr('باز کردن در برنامهٔ دیگر؟', 'Open in another app?'), u)) {
          try { await launchUrl(Uri.parse(u), mode: LaunchMode.externalApplication); } catch (_) {}
        }
        return true;
      }
      case 'extInstallPrompt': {
        final perms = [...(a['permissions'] as List? ?? const []), ...(a['origins'] as List? ?? const [])].map((e) => '$e').toList();
        return _ask(
          '${tr('نصب', 'Install')} ${a['name']}؟',
          perms.isEmpty ? tr('این افزونه مجوز ویژه‌ای نمی‌خواهد.', 'This extension asks for no special permissions.') : '${tr('این افزونه می‌خواهد به این موارد دسترسی داشته باشد', 'This extension wants access to')}:\n${perms.take(12).join('\n')}',
        );
      }
    }
    return null;
  }

  // ---------------- basic dialogs ----------------
  /// Card shown before a page-started download begins.
  Future<void> _dlConfirm(Map<String, dynamic> e) async {
    final name = '${e['name']}';
    final size = (e['size'] as num?)?.toInt() ?? -1;
    final host = Uri.tryParse('${e['url']}')?.host ?? '';
    final sz = size < 0 ? '' : (size >= 1048576 ? '${(size / 1048576).toStringAsFixed(1)} MB' : '${(size / 1024).ceil()} KB');
    final ok = await showGlassDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Row(children: [const Icon(Icons.download_rounded, size: 22), const SizedBox(width: 10), Text(tr('دانلود فایل', 'Download file'), style: const TextStyle(fontSize: 16))]),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(name, maxLines: 3, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600)),
          if (sz.isNotEmpty || host.isNotEmpty) const SizedBox(height: 8),
          if (sz.isNotEmpty) Text(sz, style: const TextStyle(fontSize: 13)),
          if (host.isNotEmpty) Text(host, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, color: Colors.grey)),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('دانلود', 'Download'))),
        ],
      ),
    );
    await gecko.call('downloadAnswer', {'id': e['id'], 'ok': ok == true});
  }

  Future<bool> _ask(String title, String body) async {
    final r = await showGlassDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(title, style: const TextStyle(fontSize: 16)), content: Text(body, maxLines: 10, overflow: TextOverflow.ellipsis),
        actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('باشه', 'OK')))],
      ),
    );
    return r == true;
  }

  /// true = allow, false = block, null = dismissed
  Future<bool?> _permDialog(String host, String what) => showGlassDialog<bool>(
        context: context,
        builder: (d) => AlertDialog(
          title: Text(tr('درخواست دسترسی', 'Permission request'), style: const TextStyle(fontSize: 16)),
          content: Text(tr('$host می‌خواهد به $what شما دسترسی داشته باشد.', '$host wants to use your $what.')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('مسدود', 'Block'))),
            TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('اجازه', 'Allow'))),
          ],
        ),
      );

  Future<(String, String)?> _credDialog(String host, {bool onlyPassword = false}) async {
    final u = TextEditingController(), p = TextEditingController();
    final ok = await showGlassDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('ورود به $host', 'Sign in to $host'), style: const TextStyle(fontSize: 16)),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          if (!onlyPassword) TextField(controller: u, decoration: InputDecoration(labelText: tr('نام کاربری', 'Username'))),
          TextField(controller: p, obscureText: true, decoration: InputDecoration(labelText: tr('رمز عبور', 'Password'))),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('ورود', 'Sign in')))],
      ),
    );
    return ok == true ? (u.text, p.text) : null;
  }

  // ---------------- permissions ----------------
  Future<bool> _hostAllowed(String host, String key, String label) async {
    var v = app.sitePerm(host, key);
    if (v == 'ask') {
      final r = await _permDialog(host, label);
      if (r == null) return false;
      v = r ? 'allow' : 'block';
    }
    return v == 'allow';
  }

  Future<String?> _permission(Map<String, dynamic> a) async {
    final host = '${a['host']}';
    final kind = '${a['kind']}';
    final key = kind == 'geolocation' ? 'geolocation' : 'storage';
    final label = kind == 'geolocation' ? tr('موقعیت مکانی', 'location') : tr('کوکی‌های شخص ثالث', 'third-party cookies');
    var v = app.sitePerm(host, key);
    if (v == 'ask') {
      final r = await _permDialog(host, label);
      if (r == null) return null;
      v = r ? 'allow' : 'block';
    }
    return v;
  }

  Future<Map<String, dynamic>?> _media(Map<String, dynamic> a) async {
    final host = '${a['host']}';
    var video = false, audio = false;
    if (a['video'] == true) video = await _hostAllowed(host, 'camera', tr('دوربین', 'camera'));
    if (a['audio'] == true) audio = await _hostAllowed(host, 'microphone', tr('میکروفون', 'microphone'));
    if (!video && !audio) return null;
    return {'video': video, 'audio': audio};
  }

  // ---------------- JS dialogs / prompts ----------------
  Future<dynamic> _prompt(Map<String, dynamic> a) async {
    final kind = '${a['kind']}';
    final title = a['title'] as String?;
    final msg = a['message'] as String? ?? '';
    switch (kind) {
      case 'alert':
        await showGlassDialog<void>(context: context, builder: (d) => AlertDialog(title: title == null || title.isEmpty ? null : Text(title, style: const TextStyle(fontSize: 16)), content: Text(msg), actions: [TextButton(onPressed: () => Navigator.pop(d), child: Text(tr('باشه', 'OK')))]));
        return true;
      case 'confirm':
        return _ask(title == null || title.isEmpty ? tr('تأیید', 'Confirm') : title, msg);
      case 'beforeUnload':
        return _ask(tr('ترک این صفحه؟', 'Leave this page?'), tr('تغییرات ذخیره‌نشده ممکن است از بین برود.', 'Changes you made may not be saved.'));
      case 'repost':
        return _ask(tr('ارسال مجدد اطلاعات؟', 'Resend data?'), tr('برای نمایش این صفحه باید اطلاعات فرم دوباره ارسال شود.', 'Showing this page requires resending form data.'));
      case 'text': {
        final ctl = TextEditingController(text: '${a['default'] ?? ''}');
        final ok = await showGlassDialog<bool>(
          context: context,
          builder: (d) => AlertDialog(
            title: Text(msg.isEmpty ? (title ?? '') : msg), content: TextField(controller: ctl, autofocus: true),
            actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('باشه', 'OK')))],
          ),
        );
        return ok == true ? ctl.text : null;
      }
      case 'auth': {
        final r = await _credDialog('${a['host'] ?? ''}', onlyPassword: a['onlyPassword'] == true);
        return r == null ? null : {'user': r.$1, 'pass': r.$2};
      }
      case 'choice':
        return _choiceDialog(a);
    }
    return null;
  }

  Future<List<String>?> _choiceDialog(Map<String, dynamic> a) {
    final items = ((a['choices'] as List?) ?? const []).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    final multi = a['multiple'] == true;
    final sel = <String>{for (final i in items) if (i['selected'] == true) '${i['id']}'};
    final heading = '${a['title'] ?? a['message'] ?? ''}';
    return showGlassDialog<List<String>>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, set) => AlertDialog(
          title: heading.isEmpty ? null : Text(heading, style: const TextStyle(fontSize: 16)),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView(shrinkWrap: true, children: [
              for (final i in items)
                if (i['separator'] == true)
                  const Divider()
                else if (i['disabled'] == true)
                  Padding(
                    padding: EdgeInsetsDirectional.only(start: 16.0 + 12.0 * ((i['depth'] as num?)?.toInt() ?? 0), top: 8, bottom: 4),
                    child: Text('${i['label']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  )
                else if (multi)
                  CheckboxListTile(
                    dense: true, value: sel.contains('${i['id']}'), title: Text('${i['label']}'),
                    onChanged: (v) => set(() { if (v == true) { sel.add('${i['id']}'); } else { sel.remove('${i['id']}'); } }),
                  )
                else
                  ListTile(dense: true, selected: sel.contains('${i['id']}'), title: Text('${i['label']}'), onTap: () => Navigator.pop(d, ['${i['id']}'])),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(d), child: Text(tr('لغو', 'Cancel'))),
            if (multi) TextButton(onPressed: () => Navigator.pop(d, sel.toList()), child: Text(tr('باشه', 'OK'))),
          ],
        ),
      ),
    );
  }
}
