import 'app_proxy.dart';
import 'dart:async';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import '../models.dart';
import '../services.dart';

abstract class BrowserApi {
  List<BrowserTab> get tabs;
  BrowserTab get current;
  BrowserTab openTab(String url, {bool active = true, bool private = false, bool pwa = false});
  void closeTab(BrowserTab t);
  void selectTab(BrowserTab t);
  void navigate(BrowserTab t, String url);
  void toast(String msg);
}

List<String> _strs(dynamic v) => v is List ? v.map((e) => '$e').toList() : <String>[];

/// A real Firefox WebExtension installed in GeckoView.
class ExtInfo {
  ExtInfo(Map<String, dynamic> m)
      : id = '${m['id']}',
        name = '${m['name'] ?? m['id']}',
        description = '${m['description'] ?? ''}',
        version = '${m['version'] ?? ''}',
        enabled = m['enabled'] == true,
        privateAllowed = m['privateAllowed'] == true,
        optionsUrl = m['optionsUrl'] as String?,
        homepage = m['homepage'] as String?,
        amoUrl = m['amoUrl'] as String?,
        creator = m['creator'] as String?,
        permissions = _strs(m['permissions']),
        origins = _strs(m['origins']),
        icon = m['icon'] is Uint8List ? m['icon'] as Uint8List : null,
        hasAction = m['action'] is Map,
        badge = m['action'] is Map ? '${(m['action'] as Map)['badge'] ?? ''}' : '',
        actionTitle = m['action'] is Map ? '${(m['action'] as Map)['title'] ?? ''}' : '';
  final String id, name, description, version, badge, actionTitle;
  final bool enabled, privateAllowed, hasAction;
  final String? optionsUrl, homepage, amoUrl, creator;
  final List<String> permissions, origins;
  final Uint8List? icon;
}

class CatalogItem {
  const CatalogItem(this.name, this.fa, this.en, this.category, this.slug, [this.chromeId]);
  final String name, fa, en, category, slug;
  final String? chromeId;
}

/// Curated Mozilla (AMO) slugs. Anything else can be found with the AMO search box.
const catalog = <CatalogItem>[
  CatalogItem('uBlock Origin', 'مسدودکنندهٔ تبلیغات و ردیاب‌ها', 'Ad and tracker blocker', 'privacy', 'ublock-origin', 'cjpalhdlnbpafiamejdnhcphjbkeiagm'),
  CatalogItem('Privacy Badger', 'مسدودسازی ردیاب‌های نامرئی', 'Blocks invisible trackers', 'privacy', 'privacy-badger17', 'pkehgijcmpdhfbdbbnkijodmdjhbjlgp'),
  CatalogItem('Decentraleyes', 'محافظت در برابر ردیابی CDN', 'Local CDN emulation', 'privacy', 'decentraleyes', 'ldpochfccmkkmhdbclfhpagapcfdljkj'),
  CatalogItem('ClearURLs', 'حذف پارامترهای ردیابی از لینک‌ها', 'Strips tracking parameters from links', 'privacy', 'clearurls'),
  CatalogItem('NoScript', 'کنترل اسکریپت‌ها', 'Script control', 'security', 'noscript'),
  CatalogItem('Bitwarden', 'مدیریت رمز عبور', 'Password manager', 'security', 'bitwarden-password-manager', 'nngceckbapebfimnlniiiahkandclblb'),
  CatalogItem('Dark Reader', 'حالت تاریک برای همهٔ وب‌سایت‌ها', 'Dark mode for every website', 'appearance', 'darkreader', 'eimadpbcbfnmbkopoojfekhnkhdbieeh'),
  CatalogItem('Stylus', 'مدیریت استایل‌های سفارشی', 'Custom user styles', 'appearance', 'styl-us', 'clngdbkpkpeebahjckkjfobafhncgmne'),
  CatalogItem('Tampermonkey', 'اسکریپت‌های کاربر', 'Userscript manager', 'tools', 'tampermonkey', 'dhdgffkkebhmkfjojejmpbldmpobfkfo'),
  CatalogItem('Violentmonkey', 'مدیریت اسکریپت‌های کاربر (متن‌باز)', 'Open-source userscript manager', 'tools', 'violentmonkey', 'jinjaccalgkegednnccohejagnlnfdag'),
  CatalogItem('SponsorBlock', 'رد کردن بخش‌های اسپانسری یوتیوب', 'Skip YouTube sponsor segments', 'tools', 'sponsorblock', 'mnjggcdmjocbbbhaepdhchncahnbgone'),
  CatalogItem('Return YouTube Dislike', 'نمایش دیس‌لایک یوتیوب', 'Shows YouTube dislikes', 'tools', 'return-youtube-dislikes'),
];

class AmoItem {
  AmoItem(this.name, this.slug, this.summary, this.iconUrl, this.users, this.installUrl);
  final String name, slug, summary, iconUrl, installUrl;
  final int users;
}

class ExtensionManager extends ChangeNotifier {
  List<ExtInfo> list = [];
  BrowserApi? bridge;
  final Dio _dio = AppProxy.dio();
  Timer? _t;

  Future<void> load() async => refresh();

  final Map<String, String> _amoIcons = {};
  final Map<String, Future<String>> _amoIconJobs = {};

  /// Icon URL from addons.mozilla.org for an add-on whose manifest gave no usable icon ('' when unknown).
  Future<String> amoIconUrl(ExtInfo e) {
    final c = _amoIcons[e.id];
    if (c != null) return Future.value(c);
    return _amoIconJobs.putIfAbsent(e.id, () async {
      var url = '';
      try {
        final r = await _dio.get<dynamic>(
          'https://addons.mozilla.org/api/v5/addons/addon/${Uri.encodeComponent(e.id)}/',
          queryParameters: {'lang': 'en-US'},
          options: Options(receiveTimeout: const Duration(seconds: 8), sendTimeout: const Duration(seconds: 8)),
        );
        if (r.data is Map) url = '${(r.data as Map)['icon_url'] ?? ''}';
      } catch (_) {}
      if (url.isNotEmpty) _amoIcons[e.id] = url; else _amoIconJobs.remove(e.id);
      return url;
    });
  }

  /// Debounced re-read of the extension list from the engine.
  void refresh() {
    _t?.cancel();
    _t = Timer(const Duration(milliseconds: 120), () async {
      final raw = await gecko.extList();
      list = raw.map(ExtInfo.new).toList()..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
      notifyListeners();
    });
  }

  /// Returns null on success, otherwise an error text.
  Future<String?> installUrl(String url) async {
    final r = await gecko.call<Map<dynamic, dynamic>>('extInstall', {'url': url.trim()});
    refresh();
    if (r == null) return 'engine';
    return r['ok'] == true ? null : '${r['error'] ?? 'error'}';
  }

  Future<String?> installFile(String path) async {
    final r = await gecko.call<Map<dynamic, dynamic>>('extInstallFile', {'path': path});
    refresh();
    if (r == null) return 'engine';
    return r['ok'] == true ? null : '${r['error'] ?? 'error'}';
  }

  Future<String?> installCatalog(CatalogItem c) => installUrl('https://addons.mozilla.org/firefox/downloads/latest/${c.slug}/latest.xpi');

  Future<void> remove(ExtInfo e) async { await gecko.call('extRemove', {'id': e.id}); refresh(); }
  Future<void> setEnabled(ExtInfo e, bool on) async { await gecko.call('extEnable', {'id': e.id, 'enabled': on}); refresh(); }
  Future<void> setPrivate(ExtInfo e, bool on) async { await gecko.call('extPrivate', {'id': e.id, 'allowed': on}); refresh(); }
  Future<void> update(ExtInfo e) async { await gecko.call('extUpdate', {'id': e.id}); refresh(); }
  Future<bool> openOptions(ExtInfo e) async => (await gecko.call<bool>('extOptions', {'id': e.id})) == true;
  Future<bool> clickAction(ExtInfo e) async => (await gecko.call<bool>('extAction', {'id': e.id})) == true;

  /// Chrome Web Store / Edge Add-ons link (or bare 32-letter id) -> the Firefox build of the same extension.
  /// Chrome packages (.crx) cannot run on Gecko (unsigned, MV3), so the Mozilla-signed equivalent is installed instead.
  /// Returns null when nothing matching is found.
  Future<AmoItem?> resolveChrome(String input) async {
    final m = RegExp(r'[a-p]{32}').firstMatch(input);
    if (m == null) return null;
    final id = m.group(0)!;
    final known = catalog.where((c) => c.chromeId == id).firstOrNull;
    if (known != null) {
      return AmoItem(known.name, known.slug, '', '', 0, 'https://addons.mozilla.org/firefox/downloads/latest/${known.slug}/latest.xpi');
    }
    try {
      final r = await _dio.get<String>('https://chromewebstore.google.com/detail/$id?hl=en',
          options: Options(responseType: ResponseType.plain, receiveTimeout: const Duration(seconds: 8), headers: {'Accept-Language': 'en'}));
      final t = RegExp(r'<title>([^<]+)</title>', caseSensitive: false).firstMatch(r.data ?? '')?.group(1);
      if (t == null) return null;
      final name = t.replaceAll(RegExp(r'\s*[-–|]\s*Chrome Web Store.*$'), '').trim();
      if (name.isEmpty) return null;
      final res = await searchAmo(name);
      if (res.isEmpty) return null;
      final exact = res.where((x) => x.name.toLowerCase() == name.toLowerCase()).firstOrNull;
      return exact ?? res.first;
    } catch (_) {
      return null;
    }
  }

  /// addons.mozilla.org search (Android-compatible add-ons only).
  Future<List<AmoItem>> searchAmo(String q) async {
    final r = await _dio.get<dynamic>(
      'https://addons.mozilla.org/api/v5/addons/search/',
      queryParameters: {'app': 'android', 'type': 'extension', 'sort': 'users', 'page_size': 20, 'lang': 'en-US', 'q': q},
      options: Options(receiveTimeout: const Duration(seconds: 8), sendTimeout: const Duration(seconds: 8)),
    );
    final res = (r.data is Map ? (r.data as Map)['results'] : null) as List? ?? const [];
    final out = <AmoItem>[];
    for (final x in res) {
      if (x is! Map) continue;
      final cur = x['current_version'];
      final file = cur is Map ? cur['file'] : null;
      final url = file is Map ? '${file['url'] ?? ''}' : '';
      final slug = '${x['slug'] ?? ''}';
      if (slug.isEmpty) continue;
      final name = x['name'];
      final summary = x['summary'];
      out.add(AmoItem(
        name is Map ? '${name.values.first}' : '$name',
        slug,
        summary is Map ? '${summary.values.first}' : '${summary ?? ''}',
        '${x['icon_url'] ?? ''}',
        (x['average_daily_users'] as num?)?.toInt() ?? 0,
        url.isNotEmpty ? url : 'https://addons.mozilla.org/firefox/downloads/latest/$slug/latest.xpi',
      ));
    }
    return out;
  }
}
