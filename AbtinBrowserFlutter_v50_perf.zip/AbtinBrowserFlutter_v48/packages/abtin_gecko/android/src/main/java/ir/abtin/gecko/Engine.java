package ir.abtin.gecko;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONException;
import org.json.JSONObject;
import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.BasicSelectionActionDelegate;
import org.mozilla.geckoview.ContentBlocking;
import org.mozilla.geckoview.GeckoPreferenceController;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.GeckoViewPrintDocumentAdapter;
import org.mozilla.geckoview.StorageController;
import org.mozilla.geckoview.WebExtension;
import org.mozilla.geckoview.WebRequestError;
import org.mozilla.geckoview.WebResponse;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import android.util.Base64;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

/** Owns the GeckoRuntime, all tabs, and the single GeckoView that shows the current tab. */
final class Engine {
    static final String TAG = "AbtinGecko";
    static Engine I;

    interface Reply { void on(Object value); }

    final Context app;
    final Handler main = new Handler(Looper.getMainLooper());
    MethodChannel channel;
    io.flutter.plugin.common.EventChannel.EventSink sink;
    Activity activity;
    volatile boolean dlAsk = true;
    static final int REQ_GECKO_ACTIVITY = 0x4A13;
    static final int REQ_NOTIF = 0x4A14;
    DlNotif dlNotif;
    GeckoResult<Intent> pendingActivity;

    GeckoRuntime runtime;
    Logins logins;
    volatile boolean savePasswords = true;
    GeckoView view;
    volatile boolean appForeground = true;
    volatile long pausedAt;
    volatile boolean chromeEditing; // a Flutter text field (address / find bar) owns the keyboard
    Tab current;
    final Map<Integer, Tab> tabs = new HashMap<>();
    final Map<GeckoSession, Tab> bySession = new HashMap<>();
    final Set<String> visited = new HashSet<>();
    int nextNativeId = 1_000_000;

    // settings mirrored from Dart
    String lang = "fa";
    boolean dark = true;
    int accent = 0xFF3977F6;
    boolean blockPopups = true;
    boolean suspendBackgroundMedia = true;
    String uaOverride = "";
    boolean jsEnabled = true;
    String downloadDir = "";
    String defaultDownloadDir = "";
    String userDownloadDir = "";
    final Map<String, Object> lastApplied = new HashMap<>();
    final java.util.concurrent.ExecutorService bg = java.util.concurrent.Executors.newSingleThreadExecutor();
    /** http(s) link that launched / re-entered the app (other app, pinned shortcut). Dart pulls it with "takeUrl". */
    String pendingUrl;
    /** True when the pending link came from an "installed web app" (PWA) shortcut: Dart shows it without browser chrome. */
    boolean pendingPwa;

    Prompts prompts;
    Downloads downloads;
    Extensions extensions;
    final SmsOtp smsOtp = new SmsOtp(this);

    Engine(Context app) {
        this.app = app.getApplicationContext();
        I = this;
    }

    /** The shared engine; created on demand when an installed web app (PwaActivity) starts the process without the Flutter UI. */
    static synchronized Engine get(Context c) {
        return I != null ? I : new Engine(c);
    }

    /** Foreground activity of an installed web app (own task), or null. Dialogs and pickers must appear there, not in the browser. */
    volatile Activity pwaActivity;

    Activity act() { final Activity p = pwaActivity; return p != null ? p : activity; }

    /** Starts Gecko with defaults when no Flutter UI did it yet (the browser's own init later only applies what differs). */
    void ensureRuntime() {
        if (runtime != null) return;
        final Map<String, Object> a = new HashMap<>();
        a.put("lang", "fa".equals(Locale.getDefault().getLanguage()) ? "fa" : "en");
        init(a);
    }

    // ------------------------------------------------------------------ events / dart calls

    void emit(final Map<String, Object> ev) {
        main.post(() -> { if (sink != null) sink.success(ev); });
    }

    static Map<String, Object> ev(String type, int tab) {
        final Map<String, Object> m = new HashMap<>();
        m.put("t", type);
        m.put("tab", tab);
        return m;
    }

    void ask(String method, Map<String, Object> args, final Reply reply) {
        main.post(() -> {
            if (channel == null) { reply.on(null); return; }
            channel.invokeMethod(method, args, new MethodChannel.Result() {
                @Override public void success(@Nullable Object result) { reply.on(result); }
                @Override public void error(@NonNull String code, @Nullable String msg, @Nullable Object details) { reply.on(null); }
                @Override public void notImplemented() { reply.on(null); }
            });
        });
    }

    // ------------------------------------------------------------------ runtime

    void init(Map<String, Object> a) {
        if (runtime != null) {
            if (visited.isEmpty() && a.get("visited") instanceof List) for (Object o : (List<?>) a.get("visited")) visited.add(String.valueOf(o));
            apply(a);
            return;
        }
        lang = str(a, "lang", "fa");
        defaultDownloadDir = str(a, "downloadDir", "");
        downloadDir = defaultDownloadDir;
        final ContentBlocking.Settings.Builder cb = new ContentBlocking.Settings.Builder()
                .antiTracking(ContentBlocking.AntiTracking.DEFAULT | ContentBlocking.AntiTracking.STP)
                .safeBrowsing(ContentBlocking.SafeBrowsing.DEFAULT)
                .cookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
                .cookieBehaviorPrivateMode(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
                .enhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.DEFAULT);
        final GeckoRuntimeSettings rs = new GeckoRuntimeSettings.Builder()
                .contentBlocking(cb.build())
                .remoteDebuggingEnabled(false)
                .aboutConfigEnabled(false)
                .consoleOutput(false)
                .javaScriptEnabled(true)
                .loginAutofillEnabled(bool(a, "savePw", true))
                .build();
        savePasswords = bool(a, "savePw", true);
        runtime = GeckoRuntime.create(app, rs);
        logins = new Logins(app);
        runtime.setAutocompleteStorageDelegate(logins);
        try { GeckoPreferenceController.setGeckoPref("network.prefetch-next", Boolean.FALSE, GeckoPreferenceController.PREF_BRANCH_USER); } catch (Throwable ignored) { }
        // Faster page loads: more parallel connections, DNS cache, no request pacing, predictor/preconnect on.
        try {
            final int ub = GeckoPreferenceController.PREF_BRANCH_USER;
            GeckoPreferenceController.setGeckoPref("network.http.max-connections", Integer.valueOf(512), ub);
            GeckoPreferenceController.setGeckoPref("network.http.max-persistent-connections-per-server", Integer.valueOf(10), ub);
            GeckoPreferenceController.setGeckoPref("network.http.pacing.requests.enabled", Boolean.FALSE, ub);
            GeckoPreferenceController.setGeckoPref("network.dnsCacheEntries", Integer.valueOf(800), ub);
            GeckoPreferenceController.setGeckoPref("network.dnsCacheExpiration", Integer.valueOf(3600), ub);
            GeckoPreferenceController.setGeckoPref("network.dns.disablePrefetch", Boolean.FALSE, ub);
            GeckoPreferenceController.setGeckoPref("network.predictor.enabled", Boolean.TRUE, ub);
            GeckoPreferenceController.setGeckoPref("network.http.speculative-parallel-limit", Integer.valueOf(6), ub);
            GeckoPreferenceController.setGeckoPref("nglayout.initialpaint.delay", Integer.valueOf(0), ub);
            // Bigger socket / read buffers: faster uploads and large transfers on fast links.
            GeckoPreferenceController.setGeckoPref("network.tcp.sendbuffer", Integer.valueOf(524288), ub);
            GeckoPreferenceController.setGeckoPref("network.buffer.cache.size", Integer.valueOf(262144), ub);
            GeckoPreferenceController.setGeckoPref("network.buffer.cache.count", Integer.valueOf(64), ub);
            // Faster repeat visits / handshakes.
            GeckoPreferenceController.setGeckoPref("network.ssl_tokens_cache_enabled", Boolean.TRUE, ub);
            GeckoPreferenceController.setGeckoPref("security.tls.enable_0rtt_data", Boolean.TRUE, ub);
            GeckoPreferenceController.setGeckoPref("network.early-hints.enabled", Boolean.TRUE, ub);
            GeckoPreferenceController.setGeckoPref("network.early-hints.preconnect.enabled", Boolean.TRUE, ub);
            GeckoPreferenceController.setGeckoPref("network.http.rcwn.enabled", Boolean.TRUE, ub);
            GeckoPreferenceController.setGeckoPref("network.preload", Boolean.TRUE, ub);
            // Larger caches (disk 512 MB, memory 64 MB) and cached JS bytecode.
            GeckoPreferenceController.setGeckoPref("browser.cache.disk.smart_size.enabled", Boolean.FALSE, ub);
            GeckoPreferenceController.setGeckoPref("browser.cache.disk.capacity", Integer.valueOf(262144), ub);
            GeckoPreferenceController.setGeckoPref("browser.cache.memory.capacity", Integer.valueOf(32768), ub);
            GeckoPreferenceController.setGeckoPref("dom.script_loader.bytecode_cache.enabled", Boolean.TRUE, ub);
            GeckoPreferenceController.setGeckoPref("image.mem.decode_bytes_at_a_time", Integer.valueOf(131072), ub);
        } catch (Throwable ignored) { }
        // WebAuthn / passkeys (fingerprint, screen lock): Gecko hands us a PendingIntent from Google Play
        // Services FIDO2 and expects us to launch it and return the result. Without this delegate the
        // passkey step silently does nothing.
        runtime.setActivityDelegate(pi -> {
            final GeckoResult<Intent> result = new GeckoResult<>();
            Log.i(TAG, "activityDelegate: launching " + pi);
            final Activity fa = act();
            if (fa == null) { result.completeExceptionally(new IllegalStateException("no activity")); return result; }
            try {
                pendingActivity = result;
                fa.startIntentSenderForResult(pi.getIntentSender(), REQ_GECKO_ACTIVITY, null, 0, 0, 0);
            } catch (Exception e) {
                pendingActivity = null;
                Log.e(TAG, "activityDelegate failed", e);
                final Map<String, Object> m = ev("passkey", 0); m.put("err", String.valueOf(e)); emit(m);
                result.completeExceptionally(e);
            }
            return result;
        });
        prompts = new Prompts(this);
        downloads = new Downloads(this);
        dlNotif = new DlNotif(this);
        extensions = new Extensions(this);
        final List<?> vis = a.get("visited") instanceof List ? (List<?>) a.get("visited") : null;
        if (vis != null) for (Object o : vis) visited.add(String.valueOf(o));
        apply(a);
        try { extensions.start(); } catch (Throwable t) { Log.e(TAG, "extensions.start failed", t); }
        smsOtp.refresh();
    }

    private void pref(String k, Object v) {
        try { GeckoPreferenceController.setGeckoPref(k, v, GeckoPreferenceController.PREF_BRANCH_USER); } catch (Throwable ignored) { }
    }

    boolean lowEnd() {
        try {
            final android.app.ActivityManager am = (android.app.ActivityManager) app.getSystemService(Context.ACTIVITY_SERVICE);
            final android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            return am.isLowRamDevice() || mi.totalMem < 4600L * 1024 * 1024;
        } catch (Throwable t) { return false; }
    }

    @SuppressWarnings("unchecked")
    void apply(Map<String, Object> a0) {
        if (runtime == null) return;
        // Only touch what actually changed: re-applying every pref on each settings tweak re-evaluates all open pages.
        final Map<String, Object> a = new HashMap<>();
        for (Map.Entry<String, Object> en : a0.entrySet()) {
            final Object old = lastApplied.get(en.getKey());
            if (old == null || !old.equals(en.getValue())) { a.put(en.getKey(), en.getValue()); lastApplied.put(en.getKey(), en.getValue()); }
        }
        if (a.isEmpty()) return;
        lang = str(a, "lang", lang);
        if (a.containsKey("dark")) dark = bool(a, "dark", dark);
        if (a.containsKey("accent")) accent = ((Number) a.get("accent")).intValue();
        if (a.containsKey("popups")) blockPopups = bool(a, "popups", true);
        if (a.containsKey("smsOtp")) smsOtp.setEnabled(bool(a, "smsOtp", true));
        if (a.containsKey("sleeping")) suspendBackgroundMedia = bool(a, "sleeping", true);
        if (a.containsKey("ua")) uaOverride = str(a, "ua", "");
        if (a.containsKey("downloadDir") && !str(a, "downloadDir", "").isEmpty()) defaultDownloadDir = str(a, "downloadDir", defaultDownloadDir);
        if (a.containsKey("userDownloadDir")) userDownloadDir = str(a, "userDownloadDir", "");
        if (a.containsKey("downloadDir") || a.containsKey("userDownloadDir")) {
            downloadDir = userDownloadDir.isEmpty() ? defaultDownloadDir : userDownloadDir;
            if (!userDownloadDir.isEmpty()) { try { new java.io.File(userDownloadDir).mkdirs(); } catch (Throwable ignored) { } }
        }
        final GeckoRuntimeSettings s = runtime.getSettings();
        if (a.containsKey("js")) { jsEnabled = bool(a, "js", true); s.setJavaScriptEnabled(jsEnabled); }
        if (a.containsKey("savePw")) { savePasswords = bool(a, "savePw", true); try { s.setLoginAutofillEnabled(savePasswords); } catch (Throwable ignored) { } }
        if (a.containsKey("lite")) {
            // Slow-connection mode: no autoplay at all (feeds such as Instagram preload and play every video you scroll past),
            // fewer parallel / speculative connections (each one costs a handshake through the proxy / VPN).
            final boolean lite = bool(a, "lite", false);
            try {
                final int ub = GeckoPreferenceController.PREF_BRANCH_USER;
                GeckoPreferenceController.setGeckoPref("media.autoplay.default", Integer.valueOf(lite ? 5 : 0), ub);
                GeckoPreferenceController.setGeckoPref("media.autoplay.blocking_policy", Integer.valueOf(lite ? 1 : 0), ub);
                GeckoPreferenceController.setGeckoPref("network.http.speculative-parallel-limit", Integer.valueOf(lite ? 0 : 6), ub);
                GeckoPreferenceController.setGeckoPref("network.http.max-persistent-connections-per-server", Integer.valueOf(lite ? 6 : 10), ub);
            } catch (Throwable ignored) { }
        }
        if (a.containsKey("perf")) {
            final boolean p = bool(a, "perf", false);
            pref("browser.cache.memory.capacity", p ? 8192 : 32768);
            pref("browser.cache.disk.capacity", p ? 131072 : 262144);
            pref("browser.sessionhistory.max_total_viewers", p ? 0 : -1);
            pref("image.mem.max_decoded_image_kb", p ? 51200 : 512000);
            pref("image.mem.surfacecache.max_size_kb", p ? 32768 : 1048576);
            pref("image.mem.decode_bytes_at_a_time", p ? 32768 : 131072);
            pref("media.cache_size", p ? 16384 : 512000);
            pref("network.http.max-connections", p ? 256 : 512);
            pref("network.buffer.cache.count", p ? 24 : 64);
            pref("network.predictor.enabled", !p);
            pref("toolkit.cosmeticAnimations.enabled", !p);
            pref("ui.prefersReducedMotion", p ? 1 : 0);
            if (p) { pref("dom.ipc.processCount", 1); pref("dom.ipc.keepProcessesAlive.web", 0); }
        }
        if (a.containsKey("gpc")) s.setGlobalPrivacyControl(bool(a, "gpc", true));
        if (a.containsKey("fingerprint") || a.containsKey("track")) {
            final boolean fp = bool(a, "fingerprint", false) || "strict".equals(str(a, "track", "standard"));
            s.setFingerprintingProtection(fp);
            s.setFingerprintingProtectionPrivateBrowsing(fp);
        }
        if (a.containsKey("httpsOnly")) {
            s.setAllowInsecureConnections(bool(a, "httpsOnly", true) ? GeckoRuntimeSettings.HTTPS_ONLY : GeckoRuntimeSettings.ALLOW_ALL);
        }
        if (a.containsKey("textZoom")) {
            s.setAutomaticFontSizeAdjustment(false);
            s.setFontSizeFactor(((Number) a.get("textZoom")).floatValue() / 100f);
        }
        if (a.containsKey("theme")) {
            final String th = str(a, "theme", "dark");
            int scheme = GeckoRuntimeSettings.COLOR_SCHEME_SYSTEM;
            if ("light".equals(th)) scheme = GeckoRuntimeSettings.COLOR_SCHEME_LIGHT;
            else if ("dark".equals(th)) scheme = GeckoRuntimeSettings.COLOR_SCHEME_DARK;
            s.setPreferredColorScheme(scheme);
        }
        if (a.containsKey("doh") || a.containsKey("dohCustom")) {
            // The browser-only secure DNS (DoH) is removed: with TRR mode 2 every lookup waited for the DoH timeout before
            // falling back, which made pages look frozen. Mode 5 = TRR explicitly off: the browser uses the system resolver
            // (which the system-wide DNS / v2ray tunnel of this app can still redirect).
            final int branch = GeckoPreferenceController.PREF_BRANCH_USER;
            try {
                GeckoPreferenceController.setGeckoPref("network.trr.mode", Integer.valueOf(5), branch);
                GeckoPreferenceController.setGeckoPref("network.trr.uri", "", branch);
                GeckoPreferenceController.setGeckoPref("network.trr.custom_uri", "", branch);
                GeckoPreferenceController.setGeckoPref("network.trr.default_provider_uri", "", branch);
                GeckoPreferenceController.setGeckoPref("network.trr.bootstrapAddr", "", branch);
            } catch (Throwable t) { Log.e(TAG, "doh prefs", t); }
        }
        if (a.containsKey("netCompat")) {
            // HTTP/3 (QUIC, UDP) and IPv6 are often dropped by VPN apps: Meta sites (Instagram...) then hang instead of falling back.
            final boolean compat = bool(a, "netCompat", true);
            try {
                GeckoPreferenceController.setGeckoPref("network.http.http3.enable", Boolean.valueOf(!compat), GeckoPreferenceController.PREF_BRANCH_USER);
                GeckoPreferenceController.setGeckoPref("network.dns.disableIPv6", Boolean.valueOf(compat), GeckoPreferenceController.PREF_BRANCH_USER);
            } catch (Throwable t) { Log.e(TAG, "netCompat prefs", t); }
        }
        if (a.containsKey("proxyPort")) {
            // v2ray tunnel up: the browser (same package, excluded from the VPN) goes through the core's local SOCKS inbound.
            final Object po = a.get("proxyPort");
            final int port = po instanceof Number ? ((Number) po).intValue() : 0;
            final int ub = GeckoPreferenceController.PREF_BRANCH_USER;
            try {
                if (port > 0) {
                    GeckoPreferenceController.setGeckoPref("network.proxy.socks", "127.0.0.1", ub);
                    GeckoPreferenceController.setGeckoPref("network.proxy.socks_port", Integer.valueOf(port), ub);
                    GeckoPreferenceController.setGeckoPref("network.proxy.socks_version", Integer.valueOf(5), ub);
                    GeckoPreferenceController.setGeckoPref("network.proxy.socks_remote_dns", Boolean.TRUE, ub);
                    GeckoPreferenceController.setGeckoPref("network.proxy.no_proxies_on", "localhost, 127.0.0.1", ub);
                    GeckoPreferenceController.setGeckoPref("network.proxy.type", Integer.valueOf(1), ub);
                    // Nothing of the browser may leave around the tunnel: no direct fallback when the proxy hiccups,
                    // no QUIC/UDP (HTTP/3), no WebRTC address leak, no system-proxy override.
                    GeckoPreferenceController.setGeckoPref("network.proxy.failover_direct", Boolean.FALSE, ub);
                    GeckoPreferenceController.setGeckoPref("network.proxy.allow_bypass", Boolean.FALSE, ub);
                    GeckoPreferenceController.setGeckoPref("network.http.http3.enable", Boolean.FALSE, ub);
                    GeckoPreferenceController.setGeckoPref("media.peerconnection.ice.proxy_only_if_behind_proxy", Boolean.TRUE, ub);
                    GeckoPreferenceController.setGeckoPref("media.peerconnection.ice.default_address_only", Boolean.TRUE, ub);
                } else {
                    GeckoPreferenceController.setGeckoPref("network.proxy.type", Integer.valueOf(0), ub);
                    GeckoPreferenceController.setGeckoPref("network.proxy.failover_direct", Boolean.TRUE, ub);
                    GeckoPreferenceController.setGeckoPref("network.proxy.allow_bypass", Boolean.TRUE, ub);
                }
            } catch (Throwable t) { Log.e(TAG, "proxy prefs", t); }
        }
        if (a.containsKey("dlAsk")) dlAsk = bool(a, "dlAsk", true);
        if (a.containsKey("dlConns") && downloads != null) {
            try { downloads.conns = Math.max(1, Math.min(16, Integer.parseInt(str(a, "dlConns", "4")))); } catch (Exception ignored) { }
        }
        if (a.containsKey("passkeys")) {
            final boolean pk = bool(a, "passkeys", false);
            try {
                GeckoPreferenceController.setGeckoPref("security.webauth.webauthn", Boolean.valueOf(pk), GeckoPreferenceController.PREF_BRANCH_USER);
                GeckoPreferenceController.setGeckoPref("security.webauth.webauthn_enable_android_fido2", Boolean.valueOf(pk), GeckoPreferenceController.PREF_BRANCH_USER);
                GeckoPreferenceController.setGeckoPref("security.webauthn.ctap2", Boolean.valueOf(pk), GeckoPreferenceController.PREF_BRANCH_USER);
            } catch (Throwable t) { Log.e(TAG, "webauthn pref", t); }
        }
        final ContentBlocking.Settings cb = s.getContentBlocking();
        if (a.containsKey("track")) {
            final String lvl = str(a, "track", "standard");
            if ("off".equals(lvl)) {
                cb.setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.NONE);
                cb.setAntiTracking(ContentBlocking.AntiTracking.NONE);
            } else if ("strict".equals(lvl)) {
                cb.setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT);
                cb.setAntiTracking(ContentBlocking.AntiTracking.STRICT);
            } else {
                cb.setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.DEFAULT);
                cb.setAntiTracking(ContentBlocking.AntiTracking.DEFAULT | ContentBlocking.AntiTracking.STP);
            }
        }
        if (a.containsKey("tpc")) {
            final int cookies = bool(a, "tpc", true)
                    ? ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS
                    : ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS;
            cb.setCookieBehavior(cookies);
            cb.setCookieBehaviorPrivateMode(cookies);
        }
        if (a.containsKey("safeBrowsing")) {
            cb.setSafeBrowsing(bool(a, "safeBrowsing", true) ? ContentBlocking.SafeBrowsing.DEFAULT : ContentBlocking.SafeBrowsing.NONE);
        }
        if (a.containsKey("webrtc")) {
            GeckoPreferenceController.setGeckoPref("media.peerconnection.ice.default_address_only", Boolean.valueOf(bool(a, "webrtc", false)),
                    GeckoPreferenceController.PREF_BRANCH_USER);
        }
        if (a.containsKey("ua") || a.containsKey("sleeping")) {
            for (Tab t : tabs.values()) applyTabSettings(t, t.session.getSettings().getUserAgentMode() == GeckoSessionSettings.USER_AGENT_MODE_DESKTOP);
        }
        if (extensions != null && a.get("core") instanceof Map) extensions.setCoreConfig(new JSONObject((Map<String, Object>) a.get("core")));
    }

    void applyTabSettings(Tab t, boolean desktop) {
        final GeckoSessionSettings ss = t.session.getSettings();
        ss.setUserAgentMode(desktop ? GeckoSessionSettings.USER_AGENT_MODE_DESKTOP : GeckoSessionSettings.USER_AGENT_MODE_MOBILE);
        ss.setViewportMode(desktop ? GeckoSessionSettings.VIEWPORT_MODE_DESKTOP : GeckoSessionSettings.VIEWPORT_MODE_MOBILE);
        ss.setUserAgentOverride(uaOverride.isEmpty() ? null : uaOverride);
        ss.setSuspendMediaWhenInactive(suspendBackgroundMedia);
    }

    // ------------------------------------------------------------------ tabs

    Tab createTab(int id, boolean priv, boolean desktop, @Nullable GeckoSession existing) {
        final GeckoSession s;
        if (existing != null) {
            s = existing;
        } else {
            final GeckoSessionSettings.Builder b = new GeckoSessionSettings.Builder()
                    .usePrivateMode(priv)
                    .suspendMediaWhenInactive(suspendBackgroundMedia)
                    .userAgentMode(desktop ? GeckoSessionSettings.USER_AGENT_MODE_DESKTOP : GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
                    .viewportMode(desktop ? GeckoSessionSettings.VIEWPORT_MODE_DESKTOP : GeckoSessionSettings.VIEWPORT_MODE_MOBILE);
            if (!uaOverride.isEmpty()) b.userAgentOverride(uaOverride);
            s = new GeckoSession(b.build());
        }
        final Tab t = new Tab(id, s, priv);
        tabs.put(id, t);
        bySession.put(s, t);
        new TabDelegates(this, t).install();
        extensions.wire(t);
        return t;
    }

    /** Session handed to Gecko by onNewSession / extensions: must NOT be opened by us. */
    Tab createForeignTab(boolean priv) {
        final Tab t = createTab(nextNativeId++, priv, false, null);
        return t;
    }

    // First install: the built-in core extension (webRequest blocking) is still being installed while the first page
    // starts loading, and that first load stalls. Page loads wait for the extension (max 6 s) and then run in order.
    private boolean coreReady = false;
    private final List<Runnable> afterCore = new ArrayList<>();

    void whenCoreReady(Runnable r) {
        if (coreReady) r.run(); else afterCore.add(r);
    }

    void coreDone() {
        main.post(() -> {
            if (coreReady) return;
            coreReady = true;
            final List<Runnable> l = new ArrayList<>(afterCore);
            afterCore.clear();
            for (Runnable r : l) { try { r.run(); } catch (Throwable ex) { Log.e(TAG, "after core", ex); } }
        });
    }

    void ensureOpen(Tab t) {
        if (!t.session.isOpen()) t.session.open(runtime);
    }

    void select(Tab t) {
        if (current != null && current != t) {
            runtime.getWebExtensionController().setTabActive(current.session, false);
            if (current.session.isOpen()) current.session.setActive(false);
        }
        current = t;
        if (t.needsRestore) { recover(t); return; }
        if (!t.session.isOpen() && !isForeignPending(t)) ensureOpen(t);
        attach(t, 0);
        if (t.session.isOpen()) t.session.setActive(true);
        runtime.getWebExtensionController().setTabActive(t.session, true);
    }

    /** Presses Escape in the page: chat web apps (Telegram / Eitaa web...) close the open chat or dialog with it, which is what Back should do there. */
    static void sendEscape(android.view.View v) {
        if (v == null) return;
        try {
            final long now = android.os.SystemClock.uptimeMillis();
            v.dispatchKeyEvent(new android.view.KeyEvent(now, now, android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ESCAPE, 0));
            v.dispatchKeyEvent(new android.view.KeyEvent(now, now + 30, android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ESCAPE, 0));
        } catch (Throwable ignored) {}
    }

    /** Reopens a tab whose content process was killed and brings back its history (falls back to its URL); shows it when it is the current tab. */
    void recover(final Tab t) {
        t.needsRestore = false;
        main.post(() -> {
            try {
                if (!t.session.isOpen()) t.session.open(runtime);
                final GeckoSession.SessionState st = t.privateMode ? null : t.sessionState;
                if (st != null) t.session.restoreState(st);
                else if (!t.url.isEmpty() && t.failedUri == null) t.session.loadUri(t.url);
                if (current == t && view != null) {
                    if (view.getSession() != null) view.releaseSession();
                    attach(t, 0);
                    t.session.setActive(true);
                    runtime.getWebExtensionController().setTabActive(t.session, true);
                }
            } catch (Throwable ex) { Log.e(TAG, "recover", ex); }
        });
    }

    private boolean isForeignPending(Tab t) { return t.id >= 1_000_000 && t.url.isEmpty() && !t.session.isOpen(); }

    void attach(final Tab t, final int tries) {
        if (view == null || t != current) return;
        if (view.getSession() == t.session) return;
        if (!t.session.isOpen()) {
            if (tries < 40) main.postDelayed(() -> attach(t, tries + 1), 50);
            return;
        }
        if (view.getSession() != null) view.releaseSession();
        view.setSession(t.session);
        t.session.setActive(true);
    }

    void closeTab(Tab t) {
        tabs.remove(t.id);
        bySession.remove(t.session);
        extensions.forget(t);
        if (current == t) {
            current = null;
            if (view != null && view.getSession() == t.session) view.releaseSession();
        }
        if (t.session.isOpen()) t.session.close();
    }

    @Nullable Tab tab(MethodCall c) {
        final Integer id = c.argument("id");
        return id == null ? null : tabs.get(id);
    }

    // ------------------------------------------------------------------ method calls

    // ------------------------------------------------------------------ external links / shortcuts

    void handleIntent(@Nullable Intent it) {
        if (it == null) return;
        // Opened from the app's own launcher icon (not a link / PWA shortcut): Dart must leave any web-app (PWA) tab.
        if (Intent.ACTION_MAIN.equals(it.getAction()) && it.hasCategory(Intent.CATEGORY_LAUNCHER)
                && it.getData() == null && !it.getBooleanExtra("abtin_launcher_seen", false)) {
            it.putExtra("abtin_launcher_seen", true); // re-attach (rotation) hands us the same Intent again
            emit(ev("launcherOpen", 0));
            return;
        }
        Uri d = it.getData();
        if (d == null && Intent.ACTION_SEND.equals(it.getAction())) {
            if (android.os.Build.VERSION.SDK_INT >= 33) {
                d = it.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class);
            } else {
                //noinspection deprecation
                d = (Uri) it.getParcelableExtra(Intent.EXTRA_STREAM);
            }
        }
        if (d == null) return;
        final String action = it.getAction();
        final String sc = d.getScheme();
        if (Intent.ACTION_VIEW.equals(action) && ("http".equalsIgnoreCase(sc) || "https".equalsIgnoreCase(sc))) {
            if (it.getBooleanExtra("abtin_pwa", false)) {
                // Shortcut made by an older version: an installed web app is its own app now, not a tab of this browser.
                try {
                    final Intent w = new Intent(app, PwaActivity.class).setData(d);
                    w.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
                    app.startActivity(w);
                    it.setData(null);
                    return;
                } catch (Throwable ex) { Log.e(TAG, "legacy pwa redirect", ex); }
            }
            pendingUrl = d.toString();
            pendingPwa = false;
        } else if ((Intent.ACTION_VIEW.equals(action) || Intent.ACTION_SEND.equals(action)) &&
                ("content".equalsIgnoreCase(sc) || "file".equalsIgnoreCase(sc))) {
            // Accept JSON files from file managers and Android Sharesheet. Do not rely only on
            // the URI's last segment: document-provider URIs often contain an opaque numeric ID.
            String type = it.getType() == null ? "" : it.getType().toLowerCase(Locale.ROOT);
            String name = d.getLastPathSegment() == null ? "" : d.getLastPathSegment();
            if ("content".equalsIgnoreCase(sc)) {
                try (android.database.Cursor c = app.getContentResolver().query(d,
                        new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                    if (c != null && c.moveToFirst()) {
                        final int ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                        if (ix >= 0 && c.getString(ix) != null) name = c.getString(ix);
                    }
                } catch (Throwable ignored) { }
                final String resolvedType = app.getContentResolver().getType(d);
                if ((type.isEmpty() || "application/octet-stream".equals(type)) && resolvedType != null) {
                    type = resolvedType.toLowerCase(Locale.ROOT);
                }
            }
            final String lowerName = name.toLowerCase(Locale.ROOT);
            if (type.contains("json") || lowerName.endsWith(".json")) {
                try (InputStream in = app.getContentResolver().openInputStream(d);
                     ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    if (in == null) throw new IllegalStateException("Unable to read JSON file");
                    byte[] buf = new byte[8192]; int n; long total = 0;
                    while ((n = in.read(buf)) != -1) {
                        total += n;
                        if (total > 20L * 1024L * 1024L) throw new IllegalStateException("JSON file exceeds 20 MB");
                        out.write(buf, 0, n);
                    }
                    final String json = new String(out.toByteArray(), StandardCharsets.UTF_8);
                    final String quoted = JSONObject.quote(json);
                    final String safeName = JSONObject.quote(name == null || name.isEmpty() ? "JSON" : name);
                    final String html = "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>JSON</title>" +
                            "<style>:root{color-scheme:dark}body{margin:0;padding:18px;background:#111827;color:#e5e7eb;font:14px ui-monospace,monospace}header{font:600 14px sans-serif;color:#93c5fd;margin-bottom:14px;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.6;margin:0}#err{color:#fca5a5;font:13px sans-serif;margin-top:12px}</style><header id=h></header><pre id=j></pre><div id=err></div>" +
                            "<script>const s=" + quoted + ",n=" + safeName + ";document.getElementById('h').textContent=n;let v=s;try{v=JSON.stringify(JSON.parse(s),null,2)}catch(e){document.getElementById('err').textContent='JSON نامعتبر است: '+e.message}document.getElementById('j').textContent=v;</script>";
                    pendingUrl = "data:text/html;base64," + Base64.encodeToString(html.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                    pendingPwa = false;
                } catch (Throwable ex) {
                    Log.e(TAG, "Unable to open shared JSON file", ex);
                    final String message = JSONObject.quote(ex.getMessage() == null ? "Unable to read JSON file" : ex.getMessage());
                    final String html = "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>JSON</title><body style='background:#111827;color:#fca5a5;font:16px sans-serif;padding:20px'><h3>باز کردن فایل JSON ناموفق بود</h3><pre id=e></pre><script>document.getElementById('e').textContent=" + message + ";</script></body>";
                    pendingUrl = "data:text/html;base64," + Base64.encodeToString(html.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
                    pendingPwa = false;
                }
            } else if (openTextFile(d, name, type, lowerName)) {
                pendingPwa = false;
            } else return;
        } else return;
        it.setData(null); // handled; do not reopen it if the activity is re-attached
        emit(ev("openUrl", 0));
    }

    /** HTML / SVG / XML render as pages; css, js, txt, md, csv ... open in a readable text viewer (like Opera). */
    private boolean openTextFile(Uri d, String name, String type, String lowerName) {
        final String ext = lowerName.lastIndexOf('.') >= 0 ? lowerName.substring(lowerName.lastIndexOf('.') + 1) : "";
        final boolean html = ext.equals("html") || ext.equals("htm") || ext.equals("xhtml") || type.equals("text/html") || type.equals("application/xhtml+xml");
        final boolean svg = ext.equals("svg") || type.equals("image/svg+xml");
        final boolean xml = ext.equals("xml") || type.equals("text/xml") || type.equals("application/xml");
        final boolean textExt = java.util.Arrays.asList("css", "js", "mjs", "txt", "md", "markdown", "csv", "tsv", "log", "ini", "yml", "yaml", "map", "webmanifest").contains(ext);
        if (!(html || svg || xml || textExt || type.startsWith("text/") || type.contains("javascript"))) return false;
        try (InputStream in = app.getContentResolver().openInputStream(d);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) throw new IllegalStateException("Unable to read file");
            byte[] buf = new byte[8192]; int n; long total = 0;
            while ((n = in.read(buf)) != -1) {
                total += n;
                if (total > 8L * 1024L * 1024L) throw new IllegalStateException("File exceeds 8 MB");
                out.write(buf, 0, n);
            }
            final byte[] bytes = out.toByteArray();
            if (html) {
                pendingUrl = "data:text/html;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP);
            } else if (svg) {
                pendingUrl = "data:image/svg+xml;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP);
            } else if (xml) {
                pendingUrl = "data:text/xml;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP);
            } else {
                String text;
                try {
                    text = StandardCharsets.UTF_8.newDecoder()
                            .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                            .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                            .decode(java.nio.ByteBuffer.wrap(bytes)).toString();
                } catch (Throwable e) { // Persian files saved by old editors
                    text = new String(bytes, java.nio.charset.Charset.forName("windows-1256"));
                }
                final String page = "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><title>" + "File" + "</title>" +
                        "<style>:root{color-scheme:dark}body{margin:0;padding:18px;background:#111827;color:#e5e7eb;font:14px ui-monospace,monospace}header{font:600 14px sans-serif;color:#93c5fd;margin-bottom:14px;overflow-wrap:anywhere}pre{white-space:pre-wrap;overflow-wrap:anywhere;line-height:1.6;margin:0;unicode-bidi:plaintext}</style><header id=h></header><pre id=t></pre>" +
                        "<script>document.getElementById('h').textContent=" + JSONObject.quote(name == null || name.isEmpty() ? "File" : name) + ";document.title=document.getElementById('h').textContent;document.getElementById('t').textContent=" + JSONObject.quote(text) + ";</script>";
                pendingUrl = "data:text/html;base64," + Base64.encodeToString(page.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
            }
        } catch (Throwable ex) {
            Log.e(TAG, "Unable to open shared file", ex);
            final String message = JSONObject.quote(ex.getMessage() == null ? "Unable to read file" : ex.getMessage());
            final String page = "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><body style='background:#111827;color:#fca5a5;font:16px sans-serif;padding:20px'><h3>باز کردن فایل ناموفق بود</h3><pre id=e></pre><script>document.getElementById('e').textContent=" + message + ";</script></body>";
            pendingUrl = "data:text/html;base64," + Base64.encodeToString(page.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        }
        return true;
    }

    private boolean pinShortcut(MethodCall c) {
        try {
            final String url = c.argument("url");
            String title = c.argument("title");
            final byte[] icon = c.argument("icon");
            if (url == null || url.isEmpty()) return false;
            if (title == null || title.trim().isEmpty()) title = hostOf(url);
            final android.content.pm.ShortcutManager sm = app.getSystemService(android.content.pm.ShortcutManager.class);
            if (sm == null || !sm.isRequestPinShortcutSupported()) return false;
            final boolean pwa = Boolean.TRUE.equals(c.argument("pwa"));
            final Intent launch = app.getPackageManager().getLaunchIntentForPackage(app.getPackageName());
            final Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            if (pwa) {
                // Installed web app: its own activity in its own task (own entry in Recents), no browser tabs around it.
                it.setClass(app, PwaActivity.class);
                it.putExtra("abtin_title", title);
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
            } else {
                if (launch != null && launch.getComponent() != null) it.setComponent(launch.getComponent());
                else it.setPackage(app.getPackageName());
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            }
            final android.content.pm.ShortcutInfo info = new android.content.pm.ShortcutInfo.Builder(app, (pwa ? "abtin_pwa_" : "abtin_") + Integer.toHexString(url.hashCode()))
                    .setShortLabel(title.length() > 24 ? title.substring(0, 24) : title)
                    .setLongLabel(title)
                    .setIcon(android.graphics.drawable.Icon.createWithBitmap(shortcutIcon(icon, title)))
                    .setIntent(it)
                    .build();
            return sm.requestPinShortcut(info, null);
        } catch (Throwable ex) {
            Log.e(TAG, "pinShortcut", ex);
            return false;
        }
    }

    /** The site's icon at full size (transparent background kept), or a coloured tile with the first letter when there is no usable icon. */
    private Bitmap shortcutIcon(@Nullable byte[] data, String title) {
        final int size = 256;
        final Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        final android.graphics.Canvas cv = new android.graphics.Canvas(out);
        final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG | android.graphics.Paint.FILTER_BITMAP_FLAG);
        Bitmap fav = null;
        if (data != null && data.length > 0) {
            try { fav = android.graphics.BitmapFactory.decodeByteArray(data, 0, data.length); } catch (Throwable ignored) { }
        }
        final float r = size * .22f;
        if (fav != null && fav.getWidth() >= 16) {
            // The site's own icon, as it is: no tile, no padding, no background colour. Transparent areas stay transparent.
            final float k = Math.min((float) size / fav.getWidth(), (float) size / fav.getHeight());
            final float w = fav.getWidth() * k, h = fav.getHeight() * k;
            final float l = (size - w) / 2f, t = (size - h) / 2f;
            cv.drawBitmap(fav, null, new android.graphics.RectF(l, t, l + w, t + h), p);
        } else {
            final float hue = (title.hashCode() & 0x7fffffff) % 360;
            p.setColor(android.graphics.Color.HSVToColor(new float[]{hue, .62f, .74f}));
            cv.drawRoundRect(0, 0, size, size, r, r, p);
            p.setColor(0xFFFFFFFF);
            p.setTextSize(size * .52f);
            p.setTextAlign(android.graphics.Paint.Align.CENTER);
            p.setFakeBoldText(true);
            final String ch = title.isEmpty() ? "?" : new String(Character.toChars(title.codePointAt(0))).toUpperCase();
            final android.graphics.Paint.FontMetrics fm = p.getFontMetrics();
            cv.drawText(ch, size / 2f, size / 2f - (fm.ascent + fm.descent) / 2f, p);
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    void onCall(MethodCall c, final MethodChannel.Result r) {
        try {
            switch (c.method) {
                case "init":
                    init((Map<String, Object>) c.arguments);
                    r.success(GeckoSession.getDefaultUserAgent());
                    return;
                case "smsPerm":
                    smsOtp.request(true);
                    r.success(smsOtp.granted());
                    return;
                case "chromeEditing":
                    chromeEditing = Boolean.TRUE.equals(c.argument("on"));
                    r.success(null);
                    return;
                case "lowEnd":
                    r.success(lowEnd());
                    return;
                case "apply":
                    apply((Map<String, Object>) c.arguments);
                    r.success(null);
                    return;
                case "createTab": {
                    final int id = ((Number) c.argument("id")).intValue();
                    final boolean priv = Boolean.TRUE.equals(c.argument("private"));
                    final boolean desktop = Boolean.TRUE.equals(c.argument("desktop"));
                    final Tab t = createTab(id, priv, desktop, null);
                    ensureOpen(t);
                    final String url = c.argument("url");
                    final String saved = c.argument("state");
                    GeckoSession.SessionState restored = null;
                    if (!priv && saved != null && !saved.isEmpty()) {
                        try { restored = GeckoSession.SessionState.fromString(saved); } catch (Throwable ex) { Log.w(TAG, "restore state", ex); }
                    }
                    if (restored != null) {
                        final GeckoSession.SessionState rs = restored;
                        if (url != null) t.url = url;
                        whenCoreReady(() -> t.session.restoreState(rs));
                    } else if (url != null && !url.isEmpty()) { t.url = url; whenCoreReady(() -> t.session.loadUri(url)); }
                    if (Boolean.TRUE.equals(c.argument("select"))) select(t);
                    r.success(null);
                    return;
                }
                case "tabStates": {
                    // history of every tab that changed since the last call (id -> serialized state)
                    final Map<String, String> out = new HashMap<>();
                    for (Tab t : tabs.values()) {
                        if (t.privateMode || !t.stateDirty || t.sessionState == null) continue;
                        try {
                            final String s = t.sessionState.toString();
                            t.stateDirty = false;
                            if (s != null && s.length() < 300000) out.put(String.valueOf(t.id), s);
                        } catch (Throwable ex) { Log.w(TAG, "tab state", ex); }
                    }
                    r.success(out);
                    return;
                }
                case "closeTab": { final Tab t = tab(c); if (t != null) closeTab(t); r.success(null); return; }
                case "selectTab": { final Tab t = tab(c); if (t != null) select(t); r.success(null); return; }
                case "pauseTab": { final Tab t = tab(c); if (t != null && t != current && t.session.isOpen()) t.session.setActive(false); r.success(null); return; }
                case "loadUrl": {
                    final Tab t = tab(c);
                    if (t != null) {
                        ensureOpen(t);
                        final String u = c.argument("url");
                        t.url = u;
                        t.failedUri = null;
                        whenCoreReady(() -> t.session.loadUri(u));
                    }
                    r.success(null);
                    return;
                }
                case "reload": {
                    final Tab t = tab(c);
                    if (t != null) {
                        if (t.failedUri != null) t.session.loadUri(t.failedUri);
                        else t.session.reload(Boolean.TRUE.equals(c.argument("bypass")) ? GeckoSession.LOAD_FLAGS_BYPASS_CACHE : GeckoSession.LOAD_FLAGS_NONE);
                    }
                    r.success(null);
                    return;
                }
                case "stop": { final Tab t = tab(c); if (t != null) t.session.stop(); r.success(null); return; }
                case "back": { final Tab t = tab(c); if (t != null) t.session.goBack(); r.success(null); return; }
                case "escape": { main.post(() -> sendEscape(view)); r.success(null); return; }
                case "forward": { final Tab t = tab(c); if (t != null) t.session.goForward(); r.success(null); return; }
                case "setDesktop": {
                    final Tab t = tab(c);
                    if (t != null) {
                        applyTabSettings(t, Boolean.TRUE.equals(c.argument("desktop")));
                        t.session.reload(GeckoSession.LOAD_FLAGS_BYPASS_CACHE);
                    }
                    r.success(null);
                    return;
                }
                case "exitFullscreen": { final Tab t = tab(c); if (t != null) t.session.exitFullScreen(); r.success(null); return; }
                case "find": {
                    final Tab t = tab(c);
                    if (t == null) { r.success(null); return; }
                    final String text = c.argument("text");
                    final boolean back = Boolean.TRUE.equals(c.argument("backwards"));
                    t.session.getFinder().setDisplayFlags(GeckoSession.FINDER_DISPLAY_HIGHLIGHT_ALL);
                    t.session.getFinder().find(text, back ? GeckoSession.FINDER_FIND_BACKWARDS : GeckoSession.FINDER_FIND_FORWARD)
                            .accept(res -> {
                                final Map<String, Object> m = ev("find", t.id);
                                m.put("current", res == null ? 0 : res.current);
                                m.put("total", res == null ? 0 : res.total);
                                emit(m);
                            }, err -> { });
                    r.success(null);
                    return;
                }
                case "findClear": { final Tab t = tab(c); if (t != null) t.session.getFinder().clear(); r.success(null); return; }
                case "capture": capture(c, r); return;
                case "appActive": {
                    final boolean on = Boolean.TRUE.equals(c.argument("active"));
                    appForeground = on;
                    if (!on) pausedAt = android.os.SystemClock.elapsedRealtime();
                    final Tab cur = current;
                    if (on && cur != null && (cur.needsRestore || !cur.session.isOpen())) {
                        recover(cur);
                    } else {
                        if (cur != null && cur.session.isOpen() && (on || suspendBackgroundMedia)) cur.session.setActive(on);
                        // After a long time in the background the page surface can come back black: attach the session afresh.
                        if (on && cur != null && view != null && view.getSession() == cur.session
                                && android.os.SystemClock.elapsedRealtime() - pausedAt > 20_000) {
                            main.post(() -> {
                                try {
                                    if (current == cur && view != null && cur.session.isOpen()) {
                                        view.releaseSession();
                                        view.setSession(cur.session);
                                        cur.session.setActive(true);
                                        view.requestLayout();
                                    }
                                } catch (Throwable ex) { Log.e(TAG, "resume attach", ex); }
                            });
                        }
                    }
                    r.success(null);
                    return;
                }
                case "print": print(c, r); return;
                case "savePdf": savePdf(c, r); return;
                case "contentCmd": {
                    final Tab t = tab(c);
                    final Map<String, Object> m = c.argument("cmd");
                    boolean ok = false;
                    if (t != null && m != null) {
                        final JSONObject j = new JSONObject(m);
                        if (t.contentPort != null) {
                            try { t.contentPort.postMessage(j); ok = true; } catch (Throwable ex) { t.contentPort = null; }
                        }
                        // The page never attached its native port (e.g. it loaded before the extension was ready):
                        // let the extension's background page forward the command through the tabs API.
                        if (!ok) ok = extensions.relayToActiveTab(j);
                    }
                    r.success(ok);
                    return;
                }
                case "downloadAnswer": {
                    downloads.answer((String) c.argument("id"), Boolean.TRUE.equals(c.argument("ok")));
                    r.success(null);
                    return;
                }
                case "download": {
                    downloads.fetch((String) c.argument("url"), (String) c.argument("referer"), (String) c.argument("name"),
                            Boolean.TRUE.equals(c.argument("private")));
                    r.success(null);
                    return;
                }
                case "thumb": {
                    final String tp = c.argument("path");
                    final Number sz = c.argument("size");
                    new Thread(() -> {
                        final byte[] b = Thumbs.make(app, tp, sz == null ? 256 : sz.intValue());
                        main.post(() -> r.success(b));
                    }, "abtin-thumb").start();
                    return;
                }
                case "openFile": r.success(openFile(c.<String>argument("path"), c.<String>argument("mime"))); return;
                case "dlNotify": {
                    final Number tot = c.argument("total"), rec = c.argument("received");
                    if (dlNotif != null) dlNotif.update(String.valueOf((Object) c.argument("id")), String.valueOf((Object) c.argument("name")),
                            rec == null ? 0 : rec.longValue(), tot == null ? -1 : tot.longValue(), String.valueOf((Object) c.argument("status")),
                            c.<String>argument("path"), Boolean.TRUE.equals(c.argument("private")));
                    r.success(null);
                    return;
                }
                case "cancelDownload": downloads.cancel((String) c.argument("id"), c.<String>argument("path")); r.success(null); return;
                case "pauseDownload": downloads.pause((String) c.argument("id")); r.success(null); return;
                case "resumeDownload":
                    downloads.resume((String) c.argument("id"), (String) c.argument("url"), c.<String>argument("referer"), c.<String>argument("name"),
                            c.<String>argument("path"), Boolean.TRUE.equals(c.argument("private")));
                    r.success(null);
                    return;
                case "mux": {
                    final List<String> ins = new ArrayList<>();
                    final Object li = c.argument("inputs");
                    if (li instanceof List) for (Object o : (List<?>) li) ins.add(String.valueOf(o));
                    final String outPath = c.argument("out");
                    new Thread(() -> {
                        final boolean ok = outPath != null && Mux.run(ins, outPath);
                        main.post(() -> r.success(ok));
                    }).start();
                    return;
                }
                case "clearData": clearData(c, r); return;
                case "clearHost": {
                    final String host = c.argument("host");
                    runtime.getStorageController().clearDataFromHost(host,
                            StorageController.ClearFlags.COOKIES | StorageController.ClearFlags.DOM_STORAGES | StorageController.ClearFlags.AUTH_SESSIONS
                                    | StorageController.ClearFlags.NETWORK_CACHE)
                            .accept(x -> r.success(null), e -> r.success(null));
                    return;
                }
                case "resetPermissions": {
                    final String host = c.argument("host");
                    runtime.getStorageController().clearDataFromHost(host, StorageController.ClearFlags.PERMISSIONS)
                            .accept(x -> r.success(null), e -> r.success(null));
                    return;
                }
                case "loginsList": r.success(logins.list()); return;
                case "loginsPut": r.success(logins.put(c.<String>argument("guid"), c.<String>argument("origin"), c.<String>argument("user"), c.<String>argument("pass"))); return;
                case "loginsDelete": logins.delete(c.<String>argument("guid")); r.success(null); return;
                case "loginsClear": logins.clear(); r.success(null); return;
                case "loginsNever": r.success(logins.neverList()); return;
                case "loginsNeverRemove": logins.removeNever(c.<String>argument("host")); r.success(null); return;
                case "pinShortcut": r.success(pinShortcut(c)); return;
                case "takeLaunch": {
                    final Map<String, Object> m = new HashMap<>();
                    m.put("url", pendingUrl);
                    m.put("pwa", pendingPwa);
                    pendingUrl = null; pendingPwa = false;
                    r.success(m); return;
                }
                case "takeUrl": { final String u = pendingUrl; pendingUrl = null; r.success(u); return; }
                case "addVisited": { final String u = c.argument("url"); if (u != null) visited.add(u); r.success(null); return; }
                default:
                    if (c.method.startsWith("ext")) { extensions.onCall(c, r); return; }
                    r.notImplemented();
            }
        } catch (Throwable e) {
            Log.e(TAG, "call " + c.method, e);
            r.error("engine", String.valueOf(e), null);
        }
    }

    private void clearData(MethodCall c, final MethodChannel.Result r) {
        long flags = 0;
        if (Boolean.TRUE.equals(c.argument("cookies")))
            flags |= StorageController.ClearFlags.COOKIES | StorageController.ClearFlags.DOM_STORAGES | StorageController.ClearFlags.AUTH_SESSIONS;
        if (Boolean.TRUE.equals(c.argument("cache"))) flags |= StorageController.ClearFlags.ALL_CACHES;
        if (Boolean.TRUE.equals(c.argument("perms"))) flags |= StorageController.ClearFlags.PERMISSIONS;
        if (flags == 0) { r.success(null); return; }
        runtime.getStorageController().clearData(flags).accept(x -> r.success(null), e -> r.success(null));
    }

    private void capture(MethodCall c, final MethodChannel.Result r) {
        final Integer w = c.argument("width");
        final boolean png = Boolean.TRUE.equals(c.argument("png"));
        if (view == null || view.getSession() == null) { r.success(null); return; }
        view.capturePixels().accept(bmp -> {
            if (bmp == null) { r.success(null); return; }
            // scaling + encoding off the UI thread (full-screen PNG encode used to freeze the page)
            bg.execute(() -> {
                byte[] bytes = null;
                try {
                    Bitmap out = bmp;
                    if (w != null && w > 0 && bmp.getWidth() > w) {
                        out = Bitmap.createScaledBitmap(bmp, w, Math.max(1, bmp.getHeight() * w / bmp.getWidth()), true);
                    }
                    final ByteArrayOutputStream bo = new ByteArrayOutputStream();
                    out.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, png ? 100 : 55, bo);
                    bytes = bo.toByteArray();
                } catch (Throwable ex) { Log.e(TAG, "capture", ex); }
                final byte[] res = bytes;
                main.post(() -> r.success(res));
            });
        }, e -> r.success(null));
    }

    private void print(MethodCall c, final MethodChannel.Result r) {
        final Tab t = tab(c);
        if (t == null || activity == null) { r.success(false); return; }
        t.session.saveAsPdf().accept(stream -> {
            try {
                final PrintManager pm = (PrintManager) activity.getSystemService(Context.PRINT_SERVICE);
                pm.print("Abtin", new GeckoViewPrintDocumentAdapter(stream, activity), null);
                r.success(true);
            } catch (Throwable e) {
                r.success(false);
            }
        }, e -> r.success(false));
    }

    /** Saves the current page as a PDF straight into [path] (no print dialog). */
    private void savePdf(MethodCall c, final MethodChannel.Result r) {
        final Tab t = tab(c);
        final String path = c.argument("path");
        if (t == null || path == null) { r.success(false); return; }
        t.session.saveAsPdf().accept(stream -> new Thread(() -> {
            boolean ok = false;
            try (java.io.InputStream in = stream; java.io.OutputStream out = new java.io.FileOutputStream(path)) {
                final byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                ok = true;
            } catch (Throwable ex) {
                Log.e(TAG, "savePdf", ex);
                try { new java.io.File(path).delete(); } catch (Throwable ignored) {}
            }
            final boolean res = ok;
            main.post(() -> r.success(res));
        }, "abtin-savepdf").start(), e -> r.success(false));
    }

    // ------------------------------------------------------------------ activity hooks

    boolean onActivityResult(int req, int res, Intent data) {
        if (req == REQ_GECKO_ACTIVITY) {
            final GeckoResult<Intent> r = pendingActivity;
            pendingActivity = null;
            Log.i(TAG, "activityResult res=" + res + " extras=" + (data == null ? null : data.getExtras()));
            if (r != null) {
                if (res == Activity.RESULT_OK) r.complete(data);
                else {
                    final Map<String, Object> m = ev("passkey", 0); m.put("err", "result=" + res + fidoError(data)); emit(m);
                    r.completeExceptionally(new RuntimeException("activity cancelled"));
                }
            }
            return true;
        }
        return prompts != null && prompts.onActivityResult(req, res, data);
    }

    /** ACTION_VIEW intent for a downloaded file through our own FileProvider; null if the file is gone. */
    @Nullable Intent viewIntent(String path, @Nullable String mimeArg) {
        try {
            final java.io.File f = new java.io.File(path);
            if (!f.exists()) return null;
            final Uri uri = androidx.core.content.FileProvider.getUriForFile(app, app.getPackageName() + ".abtin.files", f);
            String mime = mimeArg;
            if (mime == null || mime.isEmpty()) {
                final String n = f.getName().toLowerCase(Locale.ROOT);
                final int dot = n.lastIndexOf('.');
                final String ext = dot >= 0 ? n.substring(dot + 1) : "";
                mime = ext.isEmpty() ? null : android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
                if ("apk".equals(ext)) mime = "application/vnd.android.package-archive";
                if ("json".equals(ext)) mime = "application/json";
                if (mime == null) mime = "*/*";
            }
            final Intent i = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime);
            i.setClipData(android.content.ClipData.newRawUri("", uri));
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            return i;
        } catch (Throwable t) { Log.w(TAG, "viewIntent", t); return null; }
    }

    /** Opens a file with another app. Returns ok | nofile | nohandler | installperm | error. */
    String openFile(@Nullable String path, @Nullable String mime) {
        if (path == null || path.isEmpty()) return "nofile";
        final Intent i = viewIntent(path, mime);
        if (i == null) return "nofile";
        final Context ctx = activity != null ? activity : app;
        try {
            if ("application/vnd.android.package-archive".equals(i.getType()) && !app.getPackageManager().canRequestPackageInstalls()) {
                ctx.startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + app.getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return "installperm";
            }
            ctx.startActivity(i);
            return "ok";
        } catch (android.content.ActivityNotFoundException ex) {
            try {
                i.setDataAndType(i.getData(), "*/*");
                ctx.startActivity(Intent.createChooser(i, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return "ok";
            } catch (Throwable t2) { return "nohandler"; }
        } catch (Throwable t) { Log.w(TAG, "openFile", t); return "error"; }
    }

    /** Decodes the error Google Play Services FIDO2 returns (e.g. "calling app not allowed") for the toast/log. */
    static String fidoError(Intent data) {
        try {
            if (data == null || !data.hasExtra("FIDO2_ERROR_EXTRA")) return "";
            final byte[] raw = data.getByteArrayExtra("FIDO2_ERROR_EXTRA");
            final com.google.android.gms.fido.fido2.api.common.AuthenticatorErrorResponse er =
                    com.google.android.gms.fido.fido2.api.common.AuthenticatorErrorResponse.deserializeFromBytes(raw);
            Log.e(TAG, "FIDO2 error " + er.getErrorCodeAsInt() + " " + er.getErrorMessage());
            return " fido=" + er.getErrorCodeAsInt() + " " + er.getErrorMessage();
        } catch (Throwable t) { return ""; }
    }

    boolean onPermissionsResult(int req, String[] perms, int[] results) { if (req == REQ_NOTIF) return true; if (req == SmsOtp.REQ_SMS) { smsOtp.onResult(); return true; } return prompts != null && prompts.onPermissionsResult(req, perms, results); }

    void dispose() {
        // The runtime intentionally outlives the Flutter engine/activity; tabs are kept.
    }

    // ------------------------------------------------------------------ helpers

    static String str(Map<String, Object> m, String k, String d) { final Object o = m.get(k); return o == null ? d : String.valueOf(o); }

    static boolean bool(Map<String, Object> m, String k, boolean d) { final Object o = m.get(k); return o instanceof Boolean ? (Boolean) o : d; }

    static boolean hasPermission(Context c, String p) { return c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    static String hostOf(String url) {
        try { final String h = Uri.parse(url).getHost(); return h == null ? "" : h.toLowerCase(Locale.ROOT); } catch (Exception e) { return ""; }
    }
}
