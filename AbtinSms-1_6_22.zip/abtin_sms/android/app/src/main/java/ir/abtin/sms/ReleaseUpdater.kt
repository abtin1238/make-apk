package ir.abtin.sms

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.io.FilterInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object ReleaseUpdater {
    private const val API = "https://api.github.com/repos/abtin1238/make-apk/releases/latest"
    private const val RELEASES = "https://github.com/abtin1238/make-apk/releases/latest"
    private const val MAX_APK_BYTES = 120L * 1024L * 1024L

    data class Result(val apk: File?, val version: String, val tag: String, val releaseUrl: String)

    fun checkAndDownload(context: android.content.Context): Result {
        val json = request(API, "application/vnd.github+json").bufferedReader().use { it.readText() }
        val release = JSONObject(json)
        val tag = release.optString("tag_name")
        val releaseUrl = release.optString("html_url", RELEASES).ifBlank { RELEASES }
        val assets = release.optJSONArray("assets") ?: error("No release assets")
        // Only the zip's name (AbtinSms…) and the version at its end (AbtinSms-1_6_17.zip) matter; tag/build are ignored.
        val nameRx = Regex("^AbtinSms.*?(\\d+(?:[._]\\d+)+)\\.zip$", RegexOption.IGNORE_CASE)
        class Cand(val url: String, val name: String, val ver: List<Int>, val label: String)
        val cands = ArrayList<Cand>()
        for (index in 0 until assets.length()) {
            val asset = assets.getJSONObject(index)
            val name = asset.optString("name")
            val m = nameRx.find(name) ?: continue
            val url = asset.optString("browser_download_url").takeIf { it.startsWith("https://") } ?: continue
            val label = m.groupValues[1].replace('_', '.')
            cands += Cand(url, name, parseVer(label), label)
        }
        require(cands.isNotEmpty()) { "No AbtinSms-<version>.zip in release" }
        val best = cands.reduce { x, y -> if (cmpVer(y.ver, x.ver) > 0) y else x }
        val top = cands.filter { cmpVer(it.ver, best.ver) == 0 }
        val pick = Build.SUPPORTED_ABIS.firstNotNullOfOrNull { abi -> top.firstOrNull { it.name.contains(abi, true) } } ?: top.first()
        val localName = context.packageManager.getPackageInfo(context.packageName, 0).versionName.orEmpty()
        if (cmpVer(pick.ver, parseVer(localName)) <= 0) return Result(null, localName, tag, releaseUrl)
        val downloadUrl = pick.url
        val cache = File(context.cacheDir, "updates").apply { mkdirs() }
        val zipFile = File(cache, "latest.zip")
        request(downloadUrl, "application/octet-stream").use { input ->
            zipFile.outputStream().use { output -> input.copyTo(output) }
        }

        val apkFile = File(cache, "AbtinSms-update.apk")
        var extracted = false
        ZipInputStream(zipFile.inputStream().buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name.endsWith(".apk", ignoreCase = true)) {
                    var total = 0L
                    apkFile.outputStream().use { output ->
                        val buffer = ByteArray(16 * 1024)
                        while (true) {
                            val count = zip.read(buffer)
                            if (count < 0) break
                            total += count
                            require(total <= MAX_APK_BYTES) { "APK is unexpectedly large" }
                            output.write(buffer, 0, count)
                        }
                    }
                    extracted = true
                    break
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        zipFile.delete()
        require(extracted && apkFile.isFile && apkFile.length() > 0) { "APK was not found in release archive" }

        val archiveInfo = context.packageManager.getPackageArchiveInfo(apkFile.absolutePath, 0)
            ?: error("Downloaded APK is invalid")
        require(archiveInfo.packageName == context.packageName) { "Downloaded APK is for a different app" }
        val remoteName = pick.label
        return Result(apkFile, remoteName, tag, releaseUrl)
    }

    private fun parseVer(v: String): List<Int> = Regex("\\d+").findAll(v).map { it.value.toInt() }.toList()
    private fun cmpVer(a: List<Int>, b: List<Int>): Int {
        for (i in 0 until maxOf(a.size, b.size)) {
            val d = a.getOrElse(i) { 0 }.compareTo(b.getOrElse(i) { 0 })
            if (d != 0) return d
        }
        return 0
    }

    fun installOrRequestPermission(activity: Activity, apk: File) {
        if (Build.VERSION.SDK_INT >= 26 && !activity.packageManager.canRequestPackageInstalls()) {
            activity.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${activity.packageName}")))
            return
        }
        val uri = FileProvider.getUriForFile(activity, activity.packageName + ".files", apk)
        val intent = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        activity.startActivity(intent)
    }

    private fun request(address: String, accept: String): java.io.InputStream {
        val connection = (URL(address).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 45_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "AbtinSms-Android")
            setRequestProperty("Accept", accept)
        }
        if (connection.responseCode !in 200..299) {
            val code = connection.responseCode
            connection.disconnect()
            error("GitHub returned HTTP $code")
        }
        return object : FilterInputStream(connection.inputStream) {
            override fun close() {
                try { super.close() } finally { connection.disconnect() }
            }
        }
    }
}
