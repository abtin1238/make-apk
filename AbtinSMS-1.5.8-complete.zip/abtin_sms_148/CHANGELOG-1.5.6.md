# Abtin SMS 1.5.6

- Separated Phone notification preferences from SMS preferences, including independent call-notification enablement, sound, vibration, and accent color.
- Prevented the Phone profile from inheriting legacy unscoped SMS preferences; existing SMS settings remain migrated from their legacy keys.
- Kept incoming-call answer/decline controls in a custom heads-up notification, with app-language labels and separate green/red controls; no full-screen activity is launched by the notification.
- Improved SMS notification expansion with full BigText content and a localized inline-reply action using Android RemoteInput.
- Preserved the existing Hold/Resume call control and previous project assets.
