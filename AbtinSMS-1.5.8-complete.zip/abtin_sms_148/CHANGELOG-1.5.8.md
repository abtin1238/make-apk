# Abtin SMS 1.5.8

- Replaced the system CallStyle notification with Abtin's own themed call card (compact single row, never clipped, works on heads-up and lock screen).
- Added a call theme engine with 6 ready-made themes: Midnight, Mountain, Neon, Violet, Emerald, Classic.
- Full customization from Phone settings > Call appearance: answer/decline control (two buttons / capsule / swipe), button shape (circle / rounded / pill / square), style (filled / outline / glow), size, labels, icon and button colors, custom texts, background colors, avatar ring and notification card colors.
- Live preview of the incoming screen and the notification card, plus a "send test notification" action.
- Themed incoming, in-call, call-ended and missed-call screens; missed-call card has a one-tap Call back button.
- Kept 1.5.7 behaviour: full-screen intent over the lock screen, screen wake, persistent ringing notification with Answer/Decline, hang-up + timer on the ongoing-call notification.
