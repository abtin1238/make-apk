# Abtin SMS 1.5.1

- Refined incoming-call slider: compact pill track with a larger centered thumb; swipe right to answer and left to decline.
- Incoming-call notifications use Android CallStyle on Android 12+ for native answer/decline controls; older Android versions retain explicit actions.
- Call recording now attempts only the direct `VOICE_CALL` audio source. Microphone fallback and speaker routing are removed. On devices where Android does not grant direct call-audio capture, recording reports unsupported instead of saving microphone audio.
- Message multi-select toolbar is fixed to a compact 64dp action bar with smaller controls to prevent the oversized selection header.
