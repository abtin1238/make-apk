# Abtin SMS 1.5.3

- Replaced the incoming-call notification's system CallStyle actions with app-owned green Answer and red Decline buttons.
- Localized the incoming-call notification labels using the app language preference (Persian/English).
- Kept incoming calls as heads-up notifications; removed the full-screen intent from the notification path.
- Preserved the existing call action receiver and its answer/decline behavior.
- Retained all prior SMS, contacts, notification, settings, and release-signing files.
