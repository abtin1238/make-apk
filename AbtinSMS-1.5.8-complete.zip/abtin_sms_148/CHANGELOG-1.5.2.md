# 1.5.2

- Added independent preference namespaces for the Abtin SMS launcher and the Abtin Phone (calls/contacts) launcher. Theme colors, notification options, and other settings can now be configured separately in each app.
- SMS notifications now use profile-specific notification channels and app accent colors.
- Replaced the notification's RemoteInput action caption with a send action; Android's expanded BigText notification provides the standard expand/collapse chevron and inline reply field.
- Hardened incoming-call notification answer/decline actions by validating the live ringing call before invoking Telecom actions.

Build verification could not be completed in this environment because the Gradle distribution could not be downloaded (network unavailable).
