# Abtin SMS 1.5.7

- Incoming call notification rebuilt on the system CallStyle (like Google Phone): caller name, Answer and Decline buttons, visible on the lock screen and as heads-up.
- Full-screen intent: the call screen now wakes the display and shows over the lock screen with swipe answer/decline.
- Ringing notification is persistent (cannot be swiped away; auto-restored if dismissed) and rings repeatedly until answered, declined or missed.
- Answer from the notification opens the in-call screen (works from the lock screen, no Android 12+ trampoline block).
- Ongoing-call notification now has a Hang up button and a live call timer.
- Ring channel uses the system ringtone by default and public lock-screen visibility (new channel id so existing installs pick it up).
- Android 14+: prompts for full-screen-intent access if it is not granted.
