package ir.abtin.sms

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat

// =====================================================================
// Call themes: ready-made presets + user overrides stored in phone_* prefs
// =====================================================================
enum class BgKind { MIDNIGHT, MOUNTAIN, NEON, WAVE, EMERALD, CLASSIC }

class CallTheme(
    val id: String, val fa: String, val en: String,
    val bg: BgKind,
    val top: Color, val bottom: Color, val accent: Color,
    val text: Color, val sub: Color,
    val answer: Color, val decline: Color,
    val ring: String,          // none | plain | glow | gradient | arc
    val layout: String,        // buttons | pill | swipe
    val shape: String,         // circle | rounded | pill | square
    val style: String,         // filled | outline | glow
    val labels: Boolean,
    val notifBg: Color, val notifText: Color
)

/** Fully-resolved look: theme defaults with the user's overrides applied. */
class CallLook(
    val t: CallTheme,
    val layout: String, val shape: String, val style: String, val labels: Boolean, val scale: Float,
    val answer: Color, val decline: Color, val icon: Color,
    val answerText: String, val declineText: String, val subtitle: String,
    val ring: String, val top: Color, val bottom: Color,
    val notifBg: Color, val notifText: Color
)

object CallLooks {
    private val WHITE = Color.White
    val all: List<CallTheme> = listOf(
        CallTheme("midnight", "نیمه‌شب", "Midnight", BgKind.MIDNIGHT,
            Color(0xFF0A1128), Color(0xFF2B1B52), Color(0xFF5B7CFF), WHITE, Color(0xFFB6BDD0),
            Color(0xFF22C55E), Color(0xFFEF4444), "glow", "buttons", "circle", "filled", true,
            Color(0xFF1E2433), WHITE),
        CallTheme("mountain", "کوهستان", "Mountain", BgKind.MOUNTAIN,
            Color(0xFF3C6EA8), Color(0xFFD98CA3), Color(0xFF4DD0C4), WHITE, Color(0xFFE6ECF5),
            Color(0xFF22C55E), Color(0xFFEF4444), "plain", "pill", "circle", "filled", true,
            Color(0xFF26323F), WHITE),
        CallTheme("neon", "نئون", "Neon", BgKind.NEON,
            Color(0xFF000000), Color(0xFF04080A), Color(0xFFB06BFF), WHITE, Color(0xFFA7ADB8),
            Color(0xFF2BE37A), Color(0xFFFF3B4D), "gradient", "buttons", "circle", "glow", false,
            Color(0xFF111318), WHITE),
        CallTheme("violet", "بنفش", "Violet", BgKind.WAVE,
            Color(0xFF160E48), Color(0xFF5B21B6), Color(0xFFA78BFA), WHITE, Color(0xFFD5CCF5),
            Color(0xFF22C55E), Color(0xFFEF4444), "plain", "buttons", "circle", "filled", true,
            Color(0xFF2A1F5C), WHITE),
        CallTheme("emerald", "زمرد", "Emerald", BgKind.EMERALD,
            Color(0xFF06141F), Color(0xFF0F766E), Color(0xFF38BDF8), WHITE, Color(0xFFB4D6D4),
            Color(0xFF22C55E), Color(0xFFEF4444), "arc", "buttons", "circle", "filled", true,
            Color(0xFF0F2A33), WHITE),
        CallTheme("classic", "کلاسیک", "Classic", BgKind.CLASSIC,
            Color(0xFF12161D), Color(0xFF1D2430), Color(0xFF2F6BFF), WHITE, Color(0xFFC7CDD5),
            Color(0xFF34C77B), Color(0xFFFF4D5E), "none", "swipe", "circle", "filled", true,
            Color(0xFF20242B), WHITE)
    )

    fun byId(id: String): CallTheme = all.firstOrNull { it.id == id } ?: all[0]

    private fun colorOr(v: Int, def: Color) = if (v != 0) Color(v) else def

    fun forTheme(t: CallTheme) = CallLook(
        t, t.layout, t.shape, t.style, t.labels, 1f, t.answer, t.decline, Color.White,
        tr("پاسخ", "Answer"), tr("رد تماس", "Decline"), tr("تماس ورودی…", "Incoming call…"),
        t.ring, t.top, t.bottom, t.notifBg, t.notifText
    )

    /** Reads the phone-profile prefs (observable state, so Compose callers recompose on change). */
    fun resolve(): CallLook = Prefs.withProfile(true) {
        val t = byId(Prefs.callTheme.value)
        CallLook(
            t,
            layout = Prefs.callLayout.value.ifBlank { t.layout },
            shape = Prefs.callBtnShape.value.ifBlank { t.shape },
            style = Prefs.callBtnStyle.value.ifBlank { t.style },
            labels = when (Prefs.callBtnLabels.value) { "on" -> true; "off" -> false; else -> t.labels },
            scale = Prefs.callBtnScale.value.coerceIn(0.7f, 1.4f),
            answer = colorOr(Prefs.callAnswerColor.value, t.answer),
            decline = colorOr(Prefs.callDeclineColor.value, t.decline),
            icon = colorOr(Prefs.callBtnIconColor.value, Color.White),
            answerText = Prefs.callAnswerText.value.ifBlank { tr("پاسخ", "Answer") },
            declineText = Prefs.callDeclineText.value.ifBlank { tr("رد تماس", "Decline") },
            subtitle = Prefs.callSubtitleText.value.ifBlank { tr("تماس ورودی…", "Incoming call…") },
            ring = Prefs.callAvatarRing.value.ifBlank { t.ring },
            top = colorOr(Prefs.callBgTop.value, t.top),
            bottom = colorOr(Prefs.callBgBottom.value, t.bottom),
            notifBg = colorOr(Prefs.callNotifBg.value, t.notifBg),
            notifText = colorOr(Prefs.callNotifText.value, t.notifText)
        )
    }

    fun resetOverrides() = Prefs.withProfile(true) {
        Prefs.callLayout.value = ""; Prefs.callBtnShape.value = ""; Prefs.callBtnStyle.value = ""
        Prefs.callBtnLabels.value = ""; Prefs.callBtnScale.value = 1f
        Prefs.callAnswerColor.value = 0; Prefs.callDeclineColor.value = 0; Prefs.callBtnIconColor.value = 0
        Prefs.callAnswerText.value = ""; Prefs.callDeclineText.value = ""; Prefs.callSubtitleText.value = ""
        Prefs.callAvatarRing.value = ""; Prefs.callBgTop.value = 0; Prefs.callBgBottom.value = 0
        Prefs.callNotifBg.value = 0; Prefs.callNotifText.value = 0
    }

    fun applyTheme(id: String) = Prefs.withProfile(true) {
        resetOverrides()
        Prefs.callTheme.value = id
    }
}

// =====================================================================
// Compose: themed background, avatar ring, action buttons, ring controls
// =====================================================================
@Composable
fun CallBackground(look: CallLook, modifier: Modifier = Modifier.fillMaxSize(), content: @Composable BoxScope.() -> Unit = {}) {
    Box(modifier.background(Brush.verticalGradient(listOf(look.top, look.bottom)))) {
        ComposeCanvas(Modifier.matchParentSize()) {
            val w = size.width
            val h = size.height
            when (look.t.bg) {
                BgKind.MIDNIGHT -> drawCircle(
                    Brush.radialGradient(listOf(look.t.accent.copy(alpha = .22f), Color.Transparent), Offset(w / 2, h * .26f), w * .75f),
                    radius = w * .75f, center = Offset(w / 2, h * .26f))
                BgKind.NEON -> {
                    drawCircle(Brush.radialGradient(listOf(look.answer.copy(alpha = .30f), Color.Transparent), Offset(w * .8f, h * .94f), w * .6f),
                        radius = w * .6f, center = Offset(w * .8f, h * .94f))
                    drawCircle(Brush.radialGradient(listOf(look.decline.copy(alpha = .16f), Color.Transparent), Offset(w * .2f, h * .94f), w * .5f),
                        radius = w * .5f, center = Offset(w * .2f, h * .94f))
                }
                BgKind.EMERALD -> drawCircle(
                    Brush.radialGradient(listOf(Color(0xFF2DD4BF).copy(alpha = .22f), Color.Transparent), Offset(w * .5f, h * .9f), w * .9f),
                    radius = w * .9f, center = Offset(w * .5f, h * .9f))
                BgKind.WAVE -> {
                    val p1 = Path().apply {
                        moveTo(0f, h * .66f)
                        cubicTo(w * .25f, h * .56f, w * .45f, h * .80f, w * .75f, h * .68f)
                        cubicTo(w * .88f, h * .63f, w * .95f, h * .62f, w, h * .64f)
                        lineTo(w, h); lineTo(0f, h); close()
                    }
                    drawPath(p1, Brush.verticalGradient(listOf(Color(0xFF7C3AED).copy(alpha = .75f), Color(0xFF2E1065).copy(alpha = .9f)), h * .6f, h))
                    val p2 = Path().apply {
                        moveTo(0f, h * .78f)
                        cubicTo(w * .3f, h * .70f, w * .55f, h * .90f, w, h * .76f)
                        lineTo(w, h); lineTo(0f, h); close()
                    }
                    drawPath(p2, Color(0xFF4C1D95).copy(alpha = .55f))
                }
                BgKind.MOUNTAIN -> {
                    val far = Path().apply {
                        moveTo(0f, h * .60f); lineTo(w * .22f, h * .46f); lineTo(w * .38f, h * .56f)
                        lineTo(w * .62f, h * .38f); lineTo(w * .82f, h * .54f); lineTo(w, h * .47f)
                        lineTo(w, h); lineTo(0f, h); close()
                    }
                    drawPath(far, Color(0xFF3B4A66))
                    val cap = Path().apply {
                        moveTo(w * .62f, h * .38f); lineTo(w * .55f, h * .445f); lineTo(w * .60f, h * .43f)
                        lineTo(w * .64f, h * .46f); lineTo(w * .68f, h * .43f); lineTo(w * .72f, h * .45f); close()
                    }
                    drawPath(cap, Color(0xFFF3F4F8))
                    val near = Path().apply {
                        moveTo(0f, h * .70f); lineTo(w * .30f, h * .60f); lineTo(w * .55f, h * .72f)
                        lineTo(w * .80f, h * .62f); lineTo(w, h * .70f); lineTo(w, h); lineTo(0f, h); close()
                    }
                    drawPath(near, Color(0xFF1E2B3F))
                    // pine silhouettes
                    val tree = Color(0xFF0F1B14)
                    var x = 0f
                    while (x < w + 20f) {
                        val th = h * (.07f + .03f * ((x / 37f).toInt() % 3))
                        val base = h * .86f + ((x / 23f).toInt() % 2) * h * .02f
                        val t = Path().apply { moveTo(x, base); lineTo(x + w * .025f, base - th); lineTo(x + w * .05f, base); close() }
                        drawPath(t, tree)
                        x += w * .04f
                    }
                    drawRect(tree, Offset(0f, h * .86f), androidx.compose.ui.geometry.Size(w, h * .14f))
                }
                BgKind.CLASSIC -> {}
            }
        }
        content()
    }
}

@Composable
fun CallAvatar(repo: SmsRepo?, number: String, name: String, look: CallLook, size: Dp = 128.dp, pulse: Boolean = true) {
    val a = look.t.accent
    val transition = rememberInfiniteTransition(label = "avatar")
    val k by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "k")
    val outer = size * 1.7f
    Box(Modifier.size(outer), contentAlignment = Alignment.Center) {
        if (look.ring == "glow") {
            val s1 = size * (1.30f + .08f * (if (pulse) k else 0f))
            val s2 = size * (1.58f + .08f * (if (pulse) k else 0f))
            Box(Modifier.size(s2).clip(CircleShape).background(a.copy(alpha = .06f)))
            Box(Modifier.size(s1).clip(CircleShape).background(a.copy(alpha = .10f)).border(1.dp, a.copy(alpha = .25f), CircleShape))
        }
        val ringMod = when (look.ring) {
            "gradient" -> Modifier.size(size + 14.dp).border(4.dp, Brush.sweepGradient(listOf(Color(0xFFFF4FD8), Color(0xFF6C7BFF), Color(0xFF22D3EE), Color(0xFFB06BFF), Color(0xFFFF4FD8))), CircleShape).padding(7.dp)
            "arc" -> Modifier.size(size + 14.dp).border(4.dp, Brush.sweepGradient(listOf(a, a.copy(alpha = .15f), a)), CircleShape).padding(7.dp)
            "plain" -> Modifier.size(size + 12.dp).border(2.dp, a.copy(alpha = .85f), CircleShape).padding(6.dp)
            else -> Modifier.size(size)
        }
        Box(ringMod, contentAlignment = Alignment.Center) { Avatar(repo, number, name, size) }
    }
}

/** One answer / decline button honouring the user's shape, style, size, colors and label settings. */
@Composable
fun CallActionButton(answer: Boolean, look: CallLook, onClick: () -> Unit, noLabel: Boolean = false, sizeOverride: Dp? = null) {
    val color = if (answer) look.answer else look.decline
    val label = if (answer) look.answerText else look.declineText
    val s = sizeOverride ?: (64.dp * look.scale)
    val pillLabel = look.shape == "pill" && look.labels && !noLabel
    val shape = when (look.shape) {
        "rounded" -> RoundedCornerShape(s * 0.30f)
        "square" -> RoundedCornerShape(6.dp)
        "pill" -> RoundedCornerShape(50)
        else -> CircleShape
    }
    val tint = if (look.style == "filled") look.icon else color
    var m = Modifier.size(width = if (pillLabel) s * 2.4f else s, height = s)
    if (look.style == "glow") m = m.shadow(20.dp, shape, ambientColor = color, spotColor = color)
    m = m.clip(shape).background(when (look.style) {
        "filled" -> color
        "outline" -> color.copy(alpha = .14f)
        else -> Color.Black.copy(alpha = .45f)
    })
    if (look.style != "filled") m = m.border(if (look.style == "glow") 1.5.dp else 2.dp, color, shape)
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(m.clickable(onClick = onClick), contentAlignment = Alignment.Center) {
            if (pillLabel) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (answer) Icons.Default.Call else Icons.Default.CallEnd, null, tint = tint, modifier = Modifier.size(s * 0.42f))
                    Spacer(Modifier.width(8.dp))
                    Text(label, color = tint, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                }
            } else {
                Icon(if (answer) Icons.Default.Call else Icons.Default.CallEnd, null, tint = tint, modifier = Modifier.size(s * 0.45f))
            }
        }
        if (look.labels && !pillLabel && !noLabel) {
            Text(label, color = look.t.sub, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable
fun RingControls(look: CallLook, onDecline: () -> Unit, onAnswer: () -> Unit) {
    when (look.layout) {
        "swipe" -> SwipeCallControl(look, onDecline, onAnswer)
        "pill" -> Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = .35f))
                .border(1.dp, Color.White.copy(alpha = .18f), RoundedCornerShape(50)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween
        ) {
            CallActionButton(false, look, onDecline, noLabel = true, sizeOverride = 58.dp * look.scale)
            if (look.labels) {
                Text(look.declineText, color = look.t.text, fontSize = 14.sp, maxLines = 1)
                Box(Modifier.width(1.dp).height(22.dp).background(Color.White.copy(alpha = .25f)))
                Text(look.answerText, color = look.t.text, fontSize = 14.sp, maxLines = 1)
            }
            CallActionButton(true, look, onAnswer, noLabel = true, sizeOverride = 58.dp * look.scale)
        }
        else -> Row(Modifier.fillMaxWidth().padding(horizontal = 24.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            CallActionButton(false, look, onDecline)
            CallActionButton(true, look, onAnswer)
        }
    }
}

// =====================================================================
// Notification artwork (RemoteViews can only show bitmaps for custom shapes/colors)
// =====================================================================
object CallNotifArt {
    private fun density(c: Context) = c.resources.displayMetrics.density.coerceAtMost(3.5f)

    private fun drawIcon(c: Context, cv: Canvas, res: Int, color: Int, cx: Float, cy: Float, size: Float) {
        val d = ContextCompat.getDrawable(c, res)?.mutate() ?: return
        DrawableCompat.setTint(d, color)
        d.setBounds((cx - size / 2).toInt(), (cy - size / 2).toInt(), (cx + size / 2).toInt(), (cy + size / 2).toInt())
        d.draw(cv)
    }

    private fun alpha(color: Int, a: Int) = (color and 0x00FFFFFF) or (a shl 24)

    /** Rounded card background. Stretched (fitXY) to the real notification width. */
    fun card(argb: Int): Bitmap {
        val bmp = Bitmap.createBitmap(720, 120, Bitmap.Config.ARGB_8888)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = argb; style = Paint.Style.FILL }
        Canvas(bmp).drawRoundRect(RectF(0f, 0f, 720f, 120f), 30f, 30f, p)
        return bmp
    }

    /** Round caller badge: answer color + phone icon, or decline color + hang-up icon for missed calls. */
    fun badge(c: Context, look: CallLook, missed: Boolean): Bitmap {
        val d = density(c)
        val size = (44 * d).toInt()
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val col = (if (missed) look.decline else look.answer).toArgb()
        cv.drawCircle(size / 2f, size / 2f, size * 0.42f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = col })
        drawIcon(c, cv, if (missed) R.drawable.ic_call_decline else R.drawable.ic_call_answer, look.icon.toArgb(), size / 2f, size / 2f, size * 0.42f)
        return bmp
    }

    fun button(c: Context, look: CallLook, answer: Boolean, labelOverride: String? = null): Bitmap {
        val d = density(c)
        val col = (if (answer) look.answer else look.decline).toArgb()
        val iconColor = if (look.style == "filled") look.icon.toArgb() else col
        val label = labelOverride ?: if (answer) look.answerText else look.declineText
        val base = 38f * look.scale.coerceIn(0.85f, 1.15f) * d
        val margin = 4f * d
        val pillLabel = look.shape == "pill" && look.labels
        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = iconColor; textSize = 13f * d; typeface = Typeface.DEFAULT_BOLD
        }
        val iconSize = base * 0.5f
        val gap = 6f * d
        val textW = if (pillLabel) textPaint.measureText(label) else 0f
        val w = if (pillLabel) base * 0.5f + iconSize + gap + textW + base * 0.1f else base
        val bmp = Bitmap.createBitmap((w + margin * 2).toInt() + 1, (base + margin * 2).toInt() + 1, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val rect = RectF(margin, margin, margin + w, margin + base)
        val r = when (look.shape) { "square" -> 5f * d; "rounded" -> base * 0.3f; else -> base / 2f }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            this.color = when (look.style) { "filled" -> col; "outline" -> alpha(col, 40); else -> alpha(0, 115) }
            if (look.style == "glow") setShadowLayer(margin, 0f, 0f, col)
        }
        cv.drawRoundRect(rect, r, r, fill)
        if (look.style != "filled") {
            val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.6f * d; this.color = col }
            cv.drawRoundRect(rect, r, r, stroke)
        }
        val res = if (answer) R.drawable.ic_call_answer else R.drawable.ic_call_decline
        if (pillLabel) {
            val total = iconSize + gap + textW
            val startX = rect.centerX() - total / 2f
            drawIcon(c, cv, res, iconColor, startX + iconSize / 2f, rect.centerY(), iconSize)
            cv.drawText(label, startX + iconSize + gap, rect.centerY() - (textPaint.ascent() + textPaint.descent()) / 2f, textPaint)
        } else {
            drawIcon(c, cv, res, iconColor, rect.centerX(), rect.centerY(), iconSize)
        }
        return bmp
    }
}
