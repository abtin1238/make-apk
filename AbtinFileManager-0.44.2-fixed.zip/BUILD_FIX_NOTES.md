# Android build repair

- Updated Android Gradle Plugin from 8.11.1 to 9.1.1, matching the minimum required by the Flutter SDK shown in the supplied CI logs.
- Updated Kotlin Gradle Plugin from 2.2.20 to 2.3.20 for alignment with the AGP 9.1 toolchain.
- Kept the existing Gradle 9.3.1 wrapper, Java 17 bytecode target, app IDs, signing fallback, and application features unchanged.

Build verification: source/configuration checks and ZIP integrity passed. A full APK build could not be run in this environment because the Flutter SDK is not installed.
