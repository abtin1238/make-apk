import 'package:flutter/material.dart';

import '../core/layouts.dart' show tr2;
import '../services/claude_settings.dart';

/// Claude Code sign-in settings. Returns true when the user saved (so the caller may start Claude Code).
Future<bool> showClaudeSettings(BuildContext context, {bool startLabel = false}) async {
  await ClaudeSettings.load();
  if (!context.mounted) return false;
  final r = await showDialog<bool>(context: context, builder: (_) => _ClaudeSettingsDialog(startLabel: startLabel));
  return r == true;
}

class _ClaudeSettingsDialog extends StatefulWidget {
  const _ClaudeSettingsDialog({required this.startLabel});
  final bool startLabel;

  @override
  State<_ClaudeSettingsDialog> createState() => _ClaudeSettingsDialogState();
}

class _ClaudeSettingsDialogState extends State<_ClaudeSettingsDialog> {
  late String _prov = ClaudeSettings.provider ?? 'account';
  late final _key = TextEditingController(text: ClaudeSettings.apiKey);
  late final _url = TextEditingController(text: ClaudeSettings.baseUrl);
  late final _model = TextEditingController(text: ClaudeSettings.model);
  bool _hide = true;

  ClaudeProvider get _p => ClaudeSettings.providers.firstWhere((e) => e.id == _prov);

  @override
  void dispose() {
    _key.dispose();
    _url.dispose();
    _model.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    await ClaudeSettings.save(provider: _prov, apiKey: _key.text, baseUrl: _prov == 'custom' ? _url.text : '', model: _model.text);
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final account = _prov == 'account';
    return AlertDialog(
      title: Text(tr2('ورود به Claude Code', 'Claude Code sign-in')),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          DropdownButtonFormField<String>(
            value: _prov,
            isExpanded: true,
            decoration: InputDecoration(labelText: tr2('سرویس', 'Provider')),
            items: [for (final p in ClaudeSettings.providers) DropdownMenuItem(value: p.id, child: Text(p.name, overflow: TextOverflow.ellipsis))],
            onChanged: (v) => setState(() => _prov = v ?? 'account'),
          ),
          const SizedBox(height: 12),
          if (account)
            Text(tr2('با حساب Claude (اشتراک Pro یا Max) وارد می‌شوید؛ مرورگر خودش باز می‌شود.',
                'Sign in with a Claude account (Pro or Max subscription); the browser opens by itself.'))
          else ...[
            TextField(
              controller: _key,
              obscureText: _hide,
              autocorrect: false,
              enableSuggestions: false,
              decoration: InputDecoration(
                labelText: tr2('کلید API', 'API key'),
                suffixIcon: IconButton(icon: Icon(_hide ? Icons.visibility_rounded : Icons.visibility_off_rounded), onPressed: () => setState(() => _hide = !_hide)),
              ),
            ),
            if (_prov == 'custom') ...[
              const SizedBox(height: 8),
              TextField(controller: _url, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Base URL', hintText: 'https://…/anthropic')),
            ] else if (_p.baseUrl.isNotEmpty)
              Padding(padding: const EdgeInsets.only(top: 8), child: Text(_p.baseUrl, style: const TextStyle(fontSize: 12))),
            const SizedBox(height: 8),
            TextField(
              controller: _model,
              autocorrect: false,
              decoration: InputDecoration(labelText: tr2('مدل (اختیاری)', 'Model (optional)'), hintText: _p.modelHint),
            ),
            const SizedBox(height: 8),
            Text(
              tr2('کلید فقط در حافظهٔ خصوصی همین اپ ذخیره می‌شود و درخواست‌ها (از جمله کدهای پروژه) به سرویس انتخابی فرستاده می‌شوند.',
                  'The key is stored only in this app\'s private storage; requests (including project code) go to the chosen provider.'),
              style: const TextStyle(fontSize: 12),
            ),
          ],
        ]),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: Text(tr2('لغو', 'Cancel'))),
        FilledButton(
          onPressed: (!account && _key.text.trim().isEmpty && _prov != 'custom') ? null : _save,
          child: Text(widget.startLabel ? tr2('ذخیره و شروع', 'Save & start') : tr2('ذخیره', 'Save')),
        ),
      ],
    );
  }
}
