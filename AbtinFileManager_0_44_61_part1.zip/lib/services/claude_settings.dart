import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// One way of signing in to Claude Code.
class ClaudeProvider {
  const ClaudeProvider(this.id, this.name, this.baseUrl, this.modelHint, {this.keyHeaderIsApiKey = false});
  final String id;
  final String name;

  /// Anthropic-compatible endpoint (empty = Claude Code's default).
  final String baseUrl;
  final String modelHint;

  /// true: key goes to ANTHROPIC_API_KEY (Anthropic itself), false: ANTHROPIC_AUTH_TOKEN (other providers).
  final bool keyHeaderIsApiKey;
}

/// Claude Code login settings: own account (Pro/Max) or an API key of Anthropic / another provider that
/// speaks the Anthropic API. Saved in app-private SharedPreferences and written as `~/.abtin-claude.env`
/// inside Termux right before the Claude Code tab opens (the launcher script sources it).
class ClaudeSettings {
  static const providers = <ClaudeProvider>[
    ClaudeProvider('account', 'Claude account (Pro / Max)', '', ''),
    ClaudeProvider('anthropic', 'Anthropic API key (console.anthropic.com)', '', '', keyHeaderIsApiKey: true),
    ClaudeProvider('deepseek', 'DeepSeek', 'https://api.deepseek.com/anthropic', 'deepseek-chat'),
    ClaudeProvider('zai', 'Z.ai (GLM)', 'https://api.z.ai/api/anthropic', 'glm-5.1'),
    ClaudeProvider('kimi', 'Kimi (Moonshot)', 'https://api.moonshot.ai/anthropic', 'kimi-k2.5'),
    ClaudeProvider('openrouter', 'OpenRouter', 'https://openrouter.ai/api', ''),
    ClaudeProvider('custom', 'Custom (Anthropic-compatible URL)', '', ''),
  ];

  static const _kProvider = 'claude_provider';
  static const _kKey = 'claude_api_key';
  static const _kUrl = 'claude_base_url';
  static const _kModel = 'claude_model';

  static String? provider; // null = never configured
  static String apiKey = '';
  static String baseUrl = '';
  static String model = '';

  static bool get configured => provider != null;
  static ClaudeProvider get current => providers.firstWhere((e) => e.id == provider, orElse: () => providers.first);

  static Future<void> load() async {
    final sp = await SharedPreferences.getInstance();
    provider = sp.getString(_kProvider);
    apiKey = sp.getString(_kKey) ?? '';
    baseUrl = sp.getString(_kUrl) ?? '';
    model = sp.getString(_kModel) ?? '';
  }

  static Future<void> save({required String provider, String apiKey = '', String baseUrl = '', String model = ''}) async {
    ClaudeSettings.provider = provider;
    ClaudeSettings.apiKey = apiKey.trim();
    ClaudeSettings.baseUrl = baseUrl.trim();
    ClaudeSettings.model = model.trim();
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_kProvider, provider);
    await sp.setString(_kKey, ClaudeSettings.apiKey);
    await sp.setString(_kUrl, ClaudeSettings.baseUrl);
    await sp.setString(_kModel, ClaudeSettings.model);
  }

  static String _q(String v) => "'${v.replaceAll("'", "'\\''")}'";

  /// Shell text sourced by the Claude Code launcher.
  static String envText() {
    final p = current;
    if (p.id == 'account' || (apiKey.isEmpty && p.id != 'custom')) return '# sign in with a Claude account\n';
    final b = StringBuffer();
    final url = p.id == 'custom' ? baseUrl : (baseUrl.isNotEmpty ? baseUrl : p.baseUrl);
    if (url.isNotEmpty) b.writeln('export ANTHROPIC_BASE_URL=${_q(url)}');
    if (apiKey.isNotEmpty) {
      if (p.keyHeaderIsApiKey) {
        b.writeln('export ANTHROPIC_API_KEY=${_q(apiKey)}');
      } else {
        b.writeln('export ANTHROPIC_AUTH_TOKEN=${_q(apiKey)}');
        if (p.id == 'openrouter') b.writeln("export ANTHROPIC_API_KEY=''");
      }
    }
    if (model.isNotEmpty) b.writeln('export ANTHROPIC_MODEL=${_q(model)}');
    if (!p.keyHeaderIsApiKey && p.id != 'account') b.writeln('export CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC=1');
    return b.toString();
  }

  /// Writes `<files>/usr/termux/files/home/.abtin-claude.env` (the Termux home as seen from the host).
  static Future<void> writeEnv() async {
    final dir = await getApplicationSupportDirectory();
    final home = Directory('${dir.path}/usr/termux/files/home');
    await home.create(recursive: true);
    await File('${home.path}/.abtin-claude.env').writeAsString(envText(), flush: true);
  }
}
