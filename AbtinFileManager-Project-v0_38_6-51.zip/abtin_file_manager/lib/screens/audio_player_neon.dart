part of 'audio_player_screen.dart';

/// "Neon" style of the music player: square cover with a vinyl peeking out behind it,
/// big title, and a FIXED control panel (seek, transport, volume, utilities) pinned to the
/// bottom exactly like the video player. Controls are always left-to-right.
/// On wide screens (tablet / landscape) an "Up Next" panel is shown on the right.
extension _NeonAudio on _AudioPlayerScreenState {
  Widget _ltrWrap(Widget w) => Directionality(
        textDirection: TextDirection.ltr,
        child: DefaultTextStyle.merge(
          style: const TextStyle(color: Colors.white),
          child: IconTheme.merge(
              data: const IconThemeData(color: Colors.white), child: w),
        ),
      );

  Widget _neonBody(PlayerService pl, AppSettings s) {
    final t = PlayerTheme.I;
    return ListenableBuilder(
      listenable: t,
      builder: (context, _) => _ltrWrap(LayoutBuilder(builder: (c, box) {
        final wide = box.maxWidth >= 840;
        final short = box.maxHeight < 640;
        final tall = box.maxHeight >= 800;
        final main = Column(children: [
          _neonTop(pl, t),
          Expanded(child: _neonStage(pl, s, t, short)),
          _neonControls(pl, t, short),
          _neonWave(t, short),
          if (tall && !wide) _neonUpNextCompact(pl, t),
          SizedBox(height: short ? 4 : 10),
        ]);
        return Stack(children: [
          Positioned.fill(child: _neonBg(pl, t)),
          SafeArea(
            child: wide
                ? Row(children: [
                    Expanded(child: main),
                    SizedBox(
                        width: 340,
                        child: Padding(
                            padding: const EdgeInsets.fromLTRB(0, 12, 12, 12),
                            child: _neonUpNext(pl, t))),
                  ])
                : main,
          ),
        ]);
      })),
    );
  }

  Widget _neonBg(PlayerService pl, PlayerTheme t) {
    final art = pl.meta?.art;
    return Stack(fit: StackFit.expand, children: [
      const ColoredBox(color: Color(0xFF05030F)),
      if (art != null && t.blur)
        Opacity(
          opacity: .35,
          child: ImageFiltered(
            imageFilter: ui.ImageFilter.blur(sigmaX: 40, sigmaY: 40),
            child: Image.memory(art,
                fit: BoxFit.cover,
                gaplessPlayback: true,
                errorBuilder: (_, __, ___) => const SizedBox()),
          ),
        ),
      DecoratedBox(
          decoration: BoxDecoration(
              gradient: RadialGradient(
                  center: const Alignment(.6, -.5),
                  radius: 1.2,
                  colors: [
            t.accent.withOpacity(.30 * (.4 + t.glow * .6)),
            Colors.transparent
          ]))),
      DecoratedBox(
          decoration: BoxDecoration(
              gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
            Colors.black.withOpacity(.25),
            Colors.black.withOpacity(.78)
          ]))),
    ]);
  }

  Widget _neonTop(PlayerService pl, PlayerTheme t) => Padding(
        padding: const EdgeInsets.fromLTRB(8, 6, 8, 0),
        child: Row(children: [
          BareIcon(t, Icons.arrow_back_ios_new_rounded,
              () => Navigator.pop(context),
              size: 22),
          Expanded(
            child: Center(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.graphic_eq_rounded, size: 30, color: t.accent),
                  const SizedBox(width: 8),
                  const Text('Aptin Music',
                      style:
                          TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                ]),
              ),
            ),
          ),
          BareIcon(
              t,
              Icons.equalizer_rounded,
              () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const EqualizerScreen())),
              size: 24,
              pad: 8),
          BareIcon(t, Icons.palette_rounded, () => showPlayerThemeSheet(context),
              size: 24, pad: 8, tip: L.t('vpTheme')),
          _moreMenu(pl, color: Colors.white, full: true),
        ]),
      );

  Widget _neonStage(PlayerService pl, AppSettings s, PlayerTheme t, bool short) {
    if (showLyrics && lrc != null) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
        child: _lyrics(pl, hi: t.highlight),
      );
    }
    return Column(children: [
      Expanded(
        child: LayoutBuilder(builder: (c, b) {
          final side = math
              .min(b.maxWidth * .72, b.maxHeight - 12)
              .clamp(100.0, 460.0)
              .toDouble();
          return Center(child: _neonArt(pl, t, side));
        }),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(24, 6, 24, 2),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(pl.title,
              maxLines: 1,
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: short ? 24 : 32,
                  fontWeight: FontWeight.w800,
                  height: 1.15)),
          const SizedBox(height: 2),
          Text(pl.artist.isEmpty ? '—' : pl.artist,
              maxLines: 1,
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontSize: short ? 17 : 22,
                  fontWeight: FontWeight.w800,
                  color: t.accent)),
          if (!short && pl.album.isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text.rich(
                  TextSpan(children: [
                    TextSpan(text: '${L.t('fromAlbum')} '),
                    TextSpan(
                        text: pl.album,
                        style: const TextStyle(fontStyle: FontStyle.italic))
                  ]),
                  maxLines: 1,
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 15, color: t.highlight.withOpacity(.75))),
            ),
        ]),
      ),
    ]);
  }

  Widget _neonArt(PlayerService pl, PlayerTheme t, double side) {
    final art = pl.meta?.art;
    final note = Icon(Icons.music_note_rounded,
        size: side * .35, color: Colors.white70);
    return Container(
      width: side,
      height: side,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(side * .09),
        gradient: t.gradient,
        border: Border.all(color: t.accent.withOpacity(.9), width: 1.6),
        boxShadow: [
          BoxShadow(
              color: t.accent.withOpacity(.55 * t.glow),
              blurRadius: 40,
              spreadRadius: -2)
        ],
      ),
      child: art != null
          ? Image.memory(art,
              fit: BoxFit.cover,
              gaplessPlayback: true,
              errorBuilder: (_, __, ___) => note)
          : note,
    );
  }

  /// Fixed bottom area: never scrolls, never moves, always left-to-right.
  Widget _neonControls(PlayerService pl, PlayerTheme t, bool short) {
    final hasLrc = lrc != null;
    final fav = context.read<AppSettings>().isFav(pl.current);
    return Padding(
      padding: const EdgeInsets.fromLTRB(22, 4, 22, 0),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        _neonSeek(pl, t),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          BareIcon(t, Icons.shuffle_rounded, pl.toggleShuffle,
              on: pl.shuffle, size: 28),
          BareIcon(t, Icons.skip_previous_rounded, pl.player.previous,
              size: 44),
          NeonPlay(
              t: t,
              playing: pl.playing,
              onTap: pl.player.playOrPause,
              size: short ? 64 : 78),
          BareIcon(t, Icons.skip_next_rounded, pl.player.next, size: 44),
          BareIcon(
              t,
              pl.mode == PlaylistMode.single
                  ? Icons.repeat_one_rounded
                  : Icons.repeat_rounded,
              pl.cycleMode,
              on: pl.mode != PlaylistMode.none,
              size: 28),
        ]),
        Row(children: [
          BareIcon(
              t,
              pl.volume == 0
                  ? Icons.volume_off_rounded
                  : Icons.volume_up_rounded,
              () => pl.setVolume(pl.volume == 0 ? 100 : 0),
              size: 22,
              pad: 8),
          Expanded(
            child: SliderTheme(
              data: SliderTheme.of(context).copyWith(
                  trackHeight: 3,
                  activeTrackColor: t.accent,
                  inactiveTrackColor: Colors.white24,
                  thumbColor: t.highlight,
                  overlayColor: t.accent.withOpacity(.2),
                  thumbShape:
                      const RoundSliderThumbShape(enabledThumbRadius: 6),
                  overlayShape:
                      const RoundSliderOverlayShape(overlayRadius: 14)),
              child: Slider(
                  value: pl.volume.clamp(0.0, 100.0).toDouble(),
                  max: 100,
                  onChanged: pl.setVolume),
            ),
          ),
          BareIcon(
              t,
              fav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
              () => context.read<AppSettings>().toggleFav(pl.current),
              on: fav,
              size: 22,
              pad: 8),
          BareIcon(
              t,
              Icons.article_outlined,
              hasLrc ? _toggleLyrics : () => _addLyrics(pl),
              on: hasLrc && showLyrics,
              size: 22,
              pad: 8,
              tip: L.t('lyrics')),
          BareIcon(t, Icons.bedtime_rounded, () => _sleepMenu(pl),
              on: pl.sleepActive, size: 22, pad: 8, tip: L.t('sleepTimer')),
          BareIcon(t, Icons.graphic_eq_rounded,
              pl.hasQueue ? _toggleVisualizer : null,
              on: visualizerOn, size: 22, pad: 8, tip: L.t('visualizer')),
          BareIcon(t, Icons.queue_music_rounded, _queue,
              size: 22, pad: 8, tip: L.t('nextQueue')),
        ]),
      ]),
    );
  }

  /// Neon spectrum bars with a soft reflection (tap = switch the visualizer on / off).
  Widget _neonWave(PlayerTheme t, bool short) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _toggleVisualizer,
        child: SizedBox(
          height: short ? 44 : 78,
          width: double.infinity,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 18),
            child: CustomPaint(
                painter: _NeonBarsPainter(
                    visualizerOn ? _spectrum : const <double>[],
                    t.accent,
                    t.highlight,
                    t.glow)),
          ),
        ),
      );

  /// "Up Next" card of the design: the next two tracks + a link to the full queue.
  Widget _neonUpNextCompact(PlayerService pl, PlayerTheme t) {
    final next = <int>[
      for (var k = 1; k <= 2; k++)
        if (pl.index + k < pl.queue.length) pl.index + k
    ];
    if (next.isEmpty) return const SizedBox();
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
      child: Glass(
        t: t,
        radius: 22,
        padding: const EdgeInsets.fromLTRB(14, 10, 8, 6),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            Expanded(
                child: Text(L.t('upNext'),
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w800))),
            GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: _queue,
              child: Padding(
                padding: const EdgeInsets.all(6),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text(L.t('nextQueue'),
                      style: const TextStyle(color: Colors.white60)),
                  const Icon(Icons.chevron_right_rounded,
                      color: Colors.white60),
                ]),
              ),
            ),
          ]),
          for (final i in next)
            InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => pl.player.jump(i),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Row(children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        gradient: t.gradient),
                    child: const Icon(Icons.music_note_rounded,
                        color: Colors.white70, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                        p.basenameWithoutExtension(Uri.decodeFull(pl.queue[i])),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600)),
                  ),
                  const Icon(Icons.more_vert_rounded, color: Colors.white54),
                ]),
              ),
            ),
        ]),
      ),
    );
  }

  Widget _neonSeek(PlayerService pl, PlayerTheme t) =>
      StreamBuilder<Duration>(
        stream: pl.player.stream.position,
        builder: (c, snap) {
          final pos = snap.data ?? Duration.zero;
          final dur = pl.player.state.duration;
          final max =
              dur.inMilliseconds.toDouble().clamp(1, double.infinity).toDouble();
          final v = (_drag ?? pos.inMilliseconds.toDouble())
              .clamp(0, max)
              .toDouble();
          const ts = TextStyle(
              fontSize: 12.5,
              color: Colors.white70,
              fontFeatures: [ui.FontFeature.tabularFigures()]);
          return Column(children: [
            SliderTheme(
              data: SliderTheme.of(context).copyWith(
                  trackHeight: 4,
                  activeTrackColor: t.highlight,
                  inactiveTrackColor: Colors.white24,
                  thumbColor: Colors.white,
                  overlayColor: t.accent.withOpacity(.2),
                  thumbShape:
                      const RoundSliderThumbShape(enabledThumbRadius: 7),
                  overlayShape:
                      const RoundSliderOverlayShape(overlayRadius: 16)),
              child: Slider(
                value: v,
                max: max,
                onChanged: (x) => _setDrag(x),
                onChangeEnd: (x) {
                  pl.player.seek(Duration(milliseconds: x.round()));
                  _setDrag(null);
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 6),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(_t(Duration(milliseconds: v.round())), style: ts),
                    Text(_t(dur), style: ts)
                  ]),
            ),
          ]);
        },
      );

  Widget _neonUpNext(PlayerService pl, PlayerTheme t) => Glass(
        t: t,
        radius: 26,
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 16, 12, 8),
            child: Row(children: [
              Expanded(
                  child: Text(L.t('upNext'),
                      style: const TextStyle(
                          fontSize: 17, fontWeight: FontWeight.w700))),
              Text('${pl.index + 1}/${pl.queue.length}',
                  style: const TextStyle(color: Colors.white60)),
            ]),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.fromLTRB(8, 0, 8, 10),
              itemCount: pl.queue.length,
              itemExtent: 60,
              itemBuilder: (c, i) {
                final cur = i == pl.index;
                return InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () => pl.player.jump(i),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: cur ? t.accent.withOpacity(.28) : null),
                    child: Row(children: [
                      SizedBox(
                          width: 28,
                          child: cur
                              ? Icon(Icons.graphic_eq_rounded,
                                  size: 20, color: t.highlight)
                              : Text('${i + 1}',
                                  style:
                                      const TextStyle(color: Colors.white54))),
                      Expanded(
                        child: Text(
                            p.basenameWithoutExtension(
                                Uri.decodeFull(pl.queue[i])),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontWeight:
                                    cur ? FontWeight.w700 : FontWeight.w500)),
                      ),
                    ]),
                  ),
                );
              },
            ),
          ),
        ]),
      );

  // ======================= "Classic dark" and "Warm gold" styles =======================
  Widget _proBody(PlayerService pl, AppSettings s, _ProPalette P) {
    return _ltrWrap(LayoutBuilder(builder: (c, box) {
      final short = box.maxHeight < 640;
      final col = Column(children: [
        _proTop(pl, s, P),
        Expanded(child: _proStage(pl, P, short)),
        _proSeek(pl, P),
        _proTransport(pl, P, short),
        _proWave(P, short),
        _proNav(pl, P),
      ]);
      return DecoratedBox(
        decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: P.bg)),
        child: SafeArea(
          bottom: false,
          child: Center(
              child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 560),
                  child: col)),
        ),
      );
    }));
  }

  Widget _proTop(PlayerService pl, AppSettings s, _ProPalette P) {
    final fav = s.isFav(pl.current);
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 0),
      child: Row(children: [
        IconButton(
            icon: Icon(Icons.arrow_back_ios_new_rounded,
                color: P.accent, size: 22),
            onPressed: () => Navigator.pop(context)),
        Expanded(
            child: Text(L.t('nowPlaying'),
                textAlign: TextAlign.center,
                style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w600,
                    color: P.title))),
        IconButton(
            icon: Icon(
                fav ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                color: fav ? P.accent : P.sub),
            onPressed: () => s.toggleFav(pl.current)),
        _moreMenu(pl, color: P.accent, full: true),
      ]),
    );
  }

  Widget _proStage(PlayerService pl, _ProPalette P, bool short) {
    final title = Padding(
      padding: EdgeInsets.fromLTRB(24, short ? 4 : 8, 24, short ? 4 : 10),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Text(pl.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: short ? 24 : 30,
                fontWeight: FontWeight.w700,
                color: P.title)),
        const SizedBox(height: 4),
        Text(pl.artist.isEmpty ? '—' : pl.artist,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: short ? 16 : 20, color: P.sub)),
      ]),
    );
    if (showLyrics && lrc != null) {
      return Column(children: [
        Expanded(
            child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 8, 24, 0),
                child: _lyrics(pl, hi: P.accent))),
        title,
      ]);
    }
    return Column(children: [
      Expanded(
        child: LayoutBuilder(builder: (c, b) {
          final k = P.vinyl ? .72 : .88;
          final side = math
              .min(b.maxWidth * k, b.maxHeight - 8)
              .clamp(100.0, 480.0)
              .toDouble();
          return Center(
            child: SizedBox(
              width: P.vinyl ? side * 1.22 : side,
              height: side,
              child: Stack(clipBehavior: Clip.none, children: [
                if (P.vinyl)
                  Positioned(
                    right: 0,
                    top: side * .06,
                    child: RotationTransition(
                      turns: spin,
                      child: CustomPaint(
                          size: Size.square(side * .88),
                          painter: _VinylPainter(P.accent, P.accent2)),
                    ),
                  ),
                Positioned(left: 0, top: 0, child: _proArt(pl, P, side)),
              ]),
            ),
          );
        }),
      ),
      title,
    ]);
  }

  Widget _proArt(PlayerService pl, _ProPalette P, double side) {
    final art = pl.meta?.art;
    final note = Center(
        child: Icon(Icons.music_note_rounded,
            size: side * .3, color: P.title.withOpacity(.7)));
    return Container(
      width: side,
      height: side,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(side * .07),
        gradient: LinearGradient(
            colors: [P.accent2, P.navBg],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight),
        border: Border.all(color: P.border, width: 1.5),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(.5),
              blurRadius: 30,
              offset: const Offset(0, 12))
        ],
      ),
      child: art != null
          ? Image.memory(art,
              fit: BoxFit.cover,
              gaplessPlayback: true,
              errorBuilder: (_, __, ___) => note)
          : note,
    );
  }

  Widget _proSeek(PlayerService pl, _ProPalette P) => StreamBuilder<Duration>(
        stream: pl.player.stream.position,
        builder: (c, snap) {
          final pos = snap.data ?? Duration.zero;
          final dur = pl.player.state.duration;
          final max =
              dur.inMilliseconds.toDouble().clamp(1, double.infinity).toDouble();
          final v = (_drag ?? pos.inMilliseconds.toDouble())
              .clamp(0, max)
              .toDouble();
          final shown = Duration(milliseconds: v.round());
          final remain = P.remain != remainFlip;
          final left = dur - shown;
          final right = remain
              ? '-${_t(left < Duration.zero ? Duration.zero : left)}'
              : _t(dur);
          final ts = TextStyle(
              fontSize: 14,
              color: P.sub,
              fontFeatures: const [ui.FontFeature.tabularFigures()]);
          return Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
            child: Column(children: [
              SliderTheme(
                data: SliderTheme.of(context).copyWith(
                    trackHeight: 4,
                    activeTrackColor: P.accent,
                    inactiveTrackColor: P.track,
                    thumbColor: P.accent,
                    overlayColor: P.accent.withOpacity(.18),
                    thumbShape: const RoundSliderThumbShape(
                        enabledThumbRadius: 8, elevation: 0, pressedElevation: 0),
                    overlayShape:
                        const RoundSliderOverlayShape(overlayRadius: 18)),
                child: Slider(
                  value: v,
                  max: max,
                  onChanged: (x) => _setDrag(x),
                  onChangeEnd: (x) {
                    pl.player.seek(Duration(milliseconds: x.round()));
                    _setDrag(null);
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(_t(shown), style: ts),
                      GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onTap: _toggleRemain,
                          child: Padding(
                              padding: const EdgeInsets.only(left: 16),
                              child: Text(right, style: ts))),
                    ]),
              ),
            ]),
          );
        },
      );

  Widget _proTransport(PlayerService pl, _ProPalette P, bool short) {
    final d = short ? 70.0 : 84.0;
    Widget ic(IconData i, VoidCallback? f, {Color? c, double z = 36}) =>
        IconButton(
            iconSize: z,
            padding: const EdgeInsets.all(10),
            icon: Icon(i, color: c ?? P.icon),
            onPressed: f);
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 6, 14, 6),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        ic(Icons.shuffle_rounded, pl.toggleShuffle,
            c: pl.shuffle ? P.accent : P.sub, z: 26),
        ic(Icons.skip_previous_rounded, pl.player.previous, z: 42),
        GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: pl.player.playOrPause,
          child: Container(
            width: d,
            height: d,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: P.accent, width: 2.5),
                boxShadow: [
                  BoxShadow(
                      color: P.accent.withOpacity(.4),
                      blurRadius: 22,
                      spreadRadius: -2)
                ]),
            child: Icon(
                pl.playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
                size: d * .52,
                color: P.icon),
          ),
        ),
        ic(Icons.skip_next_rounded, pl.player.next, z: 42),
        ic(
            pl.mode == PlaylistMode.single
                ? Icons.repeat_one_rounded
                : Icons.repeat_rounded,
            pl.cycleMode,
            c: pl.mode != PlaylistMode.none ? P.accent : P.sub,
            z: 26),
      ]),
    );
  }

  /// Mirrored thin-bar waveform. Shows the live spectrum when the visualizer is on
  /// (tap it to switch on/off), otherwise a quiet dotted line.
  Widget _proWave(_ProPalette P, bool short) => GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _toggleVisualizer,
        child: SizedBox(
          height: short ? 40 : 58,
          width: double.infinity,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: CustomPaint(
                painter: _MirrorPainter(
                    visualizerOn ? _spectrum : const <double>[],
                    P.accent,
                    P.accent2)),
          ),
        ),
      );

  Widget _proNav(PlayerService pl, _ProPalette P) {
    final hasLrc = lrc != null;
    final bottom = MediaQuery.of(context).padding.bottom;
    Widget item(IconData i, bool on, VoidCallback? f) => Expanded(
          child: GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: f,
            child: SizedBox(
              height: 58,
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(i, size: 27, color: on ? P.accent : P.sub),
                const SizedBox(height: 6),
                if (P.underline)
                  Container(
                      width: 40,
                      height: 3,
                      decoration: BoxDecoration(
                          color: on ? P.accent : Colors.transparent,
                          borderRadius: BorderRadius.circular(2)))
                else
                  Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: on ? P.accent : Colors.transparent)),
              ]),
            ),
          ),
        );
    return Container(
      padding: EdgeInsets.only(bottom: bottom, top: 6),
      decoration: BoxDecoration(
        color: P.navBg,
        borderRadius: P.underline
            ? const BorderRadius.vertical(top: Radius.circular(32))
            : null,
        border: P.underline
            ? Border.all(color: P.border.withOpacity(.7))
            : Border(top: BorderSide(color: P.border.withOpacity(.7))),
      ),
      child: Row(children: [
        item(Icons.music_note_rounded, !(showLyrics && hasLrc),
            showLyrics ? _toggleLyrics : null),
        item(Icons.lyrics_rounded, showLyrics && hasLrc,
            hasLrc ? _toggleLyrics : () => _addLyrics(pl)),
        item(
            Icons.equalizer_rounded,
            false,
            () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const EqualizerScreen()))),
        item(Icons.queue_music_rounded, false, _queue),
      ]),
    );
  }
}

/// Black vinyl record with grooves and a neon-gradient label (rotates while playing).
class _VinylPainter extends CustomPainter {
  final Color a, b;
  _VinylPainter(this.a, this.b);

  @override
  void paint(Canvas canvas, Size s) {
    final ctr = s.center(Offset.zero);
    final r = s.width / 2;
    canvas.drawCircle(
        ctr,
        r,
        Paint()
          ..shader = const RadialGradient(
                  colors: [Color(0xFF1B1B26), Color(0xFF050509)])
              .createShader(Rect.fromCircle(center: ctr, radius: r)));
    final groove = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = Colors.white.withOpacity(.05);
    for (var k = .38; k < .98; k += .045) {
      canvas.drawCircle(ctr, r * k, groove);
    }
    canvas.drawArc(
        Rect.fromCircle(center: ctr, radius: r * .78),
        -.9,
        .7,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = r * .3
          ..color = Colors.white.withOpacity(.035));
    final label = Rect.fromCircle(center: ctr, radius: r * .3);
    canvas.drawCircle(
        ctr,
        r * .3,
        Paint()
          ..shader = LinearGradient(
                  colors: [a, b],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight)
              .createShader(label));
    canvas.drawCircle(ctr, r * .05, Paint()..color = const Color(0xFF05030F));
    canvas.drawCircle(
        ctr,
        r,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2
          ..color = a.withOpacity(.5));
  }

  @override
  bool shouldRepaint(covariant _VinylPainter o) => o.a != a || o.b != b;
}

/// Colours of the "Classic dark" and "Warm gold" player styles.
class _ProPalette {
  final List<Color> bg;
  final Color accent, accent2, title, sub, icon, track, border, navBg;
  final bool vinyl, remain, underline;
  const _ProPalette({
    required this.bg,
    required this.accent,
    required this.accent2,
    required this.title,
    required this.sub,
    required this.icon,
    required this.track,
    required this.border,
    required this.navBg,
    this.vinyl = false,
    this.remain = false,
    this.underline = true,
  });

  static const dark = _ProPalette(
    bg: [Color(0xFF14213D), Color(0xFF08101F), Color(0xFF050912)],
    accent: Color(0xFF4FC3F7),
    accent2: Color(0xFF3B4C7A),
    title: Color(0xFFEAF2FF),
    sub: Color(0xFF8793AD),
    icon: Color(0xFFDCE8FF),
    track: Color(0xFF2C3A55),
    border: Color(0xFF30436B),
    navBg: Color(0xFF0C1528),
  );

  static const warm = _ProPalette(
    bg: [Color(0xFF131313), Color(0xFF0A0A0A)],
    accent: Color(0xFFE9B565),
    accent2: Color(0xFF6B4A22),
    title: Color(0xFFFFF3E0),
    sub: Color(0xFF9C8466),
    icon: Color(0xFFFFF1DC),
    track: Color(0xFF3A342B),
    border: Color(0xFF3B3226),
    navBg: Color(0xFF0A0A0A),
    vinyl: true,
    remain: true,
    underline: false,
  );
}

/// Mirrored thin bars (like a waveform) with faded ends; dots when there is no data.
class _MirrorPainter extends CustomPainter {
  final List<double> v;
  final Color a, b;
  _MirrorPainter(this.v, this.a, this.b);

  @override
  void paint(Canvas canvas, Size s) {
    const n = 64;
    final mid = s.height / 2;
    final step = s.width / n;
    for (var i = 0; i < n; i++) {
      final x = step * (i + .5);
      final env = math.sin(math.pi * (i + .5) / n);
      var amp = 0.0;
      if (v.isNotEmpty) {
        amp = v[(i * v.length ~/ n).clamp(0, v.length - 1).toInt()].clamp(0.0, 1.0).toDouble();
      }
      final col = Color.lerp(a, b, i / n)!;
      if (amp <= .02) {
        canvas.drawCircle(Offset(x, mid), 1.1,
            Paint()..color = col.withOpacity((.2 + .5 * env).clamp(0.0, 1.0).toDouble()));
        continue;
      }
      final h = (s.height * .5 * (.12 + .88 * amp) * (.45 + .55 * env))
          .clamp(1.5, s.height / 2)
          .toDouble();
      canvas.drawLine(
          Offset(x, mid - h),
          Offset(x, mid + h),
          Paint()
            ..color = col.withOpacity((.3 + .7 * env).clamp(0.0, 1.0).toDouble())
            ..strokeWidth = 2.2
            ..strokeCap = StrokeCap.round);
    }
  }

  @override
  bool shouldRepaint(covariant _MirrorPainter o) =>
      o.v != v || o.a != a || o.b != b;
}


/// Centered neon bars (tall in the middle, like the design) with a faded reflection underneath.
class _NeonBarsPainter extends CustomPainter {
  final List<double> values;
  final Color lo, hi;
  final double glow;
  _NeonBarsPainter(this.values, this.lo, this.hi, this.glow);

  static const _n = 56;

  double _at(int i) {
    final x = i / (_n - 1);
    if (values.isEmpty) {
      // idle: a calm bell-shaped silhouette
      return .05 + .30 * math.exp(-math.pow((x - .5) / .2, 2).toDouble());
    }
    final f = x * (values.length - 1);
    final a = f.floor().clamp(0, values.length - 1);
    final b = (a + 1).clamp(0, values.length - 1);
    final v = values[a] + (values[b] - values[a]) * (f - a);
    return v.clamp(0.0, 1.0).toDouble();
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;
    final base = size.height * .70;
    final slot = size.width / _n;
    final w = math.max(1.5, slot * .42);
    final live = values.isNotEmpty;
    final shader = ui.Gradient.linear(Offset(0, base), Offset(0, 0), [lo, hi]);
    final fill = Paint()..shader = shader;
    final halo = Paint()
      ..shader = shader
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 5 + 4 * glow);
    final refl = Paint()
      ..shader = ui.Gradient.linear(Offset(0, base), Offset(0, size.height),
          [lo.withOpacity(.35), Colors.transparent]);
    for (var i = 0; i < _n; i++) {
      final v = _at(i);
      final h = math.max(2.0, base * (.04 + v * .96));
      final cx = slot * (i + .5);
      final r = RRect.fromRectAndRadius(
          Rect.fromLTWH(cx - w / 2, base - h, w, h), Radius.circular(w / 2));
      if (live && glow > 0) {
        canvas.drawRRect(r, halo);
      }
      canvas.drawRRect(r, fill);
      final rh = math.min(size.height - base, h * .45);
      canvas.drawRRect(
          RRect.fromRectAndRadius(Rect.fromLTWH(cx - w / 2, base + 2, w, rh),
              Radius.circular(w / 2)),
          refl);
    }
    canvas.drawRect(Rect.fromLTWH(0, base, size.width, 1),
        Paint()..color = lo.withOpacity(.35));
  }

  @override
  bool shouldRepaint(covariant _NeonBarsPainter o) =>
      o.values != values || o.lo != lo || o.hi != hi || o.glow != glow;
}
