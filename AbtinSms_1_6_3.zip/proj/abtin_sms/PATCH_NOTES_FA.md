## نسخه 1.6.26
- رنگ متن اعلان ثابت روشن شد (رنگ تم سیستم روی کارت تیره خاکستری تیره می‌شد) و پس‌زمینهٔ دکمهٔ «پاسخ» دوباره پررنگ شد

## نسخه 1.6.25
- متن اعلان (فرستنده/متن پیام و تماس) با استایل‌های خود سیستم (TextAppearance.Compat.Notification) و چپ‌چین مثل اعلان‌های گوشی؛ فقط دکمه‌ها سفارشی‌اند

## نسخه 1.6.24
- کارت اعلان (نسخهٔ دکمه‌دار پیامک و کارت تماس مجدد/پایان تماس) بدون بک‌گراند و کادر؛ فقط متن و دکمه‌ها؛ رنگ متن از تم سیستم

## نسخه 1.6.23
- margin منفی تمام‌عرض (1.6.22) برداشته شد: MIUI/HyperOS محتوای سفارشی را از لبهٔ ستون آیکون کلیپ می‌کند و سمت چپ کارت بریده می‌شد

## نسخه 1.6.22
- کارت اعلان (پیامک، تماس مجدد، پایان تماس) به‌جای سه‌چهارم عرض، تمام‌عرض می‌شود: margin منفی شروع به اندازهٔ ستون آیکون (NOTIF_GUTTER_DP در Core.kt، فقط API 31+)
- versionCode=44 / versionName=1.6.22

## نسخه 1.6.21
- تماسی که طرف مقابل قطع می‌کند دیگر در اعلان «تماس جاری» نمی‌ماند: هنگام DISCONNECTED/DISCONNECTING اعلان‌های زنگ و جاری لغو می‌شوند و دوباره ساخته نمی‌شوند (Call.kt: notifyCall / onCallRemoved)
- «تماس مجدد» (تماس ازدست‌رفته) و «پایان تماس» (تماس جاری) حالا دکمهٔ واقعی داخل کارت اعلان هستند (notification_call_row.xml، notif_btn_green / notif_btn_red) نه متن ساده‌ی Action سیستم
- اعلان پیامک: متن «پاسخ» پایین کارت (Action سیستم) حذف شد؛ دکمهٔ «پاسخ» داخل کارت می‌ماند. اگر کارت سفارشی ساخته نشود، Action پاسخ سیستم (با پاسخ درون‌خطی) به‌عنوان جایگزین اضافه می‌شود
- دکمهٔ «کپی کد»: به‌جای BroadcastReceiver (در پس‌زمینه روی MIUI/HyperOS کلیپ‌بورد بلاک می‌شود) با Activity شفاف CopyCodeActivity کپی می‌کند
- versionCode=43 / versionName=1.6.21

## نسخه 1.6.20
- علت واقعی نیامدن کارت اعلان پیامک (طبق لاگ): `<View>` ساده در لی‌اوت RemoteViews مجاز نیست (Class not allowed to be inflated android.view.View) و اعلان به حالت ساده برمی‌گشت. خط جداکننده در notification_message_actions و notification_message_expanded با FrameLayout عوض شد
- versionCode=42 / versionName=1.6.20

## نسخه 1.6.19
- کانال‌های اعلان تماس («تماس ورودی»، «تماس جاری») حالا هنگام باز شدن برنامه ساخته می‌شوند؛ قبلاً فقط با اولین اعلان تماس ساخته می‌شدند و تا آن موقع در تنظیمات اعلان گوشی دیده نمی‌شدند
- versionCode=41 / versionName=1.6.19

## نسخه 1.6.18
- به‌روزرسانی: فقط نام زیپ (AbtinSms…) و ورژن انتهای نام (مثل AbtinSms-1_6_18.zip) در نظر گرفته می‌شود؛ بیلد/versionCode و تگ GitHub و پسوند ABI الزامی نیست
- اعلان: قبل از ارسال، لی‌اوت کارت داخل خود برنامه inflate می‌شود؛ اگر خراب بود یا ۱.۲ ثانیه بعد اعلان در لیست فعال‌ها نبود، اعلان استاندارد نشان داده می‌شود
- versionCode=40 / versionName=1.6.18

## نسخه 1.6.17
- اصلاح چیدمان اعلان پیامک مطابق طرح: حذف ردیف تکراری آواتار/عنوان (هدر را خود سیستم نشان می‌دهد)، حذف آیکن بزرگ (عرض کارت را کوچک می‌کرد و دکمه‌ها گرد/بریده می‌شدند)، حذف RTL روی ریشه
- شماره/نام فرستنده بالا وسط، متن، سه دکمه هم‌عرض (تماس / کپی کد / خواندن)، خط جداکننده و دکمه پاسخ
- دکمه‌های مخفی (مثلاً کپی کد وقتی کد نیست) جایشان را آزاد می‌کنند
- versionCode=39 / versionName=1.6.17

# تغییرات نسخهٔ 1.6.3

- زمان‌بندی ارسال: دکمه‌های بالا/پایین «دقیقه» حالا ۱ دقیقه‌ای حرکت می‌کنند (قبلاً ۵ دقیقه‌ای). فایل: `Send.kt`
- USSD: فیلتر `ACTION_CALL` از `PhoneActivity` حذف شد (مسیر قدیمی USSD ممکن بود به خود برنامه برسد و نادیده گرفته شود)؛ ارسال با `placeCall` مثل تماس عادی انجام می‌شود، صفحهٔ تماس آبتین روی پنجرهٔ پاسخ USSD باز نمی‌شود و `sendUssdRequest` آخرین راه است. فایل‌ها: `AndroidManifest.xml`, `Call.kt`
- اعلان پیامک: کانال جدید (v2) با صدا و لرزش پیش‌فرض خود اندروید (بدون صدا یا الگوی لرزش اختصاصی برنامه)؛ فقط اگر در تنظیمات صدایی انتخاب شده باشد همان استفاده می‌شود. اعلان ساده همیشه ساخته می‌شود و خطا در اعلان گیرندهٔ پیامک را متوقف نمی‌کند. فایل: `Core.kt`
- versionCode=24 / versionName=1.6.2 (برای نصب روی نسخهٔ قبلی)
- تماس ورودی: وقتی گوشی در حال استفاده و باز است فقط اعلان بالای صفحه (heads-up) نمایش داده می‌شود و صفحهٔ تماس روی برنامهٔ دیگر باز نمی‌شود؛ با لمس اعلان باز می‌شود. در حالت قفل/خاموش بودن صفحه همان تمام‌صفحه قبلی می‌ماند. فایل: `Call.kt`, `Settings.kt`
- انیمیشن صفحهٔ تماس: در حالت «کشیدنی» دکمهٔ وسط آرام کمی به راست (پاسخ) و بعد چپ (رد) تکان می‌خورد؛ در حالت دو دکمه‌ای هر دکمه کمی به سمت خودش حرکت می‌کند. فایل‌ها: `Call.kt`, `CallTheme.kt`
- versionCode=25 / versionName=1.6.3

## 1.6.4
- In-app debug log (Settings > Notifications > Debug log): state dump + receiver/notifier trace, copy/share.
- Notification channel v3 with explicit default sound + vibration; manual sound/vibrate fallback; plain-notification fallback.
- Real back stack: phone Back / arrow returns exactly one step (chat -> previous screen).

## 1.6.5
- SMS app: Contacts tab hidden by default (contacts still shown in New message picker). Settings > General > Sections > "Show Contacts section" brings it back.

## 1.6.6
- Xiaomi/MIUI: "Guaranteed sound & vibration" (default on for Xiaomi): silent channel + app plays tone/vibration itself. Button to Xiaomi special permissions.

## 1.6.7 - 1.6.9
- Play Protect: removed SYSTEM_ALERT_WINDOW and REQUEST_IGNORE_BATTERY_OPTIMIZATIONS permissions, allowBackup=false.
- Location permission kept: the app asks for it at runtime only when the user taps "share location" in a chat.
- Signing key lives in GitHub secrets; no keystore / key.properties in the project (build.gradle.kts reads key.properties only if the CI creates it).

## 1.6.10
- Call recording restored (direct call stream first, opt-in mic fallback). The microphone permission is no longer asked at startup: it is asked in-app when the user turns on auto-record or taps record in a call.

## 1.6.11
- Call recording: mic/speaker fallback dialog removed; only direct call-stream recording. Failure reason is written to the in-app debug log. RECORD_AUDIO asked in-app at startup again.

## 1.6.12
- Xiaomi channel uses a bundled 200 ms zero-amplitude clip plus a 1 ms vibration pattern so MIUI does not demote it as fully silent; the app plays the actual alert itself.
- Notification channel id suffix `_app2` introduced for the Xiaomi fallback.

## 1.6.13 (versionCode 35)
- Notification channel id advanced to v4 so Android drops any immutable channel sound left from older builds.
- In Silent mode, no notification tone is played; when the app's Vibrate option is enabled, the phone vibrates even if Android ringer mode is Silent. Any previously started app ringtone is stopped when the phone leaves Normal mode.
- Incoming SMS and test notifications now use Android's standard notification template rather than custom RemoteViews, improving shade/heads-up compatibility on Xiaomi/MIUI.
- APK build verified with `flutter build apk --debug`; real device behavior still needs confirmation on the target phone.

## نسخه 1.6.14
- زوم با دو انگشت (Pinch) داخل گفتگو: اندازه فونت پیام‌ها بزرگ/کوچک می‌شود (۷۰٪ تا ۲۵۰٪) و برای دفعه بعد ذخیره می‌شود. اسکرول و لمس عادی تغییری نکرده است.
- اصلاح تشخیص «کپی کد» در پیام‌های فارسی: تاریخ (۱۴۰۵/۰۸/۲۴)، ساعت، مبلغ، شماره موبایل و لینک نادیده گرفته می‌شوند و عددی که نزدیک‌ترین فاصله را به «کد/رمز/تایید» دارد انتخاب می‌شود؛ سال دیگر به‌جای کد کپی نمی‌شود.

## نسخه 1.6.15
- رفع کندی و پرش زوم با دو انگشت در گفتگو: در حین حرکت انگشت‌ها فقط تصویر با GPU (`graphicsLayer`) بزرگ/کوچک می‌شود و اندازهٔ واقعی فونت یک‌بار در لحظهٔ برداشتن انگشت‌ها اعمال می‌شود (قبلاً در هر فریم همهٔ حباب‌ها دوباره چیده می‌شدند). محل پیامِ زیر انگشت‌ها پس از زوم حفظ می‌شود. فایل: `Chat.kt`
- حباب پیام: تشخیص جهت متن و «کپی کد» دیگر در هر بازترکیب دوباره محاسبه نمی‌شوند (`remember`). فایل: `Chat.kt`

## نسخه 1.6.16
- اعلان پیامک: در حالت بازشدهٔ اعلان، سه دکمهٔ گرادیانی سفارشی اضافه شد: «خوانده شد»، «کپی کد» (فقط وقتی پیام کد تأیید دارد) و «تماس» (فقط برای شمارهٔ عددی). حالت جمع‌شده، هدز‌آپ و صفحهٔ قفل همچنان قالب استاندارد اندروید هستند (برای سازگاری با MIUI/HyperOS).
- دکمهٔ پاسخ سریع استاندارد (`RemoteInput`) سر جایش مانده و برچسبش از «ارسال» به «پاسخ» تغییر کرد.
- اگر ساخت ویوی سفارشی یا نمایش آن خطا بدهد، اعلان استاندارد (BigTextStyle) و در نهایت اعلان ساده نمایش داده می‌شود؛ خطا در لاگ برنامه ثبت می‌شود. اگر «نمایش پیش‌نمایش پیام» خاموش باشد ویوی سفارشی ساخته نمی‌شود.
- اکشن جدید `COPY` در `NotifActionReceiver` (کپی در کلیپ‌بورد + پیام «کد کپی شد»). فایل‌ها: `Core.kt`, `res/layout/notification_message_actions.xml`, `res/drawable/notif_btn_*.xml`
- versionCode=38 / versionName=1.6.16


## اصلاح اعلان پیامک و کپی کد (نسخه 1.6.16)
- ظاهر اعلان بازشده بازطراحی شد: سربرگ فرستنده و شماره، متن پیام، دکمه‌های رنگی تماس/کپی کد/خواندن و ردیف پاسخ.
- دکمه کپی کد، کد را از متن اصلی پیامک استخراج می‌کند؛ حتی وقتی پیش‌نمایش پیام در اعلان خاموش است.
- شناسه PendingIntent کپی بر اساس شناسه گفتگو، هش متن اصلی و خود کد یکتا شده و توکن قبلی پیش از ساخت جایگزین لغو می‌شود تا کد پیام قبلی کپی نشود.
- برچسب کلیپ‌بورد «کد تأیید» شد؛ محتوای کپی فقط خود کد عددی است.
- ردیف پاسخ اعلان با باز کردن همان گفتگوی فرستنده کار می‌کند.


## نسخه 1.6.35
- تماس‌ها هم می‌توانند اسپم تعریف شوند: دکمهٔ «اسپم» در تاریخچهٔ تماس، گزینه در منوی مخاطبین، و دکمه روی صفحهٔ تماس ورودی. لیست اسپم با پیامک مشترک است.
- حالت‌های برخورد با تماس اسپم: فقط برچسب، بی‌صدا کردن زنگ (پیش‌فرض)، رد خودکار. فایل‌ها: `Core.kt`, `Call.kt`, `Contacts.kt`, `Settings.kt`
- versionCode=57 / versionName=1.6.35

## نسخه 1.6.36
- صفحهٔ کلمات اسپم (افزودن/حذف)، خاموش/روشن کردن کلمات داخلی، و تطبیق کلمات با نام تماس‌گیرنده برای تماس‌ها. فایل‌ها: Core.kt, Mms.kt, Call.kt, Settings.kt

## نسخه 1.6.37
- کلمات اسپم فقط برای پیامک؛ تماس‌ها فقط با شماره‌ای که کاربر اسپم/مسدود کرده. مسدودها همیشه رد می‌شوند.
- پرسش برای شمارهٔ ناشناسِ پرتکرار (تنظیم‌پذیر: ۳/۵/۱۰ تماس در ۳ روز). فایل‌ها: Core.kt, Call.kt, Contacts.kt, Settings.kt
