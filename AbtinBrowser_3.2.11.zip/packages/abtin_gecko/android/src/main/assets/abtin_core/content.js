'use strict';
// Abtin Core - content script (top frame only; isolated from the page's JS world).
(function () {
  if (window.top !== window) return;

  // ---- cosmetic ad hiding ------------------------------------------------
  browser.runtime.sendMessage({ t: 'getConfig' }).then(function (c) {
    if (!c) return;
    mbCfg(c);
    if (!c.adblock || !c.cosmetic) return;
    var s = document.createElement('style');
    s.textContent = c.cosmetic;
    var add = function () { (document.head || document.documentElement).appendChild(s); };
    if (document.documentElement) add(); else document.addEventListener('readystatechange', add, { once: true });
  }).catch(function () {});


  // ---- native port (retries: the app may attach its delegate a moment after the page started) ----
  var port = null, tries = 0;

  function sendPage() {
    if (!port) return;
    var icon = '', theme = '';
    var cands = iconCandidates();
    icon = cands[0] || '';
    for (var ci = 0; ci < cands.length; ci++) if (iconDone[cands[ci]]) { icon = cands[ci]; break; }
    var m = document.querySelector('meta[name="theme-color"]');
    if (m) theme = m.content || '';
    lastTheme = theme;
    lastPc = '';
    pcSend(true);
    try { port.postMessage({ t: 'page', icon: icon, theme: theme, iconData: iconDone[icon] || '' }); } catch (e) {}
    wantIcon(icon, cands, 1);
    wantManifestIcons();
  }

  // All icons the page declares (apple-touch-icon / larger ones first), then the default /favicon.ico: the first that loads is used.
  function iconCandidates() {
    var out = [], seen = {};
    function add(u) { if (u && !seen[u]) { seen[u] = 1; out.push(u); } }
    var ls = document.querySelectorAll('link[rel~="icon"],link[rel="shortcut icon"],link[rel~="apple-touch-icon"],link[rel="apple-touch-icon-precomposed"]');
    var arr = [];
    for (var i = 0; i < ls.length; i++) {
      var l = ls[i];
      if (!l.href) continue;
      var sz = 0, m = /(\d+)\s*x\s*(\d+)/i.exec(l.getAttribute('sizes') || '');
      if (m) sz = parseInt(m[1], 10);
      if (/apple-touch/i.test(l.getAttribute('rel') || '')) sz = sz || 180;
      arr.push({ u: l.href, s: sz });
    }
    arr.sort(function (a, b) { return b.s - a.s; });
    for (var j = 0; j < arr.length; j++) add(arr[j].u);
    if (location.protocol.indexOf('http') === 0) add(location.origin + '/favicon.ico');
    return out;
  }

  // Manifest icons are often the only high-resolution artwork a PWA provides. Fetch them
  // independently and rasterize SVG/WebP/ICO to a 512px PNG in the extension context.
  function wantManifestIcons() {
    var link = document.querySelector('link[rel~="manifest"]');
    if (!link || !link.href || !/^https?:/i.test(link.href)) return;
    fetch(link.href, { credentials: 'same-origin' }).then(function (r) {
      if (!r.ok) throw new Error('manifest');
      return r.json();
    }).then(function (m) {
      if (!m || !Array.isArray(m.icons)) return;
      var list = [], seen = {};
      m.icons.forEach(function (it) {
        if (!it || !it.src) return;
        var u;
        try { u = new URL(it.src, link.href).href; } catch (e) { return; }
        if (!/^https?:/i.test(u) || seen[u]) return;
        seen[u] = 1;
        var sizes = String(it.sizes || ''), score = 0, mm;
        var re = /(\d+)\s*x\s*(\d+)/ig;
        while ((mm = re.exec(sizes))) score = Math.max(score, parseInt(mm[1], 10));
        if (String(it.purpose || 'any').indexOf('monochrome') >= 0 && String(it.purpose || '').indexOf('any') < 0) score -= 10000;
        if (String(it.purpose || '').indexOf('maskable') >= 0) score += 2;
        list.push({ u: u, score: score });
      });
      list.sort(function (a, b) { return b.score - a.score; });
      if (list.length) wantIcon(list[0].u, list.map(function (x) { return x.u; }), 1);
    }).catch(function () {});
  }

  // ---- colour of the page, for the installed web app's status bar / notch area (PwaActivity paints it) ----
  var lastPc = '', pcT = 0;
  function hex2(n) { return ('0' + Math.max(0, Math.min(255, n | 0)).toString(16)).slice(-2); }
  function rgbHex(c) { // computed "rgb(r, g, b)" / "rgba(r, g, b, a)" -> "#rrggbb"; '' when (nearly) transparent
    var m = /rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)(?:[,\s/]+([\d.]+%?))?/.exec(c || '');
    if (!m) return '';
    if (m[4] !== undefined && parseFloat(m[4]) / (m[4].slice(-1) === '%' ? 100 : 1) < 0.5) return '';
    return '#' + hex2(+m[1]) + hex2(+m[2]) + hex2(+m[3]);
  }
  function cssToHex(v) { // any CSS colour (names, #rgb, hsl...) -> "#rrggbb"
    if (!v || !document.documentElement) return '';
    try {
      var el = document.createElement('i');
      el.style.color = v;
      if (!el.style.color) return '';
      document.documentElement.appendChild(el);
      var c = getComputedStyle(el).color;
      el.remove();
      return rgbHex(c);
    } catch (e) { return ''; }
  }
  function themeMeta() { // <meta name=theme-color>: the one matching the current light/dark scheme wins
    var ms = document.querySelectorAll('meta[name="theme-color"]'), plain = '';
    for (var i = 0; i < ms.length; i++) {
      var md = ms[i].getAttribute('media');
      if (!md) { if (!plain) plain = ms[i].content || ''; continue; }
      try { if (window.matchMedia(md).matches) return ms[i].content || ''; } catch (e) {}
    }
    return plain;
  }
  function layerBg(el) { // first opaque background colour at / above an element ('' = none)
    while (el && el.nodeType === 1) {
      var cs = getComputedStyle(el), h = rgbHex(cs.backgroundColor);
      if (h) return h;
      el = el.parentElement;
    }
    return '';
  }
  function pageBg() { // background colour at the very top of the page (what sits next to the status bar / notch)
    try {
      var w = window.innerWidth || 360, xs = [0.5, 0.15, 0.85], i, h;
      for (i = 0; i < xs.length; i++) {
        var el = document.elementFromPoint(Math.floor(w * xs[i]), 1);
        h = el && layerBg(el);
        if (h) return h;
      }
      h = (document.body && layerBg(document.body)) || layerBg(document.documentElement);
      if (h) return h;
      // nothing paints a colour: the browser's own canvas shows, white unless the page asks for a dark colour scheme
      var sch = (getComputedStyle(document.documentElement).colorScheme || '').toLowerCase();
      return sch.indexOf('dark') >= 0 && sch.indexOf('light') < 0 ? '#121212' : '#ffffff';
    } catch (e) { return ''; }
  }
  function pcSend(force) {
    if (!port || document.visibilityState === 'hidden') return;
    var c = cssToHex(themeMeta()) || pageBg();
    if (!c || (c === lastPc && !force)) return;
    lastPc = c;
    try { port.postMessage({ t: 'pwaColor', c: c }); } catch (e) {}
  }
  setInterval(function () { pcSend(false); }, 2000);   // only the installed-web-app status bar uses this colour
  window.addEventListener('load', function () { pcSend(false); });
  document.addEventListener('DOMContentLoaded', function () {
    pcSend(false);
    try { new MutationObserver(function () { pcSend(false); }).observe(document.head || document.documentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ['content', 'media', 'name'] }); } catch (e) {}
  });
  window.addEventListener('scroll', function () { clearTimeout(pcT); pcT = setTimeout(function () { pcSend(false); }, 150); }, { passive: true });

  var iconDone = {}, iconAsked = {}, lastTheme = '';
  function wantIcon(icon, rest, next) {
    if (!icon || iconDone[icon] || iconAsked[icon]) return;
    iconAsked[icon] = 1;
    browser.runtime.sendMessage({ t: 'icon', url: icon }).then(function (d) {
      if (!d) {
        iconAsked[icon] = 0;
        // this candidate did not load: try the next one the page declared
        if (rest && next < rest.length) wantIcon(rest[next], rest, next + 1);
        return;
      }
      iconDone[icon] = d;
      if (port) try { port.postMessage({ t: 'page', icon: icon, theme: lastTheme, iconData: d }); } catch (e) {}
    }).catch(function () { iconAsked[icon] = 0; if (rest && next < rest.length) wantIcon(rest[next], rest, next + 1); });
  }

  function retry() {
    port = null;
    if (tries++ < 8) setTimeout(connect, 500 * tries);
  }

  function connect() {
    try {
      var p = browser.runtime.connectNative('abtin');
      port = p;
      p.onMessage.addListener(onCmd);
      p.onDisconnect.addListener(function () { if (port === p) retry(); });
      sendPage();
      flushMedia();
    } catch (e) { retry(); }
  }
  connect();

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', sendPage); else sendPage();
  window.addEventListener('load', sendPage);
  window.addEventListener('pageshow', function (e) { if (e.persisted && !port) { tries = 0; connect(); } });

  // ---- site info for the app installer + "Chrome only" pages (one cheap check after load, nothing keeps running) ----
  var infoDone = false;
  function pageInfo() {
    if (infoDone || !port || location.protocol.indexOf('http') !== 0) return;
    infoDone = true;
    // Service worker registered for this origin (a real PWA needs a manifest AND a service worker).
    try {
      navigator.serviceWorker.getRegistration().then(function (r) {
        try { port && port.postMessage({ t: 'swInfo', sw: !!r }); } catch (e) {}
      }, function () {});
    } catch (e) {}
    // Short page that says it only works in Chrome / the browser is not supported: tell the app, which then
    // sends the Chrome identity for this site and reloads it once. Long pages (articles, chats) are never scanned.
    try {
      var b = document.body;
      if (!b || b.childElementCount > 80) return;
      var tx = (b.innerText || '').slice(0, 3000);
      if (tx.length > 1500 || tx.length < 10) return;
      var re = /(only|best viewed|please use|requires?|supports?)[^.\n]{0,40}(google\s*)?chrome|(browser|مرورگر)[^.\n]{0,40}(not supported|unsupported|پشتیبانی نمی)|(لطفا|لطفاً|فقط)[^.\n]{0,30}(کروم|chrome)/i;
      if (re.test(tx) && !/chrome/i.test(navigator.userAgent)) port.postMessage({ t: 'browserBlocked' });
    } catch (e) {}
  }
  window.addEventListener('load', function () { setTimeout(pageInfo, 1200); });
  window.addEventListener('pageshow', function () { infoDone = false; });

  // commands can also arrive through the background page (tabs.sendMessage) when the port is missing
  browser.runtime.onMessage.addListener(function (m) { onCmd(m); });

  // ---- Touch-and-hold video previews ----------------------------------------------------------------------------
  // Many sites start a preview (a muted <video>, or frames swapped in an <img>) while a thumbnail is held. After ~0.5 s the
  // browser's long-press menu / text selection used to take the touch over and the preview stopped after a few frames.
  // While a preview is running under the finger, the long-press menu and the selection are suppressed.
  var tpEl = null, tpMut = 0, tpMo = null, tpStyle = null, tpAt = 0;
  function tpRoot(t) {
    if (!t || !t.closest) return null;
    return t.closest('a, [class*=thumb i], [class*=preview i], [class*=video i], li, article') || t.parentElement;
  }
  function tpPlaying(root) {
    var vs = root ? root.querySelectorAll('video') : [];
    for (var i = 0; i < vs.length; i++) {
      var v = vs[i];
      if (!v.controls && !v.paused && !v.ended) return true;
    }
    return false;
  }
  function tpEnd() {
    if (tpMo) { try { tpMo.disconnect(); } catch (e) {} tpMo = null; }
    if (tpEl && tpStyle !== null) { try { tpEl.style.setProperty('-moz-user-select', tpStyle || '', ''); if (!tpStyle) tpEl.style.removeProperty('-moz-user-select'); } catch (e) {} }
    tpStyle = null;
    setTimeout(function () { tpEl = null; tpMut = 0; }, 400); // a late contextmenu after touchend is still ours
  }
  document.addEventListener('touchstart', function (e) {
    if (e.touches && e.touches.length > 1) return;
    var root = tpRoot(e.target);
    if (!root || root === document.body || root === document.documentElement) return;
    // Only when the finger is ON the thumbnail itself (img/video/picture/canvas/svg). A touch on any text (video titles, link text,
    // chat messages, lists) is never touched, even inside a card that contains a <video>, so text stays selectable everywhere.
    var tg = e.target;
    if (!(tg && tg.closest && tg.closest('img, video, picture, canvas, svg'))) return;
    tpEnd();
    tpEl = root; tpMut = 0; tpAt = Date.now();
    try { tpStyle = root.style.getPropertyValue('-moz-user-select') || ''; root.style.setProperty('-moz-user-select', 'none', 'important'); } catch (x) { tpStyle = null; }
    try {
      tpMo = new MutationObserver(function (ms) { tpMut += ms.length; });
      tpMo.observe(root, { subtree: true, childList: true, attributes: true, attributeFilter: ['src', 'srcset', 'style', 'class', 'poster'] });
    } catch (x) {}
  }, { passive: true, capture: true });
  ['touchend', 'touchcancel'].forEach(function (n) { document.addEventListener(n, function () { if (tpMo || tpStyle !== null) tpEnd(); }, { passive: true, capture: true }); });
  document.addEventListener('contextmenu', function (e) {
    if (!tpEl || !tpEl.contains(e.target) || Date.now() - tpAt > 15000) return;
    if (tpMut >= 3 || tpPlaying(tpEl)) { e.preventDefault(); }
  }, true);

  // ---- Tap on a site's own big play button that did nothing (autoplay-blocked feeds such as Instagram stories) ----
  // The page's handler may call play() too late for the autoplay policy. If the video was paused before the tap, the tap was in the
  // middle of it, and it is still paused shortly after, start it here (we are inside the user's tap window).
  document.addEventListener('click', function (e) {
    try {
      var t = e.target;
      if (!t || !t.closest || t.closest('video[controls], a[href], input, textarea, select')) return;
      var box = t, vid = null;
      for (var i = 0; i < 6 && box && !vid; i++, box = box.parentElement) vid = box.querySelector && box.querySelector('video');
      if (!vid || vid.controls || !vid.paused || vid.ended) return;
      var r = vid.getBoundingClientRect();
      if (r.width < 120 || r.height < 120) return;
      var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
      if (Math.abs(e.clientX - cx) > r.width * 0.22 || Math.abs(e.clientY - cy) > r.height * 0.22) return;
      setTimeout(function () {
        if (!vid.paused || !document.contains(vid)) return;
        var p = vid.play();
        if (p && p.catch) p.catch(function () { try { vid.muted = true; vid.play().catch(function () {}); } catch (x) {} });
      }, 250);
    } catch (x) {}
  }, true);

  // ---- SMS login codes: the app reads the SMS (RECEIVE_SMS) and sends only the digits; we put them in the code box ----
  var otpCode = '', otpHost = '', otpAt = 0, otpChip = null, otpAsked = 0;
  var OTP_NAME = /otp|one[-_ ]?time|sms|verif|vcode|v-code|passcode|confirm.?code|auth.?code|activation|\u06a9\u062f|\u062a\u0627\u06cc\u06cc\u062f|\u062a\u0623\u06cc\u06cc\u062f|\u0631\u0645\u0632 \u06cc\u06a9/i;

  function otpOk(el) {
    if (!el || el.tagName !== 'INPUT' || el.disabled || el.readOnly) return false;
    var ty = (el.getAttribute('type') || 'text').toLowerCase();
    if (ty !== 'text' && ty !== 'tel' && ty !== 'number' && ty !== 'search') return false;
    var ac = (el.getAttribute('autocomplete') || '').toLowerCase();
    if (ac.indexOf('one-time-code') >= 0) return true;
    var ml = parseInt(el.getAttribute('maxlength') || '0', 10);
    var im = (el.getAttribute('inputmode') || '').toLowerCase();
    var txt = [el.name, el.id, el.placeholder, el.getAttribute('aria-label'), el.getAttribute('data-testid'), typeof el.className === 'string' ? el.className : ''].join(' ');
    if (OTP_NAME.test(txt)) return true;
    // split boxes: several 1-character numeric inputs side by side
    if (ml === 1 && (im === 'numeric' || ty === 'tel' || ty === 'number' || /digit|num|pin|code/i.test(txt))) return otpBoxes(el).length >= 4;
    // a 4-8 digit numeric box
    return ml >= 4 && ml <= 8 && (im === 'numeric' || ty === 'tel' || ty === 'number');
  }

  function otpBoxes(el) {
    var p = el.parentElement, i = 0, list = [];
    while (p && i++ < 3) {
      list = Array.prototype.filter.call(p.querySelectorAll('input'), function (x) {
        return !x.disabled && !x.readOnly && parseInt(x.getAttribute('maxlength') || '0', 10) === 1;
      });
      if (list.length >= 4) return list;
      p = p.parentElement;
    }
    return [];
  }

  function otpSet(el, v) {
    try { el.focus(); } catch (e) {}
    try { el.value = v; } catch (e) { return; }
    ['keydown', 'keypress'].forEach(function (t) { try { el.dispatchEvent(new KeyboardEvent(t, { key: v.slice(-1), bubbles: true })); } catch (e) {} });
    try { el.dispatchEvent(new InputEvent('input', { bubbles: true, data: v, inputType: 'insertText' })); } catch (e) { el.dispatchEvent(new Event('input', { bubbles: true })); }
    try { el.dispatchEvent(new KeyboardEvent('keyup', { key: v.slice(-1), bubbles: true })); } catch (e) {}
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function otpFill(el, code) {
    var boxes = parseInt(el.getAttribute('maxlength') || '0', 10) === 1 ? otpBoxes(el) : [];
    if (boxes.length >= 4) {
      for (var i = 0; i < boxes.length && i < code.length; i++) otpSet(boxes[i], code.charAt(i));
      try { boxes[Math.min(code.length, boxes.length) - 1].focus(); } catch (e) {}
    } else {
      var ml = parseInt(el.getAttribute('maxlength') || '0', 10);
      otpSet(el, ml > 0 && ml < code.length ? code.slice(0, ml) : code);
    }
  }

  function otpTarget() {
    var a = document.activeElement;
    if (otpOk(a)) return a;
    var list = document.querySelectorAll('input');
    for (var i = 0; i < list.length && i < 300; i++) {
      var el = list[i];
      if (!otpOk(el)) continue;
      var r = el.getBoundingClientRect();
      if (r.width > 4 && r.height > 4 && getComputedStyle(el).visibility !== 'hidden') return el;
    }
    return null;
  }

  function otpHideChip() { if (otpChip) { try { otpChip.remove(); } catch (e) {} otpChip = null; } }

  // Fallback when no code box is on the page (or the SMS names another site): a small pill with the code; tap = copy.
  function otpShowChip(code, why) {
    otpHideChip();
    var host = document.createElement('div');
    host.style.cssText = 'all:initial;position:fixed;left:0;right:0;bottom:calc(env(safe-area-inset-bottom,0px) + 72px);z-index:2147483647;display:flex;justify-content:center;pointer-events:none';
    var sh = host.attachShadow({ mode: 'closed' });
    var fa = (document.documentElement.lang || navigator.language || '').indexOf('fa') === 0 || /[\u0600-\u06ff]/.test(document.title || '');
    var b = document.createElement('button');
    b.style.cssText = 'pointer-events:auto;font:600 15px system-ui,sans-serif;background:#1f2937;color:#fff;border:0;border-radius:22px;padding:10px 18px;box-shadow:0 4px 16px rgba(0,0,0,.35);direction:ltr';
    b.textContent = (fa ? '\u06a9\u062f \u067e\u06cc\u0627\u0645\u06a9: ' : 'SMS code: ') + code + (why ? '  \u00b7  ' : '  \u00b7  ') + (fa ? '\u06a9\u067e\u06cc' : 'Copy');
    b.addEventListener('click', function () {
      try { navigator.clipboard.writeText(code); b.textContent = fa ? '\u06a9\u067e\u06cc \u0634\u062f' : 'Copied'; } catch (e) {}
      setTimeout(otpHideChip, 900);
    });
    sh.appendChild(b);
    (document.body || document.documentElement).appendChild(host);
    otpChip = host;
    setTimeout(function () { if (otpChip === host) otpHideChip(); }, 25000);
  }

  function otpTry(auto) {
    if (!otpCode || Date.now() - otpAt > 5 * 60000) { otpCode = ''; return false; }
    var el = otpTarget();
    // The SMS carries "@site #code" (Web OTP format): never put it into another site's box.
    var wrong = otpHost && location.hostname !== otpHost && location.hostname.slice(-otpHost.length - 1) !== '.' + otpHost;
    if (el && !wrong) {
      otpFill(el, otpCode);
      try { port && port.postMessage({ t: 'otpUsed' }); } catch (e) {}
      otpCode = '';
      otpHideChip();
      return true;
    }
    if (!auto || !wrong) otpShowChip(otpCode, wrong);
    return false;
  }

  function onOtp(m) {
    if (!m.code) return;
    otpCode = String(m.code); otpHost = String(m.host || '').toLowerCase(); otpAt = Date.now();
    // wait a moment so a code box that is just being built can appear
    if (!otpTry(true)) setTimeout(function () { if (otpCode) otpTry(false); }, 1200);
  }

  document.addEventListener('focusin', function (e) {
    if (!otpOk(e.target)) return;
    if (otpCode && otpTry(true)) return;
    // tell the app a code box is focused: it asks for the SMS permission once, or answers with a fresh code
    if (port && Date.now() - otpAsked > 3000) { otpAsked = Date.now(); try { port.postMessage({ t: 'otpField' }); } catch (x) {} }
  }, true);

  // ---- Back inside a web app (PWA): close the open chat / dialog / panel. Reports {t:'backDone', id, handled} ----
  function pwaBack(id) {
    var changed = false, done = false;
    var mo = new MutationObserver(function () { changed = true; });
    try { mo.observe(document.documentElement, { childList: true, subtree: true, attributes: true, characterData: false }); } catch (e) {}
    function reply(h) {
      if (done) return;
      done = true;
      try { mo.disconnect(); } catch (e) {}
      try { port && port.postMessage({ t: 'backDone', id: id, handled: !!h }); } catch (e) {}
    }
    function esc() {
      var t = document.activeElement || document.body;
      ['keydown', 'keyup'].forEach(function (type) {
        var ev = new KeyboardEvent(type, { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true });
        try { t.dispatchEvent(ev); } catch (e) {}
        if (t !== document.body) try { document.body.dispatchEvent(new KeyboardEvent(type, { key: 'Escape', code: 'Escape', keyCode: 27, which: 27, bubbles: true, cancelable: true })); } catch (e) {}
      });
    }
    var RX = /(^|[\s_\-])(back|go-?back|arrow-?back|tgico-back|btn-back|navigate-back|close-?button|sidebar-close|nav-back)([\s_\-]|$)|بازگشت|برگشت|بستن|^back$|^close$/i;
    function visible(el) {
      var r = el.getBoundingClientRect();
      if (r.width < 8 || r.height < 8 || r.bottom < 0 || r.top > innerHeight * 0.35) return false;
      var cs = getComputedStyle(el);
      return cs.visibility !== 'hidden' && cs.display !== 'none' && cs.opacity !== '0';
    }
    function backButton() {
      var list = document.querySelectorAll('button, [role=button], a, [class*=back i], [class*=close i], [aria-label], [title]');
      var best = null;
      for (var i = 0; i < list.length && i < 4000; i++) {
        var el = list[i];
        var txt = (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('title') || '') + ' ' + (typeof el.className === 'string' ? el.className : '');
        if (!RX.test(txt.trim()) && !RX.test((el.getAttribute('aria-label') || '').trim())) continue;
        if (!visible(el)) continue;
        var r = el.getBoundingClientRect();
        // header-like: prefer the highest element; leftmost / rightmost corners are where back buttons live
        if (!best || r.top < best.r.top - 4) best = { el: el, r: r };
      }
      return best && best.el;
    }
    esc();
    setTimeout(function () {
      if (changed) return reply(true);
      var b = backButton();
      if (!b) return reply(false);
      changed = false;
      try { b.click(); } catch (e) { return reply(false); }
      setTimeout(function () { reply(changed); }, 200);
    }, 180);
    setTimeout(function () { reply(changed); }, 900);
  }

  // ======================================================================
  //  Inspect element: tap an element, see / edit its attributes, styles, box model and HTML. Toggled by {cmd:'inspect'}.
  // ======================================================================
  var insp = null;
  function inspector(m) {
    if (insp) { insp.close(); return; }
    try { insp = makeInspector(m && m.lang === 'fa' ? 'fa' : 'en'); } catch (e) { insp = null; }
  }
  function makeInspector(lang) {
    var fa = lang === 'fa';
    function T(f, e) { return fa ? f : e; }
    var host = document.createElement('div');
    host.setAttribute('data-abtin-inspector', '1');
    host.style.cssText = 'all:initial;position:fixed;top:0;left:0;right:0;bottom:0;z-index:2147483647;pointer-events:none;';
    var root = host.attachShadow({ mode: 'closed' });
    var st = document.createElement('style');
    st.textContent =
      ':host{all:initial}*{box-sizing:border-box;font-family:system-ui,sans-serif}' +
      '#hl{position:fixed;pointer-events:none;background:rgba(66,133,244,.28);outline:2px solid #4285f4;display:none}' +
      '#tag{position:fixed;pointer-events:none;background:#202124;color:#fff;font:11px monospace;padding:2px 6px;border-radius:4px;display:none;max-width:90vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
      '#panel{position:fixed;left:0;right:0;bottom:0;max-height:48vh;display:flex;flex-direction:column;pointer-events:auto;background:#1f2126;color:#e8eaed;font-size:12px;border-top:1px solid #3c4043;border-radius:14px 14px 0 0;padding-bottom:env(safe-area-inset-bottom,0)}' +
      '#panel.min #crumb,#panel.min #tabs,#panel.min #body{display:none}' +
      '.row{display:flex;gap:4px;padding:6px;align-items:center;overflow-x:auto;flex:none}' +
      'button{all:unset;cursor:pointer;background:#33363d;color:#e8eaed;padding:7px 10px;border-radius:8px;font:12px system-ui,sans-serif;white-space:nowrap;flex:none}' +
      'button.on{background:#4285f4;color:#fff}button.bad{background:#7a2b2b}' +
      '#crumb{display:flex;gap:2px;padding:0 6px 4px;overflow-x:auto;flex:none;direction:ltr}' +
      '#crumb span{padding:3px 6px;border-radius:6px;background:#2b2e34;font:11px monospace;white-space:nowrap;cursor:pointer;flex:none}#crumb span.cur{background:#4285f4;color:#fff}' +
      '#tabs{display:flex;border-bottom:1px solid #3c4043;flex:none}#tabs div{flex:1;text-align:center;padding:8px 2px;cursor:pointer;color:#9aa0a6}#tabs div.on{color:#8ab4f8;border-bottom:2px solid #8ab4f8}' +
      '#body{overflow:auto;padding:8px;flex:1;min-height:60px;direction:ltr;-webkit-overflow-scrolling:touch}' +
      '.kv{display:flex;gap:6px;align-items:center;margin-bottom:5px}.kv b{color:#8ab4f8;font:11px monospace;min-width:92px;max-width:42%;overflow:hidden;text-overflow:ellipsis;flex:none}' +
      'input,textarea{all:unset;background:#2b2e34;color:#e8eaed;border-radius:6px;padding:5px 7px;font:12px monospace;flex:1;min-width:0;-webkit-user-select:text;user-select:text}' +
      'textarea{display:block;width:100%;min-height:150px;white-space:pre;overflow:auto;box-sizing:border-box}' +
      '.ch{padding:5px 7px;margin-bottom:4px;background:#2b2e34;border-radius:6px;font:11px monospace;cursor:pointer;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
      '.sec{color:#9aa0a6;margin:8px 0 4px;font-size:11px}' +
      '.bx{border:1px dashed #888;padding:6px;text-align:center;border-radius:4px;font:11px monospace}.bx>.l{color:#9aa0a6;text-align:left;font-size:10px}' +
      '.m{background:#4a3a1f}.b{background:#3f3f1f}.p{background:#1f3f2a}.c{background:#1f3350;padding:8px}' +
      '.bx .r{display:flex;justify-content:space-between;align-items:center;gap:6px}' +
      '#msg{color:#81c995;font-size:11px;padding:0 6px;flex:none}';

    st.textContent +=
      '#tabs{overflow-x:auto;-webkit-overflow-scrolling:touch}#tabs div{flex:none;padding:8px 12px;white-space:nowrap}' +
      '#panel.big{height:92vh;max-height:92vh}' +
      '.tree{min-width:max-content}.tr{font:11px/1.6 monospace;white-space:nowrap;cursor:pointer;padding:3px 2px;border-radius:3px;color:#c4c7cc}' +
      '.tr.sel{background:#2a4a7f}.tr .tg{color:#c58af9}.tr .an{color:#e8a05a}.tr .av{color:#8ab4f8}.tr .tx{color:#9aa0a6}.tr .cm{color:#6a9955}' +
      '.tr .tgl{display:inline-block;min-width:20px;color:#9aa0a6}' +
      '.rule{background:#26282e;border-radius:8px;padding:6px 8px;margin-bottom:8px}.rule .rs{font:11px monospace;color:#c58af9;word-break:break-all;margin-bottom:4px}' +
      '.rule .src{color:#9aa0a6;font:10px monospace;margin-bottom:3px;word-break:break-all}.rule .row{padding:4px 0 0}' +
      '.dc{display:flex;gap:4px;align-items:center;margin:2px 0 2px 8px}.dc b{color:#8ab4f8;font:11px monospace;flex:none;max-width:42%;overflow:hidden;text-overflow:ellipsis}.ck{cursor:pointer;color:#9aa0a6;flex:none;padding:2px}' +
      '.cl{font:11px/1.5 monospace;padding:3px 6px;border-bottom:1px solid #2b2e34;white-space:pre-wrap;word-break:break-all;-webkit-user-select:text;user-select:text}' +
      '.cl.warn{background:#3a3217;color:#f1d27a}.cl.error{background:#3d1f1f;color:#f28b82}.cl.in{color:#8ab4f8}.cl.res{color:#81c995}.cl.debug,.cl.info{color:#9aa0a6}' +
      '.nr{display:flex;gap:6px;font:11px monospace;padding:6px 4px;border-bottom:1px solid #2b2e34;cursor:pointer;align-items:center}' +
      '.nu{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.nz{color:#9aa0a6;flex:none}.ns{flex:none;min-width:34px}' +
      '.ns.ok{color:#81c995}.ns.rd{color:#8ab4f8}.ns.er{color:#f28b82}.wr{font:11px monospace;word-break:break-all;-webkit-user-select:text;user-select:text}';
    root.appendChild(st);
    function h(tag, props, kids) {
      var el = document.createElement(tag);
      if (props) for (var k in props) { if (k === 'text') el.textContent = props[k]; else if (k === 'cls') el.className = props[k]; else if (k.slice(0, 2) === 'on') el.addEventListener(k.slice(2), props[k]); else el[k] = props[k]; }
      if (kids) kids.forEach(function (c) { if (c) el.appendChild(c); });
      return el;
    }
    var hl = h('div', { id: 'hl' }), tag = h('div', { id: 'tag' });
    var panel = h('div', { id: 'panel' }), bar = h('div', { cls: 'row' }), crumb = h('div', { id: 'crumb' });
    var tabs = h('div', { id: 'tabs' }), body = h('div', { id: 'body' }), msg = h('span', { id: 'msg' });
    panel.appendChild(bar); panel.appendChild(crumb); panel.appendChild(tabs); panel.appendChild(body);
    root.appendChild(hl); root.appendChild(tag); root.appendChild(panel);
    (document.documentElement || document).appendChild(host);

    var sel = null, tab = 'tree', pick = true, timer = 0, msgT = 0;

    function esc(s) { return window.CSS && CSS.escape ? CSS.escape(s) : String(s).replace(/[^\w-]/g, '\\$&'); }
    function label(el) {
      var s = el.tagName.toLowerCase();
      if (el.id) s += '#' + el.id;
      var c = typeof el.className === 'string' ? el.className.trim().split(/\s+/).filter(Boolean).slice(0, 3) : [];
      if (c.length) s += '.' + c.join('.');
      return s;
    }
    function selector(el) {
      var parts = [], n = el;
      while (n && n.nodeType === 1 && n !== document.documentElement) {
        var p = n.tagName.toLowerCase();
        if (n.id && document.querySelectorAll('#' + esc(n.id)).length === 1) { parts.unshift('#' + esc(n.id)); break; }
        var cls = typeof n.className === 'string' ? n.className.trim().split(/\s+/).filter(Boolean).slice(0, 2) : [];
        if (cls.length) p += '.' + cls.map(esc).join('.');
        var par = n.parentElement;
        if (par) {
          var same = Array.prototype.filter.call(par.children, function (x) { return x.tagName === n.tagName; });
          if (same.length > 1) p += ':nth-of-type(' + (same.indexOf(n) + 1) + ')';
        }
        parts.unshift(p);
        try { if (document.querySelectorAll(parts.join(' > ')).length === 1) break; } catch (e) {}
        n = par;
      }
      return parts.join(' > ');
    }
    function say(t) { msg.textContent = t; clearTimeout(msgT); msgT = setTimeout(function () { msg.textContent = ''; }, 1800); }
    function copy(text) {
      try {
        var ta = h('textarea', { value: text });
        root.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove();
        say(T('کپی شد', 'Copied'));
      } catch (e) { try { navigator.clipboard.writeText(text); say(T('کپی شد', 'Copied')); } catch (x) { say(T('کپی نشد', 'Copy failed')); } }
    }
    function selectEl(el) {
      if (!el || el.nodeType !== 1 || el === host || host.contains(el)) return;
      sel = el;
      if (tab === 'src' || tab === 'net' || tab === 'con' || tab === 'sto') tab = 'tree';
      render();
      try { sel.scrollIntoView({ block: 'nearest', inline: 'nearest' }); } catch (e) {}
    }
    function place() {
      if (!sel || !sel.isConnected) { hl.style.display = tag.style.display = 'none'; return; }
      var r = sel.getBoundingClientRect();
      hl.style.cssText = 'display:block;left:' + r.left + 'px;top:' + r.top + 'px;width:' + r.width + 'px;height:' + r.height + 'px';
      tag.textContent = label(sel) + '  ' + Math.round(r.width) + '×' + Math.round(r.height);
      var ty = r.top - 22 < 0 ? Math.min(r.bottom + 2, innerHeight - 24) : r.top - 22;
      tag.style.cssText = 'display:block;left:' + Math.max(0, Math.min(r.left, innerWidth - 120)) + 'px;top:' + ty + 'px';
    }

    function renderBar() {
      bar.textContent = '';
      var min = panel.classList.contains('min');
      bar.appendChild(h('button', { text: pick ? T('انتخاب: روشن', 'Pick: on') : T('انتخاب: خاموش', 'Pick: off'), cls: pick ? 'on' : '', onclick: function () { pick = !pick; renderBar(); } }));
      bar.appendChild(h('button', { text: '↑', title: 'parent', onclick: function () { if (sel && sel.parentElement && sel.parentElement !== document.documentElement.parentNode) selectEl(sel.parentElement); } }));
      bar.appendChild(h('button', { text: '↓', onclick: function () { if (sel && sel.firstElementChild) selectEl(sel.firstElementChild); } }));
      bar.appendChild(h('button', { text: '←', onclick: function () { if (sel && sel.previousElementSibling) selectEl(sel.previousElementSibling); } }));
      bar.appendChild(h('button', { text: '→', onclick: function () { if (sel && sel.nextElementSibling) selectEl(sel.nextElementSibling); } }));
      bar.appendChild(h('button', { text: T('کپی انتخابگر', 'Copy selector'), onclick: function () { if (sel) copy(selector(sel)); } }));
      bar.appendChild(h('button', { text: T('کپی HTML', 'Copy HTML'), onclick: function () { if (sel) copy(sel.outerHTML); } }));
      bar.appendChild(h('button', { text: T('حذف', 'Delete'), cls: 'bad', onclick: function () { if (sel && sel !== document.documentElement && sel !== document.body) { var p = sel.parentElement; sel.remove(); sel = null; if (p) selectEl(p); else render(); } } }));
      bar.appendChild(h('button', { text: '⤢', onclick: function () { panel.classList.toggle('big'); panel.classList.remove('min'); renderBar(); renderBody(); } }));
      bar.appendChild(h('button', { text: min ? '▴' : '▾', onclick: function () { panel.classList.toggle('min'); renderBar(); } }));
      bar.appendChild(h('button', { text: '✕', onclick: close }));
      bar.appendChild(msg);
    }
    var TABS = [['tree', T('درخت', 'Tree')], ['css', T('استایل', 'Styles')], ['el', T('المنت', 'Element')], ['box', T('جعبه', 'Box')], ['html', 'HTML'], ['src', T('منابع', 'Sources')], ['net', T('شبکه', 'Network')], ['con', T('کنسول', 'Console')], ['sto', T('ذخیره', 'Storage')]];
    function renderTabs() {
      tabs.textContent = '';
      TABS.forEach(function (t) { tabs.appendChild(h('div', { text: t[1], cls: tab === t[0] ? 'on' : '', onclick: function () { tab = t[0]; renderTabs(); renderBody(); } })); });
    }
    function renderCrumb() {
      crumb.textContent = '';
      var chain = [], n = sel;
      while (n && n.nodeType === 1) { chain.unshift(n); n = n.parentElement; }
      chain.forEach(function (c) { crumb.appendChild(h('span', { text: c.tagName.toLowerCase() + (c.id ? '#' + c.id : ''), cls: c === sel ? 'cur' : '', onclick: function () { selectEl(c); } })); });
      var cur = crumb.querySelector('.cur'); if (cur) cur.scrollIntoView({ inline: 'end', block: 'nearest' });
    }
    function kv(name, val, onSet, onDel) {
      var inp = h('input', { value: val, spellcheck: false, autocapitalize: 'off', autocomplete: 'off' });
      inp.addEventListener('change', function () { try { onSet(inp.value); } catch (e) {} place(); });
      var row = h('div', { cls: 'kv' }, [h('b', { text: name }), inp]);
      if (onDel) row.appendChild(h('button', { text: '✕', onclick: function () { onDel(); renderBody(); place(); } }));
      return row;
    }
    function renderBody() {
      var keep = tab === 'tree' && renderedTab === 'tree' ? body.scrollTop : -1, keepX = tab === 'tree' && renderedTab === 'tree' ? body.scrollLeft : 0;
      body.textContent = '';
      renderedTab = tab;
      if (EXT[tab]) { EXT[tab](); if (keep >= 0) { body.scrollTop = keep; body.scrollLeft = keepX; } return; }
      if (!sel) { body.appendChild(h('div', { text: T('روی یک المنت در صفحه بزنید', 'Tap an element on the page') })); return; }
      var cs = getComputedStyle(sel);
      if (tab === 'el') {
        body.appendChild(h('div', { cls: 'sec', text: T('ویژگی‌ها', 'Attributes') }));
        Array.prototype.slice.call(sel.attributes).forEach(function (a) {
          body.appendChild(kv(a.name, a.value, function (v) { sel.setAttribute(a.name, v); }, function () { sel.removeAttribute(a.name); }));
        });
        var add = h('button', { text: T('+ ویژگی', '+ Attribute'), onclick: function () {
          var n = prompt(T('نام ویژگی', 'Attribute name'));
          if (n) { try { sel.setAttribute(n.trim(), ''); } catch (e) {} renderBody(); }
        } });
        body.appendChild(add);
        var own = Array.prototype.filter.call(sel.childNodes, function (n) { return n.nodeType === 3 && n.nodeValue.trim(); }).map(function (n) { return n.nodeValue.trim(); }).join(' ');
        if (own) {
          body.appendChild(h('div', { cls: 'sec', text: T('متن', 'Text') }));
          var ti = h('input', { value: own.slice(0, 500) });
          ti.addEventListener('change', function () {
            var first = true;
            Array.prototype.slice.call(sel.childNodes).forEach(function (n) { if (n.nodeType === 3 && n.nodeValue.trim()) { if (first) { n.nodeValue = ti.value; first = false; } else n.nodeValue = ''; } });
            place();
          });
          body.appendChild(ti);
        }
        body.appendChild(h('div', { cls: 'sec', text: T('فرزندان', 'Children') + ' (' + sel.children.length + ')' }));
        Array.prototype.slice.call(sel.children, 0, 60).forEach(function (c) { body.appendChild(h('div', { cls: 'ch', text: label(c), onclick: function () { selectEl(c); } })); });
      } else if (tab === 'css') {
        body.appendChild(h('div', { cls: 'sec', text: T('استایل inline', 'Inline style') }));
        var si = h('input', { value: sel.getAttribute('style') || '' });
        si.addEventListener('change', function () { if (si.value.trim()) sel.setAttribute('style', si.value); else sel.removeAttribute('style'); renderBody(); place(); });
        body.appendChild(si);
        renderRules(sel);
        body.appendChild(h('div', { cls: 'sec', text: T('استایل محاسبه‌شده (قابل ویرایش)', 'Computed (editable)') }));
        ['display', 'position', 'top', 'right', 'bottom', 'left', 'z-index', 'width', 'height', 'color', 'background-color', 'background-image', 'font-family', 'font-size', 'font-weight', 'line-height', 'text-align', 'direction', 'opacity', 'overflow-x', 'overflow-y', 'flex-direction', 'justify-content', 'align-items', 'gap', 'transform', 'visibility', 'cursor', 'box-sizing', 'border-top-left-radius', 'box-shadow', 'pointer-events']
          .forEach(function (p) {
            var v = cs.getPropertyValue(p);
            if (v === '') return;
            body.appendChild(kv(p, v, function (nv) { sel.style.setProperty(p, nv, 'important'); }));
          });
      } else if (tab === 'box') {
        var r = sel.getBoundingClientRect();
        function num(p) { return Math.round(parseFloat(cs.getPropertyValue(p)) * 10) / 10 || 0; }
        function sides(pfx, sfx) { return ['top', 'right', 'bottom', 'left'].map(function (s) { return num(pfx + '-' + s + (sfx || '')); }); }
        function box(cls, name, v, inner) {
          return h('div', { cls: 'bx ' + cls }, [h('div', { cls: 'l', text: name }),
            h('div', { text: v[0] }),
            h('div', { cls: 'r' }, [h('span', { text: v[3] }), inner, h('span', { text: v[1] })]),
            h('div', { text: v[2] })]);
        }
        var c = h('div', { cls: 'bx c', text: Math.round(r.width) + ' × ' + Math.round(r.height) });
        body.appendChild(box('m', 'margin', sides('margin'), box('b', 'border', sides('border', '-width'), box('p', 'padding', sides('padding'), c))));
        body.appendChild(h('div', { cls: 'sec', text: 'x:' + Math.round(r.left + scrollX) + '  y:' + Math.round(r.top + scrollY) + '   scroll:' + sel.scrollWidth + '×' + sel.scrollHeight }));
      } else {
        var ta = h('textarea', { value: sel.outerHTML, spellcheck: false });
        body.appendChild(ta);
        body.appendChild(h('div', { cls: 'row' }, [
          h('button', { text: T('اعمال', 'Apply'), cls: 'on', onclick: function () {
            try {
              if (sel === document.documentElement || sel === document.body) { sel.innerHTML = ta.value; say(T('اعمال شد', 'Applied')); return; }
              var tp = document.createElement('template'); tp.innerHTML = ta.value;
              var nu = tp.content.firstElementChild;
              sel.replaceWith(tp.content);
              if (nu) selectEl(nu); else { sel = null; render(); }
              say(T('اعمال شد', 'Applied'));
            } catch (e) { say(T('خطا', 'Error')); }
          } }),
          h('button', { text: T('کپی', 'Copy'), onclick: function () { copy(ta.value); } })
        ]));
      }
    }
    // ---------------------------------------------------------------- DevTools-style tabs: tree, CSS rules, sources, network, console, storage
    var renderedTab = '', treeOpen = new WeakSet(), treeLimit = new WeakMap(), fromTree = false;
    var cssCache = {};          // cross-origin stylesheet href -> parsed CSSStyleSheet (null = pending / failed)
    var view = null;            // Sources tab: the open file
    var netData = null, netFilter = 'all', netOpen = null, netClear = 0, conListEl = null;
    var VOID = /^(area|base|br|col|embed|hr|img|input|link|meta|param|source|track|wbr)$/;

    function short(u) {
      try { var o = new URL(u, location.href), p = o.pathname.split('/').filter(Boolean).pop() || o.hostname; return p + (o.search ? '?…' : ''); } catch (e) { return String(u).slice(0, 60); }
    }
    function sizeStr(n) { return n == null || isNaN(n) ? '—' : n < 1024 ? n + ' B' : n < 1048576 ? (n / 1024).toFixed(1) + ' KB' : (n / 1048576).toFixed(1) + ' MB'; }
    function bgFetch(url) {
      return browser.runtime.sendMessage({ t: 'fetchText', url: url }).then(function (r) { return r || { ok: false, error: 'no reply' }; }, function (e) { return { ok: false, error: String(e && e.message || e) }; });
    }
    // split on a separator that is not inside (), [], or quotes
    function splitBy(s, ch) {
      var out = [], cur = '', d = 0, q = '';
      for (var i = 0; i < s.length; i++) {
        var c = s[i];
        if (q) { cur += c; if (c === '\\') cur += s[++i] || ''; else if (c === q) q = ''; continue; }
        if (c === '"' || c === "'") { q = c; cur += c; continue; }
        if (c === '(' || c === '[') d++; else if (c === ')' || c === ']') d--;
        if (c === ch && d === 0) { out.push(cur); cur = ''; continue; }
        cur += c;
      }
      if (cur.trim()) out.push(cur);
      return out;
    }
    // approximate CSS specificity as one number (ids, classes/attrs/pseudo-classes, types)
    function specOf(sel) {
      var s = sel.replace(/"[^"]*"|'[^']*'/g, '""');
      var a = (s.match(/#[\w-]+/g) || []).length;
      s = s.replace(/#[\w-]+/g, ' ');
      var attrs = (s.match(/\[[^\]]*\]/g) || []).length;
      s = s.replace(/\[[^\]]*\]/g, ' ');
      var pe = (s.match(/::[\w-]+/g) || []).length;
      s = s.replace(/::[\w-]+/g, ' ');
      var b = (s.match(/\.[\w-]+/g) || []).length + attrs + (s.match(/:[\w-]+/g) || []).length;
      s = s.replace(/\.[\w-]+/g, ' ').replace(/:[\w-]+/g, ' ');
      var c = (s.match(/(^|[\s>+~(,])[a-zA-Z][\w-]*/g) || []).length + pe;
      return a * 1e6 + b * 1e3 + c;
    }
    function pad(n) { var o = ''; for (var i = 0; i < n; i++) o += '  '; return o; }
    // simple formatter for minified CSS / JS (display only; never executed)
    function beautify(src, kind) {
      if (kind === 'json') { try { return JSON.stringify(JSON.parse(src), null, 2); } catch (e) { return src; } }
      var js = kind === 'js', out = '', ind = 0, q = '', par = 0, i, c;
      for (i = 0; i < src.length; i++) {
        c = src[i];
        if (q) { out += c; if (c === '\\') out += src[++i] || ''; else if (c === q) q = ''; continue; }
        if (c === '"' || c === "'" || (js && c === '`')) { q = c; out += c; continue; }
        if (c === '/' && src[i + 1] === '*') { var e = src.indexOf('*/', i + 2); if (e < 0) e = src.length - 2; out += src.slice(i, e + 2); i = e + 1; continue; }
        if (js && c === '/' && src[i + 1] === '/') { var nl = src.indexOf('\n', i); if (nl < 0) nl = src.length; out += src.slice(i, nl) + '\n' + pad(ind); i = nl; continue; }
        if (!js && c === '(') {
          var dd = 1, j = i + 1;
          while (j < src.length && dd > 0) {
            var cj = src[j];
            if (cj === '(') dd++; else if (cj === ')') dd--;
            else if (cj === '"' || cj === "'") { j++; while (j < src.length && src[j] !== cj) { if (src[j] === '\\') j++; j++; } }
            j++;
          }
          out += src.slice(i, j); i = j - 1; continue;
        }
        if (js && c === '(') par++; else if (js && c === ')') par = Math.max(0, par - 1);
        if (c === '{') { ind++; out = out.replace(/[ \t]+$/, '') + ' {\n' + pad(ind); continue; }
        if (c === '}') { ind = Math.max(0, ind - 1); out = out.replace(/[ \t\n]+$/, '') + '\n' + pad(ind) + '}\n' + pad(ind); continue; }
        if (c === ';' && (!js || par === 0)) { out += ';\n' + pad(ind); continue; }
        if (c === '\n' || c === '\r' || c === '\t') { if (!/\s$/.test(out)) out += ' '; continue; }
        out += c;
      }
      return out.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n');
    }
    function sp(cls, t) { return h('span', { cls: cls, text: t }); }

    // ---- Tree (Elements) ----
    function kidsOf(n) {
      var out = [], c = n.childNodes;
      for (var i = 0; i < c.length; i++) {
        var k = c[i];
        if (k.nodeType === 1) { if (k === host || (k.hasAttribute && k.hasAttribute('data-abtin-inspector'))) continue; out.push(k); }
        else if (k.nodeType === 3) { if (k.nodeValue.trim()) out.push(k); }
        else if (k.nodeType === 8) out.push(k);
      }
      return out;
    }
    function openTag(n) {
      var parts = [sp('', '<'), sp('tg', n.tagName.toLowerCase())];
      Array.prototype.forEach.call(n.attributes, function (a) {
        var v = a.value; if (v.length > 70) v = v.slice(0, 70) + '…';
        parts.push(sp('', ' '), sp('an', a.name));
        if (a.value !== '') parts.push(sp('', '="'), sp('av', v), sp('', '"'));
      });
      parts.push(sp('', '>'));
      return parts;
    }
    function closeTag(tg) { return [sp('', '</'), sp('tg', tg), sp('', '>')]; }
    function renderTree() {
      var wrap = h('div', { cls: 'tree' }), rows = 0, MAX = 1500, selRow = null;
      if (sel) for (var a = sel.parentElement; a; a = a.parentElement) treeOpen.add(a);
      treeOpen.add(document.documentElement);
      if (document.body) treeOpen.add(document.body);
      function row(depth, parts, node, onTap) {
        var r = h('div', { cls: 'tr' + (node && node === sel ? ' sel' : ''), onclick: onTap || function () { if (node && node.nodeType === 1) { fromTree = true; selectEl(node); } } });
        r.style.paddingLeft = (depth * 12 + 2) + 'px';
        parts.forEach(function (p) { r.appendChild(p); });
        wrap.appendChild(r); rows++;
        if (node && node === sel) selRow = r;
        return r;
      }
      function toggle(n) { if (treeOpen.has(n)) treeOpen.delete(n); else treeOpen.add(n); renderBody(); }
      function node(n, d) {
        if (rows > MAX) return;
        if (n.nodeType === 3) { var t = n.nodeValue.trim().replace(/\s+/g, ' '); row(d, [sp('tgl', ''), sp('tx', '"' + (t.length > 120 ? t.slice(0, 120) + '…' : t) + '"')], null); return; }
        if (n.nodeType === 8) { var cm = n.nodeValue.trim().replace(/\s+/g, ' '); row(d, [sp('tgl', ''), sp('cm', '<!-- ' + cm.slice(0, 80) + ' -->')], null); return; }
        var tg = n.tagName.toLowerCase(), kids = kidsOf(n), isVoid = VOID.test(tg);
        if (isVoid || !kids.length) { row(d, [sp('tgl', '')].concat(openTag(n), isVoid ? [] : closeTag(tg)), n); return; }
        if (kids.length === 1 && kids[0].nodeType === 3 && kids[0].nodeValue.trim().length <= 80 && !/^(script|style)$/.test(tg)) {
          row(d, [sp('tgl', '')].concat(openTag(n), [sp('tx', kids[0].nodeValue.trim().replace(/\s+/g, ' '))], closeTag(tg)), n); return;
        }
        var isOpen = treeOpen.has(n);
        var tgl = h('span', { cls: 'tgl', text: isOpen ? '▾' : '▸', onclick: function (e) { e.stopPropagation(); toggle(n); } });
        var tap = function () { if (sel === n) toggle(n); else { fromTree = true; selectEl(n); } };
        if (!isOpen) { row(d, [tgl].concat(openTag(n), [sp('', '…')], closeTag(tg)), n, tap); return; }
        row(d, [tgl].concat(openTag(n)), n, tap);
        var lim = treeLimit.get(n) || 120;
        kids.slice(0, lim).forEach(function (k) { node(k, d + 1); });
        if (kids.length > lim) row(d + 1, [sp('tgl', ''), sp('tx', '… ' + (kids.length - lim) + ' ' + T('مورد دیگر', 'more'))], null, function () { treeLimit.set(n, lim + 200); renderBody(); });
        row(d, [sp('tgl', '')].concat(closeTag(tg)), null);
      }
      var dt = document.doctype;
      if (dt) row(0, [sp('tgl', ''), sp('cm', '<!DOCTYPE ' + dt.name + '>')], null);
      node(document.documentElement, 0);
      body.appendChild(wrap);
      if (selRow && !fromTree) { try { selRow.scrollIntoView({ block: 'center', inline: 'start' }); } catch (e) {} }
      fromTree = false;
    }

    // ---- CSS rules (Styles tab) ----
    function ruleSheets() {
      var out = [], blocked = [], list = [];
      try { list = Array.prototype.slice.call(document.styleSheets); } catch (e) {}
      try { (document.adoptedStyleSheets || []).forEach(function (s) { list.push(s); }); } catch (e) {}
      list.forEach(function (s, i) {
        try {
          if (s.disabled) return;
          if (s.media && s.media.mediaText && !matchMedia(s.media.mediaText).matches) return;
        } catch (e) {}
        var label = s.href ? short(s.href) : (s.ownerNode && s.ownerNode.tagName === 'STYLE' ? '<style>' : T('برگه سبک', 'stylesheet'));
        var rules = null;
        try { rules = s.cssRules; } catch (e) { rules = null; }
        if (rules) out.push({ i: i, label: label, rules: rules, live: true });
        else if (s.href) {
          if (Object.prototype.hasOwnProperty.call(cssCache, s.href)) { var c = cssCache[s.href]; if (c) out.push({ i: i, label: label, rules: c.cssRules, live: false }); }
          else blocked.push(s.href);
        }
      });
      return { sheets: out, blocked: blocked };
    }
    function matchedRules(el) {
      var info = ruleSheets(), out = [];
      info.sheets.forEach(function (sh) {
        var ord = 0;
        (function walk(rules, media) {
          for (var i = 0; i < rules.length; i++) {
            var r = rules[i], t = r.type;
            try {
              if (t === 1) {
                var best = -1;
                splitBy(r.selectorText, ',').forEach(function (p) { p = p.trim(); if (!p) return; try { if (el.matches(p)) best = Math.max(best, specOf(p)); } catch (e) {} });
                if (best < 0) { try { if (el.matches(r.selectorText)) best = specOf(r.selectorText); } catch (e) {} }
                if (best >= 0) out.push({ rule: r, sel: r.selectorText, label: sh.label, media: media, live: sh.live, spec: best, ord: sh.i * 1e6 + ord++ });
              } else if (t === 4) { if (matchMedia(r.media.mediaText).matches) walk(r.cssRules, (media ? media + ' ' : '') + '@media ' + r.media.mediaText); }
              else if (t === 12) { if (CSS.supports(r.conditionText)) walk(r.cssRules, media); }
              else if (t === 3) { if (r.styleSheet) walk(r.styleSheet.cssRules, media); }
              else if (t !== 7 && t !== 5 && t !== 6 && r.cssRules && r.cssRules.length) walk(r.cssRules, media);
            } catch (e) {}
          }
        })(sh.rules, '');
      });
      out.sort(function (a, b) { return b.spec - a.spec || b.ord - a.ord; });
      return { rules: out, blocked: info.blocked };
    }
    function ruleBox(m) {
      var box = h('div', { cls: 'rule' });
      box.appendChild(h('div', { cls: 'src', text: m.label + (m.media ? '   ' + m.media : '') + (m.live ? '' : '   (' + T('فقط‌خواندنی', 'read-only') + ')') }));
      box.appendChild(h('div', { cls: 'rs', text: m.sel + ' {' }));
      splitBy(m.rule.style.cssText, ';').forEach(function (d) {
        var k = d.indexOf(':'); if (k < 1) return;
        var name = d.slice(0, k).trim(), val = d.slice(k + 1).trim(), on = true;
        var inp = h('input', { value: val, spellcheck: false, autocapitalize: 'off', autocomplete: 'off' });
        function apply() {
          if (!m.live) return;
          try {
            var v = inp.value.trim(), im = /!important\s*$/i.test(v);
            v = v.replace(/\s*!important\s*$/i, '');
            if (on && v) m.rule.style.setProperty(name, v, im ? 'important' : ''); else m.rule.style.removeProperty(name);
          } catch (e) {}
          place();
        }
        inp.addEventListener('change', apply);
        if (!m.live) inp.readOnly = true;
        var ck = h('span', { cls: 'ck', text: '☑', onclick: function () { if (!m.live) return; on = !on; ck.textContent = on ? '☑' : '☐'; inp.style.opacity = on ? '1' : '.45'; apply(); } });
        box.appendChild(h('div', { cls: 'dc' }, [ck, h('b', { text: name + ':' }), inp]));
      });
      var foot = [sp('', '}')];
      if (m.live) foot.push(h('button', { text: '+', onclick: function () {
        var v = prompt(T('ویژگی: مقدار (مثال: color: red)', 'property: value (e.g. color: red)'));
        if (!v) return;
        var k = v.indexOf(':'); if (k < 1) return;
        try { m.rule.style.setProperty(v.slice(0, k).trim(), v.slice(k + 1).replace(/;\s*$/, '').trim()); } catch (e) {}
        renderBody(); place();
      } }));
      foot.push(h('button', { text: T('کپی', 'Copy'), onclick: function () { copy(m.rule.cssText); } }));
      box.appendChild(h('div', { cls: 'row' }, foot));
      return box;
    }
    function renderRules(el) {
      var res = matchedRules(el);
      body.appendChild(h('div', { cls: 'sec', text: T('قوانین CSS مطابق (قوی‌ترین بالا)', 'Matched CSS rules (strongest first)') + ' — ' + res.rules.length }));
      if (res.blocked.length) {
        body.appendChild(h('div', { cls: 'sec', text: T('در حال دریافت CSSهای خارجی…', 'Loading external stylesheets…') }));
        res.blocked.forEach(function (href) {
          cssCache[href] = null;
          bgFetch(href).then(function (r) {
            if (r.ok) { try { var cs = new CSSStyleSheet(); cs.replaceSync(r.text); cssCache[href] = cs; } catch (e) {} }
            if (tab === 'css' && sel === el) renderBody();
          });
        });
      }
      res.rules.slice(0, 80).forEach(function (m) { body.appendChild(ruleBox(m)); });
      if (res.rules.length > 80) body.appendChild(h('div', { cls: 'sec', text: '… +' + (res.rules.length - 80) }));
    }

    // ---- Sources ----
    function listSources() {
      var items = [];
      items.push({ g: 'doc', label: T('HTML صفحه (DOM فعلی)', 'Page HTML (live DOM)'), kind: 'html', load: function () {
        return Promise.resolve({ ok: true, text: (document.doctype ? '<!DOCTYPE ' + document.doctype.name + '>\n' : '') + document.documentElement.outerHTML.replace(/<div data-abtin-inspector="1"[^>]*><\/div>/, '') });
      } });
      items.push({ g: 'doc', label: T('سورس اصلی صفحه (از شبکه)', 'Original page source (network)'), kind: 'html', url: location.href, sub: location.href });
      Array.prototype.forEach.call(document.querySelectorAll('link[rel~="stylesheet"], style, script'), function (n) {
        if (n === host) return;
        var tg = n.tagName.toLowerCase();
        if (tg === 'link') { if (n.href) items.push({ g: 'css', label: short(n.href), sub: n.href, url: n.href, kind: 'css' }); }
        else if (tg === 'style') { var tx = n.textContent || ''; items.push({ g: 'css', label: '<style>' + (n.id ? '#' + n.id : ''), sub: tx.length + ' chars', text: tx, kind: 'css' }); }
        else if (n.src) items.push({ g: 'js', label: short(n.src), sub: n.src, url: n.src, kind: 'js' });
        else { var s = n.textContent || ''; var ty = n.type && !/javascript|module/i.test(n.type) ? ' [' + n.type + ']' : ''; items.push({ g: 'js', label: '<script>' + ty, sub: s.length + ' chars', text: s, kind: /json/i.test(n.type || '') ? 'json' : 'js' }); }
      });
      return items;
    }
    function renderSrc() {
      if (view) { renderViewer(); return; }
      var items = listSources(), names = { doc: 'HTML', css: 'CSS', js: 'JavaScript' };
      ['doc', 'css', 'js'].forEach(function (g) {
        var list = items.filter(function (x) { return x.g === g; });
        body.appendChild(h('div', { cls: 'sec', text: names[g] + ' (' + list.length + ')' }));
        list.forEach(function (it) {
          var r = h('div', { cls: 'ch', onclick: function () { openView(it); } }, [sp('', it.label)]);
          if (it.sub) { var s = sp('', '   ' + it.sub); s.style.color = '#9aa0a6'; r.appendChild(s); }
          body.appendChild(r);
        });
      });
    }
    function openView(it) {
      var v = view = { it: it, text: null, shown: null, err: '', pos: 0 };
      var p = it.load ? it.load() : it.url ? bgFetch(it.url) : Promise.resolve({ ok: true, text: it.text || '' });
      p.then(function (r) {
        if (view !== v) return;
        if (r.ok) { v.text = v.shown = r.text; } else v.err = T('دریافت نشد', 'Could not load') + (r.status ? ' (HTTP ' + r.status + ')' : r.error ? ': ' + r.error : '');
        if (tab === 'src') renderBody();
      });
      renderBody();
    }
    function renderViewer() {
      var v = view, MAXV = 400000;
      var q = h('input', { placeholder: T('جستجو در کد…', 'Find in code…'), spellcheck: false });
      var ta = h('textarea', { readOnly: true, spellcheck: false });
      ta.style.height = panel.classList.contains('big') ? '62vh' : '26vh';
      function show() {
        var t = v.shown == null ? '' : v.shown;
        ta.value = v.err ? v.err : v.text == null ? T('در حال دریافت…', 'Loading…') : (t.length > MAXV ? t.slice(0, MAXV) + '\n\n… (' + sizeStr(t.length) + ')' : t);
      }
      function find() {
        var t = ta.value.toLowerCase(), s = q.value.toLowerCase();
        if (!s) return;
        var i = t.indexOf(s, v.pos);
        if (i < 0) { i = t.indexOf(s, 0); if (i < 0) { say(T('پیدا نشد', 'Not found')); return; } }
        v.pos = i + 1;
        try { ta.focus(); ta.setSelectionRange(i, i + s.length); } catch (e) {}
      }
      q.addEventListener('keydown', function (e) { if (e.key === 'Enter') find(); });
      var btns = [
        h('button', { text: '← ' + T('بازگشت', 'Back'), onclick: function () { view = null; renderBody(); } }),
        h('button', { text: T('کپی همه', 'Copy all'), onclick: function () { if (v.text != null) copy(v.text); } })
      ];
      if (v.it.kind !== 'html') btns.push(h('button', { text: T('مرتب‌سازی', 'Beautify'), onclick: function () { if (v.text != null) { v.shown = beautify(v.text, v.it.kind); show(); } } }));
      btns.push(h('button', { text: T('بعدی', 'Find'), onclick: find }));
      body.appendChild(h('div', { cls: 'row' }, btns));
      body.appendChild(h('div', { cls: 'sec', text: v.it.label + (v.text != null ? '  —  ' + sizeStr(v.text.length) : '') }));
      body.appendChild(h('div', { cls: 'row' }, [q]));
      body.appendChild(ta);
      show();
    }

    // ---- Network ----
    var NET_GROUPS = [['all', 'All', null], ['doc', 'Doc', ['main_frame', 'sub_frame']], ['css', 'CSS', ['stylesheet']], ['js', 'JS', ['script']], ['img', 'Img', ['image', 'imageset']], ['xhr', 'XHR', ['xmlhttprequest', 'fetch', 'ping', 'beacon']], ['media', 'Media', ['media']], ['font', 'Font', ['font']], ['ws', 'WS', ['websocket']]];
    function netGroup(e) {
      for (var i = 1; i < NET_GROUPS.length; i++) if (NET_GROUPS[i][2].indexOf(e.type) >= 0) return NET_GROUPS[i][0];
      return 'other';
    }
    // The background page only logs requests while the inspector is open (it starts on the first call); everything that was
    // loaded earlier is rebuilt from the page's own Resource Timing so the list is complete without a reload.
    var NET_TYPES = { script: 'script', css: 'stylesheet', link: 'stylesheet', img: 'image', image: 'image', fetch: 'xmlhttprequest', xmlhttprequest: 'xmlhttprequest', beacon: 'beacon', navigation: 'main_frame', iframe: 'sub_frame', frame: 'sub_frame', video: 'media', audio: 'media', other: 'other' };
    function perfNet(have) {
      var out = [];
      try {
        var seen = {};
        have.forEach(function (e) { seen[e.url] = 1; });
        var nav = performance.getEntriesByType('navigation')[0];
        var l = performance.getEntriesByType('resource');
        if (nav && !seen[nav.name]) { out.push({ id: 'p-nav', url: nav.name, method: 'GET', type: 'main_frame', ts: Math.round(performance.timeOrigin), status: 200, done: true, end: Math.round(performance.timeOrigin + nav.responseEnd), len: nav.encodedBodySize || undefined, perf: true }); }
        for (var i = 0; i < l.length && out.length < 400; i++) {
          var r = l[i];
          if (seen[r.name] || !/^https?:/i.test(r.name)) continue;
          var ty = NET_TYPES[r.initiatorType] || 'other';
          if (/\.(woff2?|ttf|otf)(\?|$)/i.test(r.name)) ty = 'font';
          out.push({ id: 'p-' + i, url: r.name, method: 'GET', type: ty, ts: Math.round(performance.timeOrigin + r.startTime), status: r.responseStatus || 200, done: true, end: Math.round(performance.timeOrigin + r.responseEnd), len: r.encodedBodySize || undefined, cache: r.transferSize === 0 && r.encodedBodySize > 0, perf: true });
        }
      } catch (e) {}
      return out;
    }
    function loadNet() {
      browser.runtime.sendMessage({ t: 'net' }).then(function (l) { l = l || []; netData = perfNet(l).concat(l); if (tab === 'net') renderBody(); }, function () { netData = perfNet([]); if (tab === 'net') renderBody(); });
    }
    function curl(e) {
      var s = "curl '" + e.url.replace(/'/g, "'\\''") + "'";
      if (e.method && e.method !== 'GET') s += ' -X ' + e.method;
      (e.reqH || []).forEach(function (x) { s += " -H '" + (x[0] + ': ' + x[1]).replace(/'/g, "'\\''") + "'"; });
      return s;
    }
    function renderNet() {
      if (netOpen) { renderNetDetail(); return; }
      var chips = NET_GROUPS.map(function (g) { return h('button', { text: g[1], cls: netFilter === g[0] ? 'on' : '', onclick: function () { netFilter = g[0]; renderBody(); } }); });
      chips.push(h('button', { text: '↻', onclick: function () { netData = null; renderBody(); } }));
      chips.push(h('button', { text: T('پاک', 'Clear'), onclick: function () { netClear = Date.now(); renderBody(); } }));
      body.appendChild(h('div', { cls: 'row' }, chips));
      if (netData === null) { body.appendChild(h('div', { cls: 'sec', text: T('در حال دریافت…', 'Loading…') })); loadNet(); return; }
      var list = netData.filter(function (e) {
        if (netClear && e.ts < netClear) return false;
        if (netFilter === 'all') return true;
        return netGroup(e) === netFilter;
      });
      var total = 0; list.forEach(function (e) { if (e.len > 0) total += e.len; });
      body.appendChild(h('div', { cls: 'sec', text: list.length + ' ' + T('درخواست', 'requests') + '  ·  ' + sizeStr(total) }));
      list.slice().reverse().slice(0, 400).forEach(function (e) {
        var st = e.err ? 'ERR' : e.status || (e.done ? '—' : '…');
        var cls = e.err || e.status >= 400 ? 'er' : e.status >= 300 ? 'rd' : 'ok';
        body.appendChild(h('div', { cls: 'nr', onclick: function () { netOpen = e; renderBody(); } }, [
          h('span', { cls: 'ns ' + cls, text: String(st) }), h('span', { cls: 'nz', text: e.method }),
          h('span', { cls: 'nu', text: short(e.url) }), h('span', { cls: 'nz', text: sizeStr(e.len) }),
          h('span', { cls: 'nz', text: e.end ? (e.end - e.ts) + ' ms' : '' })]));
      });
    }
    function renderNetDetail() {
      var e = netOpen;
      body.appendChild(h('div', { cls: 'row' }, [
        h('button', { text: '← ' + T('بازگشت', 'Back'), onclick: function () { netOpen = null; renderBody(); } }),
        h('button', { text: T('کپی URL', 'Copy URL'), onclick: function () { copy(e.url); } }),
        h('button', { text: 'cURL', onclick: function () { copy(curl(e)); } })
      ]));
      function line(k, v) { if (v === '' || v == null) return; body.appendChild(h('div', { cls: 'kv' }, [h('b', { text: k }), h('span', { text: String(v), cls: 'wr' })])); }
      body.appendChild(h('div', { cls: 'sec', text: T('عمومی', 'General') }));
      line('URL', e.url); line('Method', e.method); line('Status', e.err ? e.err : (e.line || e.status)); line('Type', e.type + (e.ctype ? '  ·  ' + e.ctype : ''));
      line('Size', e.len != null ? sizeStr(e.len) : ''); line('Remote IP', e.ip); line('Cache', e.cache ? 'yes' : ''); line('Time', e.end ? (e.end - e.ts) + ' ms' : ''); line('Redirect →', e.redir);
      [[T('هدرهای پاسخ', 'Response headers'), e.resH], [T('هدرهای درخواست', 'Request headers'), e.reqH]].forEach(function (g) {
        body.appendChild(h('div', { cls: 'sec', text: g[0] + (g[1] ? ' (' + g[1].length + ')' : '') }));
        (g[1] || []).forEach(function (x) { line(x[0], x[1]); });
      });
    }

    // ---- Console ----
    function readCon() {
      var out = [];
      try { var b = window.wrappedJSObject.__abtinCon; if (b) for (var i = 0; i < b.length; i++) { try { out.push(JSON.parse(String(b[i]))); } catch (e) {} } } catch (e) {}
      return out;
    }
    function conLine(c) { return h('div', { cls: 'cl ' + c.l, text: (c.l === 'in' ? '› ' : c.l === 'res' ? '‹ ' : '') + c.m }); }
    function conSend(o) { try { document.dispatchEvent(new CustomEvent('abtin-cmd', { detail: JSON.stringify(o) })); } catch (e) {} }
    function onConEvent(e) {
      if (tab !== 'con' || !conListEl || !conListEl.isConnected) return;
      try { var hint = conListEl.querySelector('.sec'); if (hint) hint.remove(); var c = JSON.parse(String(e.detail)); conListEl.appendChild(conLine(c)); body.scrollTop = body.scrollHeight; } catch (x) {}
    }
    document.addEventListener('abtin-con', onConEvent);
    function renderCon() {
      var list = conListEl = h('div'), items = readCon();
      items.forEach(function (c) { list.appendChild(conLine(c)); });
      if (!items.length) list.appendChild(h('div', { cls: 'sec', text: T('پیامی ثبت نشده (از شروع بارگذاری صفحه ثبت می‌شود)', 'No messages yet (recorded from page start)') }));
      var inp = h('input', { placeholder: T('جاوااسکریپت اجرا کنید…', 'Run JavaScript…'), spellcheck: false, autocapitalize: 'off', autocomplete: 'off' });
      function run() { var code = inp.value.trim(); if (!code) return; inp.value = ''; var hint = list.querySelector('.sec'); if (hint) hint.remove(); conSend({ c: 'eval', code: code }); }
      inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') run(); });
      body.appendChild(h('div', { cls: 'row' }, [
        h('button', { text: T('پاک', 'Clear'), onclick: function () { conSend({ c: 'clear' }); renderBody(); } }),
        h('button', { text: T('اجرا', 'Run'), cls: 'on', onclick: run })]));
      body.appendChild(h('div', { cls: 'row' }, [inp]));
      body.appendChild(list);
      body.scrollTop = body.scrollHeight;
    }

    // ---- Storage ----
    function renderSto() {
      ['localStorage', 'sessionStorage'].forEach(function (nm) {
        var st = null;
        try { st = window[nm]; } catch (e) {}
        body.appendChild(h('div', { cls: 'sec', text: nm + (st ? ' (' + st.length + ')' : '') }));
        if (!st) return;
        var keys = [];
        try { for (var i = 0; i < st.length && i < 200; i++) keys.push(st.key(i)); } catch (e) {}
        keys.forEach(function (k) {
          var v = ''; try { v = st.getItem(k) || ''; } catch (e) {}
          body.appendChild(kv(k, v.length > 3000 ? v.slice(0, 3000) : v, function (nv) { st.setItem(k, nv); }, function () { st.removeItem(k); }));
        });
        body.appendChild(h('div', { cls: 'row' }, [
          h('button', { text: '+ ' + T('کلید', 'Key'), onclick: function () { var k = prompt(T('نام کلید', 'Key name')); if (k) { try { st.setItem(k, ''); } catch (e) {} renderBody(); } } }),
          h('button', { text: T('پاک کردن همه', 'Clear all'), cls: 'bad', onclick: function () { try { st.clear(); } catch (e) {} renderBody(); } })]));
      });
      var cs = []; try { cs = document.cookie ? document.cookie.split(/;\s*/) : []; } catch (e) {}
      body.appendChild(h('div', { cls: 'sec', text: 'Cookies (' + cs.length + ') — ' + T('بدون HttpOnly', 'not HttpOnly') }));
      cs.forEach(function (c) {
        var i = c.indexOf('='), k = i < 0 ? c : c.slice(0, i), v = i < 0 ? '' : c.slice(i + 1);
        body.appendChild(kv(k, v, function (nv) { document.cookie = k + '=' + nv + '; path=/'; }, function () { document.cookie = k + '=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/'; }));
      });
    }
    var EXT = { tree: renderTree, src: renderSrc, net: renderNet, con: renderCon, sto: renderSto };

    function render() { renderBar(); renderTabs(); renderCrumb(); renderBody(); place(); }

    // While picking, the page must not react to the tap: swallow its events and select the element instead.
    function inPanel(e) { return e.target === host || (e.composedPath && e.composedPath().indexOf(host) >= 0); }
    function swallow(e) { if (!pick || inPanel(e)) return; e.stopImmediatePropagation(); }
    function onClick(e) {
      if (!pick || inPanel(e)) return;
      e.preventDefault(); e.stopImmediatePropagation();
      selectEl(e.target);
    }
    var SW = ['touchstart', 'touchend', 'pointerdown', 'pointerup', 'mousedown', 'mouseup', 'dblclick', 'contextmenu', 'submit'];
    SW.forEach(function (n) { window.addEventListener(n, swallow, { capture: true, passive: true }); });
    window.addEventListener('click', onClick, true);
    window.addEventListener('scroll', place, { capture: true, passive: true });
    window.addEventListener('resize', place);
    timer = setInterval(place, 400);

    function close() {
      SW.forEach(function (n) { window.removeEventListener(n, swallow, true); });
      window.removeEventListener('click', onClick, true);
      window.removeEventListener('scroll', place, true);
      window.removeEventListener('resize', place);
      clearInterval(timer); clearTimeout(msgT);
      try { browser.runtime.sendMessage({ t: 'netOff' }).catch(function () {}); } catch (e) {}
      document.removeEventListener('abtin-con', onConEvent);
      host.remove(); insp = null;
    }
    render();
    return { close: close };
  }

  function onCmd(m) {
    if (!m) return;
    if (m.cmd === 'focusLogin') {
      try {
        var fields = Array.from(document.querySelectorAll('input:not([type=hidden]):not([disabled]):not([readonly]),textarea'));
        var visible = fields.filter(function (x) { return !!(x.offsetWidth || x.offsetHeight || x.getClientRects().length); });
        var user = visible.find(function (x) { return x.type !== 'password' && /user|email|login|account|identifier/i.test(((x.autocomplete || '') + ' ' + (x.name || '') + ' ' + (x.id || '') + ' ' + (x.placeholder || '')).toLowerCase()); });
        var target = user || visible.find(function (x) { return x.type === 'password'; }) || visible.find(function (x) { return x.type !== 'password'; });
        if (target) { target.focus(); try { target.click(); } catch (_) {} return true; }
      } catch (e) {}
      return false;
    }
    if (m.cmd === 'submitLogin') {
      try {
        if (location.hostname.toLowerCase() !== String(m.host || '').toLowerCase()) return false;
        var ps = Array.from(document.querySelectorAll('input[type=password]:not([disabled]):not([readonly])'));
        if (ps.length !== 1 || !ps[0].value || !ps[0].form) return false;
        var f = ps[0].form, a = new URL(f.getAttribute('action') || location.href, location.href);
        if (a.origin !== location.origin) return false;
        if (typeof f.requestSubmit === 'function') f.requestSubmit(); else f.submit();
        return true;
      } catch (e) { return false; }
    }
    if (m.cmd === 'vaultFill') {
      try {
        if (location.protocol !== 'https:') return false;
        var d = m.item || {}, es = Array.from(document.querySelectorAll('input:not([type=hidden]):not([type=password]):not([disabled]):not([readonly]),textarea,select'));
        var find = function (re) { return es.find(function (x) { return re.test(((x.autocomplete || '') + ' ' + (x.name || '') + ' ' + (x.id || '') + ' ' + (x.placeholder || '')).toLowerCase()); }); };
        var put = function (re, v) { if (!v) return false; var x = find(re); if (!x) return false; try { x.focus(); x.value = v; x.dispatchEvent(new Event('input', {bubbles:true})); x.dispatchEvent(new Event('change', {bubbles:true})); return true; } catch (e) { return false; } };
        var n = 0;
        if (d.kind === 'card') {
          n += put(/cc-name|card.?holder|card.?name/, d.holder) ? 1 : 0;
          n += put(/cc-number|card.?number/, d.number) ? 1 : 0;
          var p = String(d.expiry || '').split(/[\/\-]/), mth = p[0] || '', yr = p[1] || '';
          var hm = put(/cc-exp-month|exp.?month/, mth), hy = put(/cc-exp-year|exp.?year/, yr.length === 2 ? '20' + yr : yr);
          n += (hm || hy) ? 1 : (put(/cc-exp|expir(y|ation)?/, d.expiry) ? 1 : 0);
        } else if (d.kind === 'address') {
          var parts = String(d.name || '').trim().split(/\s+/), first = parts.shift() || '', last = parts.join(' ');
          n += put(/given-name|first.?name/, first) ? 1 : 0; n += put(/family-name|last.?name/, last) ? 1 : 0;
          if (!first && !last) n += put(/full.?name/, d.name) ? 1 : 0;
          n += put(/street-address|address.?line.?1|street/, d.street) ? 1 : 0;
          n += put(/address-level2|(^|\s)city(\s|$)/, d.city) ? 1 : 0;
          n += put(/address-level1|state|province|region/, d.region) ? 1 : 0;
          n += put(/postal-code|zip/, d.postal) ? 1 : 0; n += put(/country/, d.country) ? 1 : 0;
          n += put(/tel|phone/, d.phone) ? 1 : 0; n += put(/email/, d.email) ? 1 : 0;
        }
        return n > 0;
      } catch (e) { return false; }
    }
    if (m.cmd === 'reader') toggleReader(!!m.dark, m.lang);
    else if (m.cmd === 'uiCfg') { mbCfg(m); }
    else if (m.cmd === 'savePage') savePage();
    else if (m.cmd === 'back') pwaBack(m.id);
    else if (m.cmd === 'inspect') inspector(m);
    else if (m.cmd === 'otp') onOtp(m);
    else if (m.cmd === 'media') reportMedia({ url: m.url, mime: m.mime, size: m.size, kind: m.kind, part: m.part, ts: m.ts });
  }


  // ======================================================================
  //  Save page: one self-contained .html (styles + images inlined, scripts removed)
  // ======================================================================
  function savePage() {
    var TOTAL = 24 * 1024 * 1024, IMG = 1536 * 1024, used = 0;
    function send(o) {
      if (!port) { tries = 0; connect(); }
      try { port.postMessage(o); } catch (e) {}
    }
    function abs(u) { try { return new URL(u, document.baseURI).href; } catch (e) { return ''; } }
    function toData(url) {
      return fetch(url, { credentials: 'include' }).then(function (r) {
        if (!r.ok) throw 0;
        return r.blob();
      }).then(function (b) {
        if (b.size > IMG || used + b.size > TOTAL) throw 0;
        used += b.size;
        return new Promise(function (ok, no) {
          var fr = new FileReader();
          fr.onload = function () { ok(fr.result); };
          fr.onerror = no;
          fr.readAsDataURL(b);
        });
      });
    }
    var root = document.documentElement.cloneNode(true);
    var jobs = [];
    root.querySelectorAll('script, noscript, iframe, object, embed, link[rel=preload], link[rel=modulepreload], link[rel=prefetch]').forEach(function (n) { n.remove(); });
    root.querySelectorAll('[onclick],[onload],[onerror]').forEach(function (n) { n.removeAttribute('onclick'); n.removeAttribute('onload'); n.removeAttribute('onerror'); });
    root.querySelectorAll('link[rel~=stylesheet][href]').forEach(function (l) {
      var u = abs(l.getAttribute('href'));
      if (!u) return;
      jobs.push(fetch(u, { credentials: 'include' }).then(function (r) { return r.ok ? r.text() : Promise.reject(); }).then(function (css) {
        if (used + css.length > TOTAL) throw 0;
        used += css.length;
        // make relative url() / @import in the stylesheet absolute, so images still resolve when online
        css = css.replace(/url\(\s*(['"]?)(?!data:|https?:|#|\/\/)([^'")]+)\1\s*\)/gi, function (_, q, rel) {
          try { return 'url("' + new URL(rel, u).href + '")'; } catch (e) { return _; }
        });
        var st = document.createElement('style');
        st.textContent = css;
        l.replaceWith(st);
      }).catch(function () {}));
    });
    root.querySelectorAll('img[src], source[srcset], img[srcset]').forEach(function (im) {
      im.removeAttribute('srcset'); im.removeAttribute('loading');
      var u = im.getAttribute('src');
      if (!u || /^data:/i.test(u)) return;
      u = abs(u);
      if (!u) return;
      im.setAttribute('src', u);
      jobs.push(toData(u).then(function (d) { im.setAttribute('src', d); }).catch(function () {}));
    });
    root.querySelectorAll('a[href]').forEach(function (a) { var h = abs(a.getAttribute('href')); if (h) a.setAttribute('href', h); });
    var head = root.querySelector('head');
    if (head) {
      var b = document.createElement('base');
      b.setAttribute('href', document.baseURI);
      head.insertBefore(b, head.firstChild);
      head.insertBefore(document.createComment(' Saved by Abtin Browser from ' + location.href + ' on ' + new Date().toISOString() + ' '), head.firstChild);
    }
    Promise.all(jobs).then(function () {
      var html = '<!DOCTYPE html>\n' + root.outerHTML;
      send({ t: 'pageSaved', url: location.href, title: document.title || '', html: html });
    }).catch(function () { send({ t: 'pageSaved', url: location.href, title: '', html: '' }); });
  }

  // ======================================================================
  //  Media detection (the app shows a download / play button when something is found)
  // ======================================================================
  var seenMedia = {}, pendingMedia = [], blobSent = false;
  function posterUrl() {
    var v = document.querySelector('video[poster]');
    return v && v.poster ? v.poster : '';
  }
  function sendMedia(m) {
    try {
      port.postMessage({ t: 'media', url: m.url || '', mime: m.mime || '', size: typeof m.size === 'number' ? m.size : -1, kind: m.kind || 'video',
        part: m.part || '', ts: m.ts || Date.now(), page: location.href, title: document.title || '', poster: m.poster || posterUrl() });
    } catch (e) {}
  }
  function reportMedia(m) {
    if (!m) return;
    var key = m.url || ('#' + m.kind);
    if (seenMedia[key]) return;
    seenMedia[key] = 1;
    if (!port) { pendingMedia.push(m); return; }
    sendMedia(m);
  }
  function flushMedia() {
    if (!port || !pendingMedia) return;   // connect() can run before this block initialised the queue
    pendingMedia.splice(0).forEach(sendMedia);
  }
  function mediaKindOf(url, el) {
    var path = url.split('#')[0].split('?')[0].toLowerCase();
    if (/\.m3u8$/.test(path)) return 'hls';
    if (/\.(mp3|m4a|ogg|oga|opus|flac|wav)$/.test(path)) return 'audio';
    return el && el.tagName === 'AUDIO' ? 'audio' : 'video';
  }
  function cleanMediaUrl(u) {
    try {
      var o = new URL(u, location.href);
      if (/(^|\.)(fbcdn\.net|cdninstagram\.com)$/.test(o.hostname)) { o.searchParams.delete('bytestart'); o.searchParams.delete('byteend'); }
      return o.toString();
    } catch (e) { return u; }
  }
  var scanN = 0;
  function scanMedia() {
    if (document.visibilityState === 'hidden') return;
    try {
      var els = document.querySelectorAll('video,audio,video source,audio source');
      for (var i = 0; i < els.length; i++) {
        var el = els[i], src = el.currentSrc || el.src || '';
        if (/^https?:/i.test(src)) {
          var u = cleanMediaUrl(src);
          reportMedia({ url: u, kind: mediaKindOf(u, el), mime: el.type || '', size: -1, poster: el.poster || '' });
        } else if (/^blob:/i.test(src) && !blobSent) {
          blobSent = true;
          reportMedia({ url: '', kind: 'blob' });
        }
      }
      var metas = document.querySelectorAll('meta[property="og:video"],meta[property="og:video:url"],meta[property="og:video:secure_url"],meta[name="twitter:player:stream"]');
      for (var j = 0; j < metas.length; j++) {
        var c = metas[j].content;
        if (/^https?:/i.test(c) && /\.(mp4|m3u8|webm|mov)(\?|$)/i.test(c)) reportMedia({ url: cleanMediaUrl(c), kind: mediaKindOf(c, null), size: -1 });
      }
      var as = (document.querySelector('video,audio') || (scanN++ % 3 === 0)) ? document.querySelectorAll('a[href]') : [];
      for (var k = 0; k < as.length && k < 400; k++) {
        var h = as[k].href;
        if (/\.(mp4|webm|mkv|mov|m4v|mp3|m4a)(\?|#|$)/i.test(h)) reportMedia({ url: h, kind: mediaKindOf(h, null), size: -1 });
      }
    } catch (e) {}
  }
  setInterval(scanMedia, 5000);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', scanMedia); else scanMedia();
  browser.runtime.sendMessage({ t: 'recentMedia' }).then(function (l) {
    (l || []).forEach(reportMedia);
  }).catch(function () {});


  // ======================================================================
  //  In-page video buttons (download / player), like Samsung Internet's video assistant.
  //  The X hides them for the whole site (remembered); they can be re-enabled in Settings.
  // ======================================================================
  var prOn = true, sbOn = true, mbOn = true, mbFa = true, mbOff = {}, mbHost = null, mbShadow = null, mbBox = null, mbRaf = 0, mbTarget = null;
  function mbCfg(c) {
    if (typeof c.mediaBtn === 'boolean') mbOn = c.mediaBtn;
    if (typeof c.pullRefresh === 'boolean') prOn = c.pullRefresh;
    if (typeof c.scrollBtn === 'boolean') sbOn = c.scrollBtn;
    sbTick();
    if (c.lang) mbFa = c.lang !== 'en';
    if (c.resetOff) mbOff = {};
    try {
      browser.storage.local.get('mbOff').then(function (r) { if (!c.resetOff) mbOff = (r && r.mbOff) || {}; mbTick(); }).catch(function () {});
    } catch (e) {}
    mbTick();
  }
  // The X closes the buttons on this site; turning the video buttons off and on again in the settings brings them back everywhere.
  function mbDismissed() { return !!mbOff[location.hostname]; }
  function mbDismiss() {
    mbOff[location.hostname] = 1;
    try { browser.storage.local.set({ mbOff: mbOff }).catch(function () {}); } catch (e) {}
    mbTick();
  }
  function mbPickVideo() {
    var best = null, bestA = 0, vh = window.innerHeight || 0, vw = window.innerWidth || 0;
    var vs = document.getElementsByTagName('video');
    for (var i = 0; i < vs.length; i++) {
      var v = vs[i], r = v.getBoundingClientRect();
      if (r.width < 150 || r.height < 90) continue;
      var w = Math.min(r.right, vw) - Math.max(r.left, 0), h = Math.min(r.bottom, vh) - Math.max(r.top, 0);
      if (w < 120 || h < 70) continue;
      if (v.readyState < 1 && !v.currentSrc && !v.src && !v.querySelector('source')) continue;
      var cs = getComputedStyle(v);
      if (cs.visibility === 'hidden' || cs.display === 'none' || parseFloat(cs.opacity) === 0) continue;
      var a = w * h * (v.paused ? 1 : 2);
      if (a > bestA) { bestA = a; best = v; }
    }
    return best;
  }
  // when each <video> started loading its current source: used to tell which sniffed stream belongs to which video (blob/MSE players)
  function mbMark(ev) {
    var v = ev.target;
    if (!v || v.tagName !== 'VIDEO') return;
    if (ev.type === 'loadstart' || !v.__abT) v.__abT = Date.now();
  }
  ['loadstart', 'play', 'playing'].forEach(function (n) { document.addEventListener(n, mbMark, true); });
  function mbBuild() {
    if (mbHost) return;
    mbHost = document.createElement('div');
    mbHost.id = '__abtin_mb';
    mbHost.style.cssText = 'all:initial;position:fixed;left:0;top:0;width:0;height:0;z-index:2147483646;';
    mbShadow = mbHost.attachShadow({ mode: 'closed' });
    var st0 = document.createElement('style');
    st0.textContent = '.b{position:fixed;display:none;gap:2px;align-items:center;padding:3px;border-radius:22px;background:#181a20;' +
      'box-shadow:0 2px 10px rgba(0,0,0,.45);direction:ltr;font:600 12px/1 sans-serif;color:#fff;touch-action:manipulation}' +
      '.b button{all:unset;box-sizing:border-box;display:flex;align-items:center;gap:5px;height:34px;min-width:34px;padding:0 10px;border-radius:17px;color:#fff;cursor:pointer;justify-content:center;-webkit-tap-highlight-color:transparent}' +
      '.b button:active{background:#343943}.b .x{padding:0;width:30px;min-width:30px;opacity:.8}.b svg{width:18px;height:18px;fill:#fff;flex:none}' +
      '.b .d{background:#2f7df6}';
    mbShadow.appendChild(st0);
    mbBox = document.createElement('div');
    mbBox.className = 'b';
    var ic = {
      dl: '<svg viewBox="0 0 24 24"><path d="M5 20h14v-2H5v2zM12 4v9.2l3.6-3.6L17 11l-5 5-5-5 1.4-1.4L11 13.2V4h1z"/></svg>',
      pl: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',
      x: '<svg viewBox="0 0 24 24"><path d="M18.3 5.7 12 12l6.3 6.3-1.4 1.4L10.6 13.4 4.3 19.7 2.9 18.3 9.2 12 2.9 5.7 4.3 4.3l6.3 6.3 6.3-6.3z" transform="translate(1.2 0) scale(.9)"/></svg>'
    };
    function mk(cls, svg, label, act) {
      var b = document.createElement('button');
      b.className = cls;
      b.innerHTML = svg + (label ? '<span>' + label + '</span>' : '');
      ['pointerdown', 'pointerup', 'touchstart', 'touchend', 'mousedown', 'mouseup'].forEach(function (n) {
        b.addEventListener(n, function (ev) { ev.stopPropagation(); }, true);
      });
      b.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); act(); }, true);
      return b;
    }
    mbBox.appendChild(mk('d', ic.dl, mbFa ? 'دانلود' : 'Download', function () { mbAct('download'); }));
    mbBox.appendChild(mk('p', ic.pl, mbFa ? 'پلیر' : 'Player', function () { mbAct('play'); }));
    mbBox.appendChild(mk('x', ic.x, '', mbDismiss));
    mbShadow.appendChild(mbBox);
    (document.documentElement || document.body).appendChild(mbHost);
  }
  function mbAct(act) {
    var v = mbTarget, u = v ? (v.currentSrc || v.src || '') : '', hint = [];
    try {   // mse.js (page world) lists the real stream URLs that feed this blob / MSE video
      document.dispatchEvent(new CustomEvent('__abtin_refresh'));
      var hv = v && v.getAttribute('data-abtin-u');
      if (hv) hint = JSON.parse(hv);
    } catch (e) {}
    var o = { t: 'mediaAct', act: act, url: /^https?:/i.test(u) ? cleanMediaUrl(u) : '', hint: hint, page: location.href, title: document.title || '', poster: (v && v.poster) || '', t0: (v && v.__abT) || 0 };
    if (!port) { tries = 0; connect(); }
    try { port.postMessage(o); } catch (e) {}
  }
  function mbTick() {
    if (mbRaf) return;
    mbRaf = requestAnimationFrame(function () {
      mbRaf = 0;
      try {
        if (!mbOn || mbDismissed() || document.visibilityState === 'hidden') { if (mbBox) mbBox.style.display = 'none'; mbTarget = null; return; }
        var v = mbPickVideo();
        if (!v) { if (mbBox) mbBox.style.display = 'none'; mbTarget = null; return; }
        mbBuild();
        mbTarget = v;
        var r = v.getBoundingClientRect(), vw = window.innerWidth || 0;
        mbBox.style.display = 'flex';
        var w = mbBox.offsetWidth || 150;
        var left = Math.max(6, Math.min(r.right - w - 8, vw - w - 6));
        var top = Math.max(6, r.top + 8);
        mbBox.style.left = left + 'px';
        mbBox.style.top = top + 'px';
      } catch (e) {}
    });
  }
  setInterval(function () { if (document.visibilityState !== 'hidden' && document.querySelector('video')) mbTick(); }, 800);
  window.addEventListener('scroll', mbTick, { passive: true, capture: true });
  window.addEventListener('resize', mbTick, { passive: true });
  document.addEventListener('play', mbTick, true);
  document.addEventListener('loadedmetadata', mbTick, true);


  // ======================================================================
  //  Pull down to refresh + Opera-style jump-to-top / jump-to-bottom button
  // ======================================================================
  var prHost = null, prDot = null, prY0 = 0, prX0 = 0, prDy = 0, prActive = false, PR_MAX = 150, PR_GO = 95;
  function prAtTop(el) {
    if ((window.pageYOffset || document.documentElement.scrollTop || 0) > 0) return false;
    for (var n = el; n && n !== document.body && n !== document.documentElement; n = n.parentElement) {
      if (n.scrollTop > 0) return false;
    }
    return true;
  }
  function prBuild() {
    if (prHost) return;
    prHost = document.createElement('div');
    prHost.style.cssText = 'all:initial;position:fixed;left:0;top:0;width:100%;height:0;z-index:2147483646;pointer-events:none;';
    var sh = prHost.attachShadow({ mode: 'closed' });
    prDot = document.createElement('div');
    prDot.style.cssText = 'position:absolute;left:50%;top:0;width:40px;height:40px;margin-left:-20px;border-radius:50%;background:#fff;box-shadow:0 2px 10px rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center;transform:translateY(-60px);will-change:transform';
    prDot.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22" style="transition:transform .15s"><path fill="#2f7df6" d="M17.65 6.35A7.96 7.96 0 0 0 12 4a8 8 0 1 0 7.73 10h-2.08A6 6 0 1 1 12 6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/></svg>';
    var prSt = document.createElement('style');
    prSt.textContent = '@keyframes abspin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}';
    sh.appendChild(prSt);
    sh.appendChild(prDot);
    (document.documentElement || document.body).appendChild(prHost);
  }
  function prSet(dy) {
    prBuild();
    var y = Math.min(dy, PR_MAX) * .75 - 50;
    prDot.style.transition = 'none';
    prDot.style.transform = 'translateY(' + y + 'px)';
    prDot.firstChild.style.animation = 'none';
    prDot.firstChild.style.transform = 'rotate(' + (dy * 3) + 'deg)';
  }
  function prHide(spin) {
    if (!prDot) return;
    prDot.style.transition = 'transform .2s';
    prDot.style.transform = 'translateY(-60px)';
  }
  window.addEventListener('touchstart', function (e) {
    prActive = false; prDy = 0;
    if (!prOn || e.touches.length !== 1 || document.fullscreenElement) return;
    if (!prAtTop(e.target)) return;
    prY0 = e.touches[0].clientY; prX0 = e.touches[0].clientX; prActive = true;
  }, { passive: true, capture: true });
  window.addEventListener('touchmove', function (e) {
    if (!prActive) return;
    var dy = e.touches[0].clientY - prY0, dx = Math.abs(e.touches[0].clientX - prX0);
    if (dy <= 0 || (window.pageYOffset || 0) > 0) { if (prDy > 0) prHide(); prActive = dy > 0 && prActive; prDy = 0; if (dy <= 0) prActive = false; return; }
    if (dx > dy) { prActive = false; prHide(); return; }
    prDy = dy;
    if (dy > 12) prSet(dy);
  }, { passive: true, capture: true });
  function prEnd() {
    if (!prActive) return;
    var go = prDy >= PR_GO;
    prActive = false; prDy = 0;
    if (go) {
      if (prDot) { prDot.style.transition = 'transform .15s'; prDot.style.transform = 'translateY(' + (PR_GO * .75 - 50) + 'px)'; prDot.firstChild.style.transition = 'none'; prDot.firstChild.style.animation = 'abspin .6s linear infinite'; }
      setTimeout(function () { try { location.reload(); } catch (e) {} }, 450);
    } else prHide();
  }
  window.addEventListener('touchend', prEnd, { passive: true, capture: true });
  window.addEventListener('touchcancel', function () { prActive = false; prDy = 0; prHide(); }, { passive: true, capture: true });

  var sbHost = null, sbBtn = null, sbLast = 0, sbDir = 0, sbHideT = 0, sbRaf = 0;
  function sbBuild() {
    if (sbHost) return;
    sbHost = document.createElement('div');
    sbHost.style.cssText = 'all:initial;position:fixed;right:0;bottom:0;width:0;height:0;z-index:2147483645;';
    var sh = sbHost.attachShadow({ mode: 'closed' });
    sbBtn = document.createElement('button');
    sbBtn.style.cssText = 'all:initial;position:fixed;right:14px;bottom:84px;width:44px;height:44px;border-radius:50%;background:rgba(30,30,36,.78);box-shadow:0 2px 10px rgba(0,0,0,.4);display:none;align-items:center;justify-content:center;opacity:0;transition:opacity .2s;-webkit-tap-highlight-color:transparent;cursor:pointer';
    sbBtn.innerHTML = '<svg viewBox="0 0 24 24" width="26" height="26"><path fill="#fff" d="M12 8l6 6-1.4 1.4L12 10.8l-4.6 4.6L6 14z"/></svg>';
    ['touchstart', 'touchend', 'pointerdown', 'pointerup', 'mousedown', 'mouseup'].forEach(function (n) { sbBtn.addEventListener(n, function (ev) { ev.stopPropagation(); }, true); });
    sbBtn.addEventListener('click', function (ev) {
      ev.preventDefault(); ev.stopPropagation();
      var top = sbDir < 0;
      try { window.scrollTo({ top: top ? 0 : Math.max(document.documentElement.scrollHeight, document.body ? document.body.scrollHeight : 0), behavior: 'smooth' }); } catch (e) {}
      sbShow(false);
    }, true);
    sh.appendChild(sbBtn);
    (document.documentElement || document.body).appendChild(sbHost);
  }
  function sbShow(on) {
    if (!sbBtn) return;
    clearTimeout(sbHideT);
    if (!on) { sbBtn.style.opacity = '0'; sbHideT = setTimeout(function () { sbBtn.style.display = 'none'; }, 220); return; }
    sbBtn.style.display = 'flex';
    requestAnimationFrame(function () { sbBtn.style.opacity = '1'; });
    sbHideT = setTimeout(function () { sbShow(false); }, 3000);
  }
  function sbTick() { if (!sbOn && sbBtn) sbShow(false); }
  window.addEventListener('scroll', function () {
    if (!sbOn || sbRaf) return;
    sbRaf = requestAnimationFrame(function () {
      sbRaf = 0;
      try {
        var y = window.pageYOffset || document.documentElement.scrollTop || 0;
        var h = Math.max(document.documentElement.scrollHeight, document.body ? document.body.scrollHeight : 0) - (window.innerHeight || 0);
        var d = y - sbLast;
        sbLast = y;
        if (Math.abs(d) < 14 || h < (window.innerHeight || 600) * 1.5) return;
        var dir = d > 0 ? 1 : -1;
        if ((dir < 0 && y < 120) || (dir > 0 && y > h - 120)) { if (sbBtn) sbShow(false); return; }
        sbBuild();
        sbDir = dir;
        sbBtn.firstChild.style.transform = dir < 0 ? 'none' : 'rotate(180deg)';
        sbShow(true);
      } catch (e) {}
    });
  }, { passive: true, capture: true });

  // ======================================================================
  //  Reader mode
  // ======================================================================
  var RDR = { size: 19, theme: null };
  var THEMES = {
    light: { bg: '#fbfbf8', fg: '#1b1b1b', sub: '#6b6b6b', link: '#0a58d6', bar: '#eeeeea', line: '#d9d9d2' },
    sepia: { bg: '#f4ecd8', fg: '#3a2f1d', sub: '#7a6a4f', link: '#8a4b08', bar: '#e9dfc6', line: '#d8c9a6' },
    dark: { bg: '#0d1b30', fg: '#e6edf7', sub: '#97a8c2', link: '#7db4ff', bar: '#16294a', line: '#243b63' }
  };
  var UNLIKELY = /(^|[\s_-])(banner|breadcrumb|combx|comment|community|cover-wrap|disqus|extra|footer|gdpr|header|legend|menu|related|remark|replies|rss|shoutbox|sidebar|skyscraper|social|sponsor|supplemental|ad-break|agegate|pagination|pager|popup|share|newsletter|subscribe|cookie|nav|toolbar|widget|promo|advert|ads?)([\s_-]|$)/i;
  var MAYBE = /(article|body|column|content|main|shadow|post|entry|story)/i;
  var POSITIVE = /article|body|content|entry|hentry|h-entry|main|page|post|text|blog|story/i;
  var NEGATIVE = /hidden|banner|combx|comment|com-|contact|foot|footer|footnote|gdpr|masthead|media|meta|outbrain|promo|related|scroll|share|shoutbox|sidebar|skyscraper|sponsor|shopping|tags|tool|widget/i;
  var DROP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, IFRAME: 1, FORM: 1, NAV: 1, ASIDE: 1, FOOTER: 1, BUTTON: 1, INPUT: 1, SELECT: 1, TEXTAREA: 1, SVG: 1, CANVAS: 1, OBJECT: 1, EMBED: 1, AUDIO: 1, VIDEO: 1, LINK: 1, META: 1, TEMPLATE: 1, DIALOG: 1 };
  var KEEP = { P: 1, H1: 1, H2: 1, H3: 1, H4: 1, H5: 1, H6: 1, UL: 1, OL: 1, LI: 1, BLOCKQUOTE: 1, PRE: 1, CODE: 1, EM: 1, STRONG: 1, B: 1, I: 1, A: 1, BR: 1, IMG: 1, FIGURE: 1, FIGCAPTION: 1, TABLE: 1, THEAD: 1, TBODY: 1, TR: 1, TD: 1, TH: 1, HR: 1, SUP: 1, SUB: 1 };

  function txt(el) { return (el.textContent || '').replace(/\s+/g, ' ').trim(); }
  function weight(el) {
    var w = 0, s = (el.className && el.className.baseVal === undefined ? el.className : '') + ' ' + (el.id || '');
    if (typeof s !== 'string') return 0;
    if (POSITIVE.test(s)) w += 25;
    if (NEGATIVE.test(s)) w -= 25;
    return w;
  }
  function linkDensity(el) {
    var t = txt(el).length;
    if (!t) return 0;
    var n = 0;
    [].forEach.call(el.getElementsByTagName('a'), function (a) { n += txt(a).length; });
    return n / t;
  }
  function visible(el) {
    try { var cs = getComputedStyle(el); return cs.display !== 'none' && cs.visibility !== 'hidden'; } catch (e) { return true; }
  }

  // Readability-style scoring: paragraphs vote for their parent and grandparent.
  function findArticle() {
    var scores = new Map(), order = [];
    function init(el) {
      if (scores.has(el)) return;
      var s = 0;
      switch (el.tagName) {
        case 'DIV': s = 5; break;
        case 'PRE': case 'TD': case 'BLOCKQUOTE': s = 3; break;
        case 'ADDRESS': case 'OL': case 'UL': case 'DL': case 'DD': case 'DT': case 'LI': case 'FORM': s = -3; break;
        case 'H1': case 'H2': case 'H3': case 'H4': case 'H5': case 'H6': case 'TH': s = -5; break;
      }
      scores.set(el, s + weight(el));
      order.push(el);
    }
    var paras = document.querySelectorAll('p,pre,td,blockquote,div,li');
    for (var i = 0; i < paras.length && i < 6000; i++) {
      var p = paras[i];
      if (p.tagName === 'DIV' || p.tagName === 'LI') {
        // only "text divs": direct text, no block children
        if (p.querySelector('p,div,ul,ol,table,blockquote,pre,h1,h2,h3,h4,h5,h6')) continue;
      }
      var t = txt(p);
      if (t.length < 25) continue;
      var par = p.parentElement;
      if (!par || !visible(p)) continue;
      var gp = par.parentElement;
      init(par); if (gp) init(gp);
      var add = 1 + (t.match(/[,،،]/g) || []).length + Math.min(Math.floor(t.length / 100), 3);
      scores.set(par, scores.get(par) + add);
      if (gp) scores.set(gp, scores.get(gp) + add / 2);
    }
    var best = null, bestScore = 0;
    order.forEach(function (el) {
      var sc = scores.get(el) * (1 - linkDensity(el));
      if (sc > bestScore) { bestScore = sc; best = el; }
    });
    // hop up one level while the parent holds nearly all of the same text (avoids picking one half of a post)
    while (best && best.parentElement && best.parentElement !== document.body && best.parentElement !== document.documentElement) {
      var pt = txt(best.parentElement).length, bt = txt(best).length;
      if (bt > 0 && pt < bt * 1.15 && !UNLIKELY.test((best.parentElement.className || '') + ' ' + (best.parentElement.id || ''))) best = best.parentElement; else break;
    }
    return best;
  }

  function absUrl(u) { try { return new URL(u, document.baseURI).href; } catch (e) { return ''; } }

  function pickImg(img) {
    var src = img.getAttribute('src') || '';
    var lazy = img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || img.getAttribute('data-original') || '';
    if (lazy && (!src || /^data:/.test(src))) src = lazy;
    if (!src) {
      var ss = img.getAttribute('srcset') || img.getAttribute('data-srcset') || '';
      if (ss) src = ss.split(',')[0].trim().split(/\s+/)[0];
    }
    return src && !/^data:image\/(gif|svg)/.test(src) ? absUrl(src) : '';
  }

  function st(el, css) { el.style.cssText = css; return el; }

  // Copy only whitelisted tags into the overlay; everything else is unwrapped or dropped.
  function clean(src, out, th) {
    for (var n = src.firstChild; n; n = n.nextSibling) {
      if (n.nodeType === 3) { out.appendChild(document.createTextNode(n.nodeValue)); continue; }
      if (n.nodeType !== 1) continue;
      var tag = n.tagName;
      if (DROP[tag] || n.hidden || n.getAttribute('aria-hidden') === 'true') continue;
      var idc = (n.className && typeof n.className === 'string' ? n.className : '') + ' ' + (n.id || '');
      if (UNLIKELY.test(idc) && !MAYBE.test(idc)) continue;
      if (!KEEP[tag]) { clean(n, out, th); continue; }
      if ((tag === 'UL' || tag === 'OL' || tag === 'TABLE' || tag === 'FIGURE') && linkDensity(n) > .6 && txt(n).length < 600) continue;
      if (tag === 'IMG') {
        var u = pickImg(n);
        if (!u) continue;
        var w = parseInt(n.getAttribute('width') || '0', 10);
        if (w && w < 80) continue;
        var im = document.createElement('img');
        im.src = u; im.alt = n.getAttribute('alt') || '';
        st(im, 'display:block;max-width:100%;height:auto;margin:14px auto;border-radius:10px');
        out.appendChild(im);
        continue;
      }
      if (tag === 'BR' || tag === 'HR') { out.appendChild(document.createElement(tag.toLowerCase())); continue; }
      var e = document.createElement(tag.toLowerCase());
      if (tag === 'A') {
        var h = n.getAttribute('href');
        if (h && !/^javascript:/i.test(h)) { e.href = absUrl(h); e.rel = 'noopener noreferrer'; }
        st(e, 'color:' + th.link + ';text-decoration:underline');
      } else if (/^H[1-6]$/.test(tag)) {
        st(e, 'margin:1.4em 0 .5em;line-height:1.4;font-weight:700;font-size:' + ({ H1: 1.5, H2: 1.35, H3: 1.2, H4: 1.1, H5: 1.05, H6: 1 }[tag]) + 'em');
        e.setAttribute('dir', 'auto');
      } else if (tag === 'P' || tag === 'LI' || tag === 'BLOCKQUOTE' || tag === 'FIGCAPTION') {
        e.setAttribute('dir', 'auto');
        if (tag === 'P') st(e, 'margin:0 0 1em');
        if (tag === 'LI') st(e, 'margin:0 0 .5em');
        if (tag === 'BLOCKQUOTE') st(e, 'margin:1em 0;padding:.2em 1em;border-inline-start:4px solid ' + th.line + ';color:' + th.sub);
        if (tag === 'FIGCAPTION') st(e, 'font-size:.85em;color:' + th.sub + ';text-align:center;margin:-6px 0 14px');
      } else if (tag === 'UL' || tag === 'OL') {
        st(e, 'margin:0 0 1em;padding-inline-start:1.4em');
      } else if (tag === 'PRE' || tag === 'CODE') {
        st(e, 'direction:ltr;text-align:left;font-family:monospace;font-size:.88em;background:' + th.bar + ';border-radius:8px;' + (tag === 'PRE' ? 'padding:10px;overflow:auto;margin:0 0 1em' : 'padding:1px 5px'));
      } else if (tag === 'TABLE') {
        st(e, 'border-collapse:collapse;max-width:100%;display:block;overflow:auto;margin:0 0 1em');
      } else if (tag === 'TD' || tag === 'TH') {
        st(e, 'border:1px solid ' + th.line + ';padding:5px 8px');
      }
      clean(n, e, th);
      // drop empty shells (e.g. paragraphs that only held an ad)
      if (!e.firstChild && tag !== 'A') continue;
      if ((tag === 'P' || tag === 'LI') && !txt(e) && !e.querySelector('img')) continue;
      out.appendChild(e);
    }
  }

  function pageTitle() {
    var m = document.querySelector('meta[property="og:title"]');
    var t = (m && m.content) || '';
    if (!t) { var h = document.querySelector('article h1, main h1, h1'); t = h ? txt(h) : ''; }
    return (t || document.title || '').trim();
  }

  function isRtl(s) {
    var r = (s.match(/[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]/g) || []).length;
    var l = (s.match(/[A-Za-z]/g) || []).length;
    return r > l;
  }

  function note(msg, rtl) {
    var d = document.createElement('div');
    st(d, 'position:fixed;left:50%;bottom:28px;transform:translateX(-50%);max-width:86vw;z-index:2147483647;background:#222;color:#fff;padding:10px 16px;border-radius:14px;font:14px/1.6 sans-serif;box-shadow:0 4px 18px rgba(0,0,0,.4)');
    d.setAttribute('dir', rtl ? 'rtl' : 'ltr');
    d.textContent = msg;
    document.documentElement.appendChild(d);
    setTimeout(function () { d.remove(); }, 2800);
  }

  function toggleReader(dark, lang) {
    var old = document.getElementById('__abtin_reader');
    if (old) { old.remove(); document.documentElement.style.overflow = old.__prevOverflow || ''; return; }
    var fa = lang !== 'en';
    var art = null;
    try { art = findArticle(); } catch (e) { art = null; }
    if (!art || txt(art).length < 200) {
      note(fa ? 'محتوای قابل‌خواندن در این صفحه پیدا نشد' : 'No readable content found on this page', fa);
      return;
    }
    if (!RDR.theme) RDR.theme = dark ? 'dark' : 'light';
    build(art, fa);
  }

  function build(art, fa) {
    var title = pageTitle();
    var body = document.createElement('div');
    clean(art, body, THEMES[RDR.theme]);
    // the page title is shown separately: drop a duplicate leading heading
    var f = body.firstElementChild;
    if (f && /^H[1-3]$/.test(f.tagName) && txt(f) && title.indexOf(txt(f).slice(0, 25)) !== -1) f.remove();
    if (txt(body).length < 150) { note(fa ? 'محتوای قابل‌خواندن در این صفحه پیدا نشد' : 'No readable content found on this page', fa); return; }

    var rtl = isRtl(txt(body).slice(0, 500));
    var th = THEMES[RDR.theme];

    var root = document.createElement('div');
    root.id = '__abtin_reader';
    root.__prevOverflow = document.documentElement.style.overflow;
    document.documentElement.style.overflow = 'hidden';
    st(root, 'all:initial;position:fixed;top:0;left:0;right:0;bottom:0;z-index:2147483647;overflow:auto;overscroll-behavior:contain;-webkit-overflow-scrolling:touch;background:' + th.bg + ';color:' + th.fg + ';display:block');

    var bar = document.createElement('div');
    st(bar, 'position:sticky;top:0;z-index:2;display:flex;align-items:center;gap:6px;padding:6px 10px;background:' + th.bar + ';border-bottom:1px solid ' + th.line + ';direction:ltr;font:15px sans-serif');
    function btn(label, fn, wide) {
      var b = document.createElement('button');
      b.textContent = label;
      st(b, 'all:unset;box-sizing:border-box;min-width:' + (wide ? 46 : 38) + 'px;height:34px;padding:0 10px;text-align:center;line-height:34px;border-radius:17px;background:' + th.bg + ';color:' + th.fg + ';font:600 15px/34px sans-serif;border:1px solid ' + th.line);
      b.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); fn(); });
      return b;
    }
    function rebuild() { var p = root.parentNode; if (p) { p.removeChild(root); } document.documentElement.style.overflow = root.__prevOverflow || ''; build(art, fa); }
    var spacer = document.createElement('div'); st(spacer, 'flex:1');
    bar.appendChild(btn('✕', function () { root.remove(); document.documentElement.style.overflow = root.__prevOverflow || ''; }));
    bar.appendChild(spacer);
    bar.appendChild(btn('A−', function () { RDR.size = Math.max(14, RDR.size - 2); wrapSize(); }));
    bar.appendChild(btn('A+', function () { RDR.size = Math.min(34, RDR.size + 2); wrapSize(); }));
    bar.appendChild(btn(RDR.theme === 'light' ? '☀' : RDR.theme === 'sepia' ? '☕' : '☾', function () {
      RDR.theme = RDR.theme === 'light' ? 'sepia' : RDR.theme === 'sepia' ? 'dark' : 'light';
      rebuild();
    }, true));
    root.appendChild(bar);

    var wrap = document.createElement('div');
    function wrapSize() { st(wrap, 'box-sizing:border-box;max-width:720px;margin:0 auto;padding:18px 18px 80px;font-family:Vazirmatn,"Noto Naskh Arabic","Segoe UI",Roboto,sans-serif;font-size:' + RDR.size + 'px;line-height:1.95;word-wrap:break-word;overflow-wrap:anywhere'); }
    wrapSize();
    wrap.setAttribute('dir', rtl ? 'rtl' : 'ltr');

    var h1 = document.createElement('h1');
    h1.setAttribute('dir', 'auto');
    st(h1, 'margin:.6em 0 .2em;font-size:1.55em;line-height:1.5;font-weight:800');
    h1.textContent = title;
    var site = document.createElement('div');
    st(site, 'direction:ltr;font-size:.7em;color:' + th.sub + ';margin-bottom:1.2em');
    site.textContent = location.hostname;
    wrap.appendChild(h1); wrap.appendChild(site); wrap.appendChild(body);
    root.appendChild(wrap);
    document.documentElement.appendChild(root);
  }
})();

// Keyboard: after the soft keyboard opens (viewport shrinks) make sure the focused field is visible.
// Only act when the field is really outside the visible area. The old rule (scroll whenever the field sat in the lower
// half of the screen) also fired for chat composers pinned to the bottom (Telegram / Eitaa web): the page scroll made the
// site blur the field, so the keyboard closed right after opening.
(function () {
  var kt = null;
  function isEdit(e) { return e && (e.tagName === 'INPUT' || e.tagName === 'TEXTAREA' || e.isContentEditable); }
  // fixed / sticky bars (chat composers, bottom sheets) follow the viewport: scrolling the page cannot reveal them
  function pinned(e) {
    for (var n = e; n && n.nodeType === 1 && n !== document.documentElement; n = n.parentElement) {
      var p = '';
      try { p = getComputedStyle(n).position; } catch (x) {}
      if (p === 'fixed' || p === 'sticky') return true;
    }
    return false;
  }
  function reveal() {
    clearTimeout(kt);
    kt = setTimeout(function () {
      var e = document.activeElement;
      if (!isEdit(e)) return;
      try {
        var r = e.getBoundingClientRect();
        var vh = (window.visualViewport && window.visualViewport.height) || window.innerHeight;
        if (r.bottom <= vh + 1 && r.top >= 0) return; // already visible
        if (pinned(e)) return;
        e.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'auto' });
      } catch (x) {}
    }, 300);
  }
  document.addEventListener('focusin', reveal, true);
  if (window.visualViewport) window.visualViewport.addEventListener('resize', reveal);
})();
