import 'package:flutter/painting.dart';

/// Selectable themes. Colors are plain ARGB ints; the helpers below turn them into the colours the whole UI uses.
class AbtinPalette {
  const AbtinPalette(this.id, this.fa, this.en, this.dark, this.bg, this.blobs, this.accent);
  final String id, fa, en;
  final bool dark;
  final List<int> bg;    // 3-stop background gradient
  final List<int> blobs; // 3 soft glows painted over the gradient
  final int accent;
}

const palettes = <AbtinPalette>[
  // iOS Safari look (system grouped background, white / #1C1C1E bars, system blue).
  AbtinPalette('ios-light', 'iOS روشن', 'iOS Light', false,
      [0xFFF2F2F7, 0xFFF2F2F7, 0xFFF2F2F7], [0xFF007AFF, 0xFF5AC8FA, 0xFF34C759], 0xFF007AFF),
  AbtinPalette('ios-dark', 'iOS تیره', 'iOS Dark', true,
      [0xFF000000, 0xFF000000, 0xFF000000], [0xFF0A84FF, 0xFF64D2FF, 0xFF30D158], 0xFF0A84FF),
  // Browser chrome inspired by the supplied desktop reference: restrained navy surfaces and a cool, quiet light mode.
  AbtinPalette('browser-dark', 'مرورگر تیره', 'Browser Dark', true,
      [0xFF080F1D, 0xFF111C2D, 0xFF0A1423], [0xFF263D62, 0xFF1D3458, 0xFF172B48], 0xFF2878E8),
  AbtinPalette('browser-light', 'مرورگر روشن', 'Browser Light', false,
      [0xFFEAF0F8, 0xFFF4F6FA, 0xFFE8EEF7], [0xFFD6E2F2, 0xFFC8D8EE, 0xFFE0E8F4], 0xFF1769D2),
  AbtinPalette('ocean', 'اقیانوس', 'Ocean', true,
      [0xFF03102A, 0xFF0A2A5E, 0xFF06304F], [0xFF3B82F6, 0xFF06B6D4, 0xFF8B5CF6], 0xFF4C8DFF),
  AbtinPalette('forest', 'جنگل', 'Forest', true,
      [0xFF03211B, 0xFF0A3F31, 0xFF0A2C3C], [0xFF10B981, 0xFF34D399, 0xFF06B6D4], 0xFF34D399),
  AbtinPalette('sunset', 'غروب', 'Sunset', true,
      [0xFF2B0F20, 0xFF54173A, 0xFF3D1A0A], [0xFFFF7A45, 0xFFEC4899, 0xFFFBBF24], 0xFFFF8A5B),
  AbtinPalette('amoled', 'مشکی خالص', 'AMOLED Black', true,
      [0xFF000000, 0xFF000000, 0xFF050505], [0xFF2563EB, 0xFF7C3AED, 0xFF0891B2], 0xFF5B9DFF),
  AbtinPalette('ice', 'یخ', 'Ice', false,
      [0xFFEAF3FF, 0xFFD6E7FF, 0xFFE9F8FF], [0xFF60A5FA, 0xFF22D3EE, 0xFFA78BFA], 0xFF2563EB),
];

/// ONE source of truth for the colours of a palette, used by ThemeData, Glass cards, sheets and the background,
/// so every palette really changes every screen (in every interface style) instead of only the picker preview.
extension PaletteColors on AbtinPalette {
  Color get base => Color(bg[1]);
  bool get isIos => id.startsWith('ios-');

  /// Page / scaffold colour. Styles only change how strongly the palette tints it, never replace it.
  Color pageColor(String style) {
    final b = base;
    if (isIos) return b;
    if (style == 'samsung') return Color.lerp(b, dark ? const Color(0xFF111318) : const Color(0xFFF3F5F8), .45)!;
    if (style == 'uc') return Color.lerp(b, Color(accent), dark ? .10 : .08)!;
    return b;
  }

  /// Card / sheet surface.
  Color surfaceColor(String style, {bool strong = false}) {
    final b = base;
    if (isIos) return dark ? (strong ? const Color(0xFF2C2C2E) : const Color(0xFF1C1C1E)) : const Color(0xFFFFFFFF);
    if (style == 'neu') return dark ? Color.lerp(b, const Color(0xFFFFFFFF), .035)! : Color.lerp(b, const Color(0xFFFFFFFF), .35)!;
    if (style == 'samsung') {
      final n = dark ? const Color(0xFF20242B) : const Color(0xFFF7F8FA);
      return Color.lerp(b, n, .55)!;
    }
    if (style == 'uc') return Color.lerp(b, Color(accent), dark ? .14 : .10)!.withAlpha(255);
    if (dark) return Color.lerp(b, const Color(0xFFFFFFFF), strong ? .11 : .07)!;
    return Color.lerp(b, const Color(0xFFFFFFFF), strong ? .85 : .65)!;
  }

  /// Top bar colour of the 'uc' style (accent based); other styles use the page colour.
  Color appBarColor(String style) {
    if (isIos) return dark ? const Color(0xFF1C1C1E) : const Color(0xFFF7F7F7);
    if (style == 'uc') return Color.lerp(base, Color(accent), dark ? .45 : .90)!;
    if (style == 'samsung') return surfaceColor(style, strong: true);
    return pageColor(style);
  }
}
