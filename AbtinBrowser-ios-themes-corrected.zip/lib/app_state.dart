import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'engine/blocker.dart';
import 'models.dart';
import 'palettes.dart';

/// Page transition that shows the new page at once (used when UI animations are switched off).
class _NoTransitions extends PageTransitionsBuilder {
  const _NoTransitions();
  @override
  Widget buildTransitions<T>(PageRoute<T> route, BuildContext context, Animation<double> animation, Animation<double> secondaryAnimation, Widget child) => child;
}

String _lang = 'fa';
String tr(String fa, String en) => _lang == 'fa' ? fa : en;

class SearchEngine {
  const SearchEngine(this.name, this.url, this.suggest);
  final String name, url, suggest;
}

const engines = <String, SearchEngine>{
  'google': SearchEngine('Google', 'https://www.google.com/search?q=%s', 'https://suggestqueries.google.com/complete/search?client=firefox&q=%s'),
  'duckduckgo': SearchEngine('DuckDuckGo', 'https://duckduckgo.com/?q=%s', 'https://duckduckgo.com/ac/?type=list&q=%s'),
  'bing': SearchEngine('Bing', 'https://www.bing.com/search?q=%s', 'https://api.bing.com/osjson.aspx?query=%s'),
  'brave': SearchEngine('Brave', 'https://search.brave.com/search?q=%s', ''),
  'startpage': SearchEngine('Startpage', 'https://www.startpage.com/do/search?q=%s', ''),
  'ecosia': SearchEngine('Ecosia', 'https://www.ecosia.org/search?q=%s', ''),
  'yandex': SearchEngine('Yandex', 'https://yandex.com/search/?text=%s', ''),
};

const groupColors = [0xFF3977F6, 0xFF8B5CF6, 0xFF10B981, 0xFFF59E0B, 0xFFEF4444, 0xFF06B6D4, 0xFFEC4899];

class AppState extends ChangeNotifier {
  late SharedPreferences prefs;
  final Map<String, dynamic> _s = {};
  static const _def = <String, dynamic>{
    'theme': 'dark', 'palette': 'browser-dark', 'uiStyle': 'minimal', 'topBtn': 'bookmark', 'menuStyle': 'chrome', 'uiAnim': false, 'perf': false, 'accent': 0, 'lang': 'fa', 'engine': 'google', 'suggest': true, 'homepage': '',
    'track': 'standard', 'httpsOnly': true, 'adblock': true, 'popups': true, 'tpc': true, 'gpc': true,
    'fingerprint': false, 'webrtc': false, 'js': true, 'safeBrowsing': true, 'clearOnExit': false, 'restore': true,
    'desktop': false, 'doh': 'off', 'dlConns': '8', 'dlAsk': true, 'dlGrid': false, 'netMode': 'auto', 'passkeys': true, 'passkeysConfigured': false, 'mediaBtn': true, 'pullRefresh': true, 'scrollBtn': true, 'dnsBtn': true, 'textZoom': 100, 'sleeping': true, 'ua': '', 'chromeUa': true, 'chromeAll': false, 'chromeHosts': '', 'autoDiscard': true,
    'v2SortPing': false, 'dnsPreset': '', 'dohCustom': '', 'dnsCustoms': '', 'v2BypassIran': true, 'v2BypassIranIp': true, 'v2SkipIranApps': true, 'v2AppOver': '{}', 'v2BlockAds': false, 'v2BlockUdp': true, 'v2BypassLan': true, 'v2Ipv6': true, 'v2Mtu': '1500', 'v2Dns': '8.8.8.8,8.8.4.4', 'v2TestUrl': 'https://www.gstatic.com/generate_204',
    'smsOtp': true, 'savePw': true, 'bioLogin': true, 'siteCache': true, 'lite': false, 'googleClientId': '', 'extPrivate': false, 'downloadDir': '', 'screenshotDir': '', 'saveHistory': true, 'onboarded': false,
  };
  List<HistoryEntry> history = [];
  List<Bookmark> bookmarks = [];
  List<DownloadItem> downloads = [];
  List<SpeedDial> dials = [];
  /// host -> favicon (data: URI or http URL), remembered so the start page can show site icons.
  Map<String, String> favicons = {};
  String? faviconFor(String url) => favicons[hostOf(url)];
  void rememberFavicon(String url, String icon) {
    final h = hostOf(url);
    if (h.isEmpty || icon.isEmpty || (icon.startsWith('data:') && icon.length > 60000)) return;
    if (favicons[h] == icon) return;
    if (favicons.length > 200) favicons.remove(favicons.keys.first);
    favicons[h] = icon;
    prefs.setString('favicons_v1', jsonEncode(favicons));
  }
  List<TabGroup> groups = [];
  Map<String, dynamic> perms = {};
  late final String sessionToken;

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    final r = Random.secure();
    sessionToken = List.generate(16, (_) => r.nextInt(36).toRadixString(36)).join();
    try { _s.addAll(Map<String, dynamic>.from(jsonDecode(prefs.getString('settings_v2') ?? '{}') as Map)); } catch (_) {}
    // Older builds defaulted passkeys off. Enable Google Password Manager / Android
    // credential-provider support once for existing installs; preserve later user choices.
    if (_s['passkeysConfigured'] != true) {
      _s['passkeys'] = true;
      _s['passkeysConfigured'] = true;
      prefs.setString('settings_v2', jsonEncode(_s));
    }
    if (!_s.containsKey('palette')) {
      final old = _s['theme'];
      _s['palette'] = old == 'light' ? 'browser-light' : old == 'system' ? 'auto' : 'browser-dark';
    }
    // Migrate legacy glass style to an opaque preset; retain explicit modern styles.
    final savedStyle = (_s['uiStyle'] ?? 'minimal').toString();
    const supportedStyles = {'minimal', 'neu', 'uc', 'samsung'};
    _s['uiStyle'] = supportedStyles.contains(savedStyle) ? savedStyle : 'minimal';
    _s.remove('glassBlur'); _s.remove('glassAnim');
    _lang = str('lang');
    _tuneImageCache(flag('perf'));
    history = _load('history_v2', HistoryEntry.fromJson);
    bookmarks = _load('bookmarks_v2', Bookmark.fromJson);
    downloads = _load('downloads_v2', DownloadItem.fromJson);
    groups = _load('groups_v2', TabGroup.fromJson);
    try { favicons = Map<String, String>.from(jsonDecode(prefs.getString('favicons_v1') ?? '{}') as Map); } catch (_) { favicons = {}; }
    dials = _load('dials_v2', SpeedDial.fromJson);
    if (dials.isEmpty && prefs.getString('dials_v2') == null) {
      dials = [
        SpeedDial('Google', 'https://www.google.com'), SpeedDial('YouTube', 'https://m.youtube.com'),
        SpeedDial('Wikipedia', 'https://fa.wikipedia.org'), SpeedDial('Instagram', 'https://www.instagram.com'),
        SpeedDial('Telegram', 'https://web.telegram.org'), SpeedDial('Amazon', 'https://www.amazon.com'),
        SpeedDial('X', 'https://x.com'), SpeedDial('GitHub', 'https://github.com'),
      ];
    }
    try { perms = Map<String, dynamic>.from(jsonDecode(prefs.getString('perms_v2') ?? '{}') as Map); } catch (_) {}
  }

  List<T> _load<T>(String key, T Function(Map<String, dynamic>) f) {
    try {
      final raw = jsonDecode(prefs.getString(key) ?? '[]') as List;
      return raw.map((e) => f(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) { return []; }
  }

  T get<T>(String k) => (_s[k] ?? _def[k]) as T;
  bool flag(String k) => get<bool>(k);
  String str(String k) => get<String>(k);
  int num_(String k) => (get<num>(k)).toInt();
  String get lang => str('lang');
  void set(String k, dynamic v) {
    if (k == 'passkeys') _s['passkeysConfigured'] = true;
    if (k == 'uiStyle' && !{'minimal', 'neu', 'uc', 'samsung'}.contains(v)) v = 'minimal';
    _s[k] = v;
    if (k == 'lang') _lang = v as String;
    prefs.setString('settings_v2', jsonEncode(_s));
    notifyListeners();
  }

  /// Sites that get the Chrome identity without the user asking (same list as the native Engine.CHROME_SEED).
  static const chromeSeed = ['rb24.ir'];
  List<String> get chromeList => str('chromeHosts').split(RegExp(r'[\s,]+')).where((e) => e.isNotEmpty).toList();

  /// Whether pages of [host] are loaded with the Chrome identity (mirrors Engine.chromeFor).
  bool chromeOn(String host) {
    if (!flag('chromeUa') || host.isEmpty) return false;
    final h = host.toLowerCase();
    bool inList(Iterable<String> l) => l.any((x) => h == x || h.endsWith('.$x'));
    final l = chromeList;
    if (inList(l.where((e) => e.startsWith('!')).map((e) => e.substring(1)))) return false;
    return flag('chromeAll') || inList(l.where((e) => !e.startsWith('!'))) || inList(chromeSeed);
  }

  /// Remember (or forget) that [host] needs the Chrome identity; [off] = never for this site.
  void setChromeHost(String host, {required bool on}) {
    final l = chromeList..removeWhere((e) => e == host || e == '!$host');
    l.add(on ? host : '!$host');
    set('chromeHosts', l.join('\n'));
  }

  AbtinPalette get palette {
    var id = str('palette');
    if (id == 'auto') id = WidgetsBinding.instance.platformDispatcher.platformBrightness == Brightness.dark ? 'browser-dark' : 'browser-light';
    return palettes.firstWhere((p) => p.id == id, orElse: () => palettes.firstWhere((p) => p.id == 'browser-dark'));
  }

  /// 0 in settings = use the palette's own accent.
  int get accentInt { final a = num_('accent'); return a == 0 ? palette.accent : a; }
  bool get dark => palette.dark;
  bool get iosLook => palette.isIos;
  /// Effective interface style: the two iOS palettes always use the 'ios' style.
  String get styleId => palette.isIos ? 'ios' : str('uiStyle');
  bool get perf => flag('perf');
  String deviceTier = 'medium';
  /// Selects UI-side memory limits from Android's real RAM report. Existing site cache is untouched.
  void configureDeviceProfile(int totalMb) {
    deviceTier = totalMb <= 2600 ? 'weak' : totalMb <= 4800 ? 'medium' : 'strong';
    final c = PaintingBinding.instance.imageCache;
    c.maximumSizeBytes = deviceTier == 'weak' ? 24 << 20 : deviceTier == 'medium' ? 32 << 20 : 64 << 20;
    c.maximumSize = deviceTier == 'weak' ? 60 : deviceTier == 'medium' ? 160 : 320;
    if (deviceTier == 'weak') {
      _s['uiAnim'] = false;
      if (!flag('perf')) set('perf', true);
    }
  }

  /// Lite mode for weak phones: no blur, no animations, small image cache, lean engine caches.
  void setPerf(bool on) {
    if (deviceTier == 'weak') on = true;
    _s['uiAnim'] = !on;
    _tuneImageCache(on);
    set('perf', on);
  }

  void _tuneImageCache(bool on) {
    try {
      final c = PaintingBinding.instance.imageCache;
      c.maximumSizeBytes = on || deviceTier == 'weak' ? 24 << 20 : deviceTier == 'strong' ? 64 << 20 : 32 << 20;
      c.maximumSize = on || deviceTier == 'weak' ? 60 : deviceTier == 'strong' ? 320 : 160;
    } catch (_) {}
  }
  void setPalette(String id) { _s['accent'] = 0; set('palette', id); }

  /// Settings mirrored into the native engine (GeckoRuntime + built-in blocker extension).
  /// Local SOCKS port of the running v2ray tunnel (0 = no tunnel): the engine's proxy follows it.
  int proxyPort = 0;

  Map<String, dynamic> geckoSettings() => {
        'proxyPort': proxyPort,
        'lang': lang, 'dark': dark, 'accent': accentInt, 'theme': dark ? 'dark' : 'light',
        'js': flag('js'), 'gpc': flag('gpc'), 'fingerprint': flag('fingerprint'), 'track': str('track'),
        'httpsOnly': flag('httpsOnly'), 'tpc': flag('tpc'), 'safeBrowsing': flag('safeBrowsing'), 'webrtc': flag('webrtc'),
        'textZoom': num_('textZoom'), 'doh': str('doh'), 'dohCustom': str('dohCustom'), 'dlConns': str('dlConns'), 'dlAsk': flag('dlAsk'), 'netMode': str('netMode'), 'passkeys': flag('passkeys'), 'passkeysConfigured': flag('passkeysConfigured'), 'ua': str('ua'), 'chromeUa': flag('chromeUa'), 'chromeAll': flag('chromeAll'), 'chromeHosts': str('chromeHosts'), 'autoDiscard': flag('autoDiscard'), 'popups': flag('popups'), 'sleeping': flag('sleeping'), 'smsOtp': flag('smsOtp'), 'savePw': flag('savePw'), 'bioLogin': flag('bioLogin'), 'siteCache': flag('siteCache'), 'lite': flag('lite'), 'perf': flag('perf'),
        'userDownloadDir': str('downloadDir'),
        'core': {...Blocker.config(adblock: flag('adblock'), level: str('track')), 'mediaBtn': flag('mediaBtn'), 'pullRefresh': flag('pullRefresh'), 'scrollBtn': flag('scrollBtn'), 'lite': flag('lite'), 'lang': lang},
      };

  ThemeData themeData() {
    final p = palette;
    final d = p.dark;
    final accent = Color(accentInt);
    final b = d ? Brightness.dark : Brightness.light;
    final style = styleId;
    final ios = style == 'ios';
    final bg0 = p.pageColor(style);
    final solid = p.surfaceColor(style, strong: true);
    final dlg = solid;
    final glassFill = p.surfaceColor(style);
    final onP = ThemeData.estimateBrightnessForColor(accent) == Brightness.dark ? Colors.white : Colors.black;
    final cs = ColorScheme.fromSeed(seedColor: accent, brightness: b).copyWith(
      primary: accent, onPrimary: onP, surface: bg0, surfaceTint: Colors.transparent,
      surfaceContainerLow: glassFill, surfaceContainer: dlg, surfaceContainerHigh: dlg,
    );
    final anim = flag('uiAnim');
    return ThemeData(
      brightness: b, useMaterial3: true, colorScheme: cs,
      pageTransitionsTheme: anim ? null : const PageTransitionsTheme(builders: {
        TargetPlatform.android: _NoTransitions(), TargetPlatform.iOS: _NoTransitions(), TargetPlatform.fuchsia: _NoTransitions(),
        TargetPlatform.linux: _NoTransitions(), TargetPlatform.macOS: _NoTransitions(), TargetPlatform.windows: _NoTransitions(),
      }),
      splashFactory: anim ? null : NoSplash.splashFactory,
      scaffoldBackgroundColor: bg0, canvasColor: solid, cardColor: glassFill,
      dividerColor: ios ? (d ? const Color(0xFF38383A) : const Color(0xFFC6C6C8)) : (d ? Colors.white : Colors.black).withAlpha(26),
      switchTheme: ios ? SwitchThemeData(
        thumbColor: const WidgetStatePropertyAll(Colors.white),
        trackColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? const Color(0xFF34C759) : (d ? const Color(0xFF39393D) : const Color(0xFFE9E9EA))),
        trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
      ) : null,
      appBarTheme: AppBarTheme(backgroundColor: p.appBarColor(style), foregroundColor: style == 'uc' ? (ThemeData.estimateBrightnessForColor(p.appBarColor(style)) == Brightness.dark ? Colors.white : Colors.black) : null, surfaceTintColor: Colors.transparent, elevation: style == 'uc' ? 2 : 0, centerTitle: style != 'uc', scrolledUnderElevation: 0, titleTextStyle: ios ? TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: d ? Colors.white : Colors.black) : null),
      bottomSheetTheme: BottomSheetThemeData(backgroundColor: solid, modalBackgroundColor: solid, surfaceTintColor: Colors.transparent, shape: ios ? const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(14))) : null),
      snackBarTheme: SnackBarThemeData(backgroundColor: dlg, contentTextStyle: TextStyle(color: d ? Colors.white : Colors.black87), behavior: SnackBarBehavior.floating, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
    );
  }

  void _save(String key, List<dynamic> l) => prefs.setString(key, jsonEncode(l.map((e) => e.toJson()).toList()));
  Timer? _histT, _tabsT;
  String? _tabsPending;
  /// History / tabs are written a moment after the last change: encoding thousands of entries on every
  /// page load made browsing janky. [flush] writes anything pending right away (called when the app pauses).
  void saveHistory() {
    _histT?.cancel();
    _histT = Timer(const Duration(seconds: 2), () => _save('history_v2', history));
  }

  void flush() {
    if (_histT?.isActive ?? false) { _histT!.cancel(); _save('history_v2', history); }
    if ((_tabsT?.isActive ?? false) && _tabsPending != null) { _tabsT!.cancel(); prefs.setString('tabs_v2', _tabsPending!); }
  }
  void saveBookmarks() => _save('bookmarks_v2', bookmarks);
  void saveDownloads() => _save('downloads_v2', downloads.where((d) => !d.private).toList());
  void saveGroups() => _save('groups_v2', groups);
  void saveDials() => _save('dials_v2', dials);

  void addHistory(String url, String title) {
    if (!url.startsWith('http') || !flag('saveHistory')) return;
    final i = history.indexWhere((h) => h.url == url);
    if (i >= 0) {
      final h = history.removeAt(i);
      h.visits++; h.time = DateTime.now().millisecondsSinceEpoch;
      if (title.isNotEmpty) h.title = title;
      history.insert(0, h);
    } else {
      history.insert(0, HistoryEntry(url, title.isEmpty ? hostOf(url) : title));
      if (history.length > 3000) history.removeRange(3000, history.length);
    }
    saveHistory();
  }

  bool isBookmarked(String url) => bookmarks.any((b) => b.url == url);
  void toggleBookmark(String url, String title) {
    final i = bookmarks.indexWhere((b) => b.url == url);
    if (i >= 0) { bookmarks.removeAt(i); } else { bookmarks.insert(0, Bookmark(url, title.isEmpty ? hostOf(url) : title)); }
    saveBookmarks();
  }

  List<HistoryEntry> mostVisited(int n) {
    final byHost = <String, HistoryEntry>{};
    final score = <String, int>{};
    for (final h in history) {
      final host = hostOf(h.url);
      score[host] = (score[host] ?? 0) + h.visits;
      byHost.putIfAbsent(host, () => h);
    }
    final hosts = score.keys.toList()..sort((a, b) => score[b]!.compareTo(score[a]!));
    return hosts.take(n).map((h) => byHost[h]!).toList();
  }

  String sitePerm(String origin, String key) => ((perms[origin] as Map?)?[key] as String?) ?? 'ask';
  void setSitePerm(String origin, String key, String v) {
    final m = Map<String, dynamic>.from((perms[origin] as Map?) ?? {});
    if (v == 'ask') { m.remove(key); } else { m[key] = v; }
    if (m.isEmpty) { perms.remove(origin); } else { perms[origin] = m; }
    prefs.setString('perms_v2', jsonEncode(perms));
  }

  void saveTabs(List<BrowserTab> tabs, int cur) {
    final l = tabs.where((t) => !t.private && (t.url.isNotEmpty || t.lazyUrl != null))
        .map((t) => {'u': t.url.isNotEmpty ? t.url : t.lazyUrl, 't': t.title, 'g': t.groupId, 'p': t.pwa, if (t.state != null && t.state!.isNotEmpty) 's': t.state}).toList();
    _tabsPending = jsonEncode({'tabs': l, 'cur': cur});
    _tabsT?.cancel();
    _tabsT = Timer(const Duration(seconds: 2), () => prefs.setString('tabs_v2', _tabsPending!));
  }

  Map<String, dynamic>? loadTabs() {
    try { return Map<String, dynamic>.from(jsonDecode(prefs.getString('tabs_v2') ?? 'null') as Map); } catch (_) { return null; }
  }

  String exportJson() => jsonEncode({
        'settings': _s, 'bookmarks': bookmarks.map((e) => e.toJson()).toList(),
        'dials': dials.map((e) => e.toJson()).toList(), 'perms': perms,
      });

  void importJson(String s) {
    final j = Map<String, dynamic>.from(jsonDecode(s) as Map);
    if (j['settings'] is Map) { _s..clear()..addAll(Map<String, dynamic>.from(j['settings'] as Map)); _lang = str('lang'); prefs.setString('settings_v2', jsonEncode(_s)); }
    if (j['bookmarks'] is List) { bookmarks = (j['bookmarks'] as List).map((e) => Bookmark.fromJson(Map<String, dynamic>.from(e as Map))).toList(); saveBookmarks(); }
    if (j['dials'] is List) { dials = (j['dials'] as List).map((e) => SpeedDial.fromJson(Map<String, dynamic>.from(e as Map))).toList(); saveDials(); }
    if (j['perms'] is Map) { perms = Map<String, dynamic>.from(j['perms'] as Map); prefs.setString('perms_v2', jsonEncode(perms)); }
    notifyListeners();
  }
}
