import 'dart:async';
import 'package:flutter/material.dart';
import '../app_state.dart';
import '../palettes.dart';
import '../services.dart';

/// Alpha helper that works on every Flutter version (no withOpacity / .value).
Color alpha(Color c, double o) => c.withAlpha((o.clamp(0.0, 1.0) * 255).round());

/// Background colour of the current palette (kept for older call sites).
Color solidBackground(AbtinPalette p) => p.pageColor(app.styleId);

/// Opaque card colour; comes from the palette in every interface style.
Color solidSurface(AbtinPalette p, bool dark, bool strong, String style) => p.surfaceColor(style, strong: strong);

// ───────────────────────── frosted glass panel ─────────────────────────
class Glass extends StatelessWidget {
  const Glass({
    super.key, required this.child, this.radius = 22, this.padding, this.margin,
    this.strong = false, this.tint, this.borderColor, this.borderWidth = 1, this.blur,
  });
  final Widget child;
  final double radius, borderWidth;
  final EdgeInsetsGeometry? padding, margin;
  final bool strong;
  final Color? tint, borderColor;
  final double? blur; // null = user setting, 0 = no backdrop filter (use inside another glass)

  Widget _flat(BuildContext context, bool dark, String style) {
    final r = style == 'ios' ? radius.clamp(10.0, 14.0).toDouble() : radius.clamp(style == 'minimal' ? 8.0 : 12.0, style == 'uc' ? 22.0 : 26.0).toDouble();
    final br = BorderRadius.circular(r);
    final p = app.palette;
    var surface = solidSurface(p, dark, strong, style);
    if (tint != null) surface = Color.alphaBlend(alpha(tint!, dark ? .26 : .20), surface);
    final inner = Material(type: MaterialType.transparency, child: padding == null ? child : Padding(padding: padding!, child: child));
    final BoxDecoration dec;
    if (style == 'ios') {
      dec = BoxDecoration(color: surface, borderRadius: br, border: borderColor != null ? Border.all(color: borderColor!, width: borderWidth) : null);
    } else if (style == 'neu') {
      final hi = dark ? alpha(Colors.white, .07) : Colors.white;
      final lo = dark ? alpha(Colors.black, .60) : alpha(const Color(0xFF8A96A8), .42);
      dec = BoxDecoration(color: surface, borderRadius: br, boxShadow: [
        BoxShadow(color: lo, blurRadius: 9, offset: const Offset(3.5, 3.5)),
        BoxShadow(color: hi, blurRadius: 9, offset: const Offset(-3.5, -3.5)),
      ]);
    } else if (style == 'uc') {
      dec = BoxDecoration(color: surface, borderRadius: BorderRadius.circular(r), border: Border.all(color: Color(app.accentInt).withAlpha(70), width: 1.2), boxShadow: app.perf ? null : [BoxShadow(color: Colors.black.withAlpha(dark ? 55 : 18), blurRadius: 8, offset: const Offset(0, 3))]);
    } else if (style == 'samsung') {
      dec = BoxDecoration(color: surface, borderRadius: BorderRadius.circular(r), border: Border.all(color: dark ? const Color(0xFF343A44) : const Color(0xFFE6E9EF), width: 1));
    } else {
      dec = BoxDecoration(color: surface, borderRadius: BorderRadius.circular(r), border: Border.all(color: borderColor ?? alpha(dark ? Colors.white : Colors.black, style == 'minimal' ? .06 : .10), width: borderWidth));
    }
    Widget w = DecoratedBox(decoration: dec, child: ClipRRect(borderRadius: br, child: inner));
    if (margin != null) w = Padding(padding: margin!, child: w);
    return w;
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return _flat(context, dark, app.styleId);
  }
}

class GlassCard extends StatelessWidget {
  const GlassCard({super.key, required this.child, this.margin = const EdgeInsets.symmetric(vertical: 4)});
  final Widget child;
  final EdgeInsetsGeometry margin;
  @override
  Widget build(BuildContext context) => Glass(radius: 20, blur: 0, margin: margin, child: child);
}

/// A ListTile inside its own glass card (used by lists).
class GlassTile extends StatelessWidget {
  const GlassTile({super.key, this.leading, this.title, this.subtitle, this.trailing, this.onTap, this.onLongPress, this.dense = false});
  final Widget? leading, title, subtitle, trailing;
  final VoidCallback? onTap, onLongPress;
  final bool dense;
  @override
  Widget build(BuildContext context) => Glass(
        radius: 18, blur: 0, margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: ListTile(dense: dense, leading: leading, title: title, subtitle: subtitle, trailing: trailing, onTap: onTap, onLongPress: onLongPress),
      );
}

// ───────────────────────── colorful icon chip ─────────────────────────
class IconChip extends StatelessWidget {
  const IconChip(this.icon, this.color, {super.key, this.size = 44});
  final IconData icon;
  final Color color;
  final double size;
  @override
  Widget build(BuildContext context) => Container(
        width: size, height: size,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(size * .32),
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color.lerp(color, Colors.white, .30)!, color]),
          boxShadow: app.perf ? null : [BoxShadow(color: alpha(color, .45), blurRadius: size * .38, offset: Offset(0, size * .1))],
        ),
        child: Icon(icon, color: Colors.white, size: size * .5),
      );
}

// ───────────────────────── animated / static background ─────────────────────────
/// Flat page background in the palette's colour (no gradients, glows or blur: the glass look is gone).
class GlassBackground extends StatefulWidget {
  const GlassBackground({super.key, required this.child});
  final Widget child;
  @override
  State<GlassBackground> createState() => _GlassBackgroundState();
}

class _GlassBackgroundState extends State<GlassBackground> {
  void _onApp() { if (mounted) setState(() {}); }

  @override
  void initState() { super.initState(); app.addListener(_onApp); }
  @override
  void dispose() { app.removeListener(_onApp); super.dispose(); }

  @override
  Widget build(BuildContext context) => ColoredBox(color: app.palette.pageColor(app.styleId), child: widget.child);
}

/// Drop-in Scaffold replacement: paints the glass background behind the page (opaque, so
/// page transitions never show the previous page through it).
class GlassScaffold extends StatelessWidget {
  const GlassScaffold({super.key, this.appBar, this.body, this.bottomNavigationBar, this.resizeToAvoidBottomInset = true});
  final PreferredSizeWidget? appBar;
  final Widget? body, bottomNavigationBar;
  final bool resizeToAvoidBottomInset;
  @override
  Widget build(BuildContext context) => GlassBackground(
        child: Scaffold(backgroundColor: Colors.transparent, resizeToAvoidBottomInset: resizeToAvoidBottomInset, appBar: appBar, body: body, bottomNavigationBar: bottomNavigationBar),
      );
}

/// Makes room for the soft keyboard in ONE step instead of once per animation frame.
/// The keyboard animates for ~250 ms and Flutter reports ~15 intermediate heights; resizing the web view for each of them
/// fires a storm of `resize` events in the page. Sites such as Telegram / Eitaa web react to that by blurring or re-focusing
/// the field (the keyboard flips between layouts and closes). Here the new height is applied once it has stopped changing.
/// [immediate] (a Flutter text field such as the find bar owns the keyboard) follows the keyboard live.
class SettledKeyboardInset extends StatefulWidget {
  const SettledKeyboardInset({super.key, required this.child, this.immediate = false, this.settle = const Duration(milliseconds: 110)});
  final Widget child;
  final bool immediate;
  final Duration settle;
  @override
  State<SettledKeyboardInset> createState() => _SettledKeyboardInsetState();
}

class _SettledKeyboardInsetState extends State<SettledKeyboardInset> {
  double _raw = 0, _applied = 0;
  Timer? _t;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final raw = MediaQuery.viewInsetsOf(context).bottom;
    if (raw == _raw) return;
    _raw = raw;
    _t?.cancel();
    if (widget.immediate) {
      _applied = raw;
      return;
    }
    _t = Timer(widget.settle, () {
      if (mounted && _applied != _raw) setState(() => _applied = _raw);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Padding(padding: EdgeInsets.only(bottom: _applied), child: widget.child);
}

// ───────────────────────── sheets & dialogs ─────────────────────────
Future<T?> showGlassSheet<T>({required BuildContext context, required WidgetBuilder builder, bool isScrollControlled = false, bool useSafeArea = false}) {
  return showModalBottomSheet<T>(
    context: context, isScrollControlled: isScrollControlled, useSafeArea: useSafeArea,
    backgroundColor: solidSurface(app.palette, app.dark, true, 'solid'), elevation: 0, barrierColor: Colors.black54,
    sheetAnimationStyle: app.flag('uiAnim') ? null : AnimationStyle.noAnimation,
    builder: (ctx) => Padding(
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
      child: Glass(radius: 30, strong: true, child: builder(ctx)),
    ),
  );
}

Future<T?> showGlassDialog<T>({required BuildContext context, required WidgetBuilder builder, bool barrierDismissible = true}) {
  return showGeneralDialog<T>(
    context: context, barrierDismissible: barrierDismissible, barrierLabel: 'dialog', barrierColor: Colors.black38,
    transitionDuration: app.flag('uiAnim') ? const Duration(milliseconds: 220) : Duration.zero,
    pageBuilder: (ctx, _, __) => SafeArea(child: Center(child: Builder(builder: builder))),
    transitionBuilder: (ctx, anim, _, child) {
      final c = CurvedAnimation(parent: anim, curve: Curves.easeOutCubic);
      return FadeTransition(opacity: c, child: ScaleTransition(scale: Tween<double>(begin: .92, end: 1).animate(c), child: child));
    },
  );
}

// ───────────────────────── theme picker ─────────────────────────
class PalettePicker extends StatelessWidget {
  const PalettePicker({super.key});

  Widget _line(Color color, double width, {double height = 3}) => Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(height),
        ),
      );

  Widget _item(BuildContext context, String id, String name, AbtinPalette p, bool selected) {
    final style = p.isIos ? 'ios' : 'minimal';
    final dark = p.dark;
    final accent = Color(p.accent);
    final ink = dark ? const Color(0xFFF5F6FA) : const Color(0xFF182235);
    final subInk = dark ? const Color(0xFFB5BFCE) : const Color(0xFF566174);
    final page = p.pageColor(style);
    final surface = p.surfaceColor(style, strong: true);
    final tabBar = p.appBarColor(style);
    final border = selected ? accent : alpha(ink, .18);

    return GestureDetector(
      onTap: () => app.setPalette(id),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 212,
        height: 142,
        margin: const EdgeInsets.symmetric(horizontal: 4),
        decoration: BoxDecoration(
          color: surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: border, width: selected ? 2 : 1),
          boxShadow: selected
              ? [BoxShadow(color: alpha(accent, .22), blurRadius: 7)]
              : null,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(10),
          child: Stack(
            children: [
              Column(
                children: [
                  // Browser tab strip. The palette's name is part of the selected tab,
                  // not a separate caption underneath the theme preview.
                  Container(
                    height: 22,
                    color: dark ? const Color(0xFF111722) : const Color(0xFFE8EDF5),
                    padding: const EdgeInsets.fromLTRB(7, 3, 5, 2),
                    child: Row(
                      children: [
                        for (final c in const [0xFFF05D58, 0xFFF6C344, 0xFF42B66A])
                          Container(
                            width: 5,
                            height: 5,
                            margin: const EdgeInsets.only(right: 3),
                            decoration: BoxDecoration(color: Color(c), shape: BoxShape.circle),
                          ),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6),
                            decoration: BoxDecoration(
                              color: surface,
                              borderRadius: const BorderRadius.vertical(top: Radius.circular(5)),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.public, size: 8, color: accent),
                                const SizedBox(width: 4),
                                Expanded(
                                  child: Text(
                                    name,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(color: ink, fontSize: 9, fontWeight: FontWeight.w600),
                                  ),
                                ),
                                Icon(Icons.close, size: 8, color: subInk),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 4),
                        Icon(Icons.add, size: 10, color: subInk),
                      ],
                    ),
                  ),
                  // Address and navigation bar.
                  Container(
                    height: 23,
                    color: surface,
                    padding: const EdgeInsets.symmetric(horizontal: 6),
                    child: Row(
                      children: [
                        Icon(Icons.arrow_back, size: 11, color: ink),
                        const SizedBox(width: 6),
                        Icon(Icons.arrow_forward, size: 11, color: subInk),
                        const SizedBox(width: 5),
                        Icon(Icons.refresh, size: 11, color: ink),
                        const SizedBox(width: 5),
                        Expanded(
                          child: Container(
                            height: 14,
                            padding: const EdgeInsets.symmetric(horizontal: 5),
                            decoration: BoxDecoration(
                              color: alpha(ink, .07),
                              borderRadius: BorderRadius.circular(7),
                            ),
                            child: Row(
                              children: [
                                Icon(Icons.lock, size: 7, color: subInk),
                                const SizedBox(width: 4),
                                Expanded(child: _line(subInk, 43, height: 2)),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 5),
                        Icon(Icons.star_border, size: 11, color: ink),
                        const SizedBox(width: 4),
                        Icon(Icons.download_outlined, size: 11, color: ink),
                        const SizedBox(width: 3),
                        Icon(Icons.account_circle, size: 12, color: accent),
                      ],
                    ),
                  ),
                  Expanded(
                    child: Container(
                      color: page,
                      width: double.infinity,
                      child: Stack(
                        children: [
                          // Familiar web-page content remains visible beside the menu.
                          Positioned(
                            left: 7,
                            right: 98,
                            top: 7,
                            bottom: 4,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: Container(
                                    width: double.infinity,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(5),
                                      gradient: LinearGradient(
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                        colors: [
                                          dark ? const Color(0xFF070C16) : const Color(0xFFE2E8F3),
                                          dark ? const Color(0xFF14223B) : const Color(0xFFF7F9FC),
                                        ],
                                      ),
                                    ),
                                    child: Center(
                                      child: Icon(Icons.laptop_mac, size: 29, color: accent),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text('MacBook Air', maxLines: 1, style: TextStyle(color: ink, fontSize: 8, fontWeight: FontWeight.w700)),
                                Text('Supercharged by M3.', maxLines: 1, style: TextStyle(color: subInk, fontSize: 5.5)),
                                const SizedBox(height: 3),
                                Container(
                                  width: 35,
                                  height: 11,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(7)),
                                  child: const Text('Learn more', style: TextStyle(color: Colors.white, fontSize: 5)),
                                ),
                              ],
                            ),
                          ),
                          // Compact Firefox-style menu, proportioned like the supplied browser reference.
                          Positioned(
                            top: 3,
                            right: 3,
                            bottom: 3,
                            width: 88,
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                color: surface,
                                borderRadius: BorderRadius.circular(7),
                                border: Border.all(color: alpha(ink, .13)),
                                boxShadow: [
                                  BoxShadow(color: alpha(Colors.black, dark ? .32 : .16), blurRadius: 4, offset: const Offset(0, 1)),
                                ],
                              ),
                              child: Padding(
                                padding: const EdgeInsets.fromLTRB(5, 4, 5, 3),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Icon(Icons.refresh, size: 9, color: ink),
                                        Icon(Icons.share, size: 9, color: ink),
                                        Icon(Icons.arrow_back, size: 9, color: accent),
                                        Icon(Icons.arrow_forward, size: 9, color: accent),
                                      ],
                                    ),
                                    Divider(height: 6, thickness: .5, color: alpha(ink, .13)),
                                    for (final item in <(IconData, String)>[
                                      (Icons.desktop_windows_outlined, 'وبگاه رومیزی'),
                                      (Icons.star_border, 'نشانک‌گذاری صفحه'),
                                      (Icons.search, 'پیدا کردن در صفحه'),
                                      (Icons.extension_outlined, 'افزونه‌ها'),
                                    ]) ...[
                                      Row(
                                        children: [
                                          Icon(item.$1, size: 8, color: accent),
                                          const SizedBox(width: 4),
                                          Expanded(
                                            child: Text(
                                              item.$2,
                                              maxLines: 1,
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(color: ink, fontSize: 5.5),
                                            ),
                                          ),
                                        ],
                                      ),
                                      Divider(height: 5, thickness: .4, color: alpha(ink, .10)),
                                    ],
                                    const Spacer(),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                                      children: [
                                        Icon(Icons.tab, size: 8, color: accent),
                                        Icon(Icons.download, size: 8, color: accent),
                                        Icon(Icons.star, size: 8, color: accent),
                                        Icon(Icons.history, size: 8, color: accent),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    height: 13,
                    color: tabBar,
                    padding: const EdgeInsets.symmetric(horizontal: 7),
                    child: Row(
                      children: [
                        Container(width: 9, height: 7, decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(2))),
                        const SizedBox(width: 4),
                        _line(subInk, 39, height: 2),
                        const Spacer(),
                        Icon(Icons.keyboard_arrow_down, size: 10, color: subInk),
                      ],
                    ),
                  ),
                ],
              ),
              if (selected)
                Positioned(
                  top: 3,
                  right: 4,
                  child: Container(
                    width: 15,
                    height: 15,
                    decoration: BoxDecoration(color: accent, shape: BoxShape.circle),
                    child: const Icon(Icons.check, color: Colors.white, size: 10),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cur = app.str('palette');
    final browserDark = palettes.firstWhere((p) => p.id == 'browser-dark');
    final browserLight = palettes.firstWhere((p) => p.id == 'browser-light');
    final auto = AbtinPalette('auto', 'خودکار', 'Auto', true, [...browserDark.bg], [...browserLight.blobs], browserDark.accent);
    return SizedBox(
      height: 164,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        children: [
          _item(context, 'auto', tr('خودکار', 'Auto'), auto, cur == 'auto'),
          for (final p in palettes) _item(context, p.id, tr(p.fa, p.en), p, cur == p.id),
        ],
      ),
    );
  }
}

/// Height of the top bar (tabs + address bar) of the browser page, set by it: message bars start BELOW it instead of covering the address bar.
double snackTopInset = 0;

/// Message bar (toast) at the TOP of the screen instead of the bottom (just under the browser's address bar).
void snackTop(BuildContext context, String msg) {
  final mq = MediaQuery.of(context);
  final m = ScaffoldMessenger.of(context);
  final bottom = (mq.size.height - mq.viewInsets.bottom - mq.padding.top - snackTopInset - 84).clamp(0.0, double.infinity);
  m.hideCurrentSnackBar();
  m.showSnackBar(SnackBar(
    content: Text(msg),
    behavior: SnackBarBehavior.floating,
    dismissDirection: DismissDirection.up,
    margin: EdgeInsets.fromLTRB(12, 0, 12, bottom),
  ));
}
