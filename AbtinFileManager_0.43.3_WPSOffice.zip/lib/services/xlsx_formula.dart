import 'dart:math' as math;

/// Local Excel-compatible formula evaluator for the common functions used in everyday
/// spreadsheets. It deliberately returns Excel error values instead of throwing into the UI.
class XlsxFormulaEngine {
  static dynamic evaluate(
    String source, {
    required dynamic Function(String ref) cell,
    required List<dynamic> Function(String from, String to) range,
  }) {
    try {
      final parser = _FormulaParser(source, cell, range);
      final value = parser.parse();
      if (!parser.done) return '#VALUE!';
      return value;
    } on _FormulaError catch (e) {
      return e.value;
    } catch (_) {
      return '#VALUE!';
    }
  }
}

class _FormulaError implements Exception {
  final String value;
  const _FormulaError(this.value);
}

class _FormulaParser {
  final String source;
  final dynamic Function(String) cell;
  final List<dynamic> Function(String, String) range;
  final List<String> tokens = [];
  int at = 0;

  _FormulaParser(this.source, this.cell, this.range) {
    _tokenize(source.startsWith('=') ? source.substring(1) : source);
  }

  bool get done => at >= tokens.length;
  String get token => done ? '' : tokens[at];
  bool take(String value) {
    if (token.toUpperCase() != value.toUpperCase()) return false;
    at++;
    return true;
  }

  void _tokenize(String s) {
    var i = 0;
    while (i < s.length) {
      if (s[i].trim().isEmpty) { i++; continue; }
      final rest = s.substring(i);
      final number = RegExp(r'^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?').firstMatch(rest);
      if (number != null) { tokens.add(number[0]!); i += number[0]!.length; continue; }
      if (s[i] == '"') {
        var j = i + 1;
        final b = StringBuffer();
        while (j < s.length) {
          if (s[j] == '"' && j + 1 < s.length && s[j + 1] == '"') { b.write('"'); j += 2; continue; }
          if (s[j] == '"') break;
          b.write(s[j++]);
        }
        if (j >= s.length) throw const _FormulaError('#VALUE!');
        tokens.add('\u0001${b.toString()}');
        i = j + 1;
        continue;
      }
      final id = RegExp(r'^\$?[A-Za-z_][A-Za-z0-9_.$]*').firstMatch(rest);
      if (id != null) { tokens.add(id[0]!); i += id[0]!.length; continue; }
      var op = '';
      for (final candidate in ['<=', '>=', '<>']) {
        if (rest.startsWith(candidate)) { op = candidate; break; }
      }
      if (op.isNotEmpty) { tokens.add(op); i += op.length; continue; }
      if ('+-*/^&%=(),:<>'.contains(s[i])) { tokens.add(s[i]); i++; continue; }
      throw const _FormulaError('#VALUE!');
    }
  }

  dynamic parse() {
    if (tokens.isEmpty) return 0;
    return _comparison();
  }

  dynamic _comparison() {
    var v = _concat();
    while (['=', '<>', '<', '>', '<=', '>='].contains(token)) {
      final op = tokens[at++];
      final b = _concat();
      final cmp = _compare(v, b);
      v = switch (op) {
        '=' => cmp == 0,
        '<>' => cmp != 0,
        '<' => cmp < 0,
        '>' => cmp > 0,
        '<=' => cmp <= 0,
        '>=' => cmp >= 0,
        _ => false,
      };
    }
    return v;
  }

  dynamic _concat() {
    var v = _add();
    while (take('&')) { v = _string(v) + _string(_add()); }
    return v;
  }

  dynamic _add() {
    var v = _multiply();
    while (token == '+' || token == '-') {
      final op = tokens[at++];
      final b = _multiply();
      v = op == '+' ? _num(v) + _num(b) : _num(v) - _num(b);
    }
    return v;
  }

  dynamic _multiply() {
    var v = _power();
    while (token == '*' || token == '/') {
      final op = tokens[at++];
      final b = _power();
      if (op == '/') {
        if (_num(b) == 0) throw const _FormulaError('#DIV/0!');
        v = _num(v) / _num(b);
      } else {
        v = _num(v) * _num(b);
      }
    }
    return v;
  }

  dynamic _power() {
    var v = _unary();
    if (take('^')) {
      final b = _power();
      v = math.pow(_num(v), _num(b)).toDouble();
    }
    while (take('%')) v = _num(v) / 100;
    return v;
  }

  dynamic _unary() {
    if (take('+')) return _num(_unary());
    if (take('-')) return -_num(_unary());
    return _primary();
  }

  dynamic _primary() {
    if (take('(')) {
      final v = _comparison();
      if (!take(')')) throw const _FormulaError('#VALUE!');
      return v;
    }
    if (done) throw const _FormulaError('#VALUE!');
    final t = tokens[at++];
    if (t.startsWith('\u0001')) return t.substring(1);
    final n = double.tryParse(t);
    if (n != null) return n;
    if (take('(')) {
      final args = <dynamic>[];
      if (!take(')')) {
        do { args.add(_comparison()); } while (take(','));
        if (!take(')')) throw const _FormulaError('#VALUE!');
      }
      return _function(t.toUpperCase(), args);
    }
    if (take(':')) {
      if (done) throw const _FormulaError('#REF!');
      final end = tokens[at++];
      if (!_isCell(t) || !_isCell(end)) throw const _FormulaError('#REF!');
      return _RangeValue(range(t.toUpperCase(), end.toUpperCase()));
    }
    switch (t.toUpperCase()) {
      case 'TRUE': return true;
      case 'FALSE': return false;
      case 'PI': return 3.141592653589793;
    }
    if (_isCell(t)) {
      final v = cell(t.replaceAll(r'$', '').toUpperCase());
      if (v is String && v.startsWith('#')) throw _FormulaError(v);
      return v;
    }
    throw const _FormulaError('#NAME?');
  }

  dynamic _function(String name, List<dynamic> args) {
    final flat = args.expand((v) => v is _RangeValue ? v.values : [v]).toList();
    final err = flat.whereType<String>().where((v) => v.startsWith('#')).firstOrNull;
    if (err != null) throw _FormulaError(err);
    final nums = flat.where((v) => v is num || (v is String && double.tryParse(v) != null)).map(_num).toList();
    double sum() => nums.fold<double>(0, (a, b) => a + b);
    switch (name) {
      case 'SUM': return sum();
      case 'AVERAGE':
        if (nums.isEmpty) throw const _FormulaError('#DIV/0!');
        return sum() / nums.length;
      case 'COUNT': return nums.length;
      case 'COUNTA': return flat.where((v) => v != null && v.toString().isNotEmpty).length;
      case 'MAX': return nums.isEmpty ? 0 : nums.reduce((a, b) => a > b ? a : b);
      case 'MIN': return nums.isEmpty ? 0 : nums.reduce((a, b) => a < b ? a : b);
      case 'PRODUCT': return nums.fold<double>(1, (a, b) => a * b);
      case 'ROUND':
        final places = args.length > 1 ? _num(args[1]).toInt() : 0;
        final factor = _pow10(places);
        return (_num(args[0]) * factor).roundToDouble() / factor;
      case 'IF':
        if (args.length < 2) throw const _FormulaError('#VALUE!');
        return _truth(args[0]) ? args[1] : (args.length > 2 ? args[2] : false);
      case 'CONCAT':
      case 'CONCATENATE': return flat.map(_string).join();
      case 'ABS': return _num(args[0]).abs();
      case 'SQRT':
        if (_num(args[0]) < 0) throw const _FormulaError('#NUM!');
        return math.sqrt(_num(args[0]));
      case 'POWER': return math.pow(_num(args[0]), _num(args[1])).toDouble();
      case 'MOD':
        if (_num(args[1]) == 0) throw const _FormulaError('#DIV/0!');
        return _num(args[0]) % _num(args[1]);
      case 'AND': return args.every(_truth);
      case 'OR': return args.any(_truth);
      case 'NOT': return !_truth(args[0]);
      case 'LEN': return _string(args[0]).length;
      case 'LEFT':
        final s = _string(args[0]); final n = args.length > 1 ? _num(args[1]).toInt() : 1;
        return s.substring(0, n.clamp(0, s.length).toInt());
      case 'RIGHT':
        final s = _string(args[0]); final n = args.length > 1 ? _num(args[1]).toInt() : 1;
        return s.substring(s.length - n.clamp(0, s.length).toInt());
      case 'MID':
        final s = _string(args[0]); final start = _num(args[1]).toInt() - 1; final len = _num(args[2]).toInt();
        if (start < 0) throw const _FormulaError('#VALUE!');
        return s.substring(start.clamp(0, s.length).toInt(), (start + len).clamp(0, s.length).toInt());
      case 'UPPER': return _string(args[0]).toUpperCase();
      case 'LOWER': return _string(args[0]).toLowerCase();
      case 'TRIM': return _string(args[0]).trim().replaceAll(RegExp(r'\s+'), ' ');
      case 'COUNTIF':
        if (args.length < 2 || args[0] is! _RangeValue) throw const _FormulaError('#VALUE!');
        return (args[0] as _RangeValue).values.where((v) => _criteria(v, args[1])).length;
      case 'SUMIF':
        if (args.length < 2 || args[0] is! _RangeValue) throw const _FormulaError('#VALUE!');
        final vals = (args.length > 2 && args[2] is _RangeValue) ? (args[2] as _RangeValue).values : (args[0] as _RangeValue).values;
        final rangeVals = (args[0] as _RangeValue).values;
        var total = 0.0;
        for (var i = 0; i < rangeVals.length && i < vals.length; i++) {
          if (_criteria(rangeVals[i], args[1])) total += _num(vals[i]);
        }
        return total;
      default: throw const _FormulaError('#NAME?');
    }
  }

  static bool _criteria(dynamic v, dynamic criteria) {
    final s = _string(criteria);
    final m = RegExp(r'^(>=|<=|<>|>|<|=)(.*)$').firstMatch(s);
    if (m == null) return _compare(v, criteria) == 0;
    final c = m.group(2)!;
    final rhs = double.tryParse(c) ?? c;
    final cmp = _compare(v, rhs);
    return switch (m.group(1)) {
      '>' => cmp > 0, '<' => cmp < 0, '>=' => cmp >= 0, '<=' => cmp <= 0,
      '<>' => cmp != 0, _ => cmp == 0,
    };
  }

  static bool _isCell(String s) => RegExp(r'^\$?[A-Za-z]{1,3}\$?[1-9]\d{0,6}$').hasMatch(s);
  static double _num(dynamic v) {
    if (v is num) return v.toDouble();
    if (v is bool) return v ? 1 : 0;
    if (v == null || v == '') return 0;
    final n = double.tryParse(v.toString());
    if (n == null) throw const _FormulaError('#VALUE!');
    return n;
  }
  static String _string(dynamic v) => v == null ? '' : (v is double && v == v.truncateToDouble() ? v.toInt().toString() : '$v');
  static bool _truth(dynamic v) => v is bool ? v : (v is num ? v != 0 : (v != null && v.toString().isNotEmpty && v.toString().toUpperCase() != 'FALSE'));
  static int _compare(dynamic a, dynamic b) {
    final an = double.tryParse('$a'), bn = double.tryParse('$b');
    if (an != null && bn != null) return an.compareTo(bn);
    return _string(a).toLowerCase().compareTo(_string(b).toLowerCase());
  }
  static double _pow10(int n) => n >= 0 ? _ipow(10, n) : 1 / _ipow(10, -n);
  static double _ipow(double x, int n) {
    var v = 1.0;
    for (var i = 0; i < n.clamp(0, 12); i++) v *= x;
    return v;
  }
}

class _RangeValue {
  final List<dynamic> values;
  const _RangeValue(this.values);
}

