import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import '../core/layouts.dart' show tr2;
import '../core/office_prefs.dart';
import '../widgets/office_chrome.dart';
import 'office_new.dart';
import 'opener.dart';

/// WPS-style Office start centre: create, open, search and resume documents.
class OfficeHubScreen extends StatefulWidget {
  final String directory;
  const OfficeHubScreen({super.key, required this.directory});

  @override
  State<OfficeHubScreen> createState() => _OfficeHubScreenState();
}

class _OfficeHubScreenState extends State<OfficeHubScreen> {
  final _search = TextEditingController();
  List<FileSystemEntity> _recent = [];
  bool _loading = true;

  static const _officeExts = {
    'docx', 'doc', 'dotx', 'xlsx', 'xlsm', 'xls', 'pptx', 'ppsx', 'pptm',
    'ppt', 'pdf', 'odt', 'ods', 'odp', 'rtf'
  };

  @override
  void initState() {
    super.initState();
    _refresh();
    _search.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _refresh() async {
    final found = <FileSystemEntity>[];
    try {
      final dir = Directory(widget.directory);
      if (await dir.exists()) {
        for (final e in dir.listSync(followLinks: false)) {
          if (e is! File) continue;
          final ext = p.extension(e.path).replaceFirst('.', '').toLowerCase();
          if (_officeExts.contains(ext)) found.add(e);
        }
      }
      found.sort((a, b) {
        final am = a.statSync().modified, bm = b.statSync().modified;
        return bm.compareTo(am);
      });
    } catch (_) {}
    if (mounted) setState(() {
      _recent = found.take(30).toList();
      _loading = false;
    });
  }

  List<FileSystemEntity> get _filtered {
    final q = _search.text.trim().toLowerCase();
    if (q.isEmpty) return _recent;
    return _recent.where((e) => p.basename(e.path).toLowerCase().contains(q)).toList();
  }

  Future<void> _create(OfficeKind kind) async {
    await officeNewFile(context, widget.directory, kind);
    await _refresh();
  }

  Future<void> _openPicker() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: _officeExts.toList(),
    );
    final path = result?.files.single.path;
    if (path == null || !mounted) return;
    await Opener.open(context, path);
    await _refresh();
  }

  Future<void> _openPdfPicker() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: const ['pdf'],
    );
    final path = result?.files.single.path;
    if (path == null || !mounted) return;
    await Opener.open(context, path);
    await _refresh();
  }

  Future<void> _open(String path) async {
    await Opener.open(context, path);
    await _refresh();
  }

  Widget _documentTile(OfficeKind kind, String subtitle, VoidCallback onTap) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: OfficePrefs.paper,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: OfficePrefs.line.withOpacity(.8)),
          boxShadow: const [BoxShadow(color: Color(0x10000000), blurRadius: 12, offset: Offset(0, 4))],
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(color: kind.color, borderRadius: BorderRadius.circular(13)),
            alignment: Alignment.center,
            child: Text(
              kind == OfficeKind.docx ? 'W' : kind == OfficeKind.xlsx ? 'X' : 'P',
              style: const TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w800),
            ),
          ),
          const Spacer(),
          Text(kind == OfficeKind.docx ? 'Word' : kind == OfficeKind.xlsx ? 'Excel' : 'PowerPoint',
              style: TextStyle(color: OfficePrefs.ink, fontSize: 15, fontWeight: FontWeight.w800)),
          const SizedBox(height: 3),
          Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: TextStyle(color: OfficePrefs.ink.withOpacity(.62), fontSize: 11)),
        ]),
      ),
    );
  }

  Widget _quickAction(IconData icon, String title, String subtitle, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(15),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
        decoration: BoxDecoration(
          color: OfficePrefs.strip,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: OfficePrefs.line.withOpacity(.8)),
        ),
        child: Row(children: [
          Icon(icon, color: kOfficeBlue, size: 25),
          const SizedBox(width: 11),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: TextStyle(fontWeight: FontWeight.w700, color: OfficePrefs.ink)),
            const SizedBox(height: 2),
            Text(subtitle, style: TextStyle(fontSize: 11, color: OfficePrefs.ink.withOpacity(.6))),
          ])),
          Icon(Icons.chevron_right_rounded, color: OfficePrefs.ink.withOpacity(.45)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Theme(
    data: officeTheme(context),
    child: Scaffold(
      backgroundColor: kOfficeBg,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _refresh,
          child: CustomScrollView(slivers: [
            SliverToBoxAdapter(child: Container(
              padding: const EdgeInsets.fromLTRB(20, 18, 20, 22),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft, end: Alignment.bottomRight,
                  colors: [Color(0xFF19365B), Color(0xFF315E91), Color(0xFF447BB2)],
                ),
                borderRadius: BorderRadius.vertical(bottom: Radius.circular(28)),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  IconButton(onPressed: () => Navigator.maybePop(context), icon: const Icon(Icons.arrow_back_rounded, color: Colors.white)),
                  const Spacer(),
                  const Icon(Icons.cloud_done_outlined, color: Colors.white70),
                  const SizedBox(width: 7),
                  const Text('Abtin Office', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
                ]),
                const SizedBox(height: 12),
                Text(tr2('همه ابزارهای آفیس، یک‌جا', 'Your documents, all in one place'),
                    style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w800)),
                const SizedBox(height: 6),
                Text(tr2('ساخت، بازکردن و ادامه ویرایش اسناد', 'Create, open and continue editing documents'),
                    style: const TextStyle(color: Colors.white70, fontSize: 13)),
                const SizedBox(height: 18),
                Material(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(15),
                  child: TextField(
                    controller: _search,
                    textDirection: TextDirection.ltr,
                    decoration: InputDecoration(
                      hintText: tr2('جست‌وجوی فایل‌های آفیس', 'Search Office files'),
                      prefixIcon: const Icon(Icons.search_rounded),
                      suffixIcon: _search.text.isEmpty ? null : IconButton(
                        onPressed: () => _search.clear(), icon: const Icon(Icons.close_rounded)),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
              ]),
            )),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 8),
              sliver: SliverToBoxAdapter(child: Row(children: [
                Expanded(child: Text(tr2('ایجاد سند جدید', 'Create new'),
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: OfficePrefs.ink))),
                Text(tr2('سریع و آسان', 'Quick start'), style: TextStyle(color: OfficePrefs.ink.withOpacity(.55), fontSize: 12)),
              ])),
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverGrid(
                delegate: SliverChildListDelegate([
                  _documentTile(OfficeKind.docx, tr2('سند متنی', 'Document'), () => _create(OfficeKind.docx)),
                  _documentTile(OfficeKind.xlsx, tr2('صفحه‌گسترده', 'Spreadsheet'), () => _create(OfficeKind.xlsx)),
                  _documentTile(OfficeKind.pptx, tr2('ارائه اسلایدی', 'Presentation'), () => _create(OfficeKind.pptx)),
                ]),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: .92,
                ),
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
              sliver: SliverToBoxAdapter(child: Column(children: [
                _quickAction(Icons.folder_open_rounded, tr2('بازکردن فایل', 'Open a file'),
                    tr2('DOCX، XLSX، PPTX، PDF و بیشتر', 'DOCX, XLSX, PPTX, PDF and more'), _openPicker),
                const SizedBox(height: 9),
                _quickAction(Icons.picture_as_pdf_rounded, tr2('ابزارهای PDF', 'PDF tools'),
                    tr2('مشاهده، جست‌وجو، امضا و ویرایش', 'View, search, sign and edit'), _openPdfPicker),
              ])),
            ),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
              sliver: SliverToBoxAdapter(child: Row(children: [
                Expanded(child: Text(tr2('فایل‌های اخیر', 'Recent files'),
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: OfficePrefs.ink))),
                TextButton.icon(onPressed: _refresh, icon: const Icon(Icons.refresh_rounded, size: 18),
                    label: Text(tr2('تازه‌سازی', 'Refresh'))),
              ])),
            ),
            if (_loading)
              const SliverToBoxAdapter(child: Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator())))
            else if (_filtered.isEmpty)
              SliverToBoxAdapter(child: Padding(
                padding: const EdgeInsets.fromLTRB(24, 22, 24, 42),
                child: Center(child: Column(children: [
                  Icon(Icons.description_outlined, size: 44, color: OfficePrefs.ink.withOpacity(.3)),
                  const SizedBox(height: 8),
                  Text(_search.text.isEmpty ? tr2('هنوز سندی در این پوشه نیست.', 'No Office files in this folder yet.')
                      : tr2('فایلی با این نام پیدا نشد.', 'No matching files found.'),
                      style: TextStyle(color: OfficePrefs.ink.withOpacity(.6))),
                ])),
              ))
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 28),
                sliver: SliverList(delegate: SliverChildBuilderDelegate((context, i) {
                  final file = _filtered[i] as File;
                  final ext = p.extension(file.path).replaceFirst('.', '').toLowerCase();
                  final kind = {'docx': OfficeKind.docx, 'doc': OfficeKind.docx, 'dotx': OfficeKind.docx,
                    'xlsx': OfficeKind.xlsx, 'xlsm': OfficeKind.xlsx, 'xls': OfficeKind.xlsx,
                    'pptx': OfficeKind.pptx, 'ppsx': OfficeKind.pptx, 'pptm': OfficeKind.pptx,
                    'ppt': OfficeKind.pptx}[ext];
                  final icon = ext == 'pdf' ? Icons.picture_as_pdf_rounded : kind?.icon ?? Icons.description_rounded;
                  final color = ext == 'pdf' ? const Color(0xFFD32F2F) : kind?.color ?? kOfficeBlue;
                  final modified = file.statSync().modified;
                  return Card(
                    color: OfficePrefs.paper,
                    elevation: 0,
                    margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13), side: BorderSide(color: OfficePrefs.line)),
                    child: ListTile(
                      leading: Container(width: 42, height: 42,
                        decoration: BoxDecoration(color: color.withOpacity(.12), borderRadius: BorderRadius.circular(11)),
                        child: Icon(icon, color: color)),
                      title: Text(p.basename(file.path), maxLines: 1, overflow: TextOverflow.ellipsis,
                          style: TextStyle(fontWeight: FontWeight.w700, color: OfficePrefs.ink)),
                      subtitle: Text('${ext.toUpperCase()}  •  ${modified.toString().substring(0, 16)}',
                          style: TextStyle(fontSize: 11, color: OfficePrefs.ink.withOpacity(.58))),
                      trailing: Icon(Icons.chevron_right_rounded, color: OfficePrefs.ink.withOpacity(.4)),
                      onTap: () => _open(file.path),
                    ),
                  );
                }, childCount: _filtered.length)),
              ),
          ]),
        ),
      ),
    ),
  );
}
