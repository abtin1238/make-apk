import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/xlsx_formula.dart';

void main() {
  group('XlsxFormulaEngine', () {
    final values = <String, dynamic>{'A1': 10, 'A2': 20, 'A3': 30, 'B1': 'Abtin'};
    dynamic cell(String ref) => values[ref] ?? '';
    List<dynamic> range(String a, String b) {
      if (a == 'A1' && b == 'A3') return [10, 20, 30];
      return const [];
    }

    test('arithmetic and precedence', () {
      expect(XlsxFormulaEngine.evaluate('=2+3*4', cell: cell, range: range), 14.0);
      expect(XlsxFormulaEngine.evaluate('=(2+3)*4', cell: cell, range: range), 20.0);
    });

    test('cell references and ranges', () {
      expect(XlsxFormulaEngine.evaluate('=A1+A2', cell: cell, range: range), 30.0);
      expect(XlsxFormulaEngine.evaluate('=SUM(A1:A3)', cell: cell, range: range), 60.0);
      expect(XlsxFormulaEngine.evaluate('=AVERAGE(A1:A3)', cell: cell, range: range), 20.0);
    });

    test('common text and logical functions', () {
      expect(XlsxFormulaEngine.evaluate('=CONCAT(B1," Maps")', cell: cell, range: range), 'Abtin Maps');
      expect(XlsxFormulaEngine.evaluate('=IF(A1>5,"yes","no")', cell: cell, range: range), 'yes');
      expect(XlsxFormulaEngine.evaluate('=ROUND(3.14159,2)', cell: cell, range: range), 3.14);
    });

    test('division by zero returns an Excel error', () {
      expect(XlsxFormulaEngine.evaluate('=1/0', cell: cell, range: range), '#DIV/0!');
    });
  });
}
