package ir.abtin.gecko;

import android.graphics.Bitmap;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.json.JSONObject;
import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.WebExtension;
import org.mozilla.geckoview.WebExtensionController;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;

/**
 * Real Firefox WebExtensions: install/list/enable/remove, browser-action popups, extension tabs,
 * plus the bundled "Abtin Core" built-in extension (ad/tracker blocking, reader mode, page info).
 */
final class Extensions {
    static final String CORE_ID = "core@abtin.ir";
    static final String NATIVE_APP = "abtin";

    private final Engine e;
    private final WebExtensionController ctl;
    private WebExtension core;
    private WebExtension.Port bgPort;
    private JSONObject coreConfig = new JSONObject();
    private final Map<String, WebExtension> known = new HashMap<>();
    private final Map<String, WebExtension.Action> defaultActions = new HashMap<>();
    private final Map<String, Tab> popupTabs = new HashMap<>();
    private long lastListEmit = 0;

    Extensions(Engine e) {
        this.e = e;
        this.ctl = e.runtime.getWebExtensionController();
    }

    // ------------------------------------------------------------------ startup
    void start() {
        ctl.setPromptDelegate(promptDelegate);
        ctl.setAddonManagerDelegate(addonManager);
        ctl.setDebuggerDelegate(new WebExtensionController.DebuggerDelegate() {
            @Override public void onExtensionListUpdated() { refresh(); }
        });
        e.main.postDelayed(e::coreDone, 6000);
        ctl.ensureBuiltIn("resource://android/assets/abtin_core/", CORE_ID).accept(ext -> {
            if (ext == null) { e.coreDone(); return; }
            core = ext;
            ext.setMessageDelegate(bgMessages, NATIVE_APP);
            ctl.setAllowedInPrivateBrowsing(ext, true);
            register(ext);
            for (Tab t : e.tabs.values()) wire(t);
            refresh();
            e.coreDone();
        }, err -> { Log.e(Engine.TAG, "core extension failed", err); e.coreDone(); });
        refresh();
    }

    void setCoreConfig(JSONObject cfg) {
        coreConfig = cfg;
        pushConfig();
    }

    private void pushConfig() {
        if (bgPort != null) {
            try {
                final JSONObject m = new JSONObject();
                m.put("cmd", "config");
                m.put("config", coreConfig);
                bgPort.postMessage(m);
            } catch (Exception ex) { Log.w(Engine.TAG, "pushConfig", ex); }
        }
    }

    /** Asks the core extension's background page to deliver [msg] to the active tab. */
    boolean relayToActiveTab(JSONObject msg) {
        if (bgPort == null) return false;
        try {
            final JSONObject m = new JSONObject();
            m.put("cmd", "relay");
            m.put("msg", msg);
            bgPort.postMessage(m);
            return true;
        } catch (Exception ex) {
            Log.w(Engine.TAG, "relay", ex);
            return false;
        }
    }

    private final WebExtension.MessageDelegate bgMessages = new WebExtension.MessageDelegate() {
        @Override public void onConnect(@NonNull WebExtension.Port port) {
            bgPort = port;
            port.setDelegate(new WebExtension.PortDelegate() {
                @Override public void onDisconnect(@NonNull WebExtension.Port p) { if (bgPort == p) bgPort = null; }
            });
            pushConfig();
        }
    };

    // content scripts of the core extension (one port per top-level page)
    private final WebExtension.MessageDelegate contentMessages = new WebExtension.MessageDelegate() {
        @Override public void onConnect(@NonNull final WebExtension.Port port) {
            final GeckoSession s = port.sender.session;
            final Tab t = s == null ? null : e.bySession.get(s);
            if (t == null || !port.sender.isTopLevel()) return;
            t.contentPort = port;
            port.setDelegate(new WebExtension.PortDelegate() {
                @Override public void onPortMessage(@NonNull Object message, @NonNull WebExtension.Port p) {
                    if (!(message instanceof JSONObject)) return;
                    final JSONObject j = (JSONObject) message;
                    final Map<String, Object> m = Engine.ev(j.optString("t", "page"), t.id);
                    m.put("icon", j.optString("icon", ""));
                    m.put("theme", j.optString("theme", ""));
                    m.put("iconData", j.optString("iconData", ""));
                    if ("pageSaved".equals(j.optString("t"))) {
                        m.put("url", j.optString("url", ""));
                        m.put("title", j.optString("title", ""));
                        m.put("html", j.optString("html", ""));
                    }
                    if ("media".equals(j.optString("t")) || "mediaAct".equals(j.optString("t"))) {
                        m.put("act", j.optString("act", ""));
                        m.put("url", j.optString("url", ""));
                        m.put("mime", j.optString("mime", ""));
                        m.put("size", j.optLong("size", -1));
                        m.put("kind", j.optString("kind", ""));
                        m.put("part", j.optString("part", ""));
                        m.put("page", j.optString("page", ""));
                        m.put("title", j.optString("title", ""));
                        m.put("poster", j.optString("poster", ""));
                        m.put("ts", j.optLong("ts", 0));
                        m.put("t0", j.optLong("t0", 0));
                    }
                    e.emit(m);
                }

                @Override public void onDisconnect(@NonNull WebExtension.Port p) { if (t.contentPort == p) t.contentPort = null; }
            });
        }
    };

    // ------------------------------------------------------------------ registration
    /** Attach per-session delegates for every known extension. */
    void wire(Tab t) {
        final WebExtension.SessionController sc = t.session.getWebExtensionController();
        if (core != null) sc.setMessageDelegate(core, contentMessages, NATIVE_APP);
        for (WebExtension x : known.values()) {
            if (x.isBuiltIn) continue;
            sc.setActionDelegate(x, actionDelegate);
            sc.setTabDelegate(x, sessionTabDelegate);
        }
        if (core != null) { sc.setActionDelegate(core, actionDelegate); sc.setTabDelegate(core, sessionTabDelegate); }
    }

    void forget(Tab t) {
        popupTabs.values().remove(t);
    }

    private void register(WebExtension x) {
        known.put(x.id, x);
        x.setActionDelegate(actionDelegate);
        x.setTabDelegate(tabDelegate);
        for (Tab t : e.tabs.values()) {
            final WebExtension.SessionController sc = t.session.getWebExtensionController();
            sc.setActionDelegate(x, actionDelegate);
            sc.setTabDelegate(x, sessionTabDelegate);
        }
    }

    void refresh() {
        ctl.list().accept(list -> {
            known.clear();
            if (list != null) for (WebExtension x : list) register(x);
            if (core != null) known.put(core.id, core);
            changed();
        }, err -> Log.w(Engine.TAG, "list", err));
    }

    private void changed() {
        final long now = System.currentTimeMillis();
        if (now - lastListEmit < 150) return;
        lastListEmit = now;
        e.emit(Engine.ev("ext", 0));
    }

    // ------------------------------------------------------------------ delegates
    private final WebExtensionController.PromptDelegate promptDelegate = new WebExtensionController.PromptDelegate() {
        @Nullable @Override
        public GeckoResult<WebExtension.PermissionPromptResponse> onInstallPromptRequest(@NonNull WebExtension ext, @NonNull String[] perms,
                                                                                         @NonNull String[] origins, @NonNull String[] data) {
            final GeckoResult<WebExtension.PermissionPromptResponse> res = new GeckoResult<>();
            final Map<String, Object> a = new HashMap<>();
            a.put("name", ext.metaData.name);
            a.put("permissions", java.util.Arrays.asList(perms));
            a.put("origins", java.util.Arrays.asList(origins));
            e.ask("extInstallPrompt", a, v -> {
                final boolean ok = Boolean.TRUE.equals(v);
                res.complete(new WebExtension.PermissionPromptResponse(Boolean.valueOf(ok), Boolean.FALSE, Boolean.FALSE));
            });
            return res;
        }

        @Nullable @Override
        public GeckoResult<AllowOrDeny> onUpdatePrompt(@NonNull WebExtension ext, @NonNull String[] p, @NonNull String[] o, @NonNull String[] d) {
            return GeckoResult.allow();
        }

        @Nullable @Override
        public GeckoResult<AllowOrDeny> onOptionalPrompt(@NonNull WebExtension ext, @NonNull String[] p, @NonNull String[] o, @NonNull String[] d) {
            return GeckoResult.allow();
        }
    };

    private final WebExtensionController.AddonManagerDelegate addonManager = new WebExtensionController.AddonManagerDelegate() {
        @Override public void onInstalled(@NonNull WebExtension ext) { register(ext); changed(); }
        @Override public void onUninstalled(@NonNull WebExtension ext) { known.remove(ext.id); defaultActions.remove(ext.id); changed(); }
        @Override public void onEnabled(@NonNull WebExtension ext) { register(ext); changed(); }
        @Override public void onDisabled(@NonNull WebExtension ext) { changed(); }
        @Override public void onReady(@NonNull WebExtension ext) { register(ext); changed(); }
        @Override public void onOptionalPermissionsChanged(@NonNull WebExtension ext) { changed(); }
    };

    private final WebExtension.ActionDelegate actionDelegate = new WebExtension.ActionDelegate() {
        @Override public void onBrowserAction(@NonNull WebExtension ext, @Nullable GeckoSession session, @NonNull WebExtension.Action action) {
            if (session == null) defaultActions.put(ext.id, action);
            else { final Tab t = e.bySession.get(session); if (t != null) t.actions.put(ext.id, action); }
            changed();
        }

        @Override public void onPageAction(@NonNull WebExtension ext, @Nullable GeckoSession session, @NonNull WebExtension.Action action) {
            onBrowserAction(ext, session, action);
        }

        @Nullable @Override public GeckoResult<GeckoSession> onTogglePopup(@NonNull WebExtension ext, @NonNull WebExtension.Action action) {
            return popup(ext);
        }

        @Nullable @Override public GeckoResult<GeckoSession> onOpenPopup(@NonNull WebExtension ext, @NonNull WebExtension.Action action) {
            return popup(ext);
        }
    };

    private GeckoResult<GeckoSession> popup(WebExtension ext) {
        final Tab old = popupTabs.get(ext.id);
        if (old != null && old.session.isOpen()) {
            e.emit(Engine.ev("tabSelect", old.id));
            return GeckoResult.fromValue(old.session);
        }
        final Tab t = e.createForeignTab(false);
        t.popup = true;
        t.popupExtId = ext.id;
        popupTabs.put(ext.id, t);
        final Map<String, Object> m = Engine.ev("tabCreated", t.id);
        m.put("url", "");
        m.put("popup", true);
        m.put("title", ext.metaData.name);
        m.put("private", false);
        e.emit(m);
        return GeckoResult.fromValue(t.session);
    }

    private final WebExtension.TabDelegate tabDelegate = new WebExtension.TabDelegate() {
        @Nullable @Override
        public GeckoResult<GeckoSession> onNewTab(@NonNull WebExtension ext, @NonNull WebExtension.CreateTabDetails d) {
            final Tab t = e.createForeignTab(false);
            final Map<String, Object> m = Engine.ev("tabCreated", t.id);
            m.put("url", d.url == null ? "" : d.url);
            m.put("private", false);
            m.put("background", Boolean.FALSE.equals(d.active));
            e.emit(m);
            return GeckoResult.fromValue(t.session);
        }

        @Override public void onOpenOptionsPage(@NonNull WebExtension ext) { openOptions(ext); }
    };

    private final WebExtension.SessionTabDelegate sessionTabDelegate = new WebExtension.SessionTabDelegate() {
        @NonNull @Override
        public GeckoResult<AllowOrDeny> onCloseTab(@Nullable WebExtension ext, @NonNull GeckoSession session) {
            final Tab t = e.bySession.get(session);
            if (t != null) e.emit(Engine.ev("closeRequest", t.id));
            return GeckoResult.allow();
        }

        @NonNull @Override
        public GeckoResult<AllowOrDeny> onUpdateTab(@NonNull WebExtension ext, @NonNull GeckoSession session, @NonNull WebExtension.UpdateTabDetails d) {
            final Tab t = e.bySession.get(session);
            if (t != null) {
                if (d.url != null) { e.ensureOpen(t); session.loadUri(d.url); }
                if (Boolean.TRUE.equals(d.active)) e.emit(Engine.ev("tabSelect", t.id));
            }
            return GeckoResult.allow();
        }
    };

    private void openOptions(WebExtension ext) {
        final String u = ext.metaData.optionsPageUrl;
        if (u == null) return;
        final Tab t = e.createForeignTab(false);
        final Map<String, Object> m = Engine.ev("tabCreated", t.id);
        m.put("url", u);
        m.put("private", false);
        m.put("title", ext.metaData.name);
        e.emit(m);
    }

    // ------------------------------------------------------------------ Dart calls
    void onCall(MethodCall c, final MethodChannel.Result r) {
        switch (c.method) {
            case "extList": list(r); return;
            case "extInstall": install((String) c.argument("url"), null, r); return;
            case "extInstallFile": install("file://" + c.argument("path"), WebExtensionController.INSTALLATION_METHOD_FROM_FILE, r); return;
            case "extRemove": withExt(c, r, x -> ctl.uninstall(x).accept(v -> r.success(true), err -> r.success(false))); return;
            case "extEnable": {
                final boolean on = Boolean.TRUE.equals(c.argument("enabled"));
                withExt(c, r, x -> (on ? ctl.enable(x, WebExtensionController.EnableSource.USER) : ctl.disable(x, WebExtensionController.EnableSource.USER))
                        .accept(v -> { refresh(); r.success(true); }, err -> r.success(false)));
                return;
            }
            case "extPrivate": {
                final boolean on = Boolean.TRUE.equals(c.argument("allowed"));
                withExt(c, r, x -> ctl.setAllowedInPrivateBrowsing(x, on).accept(v -> { refresh(); r.success(true); }, err -> r.success(false)));
                return;
            }
            case "extUpdate": withExt(c, r, x -> ctl.update(x).accept(v -> { refresh(); r.success(true); }, err -> r.success(false))); return;
            case "extOptions": withExt(c, r, x -> { openOptions(x); r.success(true); }); return;
            case "extAction": {
                withExt(c, r, x -> {
                    WebExtension.Action a = defaultActions.get(x.id);
                    if (e.current != null) {
                        final WebExtension.Action ta = e.current.actions.get(x.id);
                        if (ta != null) a = a == null ? ta : ta.withDefault(a);
                    }
                    if (a != null) a.click();
                    r.success(a != null);
                });
                return;
            }
            default: r.notImplemented();
        }
    }

    private interface ExtOp { void run(WebExtension x); }

    private void withExt(MethodCall c, MethodChannel.Result r, ExtOp op) {
        final WebExtension x = known.get((String) c.argument("id"));
        if (x == null) { r.success(false); return; }
        op.run(x);
    }

    private void install(String url, @Nullable String method, final MethodChannel.Result r) {
        final GeckoResult<WebExtension> res = method == null ? ctl.install(url) : ctl.install(url, method);
        res.accept(x -> {
            if (x != null) register(x);
            final Map<String, Object> m = new HashMap<>();
            m.put("ok", true);
            m.put("name", x == null ? "" : x.metaData.name);
            refresh();
            r.success(m);
        }, err -> {
            final Map<String, Object> m = new HashMap<>();
            m.put("ok", false);
            int code = 0;
            if (err instanceof WebExtension.InstallException) code = ((WebExtension.InstallException) err).code;
            m.put("code", code);
            m.put("error", errorText(code, err));
            r.success(m);
        });
    }

    private String errorText(int code, @Nullable Throwable err) {
        final boolean fa = "fa".equals(e.lang);
        switch (code) {
            case WebExtension.InstallException.ErrorCodes.ERROR_USER_CANCELED: return fa ? "نصب لغو شد" : "Installation canceled";
            case WebExtension.InstallException.ErrorCodes.ERROR_NETWORK_FAILURE: return fa ? "خطای شبکه" : "Network failure";
            case WebExtension.InstallException.ErrorCodes.ERROR_SIGNEDSTATE_REQUIRED:
                return fa ? "افزونه امضا نشده است (فقط افزونه‌های امضاشدهٔ Mozilla نصب می‌شوند)" : "Extension is not signed (only Mozilla-signed add-ons can be installed)";
            case WebExtension.InstallException.ErrorCodes.ERROR_CORRUPT_FILE: return fa ? "فایل افزونه خراب است" : "Corrupt extension file";
            case WebExtension.InstallException.ErrorCodes.ERROR_INCOMPATIBLE: return fa ? "با این نسخه سازگار نیست" : "Incompatible with this version";
            case WebExtension.InstallException.ErrorCodes.ERROR_BLOCKLISTED: return fa ? "افزونه مسدود شده است" : "Add-on is blocklisted";
            default: return String.valueOf(err);
        }
    }

    private void list(final MethodChannel.Result r) {
        final List<WebExtension> exts = new ArrayList<>();
        for (WebExtension x : known.values()) if (!x.isBuiltIn) exts.add(x);
        final List<GeckoResult<byte[]>> icons = new ArrayList<>();
        for (WebExtension x : exts) icons.add(iconOf(x.metaData.icon));
        final List<GeckoResult<byte[]>> actionIcons = new ArrayList<>();
        final List<WebExtension.Action> actions = new ArrayList<>();
        for (WebExtension x : exts) {
            WebExtension.Action a = defaultActions.get(x.id);
            if (e.current != null) {
                final WebExtension.Action ta = e.current.actions.get(x.id);
                if (ta != null) a = a == null ? ta : ta.withDefault(a);
            }
            actions.add(a);
            actionIcons.add(a != null && a.icon != null ? iconOf(a.icon) : GeckoResult.fromValue((byte[]) null));
        }
        GeckoResult.allOf(icons).accept(ic -> GeckoResult.allOf(actionIcons).accept(aic -> {
            final List<Map<String, Object>> out = new ArrayList<>();
            for (int i = 0; i < exts.size(); i++) {
                final WebExtension x = exts.get(i);
                final WebExtension.MetaData md = x.metaData;
                final Map<String, Object> m = new HashMap<>();
                m.put("id", x.id);
                m.put("name", md.name);
                m.put("description", md.description);
                m.put("version", md.version);
                m.put("enabled", md.enabled);
                m.put("privateAllowed", md.allowedInPrivateBrowsing);
                m.put("optionsUrl", md.optionsPageUrl);
                m.put("homepage", md.homepageUrl);
                m.put("amoUrl", md.amoListingUrl);
                m.put("creator", md.creatorName);
                m.put("permissions", java.util.Arrays.asList(md.requiredPermissions));
                m.put("origins", java.util.Arrays.asList(md.requiredOrigins));
                m.put("signed", md.signedState);
                m.put("disabledFlags", md.disabledFlags);
                final byte[] mainIcon = ic == null ? null : ic.get(i);
                final byte[] actIcon = aic == null ? null : aic.get(i);
                m.put("icon", mainIcon != null ? mainIcon : actIcon);
                final WebExtension.Action a = actions.get(i);
                if (a != null && !Boolean.FALSE.equals(a.enabled)) {
                    final Map<String, Object> am = new HashMap<>();
                    am.put("title", a.title);
                    am.put("badge", a.badgeText);
                    am.put("icon", aic == null ? null : aic.get(i));
                    m.put("action", am);
                }
                out.add(m);
            }
            r.success(out);
        }, err -> r.success(new ArrayList<>())), err -> r.success(new ArrayList<>()));
    }

    private static GeckoResult<byte[]> iconOf(@Nullable org.mozilla.geckoview.Image img) {
        return iconOf(img, new int[]{96, 128, 48, 64, 32});
    }

    /** Tries several sizes: some add-ons only ship one icon size, and getBitmap() fails for the others. */
    private static GeckoResult<byte[]> iconOf(@Nullable final org.mozilla.geckoview.Image img, final int[] sizes) {
        if (img == null || sizes.length == 0) return GeckoResult.fromValue((byte[]) null);
        final int[] rest = java.util.Arrays.copyOfRange(sizes, 1, sizes.length);
        try {
            return img.getBitmap(sizes[0]).then(bmp -> {
                if (bmp == null) return iconOf(img, rest);
                final ByteArrayOutputStream bo = new ByteArrayOutputStream();
                bmp.compress(Bitmap.CompressFormat.PNG, 100, bo);
                return GeckoResult.fromValue(bo.toByteArray());
            }, ex -> iconOf(img, rest));
        } catch (Throwable t) {
            return iconOf(img, rest);
        }
    }
}
