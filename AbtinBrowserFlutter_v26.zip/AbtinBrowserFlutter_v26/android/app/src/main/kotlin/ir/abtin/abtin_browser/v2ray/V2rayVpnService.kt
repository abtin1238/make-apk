package ir.abtin.abtin_browser.v2ray

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import ir.abtin.abtin_browser.R
import java.io.File
import java.util.concurrent.Executors

/**
 * System-wide VPN (runs in its own process, ":v2ray"). Xray reads the TUN descriptor itself (the "tun" inbound of
 * the config, same mode PattNG uses by default). This app's own package is excluded from the VPN so the core's
 * outbound sockets leave directly; the in-app browser reaches the same core through its local SOCKS inbound instead.
 */
class V2rayVpnService : VpnService() {
    companion object {
        private const val TAG = "AbtinV2rayVpn"
        private const val CHANNEL = "abtin_v2ray"
        private const val NOTIFICATION_ID = 7788
        @Volatile private var generation = 0
    }

    private val worker = Executors.newSingleThreadExecutor()
    private var tun: ParcelFileDescriptor? = null
    private var statsThread: Thread? = null
    @Volatile private var stopping = false
    private var profileName = "VPN"

    private val queryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            V2rayEvents.state(applicationContext, V2rayCore.state, V2rayCore.lastError)
        }
    }
    private val stopReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            worker.execute { teardown("disconnected", "") }
        }
    }

    override fun onCreate() {
        super.onCreate()
        ContextCompat.registerReceiver(this, queryReceiver, IntentFilter(V2rayConst.ACTION_QUERY), ContextCompat.RECEIVER_NOT_EXPORTED)
        ContextCompat.registerReceiver(this, stopReceiver, IntentFilter(V2rayConst.ACTION_STOP), ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Started with startForegroundService: enter the foreground first, whatever the intent says.
        profileName = intent?.getStringExtra("name") ?: profileName
        startForeground(NOTIFICATION_ID, notification("..."))
        if (intent == null || intent.action != V2rayConst.ACTION_START) {
            // System restart / always-on without our config: nothing to run.
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        generation++
        stopping = false
        val mtu = intent.getIntExtra("mtu", 1500)
        val ipv6 = intent.getBooleanExtra("ipv6", true)
        val bypassLan = intent.getBooleanExtra("bypassLan", true)
        val dns = (intent.getStringExtra("dns") ?: "8.8.8.8").split(',').map { it.trim() }.filter { it.isNotEmpty() }
        val skip = (intent.getStringExtra("skip") ?: "").split(',').map { it.trim() }.filter { it.isNotEmpty() }
        worker.execute { doStart(mtu, ipv6, bypassLan, dns, skip) }
        return START_NOT_STICKY
    }

    override fun onRevoke() {
        worker.execute { teardown("disconnected", "") }
    }

    override fun onDestroy() {
        try { unregisterReceiver(queryReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(stopReceiver) } catch (_: Exception) {}
        if (!stopping) {
            stopping = true
            V2rayCore.stop()
            try { tun?.close() } catch (_: Exception) {}
            tun = null
        }
        worker.shutdown()
        super.onDestroy()
    }

    private fun doStart(mtu: Int, ipv6: Boolean, bypassLan: Boolean, dns: List<String>, skip: List<String>) {
        try {
            V2rayCore.state = "connecting"
            V2rayCore.lastError = ""
            V2rayEvents.state(applicationContext, "connecting")
            val config = File(filesDir, V2rayConst.CONFIG_FILE).readText()
            val fd = establish(mtu, ipv6, bypassLan, dns, skip)
            V2rayCore.start(applicationContext, config, fd.fd)
            if (stopping) return
            V2rayCore.state = "connected"
            getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, notification("متصل / Connected"))
            V2rayEvents.state(applicationContext, "connected")
            startStats()
        } catch (t: Throwable) {
            Log.e(TAG, "start failed", t)
            teardown("error", t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName)
        }
    }

    private fun establish(mtu: Int, ipv6: Boolean, bypassLan: Boolean, dns: List<String>, skip: List<String>): ParcelFileDescriptor {
        fun build(v6: Boolean): ParcelFileDescriptor {
            val b = Builder()
            b.setSession(profileName)
            b.setMtu(mtu)
            b.addAddress("10.10.14.1", 30)
            if (v6) b.addAddress("fc00::10:10:14:1", 126)
            if (bypassLan) {
                for (r in V2rayConst.ROUTED_IP_LIST) {
                    val p = r.split('/')
                    b.addRoute(p[0], p[1].toInt())
                }
            } else {
                b.addRoute("0.0.0.0", 0)
            }
            if (v6) {
                if (bypassLan) b.addRoute("2000::", 3) else b.addRoute("::", 0)
            }
            var added = 0
            for (d in dns) {
                if (!v6 && d.contains(':')) continue // an IPv6 DNS server would let IPv6 around the VPN
                try { b.addDnsServer(d); added++ } catch (e: IllegalArgumentException) { Log.w(TAG, "dns refused: $d") }
            }
            if (added == 0) b.addDnsServer("8.8.8.8")
            b.setMetered(false)
            // The core's own sockets must not loop back into the TUN: exclude this app (the browser uses the local SOCKS inbound).
            try { b.addDisallowedApplication(packageName) } catch (_: Exception) {}
            for (p in skip) {
                try { b.addDisallowedApplication(p) } catch (_: Exception) {}
            }
            return b.establish() ?: throw IllegalStateException("VPN permission was not granted")
        }
        val fd = try {
            build(ipv6)
        } catch (e: Exception) {
            if (!ipv6) throw e
            Log.w(TAG, "IPv6 refused, retrying IPv4 only", e)
            build(false)
        }
        tun = fd
        return fd
    }

    private fun startStats() {
        val t = Thread {
            var totalUp = 0L
            var totalDown = 0L
            while (!stopping) {
                try { Thread.sleep(1000) } catch (_: InterruptedException) { break }
                if (stopping) break
                val s = V2rayCore.queryStats()
                totalUp += s.first
                totalDown += s.second
                V2rayEvents.send(applicationContext) {
                    putExtra("type", "stats")
                    putExtra("up", s.first)
                    putExtra("down", s.second)
                    putExtra("totalUp", totalUp)
                    putExtra("totalDown", totalDown)
                }
            }
        }
        t.isDaemon = true
        t.name = "abtin-v2ray-stats"
        statsThread = t
        t.start()
    }

    private fun teardown(finalState: String, error: String) {
        if (stopping && V2rayCore.state == "disconnected") return
        stopping = true
        statsThread?.let {
            it.interrupt()
            try { it.join(2000) } catch (_: InterruptedException) {}
        }
        statsThread = null
        V2rayCore.stop()
        V2rayCore.state = "disconnected"
        V2rayCore.lastError = error
        // stopSelf before closing the interface, as PattNG does: otherwise the old core may keep its port.
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        try { Thread.sleep(100) } catch (_: InterruptedException) {}
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        V2rayEvents.state(applicationContext, finalState, error)
        // A fresh Go runtime for the next connection, and the memory back: end this process unless a new start came.
        Handler(Looper.getMainLooper()).postDelayed({
            android.os.Process.killProcess(android.os.Process.myPid())
        }, 1000)
    }

    private fun notification(status: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm?.createNotificationChannel(NotificationChannel(CHANNEL, "VPN", NotificationManager.IMPORTANCE_LOW))
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val open = if (launch != null) PendingIntent.getActivity(this, 0, launch, flags) else null
        val stop = PendingIntent.getBroadcast(this, 1, Intent(V2rayConst.ACTION_STOP).setPackage(packageName), flags)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_v2ray_notif)
            .setContentTitle(profileName)
            .setContentText(status)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(open)
            .addAction(0, "قطع اتصال / Disconnect", stop)
            .build()
    }
}
