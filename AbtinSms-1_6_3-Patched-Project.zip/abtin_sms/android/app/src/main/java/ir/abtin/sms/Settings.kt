package ir.abtin.sms

import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ---------- building blocks ----------
@Composable
fun SPage(title: String, back: (() -> Unit)?, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 14.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (back != null) { CircleBtn(Icons.AutoMirrored.Filled.ArrowBack, back); Spacer(Modifier.width(14.dp)) }
            Text(title, color = p.text, fontSize = if (back == null) 38.sp else 26.sp, fontWeight = FontWeight.ExtraBold)
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(bottom = 24.dp), content = content)
    }
}

@Composable
fun SGroup(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(20.dp)
    if (title != null) Text(title, color = p.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 28.dp, end = 28.dp, top = 16.dp, bottom = 6.dp))
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp).clip(shape).background(p.surface).border(1.dp, p.line, shape), content = content)
}

@Composable
fun SNav(icon: ImageVector, title: String, sub: String?, onClick: () -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(p.primary.copy(alpha = .16f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = p.primary, modifier = Modifier.size(22.dp)) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) { Text(title, color = p.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold); if (sub != null) Text(sub, color = p.sub, fontSize = 13.sp) }
    }
}

@Composable
fun SSwitch(title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, color = p.text, fontSize = 16.sp); if (sub != null) Text(sub, color = p.sub, fontSize = 12.sp) }
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = p.primary, checkedThumbColor = Color.White, uncheckedTrackColor = p.line, uncheckedThumbColor = p.sub, uncheckedBorderColor = p.line))
    }
}

@Composable
fun SAction(title: String, sub: String? = null, danger: Boolean = false, onClick: () -> Unit) {
    val p = LocalPal.current
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 13.dp)) {
        Text(title, color = if (danger) p.danger else p.text, fontSize = 16.sp); if (sub != null) Text(sub, color = p.sub, fontSize = 12.sp)
    }
}

@Composable
fun SChoice(title: String, options: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit) {
    val p = LocalPal.current
    Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text(title, color = p.text, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { (k, label) ->
                val sel = k == selected
                Text(label, color = if (sel) Color.White else p.text, fontSize = 14.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) p.primary else p.bg.copy(alpha = .5f)).border(1.dp, if (sel) p.primary else p.line, RoundedCornerShape(50)).clickable { onPick(k) }.padding(horizontal = 16.dp, vertical = 8.dp))
            }
        }
    }
}

private val PALETTE = listOf(
    0xFF2F6BFF, 0xFF1E88E5, 0xFF00ACC1, 0xFF00897B, 0xFF43A047, 0xFF7CB342,
    0xFFFDD835, 0xFFFFB300, 0xFFFB8C00, 0xFFF4511E, 0xFFE53935, 0xFFD81B60,
    0xFF8E24AA, 0xFF5E35B1, 0xFF3949AB, 0xFF6D4C41, 0xFF546E7A, 0xFF204F99,
    0xFF0D1626, 0xFF1A2537, 0xFF121212, 0xFF263238, 0xFFFFFFFF, 0xFF9E9E9E
).map { it.toInt() }

/** Tap-to-open color picker: preset palette + HSV sliders for a stored ARGB color; 0 = default. */
@Composable
fun ColorSliders(title: String, value: Int, default: Color, onChange: (Int) -> Unit) {
    val p = LocalPal.current
    var open by remember { mutableStateOf(false) }
    val cur = if (value == 0) default else Color(value)
    val hsv = remember(value) { FloatArray(3).also { android.graphics.Color.colorToHSV(android.graphics.Color.argb(255, (cur.red * 255).toInt(), (cur.green * 255).toInt(), (cur.blue * 255).toInt()), it) } }
    var h by remember(value) { mutableFloatStateOf(hsv[0]) }
    var sat by remember(value) { mutableFloatStateOf(hsv[1]) }
    var v by remember(value) { mutableFloatStateOf(hsv[2]) }
    fun push() { onChange(android.graphics.Color.HSVToColor(floatArrayOf(h, sat, v))) }
    val live = Color(android.graphics.Color.HSVToColor(floatArrayOf(h, sat, v)))
    Column(Modifier.padding(horizontal = 18.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { open = !open }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(30.dp).clip(CircleShape).background(live).border(1.dp, p.line, CircleShape))
            Spacer(Modifier.width(12.dp))
            Text(title, color = p.text, fontSize = 16.sp, modifier = Modifier.weight(1f))
            if (value != 0) Text(tr("پیش‌فرض", "Reset"), color = p.primary, fontSize = 14.sp, modifier = Modifier.clip(RoundedCornerShape(50)).clickable { onChange(0) }.padding(horizontal = 10.dp, vertical = 4.dp))
            Icon(if (open) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = p.sub)
        }
        if (open) {
            Spacer(Modifier.height(8.dp))
            PALETTE.chunked(6).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    row.forEach { c ->
                        val sel = value == c
                        Box(Modifier.size(40.dp).clip(CircleShape).background(Color(c)).border(if (sel) 3.dp else 1.dp, if (sel) Color.White else p.line, CircleShape).clickable { onChange(c) },
                            contentAlignment = Alignment.Center) { if (sel) Icon(Icons.Default.Check, null, tint = if (Color(c).luminance() > 0.5f) Color.Black else Color.White) }
                    }
                }
            }
            val sc = SliderDefaults.colors(thumbColor = live, activeTrackColor = live, inactiveTrackColor = p.line)
            Text(tr("طیف رنگ", "Hue"), color = p.sub, fontSize = 12.sp)
            Slider(h, { h = it; push() }, valueRange = 0f..360f, colors = sc)
            Text(tr("اشباع", "Saturation"), color = p.sub, fontSize = 12.sp)
            Slider(sat, { sat = it; push() }, valueRange = 0f..1f, colors = sc)
            Text(tr("روشنایی", "Brightness"), color = p.sub, fontSize = 12.sp)
            Slider(v, { v = it; push() }, valueRange = 0f..1f, colors = sc)
        }
    }
}

@Composable
fun BubbleShapePicker(selected: String, onPick: (String) -> Unit) {
    val p = LocalPal.current
    val opts = listOf("tail" to tr("دم‌دار", "Tail"), "rounded" to tr("نرم", "Rounded"), "pill" to tr("کپسولی", "Pill"), "square" to tr("چهارگوش", "Square"))
    Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
        Text(tr("شکل حباب پیام", "Bubble shape"), color = p.text, fontSize = 16.sp)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            opts.forEach { (k, label) ->
                val sel = k == selected
                val cardShape = RoundedCornerShape(16.dp)
                Column(Modifier.weight(1f).clip(cardShape).background(if (sel) p.primary.copy(alpha = .16f) else p.bg.copy(alpha = .5f))
                    .border(if (sel) 2.dp else 1.dp, if (sel) p.primary else p.line, cardShape).clickable { onPick(k) }.padding(vertical = 10.dp, horizontal = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.fillMaxWidth().height(22.dp), contentAlignment = Alignment.CenterStart) {
                        Box(Modifier.width(46.dp).height(20.dp).background(SolidColor(p.inBubble), BubbleShape(false, k)))
                    }
                    Spacer(Modifier.height(5.dp))
                    Box(Modifier.fillMaxWidth().height(22.dp), contentAlignment = Alignment.CenterEnd) {
                        Box(Modifier.width(46.dp).height(20.dp).background(Brush.linearGradient(listOf(p.out1, p.out2)), BubbleShape(true, k)))
                    }
                    Text(label, color = if (sel) p.primary else p.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
    }
}

// ---------- screens ----------
@Composable
fun SettingsScreen(repo: SmsRepo, act: ComponentActivity, nav: MutableState<Screen>, askDefault: () -> Unit) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    val page = Bus.page.value
    val back = { Bus.page.value = "" }
    val isDef = remember(Bus.tick.intValue) { isDefaultSms(act) }
    fun toast(n: Int) = Toast.makeText(act, if (n >= 0) "$n ✓" else "✗", Toast.LENGTH_LONG).show()
    val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) scope.launch(Dispatchers.IO) { val n = runCatching { repo.backup(u) }.getOrDefault(-1); withContext(Dispatchers.Main) { toast(n) } }
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch(Dispatchers.IO) { val n = runCatching { repo.restore(u) }.getOrDefault(-1); withContext(Dispatchers.Main) { toast(n) } }
    }
    fun refreshCallNotification() {
        if (Prefs.profile == "phone" && CallHub.service != null) {
            CallHub.current()?.let { CallHub.notifyCall(it) }
        }
    }
    val ring = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            @Suppress("DEPRECATION") val u = r.data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            val picked = u?.toString() ?: ""
            if (Prefs.profile == "phone") {
                Prefs.callNotifSound.value = picked
                refreshCallNotification()
            } else Prefs.notifSound.value = picked
        }
    }

    // The Phone launcher has its own settings surface. It intentionally does not
    // expose SMS-only options and every call preference is stored in phone_* keys.
    if (Prefs.profile == "phone") {
        when (page) {
            "general" -> SPage(tr("عمومی", "General"), back) {
                SGroup(tr("زبان و نمایش", "LANGUAGE & DISPLAY")) {
                    SChoice(tr("زبان", "Language"),
                        listOf("system" to tr("سیستم", "System"), "fa" to "فارسی", "en" to "English"),
                        Prefs.language.value) { Prefs.language.value = it }
                    SSwitch(tr("ضبط خودکار تماس‌ها", "Auto-record calls"),
                        tr("به مجوز میکروفون نیاز دارد؛ ضبط مستقیم را بعضی دستگاه‌ها مسدود می‌کنند. ضبط جایگزینِ بلندگو/میکروفون فقط با تأیید دستی انجام می‌شود", "Requires microphone permission; some devices block direct call capture. The speaker/microphone fallback is manual and requires confirmation"),
                        Prefs.autoRecordCalls.value) { Prefs.autoRecordCalls.value = it }
                    Column(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
                        Text(tr("اندازه متن", "Text size") + "  ${(Prefs.fontScale.value * 100).toInt()}%", color = p.text)
                        Slider(Prefs.fontScale.value, { Prefs.fontScale.value = it }, valueRange = 0.8f..1.4f, steps = 5,
                            colors = SliderDefaults.colors(thumbColor = p.primary, activeTrackColor = p.primary, inactiveTrackColor = p.line))
                    }
                }
            }
            "notif" -> SPage(tr("اعلان تماس", "Call notifications"), back) {
                SGroup(tr("دسترسی‌های لازم برای تماس روی قفل", "LOCK SCREEN CALL ACCESS")) {
                    val nmgr = act.getSystemService(android.app.NotificationManager::class.java)
                    val okTxt = tr("✓ فعال", "✓ Enabled")
                    val noTxt = tr("✗ غیرفعال — لمس برای فعال‌کردن", "✗ Off — tap to enable")
                    val pkg = Uri.parse("package:${act.packageName}")
                    SAction(tr("راه‌اندازی مرحله‌ای دسترسی‌ها", "Guided access setup"), tr("همه دسترسی‌ها را پشت‌سرهم باز می‌کند", "Opens each access page in turn")) {
                        Prefs.withProfile(true) { Prefs.callSetupDone.value = false }
                    }
                    if (isXiaomiFamily()) SAction(tr("مجوزهای شیائومی", "Xiaomi permissions"), tr("نمایش روی صفحه قفل و پاپ‌آپ در پس‌زمینه", "Lock screen and background pop-up")) { openMiuiPermissions(act) }
                    SAction(tr("اعلان‌ها", "Notifications"), if (nmgr.areNotificationsEnabled()) okTxt else noTxt) {
                        act.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName))
                    }
                    if (Build.VERSION.SDK_INT >= 34) SAction(tr("اعلان تمام‌صفحه (روشن‌شدن صفحه قفل)", "Full-screen notifications"), if (nmgr.canUseFullScreenIntent()) okTxt else noTxt) {
                        runCatching { act.startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, pkg)) }
                    }
                    SAction(tr("نمایش روی سایر برنامه‌ها", "Display over other apps"), if (Settings.canDrawOverlays(act)) okTxt else noTxt) {
                        runCatching { act.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkg)) }
                    }
                    SAction(tr("بدون محدودیت باتری", "Unrestricted battery"), tr("برای گوشی‌هایی که برنامه را در پس‌زمینه می‌بندند", "For phones that kill background apps")) {
                        runCatching { act.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                    }
                }
                SGroup(tr("اعلان ورودی و تماس", "CALL ALERTS")) {
                    SSwitch(tr("اعلان تماس‌ها", "Call notifications"), tr("نمایش اعلان تماس ورودی و تماس جاری", "Show incoming and ongoing call notifications"), Prefs.callNotifications.value) {
                        Prefs.callNotifications.value = it
                        if (!it && CallHub.service != null) CallHub.cancelNotif() else refreshCallNotification()
                    }
                    SSwitch(tr("ماندن صفحه تماس هنگام زنگ", "Keep call screen up while ringing"), tr("اگر اعلان تماس ورودی را ببندید یا از صفحه تماس خارج شوید، دوباره بالا می‌آید؛ صفحه تماس فقط با لمس اعلان باز می‌شود", "The incoming-call notification pops up again if you leave the call screen; the call screen opens only when you tap the notification"), Prefs.callKeepOnTop.value) { Prefs.callKeepOnTop.value = it }
                    SSwitch(tr("لرزش", "Vibration"), null, Prefs.callVibrate.value) { Prefs.callVibrate.value = it; refreshCallNotification() }
                    SSwitch(tr("صدای اعلان", "Notification sound"), null, Prefs.callSoundEnabled.value) { Prefs.callSoundEnabled.value = it; refreshCallNotification() }
                    if (Prefs.callSoundEnabled.value) {
                        SAction(tr("انتخاب صدای تماس", "Choose call notification sound"),
                            if (Prefs.callNotifSound.value.isBlank()) tr("صدای پیش‌فرض سیستم", "System default") else tr("صدای سفارشی", "Custom sound")) {
                            ring.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_RINGTONE)
                                .putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, tr("صدای اعلان تماس", "Call notification sound")))
                        }
                        if (Prefs.callNotifSound.value.isNotBlank()) SAction(tr("بازگشت به صدای پیش‌فرض", "Reset to system default")) { Prefs.callNotifSound.value = ""; refreshCallNotification() }
                    }
                    if (Build.VERSION.SDK_INT >= 26) SAction(tr("تنظیمات اعلان اندروید", "Android notification settings"), tr("اولویت و نمایش اعلان را در تنظیمات سیستم کنترل کنید", "Control notification importance and display in Android settings")) {
                        act.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName))
                    }
                }
            }
            "look" -> SPage(tr("ظاهر تماس", "Call appearance"), back) {
                val look = CallLooks.resolve()
                val refresh = { refreshCallNotification() }
                SGroup(tr("پیش‌نمایش زنده", "LIVE PREVIEW")) {
                    CallRingPreview(look)
                    NotifCardPreview(look)
                    SAction(tr("نمایش اعلان آزمایشی", "Send a test notification"), tr("یک تماس ورودی نمونه با همین ظاهر در اعلان‌ها نشان می‌دهد", "Shows a sample incoming call with this look")) {
                        CallHub.showPreview(act)
                    }
                }
                SGroup(tr("پوسته‌های آماده", "READY-MADE THEMES")) {
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        CallLooks.all.forEach { t ->
                            val sel = t.id == look.t.id
                            val tl = CallLooks.forTheme(t)
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CallBackground(tl, Modifier.size(width = 92.dp, height = 150.dp).clip(RoundedCornerShape(18.dp))
                                    .border(if (sel) 3.dp else 1.dp, if (sel) p.primary else p.line, RoundedCornerShape(18.dp))
                                    .clickable { CallLooks.applyTheme(t.id); refresh() }, showImage = false) {
                                    Column(Modifier.fillMaxSize().padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Spacer(Modifier.height(14.dp))
                                        Box(Modifier.size(34.dp).clip(CircleShape).background(Color.White.copy(alpha = .25f)).border(2.dp, t.accent, CircleShape))
                                        Spacer(Modifier.weight(1f))
                                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                            Box(Modifier.size(20.dp).clip(CircleShape).background(t.decline))
                                            Box(Modifier.size(20.dp).clip(CircleShape).background(t.answer))
                                        }
                                        Spacer(Modifier.height(6.dp))
                                    }
                                }
                                Text(tr(t.fa, t.en), color = if (sel) p.primary else p.text, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                            }
                        }
                    }
                }
                SGroup(tr("پس‌زمینه تماس", "CALL BACKGROUND")) {
                    val ctx = LocalContext.current
                    val scope = rememberCoroutineScope()
                    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
                        if (uri != null) scope.launch {
                            val name = withContext(Dispatchers.IO) { CallBgStore.importFromUri(ctx, uri) }
                            if (name != null) CallBgStore.set(ctx, "file:$name")
                            else Toast.makeText(ctx, tr("خواندن تصویر ممکن نشد", "Could not read the image"), Toast.LENGTH_SHORT).show()
                        }
                    }
                    val cur = Prefs.withProfile(true) { Prefs.callBgImage.value }
                    val thumbs = remember { CALL_BG_PRESETS.map { CallBgStore.load(ctx, "res:${it.id}", 4) } }
                    val galleryThumb = remember(cur) { if (cur.startsWith("file:")) CallBgStore.load(ctx, cur, 4) else null }
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        BgTile(tr("بدون تصویر", "None"), cur.isBlank(), null, false) { CallBgStore.set(ctx, "") }
                        CALL_BG_PRESETS.forEachIndexed { i, pr ->
                            BgTile(tr(pr.fa, pr.en), cur == "res:${pr.id}", thumbs[i], false) { CallBgStore.set(ctx, "res:${pr.id}") }
                        }
                        BgTile(tr("از گالری", "Gallery"), cur.startsWith("file:"), galleryThumb, true) { pick.launch("image/*") }
                    }
                    if (cur.isNotBlank()) Column(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
                        val dim = Prefs.withProfile(true) { Prefs.callBgDim.value }
                        Text(tr("تیرگی روی تصویر", "Image dimming") + "  ${(dim * 100).toInt()}%", color = p.text)
                        Slider(dim, { v -> Prefs.withProfile(true) { Prefs.callBgDim.value = v } }, valueRange = 0f..0.85f,
                            colors = SliderDefaults.colors(thumbColor = p.primary, activeTrackColor = p.primary, inactiveTrackColor = p.line))
                    }
                }
                SGroup(tr("چیدمان صفحه تماس", "INCOMING SCREEN")) {
                    SChoice(tr("نوع کنترل پاسخ/رد", "Answer / decline control"),
                        listOf("" to tr("پیش‌فرض پوسته", "Theme default"), "buttons" to tr("دو دکمه", "Two buttons"), "pill" to tr("کپسول", "Capsule"), "swipe" to tr("کشیدنی", "Swipe")),
                        Prefs.callLayout.value) { Prefs.callLayout.value = it }
                    SChoice(tr("قاب دور عکس", "Avatar ring"),
                        listOf("" to tr("پیش‌فرض پوسته", "Theme default"), "none" to tr("بدون قاب", "None"), "plain" to tr("ساده", "Plain"), "glow" to tr("درخشان", "Glow"), "gradient" to tr("رنگین‌کمانی", "Gradient"), "arc" to tr("کمانی", "Arc")),
                        Prefs.callAvatarRing.value) { Prefs.callAvatarRing.value = it }
                    ColorSliders(tr("رنگ بالای پس‌زمینه", "Background top color"), Prefs.callBgTop.value, look.t.top) { Prefs.callBgTop.value = it }
                    ColorSliders(tr("رنگ پایین پس‌زمینه", "Background bottom color"), Prefs.callBgBottom.value, look.t.bottom) { Prefs.callBgBottom.value = it }
                }
                SGroup(tr("دکمه‌های پاسخ و رد", "ANSWER & DECLINE BUTTONS")) {
                    SChoice(tr("شکل دکمه", "Button shape"),
                        listOf("" to tr("پیش‌فرض پوسته", "Theme default"), "circle" to tr("دایره", "Circle"), "rounded" to tr("گوشه‌گرد", "Rounded"), "pill" to tr("کپسولی", "Pill"), "square" to tr("چهارگوش", "Square")),
                        Prefs.callBtnShape.value) { Prefs.callBtnShape.value = it; refresh() }
                    SChoice(tr("سبک دکمه", "Button style"),
                        listOf("" to tr("پیش‌فرض پوسته", "Theme default"), "filled" to tr("توپر", "Filled"), "outline" to tr("خطی", "Outline"), "glow" to tr("درخشان", "Glow")),
                        Prefs.callBtnStyle.value) { Prefs.callBtnStyle.value = it; refresh() }
                    SChoice(tr("نوشته روی دکمه‌ها", "Button labels"),
                        listOf("" to tr("پیش‌فرض پوسته", "Theme default"), "on" to tr("نمایش", "Show"), "off" to tr("پنهان", "Hide")),
                        Prefs.callBtnLabels.value) { Prefs.callBtnLabels.value = it; refresh() }
                    Column(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
                        Text(tr("اندازه دکمه", "Button size") + "  ${(Prefs.callBtnScale.value * 100).toInt()}%", color = p.text)
                        Slider(Prefs.callBtnScale.value, { Prefs.callBtnScale.value = it; refresh() }, valueRange = 0.7f..1.4f,
                            colors = SliderDefaults.colors(thumbColor = p.primary, activeTrackColor = p.primary, inactiveTrackColor = p.line))
                    }
                    ColorSliders(tr("رنگ دکمه پاسخ", "Answer color"), Prefs.callAnswerColor.value, look.t.answer) { Prefs.callAnswerColor.value = it; refresh() }
                    ColorSliders(tr("رنگ دکمه رد تماس", "Decline color"), Prefs.callDeclineColor.value, look.t.decline) { Prefs.callDeclineColor.value = it; refresh() }
                    ColorSliders(tr("رنگ آیکون دکمه‌ها", "Button icon color"), Prefs.callBtnIconColor.value, Color.White) { Prefs.callBtnIconColor.value = it; refresh() }
                }
                SGroup(tr("نوشته‌ها", "TEXTS")) {
                    CallTextField(tr("نوشته دکمه پاسخ", "Answer text"), Prefs.callAnswerText.value, tr("پاسخ", "Answer")) { Prefs.callAnswerText.value = it; refresh() }
                    CallTextField(tr("نوشته دکمه رد", "Decline text"), Prefs.callDeclineText.value, tr("رد تماس", "Decline")) { Prefs.callDeclineText.value = it; refresh() }
                    CallTextField(tr("نوشته زیر نام (تماس ورودی)", "Incoming subtitle"), Prefs.callSubtitleText.value, tr("تماس ورودی…", "Incoming call…")) { Prefs.callSubtitleText.value = it; refresh() }
                }
                SGroup(tr("کارت اعلان تماس", "CALL NOTIFICATION CARD")) {
                    SChoice(tr("نوع اعلان تماس ورودی", "Incoming call notification type"),
                        listOf("auto" to tr("خودکار (روی قفل: سیستمی)", "Auto (system on lock screen)"), "system" to tr("همیشه سیستمی", "Always system"), "card" to tr("کارت سفارشی", "Themed card")),
                        Prefs.callNotifStyle.value) { Prefs.callNotifStyle.value = it; refresh() }
                    ColorSliders(tr("رنگ پس‌زمینه کارت", "Card background"), Prefs.callNotifBg.value, look.t.notifBg) { Prefs.callNotifBg.value = it; refresh() }
                    ColorSliders(tr("رنگ نوشته‌های کارت", "Card text color"), Prefs.callNotifText.value, look.t.notifText) { Prefs.callNotifText.value = it; refresh() }
                    ColorSliders(tr("رنگ نماد اعلان", "Notification accent color"), Prefs.callAccentColor.value, look.t.accent) { Prefs.callAccentColor.value = it; refresh() }
                }
                SGroup(tr("رنگ برنامه تماس", "PHONE APP COLOR")) {
                    ColorSliders(tr("رنگ اصلی برنامه", "App accent color"), Prefs.accentColor.value, Def.accent) { Prefs.accentColor.value = it }
                }
                SGroup {
                    SAction(tr("بازنشانی شخصی‌سازی‌ها", "Reset customizations"), tr("پوسته انتخابی می‌ماند و فقط تغییرات شما پاک می‌شود", "Keeps the selected theme, clears your overrides"), danger = true) {
                        CallLooks.resetOverrides(); Prefs.callAccentColor.value = 0; refresh()
                    }
                }
            }
            "about" -> SPage(tr("درباره", "About"), back) {
                SGroup { Column(Modifier.padding(18.dp)) {
                    Text("آبتین تماس · 1.5.8", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(tr("مدیریت تماس و مخاطبین", "Calls and contacts"), color = p.sub)
                } }
            }
            else -> SPage(tr("تنظیمات تماس", "Phone settings"), null) {
                SGroup {
                    SNav(Icons.Default.Tune, tr("عمومی", "General"), tr("زبان و اندازه متن", "Language and text size")) { Bus.page.value = "general" }
                    SNav(Icons.Default.Notifications, tr("اعلان تماس", "Call notifications"), tr("صدا، لرزش و فعال‌سازی اعلان", "Sound, vibration and notifications")) { Bus.page.value = "notif" }
                    SNav(Icons.Default.Palette, tr("ظاهر تماس", "Call appearance"), tr("پوسته، دکمه‌ها و رنگ اعلان تماس", "Themes, buttons and notification colors")) { Bus.page.value = "look" }
                    SNav(Icons.Default.Info, tr("درباره", "About"), "1.5.8") { Bus.page.value = "about" }
                }
            }
        }
        return
    }

    when (page) {
        "general" -> SPage(tr("عمومی", "General"), back) {
            SGroup {
                SSwitch(tr("برنامه پیش‌فرض پیامک", "Default SMS app"), if (isDef) tr("آبتین SMS پیش‌فرض است ✓", "Abtin SMS is the default ✓") else tr("برای ارسال و دریافت لازم است", "Required to send & receive"), isDef) { if (!isDef) askDefault() }
            }
            SGroup(tr("ارسال و دریافت", "SEND & RECEIVE")) {
                SSwitch(tr("گزارش تحویل", "SMS delivery reports"), tr("نمایش ✓ ارسال و ✓✓ تحویل", "Show ✓ sent and ✓✓ delivered"), Prefs.deliveryReports.value) { Prefs.deliveryReports.value = it }
                SSwitch(tr("ارسال با دکمه Enter", "Enter key sends"), null, Prefs.enterSends.value) { Prefs.enterSends.value = it }
                SSwitch(tr("صدای ارسال پیام", "Outgoing message sounds"), null, Prefs.sendSound.value) { Prefs.sendSound.value = it }
                SSwitch(tr("پیام گروهی به‌صورت MMS", "Group messaging (MMS)"), tr("خاموش = ارسال جداگانه به هر نفر", "Off = send separately to each person"), Prefs.groupMms.value) { Prefs.groupMms.value = it }
                val simList = remember { repo.sims() }
                if (simList.size > 1) SChoice(tr("سیم‌کارت پیش‌فرض ارسال", "Default SIM for SMS"), listOf("-1" to tr("پیش‌فرض سیستم", "System default")) + simList.map { it.subId.toString() to "SIM ${it.slot} · ${it.name}" }, Prefs.sim.value.toString()) { Prefs.sim.value = it.toIntOrNull() ?: -1 }
            }
            SGroup(tr("نمایش", "DISPLAY")) {
                SSwitch(tr("نمایش آواتار مخاطب", "Show contact avatars"), null, Prefs.showAvatars.value) { Prefs.showAvatars.value = it }
                SSwitch(tr("ارقام فارسی در فهرست", "Persian digits in list"), null, Prefs.persianDigits.value) { Prefs.persianDigits.value = it }
                SChoice(tr("زبان", "Language"), listOf("system" to tr("سیستم", "System"), "fa" to "فارسی", "en" to "English"), Prefs.language.value) { Prefs.language.value = it }
            }
        }
        "notif" -> SPage(tr("اعلان‌ها", "Notifications"), back) {
            SGroup {
                SSwitch(tr("اعلان پیام‌ها", "Message notifications"), null, Prefs.notifications.value) { Prefs.notifications.value = it }
                SSwitch(tr("نمایش متن پیام در اعلان", "Show message preview"), tr("برای حریم خصوصی خاموش کنید", "Turn off for privacy"), Prefs.showPreview.value) { Prefs.showPreview.value = it }
                SSwitch(tr("نمایش محتوا در صفحه قفل", "Show content on lock screen"), null, Prefs.lockPreview.value) { Prefs.lockPreview.value = it }
                SSwitch(tr("لرزش", "Vibrate"), null, Prefs.vibrate.value) { Prefs.vibrate.value = it }
            }
            SGroup(tr("پیش‌نمایش اعلان", "NOTIFICATION PREVIEW")) {
                MessageNotificationPreview()
                SAction(tr("نمایش اعلان آزمایشی", "Show test notification"), tr("اعلان واقعی با همین ظاهر در نوار اعلان گوشی نمایش داده می‌شود", "Posts a real notification in the phone's notification shade")) {
                    Notifier.showPreview(act)
                }
            }
            SGroup(tr("صدا", "SOUND")) {
                SAction(tr("صدای اعلان", "Notification sound"), if (Prefs.notifSound.value.isEmpty()) tr("پیش‌فرض", "Default") else tr("سفارشی", "Custom")) {
                    ring.launch(Intent(RingtoneManager.ACTION_RINGTONE_PICKER).putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION))
                }
                if (Prefs.notifSound.value.isNotEmpty()) SAction(tr("بازگشت به صدای پیش‌فرض", "Reset to default sound")) { Prefs.notifSound.value = "" }
                if (Build.VERSION.SDK_INT >= 26) SAction(tr("تنظیمات اعلان سیستم", "System notification settings"), tr("اولویت، پاپ‌آپ و ...", "Importance, pop-up, …")) {
                    act.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, act.packageName))
                }
            }
        }
        "suggest" -> SPage(tr("پیشنهادها در گفتگو", "Suggestions in chat"), back) {
            SGroup {
                SSwitch(tr("پاسخ‌های سریع", "Quick replies"), tr("نمایش چیپ‌های پاسخ بالای کادر پیام", "Show reply chips above the composer"), Prefs.showQuickReplies.value) { Prefs.showQuickReplies.value = it }
                SSwitch(tr("لینک‌ها و شماره‌های قابل لمس", "Suggested actions (links & numbers)"), tr("باز کردن لینک و شماره‌گیری با لمس", "Tap to open links and dial numbers"), Prefs.smartLinks.value) { Prefs.smartLinks.value = it }
                SSwitch(tr("دکمه کپی کد تأیید", "Copy verification codes"), tr("روی پیام‌های دارای کد یکبارمصرف", "Chip on one-time-code messages"), Prefs.codeChip.value) { Prefs.codeChip.value = it }
            }
            SGroup(tr("قالب‌های پاسخ سریع", "QUICK REPLY TEMPLATES")) {
                OutlinedTextField(Prefs.templates.value, { Prefs.templates.value = it }, minLines = 2, placeholder = { Text(tr("هر خط یک قالب (خالی = پیش‌فرض)", "One per line (empty = defaults)")) },
                    modifier = Modifier.fillMaxWidth().padding(14.dp))
            }
        }
        "spam" -> SPage(tr("اسپم و مسدود", "Spam & blocked"), back) {
            SGroup {
                SSwitch(tr("محافظت در برابر اسپم", "Spam protection"), tr("اسپم بی‌صدا به دستهٔ «اسپم» می‌رود", "Spam goes silently to the Spam category"), Prefs.spamFilter.value) { Prefs.spamFilter.value = it }
                OutlinedTextField(Prefs.spamWords.value, { Prefs.spamWords.value = it }, minLines = 2, placeholder = { Text(tr("کلمات اسپم دلخواه (هر خط یک کلمه)", "Custom spam words (one per line)")) },
                    modifier = Modifier.fillMaxWidth().padding(14.dp))
            }
            val blocked = csv(Prefs.blocked).toList(); val spam = csv(Prefs.spam).toList()
            SGroup(tr("شماره‌های مسدود", "BLOCKED NUMBERS")) {
                if (blocked.isEmpty()) Text(tr("موردی نیست", "None"), color = p.sub, modifier = Modifier.padding(18.dp))
                blocked.forEach { n -> SAction(n, tr("لمس برای رفع مسدودی", "Tap to unblock")) { removeFrom(Prefs.blocked, n) } }
            }
            SGroup(tr("شماره‌های اسپم", "SPAM NUMBERS")) {
                if (spam.isEmpty()) Text(tr("موردی نیست", "None"), color = p.sub, modifier = Modifier.padding(18.dp))
                spam.forEach { n -> SAction(n, tr("لمس برای «اسپم نیست»", "Tap for “Not spam”")) { markSpam(n, false) } }
            }
        }
        "look" -> SPage(tr("ظاهر", "Appearance"), back) {
            SGroup(tr("پیش‌نمایش", "PREVIEW")) {
                Column(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(p.bg, p.bg2))).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    val tw = if (Prefs.bubbleShape.value == "tail") TAIL_DP.dp else 0.dp
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                        Text(tr("سلام عزیزم! امروز وقت داری؟", "Hi! Are you free today?"), color = p.text, fontSize = 16.sp,
                            modifier = Modifier.background(SolidColor(p.inBubble), BubbleShape(false, Prefs.bubbleShape.value)).padding(start = 12.dp + tw, end = 12.dp, top = 8.dp, bottom = 8.dp))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Text(tr("بله حتماً", "Sure"), color = p.text, fontSize = 16.sp,
                            modifier = Modifier.background(Brush.linearGradient(listOf(p.out1, p.out2)), BubbleShape(true, Prefs.bubbleShape.value)).padding(start = 12.dp, end = 12.dp + tw, top = 8.dp, bottom = 8.dp))
                    }
                }
                BubbleShapePicker(Prefs.bubbleShape.value) { Prefs.bubbleShape.value = it }
            }
            SGroup(tr("رنگ‌ها", "COLORS")) {
                ColorSliders(tr("رنگ اصلی (دکمه‌ها و تأکید)", "Accent color"), Prefs.accentColor.value, Def.accent) { Prefs.accentColor.value = it }
                HorizontalDivider(color = p.line)
                ColorSliders(tr("رنگ پس‌زمینه", "Background"), Prefs.chatBackground.value, Def.bg) { Prefs.chatBackground.value = it }
                HorizontalDivider(color = p.line)
                ColorSliders(tr("حباب دریافتی", "Incoming bubble"), Prefs.incomingBubble.value, Def.inBubble) { Prefs.incomingBubble.value = it }
                HorizontalDivider(color = p.line)
                ColorSliders(tr("حباب ارسالی", "Outgoing bubble"), Prefs.outgoingBubble.value, Def.out) { Prefs.outgoingBubble.value = it }
                HorizontalDivider(color = p.line)
                SAction(tr("بازنشانی همه رنگ‌ها", "Reset all colors"), danger = true) { Prefs.accentColor.value = 0; Prefs.chatBackground.value = 0; Prefs.incomingBubble.value = 0; Prefs.outgoingBubble.value = 0; Prefs.bubbleShape.value = "tail" }
            }
            SGroup(tr("متن", "TEXT")) {
                Column(Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
                    Text(tr("اندازه متن", "Text size") + "  ${(Prefs.fontScale.value * 100).toInt()}%", color = p.text)
                    Slider(Prefs.fontScale.value, { Prefs.fontScale.value = it }, valueRange = 0.8f..1.4f, steps = 5, colors = SliderDefaults.colors(thumbColor = p.primary, activeTrackColor = p.primary, inactiveTrackColor = p.line))
                }
            }
        }
        "swipe" -> SPage(tr("اکشن‌های کشیدن", "Swipe actions"), back) {
            val opts = listOf("delete" to tr("حذف", "Delete"), "archive" to tr("بایگانی", "Archive"), "read" to tr("خوانده/نخوانده", "Read / unread"), "none" to tr("هیچ", "None"))
            SGroup {
                SChoice(tr("کشیدن به چپ", "Swipe left"), opts, Prefs.swipeLeft.value) { Prefs.swipeLeft.value = it }
                SChoice(tr("کشیدن به راست", "Swipe right"), opts, Prefs.swipeRight.value) { Prefs.swipeRight.value = it }
                SSwitch(tr("نمایش راهنمای کشیدن در فهرست", "Show swipe hint in list"), null, !Prefs.swipeHintDone.value) { Prefs.swipeHintDone.value = !it }
            }
            Text(tr("با کشیدن نصفه، دکمه نمایش داده می‌شود؛ با ادامه کشیدن، عمل انجام می‌شود.", "A short swipe reveals the button; keep swiping to run the action."), color = p.sub, fontSize = 13.sp, modifier = Modifier.padding(28.dp, 10.dp))
        }
        "adv" -> SPage(tr("پیشرفته", "Advanced"), back) {
            SGroup(tr("MMS", "MMS")) {
                SSwitch(tr("دانلود خودکار MMS", "Auto-download MMS"), tr("خاموش = اعلان برای دانلود دستی", "Off = notification to download manually"), Prefs.autoDownloadMms.value) { Prefs.autoDownloadMms.value = it }
                SSwitch(tr("دانلود خودکار در رومینگ", "Auto-download MMS when roaming"), null, Prefs.autoDownloadRoaming.value) { Prefs.autoDownloadRoaming.value = it }
            }
            SGroup(tr("پیام‌ها", "MESSAGES")) {
                SSwitch(tr("استفاده از نویسه‌های ساده", "Use simple characters"), tr("علائم نگارشی و حروف لاتین تزئینی به ASCII تبدیل می‌شوند", "Convert smart punctuation and accents in outgoing SMS"), Prefs.simpleChars.value) { Prefs.simpleChars.value = it }
                SSwitch(tr("حذف خودکار کدهای تأیید بعد از ۲۴ ساعت", "Auto-delete OTPs after 24 hours"), null, Prefs.autoDeleteOtp.value) { Prefs.autoDeleteOtp.value = it }
            }
            SGroup(tr("داده‌ها", "DATA")) {
                SAction(tr("علامت‌گذاری همه به‌عنوان خوانده‌شده", "Mark all as read")) { scope.launch(Dispatchers.IO) { runCatching { repo.markAllRead() } } }
                SAction(tr("پشتیبان‌گیری از پیامک‌ها", "Back up messages")) { exp.launch("abtin-sms-backup.json") }
                SAction(tr("بازیابی از فایل پشتیبان", "Restore from backup")) { imp.launch(arrayOf("application/json", "*/*")) }
                SAction(tr("پاک‌کردن لیست پیام‌های ستاره‌دار", "Clear starred list"), danger = true) { Prefs.starred.value = "" }
            }
        }
        "privacy" -> SPage(tr("حریم خصوصی و امنیت", "Privacy & security"), back) {
            var pinIn by remember { mutableStateOf("") }
            SGroup(tr("قفل برنامه با پین", "APP LOCK")) {
                OutlinedTextField(pinIn, { pinIn = it.filter { ch -> ch.isDigit() }.take(8) }, singleLine = true, label = { Text(tr("پین جدید (۴ تا ۸ رقم)", "New PIN (4-8 digits)")) },
                    modifier = Modifier.fillMaxWidth().padding(14.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                Row(Modifier.padding(horizontal = 14.dp).padding(bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button({ if (pinIn.length >= 4) { Prefs.pin.value = pinIn; pinIn = "" } }, colors = ButtonDefaults.buttonColors(containerColor = p.primary, contentColor = Color.White)) { Text(tr("تنظیم پین", "Set PIN")) }
                    if (Prefs.pin.value.isNotEmpty()) TextButton({ Prefs.pin.value = "" }) { Text(tr("حذف پین", "Remove PIN"), color = p.danger) }
                }
            }
        }
        "about" -> SPage(tr("درباره", "About"), back) {
            SGroup {
                Column(Modifier.padding(18.dp)) {
                    Text("آبتین SMS · 1.5.8", color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(tr("برنامه پیش‌فرض SMS/MMS", "Default SMS/MMS app"), color = p.sub)
                }
            }
        }
        else -> SPage(tr("تنظیمات", "Settings"), null) {
            SGroup {
                SSwitch(tr("برنامه پیش‌فرض پیامک", "Default SMS app"), if (isDef) tr("آبتین SMS پیش‌فرض است ✓", "Abtin SMS is the default ✓") else tr("آبتین SMS پیش‌فرض نیست", "Abtin SMS is not the default"), isDef) { if (!isDef) askDefault() }
            }
            SGroup {
                SNav(Icons.Default.Tune, tr("عمومی", "General"), tr("ارسال، سیم‌کارت، زبان", "Send, SIM, language")) { Bus.page.value = "general" }
                SNav(Icons.Default.Notifications, tr("اعلان‌ها", "Notifications"), tr("صدا، پیش‌نمایش، صفحه قفل", "Sound, preview, lock screen")) { Bus.page.value = "notif" }
                SNav(Icons.Default.Lightbulb, tr("پیشنهادها در گفتگو", "Suggestions in chat"), tr("پاسخ سریع، لینک، کد تأیید", "Quick replies, links, codes")) { Bus.page.value = "suggest" }
                SNav(Icons.Default.Report, tr("اسپم و مسدود", "Spam & blocked"), tr("فیلتر و شماره‌های مسدود", "Filter and blocked numbers")) { Bus.page.value = "spam" }
                SNav(Icons.Default.Palette, tr("ظاهر", "Appearance"), tr("رنگ‌ها، شکل حباب، اندازه متن", "Colors, bubble shape, text size")) { Bus.page.value = "look" }
                SNav(Icons.Default.TouchApp, tr("اکشن‌های کشیدن", "Swipe actions"), tr("حذف، بایگانی، خوانده", "Delete, archive, read")) { Bus.page.value = "swipe" }
                SNav(Icons.Default.Sms, tr("پیشرفته", "Advanced"), tr("MMS، نویسه‌ها، پشتیبان‌گیری", "MMS, characters, backup")) { Bus.page.value = "adv" }
                SNav(Icons.Default.Lock, tr("حریم خصوصی و امنیت", "Privacy & security"), tr("قفل با پین", "PIN lock")) { Bus.page.value = "privacy" }
                SNav(Icons.Default.Info, tr("درباره", "About"), "1.2.0") { Bus.page.value = "about" }
            }
        }
    }
}


// ---------- call appearance helpers ----------
@Composable
private fun CallTextField(title: String, value: String, hint: String, onChange: (String) -> Unit) {
    val p = LocalPal.current
    OutlinedTextField(
        value = value, onValueChange = onChange, singleLine = true,
        label = { Text(title) }, placeholder = { Text(hint) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = p.text, unfocusedTextColor = p.text,
            focusedBorderColor = p.primary, unfocusedBorderColor = p.line,
            focusedLabelColor = p.primary, unfocusedLabelColor = p.sub, cursorColor = p.primary),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp))
}

@Composable
private fun CallRingPreview(look: CallLook) {
    CallBackground(look, Modifier.fillMaxWidth().height(380.dp).padding(14.dp).clip(RoundedCornerShape(24.dp))) {
        Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(4.dp))
            CallAvatar(null, "", tr("سارا احمدی", "Sara Ahmadi"), look, 76.dp)
            Text(tr("سارا احمدی", "Sara Ahmadi"), color = look.t.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(look.subtitle, color = look.t.sub, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
            Spacer(Modifier.weight(1f))
            RingControls(look, {}, {})
            Spacer(Modifier.height(6.dp))
        }
    }
}

@Composable
private fun NotifCardPreview(look: CallLook) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp).clip(RoundedCornerShape(18.dp)).background(look.notifBg).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(look.answer), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Call, null, tint = look.icon, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(tr("سارا احمدی", "Sara Ahmadi"), color = look.notifText, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(look.subtitle, color = look.notifText.copy(alpha = .72f), fontSize = 12.sp, maxLines = 1)
        }
        CallActionButton(false, look, {}, noLabel = !(look.shape == "pill" && look.labels), sizeOverride = 38.dp * look.scale.coerceIn(0.85f, 1.15f))
        Spacer(Modifier.width(6.dp))
        CallActionButton(true, look, {}, noLabel = !(look.shape == "pill" && look.labels), sizeOverride = 38.dp * look.scale.coerceIn(0.85f, 1.15f))
    }
}


@Composable
private fun BgTile(label: String, selected: Boolean, bmp: ImageBitmap?, gallery: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(width = 78.dp, height = 128.dp).clip(RoundedCornerShape(16.dp)).background(p.surface)
            .border(if (selected) 3.dp else 1.dp, if (selected) p.primary else p.line, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick), contentAlignment = Alignment.Center) {
            if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            if (gallery) Icon(Icons.Default.AddPhotoAlternate, null, tint = if (bmp != null) Color.White else p.text, modifier = Modifier.size(28.dp))
            else if (bmp == null) Icon(Icons.Default.Close, null, tint = p.sub, modifier = Modifier.size(26.dp))
        }
        Text(label, color = if (selected) p.primary else p.text, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}


@Composable
private fun MessageNotificationPreview() {
    val p = LocalPal.current
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)
            .clip(shape).background(Color(0xFF202632))
            .border(1.dp, Color.White.copy(alpha = .12f), shape)
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(p.primary, Color(0xFF8B5CF6)))),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.ChatBubble, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(tr("آبتین پیام", "Abtin SMS"), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text(tr("همین حالا", "Now"), color = Color.White.copy(alpha = .62f), fontSize = 11.sp)
            }
            Icon(Icons.Default.MoreHoriz, null, tint = Color.White.copy(alpha = .68f), modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.height(10.dp))
        Text(tr("سارا احمدی", "Sara Ahmadi"), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(
            tr("سلام! پیش‌نمایش تازهٔ آبتین چطوره؟", "Hi! How do you like Abtin's refreshed look?"),
            color = Color.White.copy(alpha = .88f), fontSize = 14.sp, lineHeight = 20.sp,
            modifier = Modifier.padding(top = 3.dp)
        )
        Row(Modifier.fillMaxWidth().padding(top = 13.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
            Text(tr("پاسخ", "Reply"), color = p.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(22.dp))
            Text(tr("خوانده شد", "Mark read"), color = p.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
    }
}
