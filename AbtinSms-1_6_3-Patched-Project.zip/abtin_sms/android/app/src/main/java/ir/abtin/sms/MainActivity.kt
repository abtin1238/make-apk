package ir.abtin.sms

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.database.ContentObserver
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

sealed class Screen {
    object Home : Screen()
    object Dash : Screen()
    object Scheduled : Screen()
    object Sent : Screen()
    object Groups : Screen()
    object Stats : Screen()
    data class Send(val mode: Int = 0, val to: String = "", val text: String = "") : Screen()
    object New : Screen()
    object Settings : Screen()
    object Contacts : Screen()
    object Calls : Screen()
    data class ContactDetail(val id: Long) : Screen()
    data class ContactForm(val id: Long = 0, val name: String = "", val number: String = "") : Screen()
    data class Chat(val threadId: Long, val address: String, val draft: String? = null) : Screen()
}

object Bus { val fav = mutableStateOf(false); val tick = mutableIntStateOf(0); val locked = mutableStateOf(false); val page = mutableStateOf(""); val dial = mutableStateOf("")
    /** Phone app: 0 = recents, 1 = recordings; pad = dial pad open */
    val callTab = mutableIntStateOf(0); val pad = mutableStateOf(false) }

open class MainActivity : ComponentActivity() {
    protected val nav = mutableStateOf<Screen>(Screen.Home)
    /** true = the "Abtin Phone" launcher (calls + contacts); false = the "Abtin SMS" launcher */
    open fun isPhone() = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT), navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        Prefs.init(this)
        Prefs.useProfile(isPhone())
        if (!isPhone()) Scheduler.rearmAll(this)
        Bus.locked.value = Prefs.pin.value.isNotEmpty()
        nav.value = if (isPhone()) Screen.Contacts else Screen.Dash
        handle(intent)
        setContent { Root(nav, this, isPhone()) }
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }
    override fun onResume() { super.onResume(); Prefs.useProfile(isPhone()); Notifier.foreground = true; Bus.tick.intValue++ }
    override fun onStop() { super.onStop(); if (Prefs.pin.value.isNotEmpty()) Bus.locked.value = true }
    override fun onPause() { super.onPause(); Notifier.foreground = false }

    private fun handle(i: Intent?) {
        i ?: return
        val a = i.getStringExtra("address")
        val sch = i.data?.scheme
        val type = i.type ?: ""
        when {
            i.getStringExtra("send_to") != null && !isPhone() -> nav.value = Screen.Send(2, i.getStringExtra("send_to") ?: "")
            a != null -> if (isPhone()) startActivity(Intent(this, MainActivity::class.java).putExtras(i).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) else nav.value = Screen.Chat(i.getLongExtra("thread", 0), a)
            i.action == Intent.ACTION_DIAL || (i.action == Intent.ACTION_VIEW && sch == "tel") -> {
                Bus.dial.value = i.data?.schemeSpecificPart?.takeIf { sch == "tel" } ?: ""
                Bus.pad.value = true
                nav.value = Screen.Calls
            }
            i.action == Intent.ACTION_INSERT || i.action == Intent.ACTION_INSERT_OR_EDIT -> {
                nav.value = Screen.ContactForm(0, i.getStringExtra(android.provider.ContactsContract.Intents.Insert.NAME) ?: "", i.getStringExtra(android.provider.ContactsContract.Intents.Insert.PHONE) ?: "")
            }
            (i.action == Intent.ACTION_VIEW || i.action == Intent.ACTION_EDIT) && type.startsWith("vnd.android.cursor.item/contact") ->
                runCatching { SmsRepo(this).contactFromUri(i.data!!) }.getOrNull()?.let { nav.value = Screen.ContactDetail(it.id) }
            i.action == Intent.ACTION_SENDTO || i.action == Intent.ACTION_VIEW ->
                i.data?.schemeSpecificPart?.substringBefore('?')?.takeIf { it.isNotBlank() }
                    ?.let { nav.value = Screen.Chat(0, it.replace(';', ','), i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT)) }
        }
    }
}

fun isDefaultSms(a: ComponentActivity) = Telephony.Sms.getDefaultSmsPackage(a) == a.packageName

@Composable
fun Root(nav: MutableState<Screen>, act: ComponentActivity, phone: Boolean = false) {
    val repo = remember { SmsRepo(act) }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { Bus.tick.intValue++ }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { Bus.tick.intValue++ }
    val askDefault = {
        val i = if (phone) null else if (Build.VERSION.SDK_INT >= 29) {
            val rm = act.getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_SMS)) rm.createRequestRoleIntent(RoleManager.ROLE_SMS) else null
        } else Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, act.packageName)
        i?.let { roleLauncher.launch(it) }; Unit
    }
    LaunchedEffect(Unit) {
        val p = mutableListOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.RECEIVE_MMS, Manifest.permission.RECEIVE_WAP_PUSH, Manifest.permission.READ_PHONE_NUMBERS,
            Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALL_LOG, Manifest.permission.WRITE_CALL_LOG, Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_CONTACTS, Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        permLauncher.launch(p.toTypedArray())
    }
    DisposableEffect(Unit) {
        val o = object : ContentObserver(Handler(Looper.getMainLooper())) { override fun onChange(b: Boolean) { Bus.tick.intValue++ } }
        var smsObserving = false
        var mmsObserving = false
        fun startObserving() {
            if (!smsObserving) runCatching { act.contentResolver.registerContentObserver(Telephony.Sms.CONTENT_URI, true, o) }
                .onSuccess { smsObserving = true }
            if (!mmsObserving) runCatching { act.contentResolver.registerContentObserver(Telephony.Mms.CONTENT_URI, true, o) }
                .onSuccess { mmsObserving = true }
        }
        fun stopObserving() {
            if (smsObserving || mmsObserving) runCatching { act.contentResolver.unregisterContentObserver(o) }
            smsObserving = false
            mmsObserving = false
        }
        val lifecycleObserver = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> startObserving()
                Lifecycle.Event.ON_PAUSE -> stopObserving()
                else -> Unit
            }
        }
        act.lifecycle.addObserver(lifecycleObserver)
        if (act.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) startObserving()
        onDispose {
            stopObserving()
            act.lifecycle.removeObserver(lifecycleObserver)
        }
    }
    val start: Screen = if (phone) Screen.Contacts else Screen.Dash
    BackHandler(nav.value != start && !(phone && nav.value is Screen.Home)) {
        val c = nav.value
        if (c is Screen.Settings && Bus.page.value != "") Bus.page.value = ""
        else if (c is Screen.ContactForm && c.id != 0L) nav.value = Screen.ContactDetail(c.id)
        else if (c is Screen.ContactDetail || c is Screen.ContactForm || c is Screen.Groups) nav.value = Screen.Contacts
        else nav.value = start
    }

    AbtinTheme {
        CompositionLocalProvider(
            // Keep the physical position of controls identical in Persian and
            // English. Text fields that contain a phone number still opt into LTR
            // explicitly, while Persian copy remains readable as content text.
            LocalLayoutDirection provides LayoutDirection.Ltr,
            LocalDensity provides Density(LocalDensity.current.density, Prefs.fontScale.value)
        ) {
            Backdrop {
                if (Bus.locked.value) LockScreen() else {
                    val s = nav.value.let { if (phone && (it is Screen.Home || it is Screen.Dash)) Screen.Contacts else it }
                    val showNav = s is Screen.Home || s is Screen.Contacts || s is Screen.Calls || (s is Screen.Settings && Bus.page.value == "")
                    Column(Modifier.fillMaxSize()) {
                        val railOn = (s is Screen.ContactDetail || s is Screen.ContactForm || s is Screen.Groups || (phone && s is Screen.Calls && !Bus.pad.value))
                        Row(Modifier.weight(1f).fillMaxWidth()) {
                        Box(Modifier.weight(1f).fillMaxHeight()) {
                            when (s) {
                                is Screen.Home -> HomeScreen(repo, act, nav, askDefault)
                                is Screen.Dash -> SmsDashboard(repo, act, nav, askDefault)
                                is Screen.Send -> key(s.to, s.mode) { SendScreen(repo, act, nav, s) }
                                is Screen.Scheduled -> ScheduledScreen(repo, act, nav)
                                is Screen.Sent -> SentScreen(repo, nav)
                                is Screen.Groups -> GroupsScreen(repo, act, nav)
                                is Screen.Stats -> StatsScreen(repo, act, nav)
                                is Screen.Chat -> key(s.threadId, s.address) { ChatScreen(repo, act, s, nav, askDefault) }
                                is Screen.New -> NewScreen(repo, nav)
                                is Screen.Contacts -> ContactsScreen(repo, nav, phone)
                                is Screen.Calls -> CallsScreen(repo, act, nav)
                                is Screen.ContactForm -> ContactFormScreen(repo, act, s, nav)
                                is Screen.ContactDetail -> ContactDetailScreen(repo, act, s, nav)
                                is Screen.Settings -> SettingsScreen(repo, act, nav, askDefault)
                            }
                        }
                        if (railOn) Box(Modifier.fillMaxHeight().statusBarsPadding().padding(end = 8.dp, top = 12.dp), contentAlignment = Alignment.TopCenter) { ContactsRail(nav, phone) }
                        }
                        if (showNav) BottomNav(nav, phone)
                    }
                }
            }
            // First run (default phone app only): guided setup of the accesses the call screen needs.
            val telecomDef = Bus.tick.intValue.let { act.getSystemService(android.telecom.TelecomManager::class.java)?.defaultDialerPackage == act.packageName }
            if (phone && telecomDef && !Bus.locked.value && !Prefs.withProfile(true) { Prefs.callSetupDone.value }) CallAccessSetup(act) { }
        }
    }
}

/** Second launcher entry ("Abtin Phone"): opens Calls/Contacts, has its own task and icon. */
class PhoneActivity : MainActivity() {
    override fun isPhone() = true
}
