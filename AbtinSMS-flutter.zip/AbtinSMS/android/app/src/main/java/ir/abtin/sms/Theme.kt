package ir.abtin.sms

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

data class Pal(
    val dark: Boolean, val ios: Boolean, val bg: Color, val bg2: Color, val surface: Color,
    val primary: Color, val onPrimary: Color, val inBubble: Color, val inText: Color,
    val out1: Color, val out2: Color, val outText: Color, val text: Color, val sub: Color, val line: Color
)

private fun c(v: Long) = Color(v)

fun pal(f: String, dark: Boolean): Pal = when (f) {
    "gold" -> if (dark) Pal(true, false, c(0xFF0B0A12), c(0xFF1A1530), c(0xFF1D1B28), c(0xFFFFD60A), Color.Black, c(0xFF272535), Color.White, c(0xFFFFD60A), c(0xFFFFB800), Color.Black, Color.White, c(0xFFA8A5B8), c(0x33FFFFFF))
    else Pal(false, false, c(0xFFFFFBEC), c(0xFFFFF1C2), Color.White, c(0xFFE5A800), Color.Black, c(0xFFF1ECDD), c(0xFF1B1A22), c(0xFFFFD60A), c(0xFFFFB800), Color.Black, c(0xFF1B1A22), c(0xFF7C7868), c(0x1A000000))
    "ios" -> if (dark) Pal(true, true, Color.Black, Color.Black, c(0xFF1C1C1E), c(0xFF0A84FF), Color.White, c(0xFF26262A), Color.White, c(0xFF0A84FF), c(0xFF0A84FF), Color.White, Color.White, c(0xFF8E8E93), c(0xFF38383A))
    else Pal(false, true, Color.White, Color.White, c(0xFFF2F2F7), c(0xFF007AFF), Color.White, c(0xFFE9E9EB), Color.Black, c(0xFF0B84FE), c(0xFF0B84FE), Color.White, Color.Black, c(0xFF8E8E93), c(0xFFD1D1D6))
    "ocean" -> if (dark) Pal(true, false, c(0xFF04141A), c(0xFF062A33), c(0xFF0C2229), c(0xFF18D6C4), Color.Black, c(0xFF123741), Color.White, c(0xFF18D6C4), c(0xFF1E9BFF), Color.Black, Color.White, c(0xFF8FB5BC), c(0x33FFFFFF))
    else Pal(false, false, c(0xFFEAFBF9), c(0xFFD5F3F7), Color.White, c(0xFF00A99D), Color.White, c(0xFFD6EEF0), c(0xFF0B2A30), c(0xFF18C7B6), c(0xFF1E9BFF), Color.White, c(0xFF0B2A30), c(0xFF5E8A91), c(0x1A000000))
    else -> if (dark) Pal(true, false, c(0xFF070B1F), c(0xFF160C3D), c(0xFF141C40), c(0xFF4D8DFF), Color.White, c(0xFF1C2550), Color.White, c(0xFF2F6BFF), c(0xFF8A3DFF), Color.White, Color.White, c(0xFF9AA6D6), c(0x33FFFFFF))
    else Pal(false, false, c(0xFFF3F6FF), c(0xFFE8E4FF), Color.White, c(0xFF3D5AFE), Color.White, c(0xFFE2E7FF), c(0xFF111633), c(0xFF3D7BFF), c(0xFF7B5CFF), Color.White, c(0xFF0F1330), c(0xFF6B7299), c(0x1A000000))
}

val LocalPal = compositionLocalOf { pal("neon", true) }

@Composable
fun AbtinTheme(content: @Composable () -> Unit) {
    val sys = isSystemInDarkTheme()
    val dark = when (Prefs.mode.value) { "light" -> false; "dark" -> true; else -> sys }
    val ctx = LocalContext.current
    val f = Prefs.family.value
    val dyn = f == "material" && Build.VERSION.SDK_INT >= 31
    val cs = if (dyn) (if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)) else null
    var p = if (cs != null) Pal(dark, false, cs.background, cs.surfaceVariant, cs.surface, cs.primary, cs.onPrimary,
        cs.surfaceVariant, cs.onSurfaceVariant, cs.primary, cs.tertiary, cs.onPrimary, cs.onBackground, cs.onSurfaceVariant, cs.outlineVariant)
    else pal(if (f == "material") "neon" else f, dark)
    if (dark && Prefs.amoled.value) p = p.copy(bg = Color.Black, bg2 = Color.Black)
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window ?: return@SideEffect
        val ic = WindowCompat.getInsetsController(w, view)
        ic.isAppearanceLightStatusBars = !dark; ic.isAppearanceLightNavigationBars = !dark
    }
    val scheme = cs ?: if (dark) darkColorScheme(primary = p.primary, onPrimary = p.onPrimary, background = p.bg, surface = p.surface,
        onSurface = p.text, onBackground = p.text, surfaceVariant = p.surface, onSurfaceVariant = p.sub)
    else lightColorScheme(primary = p.primary, onPrimary = p.onPrimary, background = p.bg, surface = p.surface,
        onSurface = p.text, onBackground = p.text, surfaceVariant = p.surface, onSurfaceVariant = p.sub)
    CompositionLocalProvider(LocalPal provides p) { MaterialTheme(colorScheme = scheme, content = content) }
}
