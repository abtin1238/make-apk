package ir.abtin.sms

import android.Manifest
import android.app.role.RoleManager
import android.content.Intent
import android.database.ContentObserver
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Telephony
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection

sealed class Screen {
    object Home : Screen()
    object New : Screen()
    object Settings : Screen()
    data class Chat(val threadId: Long, val address: String, val draft: String? = null) : Screen()
}

object Bus { val tick = mutableIntStateOf(0); val locked = mutableStateOf(false) }

class MainActivity : ComponentActivity() {
    private val nav = mutableStateOf<Screen>(Screen.Home)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        enableEdgeToEdge()
        Prefs.init(this)
        Bus.locked.value = Prefs.pin.value.isNotEmpty()
        handle(intent)
        setContent { Root(nav, this) }
    }
    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }
    override fun onResume() { super.onResume(); Notifier.foreground = true; Bus.tick.intValue++ }
    override fun onStop() { super.onStop(); if (Prefs.pin.value.isNotEmpty()) Bus.locked.value = true }
    override fun onPause() { super.onPause(); Notifier.foreground = false }

    private fun handle(i: Intent?) {
        i ?: return
        val a = i.getStringExtra("address")
        if (a != null) nav.value = Screen.Chat(i.getLongExtra("thread", 0), a)
        else if (i.action == Intent.ACTION_SENDTO || i.action == Intent.ACTION_VIEW)
            i.data?.schemeSpecificPart?.substringBefore('?')?.takeIf { it.isNotBlank() }
                ?.let { nav.value = Screen.Chat(0, it.replace(';', ','), i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT)) }
    }
}

fun isDefaultSms(a: ComponentActivity) = Telephony.Sms.getDefaultSmsPackage(a) == a.packageName

@Composable
fun Root(nav: MutableState<Screen>, act: ComponentActivity) {
    val fa = isFa()
    val repo = remember { SmsRepo(act) }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { Bus.tick.intValue++ }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { Bus.tick.intValue++ }
    val askDefault = {
        val i = if (Build.VERSION.SDK_INT >= 29) {
            val rm = act.getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_SMS)) rm.createRequestRoleIntent(RoleManager.ROLE_SMS) else null
        } else Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT).putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, act.packageName)
        i?.let { roleLauncher.launch(it) }; Unit
    }
    LaunchedEffect(Unit) {
        val p = mutableListOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS,
            Manifest.permission.READ_CONTACTS, Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.RECEIVE_MMS, Manifest.permission.RECEIVE_WAP_PUSH, Manifest.permission.READ_PHONE_NUMBERS)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        permLauncher.launch(p.toTypedArray())
    }
    DisposableEffect(Unit) {
        val o = object : ContentObserver(Handler(Looper.getMainLooper())) { override fun onChange(b: Boolean) { Bus.tick.intValue++ } }
        act.contentResolver.registerContentObserver(Telephony.Sms.CONTENT_URI, true, o)
        act.contentResolver.registerContentObserver(Telephony.Mms.CONTENT_URI, true, o)
        onDispose { act.contentResolver.unregisterContentObserver(o) }
    }
    BackHandler(nav.value !is Screen.Home) { nav.value = Screen.Home }

    AbtinTheme {
        CompositionLocalProvider(
            LocalLayoutDirection provides if (fa) LayoutDirection.Rtl else LayoutDirection.Ltr,
            LocalDensity provides Density(LocalDensity.current.density, Prefs.fontScale.value)
        ) {
            Backdrop {
                if (Bus.locked.value) LockScreen() else when (val s = nav.value) {
                    is Screen.Home -> HomeScreen(repo, act, nav, askDefault)
                    is Screen.Chat -> ChatScreen(repo, act, s, nav, askDefault)
                    is Screen.New -> NewScreen(repo, nav)
                    is Screen.Settings -> SettingsScreen(repo, act, nav, askDefault)
                }
            }
        }
    }
}
