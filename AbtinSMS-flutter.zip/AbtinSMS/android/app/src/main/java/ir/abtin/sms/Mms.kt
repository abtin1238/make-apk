package ir.abtin.sms

import android.app.Activity
import android.app.PendingIntent
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.OpenableColumns
import android.provider.Telephony
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.atomic.AtomicInteger

const val ACTION_MMS_SENT = "ir.abtin.sms.MMS_SENT"
const val ACTION_MMS_DL = "ir.abtin.sms.MMS_DL"
private val mrc = AtomicInteger(5000)

/** Outgoing attachment, already compressed and held in memory. */
class Attach(val bytes: ByteArray, val mime: String, val name: String)
/** Attachment of a stored MMS (part id in the telephony provider). */
class Att(val partId: Long, val mime: String, val name: String)
class Sim(val subId: Int, val slot: Int, val name: String)

private fun mutFlag() = if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0
fun cleanAddr(a: String): String = a.trim().let { if ('@' in it) it else it.filter { c -> c.isDigit() || c == '+' } }

// ---------------- SIM ----------------
fun SmsRepo.sims(): List<Sim> = try {
    if (ctx.checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) emptyList()
    else (ctx.getSystemService(SubscriptionManager::class.java)?.activeSubscriptionInfoList ?: emptyList())
        .map { Sim(it.subscriptionId, it.simSlotIndex + 1, it.displayName?.toString() ?: "SIM") }
} catch (e: Exception) { emptyList() }

fun SmsRepo.defaultSub(): Int = try { SubscriptionManager.getDefaultSmsSubscriptionId() } catch (e: Exception) { -1 }

@Suppress("DEPRECATION")
fun smsManagerFor(c: Context, subId: Int): SmsManager =
    if (Build.VERSION.SDK_INT >= 31) {
        val m = c.getSystemService(SmsManager::class.java)
        if (subId >= 0) m.createForSubscriptionId(subId) else m
    } else {
        if (subId >= 0) SmsManager.getSmsManagerForSubscriptionId(subId) else SmsManager.getDefault()
    }

fun SmsRepo.displayName(a: List<String>): String = a.joinToString(", ") { name(it) ?: it }
fun SmsRepo.ownNumber(): String = try { ctx.getSystemService(TelephonyManager::class.java)?.line1Number ?: "" } catch (e: Exception) { "" }

// ---------------- Spam ----------------
fun SmsRepo.hasSentTo(a: String): Boolean = try {
    cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id"), "type=2 AND address LIKE ?", arrayOf("%" + norm(a)), null)?.use { it.count > 0 } ?: false
} catch (e: Exception) { false }

object Spam {
    private val soft = listOf("برنده شدید", "برنده‌شدید", "جایزه", "قرعه کشی", "قرعه‌کشی", "وام فوری", "بدون ضامن", "کازینو",
        "شرط بندی", "شرط‌بندی", "کسب درآمد", "congratulations", "you won", "lottery", "casino", "click here", "free gift",
        "claim your", "loan approved", "bit.ly", "tinyurl")
    private val strong = listOf("لغو11", "لغو 11", "لغو۱۱", "لغو ۱۱", "لغو=11", "لغو:11")
    private val url = Regex("(https?://|www\\.)\\S+", RegexOption.IGNORE_CASE)

    /** Known contacts and numbers we've texted are never spam; user whitelist wins. */
    fun check(repo: SmsRepo, addr: String, body: String): Boolean {
        if (!Prefs.spamFilter.value) return false
        val n = norm(addr)
        if (n in csv(Prefs.spamOk)) return false
        if (n in csv(Prefs.spam)) return true
        if (repo.name(addr) != null || repo.hasSentTo(addr)) return false
        val t = body.lowercase()
        if (Prefs.spamWords.value.lines().map { it.trim().lowercase() }.filter { it.isNotEmpty() }.any { t.contains(it) }) return true
        var s = soft.count { t.contains(it) } + strong.count { t.contains(it) } * 2
        if (url.containsMatchIn(body)) s++
        return s >= 2
    }
}

// ---------------- PDU (WSP/MMS 1.2) ----------------
object Pdu {
    class Part(val mime: String, val name: String, val data: ByteArray)
    class Parsed(val type: Int, val from: String?, val to: List<String>, val subject: String?, val date: Long,
                 val tx: String?, val loc: String?, val size: Long, val parts: List<Part>)

    private val WELL = arrayOf("*/*", "text/*", "text/html", "text/plain", "text/x-hdml", "text/x-ttml", "text/x-vCalendar",
        "text/x-vCard", "text/vnd.wap.wml", "text/vnd.wap.wmlscript", "text/vnd.wap.wta-event", "multipart/*", "multipart/mixed",
        "multipart/form-data", "multipart/byteranges", "multipart/alternative", "application/*", "application/java-vm",
        "application/x-www-form-urlencoded", "application/x-hdmlc", "application/vnd.wap.wmlc", "application/vnd.wap.wmlscriptc",
        "application/vnd.wap.wta-eventc", "application/vnd.wap.uaprof", "application/vnd.wap.wtls-ca-certificate",
        "application/vnd.wap.wtls-user-certificate", "application/x-x509-ca-cert", "application/x-x509-user-cert", "image/*",
        "image/gif", "image/jpeg", "image/tiff", "image/png", "image/vnd.wap.wbmp", "application/vnd.wap.multipart.*",
        "application/vnd.wap.multipart.mixed")

    private fun ByteArrayOutputStream.text(s: String) { write(s.toByteArray(Charsets.UTF_8)); write(0) }
    private fun ByteArrayOutputStream.uintvar(v0: Int) {
        var v = v0
        val tmp = ArrayList<Int>()
        tmp += v and 0x7f; v = v shr 7
        while (v > 0) { tmp += (v and 0x7f) or 0x80; v = v shr 7 }
        for (i in tmp.indices.reversed()) write(tmp[i])
    }

    /** m-send-req with multipart/mixed body; one To header per recipient (real group MMS). */
    fun encodeSend(to: List<String>, parts: List<Part>, tx: String): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(0x8C); o.write(0x80)
        o.write(0x98); o.text(tx)
        o.write(0x8D); o.write(0x92)
        o.write(0x89); o.write(0x01); o.write(0x81)
        for (a in to) { o.write(0x97); o.text(if ('@' in a) a else "$a/TYPE=PLMN") }
        o.write(0x8A); o.write(0x80)
        o.write(0x86); o.write(0x81)
        o.write(0x90); o.write(0x81)
        o.write(0x84); o.write(0xA3)
        o.uintvar(parts.size)
        for (p in parts) {
            val h = ByteArrayOutputStream()
            if (p.mime.startsWith("text/")) {
                val ct = ByteArrayOutputStream()
                ct.text(p.mime); ct.write(0x81); ct.write(0xEA) // charset = UTF-8
                h.write(ct.size()); h.write(ct.toByteArray())
            } else h.text(p.mime)
            h.write(0x8E); h.text(p.name)
            h.write(0xC0); h.write(0x22); h.text("<${p.name}>")
            o.uintvar(h.size()); o.uintvar(p.data.size)
            o.write(h.toByteArray()); o.write(p.data)
        }
        return o.toByteArray()
    }

    private class R(val b: ByteArray, var i: Int) {
        fun eof() = i >= b.size
        fun u8(): Int = b[i++].toInt() and 0xff
        fun peek(): Int = b[i].toInt() and 0xff
        fun uintvar(): Int {
            var v = 0; var x: Int
            do { x = u8(); v = (v shl 7) or (x and 0x7f) } while ((x and 0x80) != 0)
            return v
        }
        fun text(): String {
            if (i < b.size && (peek() == 0x7f || peek() == 0x22)) i++
            val s = i
            while (i < b.size && b[i].toInt() != 0) i++
            val r = String(b, s, i - s, Charsets.UTF_8)
            if (i < b.size) i++
            return r
        }
        fun bytes(n: Int): ByteArray { val e = minOf(i + n, b.size); val r = b.copyOfRange(i, e); i = e; return r }
        /** Int (raw short-integer), ByteArray (length-prefixed) or String. */
        fun value(): Any {
            val f = peek()
            return when {
                f >= 0x80 -> { i++; f }
                f in 1..30 -> { i++; bytes(f) }
                f == 31 -> { i++; bytes(uintvar()) }
                f == 0 -> { i++; "" }
                else -> text()
            }
        }
    }

    private fun long(v: Any): Long = when (v) {
        is Int -> (v and 0x7f).toLong()
        is ByteArray -> v.fold(0L) { a, x -> (a shl 8) or (x.toLong() and 0xff) }
        else -> 0L
    }

    private fun addrOf(v: Any): String? {
        val s = when (v) {
            is String -> v
            is ByteArray -> {
                if (v.isNotEmpty() && (v[0].toInt() and 0xff) == 0x81) return null
                String(v, Charsets.UTF_8)
            }
            else -> return null
        }
        val f = s.filter { it.code < 128 && (it.isLetterOrDigit() || it in "+@._/=-") }
        return f.substringBefore("/TYPE").ifEmpty { null }
    }

    private fun subjOf(v: Any): String? {
        val s = when (v) {
            is String -> v
            is ByteArray -> { val o = if (v.isNotEmpty() && (v[0].toInt() and 0x80) != 0) 1 else 0; String(v, o, v.size - o, Charsets.UTF_8) }
            else -> return null
        }
        return s.trimEnd('\u0000').ifBlank { null }
    }

    private fun mimeOf(v: Any): String = when (v) {
        is Int -> WELL.getOrNull(v and 0x7f) ?: "application/octet-stream"
        is String -> v.substringBefore(';').trim()
        is ByteArray ->
            if (v.isNotEmpty() && (v[0].toInt() and 0x80) != 0) (WELL.getOrNull(v[0].toInt() and 0x7f) ?: "application/octet-stream")
            else String(v, Charsets.UTF_8).substringBefore('\u0000').substringBefore(';').trim()
        else -> "application/octet-stream"
    }

    fun parse(b: ByteArray, start: Int = 0): Parsed {
        val r = R(b, start)
        var type = 0; var from: String? = null; val to = ArrayList<String>(); var subj: String? = null
        var date = 0L; var tx: String? = null; var loc: String? = null; var size = 0L
        val parts = ArrayList<Part>()
        try {
            var ct = false
            while (!r.eof() && !ct) {
                val k = r.u8()
                if (k < 0x80) { r.i--; r.text(); r.value(); continue }
                when (k) {
                    0x8C -> type = r.u8()
                    0x98 -> tx = r.text()
                    0x83 -> loc = r.text()
                    0x8E -> size = long(r.value())
                    0x85 -> date = long(r.value())
                    0x89 -> from = addrOf(r.value())
                    0x97, 0x82, 0x81 -> addrOf(r.value())?.let { to.add(it) }
                    0x96 -> subj = subjOf(r.value())
                    0x84 -> { r.value(); ct = true }
                    else -> r.value()
                }
            }
            if (ct && !r.eof()) {
                val n = r.uintvar()
                for (x in 0 until n) {
                    val hl = r.uintvar(); val dl = r.uintvar()
                    val hEnd = r.i + hl
                    val mime = mimeOf(r.value())
                    var name = ""
                    while (r.i < hEnd) {
                        val k = r.u8()
                        if (k == 0x8E) name = r.text()
                        else if (k == 0xC0) r.text()
                        else if (k < 0x80) { r.i--; r.text(); r.value() }
                        else r.value()
                    }
                    r.i = hEnd
                    val data = r.bytes(dl)
                    parts.add(Part(mime, name.ifEmpty { "part$x" }, data))
                }
            }
        } catch (e: Exception) { }
        return Parsed(type, from, to, subj, date, tx, loc, size, parts)
    }

    /** Fallback when the push extra still carries the WSP header. */
    fun fromPush(data: ByteArray): Parsed? = try {
        var i = 2
        var hl = 0; var x: Int
        do { x = data[i++].toInt() and 0xff; hl = (hl shl 7) or (x and 0x7f) } while ((x and 0x80) != 0)
        parse(data, i + hl)
    } catch (e: Exception) { null }
}

// ---------------- MMS send / receive / store ----------------
fun SmsRepo.sendAny(address: String, body: String, atts: List<Attach> = emptyList(), subId: Int = Prefs.sim.value) {
    val to = address.split(',', ';').map { it.trim() }.filter { it.isNotEmpty() }
    if (to.isEmpty()) return
    if (atts.isNotEmpty() || (to.size > 1 && Prefs.groupMms.value)) sendMms(to, body, atts, subId)
    else to.forEach { send(it, body, subId) }
}

private fun SmsRepo.grant(u: Uri, write: Boolean) {
    val fl = Intent.FLAG_GRANT_READ_URI_PERMISSION or (if (write) Intent.FLAG_GRANT_WRITE_URI_PERMISSION else 0)
    for (p in listOf("com.android.phone", "com.android.mms.service", "com.android.providers.telephony"))
        runCatching { ctx.grantUriPermission(p, u, fl) }
}

private fun SmsRepo.mmsDir(): File = File(ctx.cacheDir, "mms").apply { mkdirs() }

fun SmsRepo.storePart(mid: Long, p: Pdu.Part) {
    val isText = p.mime == "text/plain"
    val pv = ContentValues().apply {
        put("mid", mid); put("ct", p.mime); put("name", p.name); put("cl", p.name); put("cid", "<${p.name}>")
        if (isText) { put("text", String(p.data, Charsets.UTF_8)); put("chset", 106) }
    }
    val pu = cr.insert(Uri.parse("content://mms/$mid/part"), pv) ?: return
    if (!isText) cr.openOutputStream(pu)?.use { it.write(p.data) }
}

fun SmsRepo.sendMms(addresses: List<String>, text: String, atts: List<Attach>, subId: Int) {
    val to = addresses.map { cleanAddr(it) }.filter { it.isNotEmpty() }.distinct()
    if (to.isEmpty()) return
    val parts = ArrayList<Pdu.Part>()
    if (text.isNotBlank()) parts.add(Pdu.Part("text/plain", "text.txt", text.toByteArray(Charsets.UTF_8)))
    atts.forEachIndexed { i, a -> parts.add(Pdu.Part(a.mime, a.name.ifEmpty { "att$i" }, a.bytes)) }
    val now = System.currentTimeMillis()
    val v = ContentValues().apply {
        put("thread_id", threadIdFor(to.joinToString(","))); put("date", now / 1000); put("msg_box", 4)
        put("read", 1); put("seen", 1); put("m_type", 128); put("v", 18)
        put("ct_t", "application/vnd.wap.multipart.mixed"); put("m_size", parts.sumOf { it.data.size })
        put("tr_id", "T$now"); put("d_rpt", 129); put("rr", 129)
        if (subId >= 0) put("sub_id", subId)
    }
    val uri = cr.insert(Telephony.Mms.CONTENT_URI, v) ?: throw SecurityException("not default SMS app")
    val id = ContentUris.parseId(uri)
    val au = Uri.parse("content://mms/$id/addr")
    for (a in to) cr.insert(au, ContentValues().apply { put("address", a); put("type", 151); put("charset", 106); put("msg_id", id) })
    cr.insert(au, ContentValues().apply { put("address", "insert-address-token"); put("type", 137); put("charset", 106); put("msg_id", id) })
    for (p in parts) storePart(id, p)
    val f = File(mmsDir(), "send_$now.pdu")
    f.writeBytes(Pdu.encodeSend(to, parts, "T$now"))
    val cu = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    grant(cu, false)
    val pi = PendingIntent.getBroadcast(ctx, mrc.getAndIncrement(),
        Intent(ctx, StatusReceiver::class.java).setAction(ACTION_MMS_SENT).setData(uri).putExtra("file", f.path),
        PendingIntent.FLAG_UPDATE_CURRENT or mutFlag())
    try { smsManagerFor(ctx, subId).sendMultimediaMessage(ctx, cu, null, null, pi) }
    catch (e: Exception) { cr.update(uri, ContentValues().apply { put("msg_box", 5) }, null, null) }
}

fun SmsRepo.downloadMms(loc: String, from: String, sub: Int, tx: String) {
    val f = File(mmsDir(), "dl_${System.nanoTime()}.pdu"); f.createNewFile()
    val cu = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
    grant(cu, true)
    val pi = PendingIntent.getBroadcast(ctx, mrc.getAndIncrement(),
        Intent(ctx, StatusReceiver::class.java).setAction(ACTION_MMS_DL).putExtra("file", f.path).putExtra("sub", sub)
            .putExtra("loc", loc).putExtra("from", from).putExtra("tx", tx),
        PendingIntent.FLAG_UPDATE_CURRENT or mutFlag())
    smsManagerFor(ctx, sub).downloadMultimediaMessage(ctx, loc, cu, null, pi)
}

fun SmsRepo.onMmsDownloaded(i: Intent, code: Int) {
    val f = File(i.getStringExtra("file") ?: return)
    try {
        if (code != Activity.RESULT_OK) return
        val p = Pdu.parse(f.readBytes())
        if (p.type != 0x84) return
        storeIncomingMms(p, i.getIntExtra("sub", -1), i.getStringExtra("from"), i.getStringExtra("loc"))
    } finally { f.delete() }
}

fun SmsRepo.storeIncomingMms(p: Pdu.Parsed, sub: Int, nfrom: String?, loc: String?) {
    val from = cleanAddr(p.from ?: nfrom ?: "")
    val me = ownNumber()
    val all = (listOf(from) + p.to.map { cleanAddr(it) })
        .filter { it.isNotEmpty() && (me.isEmpty() || norm(it) != norm(me)) }.distinctBy { norm(it) }
    if (all.isEmpty()) return
    val blocked = norm(from) in csv(Prefs.blocked)
    val text = p.parts.filter { it.mime == "text/plain" }.joinToString("\n") { String(it.data, Charsets.UTF_8) }
    val tid = threadIdFor(all.joinToString(","))
    val sj = p.subject
    val v = ContentValues().apply {
        put("thread_id", tid); put("date", System.currentTimeMillis() / 1000); put("date_sent", p.date)
        put("msg_box", 1); put("read", if (blocked) 1 else 0); put("seen", if (blocked) 1 else 0)
        put("m_type", 132); put("v", 18); put("ct_t", "application/vnd.wap.multipart.related")
        put("m_size", p.parts.sumOf { it.data.size })
        if (loc != null) put("ct_l", loc)
        if (sj != null) { put("sub", sj); put("sub_cs", 106) }
        if (sub >= 0) put("sub_id", sub)
    }
    val uri = cr.insert(Telephony.Mms.Inbox.CONTENT_URI, v) ?: return
    val id = ContentUris.parseId(uri)
    val au = Uri.parse("content://mms/$id/addr")
    cr.insert(au, ContentValues().apply { put("address", from.ifEmpty { "insert-address-token" }); put("type", 137); put("charset", 106); put("msg_id", id) })
    for (a in p.to) cr.insert(au, ContentValues().apply { put("address", cleanAddr(a)); put("type", 151); put("charset", 106); put("msg_id", id) })
    for (pt in p.parts) if (pt.mime != "application/smil") storePart(id, pt)
    if (!blocked) Notifier.show(ctx, tid, all.joinToString(","), displayName(all), text.ifBlank { sj ?: "📎 MMS" })
}

fun SmsRepo.mmsAddrs(id: Long): Pair<String, List<String>> {
    var from = ""
    val to = ArrayList<String>()
    cr.query(Uri.parse("content://mms/$id/addr"), arrayOf("address", "type"), null, null, null)?.use { c ->
        while (c.moveToNext()) {
            val a = c.getString(0) ?: continue
            when (c.getInt(1)) {
                137 -> from = a
                151, 130 -> if (a != "insert-address-token") to.add(a)
            }
        }
    }
    return Pair(from, to)
}

fun SmsRepo.mmsParts(id: Long): Pair<String, List<Att>> {
    val sb = StringBuilder()
    val atts = ArrayList<Att>()
    cr.query(Uri.parse("content://mms/part"), arrayOf("_id", "ct", "text", "name"), "mid=?", arrayOf(id.toString()), null)?.use { c ->
        while (c.moveToNext()) {
            val ct = c.getString(1) ?: ""
            if (ct == "text/plain") {
                val t = c.getString(2) ?: ""
                if (t.isNotEmpty()) { if (sb.isNotEmpty()) sb.append('\n'); sb.append(t) }
            } else if (ct != "application/smil") atts.add(Att(c.getLong(0), ct, c.getString(3) ?: ""))
        }
    }
    return Pair(sb.toString(), atts)
}

fun SmsRepo.mmsMessages(threadId: Long): List<Msg> {
    val l = ArrayList<Msg>()
    cr.query(Telephony.Mms.CONTENT_URI, arrayOf("_id", "thread_id", "date", "msg_box"), "thread_id=?", arrayOf(threadId.toString()), "date ASC")?.use { c ->
        while (c.moveToNext()) {
            val id = c.getLong(0); val box = c.getInt(3)
            val (from, tos) = mmsAddrs(id)
            val (text, atts) = mmsParts(id)
            l.add(Msg(id, c.getLong(1), if (box == 1) from else tos.joinToString(","), text, c.getLong(2) * 1000, box, -1, true, atts))
        }
    }
    return l
}

fun SmsRepo.partBytes(pid: Long): ByteArray? = try {
    cr.openInputStream(Uri.parse("content://mms/part/$pid"))?.use { it.readBytes() }
} catch (e: Exception) { null }

fun SmsRepo.thumb(pid: Long, max: Int): Bitmap? = try {
    val u = Uri.parse("content://mms/part/$pid")
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    cr.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (maxOf(o.outWidth, o.outHeight) / s > max) s *= 2
    cr.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s }) }
} catch (e: Exception) { null }

fun SmsRepo.openAtt(c: Context, a: Att) {
    try {
        val b = partBytes(a.partId) ?: return
        val f = File(mmsDir(), "open_" + a.partId + "_" + a.name.ifEmpty { "file" }.replace(Regex("[^A-Za-z0-9._-]"), "_"))
        f.writeBytes(b)
        val u = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
        c.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, a.mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) { }
}

fun SmsRepo.retry(m: Msg) {
    if (m.mms) {
        val atts = m.atts.mapNotNull { a -> partBytes(a.partId)?.let { Attach(it, a.mime, a.name.ifEmpty { "file" }) } }
        deleteMessage(m.id, true)
        sendMms(m.address.split(','), m.body, atts, Prefs.sim.value)
    } else { deleteMessage(m.id, false); send(m.address, m.body) }
}

// ---------------- attachment helpers ----------------
/** Reads, rotates and compresses (<=300KB) a picked file; null if unsupported or too large. */
fun SmsRepo.prepare(u: Uri, hint: String? = null): Attach? {
    try {
        val mime = hint ?: cr.getType(u) ?: "application/octet-stream"
        var name = "file"
        runCatching {
            cr.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0)?.let { n -> name = n } }
        }
        val raw = cr.openInputStream(u)?.use { it.readBytes() } ?: return null
        if (mime.startsWith("image/") && mime != "image/gif") {
            var rot = 0
            runCatching {
                cr.openInputStream(u)?.use { ins ->
                    rot = when (android.media.ExifInterface(ins).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                        6 -> 90; 3 -> 180; 8 -> 270; else -> 0
                    }
                }
            }
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(raw, 0, raw.size, o)
            if (o.outWidth <= 0) return null
            var s = 1
            while (maxOf(o.outWidth, o.outHeight) / s > 2560) s *= 2
            var bmp = BitmapFactory.decodeByteArray(raw, 0, raw.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return null
            if (rot != 0) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
            val jn = name.substringBeforeLast('.') + ".jpg"
            var out = ByteArray(0)
            for (maxDim in intArrayOf(1280, 1024, 800, 640)) {
                val k = minOf(1f, maxDim.toFloat() / maxOf(bmp.width, bmp.height))
                val b = if (k < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true) else bmp
                for (q in intArrayOf(85, 70, 55)) {
                    val bo = ByteArrayOutputStream()
                    b.compress(Bitmap.CompressFormat.JPEG, q, bo)
                    out = bo.toByteArray()
                    if (out.size <= 300_000) return Attach(out, "image/jpeg", jn)
                }
            }
            return Attach(out, "image/jpeg", jn)
        }
        if (raw.size > 1_000_000) return null
        return Attach(raw, mime, name)
    } catch (e: Exception) { return null }
}

fun SmsRepo.contactCard(u: Uri): String? {
    var id: String? = null; var nm: String? = null
    cr.query(u, arrayOf(ContactsContract.Contacts._ID, ContactsContract.Contacts.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) { id = it.getString(0); nm = it.getString(1) }
    }
    val cid = id ?: return null
    var num: String? = null
    cr.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
        ContactsContract.CommonDataKinds.Phone.CONTACT_ID + "=?", arrayOf(cid), null)?.use { if (it.moveToFirst()) num = it.getString(0) }
    return (nm ?: "") + (if (num != null) ": $num" else "")
}

fun SmsRepo.lastLocation(): String? {
    if (ctx.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
    return try {
        val lm = ctx.getSystemService(LocationManager::class.java)
        val l = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
        l?.let { "https://maps.google.com/?q=${it.latitude},${it.longitude}" }
    } catch (e: Exception) { null }
}
