package ir.abtin.sms

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.*
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.window.Dialog
import androidx.core.content.FileProvider
import java.io.File

// ---------- helpers ----------
fun isFa() = Prefs.language.value.let { it == "fa" || (it == "system" && Locale.getDefault().language == "fa") }
fun tr(fa: String, en: String) = if (isFa()) fa else en

fun fmtDay(ms: Long): String = try {
    if (isFa()) android.icu.text.DateFormat.getPatternInstance("yMMMMd", android.icu.util.ULocale("fa_IR@calendar=persian")).format(Date(ms))
    else DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(ms))
} catch (e: Exception) { DateFormat.getDateInstance().format(Date(ms)) }

fun fmtClock(ms: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))
fun sameDay(a: Long, b: Long): Boolean { val x = Calendar.getInstance().apply { timeInMillis = a }; val y = Calendar.getInstance().apply { timeInMillis = b }
    return x.get(Calendar.YEAR) == y.get(Calendar.YEAR) && x.get(Calendar.DAY_OF_YEAR) == y.get(Calendar.DAY_OF_YEAR) }
fun fmtList(ms: Long): String = if (sameDay(ms, System.currentTimeMillis())) fmtClock(ms) else fmtDay(ms)

fun hl(t: String, q: String, c: Color): AnnotatedString = buildAnnotatedString {
    var i = 0
    while (true) {
        val j = t.indexOf(q, i, true)
        if (j < 0) { append(t.substring(i)); break }
        append(t.substring(i, j))
        withStyle(SpanStyle(background = c.copy(alpha = .4f), fontWeight = FontWeight.Bold)) { append(t.substring(j, j + q.length)) }
        i = j + q.length
    }
}

fun templates(): List<String> = Prefs.templates.value.lines().map { it.trim() }.filter { it.isNotEmpty() }
    .ifEmpty { listOf(tr("باشه", "OK"), tr("بعداً تماس می‌گیرم", "I'll call you later"), tr("ممنون", "Thanks")) }

@Composable
fun LockScreen() {
    val p = LocalPal.current
    var t by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.Lock, null, tint = p.primary, modifier = Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text(tr("پین را وارد کنید", "Enter PIN"), color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(t, { v -> t = v.filter { it.isDigit() }.take(8); if (t == Prefs.pin.value) Bus.locked.value = false },
            singleLine = true, visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
    }
}

@Composable
fun Backdrop(content: @Composable () -> Unit) {
    val p = LocalPal.current
    Box(Modifier.fillMaxSize().background(if (p.ios) SolidColor(p.bg) else Brush.verticalGradient(listOf(p.bg, p.bg2)))) { content() }
}

@Composable
fun Avatar(name: String, size: Dp) {
    val cols = listOf(0xFF3D7BFF, 0xFF8A3DFF, 0xFFFF4D8D, 0xFF1DB954, 0xFFFF8A00, 0xFF00B8D9)
    val c = Color(cols[(name.hashCode() and 0x7fffffff) % cols.size])
    Box(Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(c, c.copy(alpha = .6f)))), contentAlignment = Alignment.Center) {
        Text(name.firstOrNull { it.isLetter() }?.uppercase() ?: "#", color = Color.White, fontWeight = FontWeight.Bold, fontSize = (size.value * 0.4f).sp)
    }
}

@Composable
fun IconBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, onClick: () -> Unit) =
    IconButton(onClick = onClick) { Icon(icon, null, tint = tint) }

@Composable
fun DefaultBanner(onClick: () -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(16.dp)).background(p.primary).clickable(onClick = onClick).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(tr("برای دریافت و ارسال پیامک، آبتین SMS را برنامه پیش‌فرض کنید", "Set Abtin SMS as your default SMS app to send & receive"),
            color = p.onPrimary, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Text(tr("تنظیم", "Set"), color = p.onPrimary, fontWeight = FontWeight.Bold)
    }
}

// ---------- Home ----------
@Composable
fun HomeScreen(repo: SmsRepo, act: ComponentActivity, nav: MutableState<Screen>, askDefault: () -> Unit) {
    val p = LocalPal.current
    val tick = Bus.tick.intValue
    var convs by remember { mutableStateOf<List<Conv>>(emptyList()) }
    LaunchedEffect(tick) { convs = withContext(Dispatchers.IO) { runCatching { repo.conversations() }.getOrDefault(emptyList()) } }
    var q by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var filter by remember { mutableIntStateOf(0) }
    var del by remember { mutableStateOf<Conv?>(null) }
    val scope = rememberCoroutineScope()
    val pins = csv(Prefs.pinned); val arch = csv(Prefs.archived); val blk = csv(Prefs.blocked); val spm = csv(Prefs.spam)
    var hits by remember { mutableStateOf<List<Msg>>(emptyList()) }
    LaunchedEffect(q, tick) {
        hits = if (q.trim().length < 2) emptyList() else withContext(Dispatchers.IO) { runCatching { repo.searchMessages(q.trim()) }.getOrDefault(emptyList()) }
    }
    val shown = convs.filter {
        val b = norm(it.address) in blk; val a = it.threadId.toString() in arch; val sp = norm(it.address) in spm
        val tabOk = when (filter) {
            4 -> a && !b
            5 -> b
            6 -> sp && !b
            else -> !a && !b && !sp && (filter == 0 || (filter == 1 && it.unread > 0) || (filter == 2 && it.name != null) || (filter == 3 && it.name == null))
        }
        tabOk && (q.isBlank() || (it.name ?: it.address).contains(q, true) || it.snippet.contains(q, true))
    }.sortedBy { if (it.threadId.toString() in pins) 0 else 1 }
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            if (p.ios) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.End) {
                    IconBtn(Icons.Default.Search, p.primary) { searching = !searching; if (!searching) q = "" }
                    IconBtn(Icons.Default.Settings, p.primary) { nav.value = Screen.Settings }
                }
                Text(tr("پیام‌ها", "Messages"), color = p.text, fontSize = 34.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp))
            } else {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).clip(CircleShape).background(p.primary), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Email, null, tint = p.onPrimary)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(tr("آبتین SMS", "Abtin SMS"), color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Text("Smart · Fast · Secure", color = p.sub, fontSize = 12.sp)
                    }
                    IconBtn(Icons.Default.Search, p.text) { searching = !searching; if (!searching) q = "" }
                    IconBtn(Icons.Default.Settings, p.text) { nav.value = Screen.Settings }
                }
            }
            if (searching) OutlinedTextField(q, { q = it }, singleLine = true, placeholder = { Text(tr("جستجو…", "Search…")) },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp), shape = RoundedCornerShape(16.dp))
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val names = listOf(tr("همه", "All"), tr("خوانده‌نشده", "Unread"), tr("مخاطبین", "Contacts"), tr("ناشناس", "Unknown"), tr("بایگانی", "Archive"), tr("مسدود", "Blocked"), tr("اسپم", "Spam"))
                items(names.size) { i ->
                    val sel = filter == i
                    Text(names[i], color = if (sel) p.onPrimary else p.text, fontSize = 14.sp,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) p.primary else p.surface)
                            .clickable { filter = i }.padding(horizontal = 16.dp, vertical = 8.dp))
                }
            }
            if (!isDefaultSms(act)) DefaultBanner(askDefault)
            if (shown.isEmpty() && hits.isEmpty()) Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(tr("پیامی وجود ندارد", "No messages"), color = p.sub)
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 96.dp)) {
                items(shown, key = { it.threadId }) { c ->
                    ConvRow(c, p, c.threadId.toString() in pins, { nav.value = Screen.Chat(c.threadId, c.address) }, { del = c })
                }
                if (hits.isNotEmpty()) {
                    item { Text(tr("نتایج در متن پیام‌ها", "In messages"), color = p.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 4.dp)) }
                    items(hits, key = { "m" + it.id }) { m ->
                        Column(Modifier.fillMaxWidth().clickable { nav.value = Screen.Chat(m.threadId, m.address) }.padding(horizontal = 16.dp, vertical = 8.dp)) {
                            Text(m.address, color = p.text, fontWeight = FontWeight.SemiBold)
                            Text(hl(m.body, q.trim(), p.primary), color = p.sub, fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }
        FloatingActionButton(onClick = { nav.value = Screen.New }, containerColor = p.primary, contentColor = p.onPrimary,
            modifier = Modifier.align(Alignment.BottomEnd).navigationBarsPadding().padding(20.dp), shape = CircleShape) {
            Icon(Icons.Default.Add, null)
        }
    }
    del?.let { c ->
        val k = c.threadId.toString(); val nb = norm(c.address)
        AlertDialog(onDismissRequest = { del = null },
            title = { Text(c.name ?: c.address) },
            text = {
                Column {
                    TextButton({ toggle(Prefs.pinned, k); del = null }) { Text(if (k in pins) tr("برداشتن سنجاق", "Unpin") else tr("سنجاق کردن", "Pin")) }
                    TextButton({ toggle(Prefs.archived, k); del = null }) { Text(if (k in arch) tr("خروج از بایگانی", "Unarchive") else tr("بایگانی", "Archive")) }
                    TextButton({ toggle(Prefs.blocked, nb); del = null }) { Text(if (nb in blk) tr("رفع مسدودی", "Unblock") else tr("مسدود کردن", "Block")) }
                    TextButton({ markSpam(nb, nb !in spm); del = null }) { Text(if (nb in spm) tr("اسپم نیست", "Not spam") else tr("علامت اسپم", "Mark as spam")) }
                    TextButton({ scope.launch(Dispatchers.IO) { runCatching { repo.deleteThread(c.threadId) } }; del = null }) { Text(tr("حذف گفتگو", "Delete conversation")) }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton({ del = null }) { Text(tr("لغو", "Cancel")) } })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ConvRow(c: Conv, p: Pal, pinned: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val title = c.name ?: c.address
    val shape = RoundedCornerShape(22.dp)
    val mod = if (p.ios) Modifier.fillMaxWidth()
    else Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp).clip(shape)
        .background(p.surface.copy(alpha = if (p.dark) .7f else 1f)).border(1.dp, p.line, shape)
    Column {
        Row(mod.combinedClickable(onClick = onClick, onLongClick = onLong).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            if (Prefs.showAvatars.value) { Avatar(title, 50.dp); Spacer(Modifier.width(12.dp)) }
            Column(Modifier.weight(1f)) {
                Text((if (pinned) "📌 " else "") + title, color = p.text, fontWeight = if (c.unread > 0) FontWeight.Bold else FontWeight.SemiBold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = TextStyle(textDirection = TextDirection.Content))
                Text(c.snippet, color = p.sub, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content))
            }
            Spacer(Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(fmtList(c.date), color = p.sub, fontSize = 12.sp)
                if (c.unread > 0) Box(Modifier.padding(top = 6.dp).defaultMinSize(22.dp, 22.dp).clip(CircleShape).background(p.primary), contentAlignment = Alignment.Center) {
                    Text("${c.unread}", color = p.onPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp))
                }
            }
        }
        if (p.ios) HorizontalDivider(color = p.line, modifier = Modifier.padding(start = if (Prefs.showAvatars.value) 74.dp else 16.dp))
    }
}

// ---------- Chat ----------
@Composable
fun ChatScreen(repo: SmsRepo, act: ComponentActivity, s: Screen.Chat, nav: MutableState<Screen>, askDefault: () -> Unit) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    val tick = Bus.tick.intValue
    val addrs = remember(s.address) { s.address.split(',', ';').map { it.trim() }.filter { it.isNotEmpty() } }
    val group = addrs.size > 1
    var tid by remember { mutableLongStateOf(s.threadId) }
    var msgs by remember { mutableStateOf<List<Msg>>(emptyList()) }
    var title by remember { mutableStateOf(s.address) }
    var text by remember { mutableStateOf(s.draft ?: "") }
    val atts = remember { mutableStateListOf<Attach>() }
    val sims = remember { repo.sims() }
    var simSel by remember { mutableIntStateOf(Prefs.sim.value.takeIf { v -> sims.any { it.subId == v } } ?: -1) }
    var attMenu by remember { mutableStateOf(false) }
    LaunchedEffect(s.address) { withContext(Dispatchers.IO) { if (tid == 0L) tid = repo.threadIdFor(s.address); title = repo.displayName(addrs) } }
    DisposableEffect(tid) { Notifier.activeThread = tid; onDispose { Notifier.activeThread = -1 } }
    LaunchedEffect(tick, tid) {
        if (tid == 0L) return@LaunchedEffect
        msgs = withContext(Dispatchers.IO) { runCatching { repo.markRead(tid) }; runCatching { repo.messages(tid) }.getOrDefault(emptyList()) }
    }
    val list = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) list.scrollToItem(msgs.lastIndex) }

    fun add(u: Uri?, hint: String? = null) {
        if (u == null) return
        scope.launch(Dispatchers.IO) {
            val a = repo.prepare(u, hint)
            withContext(Dispatchers.Main) {
                if (a != null) atts.add(a)
                else Toast.makeText(act, tr("فایل پشتیبانی نمی‌شود یا خیلی بزرگ است", "Unsupported or too large"), Toast.LENGTH_LONG).show()
            }
        }
    }
    val pickImgs = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { l -> l.forEach { add(it) } }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> add(u) }
    val camUri = remember { mutableStateOf<Uri?>(null) }
    val cam = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) add(camUri.value, "image/jpeg")
    }
    val rec = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) add(r.data?.data)
    }
    val pickContact = rememberLauncherForActivityResult(ActivityResultContracts.PickContact()) { u ->
        if (u != null) scope.launch(Dispatchers.IO) {
            repo.contactCard(u)?.let { c -> withContext(Dispatchers.Main) { text = (text + " " + c).trim() } }
        }
    }
    fun insertLoc() {
        scope.launch(Dispatchers.IO) {
            val l = repo.lastLocation()
            withContext(Dispatchers.Main) {
                if (l != null) text = (text + " " + l).trim()
                else Toast.makeText(act, tr("موقعیت در دسترس نیست", "Location unavailable"), Toast.LENGTH_LONG).show()
            }
        }
    }
    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok -> if (ok) insertLoc() }
    fun launchCamera() {
        val f = File(File(act.cacheDir, "mms").apply { mkdirs() }, "cam_${System.currentTimeMillis()}.jpg")
        val u = FileProvider.getUriForFile(act, act.packageName + ".files", f)
        camUri.value = u
        val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE).putExtra(MediaStore.EXTRA_OUTPUT, u)
            .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = ClipData.newRawUri("", u)
        runCatching { cam.launch(i) }
    }

    fun doSend() {
        val t = text.trim()
        if (t.isEmpty() && atts.isEmpty()) return
        val a = atts.toList(); val sub = simSel
        text = ""; atts.clear()
        scope.launch(Dispatchers.IO) {
            try { repo.sendAny(s.address, t, a, sub) } catch (e: Exception) {
                withContext(Dispatchers.Main) { Toast.makeText(act, tr("ابتدا آبتین SMS را برنامه پیش‌فرض کنید", "Set Abtin SMS as default first"), Toast.LENGTH_LONG).show() }
            }
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().then(if (p.ios) Modifier.background(p.surface) else Modifier).padding(horizontal = 4.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBtn(Icons.AutoMirrored.Filled.ArrowBack, if (p.ios) p.primary else p.text) { nav.value = Screen.Home }
            if (Prefs.showAvatars.value) { Avatar(title, 40.dp); Spacer(Modifier.width(10.dp)) }
            Column(Modifier.weight(1f)) {
                Text(title, color = p.text, fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content))
                if (!group && title != s.address) Text(s.address, color = p.sub, fontSize = 12.sp)
                if (group) Text(tr("گروه · ${addrs.size} نفر", "Group · ${addrs.size} people"), color = p.sub, fontSize = 12.sp)
            }
        }
        if (p.ios) HorizontalDivider(color = p.line)
        if (!isDefaultSms(act)) DefaultBanner(askDefault)
        // message column always LTR so outgoing stays on the right; text direction follows content
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = list, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(msgs.size, key = { (if (msgs[it].mms) "m" else "s") + msgs[it].id }) { i ->
                    val m = msgs[i]
                    if (i == 0 || !sameDay(msgs[i - 1].date, m.date)) Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                        Text(fmtDay(m.date), color = p.sub, fontSize = 12.sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(p.surface).padding(horizontal = 12.dp, vertical = 4.dp))
                    }
                    Bubble(m, p, repo, if (group && m.type == 1) (repo.name(m.address) ?: m.address) else null,
                        onRetry = { scope.launch(Dispatchers.IO) { runCatching { repo.retry(m) } } },
                        onCopy = { (act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("sms", m.body)) },
                        onDelete = { scope.launch(Dispatchers.IO) { runCatching { repo.deleteMessage(m.id, m.mms) } } })
                }
            }
        }
        if (atts.isNotEmpty()) LazyRow(contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(atts.size) { i ->
                val a = atts[i]
                Box {
                    AttThumb(a)
                    Box(Modifier.align(Alignment.TopEnd).size(22.dp).clip(CircleShape).background(p.primary).clickable { atts.removeAt(i) }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Close, null, tint = p.onPrimary, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(templates()) { tp ->
                Text(tp, color = p.text, fontSize = 13.sp, modifier = Modifier.clip(RoundedCornerShape(50)).background(p.surface).clickable { text = tp }.padding(horizontal = 12.dp, vertical = 6.dp))
            }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.Bottom) {
            Box {
                IconBtn(Icons.Default.Add, p.primary) { attMenu = true }
                DropdownMenu(attMenu, { attMenu = false }) {
                    DropdownMenuItem(text = { Text("🖼 " + tr("گالری", "Gallery")) }, onClick = { attMenu = false; pickImgs.launch("image/*") })
                    DropdownMenuItem(text = { Text("📷 " + tr("دوربین", "Camera")) }, onClick = { attMenu = false; launchCamera() })
                    DropdownMenuItem(text = { Text("📍 " + tr("موقعیت", "Location")) }, onClick = {
                        attMenu = false
                        if (act.checkSelfPermission(android.Manifest.permission.ACCESS_FINE_LOCATION) == android.content.pm.PackageManager.PERMISSION_GRANTED) insertLoc()
                        else locPerm.launch(android.Manifest.permission.ACCESS_FINE_LOCATION)
                    })
                    DropdownMenuItem(text = { Text("👤 " + tr("مخاطب", "Contact")) }, onClick = { attMenu = false; pickContact.launch(null) })
                    DropdownMenuItem(text = { Text("🎤 " + tr("ضبط صدا", "Record audio")) }, onClick = { attMenu = false; runCatching { rec.launch(Intent(MediaStore.Audio.Media.RECORD_SOUND_ACTION)) } })
                    DropdownMenuItem(text = { Text("🎵 " + tr("فایل صوتی", "Audio file")) }, onClick = { attMenu = false; pickFile.launch("audio/*") })
                    DropdownMenuItem(text = { Text("📎 " + tr("فایل", "File")) }, onClick = { attMenu = false; pickFile.launch("*/*") })
                }
            }
            OutlinedTextField(text, { text = it }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(if (p.ios) 20.dp else 26.dp), maxLines = 5,
                placeholder = { Text(tr("پیام…", "Type a message…")) },
                textStyle = TextStyle(textDirection = TextDirection.Content, fontSize = 16.sp),
                keyboardOptions = KeyboardOptions(imeAction = if (Prefs.enterSends.value) ImeAction.Send else ImeAction.Default),
                keyboardActions = KeyboardActions(onSend = { doSend() }))
            Spacer(Modifier.width(8.dp))
            if (sims.size > 1) {
                val eff = if (simSel >= 0) simSel else repo.defaultSub()
                val sl = sims.firstOrNull { it.subId == eff }?.slot ?: 1
                Text("SIM $sl", color = p.text, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 14.dp).clip(RoundedCornerShape(50)).background(p.surface)
                        .clickable { val idx = sims.indexOfFirst { it.subId == eff }; simSel = sims[(idx + 1) % sims.size].subId }
                        .padding(horizontal = 10.dp, vertical = 6.dp))
                Spacer(Modifier.width(6.dp))
            }
            Box(Modifier.size(52.dp).clip(CircleShape).background(Brush.linearGradient(listOf(p.out1, p.out2))).clickable { doSend() }, contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Filled.Send, null, tint = p.outText)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Bubble(m: Msg, p: Pal, repo: SmsRepo, label: String?, onRetry: () -> Unit, onCopy: () -> Unit, onDelete: () -> Unit) {
    val out = m.type != 1
    val failed = m.type == 5
    var menu by remember { mutableStateOf(false) }
    val big = if (p.ios) 18.dp else 22.dp; val small = if (p.ios) 4.dp else 6.dp
    val shape = RoundedCornerShape(big, big, if (out) small else big, if (out) big else small)
    val fg = if (out) p.outText else p.inText
    val glyph = when {
        !out -> ""
        failed -> "!"
        m.type == 4 || m.type == 6 -> "…"
        m.status == 0 -> "✓✓"
        m.status == 64 -> "✗"
        else -> "✓"
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (out) Arrangement.End else Arrangement.Start) {
        Box {
            Column(Modifier.widthIn(max = 300.dp).background(if (out) Brush.linearGradient(listOf(p.out1, p.out2)) else SolidColor(p.inBubble), shape)
                .combinedClickable(onClick = { if (failed) onRetry() }, onLongClick = { menu = true }).padding(horizontal = 12.dp, vertical = 8.dp)) {
                if (label != null) Text(label, color = p.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                m.atts.forEach { at -> AttView(repo, at, fg) }
                if (m.body.isNotEmpty()) Text(m.body, color = fg, fontSize = 16.sp, style = TextStyle(textDirection = TextDirection.Content))
                Row(Modifier.align(Alignment.End), verticalAlignment = Alignment.CenterVertically) {
                    Text(fmtClock(m.date), color = fg.copy(alpha = .65f), fontSize = 11.sp)
                    if (glyph.isNotEmpty()) Text(" $glyph", color = if (failed || m.status == 64) Color(0xFFFF5252) else fg.copy(alpha = .85f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    if (failed) Text(" " + tr("تلاش مجدد", "Tap to retry"), color = Color(0xFFFF5252), fontSize = 11.sp)
                }
            }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text(tr("کپی", "Copy")) }, onClick = { onCopy(); menu = false })
                DropdownMenuItem(text = { Text(tr("حذف", "Delete")) }, onClick = { onDelete(); menu = false })
            }
        }
    }
}

@Composable
fun AttThumb(a: Attach) {
    val p = LocalPal.current
    val bmp = remember(a) {
        if (a.mime.startsWith("image/")) BitmapFactory.decodeByteArray(a.bytes, 0, a.bytes.size, BitmapFactory.Options().apply { inSampleSize = 4 }) else null
    }
    if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
    else Box(Modifier.size(72.dp).clip(RoundedCornerShape(12.dp)).background(p.surface), contentAlignment = Alignment.Center) {
        Text("📎\n" + a.name.take(10), color = p.text, fontSize = 11.sp)
    }
}

@Composable
fun AttView(repo: SmsRepo, a: Att, fg: Color) {
    val ctx = LocalContext.current
    var big by remember { mutableStateOf(false) }
    if (a.mime.startsWith("image/")) {
        val bmp by produceState<Bitmap?>(null, a.partId) { value = withContext(Dispatchers.IO) { repo.thumb(a.partId, 640) } }
        val b0 = bmp
        if (b0 != null) Image(b0.asImageBitmap(), null, Modifier.widthIn(max = 240.dp).heightIn(max = 320.dp).clip(RoundedCornerShape(12.dp)).clickable { big = true }, contentScale = ContentScale.Fit)
        else Text("🖼 …", color = fg)
        if (big) {
            val full by produceState<Bitmap?>(null, a.partId) { value = withContext(Dispatchers.IO) { repo.thumb(a.partId, 2048) } }
            Dialog({ big = false }) {
                val f0 = full
                if (f0 != null) Image(f0.asImageBitmap(), null, Modifier.fillMaxWidth().clickable { big = false }, contentScale = ContentScale.Fit)
            }
        }
    } else Text("📎 " + a.name.ifEmpty { a.mime }, color = fg, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.clickable { repo.openAtt(ctx, a) }.padding(vertical = 4.dp))
}

// ---------- New message ----------
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NewScreen(repo: SmsRepo, nav: MutableState<Screen>) {
    val p = LocalPal.current
    var to by remember { mutableStateOf("") }
    val sel = remember { mutableStateListOf<String>() }
    var contacts by remember { mutableStateOf<List<ContactItem>>(emptyList()) }
    LaunchedEffect(Unit) { contacts = withContext(Dispatchers.IO) { runCatching { repo.contacts() }.getOrDefault(emptyList()) } }
    fun go() {
        val l = sel.toList() + (if (to.any { it.isDigit() }) listOf(to.trim()) else emptyList())
        if (l.isNotEmpty()) nav.value = Screen.Chat(0, l.joinToString(","))
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(4.dp)) {
            IconBtn(Icons.AutoMirrored.Filled.ArrowBack, p.text) { nav.value = Screen.Home }
            Text(tr("پیام جدید", "New message"), color = p.text, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (sel.isNotEmpty()) TextButton({ go() }) { Text(tr("ادامه", "Next") + " (${sel.size})", color = p.primary) }
        }
        if (sel.isNotEmpty()) LazyRow(contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(sel.toList()) { n ->
                Text((contacts.firstOrNull { it.number == n }?.name ?: n) + " ✕", color = p.onPrimary, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(p.primary).clickable { sel.remove(n) }.padding(horizontal = 12.dp, vertical = 6.dp))
            }
        }
        OutlinedTextField(to, { to = it }, singleLine = true, placeholder = { Text(tr("شماره یا نام مخاطب", "Number or contact name")) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp), shape = RoundedCornerShape(16.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go), keyboardActions = KeyboardActions(onGo = { go() }))
        if (to.any { it.isDigit() }) Text(tr("ارسال به ", "Send to ") + to, color = p.primary, modifier = Modifier.fillMaxWidth().clickable { go() }.padding(16.dp))
        Text(tr("برای پیام گروهی، روی مخاطبین نگه دارید", "Long-press contacts to start a group message"), color = p.sub, fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(contacts.filter { to.isBlank() || it.name.contains(to, true) || it.number.contains(to) }) { c ->
                val on = c.number in sel
                Row(Modifier.fillMaxWidth()
                    .combinedClickable(
                        onClick = { if (sel.isNotEmpty()) { if (on) sel.remove(c.number) else sel.add(c.number) } else nav.value = Screen.Chat(0, c.number) },
                        onLongClick = { if (on) sel.remove(c.number) else sel.add(c.number) })
                    .background(if (on) p.primary.copy(alpha = .15f) else Color.Transparent)
                    .padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(c.name, 42.dp); Spacer(Modifier.width(12.dp))
                    Column { Text(c.name, color = p.text, fontWeight = FontWeight.SemiBold); Text(c.number, color = p.sub, fontSize = 13.sp) }
                }
            }
        }
    }
}

// ---------- Settings ----------
@Composable
fun SectionTitle(t: String) { Text(t, color = LocalPal.current.primary, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 6.dp)) }

@Composable
fun SwitchRow(title: String, sub: String? = null, checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { Text(title, color = p.text, fontSize = 16.sp); if (sub != null) Text(sub, color = p.sub, fontSize = 12.sp) }
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = p.primary, checkedThumbColor = p.onPrimary))
    }
}

@Composable
fun ChoiceRow(title: String, options: List<Pair<String, String>>, selected: String, onPick: (String) -> Unit) {
    val p = LocalPal.current
    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
        Text(title, color = p.text, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(options) { (k, label) ->
                val sel = k == selected
                Text(label, color = if (sel) p.onPrimary else p.text, fontSize = 14.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) p.primary else p.surface).clickable { onPick(k) }.padding(horizontal = 16.dp, vertical = 8.dp))
            }
        }
    }
}

@Composable
fun SettingsScreen(repo: SmsRepo, act: ComponentActivity, nav: MutableState<Screen>, askDefault: () -> Unit) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    val isDef = remember(Bus.tick.intValue) { isDefaultSms(act) }
    fun toast(n: Int) = Toast.makeText(act, if (n >= 0) "$n ✓" else "✗", Toast.LENGTH_LONG).show()
    val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u ->
        if (u != null) scope.launch(Dispatchers.IO) { val n = runCatching { repo.backup(u) }.getOrDefault(-1); withContext(Dispatchers.Main) { toast(n) } }
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch(Dispatchers.IO) { val n = runCatching { repo.restore(u) }.getOrDefault(-1); withContext(Dispatchers.Main) { toast(n) } }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(4.dp)) {
            IconBtn(Icons.AutoMirrored.Filled.ArrowBack, p.text) { nav.value = Screen.Home }
            Text(tr("تنظیمات", "Settings"), color = p.text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        // default app
        Column(Modifier.fillMaxWidth().padding(14.dp).clip(RoundedCornerShape(20.dp)).background(p.surface).padding(16.dp)) {
            Text(if (isDef) tr("آبتین SMS برنامه پیش‌فرض پیامک است ✓", "Abtin SMS is your default SMS app ✓") else tr("آبتین SMS پیش‌فرض نیست", "Abtin SMS is not the default app"), color = p.text, fontWeight = FontWeight.Bold)
            if (!isDef) { Spacer(Modifier.height(10.dp)); Button(askDefault, colors = ButtonDefaults.buttonColors(containerColor = p.primary, contentColor = p.onPrimary)) { Text(tr("تنظیم به‌عنوان پیش‌فرض", "Set as default")) } }
        }

        SectionTitle(tr("ظاهر و تم", "APPEARANCE & THEME"))
        // theme swatches
        val fams = buildList {
            add("neon" to tr("نئون", "Neon")); add("gold" to tr("طلایی", "Gold")); add("ios" to "iOS"); add("ocean" to tr("اقیانوس", "Ocean"))
            if (Build.VERSION.SDK_INT >= 31) add("material" to "Material You")
        }
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(fams) { (k, label) ->
                val pv = pal(if (k == "material") "neon" else k, p.dark); val sel = Prefs.family.value == k
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { Prefs.family.value = k }) {
                    Box(Modifier.size(72.dp).clip(RoundedCornerShape(18.dp)).background(Brush.verticalGradient(listOf(pv.bg, pv.bg2)))
                        .border(if (sel) 3.dp else 1.dp, if (sel) p.primary else p.line, RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(width = 40.dp, height = 22.dp).background(Brush.linearGradient(listOf(pv.out1, pv.out2)), RoundedCornerShape(10.dp)))
                    }
                    Text(label, color = if (sel) p.primary else p.sub, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        ChoiceRow(tr("حالت روشن / تیره", "Light / Dark"), listOf("system" to tr("سیستم", "System"), "light" to tr("روشن", "Light"), "dark" to tr("تیره", "Dark")), Prefs.mode.value) { Prefs.mode.value = it }
        SwitchRow(tr("تیره کاملاً مشکی (AMOLED)", "Pure black (AMOLED)"), null, Prefs.amoled.value) { Prefs.amoled.value = it }
        SwitchRow(tr("نمایش آواتار", "Show avatars"), null, Prefs.showAvatars.value) { Prefs.showAvatars.value = it }
        Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
            Text(tr("اندازه متن", "Text size") + "  ${(Prefs.fontScale.value * 100).toInt()}%", color = p.text)
            Slider(Prefs.fontScale.value, { Prefs.fontScale.value = it }, valueRange = 0.8f..1.4f, steps = 5,
                colors = SliderDefaults.colors(thumbColor = p.primary, activeTrackColor = p.primary))
        }
        ChoiceRow(tr("زبان", "Language"), listOf("system" to tr("سیستم", "System"), "fa" to "فارسی", "en" to "English"), Prefs.language.value) { Prefs.language.value = it }

        SectionTitle(tr("پیام‌ها", "MESSAGES"))
        SwitchRow(tr("گزارش تحویل (Delivery)", "Delivery reports"), tr("نمایش ✓ ارسال و ✓✓ تحویل شد", "Show ✓ sent and ✓✓ delivered"), Prefs.deliveryReports.value) { Prefs.deliveryReports.value = it }
        SwitchRow(tr("ارسال با دکمه Enter", "Enter key sends"), null, Prefs.enterSends.value) { Prefs.enterSends.value = it }
        SwitchRow(tr("پیام گروهی به‌صورت MMS", "Group messages as MMS"), tr("خاموش = ارسال جداگانه به هر نفر", "Off = send separately to each person"), Prefs.groupMms.value) { Prefs.groupMms.value = it }
        val simList = remember { repo.sims() }
        if (simList.size > 1) ChoiceRow(tr("سیم‌کارت پیش‌فرض ارسال", "Default SIM"),
            listOf("-1" to tr("پیش‌فرض سیستم", "System default")) + simList.map { it.subId.toString() to "SIM ${it.slot} · ${it.name}" },
            Prefs.sim.value.toString()) { Prefs.sim.value = it.toIntOrNull() ?: -1 }

        SectionTitle(tr("فیلتر اسپم", "SPAM FILTER"))
        SwitchRow(tr("فیلتر خودکار اسپم", "Auto spam filter"), tr("اسپم بی‌صدا به تب «اسپم» می‌رود", "Spam goes silently to the Spam tab"), Prefs.spamFilter.value) { Prefs.spamFilter.value = it }
        OutlinedTextField(Prefs.spamWords.value, { Prefs.spamWords.value = it }, minLines = 2,
            placeholder = { Text(tr("کلمات اسپم دلخواه (هر خط یک کلمه)", "Custom spam words (one per line)")) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp))

        SectionTitle(tr("اعلان‌ها", "NOTIFICATIONS"))
        SwitchRow(tr("اعلان پیام‌ها", "Message notifications"), null, Prefs.notifications.value) { Prefs.notifications.value = it }
        SwitchRow(tr("نمایش متن پیام در اعلان", "Show message preview"), tr("برای حریم خصوصی خاموش کنید", "Turn off for privacy"), Prefs.showPreview.value) { Prefs.showPreview.value = it }
        SwitchRow(tr("لرزش", "Vibrate"), null, Prefs.vibrate.value) { Prefs.vibrate.value = it }

        SectionTitle(tr("داده‌ها", "DATA"))
        Text(tr("علامت‌گذاری همه به‌عنوان خوانده‌شده", "Mark all as read"), color = p.text, fontSize = 16.sp,
            modifier = Modifier.fillMaxWidth().clickable { scope.launch(Dispatchers.IO) { runCatching { repo.markAllRead() } } }.padding(horizontal = 20.dp, vertical = 14.dp))
        Text(tr("پشتیبان‌گیری از پیامک‌ها", "Backup messages"), color = p.text, fontSize = 16.sp,
            modifier = Modifier.fillMaxWidth().clickable { exp.launch("abtin-sms-backup.json") }.padding(horizontal = 20.dp, vertical = 14.dp))
        Text(tr("بازیابی از فایل پشتیبان", "Restore from backup"), color = p.text, fontSize = 16.sp,
            modifier = Modifier.fillMaxWidth().clickable { imp.launch(arrayOf("application/json", "*/*")) }.padding(horizontal = 20.dp, vertical = 14.dp))

        SectionTitle(tr("حریم خصوصی", "PRIVACY"))
        var pinIn by remember { mutableStateOf("") }
        OutlinedTextField(pinIn, { pinIn = it.filter { ch -> ch.isDigit() }.take(8) }, singleLine = true,
            label = { Text(tr("پین جدید (۴ تا ۸ رقم)", "New PIN (4-8 digits)")) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
        Row(Modifier.padding(horizontal = 20.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Button({ if (pinIn.length >= 4) { Prefs.pin.value = pinIn; pinIn = "" } }, colors = ButtonDefaults.buttonColors(containerColor = p.primary, contentColor = p.onPrimary)) { Text(tr("تنظیم پین", "Set PIN")) }
            if (Prefs.pin.value.isNotEmpty()) TextButton({ Prefs.pin.value = "" }) { Text(tr("حذف پین", "Remove PIN")) }
        }

        SectionTitle(tr("پاسخ‌های سریع", "QUICK REPLIES"))
        OutlinedTextField(Prefs.templates.value, { Prefs.templates.value = it }, minLines = 2,
            placeholder = { Text(tr("هر خط یک قالب (خالی = پیش‌فرض)", "One per line (empty = defaults)")) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp))

        SectionTitle(tr("درباره", "ABOUT"))
        Text("آبتین SMS · 1.1.0", color = p.sub, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp))
        Spacer(Modifier.height(32.dp))
    }
}
