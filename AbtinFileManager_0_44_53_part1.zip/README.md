# Abtin File Manager (Flutter)
Complete file manager + media player + LAN transfer + archive extractor (zip/rar/7z/tar/gz/bz2/xz).

```
flutter create . --platforms=android --org ir.abtin
flutter pub get
flutter run
```
Needs `android/local.properties` (flutter.sdk). See TODO.md for status and roadmap.

## Android terminal

The terminal uses Kotlin to manage sessions, a small Java JNI bridge, and an Android NDK C++ `forkpty(3)` backend. The Flutter screen uses `xterm` to render ANSI/VT escape sequences, cursor movement, colours and scrollback. Ctrl+C is sent as ETX to the PTY line discipline, which delivers SIGINT to the foreground process group; terminal dimensions are forwarded to the PTY.

This is a PTY-backed Android shell, **not a complete Termux distribution**. The shell is `/system/bin/sh`; tools are limited to Android's built-ins, app-installed binaries and the app's granted filesystem access. Termux's APT repositories, Linux userspace and root access are not included; instead the app ships its own `pkg` (see below). Interactive programs work only when their executables and any required libraries/data are available to this app. Building the native backend needs Android NDK + CMake; build and device-test on a supported Android host before release.

Run `flutter pub get`, `flutter analyze`, `flutter test`, then `flutter build appbundle --release` on an Android build host. See TODO.md for the current validation results and host-specific build limitation.

v0.3: Word (rich formatting, tables, images, undo, find/replace), legacy .doc (text -> .docx) and PDF (draw/highlight/text/page ops) are editable in-app. See TODO.md.
v0.4: complete media player (background audio + notification, tags/cover art, sleep timer, queue editor; video gestures, PiP, subtitles tools, resume, network streams) and media library screen.

v0.17: tar.gz / 7z (password) creation, extraction & compression progress, ProGuard rules, release signing (`android/key.properties`), CI workflow and unit tests. See TODO.md.

## Package manager (`pkg`)

Available in the terminal as `pkg` (alias `apt`). Once the Alpine environment is installed (see below), `pkg install|uninstall|update|upgrade|search|show|list-installed|files` run real Alpine packages through `apk` (Termux-style), in the Android shell and in bash; the built-in Debian-style manager stays available as `pkgnative` (also used for `pkg repo|doctor|owns|autoremove`). Prefix: `$HOME/usr` (`$PREFIX`). Implemented in `android/app/src/main/java/ir/abtin/filemanager/PkgCli.java` (pure JDK; started with `app_process`, so it needs no extra binary) and wired up by `PkgEnv.java` (creates the prefix, writes `etc/shrc` through `ENV`, defines the `pkg` function and one alias per command in `$PREFIX/bin`).

Commands: `update`, `search`, `show`, `list-all`, `list-installed`, `install` (names, local files or URLs; dependencies, SHA-256 check, conflict check, rollback), `reinstall`, `remove` (reverse-dependency check), `autoremove`, `upgrade`, `files`, `owns`, `clean`, `repo list|add|remove`, `doctor`. Options: `-y`, `--force`, `--no-deps`, `--reinstall`.

Repositories are Debian `Packages` indexes (flat, or apt layout with `dist component`). Packages: `.deb`, `.tar[.gz/.xz/.bz2]`, `.zip`; `usr/` and `/data/data/com.termux/files/usr` are mapped into the prefix. Build a repo with `python3 tools/mkrepo.py OUT PKGDIR...` and host it anywhere. Built-in offline packages: `tree`, `watch`, `sysinfo`, `abtin-tools`.

Android 10+ forbids `execve` of files in app storage: scripts run with `/system/bin/sh`, native ELF programs through `/system/bin/linker(64)` (aliases are generated automatically). Programs built for the Termux prefix usually do not work unless relocatable.

## Alpine (apk, Python, Node.js) - `alpine`

`alpine setup` downloads the official Alpine minirootfs (index: `latest-stable/releases/<arch>/latest-releases.yaml`, SHA-256 verified, safe extraction, setuid stripped) into `$PREFIX/alpine` and configures apk. `alpine proot <file|url> [loader]` installs a proot binary (not bundled). Then: `alpine bootstrap` (apk update + python3, py3-pip, git, nodejs and npm), `alpine` (shell), `alpine run CMD`, `alpine install|uninstall PKG...`, `alpine update|upgrade|status|remove|doctor`. Commands such as `git`, `python3`, `pip`, `apk`, `node` and `npm` become aliases that run inside Alpine. Mirror override: `ABTIN_ALPINE_MIRROR`.

After `alpine bootstrap` finishes, enter `pip install <package>` for Python libraries and `npm install <package>` for Node packages. Install Python itself with Alpine (`apk add python3 py3-pip`), not with pip; Python syntax is `python3` / `python`, not `py i`.

## Cassette player theme ("کاست")

`lib/widgets/animated_cassette.dart` draws the flat cassette with `CustomPainter` (no image assets). Reels turn, the tape moves from the left to the right reel and both tape packs grow/shrink with the song position. Tape linear speed is `150 * playbackRate`, so reel speed follows the playback speed (a reel spins faster while it is nearly empty). All printing on the cassette is Persian; the label shows the song title/artist/cover.

Queue sheet (`_queue()` in `audio_player_screen.dart`): tap/long-press the circle to select, select all / deselect, delete selected, add songs (to the end or right after the current track), drag to reorder.

## pip / npm in the terminal (v0.44.7)

`python`, `python3`, `pip`, `pip3`, `node`, `npm`, `npx` always exist in the terminal. If Alpine is not set up yet, running any of them asks `[Y/n]` and runs `alpine bootstrap` (Alpine rootfs + proot + python3, py3-pip, git, nodejs, npm), then runs your command. The extra key **pip/npm** in the key bar runs `alpine bootstrap` directly. proot is taken from `jniLibs/<abi>/libproot.so` (+ `libproot-loader.so`) when bundled (`PROOT_LOADER` set automatically, `useLegacyPackaging = true`), otherwise it is downloaded. Then `pip install requests`, `npm install` work; the current folder is `/workspace`.


## Zip editing + auto-update (v0.44.10)
- Zip contents screen: add files, delete (one or many), replace, rename and edit a text entry **inside the zip, without extracting** (plain, single-volume .zip/.jar/.cbz/.epub; not password-protected, not apk). The zip is rewritten to a temp file and swapped in only when complete.
- Updates: the app reads https://github.com/abtin1238/make-apk/releases (via the GitHub API), picks the newest release that already has an APK (`.apk` or a `.zip` wrapping it, arm64 preferred), downloads it and opens the installer. Start-up check every 6 h, switchable in Settings; "Check for updates" there too.

## Termux environment (experimental)
`termux setup` installs the official Termux bootstrap (aarch64 build bundled inside the APK at `android/app/src/main/assets/termux-bootstrap-aarch64.zip.001/.002` (split in two, joined at runtime), so no download is needed; other CPU types still download it) (bionic-native bash, apt, coreutils) into `$PREFIX/termux` and runs it under proot with `/data/data/com.termux/files` bound to it, so the official Termux packages (`pkg install nodejs python git`) work unchanged and avoid the syscalls that Android's seccomp filter kills in Alpine (musl). Commands: `termux` (shell), `termux run CMD`, `termux pkg install PKG`, `termux status|remove`. Local file instead of download: `termux setup /sdcard/Download/bootstrap-aarch64.zip`.
