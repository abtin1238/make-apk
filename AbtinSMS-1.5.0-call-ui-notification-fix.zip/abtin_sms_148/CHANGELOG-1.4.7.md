# Abtin SMS 1.4.7

- Sharing a selected contact now inserts the contact name and phone number into the SMS text body.
- No `.vcf` attachment is created, so selecting a contact alone no longer forces MMS.
- The normal send action uses the SMS path when the message has no other attachments.
- Retains the 1.4.5 in-app contact picker/default-dialer changes and the 1.4.6 call-recording changes.

Note: Adding other media/file attachments still uses MMS as before.
