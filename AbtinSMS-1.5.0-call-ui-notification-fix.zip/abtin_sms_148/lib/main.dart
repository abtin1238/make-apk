import 'package:flutter/material.dart';

// The app UI is the native Compose MainActivity (android/app/src/main/java/ir/abtin/sms).
// This entry point only exists so the project is a valid Flutter project.
void main() => runApp(const MaterialApp(home: Scaffold(body: Center(child: Text('Abtin SMS')))));
