# Abtin SMS 1.4.5

- The Phone screen now requests Android's default-dialer role when it is opened. Android routes incoming-call UI to the selected default dialer; the existing in-app prompt remains available if the request is declined.
- The chat contact attachment flow uses Abtin's own in-app contact list rather than depending on an external system contact-picker activity. This avoids `ActivityNotFoundException` on devices without a contacts picker.
- Android versionCode increased to 8 for upgrade installation.

Note: Android requires the user to approve Abtin as the default phone app before its `InCallService` can receive and display incoming calls. This cannot be enabled silently by an app.
