# Abtin SMS 1.4.9

- Replaced incoming call answer/decline buttons with a horizontal swipe control (right to answer, left to decline).
- Added DTMF keypad and a cleaner two-row active-call control layout.
- Added a dedicated missed-call notification and details screen with callback action.
- Ongoing-call notification is non-auto-canceling when its activity is opened.
- Removed carrier video-call functionality and all video-call controls from dialer, contacts, and in-call UI.
- Preserved SMS contact sharing and prior call-recording behavior.

Note: microphone-based call recording is subject to Android/OEM audio-routing restrictions; remote-party audio capture cannot be guaranteed on every device.
