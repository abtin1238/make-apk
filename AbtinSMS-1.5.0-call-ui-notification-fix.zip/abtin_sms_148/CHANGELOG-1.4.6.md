# Abtin SMS 1.4.6

## Call recording
- Replaced misleading attempts to use restricted `VOICE_CALL` / `VOICE_COMMUNICATION` sources with an explicit microphone-based recording path.
- The app requests the in-call speaker route before recording so the microphone can potentially capture the remote party as well.
- Recording is marked active only after `MediaRecorder.prepare()` and `start()` succeed.
- Failed or too-short recordings are deleted instead of being shown as successful recordings.
- The previous audio route is restored when recording stops.
- Uses app-specific storage with an internal-storage fallback if external app storage is unavailable.

## Compatibility note
Android generally restricts direct call-audio capture for ordinary third-party apps. This implementation records through the microphone and speaker route; whether both sides are audible depends on the phone, Android build, audio routing, and acoustic echo cancellation. It does not claim guaranteed two-way recording.

All 1.4.5 contact-picker and default-dialer changes are retained.
