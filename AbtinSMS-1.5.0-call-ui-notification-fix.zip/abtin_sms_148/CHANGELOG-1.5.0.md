# Abtin SMS 1.5.0

- Refined the call-screen styling to use the app palette with restrained accent colors.
- Kept the incoming-call slider: swipe right to answer (green), swipe left to decline (red).
- Kept the active-call notification persistent when opening the in-call screen.
- Missed-call notification now opens the dedicated missed-call details screen and is dismissed only after that screen opens.
- Removed remaining carrier video-call API references and obsolete video-call TODO entries.
- Preserved SMS contact sharing and microphone-based call recording behavior.

Call recording remains subject to Android/OEM audio-routing restrictions; recording the remote party is not guaranteed on every device.
