package ir.abtin.sms

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Telephony
import java.text.Normalizer

fun toFaDigits(s: String) = buildString { s.forEach { append(if (it in '0'..'9') '\u06F0' + (it - '0') else it) } }
fun toLatinDigits(s: String) = buildString {
    s.forEach { append(when (it) { in '\u06F0'..'\u06F9' -> '0' + (it - '\u06F0'); in '\u0660'..'\u0669' -> '0' + (it - '\u0660'); else -> it }) }
}

/** GSM-friendly text: smart punctuation → ASCII, Latin accents stripped (non-Latin scripts untouched). */
fun simplify(s: String): String = buildString {
    for (ch in s) {
        when (ch) {
            '\u2018', '\u2019', '\u201B' -> append('\'')
            '\u201C', '\u201D' -> append('"')
            '\u2013', '\u2014' -> append('-')
            '\u2026' -> append("...")
            '\u00A0' -> append(' ')
            else -> if (ch.code in 0xC0..0x24F) {
                val d = Normalizer.normalize(ch.toString(), Normalizer.Form.NFD).filter { it.code < 0x300 }
                append(d.ifEmpty { ch.toString() })
            } else append(ch)
        }
    }
}

private val otpDigits = Regex("(?<!\\d)\\d{4,8}(?!\\d)")
private val otpWords = Regex("code|otp|verification|password|pin|کد|رمز|تایید|تأیید|ورود", RegexOption.IGNORE_CASE)
fun findCode(body: String): String? {
    if (body.length > 240 || !otpWords.containsMatchIn(body)) return null
    return otpDigits.find(toLatinDigits(body))?.value
}

object Photos { val cache = HashMap<String, Bitmap?>() }

fun SmsRepo.photo(address: String): Bitmap? {
    synchronized(Photos.cache) { if (Photos.cache.containsKey(address)) return Photos.cache[address] }
    val b: Bitmap? = try {
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) null
        else {
            val u = cr.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(address)),
                arrayOf(ContactsContract.PhoneLookup.PHOTO_THUMBNAIL_URI), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
            if (u == null) null else cr.openInputStream(Uri.parse(u))?.use { BitmapFactory.decodeStream(it) }
        }
    } catch (e: Exception) { null }
    synchronized(Photos.cache) { Photos.cache[address] = b }
    return b
}

fun SmsRepo.deleteMessages(l: List<Msg>) { l.forEach { runCatching { deleteMessage(it.id, it.mms) } } }

fun SmsRepo.markUnread(threadId: Long) {
    val v = android.content.ContentValues().apply { put("read", 0); put("seen", 0) }
    runCatching {
        cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id"), "thread_id=? AND type=1", arrayOf(threadId.toString()), "date DESC LIMIT 1")?.use {
            if (it.moveToFirst()) cr.update(Telephony.Sms.CONTENT_URI, v, "_id=?", arrayOf(it.getLong(0).toString()))
        }
    }
}

fun SmsRepo.purgeOtp() {
    if (!Prefs.autoDeleteOtp.value) return
    val limit = System.currentTimeMillis() - 24 * 3600 * 1000L
    val ids = ArrayList<Long>()
    cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "body"), "type=1 AND date<?", arrayOf(limit.toString()), null)?.use { c ->
        while (c.moveToNext()) if (findCode(c.getString(1) ?: "") != null) ids += c.getLong(0)
    }
    ids.forEach { cr.delete(Telephony.Sms.CONTENT_URI, "_id=?", arrayOf(it.toString())) }
}

fun SmsRepo.partSize(pid: Long): Long = try {
    cr.openAssetFileDescriptor(Uri.parse("content://mms/part/$pid"), "r")?.use { it.length } ?: -1L
} catch (e: Exception) { -1L }

fun fmtSize(b: Long): String = when {
    b < 0 -> ""
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "${b / 1024} KB"
    else -> String.format(java.util.Locale.US, "%.1f MB", b / 1048576.0)
}

fun SmsRepo.smsById(id: Long): Msg? = try {
    cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id", "thread_id", "address", "body", "date", "type", "status"), "_id=?", arrayOf(id.toString()), null)?.use {
        if (it.moveToFirst()) Msg(it.getLong(0), it.getLong(1), it.getString(2) ?: "", it.getString(3) ?: "", it.getLong(4), it.getInt(5), it.getInt(6)) else null
    }
} catch (e: Exception) { null }

fun isRtlText(t: String): Boolean {
    for (ch in t) {
        if (!Character.isLetter(ch)) continue
        val d = Character.getDirectionality(ch)
        return d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC
    }
    return false
}
