package ir.abtin.remote.receiver

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.RandomAccessFile
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread

/**
 * این کلاس با دسترسی shell (از طریق adb و app_process) اجرا می‌شود، نه داخل خود اپ.
 * سه دستگاه HID مجازی (موس، کیبورد، کنترل رسانه) از طریق /dev/uhid می‌سازد تا
 * اندروید آن‌ها را مثل سخت‌افزار واقعی ببیند: نشانگر خود سیستم، کلیک واقعی و Enter واقعی.
 *
 * اجرا (یک بار بعد از هر ری‌استارت باکس):
 * adb shell 'CLASSPATH=$(pm path ir.abtin.remote.receiver | cut -d: -f2) nohup app_process /system/bin ir.abtin.remote.receiver.Injector >/data/local/tmp/abtin.log 2>&1 &'
 *
 * پروتکل محلی (127.0.0.1:39879، هر خط یک دستور):
 *   m dx dy | b mask | w v | k usage mods | c usage | s mask | ping
 */
class Injector {

    private class VirtualHid(name: String, desc: IntArray, vid: Int, pid: Int) {
        private val f = RandomAccessFile("/dev/uhid", "rw")

        init {
            val rd = ByteArray(desc.size) { desc[it].toByte() }
            val bb = ByteBuffer.allocate(280 + rd.size).order(ByteOrder.LITTLE_ENDIAN)
            bb.putInt(0, 11) // UHID_CREATE2
            val nb = name.toByteArray()
            for (i in 0 until minOf(nb.size, 127)) bb.put(4 + i, nb[i])
            bb.putShort(260, rd.size.toShort())
            bb.putShort(262, 3) // BUS_USB
            bb.putInt(264, vid)
            bb.putInt(268, pid)
            bb.putInt(272, 1)
            bb.putInt(276, 0)
            for (i in rd.indices) bb.put(280 + i, rd[i])
            f.write(bb.array())
            thread(isDaemon = true) {
                val b = ByteArray(4380)
                try { while (f.read(b) >= 0) { /* رویدادهای خروجی (مثل LED) نادیده گرفته می‌شوند */ } } catch (_: Exception) {}
            }
        }

        @Synchronized
        fun send(report: ByteArray) {
            val bb = ByteBuffer.allocate(6 + report.size).order(ByteOrder.LITTLE_ENDIAN)
            bb.putInt(0, 12) // UHID_INPUT2
            bb.putShort(4, report.size.toShort())
            for (i in report.indices) bb.put(6 + i, report[i])
            f.write(bb.array())
        }
    }

    companion object {
        const val PORT = 39879

        private val MOUSE = intArrayOf(
            0x05, 0x01, 0x09, 0x02, 0xA1, 0x01, 0x09, 0x01, 0xA1, 0x00,
            0x05, 0x09, 0x19, 0x01, 0x29, 0x03, 0x15, 0x00, 0x25, 0x01,
            0x95, 0x03, 0x75, 0x01, 0x81, 0x02, 0x95, 0x01, 0x75, 0x05, 0x81, 0x03,
            0x05, 0x01, 0x09, 0x30, 0x09, 0x31, 0x09, 0x38,
            0x15, 0x81, 0x25, 0x7F, 0x75, 0x08, 0x95, 0x03, 0x81, 0x06,
            0xC0, 0xC0
        )
        private val KEYBOARD = intArrayOf(
            0x05, 0x01, 0x09, 0x06, 0xA1, 0x01, 0x05, 0x07, 0x19, 0xE0, 0x29, 0xE7,
            0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
            0x95, 0x01, 0x75, 0x08, 0x81, 0x01,
            0x95, 0x05, 0x75, 0x01, 0x05, 0x08, 0x19, 0x01, 0x29, 0x05, 0x91, 0x02,
            0x95, 0x01, 0x75, 0x03, 0x91, 0x01,
            0x95, 0x06, 0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07, 0x19, 0x00, 0x29, 0x65, 0x81, 0x00,
            0xC0
        )
        private val SYSTEM = intArrayOf(
            0x05, 0x01, 0x09, 0x80, 0xA1, 0x01, 0x19, 0x81, 0x29, 0x83,
            0x15, 0x00, 0x25, 0x01, 0x75, 0x01, 0x95, 0x03, 0x81, 0x02,
            0x75, 0x05, 0x95, 0x01, 0x81, 0x03, 0xC0
        )
        private val CONSUMER = intArrayOf(
            0x05, 0x0C, 0x09, 0x01, 0xA1, 0x01, 0x15, 0x00, 0x26, 0xFF, 0x03,
            0x19, 0x00, 0x2A, 0xFF, 0x03, 0x75, 0x10, 0x95, 0x01, 0x81, 0x00, 0xC0
        )

        @Volatile private var mask = 0

        @JvmStatic
        fun main(args: Array<String>) {
            val mouse: VirtualHid
            val kb: VirtualHid
            val cons: VirtualHid
            val sys: VirtualHid
            val server: ServerSocket
            try {
                mouse = VirtualHid("Abtin Virtual Mouse", MOUSE, 0x1209, 0xAB01)
                kb = VirtualHid("Abtin Virtual Keyboard", KEYBOARD, 0x1209, 0xAB02)
                cons = VirtualHid("Abtin Virtual Media Keys", CONSUMER, 0x1209, 0xAB03)
                sys = VirtualHid("Abtin Virtual System", SYSTEM, 0x1209, 0xAB04)
                server = ServerSocket(PORT, 8, InetAddress.getByName("127.0.0.1"))
            } catch (e: Exception) {
                System.err.println("injector failed: $e")
                System.exit(1)
                return
            }
            Thread.sleep(500)
            println("ready")
            while (true) {
                val c = try { server.accept() } catch (_: Exception) { break }
                thread(name = "abtin-injector-client") { handle(c, mouse, kb, cons, sys) }
            }
        }

        private fun b(v: Int) = v.coerceIn(-127, 127).toByte()

        private fun handle(c: Socket, mouse: VirtualHid, kb: VirtualHid, cons: VirtualHid, sys: VirtualHid) {
            try {
                c.tcpNoDelay = true
                val r = BufferedReader(InputStreamReader(c.getInputStream()))
                while (true) {
                    val line = r.readLine() ?: break
                    val p = line.trim().split(' ')
                    try {
                        when (p[0]) {
                            "m" -> mouse.send(byteArrayOf(mask.toByte(), b(p[1].toInt()), b(p[2].toInt()), 0))
                            "w" -> mouse.send(byteArrayOf(mask.toByte(), 0, 0, b(p[1].toInt())))
                            "b" -> { mask = p[1].toInt() and 7; mouse.send(byteArrayOf(mask.toByte(), 0, 0, 0)) }
                            "k" -> {
                                val usage = p[1].toInt().toByte()
                                val mods = if (p.size > 2) p[2].toInt().toByte() else 0
                                kb.send(byteArrayOf(mods, 0, usage, 0, 0, 0, 0, 0))
                                Thread.sleep(25)
                                kb.send(ByteArray(8))
                            }
                            "s" -> {
                                // ۱=Power ۲=Sleep ۴=Wake
                                sys.send(byteArrayOf((p[1].toInt() and 7).toByte()))
                                Thread.sleep(40)
                                sys.send(byteArrayOf(0))
                            }
                            "c" -> {
                                val u = p[1].toInt()
                                cons.send(byteArrayOf((u and 0xFF).toByte(), (u shr 8).toByte()))
                                Thread.sleep(25)
                                cons.send(byteArrayOf(0, 0))
                            }
                        }
                    } catch (_: Exception) { }
                }
            } catch (_: Exception) {
            } finally {
                try { c.close() } catch (_: Exception) {}
            }
        }
    }
}
