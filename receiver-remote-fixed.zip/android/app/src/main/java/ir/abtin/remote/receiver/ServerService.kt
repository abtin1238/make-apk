package ir.abtin.remote.receiver

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager

class ServerService : Service() {

    companion object {
        private const val CHANNEL = "abtin_remote_server"

        fun start(context: Context) {
            val i = Intent(context, ServerService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(i) else context.startService(i)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ServerService::class.java))
        }
    }

    private var cpuLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wifiLock2: WifiManager.WifiLock? = null

    /** تا وقتی صفحه خاموش است هم سرور در دسترس بماند (برای روشن کردن با ریموت). */
    private fun holdLocks() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            cpuLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "abtin:server").apply {
                setReferenceCounted(false); acquire()
            }
        } catch (_: Exception) { }
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager ?: return
        // حالت low-latency فقط وقتی برنامه جلوی صفحه است کار می‌کند؛ بعد از Home (لانچر) غیرفعال می‌شود
        // و Wi-Fi به حالت صرفه‌جویی می‌رود. قفل FULL معمولی در پس‌زمینه هم Wi-Fi را بیدار نگه می‌دارد.
        try {
            val mode = if (Build.VERSION.SDK_INT >= 29) WifiManager.WIFI_MODE_FULL_LOW_LATENCY else WifiManager.WIFI_MODE_FULL_HIGH_PERF
            wifiLock = wm.createWifiLock(mode, "abtin:wifi").apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) { }
        try {
            wifiLock2 = wm.createWifiLock(WifiManager.WIFI_MODE_FULL, "abtin:wifi2").apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) { }
    }

    override fun onCreate() {
        super.onCreate()
        CrashLog.install(applicationContext)
        startForeground(1, buildNotification())
        holdLocks()
        RemoteServer.start(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        RemoteServer.start(applicationContext)
        return START_STICKY
    }

    override fun onDestroy() {
        try { cpuLock?.release() } catch (_: Exception) {}
        try { wifiLock?.release() } catch (_: Exception) {}
        try { wifiLock2?.release() } catch (_: Exception) {}
        RemoteServer.stop()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun buildNotification(): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Abtin Remote Receiver", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return b.setContentTitle("Abtin Remote Receiver")
            .setContentText("سرور کنترل روی پورت ${RemoteServer.PORT} فعال است")
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setContentIntent(open)
            .build()
    }
}
