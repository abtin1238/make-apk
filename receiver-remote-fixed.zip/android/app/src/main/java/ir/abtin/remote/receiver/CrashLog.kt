package ir.abtin.remote.receiver

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/** آخرین کرش را در فایل می‌نویسد تا در صفحه‌ی اصلی برنامه دیده شود (برای پیدا کردن علت قطع شدن). */
object CrashLog {
    private var installed = false

    fun install(ctx: Context) {
        if (installed) return
        installed = true
        val app = ctx.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                File(app.filesDir, "crash.txt").writeText("thread=${t.name}\n$sw")
            } catch (_: Throwable) { }
            prev?.uncaughtException(t, e)
        }
    }

    fun read(ctx: Context): String = try {
        val f = File(ctx.filesDir, "crash.txt")
        if (f.exists()) f.readText().take(700) else ""
    } catch (_: Throwable) { "" }

    fun clear(ctx: Context) { try { File(ctx.filesDir, "crash.txt").delete() } catch (_: Throwable) { } }
}
