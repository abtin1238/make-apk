package ir.abtin.filemanager

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import java.security.MessageDigest
import android.graphics.Bitmap
import android.graphics.Canvas
import java.io.ByteArrayOutputStream
import android.net.Uri
import android.provider.DocumentsContract
import android.webkit.MimeTypeMap
import java.io.IOException
import java.io.OutputStream
import android.content.res.Configuration
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.OpenableColumns
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.util.Rational
import android.view.WindowManager
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileOutputStream

class MainActivity : AudioServiceActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private var sys: MethodChannel? = null
    private var terminalNative: TerminalNative? = null
    private var shizuku: ShizukuBridge? = null
    private var frameShown = false
    private var watchdogOn = false

    // ---- "Open with" (ACTION_VIEW) ----
    private var dartReady = false
    private var pendingPath: String? = null

    private val installAction = "ir.abtin.filemanager.INSTALL_RESULT"
    private val installRx = object : android.content.BroadcastReceiver() {
        override fun onReceive(c: android.content.Context, i: Intent) {
            val st = i.getIntExtra(android.content.pm.PackageInstaller.EXTRA_STATUS, -1)
            if (st == android.content.pm.PackageInstaller.STATUS_PENDING_USER_ACTION) {
                @Suppress("DEPRECATION")
                val conf = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (conf != null) { conf.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(conf) }
            } else {
                sys?.invokeMethod("installResult", mapOf("status" to st, "msg" to i.getStringExtra(android.content.pm.PackageInstaller.EXTRA_STATUS_MESSAGE)))
            }
        }
    }

    override fun onDestroy() {
        terminalNative?.closeAll()
        terminalNative = null
        shizuku?.dispose()
        shizuku = null
        try { unregisterReceiver(installRx) } catch (e: Throwable) {}
        super.onDestroy()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val rxFilter = android.content.IntentFilter(installAction)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(installRx, rxFilter, android.content.Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(installRx, rxFilter)
        if (savedInstanceState == null) handleViewIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleViewIntent(intent)
    }

    private fun deliver(path: String) {
        if (dartReady) sys?.invokeMethod("openFile", path) else pendingPath = path
    }

    private fun handleViewIntent(i: Intent?) {
        if (i == null) return
        // "Downloads" button of other apps / the system -> open our Download folder
        if (i.action == "android.intent.action.VIEW_DOWNLOADS") {
            deliver(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath)
            return
        }
        if (i.action != Intent.ACTION_VIEW) return
        val uri = i.data ?: return
        val type = i.type
        Thread {
            val p = try { resolveIncoming(uri, type) } catch (e: Throwable) { null }
            if (p != null) ui.post { deliver(p) }
        }.start()
    }

    private fun resolveIncoming(uri: Uri, mime: String?): String? {
        if (uri.scheme == "file") {
            val f = File(uri.path ?: return null)
            if (f.isFile && f.canRead()) return f.absolutePath
        } else if (uri.scheme == "content") {
            realPathOf(uri)?.let { return it }
        }
        return copyToCache(uri, mime)
    }

    private fun realPathOf(uri: Uri): String? {
        try {
            if (DocumentsContract.isDocumentUri(this, uri)) {
                val id = DocumentsContract.getDocumentId(uri)
                if (uri.authority == extDocs) {
                    val i = id.indexOf(':')
                    if (i > 0) {
                        val vol = id.substring(0, i)
                        val base = if (vol.equals("primary", true)) Environment.getExternalStorageDirectory().path else "/storage/$vol"
                        val f = File(base, id.substring(i + 1))
                        if (f.isFile && f.canRead()) return f.absolutePath
                    }
                } else if (id.startsWith("raw:")) {
                    val f = File(id.substring(4))
                    if (f.isFile && f.canRead()) return f.absolutePath
                }
            }
            contentResolver.query(uri, arrayOf("_data"), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex("_data")
                    val p = if (idx >= 0) c.getString(idx) else null
                    if (p != null) {
                        val f = File(p)
                        if (f.isFile && f.canRead()) return f.absolutePath
                    }
                }
            }
        } catch (e: Throwable) {}
        return null
    }

    private fun copyToCache(uri: Uri, mime: String?): String? {
        val dn = try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null }
        } catch (e: Throwable) { null }
        var name = (dn ?: uri.lastPathSegment ?: "file").substringAfterLast('/').replace(Regex("[\\\\:*?\"<>|]"), "_")
        if (name.isBlank()) name = "file"
        if (!name.contains('.')) {
            val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime ?: contentResolver.getType(uri))
            if (ext != null) name += ".$ext"
        }
        val dir = File(cacheDir, "incoming")
        dir.mkdirs()
        val now = System.currentTimeMillis()
        dir.listFiles()?.forEach { if (now - it.lastModified() > 86_400_000L) it.deleteRecursively() }
        val sub = File(dir, now.toString())
        sub.mkdirs()
        val out = File(sub, name)
        contentResolver.openInputStream(uri)?.use { inp -> FileOutputStream(out).use { o -> inp.copyTo(o) } } ?: return null
        return out.absolutePath
    }

    override fun onFlutterUiDisplayed() {
        super.onFlutterUiDisplayed()
        frameShown = true
    }

    override fun onResume() {
        super.onResume()
        if (!frameShown && !watchdogOn) {
            watchdogOn = true
            ui.postDelayed({
                if (!frameShown && !isFinishing && !isDestroyed) {
                    val info = "Flutter first frame was not drawn after 12 s.\n" +
                        "Model: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
                        "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
                        "ABIs: ${Build.SUPPORTED_ABIS.joinToString()}"
                    try {
                        android.app.AlertDialog.Builder(this)
                            .setTitle("Abtin File Manager")
                            .setMessage(info)
                            .setPositiveButton("OK", null)
                            .show()
                    } catch (e: Exception) { }
                }
            }, 12000)
        }
    }

    // ---- Storage Access Framework (SD card) ----
    private val safReq = 4711
    private val extDocs = "com.android.externalstorage.documents"
    private val safPrefs by lazy { getSharedPreferences("saf", MODE_PRIVATE) }
    private var safPending: MethodChannel.Result? = null
    private var safPendingUuid: String? = null
    private val safOut = HashMap<Int, OutputStream>()
    private var safNext = 1

    private fun parts(path: String) = path.split("/").filter { it.isNotEmpty() }
    private fun uuidOf(path: String): String {
        val p = parts(path)
        if (p.size >= 2 && p[0] == "storage" && p[1] != "emulated" && p[1] != "self") return p[1]
        throw IllegalArgumentException("Not a removable volume: $path")
    }
    private fun relOf(path: String) = parts(path).drop(2).joinToString("/")
    private fun treeOf(uuid: String): Uri? = safPrefs.getString(uuid, null)?.let { Uri.parse(it) }
    private fun hasPerm(tree: Uri) = contentResolver.persistedUriPermissions.any { it.uri == tree && it.isWritePermission }
    private fun docUri(path: String): Uri {
        val uuid = uuidOf(path)
        val tree = treeOf(uuid) ?: throw IllegalStateException("No SD card access")
        val rel = relOf(path)
        return DocumentsContract.buildDocumentUriUsingTree(tree, "$uuid:$rel")
    }
    private fun docExists(uri: Uri): Boolean = try {
        contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null)?.use { it.count > 0 } ?: false
    } catch (e: Exception) { false }

    private fun safMkdirs(path: String): Uri {
        val uuid = uuidOf(path)
        var cur = "/storage/$uuid"
        var uri = docUri(cur)
        for (name in parts(relOf(path))) {
            cur += "/$name"
            val u = docUri(cur)
            uri = if (docExists(u)) u
            else DocumentsContract.createDocument(contentResolver, uri, DocumentsContract.Document.MIME_TYPE_DIR, name)
                ?: throw IOException("Could not create folder $name")
        }
        return uri
    }

    private fun safCreate(path: String): Uri {
        val f = File(path)
        val existing = docUri(path)
        if (docExists(existing)) return existing
        val parent = safMkdirs(f.parent!!)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
        return DocumentsContract.createDocument(contentResolver, parent, mime, f.name)
            ?: throw IOException("Could not create ${f.name}")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == safReq) {
            val r = safPending
            val uuid = safPendingUuid
            safPending = null
            var ok = false
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null && uuid != null) {
                try {
                    if (DocumentsContract.getTreeDocumentId(uri).equals("$uuid:", ignoreCase = true)) {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                        safPrefs.edit().putString(uuid, uri.toString()).apply()
                        ok = true
                    }
                } catch (e: Exception) { ok = false }
            }
            r?.success(ok)
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }
    private var pipAuto = false
    private var pipW = 16
    private var pipH = 9

    private fun enterPip(w: Int, h: Int): Boolean {
        if (Build.VERSION.SDK_INT < 26) return false
        return try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(w.coerceAtLeast(1), h.coerceAtLeast(1))).build())
            true
        } catch (e: Exception) { false }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (pipAuto) enterPip(pipW, pipH)
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        sys?.invokeMethod("pipChanged", isInPictureInPictureMode)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger
        terminalNative = TerminalNative(messenger, filesDir.absolutePath, cacheDir.absolutePath, applicationInfo.sourceDir, applicationInfo.nativeLibraryDir)
        NearbyNative(this, messenger)
        AudioVisualizerNative(this, messenger).register()
        AudioSpectrumNative(messenger)
        ImageThumbNative(cacheDir, messenger)
        shizuku = ShizukuBridge(this, messenger)

        sys = MethodChannel(messenger, "abtin/sys")
        sys!!.setMethodCallHandler { call, result ->
            when (call.method) {
                "openUrl" -> try {
                    val v = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(call.argument<String>("url")!!))
                    v.addCategory(Intent.CATEGORY_BROWSABLE)
                    v.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(v)
                    result.success(true)
                } catch (e: Exception) {
                    result.success(false)
                }
                "openSystemFolder" -> try {
                    val path = call.argument<String>("path") ?: "/storage/emulated/0/Android/data"
                    val root = Environment.getExternalStorageDirectory().absolutePath
                    val normalizedRoot = root.trimEnd('/')
                    val normalizedPath = File(path).canonicalPath
                    if (!normalizedPath.startsWith("$normalizedRoot/")) {
                        throw IllegalArgumentException("Folder must be inside shared storage")
                    }
                    val relativePath = normalizedPath.removePrefix("$normalizedRoot/")
                    val documentId = "primary:" + relativePath.replace(File.separatorChar, '/')
                    val initialUri = DocumentsContract.buildTreeDocumentUri(
                        "com.android.externalstorage.documents",
                        documentId
                    )

                    // Open Android's system Files document browser directly.
                    // No chooser, Xiaomi File Manager, or Shizuku is involved.
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            putExtra(DocumentsContract.EXTRA_INITIAL_URI, initialUri)
                        }
                        addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION or
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                            Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                        )
                    }
                    val filesPackages = listOf(
                        "com.google.android.documentsui",
                        "com.android.documentsui"
                    )
                    val targetPackage = filesPackages.firstOrNull { pkg ->
                        try {
                            packageManager.getPackageInfo(pkg, 0)
                            true
                        } catch (_: Exception) { false }
                    }
                    if (targetPackage != null) intent.setPackage(targetPackage)
                    startActivity(intent)
                    result.success(true)
                } catch (e: Exception) {
                    result.success(false)
                }
                "openWith" -> try {
                    val f = File(call.argument<String>("path")!!)
                    val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.abtinfiles", f)
                    val ext = f.extension.lowercase()
                    val mime = android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
                    val v = Intent(Intent.ACTION_VIEW)
                    v.setDataAndType(uri, mime)
                    v.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    val ch = Intent.createChooser(v, call.argument<String>("title") ?: "")
                    ch.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(ch)
                    result.success(true)
                } catch (e: Exception) {
                    result.error("ERR", e.message, null)
                }
                "storage" -> try {
                    val st = StatFs(call.argument<String>("path")!!)
                    result.success(listOf(st.totalBytes, st.availableBytes))
                } catch (e: Exception) {
                    result.error("ERR", e.message, null)
                }
                "brightness" -> {
                    val b = window.attributes.screenBrightness
                    if (b >= 0) result.success(b.toDouble()) else {
                        val s = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { 128 }
                        result.success(s / 255.0)
                    }
                }
                "setBrightness" -> {
                    val v = call.argument<Double>("v") ?: -1.0
                    runOnUiThread {
                        val lp = window.attributes
                        lp.screenBrightness = if (v < 0) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else v.toFloat().coerceIn(0.01f, 1f)
                        window.attributes = lp
                    }
                    result.success(true)
                }
                "sysVolume" -> {
                    val am = getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
                    val mx = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    result.success(am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC).toDouble() / mx)
                }
                "setSysVolume" -> {
                    val v = (call.argument<Double>("v") ?: 0.0).coerceIn(0.0, 1.0)
                    val am = getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
                    val mx = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                    am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, Math.round(v * mx).toInt(), 0)
                    result.success(true)
                }
                "keepOn" -> {
                    val on = call.argument<Boolean>("on") ?: false
                    runOnUiThread {
                        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                    result.success(true)
                }
                "initialFile" -> {
                    dartReady = true
                    val p = pendingPath
                    pendingPath = null
                    result.success(p)
                }
                "pip" -> result.success(enterPip(call.argument<Int>("w") ?: 16, call.argument<Int>("h") ?: 9))
                "pipAuto" -> {
                    pipAuto = call.argument<Boolean>("on") ?: false
                    pipW = call.argument<Int>("w") ?: 16
                    pipH = call.argument<Int>("h") ?: 9
                    result.success(true)
                }
                "scan" -> {
                    MediaScannerConnection.scanFile(this, arrayOf(call.argument<String>("path")), null, null)
                    result.success(true)
                }
                "apkIcon" -> {
                    val apk = call.argument<String>("path")!!
                    Thread {
                        var bytes: ByteArray? = null
                        try {
                            val pm = packageManager
                            val ai = pm.getPackageArchiveInfo(apk, 0)?.applicationInfo
                            if (ai != null) {
                                ai.sourceDir = apk
                                ai.publicSourceDir = apk
                                val d = ai.loadIcon(pm)
                                val size = 128
                                val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                                d.setBounds(0, 0, size, size)
                                d.draw(Canvas(bmp))
                                val out = ByteArrayOutputStream()
                                bmp.compress(Bitmap.CompressFormat.PNG, 90, out)
                                bytes = out.toByteArray()
                            }
                        } catch (e: Throwable) { bytes = null }
                        ui.post { result.success(bytes) }
                    }.start()
                }
                "selfInfo" -> {
                    try {
                        val pi = packageManager.getPackageInfo(packageName, 0)
                        val code = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
                        result.success(mapOf("versionName" to (pi.versionName ?: ""), "versionCode" to code, "lastUpdate" to pi.lastUpdateTime))
                    } catch (e: Exception) { result.success(null) }
                }
                "canInstall" -> result.success(Build.VERSION.SDK_INT < 26 || packageManager.canRequestPackageInstalls())
                "installSettings" -> {
                    try {
                        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } catch (e: Exception) {}
                    result.success(true)
                }
                "uninstall" -> {
                    try {
                        val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:" + call.argument<String>("pkg")))
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } catch (e: Exception) {}
                    result.success(true)
                }
                "apps" -> {
                    Thread {
                        val out = ArrayList<Map<String, Any?>>()
                        try {
                            val pm = packageManager
                            for (pi in pm.getInstalledPackages(0)) {
                                val ai = pi.applicationInfo ?: continue
                                val sys = (ai.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0 &&
                                    (ai.flags and android.content.pm.ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                                val code = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
                                var size = File(ai.sourceDir).length()
                                ai.splitSourceDirs?.forEach { size += File(it).length() }
                                out.add(mapOf(
                                    "pkg" to pi.packageName, "label" to ai.loadLabel(pm).toString(),
                                    "version" to (pi.versionName ?: ""), "code" to code, "system" to sys,
                                    "size" to size, "updated" to pi.lastUpdateTime))
                            }
                        } catch (e: Throwable) {}
                        ui.post { result.success(out) }
                    }.start()
                }
                "appIcon" -> {
                    val pkg = call.argument<String>("pkg")!!
                    Thread {
                        var bytes: ByteArray? = null
                        try {
                            val d = packageManager.getApplicationIcon(pkg)
                            val size = 96
                            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                            d.setBounds(0, 0, size, size)
                            d.draw(Canvas(bmp))
                            val o = ByteArrayOutputStream()
                            bmp.compress(Bitmap.CompressFormat.PNG, 90, o)
                            bytes = o.toByteArray()
                        } catch (e: Throwable) { bytes = null }
                        ui.post { result.success(bytes) }
                    }.start()
                }
                "backupApp" -> {
                    val pkg = call.argument<String>("pkg")!!
                    val dst = call.argument<String>("dir")!!
                    Thread {
                        var res: String? = null
                        try {
                            val pm = packageManager
                            val pi = pm.getPackageInfo(pkg, 0)
                            val ai = pi.applicationInfo!!
                            val bad = Regex("[\\\\/:*?\"<>|\\s]+")
                            val name = "${ai.loadLabel(pm)}_${pkg}_${pi.versionName ?: ""}".replace(bad, "_")
                            File(dst).mkdirs()
                            val splits = ai.splitSourceDirs
                            if (splits == null || splits.isEmpty()) {
                                val o = File(dst, "$name.apk")
                                File(ai.sourceDir).copyTo(o, true)
                                res = o.path
                            } else {
                                val dir = File(dst, name)
                                dir.mkdirs()
                                File(ai.sourceDir).copyTo(File(dir, "base.apk"), true)
                                for (sp in splits) File(sp).copyTo(File(dir, File(sp).name), true)
                                res = dir.path
                            }
                        } catch (e: Throwable) { res = null }
                        ui.post { result.success(res) }
                    }.start()
                }
                "installSplits" -> {
                    val paths = call.argument<List<String>>("paths")!!
                    Thread {
                        var err: String? = null
                        try {
                            val pi = packageManager.packageInstaller
                            val params = android.content.pm.PackageInstaller.SessionParams(android.content.pm.PackageInstaller.SessionParams.MODE_FULL_INSTALL)
                            val id = pi.createSession(params)
                            val ses = pi.openSession(id)
                            for (pth in paths) {
                                val fl = File(pth)
                                fl.inputStream().use { ins ->
                                    ses.openWrite(fl.name, 0, fl.length()).use { o -> ins.copyTo(o); ses.fsync(o) }
                                }
                            }
                            val it = Intent(installAction).setPackage(packageName)
                            val fg = android.app.PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) android.app.PendingIntent.FLAG_MUTABLE else 0)
                            ses.commit(android.app.PendingIntent.getBroadcast(this, id, it, fg).intentSender)
                            ses.close()
                        } catch (e: Throwable) { err = e.message ?: "error" }
                        ui.post { result.success(err) }
                    }.start()
                }
                "apkInfo" -> {
                    val apk = call.argument<String>("path")!!
                    Thread {
                        var out: Map<String, Any?>? = null
                        try { out = apkInfo(apk) } catch (e: Throwable) { out = null }
                        ui.post { result.success(out) }
                    }.start()
                }
                "scanMany" -> {
                    val l = call.argument<List<String>>("paths") ?: emptyList()
                    if (l.isNotEmpty()) MediaScannerConnection.scanFile(this, l.toTypedArray(), null, null)
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }

        MethodChannel(messenger, "abtin/saf").setMethodCallHandler { call, result ->
            when (call.method) {
                "has" -> {
                    val t = treeOf(call.argument<String>("uuid")!!)
                    result.success(t != null && hasPerm(t))
                }
                "request" -> {
                    val uuid = call.argument<String>("uuid")!!
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    if (Build.VERSION.SDK_INT >= 26) i.putExtra(DocumentsContract.EXTRA_INITIAL_URI, DocumentsContract.buildTreeDocumentUri(extDocs, "$uuid:"))
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    safPending?.success(false)
                    safPending = result
                    safPendingUuid = uuid
                    startActivityForResult(i, safReq)
                }
                "revoke" -> {
                    val uuid = call.argument<String>("uuid")!!
                    treeOf(uuid)?.let {
                        try { contentResolver.releasePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (e: Exception) {}
                    }
                    safPrefs.edit().remove(uuid).apply()
                    result.success(true)
                }
                else -> Thread {
                    try {
                        val path = call.argument<String>("path")
                        val r: Any? = when (call.method) {
                            "mkdirs" -> { safMkdirs(path!!); true }
                            "create" -> { safCreate(path!!); true }
                            "delete" -> {
                                if (!DocumentsContract.deleteDocument(contentResolver, docUri(path!!))) throw IOException("Delete failed")
                                true
                            }
                            "rename" -> {
                                DocumentsContract.renameDocument(contentResolver, docUri(path!!), call.argument<String>("name")!!)
                                    ?: throw IOException("Rename failed")
                                true
                            }
                            "move" -> {
                                val f = File(path!!)
                                val moved = DocumentsContract.moveDocument(contentResolver, docUri(path), docUri(f.parent!!), safMkdirs(call.argument<String>("dst")!!))
                                    ?: throw IOException("Move failed")
                                val newName = call.argument<String>("name")!!
                                if (newName != f.name) {
                                    DocumentsContract.renameDocument(contentResolver, moved, newName) ?: throw IOException("Rename failed")
                                }
                                true
                            }
                            "open" -> {
                                val os = contentResolver.openOutputStream(safCreate(path!!), "wt") ?: throw IOException("Cannot open for writing")
                                val h = synchronized(safOut) { safNext++ }
                                safOut[h] = os
                                h
                            }
                            "write" -> {
                                val os = safOut[call.argument<Int>("h")!!] ?: throw IOException("Bad handle")
                                os.write(call.argument<ByteArray>("data")!!)
                                true
                            }
                            "close" -> {
                                safOut.remove(call.argument<Int>("h")!!)?.close()
                                true
                            }
                            else -> throw UnsupportedOperationException(call.method)
                        }
                        ui.post { result.success(r) }
                    } catch (e: Throwable) {
                        ui.post { result.error("ERR", e.message ?: e.toString(), null) }
                    }
                }.start()
            }
        }

        PdfNative.register(this, messenger, ui)
        SecurityNative.register(this, messenger, ui)
        FgsNative.register(this, messenger)
        WidgetNative.register(applicationContext, messenger)

        ArchiveNative.register(messenger, ui)
    }

    @Suppress("DEPRECATION")
    private fun apkInfo(apk: String): Map<String, Any?>? {
        val pm = packageManager
        val sigFlag = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val flags = PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES or PackageManager.GET_SERVICES or
            PackageManager.GET_RECEIVERS or PackageManager.GET_PROVIDERS or sigFlag
        val pi = pm.getPackageArchiveInfo(apk, flags) ?: return null
        val ai = pi.applicationInfo ?: return null
        ai.sourceDir = apk
        ai.publicSourceDir = apk
        val code = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        val sigs = ArrayList<String>()
        try {
            val raw = if (Build.VERSION.SDK_INT >= 28) pi.signingInfo?.apkContentsSigners else pi.signatures
            raw?.forEach { s ->
                val d = MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
                sigs.add(d.joinToString(":") { "%02X".format(it) })
            }
        } catch (e: Throwable) {}
        var instCode: Long? = null
        var instName: String? = null
        try {
            val ip = pm.getPackageInfo(pi.packageName, 0)
            instCode = if (Build.VERSION.SDK_INT >= 28) ip.longVersionCode else ip.versionCode.toLong()
            instName = ip.versionName
        } catch (e: Exception) {}
        return mapOf(
            "label" to ai.loadLabel(pm).toString(),
            "package" to pi.packageName,
            "versionName" to (pi.versionName ?: ""),
            "versionCode" to code,
            "minSdk" to ai.minSdkVersion,
            "targetSdk" to ai.targetSdkVersion,
            "permissions" to (pi.requestedPermissions?.toList() ?: emptyList<String>()),
            "activities" to (pi.activities?.size ?: 0),
            "services" to (pi.services?.size ?: 0),
            "receivers" to (pi.receivers?.size ?: 0),
            "providers" to (pi.providers?.size ?: 0),
            "signatures" to sigs,
            "installedCode" to instCode,
            "installedName" to instName,
        )
    }
}
