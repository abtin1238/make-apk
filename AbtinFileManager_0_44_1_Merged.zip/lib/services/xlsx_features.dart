part of 'office_service.dart';

// ====================================================================================================
// Undo / redo support: a light snapshot of every part the spreadsheet editor can change.
// ====================================================================================================
class XSnap {
  final Map<String, List<int>> files;
  final Set<String> dirty, drop;
  XSnap(this.files, this.dirty, this.drop);
}

extension OfficeZipSnap on OfficeZip {
  XSnap liteSnapshot() {
    final m = <String, List<int>>{};
    for (final f in arc.files) {
      if (!f.isFile) continue;
      final doc = _docs[f.name];
      if (doc != null && _dirty.contains(f.name)) {
        m[f.name] = utf8.encode(doc.toXmlString());
      } else {
        m[f.name] = f.content as List<int>;
      }
    }
    return XSnap(m, {..._dirty}, {...drop});
  }

  void restoreLite(XSnap s) {
    arc.files.clear();
    s.files.forEach((name, data) => arc.addFile(ArchiveFile(name, data.length, data)));
    _docs.clear();
    drop
      ..clear()
      ..addAll(s.drop);
    _dirty
      ..clear()
      ..addAll(s.dirty);
  }
}

// ====================================================================================================
// Formula reference helpers (shift on copy / fill, adjust on row / column insert and delete)
// ====================================================================================================
final _xRefRe = RegExp(r"(?<![A-Za-z0-9_.$])((?:'[^']+'|[A-Za-z_][A-Za-z0-9_.]*)!)?(\$?)([A-Za-z]{1,3})(\$?)(\d{1,7})(?![A-Za-z0-9_(])");

/// Applies [f] to every cell reference of [formula] that is outside string literals.
String xlsxMapRefs(String formula, String Function(RegExpMatch m, String src) f) {
  final parts = formula.split('"');
  for (var i = 0; i < parts.length; i += 2) {
    final src = parts[i];
    parts[i] = src.replaceAllMapped(_xRefRe, (m) => f(m, src));
  }
  return parts.join('"');
}

/// Moves relative references by ([dc] columns, [dr] rows) like Excel does when a formula is copied.
String xlsxShiftFormula(String formula, int dc, int dr) => xlsxMapRefs(formula, (m, src) {
      final pre = m[1] ?? '';
      var c = colIndex(m[3]!);
      var r = int.parse(m[5]!);
      if (m[2] != r'$') c += dc;
      if (m[4] != r'$') r += dr;
      if (c < 0 || r < 1) return '#REF!';
      return '$pre${m[2]}${colName(c)}${m[4]}$r';
    });

/// Rewrites references to [target] after rows (or columns) were inserted / deleted at [at] (1-based position).
String xlsxAdjustRefs(String formula, {required String ownSheet, required String target, required bool rows, required int at, required int delta}) {
  String sheetOf(String? pre) {
    if (pre == null || pre.isEmpty) return ownSheet;
    var s = pre.substring(0, pre.length - 1);
    if (s.startsWith("'") && s.endsWith("'")) s = s.substring(1, s.length - 1).replaceAll("''", "'");
    return s;
  }

  final parts = formula.split('"');
  for (var i = 0; i < parts.length; i += 2) {
    final src = parts[i];
    final out = StringBuffer();
    var last = 0;
    String? rangeSheet; // sheet of the first half of a range
    for (final m in _xRefRe.allMatches(src)) {
      out.write(src.substring(last, m.start));
      last = m.end;
      final afterColon = m.start > 0 && src[m.start - 1] == ':';
      final isStart = m.end < src.length && src[m.end] == ':';
      final sheet = afterColon && m[1] == null ? (rangeSheet ?? ownSheet) : sheetOf(m[1]);
      rangeSheet = isStart ? sheet : null;
      if (sheet != target) {
        out.write(m[0]);
        continue;
      }
      var c = colIndex(m[3]!) + 1;
      var r = int.parse(m[5]!);
      var p = rows ? r : c;
      var bad = false;
      if (delta > 0) {
        if (p >= at) p += delta;
      } else {
        if (p == at) {
          if (isStart) {
            // range start moves onto the next row
          } else if (afterColon) {
            p = at - 1;
            if (p < 1) bad = true;
          } else {
            bad = true;
          }
        } else if (p > at) {
          p += delta;
        }
      }
      if (bad) {
        out.write('#REF!');
        continue;
      }
      if (rows) {
        r = p;
      } else {
        c = p;
      }
      out.write('${m[1] ?? ''}${m[2]}${colName(c - 1)}${m[4]}$r');
    }
    out.write(src.substring(last));
    parts[i] = out.toString();
  }
  return parts.join('"');
}

class _XFont {
  final bool b, i, u, s;
  final double? sz;
  final int? color;
  final String name;
  const _XFont(this.b, this.i, this.u, this.s, this.sz, this.color, this.name);
}

const _defaultTheme = [0xFFFFFF, 0x000000, 0xEEECE1, 0x1F497D, 0x4F81BD, 0xC0504D, 0x9BBB59, 0x8064A2, 0x4BACC6, 0xF79646];
const _indexedColors = [0x000000, 0xFFFFFF, 0xFF0000, 0x00FF00, 0x0000FF, 0xFFFF00, 0xFF00FF, 0x00FFFF, 0x000000, 0xFFFFFF, 0xFF0000, 0x00FF00, 0x0000FF, 0xFFFF00, 0xFF00FF, 0x00FFFF];

XmlElement? _child(XmlElement? p, String name) => p?.findElements(name, namespace: '*').firstOrNull;

void _placeWs(XmlElement root, XmlElement el) {
  const order = [
    'sheetPr', 'dimension', 'sheetViews', 'sheetFormatPr', 'cols', 'sheetData', 'sheetCalcPr', 'sheetProtection', 'protectedRanges', 'scenarios', 'autoFilter', 'sortState', 'dataConsolidate',
    'customSheetViews', 'mergeCells', 'phoneticPr', 'conditionalFormatting', 'dataValidations', 'hyperlinks', 'printOptions', 'pageMargins', 'pageSetup', 'headerFooter', 'rowBreaks', 'colBreaks',
    'customProperties', 'cellWatches', 'ignoredErrors', 'smartTags', 'drawing', 'legacyDrawing', 'legacyDrawingHF', 'picture', 'oleObjects', 'controls', 'webPublishItems', 'tableParts', 'extLst'
  ];
  final mine = order.indexOf(el.name.local);
  var at = root.children.length;
  for (var i = 0; i < root.children.length; i++) {
    final ch = root.children[i];
    if (ch is XmlElement) {
      final o = order.indexOf(ch.name.local);
      if (o > mine) {
        at = i;
        break;
      }
    }
  }
  root.children.insert(at, el);
}
void _removeWs(XmlElement root, String name) {
  root.children.removeWhere((e) => e is XmlElement && e.name.local == name);
}
int _addUnique(XmlElement parent, String childName, XmlElement el) {
  final list = parent.findElements(childName, namespace: '*').toList();
  final s = el.toXmlString();
  for (var i = 0; i < list.length; i++) {
    if (list[i].toXmlString() == s) return i;
  }
  parent.children.add(el);
  parent.setAttribute('count', '${list.length + 1}');
  return list.length;
}
String _rgbHex(int rgb) => 'FF${(rgb & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase()}';

extension XlsxFeatures on XlsxFile {
  // ==================================================================================================
  // Loading
  // ==================================================================================================
  List<int> _themeColors() {
    final th = z.xml('xl/theme/theme1.xml');
    if (th == null) return _defaultTheme;
    final scheme = th.findAllElements('clrScheme', namespace: '*').firstOrNull;
    if (scheme == null) return _defaultTheme;
    final list = <int>[];
    for (final e in scheme.childElements) {
      final c = e.childElements.firstOrNull;
      if (c == null) {
        list.add(0);
        continue;
      }
      final v = c.getAttribute('val') ?? c.getAttribute('lastClr') ?? '000000';
      list.add(int.tryParse(v, radix: 16) ?? 0);
    }
    if (list.length < 10) return _defaultTheme;
    return [list[1], list[0], list[3], list[2], ...list.sublist(4)];
  }

  int? _colorOf(XmlElement? e, List<int> theme) {
    if (e == null || e.getAttribute('auto') == '1') return null;
    int? rgb;
    final v = e.getAttribute('rgb');
    final th = int.tryParse(e.getAttribute('theme') ?? '');
    final ix = int.tryParse(e.getAttribute('indexed') ?? '');
    if (v != null && v.length >= 6) {
      rgb = int.tryParse(v.substring(v.length - 6), radix: 16);
    } else if (th != null && th >= 0 && th < theme.length) {
      rgb = theme[th];
    } else if (ix != null && ix >= 0 && ix < _indexedColors.length) {
      rgb = _indexedColors[ix];
    }
    if (rgb == null) return null;
    final tint = double.tryParse(e.getAttribute('tint') ?? '');
    if (tint != null && tint != 0) {
      int ch(int shift) {
        final c = (rgb! >> shift) & 255;
        final n = tint < 0 ? c * (1 + tint) : c + (255 - c) * tint;
        return n.round().clamp(0, 255);
      }

      rgb = (ch(16) << 16) | (ch(8) << 8) | ch(0);
    }
    return rgb;
  }

  void _loadStyles() {
    final st = z.xml('xl/styles.xml');
    if (st == null) return;
    final root = st.rootElement;
    final theme = _themeColors();
    final numFmts = <int, String>{};
    for (final n in root.findAllElements('numFmt', namespace: '*')) {
      final id = int.tryParse(n.getAttribute('numFmtId') ?? '');
      final code = n.getAttribute('formatCode');
      if (id != null && code != null) numFmts[id] = code;
    }
    final fonts = <_XFont>[];
    for (final f in _child(root, 'fonts')?.findElements('font', namespace: '*') ?? const <XmlElement>[]) {
      bool flag(String n) {
        final e = _child(f, n);
        return e != null && e.getAttribute('val') != '0' && e.getAttribute('val') != 'false';
      }

      final u = _child(f, 'u');
      fonts.add(_XFont(flag('b'), flag('i'), u != null && u.getAttribute('val') != 'none', flag('strike'), double.tryParse(_child(f, 'sz')?.getAttribute('val') ?? ''), _colorOf(_child(f, 'color'), theme), _child(f, 'name')?.getAttribute('val') ?? ''));
    }
    final base = fonts.isNotEmpty ? fonts.first : const _XFont(false, false, false, false, null, null, '');
    final fills = <int?>[];
    for (final f in _child(root, 'fills')?.findElements('fill', namespace: '*') ?? const <XmlElement>[]) {
      final pf = _child(f, 'patternFill');
      int? rgb;
      if (pf != null && pf.getAttribute('patternType') == 'solid') rgb = _colorOf(_child(pf, 'fgColor'), theme);
      fills.add(rgb);
    }
    final borders = <int>[];
    for (final b in _child(root, 'borders')?.findElements('border', namespace: '*') ?? const <XmlElement>[]) {
      var mask = 0;
      bool has(String side) {
        final e = _child(b, side);
        final s = e?.getAttribute('style');
        return s != null && s != 'none';
      }

      if (has('left')) mask |= XBorder.left;
      if (has('right')) mask |= XBorder.right;
      if (has('top')) mask |= XBorder.top;
      if (has('bottom')) mask |= XBorder.bottom;
      borders.add(mask);
    }
    final xfs = _child(root, 'cellXfs');
    if (xfs == null) return;
    for (final xf in xfs.findElements('xf', namespace: '*')) {
      final fi = int.tryParse(xf.getAttribute('fontId') ?? '0') ?? 0;
      final fl = int.tryParse(xf.getAttribute('fillId') ?? '0') ?? 0;
      final bd = int.tryParse(xf.getAttribute('borderId') ?? '0') ?? 0;
      final nid = int.tryParse(xf.getAttribute('numFmtId') ?? '0') ?? 0;
      final f = fi < fonts.length ? fonts[fi] : base;
      final al = _child(xf, 'alignment');
      var code = numFmts[nid] ?? XNumFmt.builtIn[nid] ?? '';
      if (code == 'General') code = '';
      var h = al?.getAttribute('horizontal') ?? '';
      if (h == 'general' || h == 'centerContinuous' || h == 'distributed') h = h == 'centerContinuous' ? 'center' : '';
      var v = al?.getAttribute('vertical') ?? '';
      if (v == 'distributed' || v == 'justify') v = '';
      _xfStyle.add(XStyle(
        bold: f.b,
        italic: f.i,
        underline: f.u,
        strike: f.s,
        size: f.sz != null && f.sz != base.sz ? f.sz : null,
        color: f.color == base.color ? null : f.color,
        font: f.name == base.name ? '' : f.name,
        fill: fl < fills.length ? fills[fl] : null,
        border: bd < borders.length ? borders[bd] : 0,
        numFmt: code,
        h: h,
        v: v,
        wrap: al?.getAttribute('wrapText') == '1' || al?.getAttribute('wrapText') == 'true',
        indent: int.tryParse(al?.getAttribute('indent') ?? '') ?? 0,
      ));
    }
  }

  void _expandSharedFormulas(XSheet sh) {
    final cells = sh.doc.findAllElements('c', namespace: '*').toList();
    final masters = <String, (String, String)>{};
    for (final c in cells) {
      final f = _child(c, 'f');
      if (f == null || f.getAttribute('t') != 'shared') continue;
      final si = f.getAttribute('si');
      if (si != null && f.innerText.isNotEmpty) masters[si] = ((c.getAttribute('r') ?? '').toUpperCase(), f.innerText);
    }
    if (masters.isEmpty) return;
    for (final c in cells) {
      final f = _child(c, 'f');
      if (f == null || f.getAttribute('t') != 'shared') continue;
      final m = masters[f.getAttribute('si')];
      if (m == null) continue;
      if (f.innerText.isEmpty) {
        final ref = (c.getAttribute('r') ?? '').toUpperCase();
        final a = parseRef(m.$1), b = parseRef(ref);
        if (a == null || b == null) continue;
        final nf = xlsxShiftFormula(m.$2, b.$1 - a.$1, b.$2 - a.$2);
        f.children
          ..clear()
          ..add(XmlText(nf));
        sh.formulas[ref] = nf;
      }
      f.removeAttribute('t');
      f.removeAttribute('si');
      f.removeAttribute('ref');
    }
    z.touch(sh.part);
  }

  (int?, int?, bool) _dxf(int? id) {
    if (id == null) return (null, null, false);
    final dxfs = _child(z.xml('xl/styles.xml')?.rootElement, 'dxfs');
    final list = dxfs?.findElements('dxf', namespace: '*').toList() ?? const <XmlElement>[];
    if (id < 0 || id >= list.length) return (null, null, false);
    final theme = _themeColors();
    final d = list[id];
    final font = _child(d, 'font');
    final pf = _child(_child(d, 'fill'), 'patternFill');
    final fill = _colorOf(_child(pf, 'bgColor'), theme) ?? _colorOf(_child(pf, 'fgColor'), theme);
    return (fill, _colorOf(_child(font, 'color'), theme), _child(font, 'b') != null);
  }

  void _loadSheetExtras(XSheet sh) {
    final root = sh.doc.rootElement;
    sh.tabColor = _colorOf(_child(_child(root, 'sheetPr'), 'tabColor'), _themeColors());
    final view = _child(_child(root, 'sheetViews'), 'sheetView');
    if (view != null) {
      sh.rtl = view.getAttribute('rightToLeft') == '1' || view.getAttribute('rightToLeft') == 'true';
      sh.showGrid = !(view.getAttribute('showGridLines') == '0' || view.getAttribute('showGridLines') == 'false');
      final pane = _child(view, 'pane');
      if (pane != null && (pane.getAttribute('state') ?? '').startsWith('frozen')) {
        sh.frozenCols = (double.tryParse(pane.getAttribute('xSplit') ?? '') ?? 0).toInt();
        sh.frozenRows = (double.tryParse(pane.getAttribute('ySplit') ?? '') ?? 0).toInt();
      }
    }
    final dcw = double.tryParse(_child(root, 'sheetFormatPr')?.getAttribute('defaultColWidth') ?? '');
    if (dcw != null) sh.defColW = math.max(72.0, dcw * 7 + 5);
    for (final c in _child(root, 'cols')?.findElements('col', namespace: '*') ?? const <XmlElement>[]) {
      final mn = int.tryParse(c.getAttribute('min') ?? '') ?? 0, mx = int.tryParse(c.getAttribute('max') ?? '') ?? 0;
      if (mn < 1 || mx < mn || mx - mn > 300) continue;
      final w = double.tryParse(c.getAttribute('width') ?? '');
      final hidden = c.getAttribute('hidden') == '1' || c.getAttribute('hidden') == 'true';
      for (var i = mn - 1; i < mx; i++) {
        if (w != null && c.getAttribute('customWidth') != '0') sh.colWidths[i] = math.max(24.0, w * 7 + 5);
        if (hidden) sh.hiddenCols.add(i);
      }
    }
    _readRowAttrs(sh);
    final mc = _child(root, 'mergeCells');
    for (final m in mc?.findElements('mergeCell', namespace: '*') ?? const <XmlElement>[]) {
      final r = XRange.parse(m.getAttribute('ref') ?? '');
      if (r != null && !r.isCell) sh.merges.add(r);
    }
    final af = _child(root, 'autoFilter');
    if (af != null) {
      sh.filter = XRange.parse(af.getAttribute('ref') ?? '');
      if (sh.filter != null) {
        for (final fc in af.findElements('filterColumn', namespace: '*')) {
          final id = int.tryParse(fc.getAttribute('colId') ?? '');
          final vals = _child(fc, 'filters')?.findElements('filter', namespace: '*').map((e) => e.getAttribute('val') ?? '').toSet();
          if (id != null && vals != null && vals.isNotEmpty) sh.filterValues[sh.filter!.c1 + id] = vals;
        }
      }
    }
    for (final cf in root.findElements('conditionalFormatting', namespace: '*')) {
      final rg = XRange.parse((cf.getAttribute('sqref') ?? '').split(' ').first);
      if (rg == null) continue;
      for (final rule in cf.findElements('cfRule', namespace: '*')) {
        final type = rule.getAttribute('type') ?? '';
        final fs = rule.findElements('formula', namespace: '*').map((e) => e.innerText).toList();
        final (fill, color, bold) = _dxf(int.tryParse(rule.getAttribute('dxfId') ?? ''));
        if (type == 'cellIs') {
          sh.conds.add(XCond(type: 'cellIs', range: rg, op: rule.getAttribute('operator') ?? 'equal', v1: fs.isNotEmpty ? fs[0] : '', v2: fs.length > 1 ? fs[1] : '', fill: fill, color: color, bold: bold));
        } else if (type == 'containsText') {
          sh.conds.add(XCond(type: 'containsText', range: rg, v1: rule.getAttribute('text') ?? '', fill: fill, color: color, bold: bold));
        } else if (type == 'duplicateValues' || type == 'uniqueValues') {
          sh.conds.add(XCond(type: type == 'duplicateValues' ? 'duplicate' : 'unique', range: rg, fill: fill, color: color, bold: bold));
        } else if (type == 'colorScale') {
          final theme = _themeColors();
          final cols = [for (final c in _child(rule, 'colorScale')?.findElements('color', namespace: '*') ?? const <XmlElement>[]) _colorOf(c, theme) ?? 0xFFFFFF];
          if (cols.length >= 2) sh.conds.add(XCond(type: 'colorScale', range: rg, scale: cols));
        }
      }
    }
    final dvs = _child(root, 'dataValidations');
    for (final d in dvs?.findElements('dataValidation', namespace: '*') ?? const <XmlElement>[]) {
      final rg = XRange.parse((d.getAttribute('sqref') ?? '').split(' ').first);
      if (rg == null) continue;
      sh.validations.add(XValidation(
        range: rg,
        type: d.getAttribute('type') ?? 'none',
        op: d.getAttribute('operator') ?? 'between',
        f1: _child(d, 'formula1')?.innerText ?? '',
        f2: _child(d, 'formula2')?.innerText ?? '',
        allowBlank: d.getAttribute('allowBlank') == '1',
        dropdown: d.getAttribute('showDropDown') != '1',
        title: d.getAttribute('promptTitle') ?? '',
        message: d.getAttribute('prompt') ?? '',
      ));
    }
  }

  void _readRowAttrs(XSheet sh) {
    sh.rowHeights.clear();
    sh.hiddenRows.clear();
    for (final r in sh.doc.findAllElements('row', namespace: '*')) {
      final n = int.tryParse(r.getAttribute('r') ?? '');
      if (n == null) continue;
      final ht = double.tryParse(r.getAttribute('ht') ?? '');
      final custom = r.getAttribute('customHeight') == '1' || r.getAttribute('customHeight') == 'true';
      if (ht != null) {
        final px = ht * 96 / 72;
        if (custom || px > 32) sh.rowHeights[n] = math.max(8.0, px);
      }
      if (r.getAttribute('hidden') == '1' || r.getAttribute('hidden') == 'true') sh.hiddenRows.add(n);
    }
  }

  void _loadDefinedNames() {
    definedNames.clear();
    final wb = z.xml('xl/workbook.xml');
    if (wb == null) return;
    for (final d in wb.findAllElements('definedName', namespace: '*')) {
      final n = d.getAttribute('name');
      if (n == null || n.startsWith('_xlnm.') || d.getAttribute('localSheetId') != null) continue;
      definedNames[n] = d.innerText;
    }
  }

  // ==================================================================================================
  // Display
  // ==================================================================================================
  /// Typed value of a cell (double / bool / String), after formulas.
  dynamic cellValue(XSheet sh, String ref) {
    if (sh.formulas.containsKey(ref)) return sh.computed[ref] ?? sh.cells[ref] ?? '';
    final raw = sh.cells[ref];
    if (raw == null) return null;
    final n = double.tryParse(raw);
    return n ?? raw;
  }

  /// Text shown in the grid, honouring the cell's number format.
  String displayText(XSheet sh, String ref) {
    final raw = sh.cells[ref];
    if (raw == null) return '';
    final code = sh.styles[ref]?.numFmt ?? '';
    final isF = sh.formulas.containsKey(ref);
    final dynamic v = isF ? (sh.computed[ref] ?? raw) : raw;
    if (code.isEmpty || code == 'General') return v is String ? v : XNumFmt.general(v);
    if (v is String && XlsxFormulaEngine.errors.contains(v)) return v;
    return XNumFmt.format(v, code);
  }

  // ==================================================================================================
  // Cell styles
  // ==================================================================================================
  XmlElement _section(XmlElement root, String name, {int? index}) {
    var e = _child(root, name);
    if (e == null) {
      e = XmlElement(XmlName(name), [XmlAttribute(XmlName('count'), '0')]);
      if (index != null && index <= root.children.length) {
        root.children.insert(index, e);
      } else {
        root.children.add(e);
      }
    }
    return e;
  }



  int _xfIndexFor(XStyle s, XStyle cur, int baseIdx) {
    final key = '$baseIdx>${s.key}';
    final hit = _xfCache[key];
    if (hit != null) return hit;
    final root = z.xml('xl/styles.xml')!.rootElement;
    final xfs = _section(root, 'cellXfs');
    final fonts = _section(root, 'fonts');
    final fills = _section(root, 'fills');
    final borders = _section(root, 'borders');
    final xfList = xfs.findElements('xf', namespace: '*').toList();
    final base = baseIdx < xfList.length ? xfList[baseIdx] : (xfList.isNotEmpty ? xfList.first : null);
    final xf = base?.copy() ?? XmlElement(XmlName('xf'));

    // ---- font
    final fontList = fonts.findElements('font', namespace: '*').toList();
    final bf = int.tryParse(xf.getAttribute('fontId') ?? '0') ?? 0;
    final baseFont = bf < fontList.length ? fontList[bf] : (fontList.isNotEmpty ? fontList.first : null);
    final defFont = fontList.isNotEmpty ? fontList.first : null;
    final fontChanged = s.bold != cur.bold || s.italic != cur.italic || s.underline != cur.underline || s.strike != cur.strike || s.size != cur.size || s.color != cur.color || s.font != cur.font;
    if (fontChanged) {
      final f = XmlElement(XmlName('font'));
      if (s.bold) f.children.add(XmlElement(XmlName('b')));
      if (s.italic) f.children.add(XmlElement(XmlName('i')));
      if (s.strike) f.children.add(XmlElement(XmlName('strike')));
      if (s.underline) f.children.add(XmlElement(XmlName('u')));
      XmlElement? pick(String n) => s.size != null && n == 'sz' ? null : _child(defFont, n);
      f.children.add(s.size != null ? XmlElement(XmlName('sz'), [XmlAttribute(XmlName('val'), '${s.size}')]) : (pick('sz')?.copy() ?? XmlElement(XmlName('sz'), [XmlAttribute(XmlName('val'), '11')])));
      if (s.color != null) {
        f.children.add(XmlElement(XmlName('color'), [XmlAttribute(XmlName('rgb'), _rgbHex(s.color!))]));
      } else {
        final dc = _child(defFont, 'color');
        if (dc != null) f.children.add(dc.copy());
      }
      if (s.font.isNotEmpty) {
        f.children.add(XmlElement(XmlName('name'), [XmlAttribute(XmlName('val'), s.font)]));
      } else {
        final dn = _child(defFont, 'name');
        if (dn != null) f.children.add(dn.copy());
      }
      for (final extra in ['family', 'charset']) {
        final e = _child(s.font.isEmpty ? defFont : baseFont, extra);
        if (e != null && s.font.isEmpty) f.children.add(e.copy());
      }
      if (s.font.isEmpty) {
        final sc = _child(defFont, 'scheme');
        if (sc != null) f.children.add(sc.copy());
      }
      xf.setAttribute('fontId', '${_addUnique(fonts, 'font', f)}');
      xf.setAttribute('applyFont', '1');
    }

    // ---- fill
    if (s.fill != cur.fill) {
      if (s.fill == null) {
        xf.setAttribute('fillId', '0');
      } else {
        final fe = XmlElement(XmlName('fill'), [], [
          XmlElement(XmlName('patternFill'), [XmlAttribute(XmlName('patternType'), 'solid')], [
            XmlElement(XmlName('fgColor'), [XmlAttribute(XmlName('rgb'), _rgbHex(s.fill!))]),
            XmlElement(XmlName('bgColor'), [XmlAttribute(XmlName('indexed'), '64')]),
          ])
        ]);
        xf.setAttribute('fillId', '${_addUnique(fills, 'fill', fe)}');
      }
      xf.setAttribute('applyFill', '1');
    }

    // ---- border
    if (s.border != cur.border) {
      XmlElement side(String n, int bit) => (s.border & bit) != 0 ? XmlElement(XmlName(n), [XmlAttribute(XmlName('style'), 'thin')], [XmlElement(XmlName('color'), [XmlAttribute(XmlName('auto'), '1')])]) : XmlElement(XmlName(n));
      final be = XmlElement(XmlName('border'), [], [side('left', XBorder.left), side('right', XBorder.right), side('top', XBorder.top), side('bottom', XBorder.bottom), XmlElement(XmlName('diagonal'))]);
      xf.setAttribute('borderId', '${_addUnique(borders, 'border', be)}');
      xf.setAttribute('applyBorder', '1');
    }

    // ---- number format
    if (s.numFmt != cur.numFmt) {
      final code = s.numFmt;
      int id = 0;
      if (code.isNotEmpty && code != 'General') {
        final builtin = XNumFmt.builtIn.entries.where((e) => e.value == code && e.key != 0).firstOrNull;
        if (builtin != null) {
          id = builtin.key;
        } else {
          final nf = _section(root, 'numFmts', index: 0);
          final list = nf.findElements('numFmt', namespace: '*').toList();
          final found = list.where((e) => e.getAttribute('formatCode') == code).firstOrNull;
          if (found != null) {
            id = int.parse(found.getAttribute('numFmtId')!);
          } else {
            var maxId = 163;
            for (final e in list) {
              maxId = math.max(maxId, int.tryParse(e.getAttribute('numFmtId') ?? '') ?? 0);
            }
            id = maxId + 1;
            nf.children.add(XmlElement(XmlName('numFmt'), [XmlAttribute(XmlName('numFmtId'), '$id'), XmlAttribute(XmlName('formatCode'), code)]));
            nf.setAttribute('count', '${list.length + 1}');
          }
        }
      }
      xf.setAttribute('numFmtId', '$id');
      xf.setAttribute('applyNumberFormat', '1');
    }

    // ---- alignment
    if (s.h != cur.h || s.v != cur.v || s.wrap != cur.wrap || s.indent != cur.indent) {
      final old = _child(xf, 'alignment');
      final al = old?.copy() ?? XmlElement(XmlName('alignment'));
      void put(String a, String? v) {
        if (v == null || v.isEmpty) {
          al.removeAttribute(a);
        } else {
          al.setAttribute(a, v);
        }
      }

      put('horizontal', s.h);
      put('vertical', s.v);
      put('wrapText', s.wrap ? '1' : null);
      put('indent', s.indent > 0 ? '${s.indent}' : null);
      xf.children.removeWhere((e) => e is XmlElement && e.name.local == 'alignment');
      if (al.attributes.isNotEmpty) xf.children.insert(0, al);
      xf.setAttribute('applyAlignment', '1');
    }

    xfs.children.add(xf);
    final n = xfs.findElements('xf', namespace: '*').length;
    xfs.setAttribute('count', '$n');
    z.touch('xl/styles.xml');
    _xfCache[key] = n - 1;
    return n - 1;
  }

  /// Changes the style of every cell of [rg]: [change] receives the current style and returns the new one.
  void applyStyle(XSheet sh, XRange rg, XStyle Function(XStyle) change) {
    if (z.xml('xl/styles.xml') == null) return;
    var count = 0;
    for (final ref in rg.refs) {
      if (++count > 30000) break;
      final cur = sh.styles[ref] ?? XStyle.plain;
      final next = change(cur);
      if (next == cur) continue;
      final cell = _cellEl(sh, ref);
      final baseIdx = int.tryParse(cell.getAttribute('s') ?? '0') ?? 0;
      cell.setAttribute('s', '${_xfIndexFor(next, cur, baseIdx)}');
      if (next.isPlain) {
        sh.styles.remove(ref);
      } else {
        sh.styles[ref] = next;
      }
    }
    z.touch(sh.part);
  }

  // ==================================================================================================
  // Rows / columns / merges / freeze
  // ==================================================================================================


  void _writeCols(XSheet sh) {
    final root = sh.doc.rootElement;
    _removeWs(root, 'cols');
    final idx = <int>{...sh.colWidths.keys, ...sh.hiddenCols}.toList()..sort();
    if (idx.isEmpty) {
      z.touch(sh.part);
      return;
    }
    final cols = XmlElement(XmlName('cols'));
    for (final i in idx) {
      final w = sh.colWidths[i];
      cols.children.add(XmlElement(XmlName('col'), [
        XmlAttribute(XmlName('min'), '${i + 1}'),
        XmlAttribute(XmlName('max'), '${i + 1}'),
        XmlAttribute(XmlName('width'), ((w ?? sh.defColW) - 5) / 7 > 0 ? (((w ?? sh.defColW) - 5) / 7).toStringAsFixed(2) : '1'),
        if (w != null) XmlAttribute(XmlName('customWidth'), '1'),
        if (sh.hiddenCols.contains(i)) XmlAttribute(XmlName('hidden'), '1'),
      ]));
    }
    _placeWs(root, cols);
    z.touch(sh.part);
  }

  void _writeMerges(XSheet sh) {
    final root = sh.doc.rootElement;
    _removeWs(root, 'mergeCells');
    if (sh.merges.isNotEmpty) {
      final mc = XmlElement(XmlName('mergeCells'), [XmlAttribute(XmlName('count'), '${sh.merges.length}')]);
      for (final m in sh.merges) {
        mc.children.add(XmlElement(XmlName('mergeCell'), [XmlAttribute(XmlName('ref'), m.ref)]));
      }
      _placeWs(root, mc);
    }
    z.touch(sh.part);
  }

  void setColWidth(XSheet sh, Iterable<int> cols, double px) {
    for (final c in cols) {
      sh.colWidths[c] = px.clamp(16, 600).toDouble();
      sh.hiddenCols.remove(c);
    }
    _writeCols(sh);
  }

  void setRowHeight(XSheet sh, Iterable<int> rows, double px) {
    for (final r in rows) {
      final row = _rowEl(sh, r);
      sh.rowHeights[r] = px.clamp(8, 800).toDouble();
      row.setAttribute('ht', (sh.rowHeights[r]! * 72 / 96).toStringAsFixed(2));
      row.setAttribute('customHeight', '1');
      row.removeAttribute('hidden');
      sh.hiddenRows.remove(r);
    }
    z.touch(sh.part);
  }

  void resetRowHeight(XSheet sh, Iterable<int> rows) {
    for (final r in rows) {
      final row = _rowEl(sh, r);
      sh.rowHeights.remove(r);
      row.removeAttribute('ht');
      row.removeAttribute('customHeight');
    }
    z.touch(sh.part);
  }

  void setColsHidden(XSheet sh, Iterable<int> cols, bool hidden) {
    for (final c in cols) {
      if (hidden) {
        sh.hiddenCols.add(c);
      } else {
        sh.hiddenCols.remove(c);
      }
    }
    _writeCols(sh);
  }

  void setRowsHidden(XSheet sh, Iterable<int> rows, bool hidden) {
    for (final r in rows) {
      final row = _rowEl(sh, r);
      if (hidden) {
        row.setAttribute('hidden', '1');
        sh.hiddenRows.add(r);
      } else {
        row.removeAttribute('hidden');
        sh.hiddenRows.remove(r);
      }
    }
    z.touch(sh.part);
  }

  void mergeCells(XSheet sh, XRange rg) {
    if (rg.isCell) return;
    sh.merges.removeWhere((m) => m.intersects(rg));
    // keep the top-left value, clear the others (like Excel)
    for (final ref in rg.refs) {
      if (ref != refOf(rg.c1, rg.r1) && (sh.cells.containsKey(ref) || sh.formulas.containsKey(ref))) setCellRaw(sh, ref, '');
    }
    sh.merges.add(rg);
    _writeMerges(sh);
    recalculateAll();
  }

  void unmergeCells(XSheet sh, XRange rg) {
    sh.merges.removeWhere((m) => m.intersects(rg));
    _writeMerges(sh);
  }

  void setFreeze(XSheet sh, int cols, int rows) {
    sh.frozenCols = cols;
    sh.frozenRows = rows;
    final view = _child(_child(sh.doc.rootElement, 'sheetViews'), 'sheetView');
    if (view == null) return;
    view.children.removeWhere((e) => e is XmlElement && (e.name.local == 'pane' || e.name.local == 'selection'));
    if (cols > 0 || rows > 0) {
      final active = cols > 0 && rows > 0 ? 'bottomRight' : (rows > 0 ? 'bottomLeft' : 'topRight');
      view.children.insert(
          0,
          XmlElement(XmlName('pane'), [
            if (cols > 0) XmlAttribute(XmlName('xSplit'), '$cols'),
            if (rows > 0) XmlAttribute(XmlName('ySplit'), '$rows'),
            XmlAttribute(XmlName('topLeftCell'), refOf(cols, rows + 1)),
            XmlAttribute(XmlName('activePane'), active),
            XmlAttribute(XmlName('state'), 'frozen'),
          ]));
    }
    z.touch(sh.part);
  }

  void setSheetView(XSheet sh, {bool? rtl, bool? showGrid}) {
    final view = _child(_child(sh.doc.rootElement, 'sheetViews'), 'sheetView');
    if (view == null) return;
    if (rtl != null) {
      sh.rtl = rtl;
      if (rtl) {
        view.setAttribute('rightToLeft', '1');
      } else {
        view.removeAttribute('rightToLeft');
      }
    }
    if (showGrid != null) {
      sh.showGrid = showGrid;
      if (showGrid) {
        view.removeAttribute('showGridLines');
      } else {
        view.setAttribute('showGridLines', '0');
      }
    }
    z.touch(sh.part);
  }

  /// Called by shiftRows / shiftCols after the cells were moved: keeps merges, sizes and formulas consistent.
  void _afterShift(XSheet sh, {required bool rows, required int at, required int delta}) {
    // merges
    final ms = <XRange>[];
    for (final m in sh.merges) {
      var a = rows ? m.r1 : m.c1 + 1, b = rows ? m.r2 : m.c2 + 1;
      if (delta > 0) {
        if (a >= at) a += delta;
        if (b >= at) b += delta;
      } else {
        if (a == at && b == at) continue;
        if (a > at) a += delta;
        if (b >= at) b += delta;
      }
      ms.add(rows ? XRange(m.c1, a, m.c2, b) : XRange(a - 1, m.r1, b - 1, m.r2));
    }
    sh.merges
      ..clear()
      ..addAll(ms);
    _writeMerges(sh);
    if (rows) {
      _readRowAttrs(sh);
    } else {
      Map<int, T> shift<T>(Map<int, T> m) {
        final o = <int, T>{};
        m.forEach((k, v) {
          final p = k + 1;
          if (delta > 0) {
            o[p >= at ? k + 1 : k] = v;
          } else if (p != at) {
            o[p > at ? k - 1 : k] = v;
          }
        });
        return o;
      }

      final w = shift(sh.colWidths);
      sh.colWidths
        ..clear()
        ..addAll(w);
      final h = shift({for (final c in sh.hiddenCols) c: true}).keys.toSet();
      sh.hiddenCols
        ..clear()
        ..addAll(h);
      _writeCols(sh);
    }
    // formulas of every sheet that point into this one
    for (final other in sheets) {
      for (final ref in other.formulas.keys.toList()) {
        final f = other.formulas[ref]!;
        final nf = xlsxAdjustRefs(f, ownSheet: other.name, target: sh.name, rows: rows, at: at, delta: delta);
        if (nf != f) {
          other.formulas[ref] = nf;
          final fe = _child(_cellEl(other, ref), 'f');
          if (fe != null) {
            fe.children
              ..clear()
              ..add(XmlText(nf));
          }
          z.touch(other.part);
        }
      }
    }
    recalculateAll();
  }

  // ==================================================================================================
  // Clipboard, clear, fill
  // ==================================================================================================
  XClip copyRange(XSheet sh, XRange rg, {bool cut = false}) {
    final rows = <List<XClipCell>>[];
    for (var r = rg.r1; r <= rg.r2; r++) {
      final row = <XClipCell>[];
      for (var c = rg.c1; c <= rg.c2; c++) {
        final ref = refOf(c, r);
        final content = sh.formulas.containsKey(ref) ? '=${sh.formulas[ref]}' : (sh.cells[ref] ?? '');
        row.add(XClipCell(content, sh.styles[ref] ?? XStyle.plain));
      }
      rows.add(row);
    }
    return XClip(rg.rows, rg.cols, rows, cut, rg);
  }

  /// Plain text of a range (tab / newline separated) for the system clipboard and CSV.
  String rangeText(XSheet sh, XRange rg, {String sep = '\t'}) {
    final b = StringBuffer();
    for (var r = rg.r1; r <= rg.r2; r++) {
      final cells = <String>[];
      for (var c = rg.c1; c <= rg.c2; c++) {
        cells.add(displayText(sh, refOf(c, r)));
      }
      b.writeln(cells.join(sep));
    }
    return b.toString().trimRight();
  }

  /// [mode]: all, values, formulas, formats. [transpose] swaps rows and columns.
  XRange pasteClip(XSheet sh, int c0, int r0, XClip clip, {String mode = 'all', bool transpose = false}) {
    final rows = transpose ? clip.cols : clip.rows, cols = transpose ? clip.rows : clip.cols;
    final dc = c0 - clip.source.c1, dr = r0 - clip.source.r1;
    for (var r = 0; r < rows; r++) {
      for (var c = 0; c < cols; c++) {
        final src = transpose ? clip.cells[c][r] : clip.cells[r][c];
        final tc = c0 + c, tr = r0 + r;
        if (tc > 16383 || tr > 1048576) continue;
        final ref = refOf(tc, tr);
        if (mode != 'formats') {
          var content = src.content;
          if (content.startsWith('=')) {
            if (mode == 'values') {
              // pasted as the value the formula had
              final sref = refOf(clip.source.c1 + (transpose ? r : c), clip.source.r1 + (transpose ? c : r));
              content = sh.cells[sref] ?? '';
            } else {
              content = '=${xlsxShiftFormula(content.substring(1), transpose ? 0 : dc, transpose ? 0 : dr)}';
            }
          } else if (content.isNotEmpty && double.tryParse(content) == null && content.startsWith('=')) {
            content = "'$content";
          }
          setCellRaw(sh, ref, content);
        }
        if (mode != 'values' && mode != 'formulas') {
          final target = src.style;
          if ((sh.styles[ref] ?? XStyle.plain) != target) applyStyle(sh, XRange.cell(tc, tr), (_) => target);
        }
      }
    }
    if (clip.cut && mode == 'all') {
      final dest = XRange(c0, r0, c0 + cols - 1, r0 + rows - 1);
      for (final ref in clip.source.refs) {
        final pr = parseRef(ref)!;
        if (!dest.contains(pr.$1, pr.$2)) {
          setCellRaw(sh, ref, '');
          applyStyle(sh, XRange.cell(pr.$1, pr.$2), (_) => XStyle.plain);
        }
      }
    }
    recalculateAll();
    return XRange(c0, r0, c0 + cols - 1, r0 + rows - 1);
  }

  /// what: all, contents, formats.
  void clearRange(XSheet sh, XRange rg, {String what = 'all'}) {
    var n = 0;
    for (final ref in rg.refs) {
      if (++n > 30000) break;
      final pr = parseRef(ref)!;
      if (what != 'formats' && (sh.cells.containsKey(ref) || sh.formulas.containsKey(ref))) setCellRaw(sh, ref, '');
      if (what != 'contents' && sh.styles.containsKey(ref)) applyStyle(sh, XRange.cell(pr.$1, pr.$2), (_) => XStyle.plain);
    }
    recalculateAll();
  }

  /// Copies the first row (down) / column (right) of [rg] over the rest, shifting formulas.
  void fillRange(XSheet sh, XRange rg, {required bool down}) {
    if (down) {
      for (var c = rg.c1; c <= rg.c2; c++) {
        final seed = refOf(c, rg.r1);
        final content = sh.formulas.containsKey(seed) ? '=${sh.formulas[seed]}' : (sh.cells[seed] ?? '');
        final st = sh.styles[seed] ?? XStyle.plain;
        for (var r = rg.r1 + 1; r <= rg.r2; r++) {
          setCellRaw(sh, refOf(c, r), content.startsWith('=') ? '=${xlsxShiftFormula(content.substring(1), 0, r - rg.r1)}' : content);
          applyStyle(sh, XRange.cell(c, r), (_) => st);
        }
      }
    } else {
      for (var r = rg.r1; r <= rg.r2; r++) {
        final seed = refOf(rg.c1, r);
        final content = sh.formulas.containsKey(seed) ? '=${sh.formulas[seed]}' : (sh.cells[seed] ?? '');
        final st = sh.styles[seed] ?? XStyle.plain;
        for (var c = rg.c1 + 1; c <= rg.c2; c++) {
          setCellRaw(sh, refOf(c, r), content.startsWith('=') ? '=${xlsxShiftFormula(content.substring(1), c - rg.c1, 0)}' : content);
          applyStyle(sh, XRange.cell(c, r), (_) => st);
        }
      }
    }
    recalculateAll();
  }

  /// Linear series: the first two cells (or one cell, step 1) of every column / row define the step.
  void fillSeries(XSheet sh, XRange rg, {required bool down}) {
    final lines = down ? rg.cols : rg.rows;
    final len = down ? rg.rows : rg.cols;
    for (var l = 0; l < lines; l++) {
      String at(int i) => down ? refOf(rg.c1 + l, rg.r1 + i) : refOf(rg.c1 + i, rg.r1 + l);
      final a = sh.cells[at(0)] ?? '';
      final b = len > 1 ? (sh.cells[at(1)] ?? '') : '';
      final na = double.tryParse(a), nb = double.tryParse(b);
      final m = RegExp(r'^(.*?)(\d+)$').firstMatch(a);
      for (var i = 1; i < len; i++) {
        if (na != null) {
          final step = nb != null && len > 2 ? nb - na : 1.0;
          if (i == 1 && nb != null && len > 2) continue; // the second seed stays
          setCellRaw(sh, at(i), XNumFmt.general(na + step * i));
        } else if (m != null) {
          setCellRaw(sh, at(i), '${m[1]}${int.parse(m[2]!) + i}');
        } else {
          setCellRaw(sh, at(i), a);
        }
      }
    }
    recalculateAll();
  }

  // ==================================================================================================
  // Sort / filter / duplicates / text to columns / find & replace
  // ==================================================================================================
  int _cmpCells(XSheet sh, String ra, String rb, bool asc) {
    final a = cellValue(sh, ra), b = cellValue(sh, rb);
    final ea = a == null || a == '', eb = b == null || b == '';
    if (ea && eb) return 0;
    if (ea) return 1; // blanks always last
    if (eb) return -1;
    int c;
    if (a is num && b is num) {
      c = a.compareTo(b);
    } else if (a is num) {
      c = -1;
    } else if (b is num) {
      c = 1;
    } else {
      c = '$a'.toLowerCase().compareTo('$b'.toLowerCase());
    }
    return asc ? c : -c;
  }

  /// Sorts the rows of [rg] by the given key columns (absolute 0-based columns). [header] keeps the first row.
  void sortRange(XSheet sh, XRange rg, List<(int, bool)> keys, {bool header = true}) {
    final first = header ? rg.r1 + 1 : rg.r1;
    if (first >= rg.r2) return;
    final rows = <int>[for (var r = first; r <= rg.r2; r++) r];
    final data = {for (final r in rows) r: copyRange(sh, XRange(rg.c1, r, rg.c2, r))};
    final order = [...rows];
    order.sort((x, y) {
      for (final (col, asc) in keys) {
        final c = _cmpCells(sh, refOf(col, x), refOf(col, y), asc);
        if (c != 0) return c;
      }
      return x.compareTo(y);
    });
    for (var i = 0; i < rows.length; i++) {
      final src = data[order[i]]!.cells[0];
      final r = rows[i];
      for (var c = 0; c < src.length; c++) {
        final cell = src[c];
        var content = cell.content;
        if (content.startsWith('=')) content = '=${xlsxShiftFormula(content.substring(1), 0, r - order[i])}';
        setCellRaw(sh, refOf(rg.c1 + c, r), content);
        final st = cell.style;
        if ((sh.styles[refOf(rg.c1 + c, r)] ?? XStyle.plain) != st) applyStyle(sh, XRange.cell(rg.c1 + c, r), (_) => st);
      }
    }
    recalculateAll();
  }

  /// Distinct display values of a column inside a range (for the filter list).
  List<String> distinctValues(XSheet sh, XRange rg, int col, {bool header = true}) {
    final seen = <String>{};
    for (var r = header ? rg.r1 + 1 : rg.r1; r <= rg.r2; r++) {
      seen.add(displayText(sh, refOf(col, r)));
    }
    final l = seen.toList()..sort();
    return l;
  }

  void setAutoFilter(XSheet sh, XRange? rg) {
    sh.filter = rg;
    if (rg == null) {
      for (final r in sh.hiddenRows.toList()) {
        _rowEl(sh, r).removeAttribute('hidden');
      }
      sh.filterValues.clear();
      sh.hiddenRows.clear();
    }
    _writeAutoFilter(sh);
  }

  /// [allowed] == null removes the filter of the column.
  void setColumnFilter(XSheet sh, int col, Set<String>? allowed) {
    if (sh.filter == null) return;
    if (allowed == null) {
      sh.filterValues.remove(col);
    } else {
      sh.filterValues[col] = allowed;
    }
    final f = sh.filter!;
    for (var r = f.r1 + 1; r <= f.r2; r++) {
      var ok = true;
      sh.filterValues.forEach((c, vals) {
        if (!vals.contains(displayText(sh, refOf(c, r)))) ok = false;
      });
      final row = _rowEl(sh, r);
      if (ok) {
        row.removeAttribute('hidden');
        sh.hiddenRows.remove(r);
      } else {
        row.setAttribute('hidden', '1');
        sh.hiddenRows.add(r);
      }
    }
    _writeAutoFilter(sh);
  }

  void _writeAutoFilter(XSheet sh) {
    final root = sh.doc.rootElement;
    _removeWs(root, 'autoFilter');
    final f = sh.filter;
    if (f != null) {
      final af = XmlElement(XmlName('autoFilter'), [XmlAttribute(XmlName('ref'), f.ref)]);
      sh.filterValues.forEach((c, vals) {
        af.children.add(XmlElement(XmlName('filterColumn'), [XmlAttribute(XmlName('colId'), '${c - f.c1}')], [
          XmlElement(XmlName('filters'), [], [for (final v in vals) XmlElement(XmlName('filter'), [XmlAttribute(XmlName('val'), v)])])
        ]));
      });
      _placeWs(root, af);
    }
    z.touch(sh.part);
  }

  /// Removes rows of [rg] that repeat on all [cols]; returns how many were removed. The remaining rows move up.
  int removeDuplicates(XSheet sh, XRange rg, List<int> cols, {bool header = true}) {
    final first = header ? rg.r1 + 1 : rg.r1;
    final seen = <String>{};
    final keep = <XClip>[];
    var removed = 0;
    for (var r = first; r <= rg.r2; r++) {
      final k = cols.map((c) => displayText(sh, refOf(c, r)).toLowerCase()).join('\u0001');
      if (seen.add(k)) {
        keep.add(copyRange(sh, XRange(rg.c1, r, rg.c2, r)));
      } else {
        removed++;
      }
    }
    if (removed == 0) return 0;
    var r = first;
    for (final clip in keep) {
      pasteClip(sh, rg.c1, r, XClip(1, clip.cols, clip.cells, false, XRange(rg.c1, r, rg.c2, r)));
      r++;
    }
    for (; r <= rg.r2; r++) {
      clearRange(sh, XRange(rg.c1, r, rg.c2, r));
    }
    return removed;
  }

  /// Splits every cell of a one-column range by [delim] into the columns to its right.
  void splitColumn(XSheet sh, XRange rg, String delim) {
    if (delim.isEmpty) return;
    for (var r = rg.r1; r <= rg.r2; r++) {
      final src = sh.cells[refOf(rg.c1, r)] ?? '';
      final parts = src.split(delim);
      for (var i = 0; i < parts.length; i++) {
        setCellRaw(sh, refOf(rg.c1 + i, r), parts[i].trim());
      }
    }
    recalculateAll();
  }

  /// All cells whose text contains [q]. Returns (sheet index, ref).
  List<(int, String)> findAll(String q, {bool matchCase = false, bool wholeCell = false, bool inFormulas = false, int? onlySheet}) {
    final out = <(int, String)>[];
    if (q.isEmpty) return out;
    final needle = matchCase ? q : q.toLowerCase();
    for (var i = 0; i < sheets.length; i++) {
      if (onlySheet != null && onlySheet != i) continue;
      final sh = sheets[i];
      final keys = sh.cells.keys.toList()
        ..sort((a, b) {
          final pa = parseRef(a)!, pb = parseRef(b)!;
          return pa.$2 != pb.$2 ? pa.$2.compareTo(pb.$2) : pa.$1.compareTo(pb.$1);
        });
      for (final ref in keys) {
        var t = inFormulas && sh.formulas.containsKey(ref) ? '=${sh.formulas[ref]}' : displayText(sh, ref);
        if (!matchCase) t = t.toLowerCase();
        if (wholeCell ? t == needle : t.contains(needle)) out.add((i, ref));
      }
    }
    return out;
  }

  /// Replaces in the cell content; returns true when changed. Formulas are only touched with [inFormulas].
  bool replaceIn(XSheet sh, String ref, String q, String with_, {bool matchCase = false, bool wholeCell = false, bool inFormulas = false}) {
    final isF = sh.formulas.containsKey(ref);
    if (isF && !inFormulas) return false;
    final cur = isF ? '=${sh.formulas[ref]}' : (sh.cells[ref] ?? '');
    String next;
    if (wholeCell) {
      final same = matchCase ? cur == q : cur.toLowerCase() == q.toLowerCase();
      if (!same) return false;
      next = with_;
    } else {
      final re = RegExp(RegExp.escape(q), caseSensitive: matchCase);
      if (!re.hasMatch(cur)) return false;
      next = cur.replaceAll(re, with_);
    }
    setCellRaw(sh, ref, next);
    return true;
  }

  // ==================================================================================================
  // Named ranges
  // ==================================================================================================
  void setDefinedName(String name, String? refersTo) {
    final wb = z.xml('xl/workbook.xml')!;
    var dn = _child(wb.rootElement, 'definedNames');
    for (final e in (dn?.findElements('definedName', namespace: '*').toList() ?? const <XmlElement>[])) {
      if (e.getAttribute('name') == name && e.getAttribute('localSheetId') == null) dn!.children.remove(e);
    }
    if (refersTo != null) {
      if (dn == null) {
        dn = XmlElement(XmlName('definedNames'));
        // definedNames come right after sheets
        final sheetsEl = _child(wb.rootElement, 'sheets');
        final at = sheetsEl == null ? wb.rootElement.children.length : wb.rootElement.children.indexOf(sheetsEl) + 1;
        wb.rootElement.children.insert(at, dn);
      }
      dn.children.add(XmlElement(XmlName('definedName'), [XmlAttribute(XmlName('name'), name)], [XmlText(refersTo)]));
      definedNames[name] = refersTo;
    } else {
      definedNames.remove(name);
    }
    z.touch('xl/workbook.xml');
    recalculateAll();
  }
}
