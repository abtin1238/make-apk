import 'dart:math' as math;
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/physics.dart';
import 'package:flutter/scheduler.dart';
import '../core/office_prefs.dart';
import '../services/office_service.dart';
import 'xchart_paint.dart';

const double _headW = 46, _headH = 30;

class _Geom {
  final XSheet sh;
  final int cols, rows;
  late final List<double> cx; // cx[c] = left edge of column c (unscaled), length cols+1
  late final List<double> ry; // ry[r-1] = top of row r (unscaled), length rows+1
  _Geom(this.sh, this.cols, this.rows) {
    cx = List<double>.filled(cols + 1, 0);
    for (var c = 0; c < cols; c++) {
      cx[c + 1] = cx[c] + sh.colW(c);
    }
    ry = List<double>.filled(rows + 1, 0);
    for (var r = 1; r <= rows; r++) {
      ry[r] = ry[r - 1] + sh.rowH(r);
    }
  }
  double get w => cx.last;
  double get h => ry.last;
}

/// Index i such that prefix[i] <= v < prefix[i+1] (skips zero-width entries).
int _search(List<double> prefix, double v) {
  var lo = 0, hi = prefix.length - 2;
  if (hi < 0) return 0;
  while (lo < hi) {
    final mid = (lo + hi) >> 1;
    if (prefix[mid + 1] > v) {
      hi = mid;
    } else {
      lo = mid + 1;
    }
  }
  return lo;
}

enum _Drag { none, pan, handle, colResize, rowResize, range }

class XlsxCanvas extends StatefulWidget {
  final XlsxFile file;
  final XSheet sheet;
  final int version;
  final XRange sel;
  final int curC, curR;
  final double zoom;
  final bool showFormulas;
  final XChart? selectedChart;
  final int extraRows, extraCols;
  final void Function(int c, int r) onTapCell;
  final void Function(XRange range, int c, int r) onSelectRange;
  final void Function(int c, int r) onDoubleTapCell;
  final void Function(int c, int r) onLongPressCell;
  final void Function(bool isCol, int index) onLongPressHeader;
  final void Function(XChart? chart) onSelectChart;
  final void Function(XChart chart) onChartTapAgain;
  final void Function(int c) onFilterTap;
  final void Function(Set<int> cols, double px) onResizeCols;
  final void Function(Set<int> rows, double px) onResizeRows;
  final void Function(XRange range) onHandleDrag;
  final void Function(double zoom) onZoom;
  final void Function(bool rows, bool cols) onNeedMore;
  const XlsxCanvas({
    super.key,
    required this.file,
    required this.sheet,
    required this.version,
    required this.sel,
    required this.curC,
    required this.curR,
    required this.zoom,
    required this.showFormulas,
    required this.selectedChart,
    required this.extraRows,
    required this.extraCols,
    required this.onTapCell,
    required this.onSelectRange,
    required this.onDoubleTapCell,
    required this.onLongPressCell,
    required this.onLongPressHeader,
    required this.onSelectChart,
    required this.onChartTapAgain,
    required this.onFilterTap,
    required this.onResizeCols,
    required this.onResizeRows,
    required this.onHandleDrag,
    required this.onZoom,
    required this.onNeedMore,
  });

  @override
  State<XlsxCanvas> createState() => XlsxCanvasState();
}

class XlsxCanvasState extends State<XlsxCanvas> with SingleTickerProviderStateMixin {
  double _ox = 0, _oy = 0;
  Size _size = Size.zero;
  _Geom? _g;
  int _gVersion = -1, _gRows = -1, _gCols = -1;
  XSheet? _gSheet;
  final _tick = ValueNotifier<int>(0);
  late final Ticker _ticker;
  ClampingScrollSimulation? _simX, _simY;
  _Drag _drag = _Drag.none;
  double _z0 = 1;
  int _resizeIndex = -1;
  double _resizeStart = 0, _resizeValue = 0;
  Set<int> _resizeSet = {};
  Offset _lastPointer = Offset.zero;
  Offset _doubleTapAt = Offset.zero;
  XChart? _lastTappedChart;
  int _rangeAnchorC = 0, _rangeAnchorR = 1;
  bool _longMoved = false;
  final _tpCache = <int, TextPainter>{};

  double get _z => widget.zoom;
  bool get _rtl => widget.sheet.rtl;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker(_onFling);
  }

  @override
  void dispose() {
    _ticker.dispose();
    _tick.dispose();
    super.dispose();
  }

  void _repaint() => _tick.value++;

  _Geom get g {
    final sh = widget.sheet;
    final rows = math.min(1048576, math.max(200, sh.rows + 100) + widget.extraRows);
    final cols = math.min(16384, math.max(40, sh.cols + 10) + widget.extraCols);
    if (_g == null || _gSheet != sh || _gVersion != widget.version || _gRows != rows || _gCols != cols) {
      _g = _Geom(sh, cols, rows);
      _gSheet = sh;
      _gVersion = widget.version;
      _gRows = rows;
      _gCols = cols;
      _clamp();
    }
    return _g!;
  }

  @override
  void didUpdateWidget(covariant XlsxCanvas old) {
    super.didUpdateWidget(old);
    if (old.sheet != widget.sheet) {
      _ox = 0;
      _oy = 0;
    }
    if (old.zoom != widget.zoom) _clamp();
    _tpCache.clear();
  }

  int get _fc => math.min(widget.sheet.frozenCols, g.cols - 1);
  int get _fr => math.min(widget.sheet.frozenRows, g.rows - 1);

  double _maxOx() {
    final fcW = g.cx[_fc] * _z;
    return math.max(0.0, (g.w - g.cx[_fc]) - (_size.width - _headW - fcW) / _z + 120);
  }

  double _maxOy() {
    final frH = g.ry[_fr] * _z;
    return math.max(0.0, (g.h - g.ry[_fr]) - (_size.height - _headH - frH) / _z + 120);
  }

  void _clamp() {
    if (_size == Size.zero || _g == null) return;
    _ox = _ox.clamp(0.0, _maxOx()).toDouble();
    _oy = _oy.clamp(0.0, _maxOy()).toDouble();
  }

  // ------------------------------------------------------------------ geometry (screen space)
  Rect _mirror(double l, double t, double r, double b) => _rtl ? Rect.fromLTRB(_size.width - r, t, _size.width - l, b) : Rect.fromLTRB(l, t, r, b);

  double _lx(int c) {
    final fc = _fc;
    if (c < fc) return _headW + g.cx[c] * _z;
    return _headW + g.cx[fc] * _z + (g.cx[c] - g.cx[fc] - _ox) * _z;
  }

  double _ty(int r) {
    final fr = _fr;
    if (r <= fr) return _headH + g.ry[r - 1] * _z;
    return _headH + g.ry[fr] * _z + (g.ry[r - 1] - g.ry[fr] - _oy) * _z;
  }

  Rect _colSpan(int c1, int c2, double t, double b) => _mirror(_lx(c1), t, _lx(c2) + g.sh.colW(c2) * _z, b);

  Rect cellRect(int c, int r) {
    final cw = g.sh.colW(c) * _z, rh = g.sh.rowH(r) * _z;
    final l = _lx(c), t = _ty(r);
    return _mirror(l, t, l + cw, t + rh);
  }

  Rect blockRect(XRange m) {
    final l = _lx(m.c1), t = _ty(m.r1);
    var w = 0.0, h = 0.0;
    for (var c = m.c1; c <= m.c2; c++) {
      w += g.sh.colW(c) * _z;
    }
    for (var r = m.r1; r <= m.r2; r++) {
      h += g.sh.rowH(r) * _z;
    }
    return _mirror(l, t, l + w, t + h);
  }

  Rect chartRect(XChart ch) {
    final l = _lx(ch.c1), t = _ty(ch.r1 + 1);
    final r = _lx(ch.c2), b = _ty(ch.r2 + 1);
    return _mirror(math.min(l, r), math.min(t, b), math.max(l, r), math.max(t, b));
  }

  Rect get _bodyClip => _mirror(_headW, _headH, _size.width, _size.height);

  /// Scrolls so that the cell is fully visible.
  void ensureVisible(int c, int r) {
    if (_size == Size.zero) return;
    final gg = g;
    final fc = _fc, fr = _fr;
    if (c >= fc) {
      final viewW = (_size.width - _headW - gg.cx[fc] * _z) / _z;
      final left = gg.cx[c] - gg.cx[fc], right = left + gg.sh.colW(c);
      if (left < _ox) _ox = left;
      if (right > _ox + viewW) _ox = right - viewW;
    }
    if (r > fr) {
      final viewH = (_size.height - _headH - gg.ry[fr] * _z) / _z;
      final top = gg.ry[r - 1] - gg.ry[fr], bottom = top + gg.sh.rowH(r);
      if (top < _oy) _oy = top;
      if (bottom > _oy + viewH) _oy = bottom - viewH;
    }
    _clamp();
    _repaint();
  }

  void resetScroll() {
    _ox = 0;
    _oy = 0;
    _repaint();
  }

  // ------------------------------------------------------------------ hit testing
  (int, int)? _cellAt(Offset p) {
    final gg = g;
    final x = _rtl ? _size.width - p.dx : p.dx;
    final y = p.dy;
    if (x < _headW || y < _headH) return null;
    final fc = _fc, fr = _fr;
    final fx = x - _headW, fy = y - _headH;
    final c = fx < gg.cx[fc] * _z ? _search(gg.cx, fx / _z) : _search(gg.cx, (fx - gg.cx[fc] * _z) / _z + gg.cx[fc] + _ox);
    final r1 = fy < gg.ry[fr] * _z ? _search(gg.ry, fy / _z) : _search(gg.ry, (fy - gg.ry[fr] * _z) / _z + gg.ry[fr] + _oy);
    return (c.clamp(0, gg.cols - 1), r1.clamp(0, gg.rows - 1) + 1);
  }

  /// 'corner' | 'col:<i>' | 'row:<i>' | null
  String? _headerAt(Offset p) {
    final x = _rtl ? _size.width - p.dx : p.dx;
    if (x < _headW && p.dy < _headH) return 'corner';
    if (p.dy < _headH && x >= _headW) {
      final c = _cellAt(Offset(p.dx, _headH + 1));
      return c == null ? null : 'col:${c.$1}';
    }
    if (x < _headW && p.dy >= _headH) {
      final c = _cellAt(Offset(_rtl ? _size.width - _headW - 1 : _headW + 1, p.dy));
      return c == null ? null : 'row:${c.$2}';
    }
    return null;
  }

  /// Column whose right edge is near [p] in the header strip (for resizing), or -1.
  int _colEdgeAt(Offset p) {
    if (p.dy >= _headH) return -1;
    final x = _rtl ? _size.width - p.dx : p.dx;
    if (x < _headW) return -1;
    final c0 = _cellAt(Offset(p.dx, _headH + 1));
    if (c0 == null) return -1;
    for (final c in [c0.$1 - 1, c0.$1, c0.$1 + 1]) {
      if (c < 0 || c >= g.cols) continue;
      final edge = _lx(c) + g.sh.colW(c) * _z;
      if ((edge - x).abs() < 12 && g.sh.colW(c) > 0) return c;
    }
    return -1;
  }

  int _rowEdgeAt(Offset p) {
    final x = _rtl ? _size.width - p.dx : p.dx;
    if (x >= _headW || p.dy < _headH) return -1;
    final r0 = _cellAt(Offset(_rtl ? _size.width - _headW - 1 : _headW + 1, p.dy));
    if (r0 == null) return -1;
    for (final r in [r0.$2 - 1, r0.$2, r0.$2 + 1]) {
      if (r < 1 || r > g.rows) continue;
      final edge = _ty(r) + g.sh.rowH(r) * _z;
      if ((edge - p.dy).abs() < 12 && g.sh.rowH(r) > 0) return r;
    }
    return -1;
  }

  Rect? _handleRect() {
    final s = widget.sel;
    final cell = cellRect(s.c2, s.r2);
    final p = Offset(_rtl ? cell.left : cell.right, cell.bottom);
    return Rect.fromCenter(center: p, width: 44, height: 44);
  }

  XChart? _chartAt(Offset p) {
    for (final ch in widget.sheet.charts.reversed) {
      if (chartRect(ch).contains(p) && _bodyClip.contains(p)) return ch;
    }
    return null;
  }

  // ------------------------------------------------------------------ gestures
  void _onTapUp(TapUpDetails d) {
    final p = d.localPosition;
    final h = _headerAt(p);
    final sh = widget.sheet;
    if (h != null) {
      if (h == 'corner') {
        widget.onSelectRange(XRange(0, 1, g.cols - 1, g.rows), 0, 1);
      } else if (h.startsWith('col:')) {
        final c = int.parse(h.substring(4));
        widget.onSelectRange(XRange(c, 1, c, g.rows), c, 1);
      } else {
        final r = int.parse(h.substring(4));
        widget.onSelectRange(XRange(0, r, g.cols - 1, r), 0, r);
      }
      return;
    }
    final ch = _chartAt(p);
    if (ch != null) {
      if (identical(ch, widget.selectedChart)) {
        widget.onChartTapAgain(ch);
      } else {
        widget.onSelectChart(ch);
      }
      return;
    }
    if (widget.selectedChart != null) widget.onSelectChart(null);
    final cell = _cellAt(p);
    if (cell == null) return;
    // filter drop-down buttons
    final f = sh.filter;
    if (f != null && cell.$2 == f.r1 && cell.$1 >= f.c1 && cell.$1 <= f.c2) {
      final r = cellRect(cell.$1, cell.$2);
      final btn = Rect.fromLTWH(_rtl ? r.left : r.right - 30, r.top, 30, r.height);
      if (btn.contains(p)) {
        widget.onFilterTap(cell.$1);
        return;
      }
    }
    final m = sh.mergeAt(cell.$1, cell.$2);
    if (m != null) {
      widget.onSelectRange(m, m.c1, m.r1);
    } else {
      widget.onTapCell(cell.$1, cell.$2);
    }
  }

  void _onDoubleTap() {
    final cell = _cellAt(_doubleTapAt);
    if (cell == null || _headerAt(_doubleTapAt) != null) return;
    final m = widget.sheet.mergeAt(cell.$1, cell.$2);
    widget.onDoubleTapCell(m?.c1 ?? cell.$1, m?.r1 ?? cell.$2);
  }

  void _onLongPressStart(LongPressStartDetails d) {
    final h = _headerAt(d.localPosition);
    if (h != null && h != 'corner') {
      widget.onLongPressHeader(h.startsWith('col:'), int.parse(h.substring(4)));
      _drag = _Drag.none;
      return;
    }
    final cell = _cellAt(d.localPosition);
    if (cell == null) return;
    _drag = _Drag.range;
    _longMoved = false;
    _rangeAnchorC = cell.$1;
    _rangeAnchorR = cell.$2;
    _lastPointer = d.localPosition;
  }

  void _onLongPressMove(LongPressMoveUpdateDetails d) {
    if (_drag != _Drag.range) return;
    _lastPointer = d.localPosition;
    _extendTo(d.localPosition);
  }

  void _extendTo(Offset p) {
    // auto-scroll near the edges
    var dx = 0.0, dy = 0.0;
    if (p.dy > _size.height - 40) dy = 14;
    if (p.dy < _headH + 30) dy = -14;
    final x = _rtl ? _size.width - p.dx : p.dx;
    if (x > _size.width - 40) dx = 14;
    if (x < _headW + 30) dx = -14;
    if (dx != 0 || dy != 0) {
      _ox = (_ox + dx / _z).clamp(0.0, _maxOx()).toDouble();
      _oy = (_oy + dy / _z).clamp(0.0, _maxOy()).toDouble();
    }
    final cell = _cellAt(Offset(p.dx.clamp(_rtl ? 0.0 : _headW + 1, _rtl ? _size.width - _headW - 1 : _size.width - 1).toDouble(), p.dy.clamp(_headH + 1, _size.height - 1).toDouble()));
    if (cell == null) return;
    if (cell.$1 != _rangeAnchorC || cell.$2 != _rangeAnchorR) _longMoved = true;
    widget.onSelectRange(XRange.of(_rangeAnchorC, _rangeAnchorR, cell.$1, cell.$2), _rangeAnchorC, _rangeAnchorR);
  }

  void _onLongPressEnd(LongPressEndDetails d) {
    if (_drag == _Drag.range && !_longMoved) widget.onLongPressCell(_rangeAnchorC, _rangeAnchorR);
    _drag = _Drag.none;
  }

  void _onScaleStart(ScaleStartDetails d) {
    _ticker.stop();
    _z0 = _z;
    _lastPointer = d.localFocalPoint;
    _drag = _Drag.pan;
    if (d.pointerCount == 1) {
      final p = d.localFocalPoint;
      final ce = _colEdgeAt(p);
      final re = _rowEdgeAt(p);
      if (ce >= 0) {
        _drag = _Drag.colResize;
        _resizeIndex = ce;
        _resizeStart = p.dx;
        _resizeValue = g.sh.colW(ce);
        final s = widget.sel;
        _resizeSet = (s.c1 <= ce && s.c2 >= ce && s.r1 == 1 && s.r2 >= g.rows) ? {for (var c = s.c1; c <= s.c2; c++) c} : {ce};
      } else if (re >= 1) {
        _drag = _Drag.rowResize;
        _resizeIndex = re;
        _resizeStart = p.dy;
        _resizeValue = g.sh.rowH(re);
        final s = widget.sel;
        _resizeSet = (s.r1 <= re && s.r2 >= re && s.c1 == 0 && s.c2 >= g.cols - 1) ? {for (var r = s.r1; r <= s.r2; r++) r} : {re};
      } else if (_handleRect()?.contains(p) == true && _bodyClip.contains(p)) {
        _drag = _Drag.handle;
        // the anchor stays at the active cell
        _rangeAnchorC = widget.curC;
        _rangeAnchorR = widget.curR;
      }
    }
  }

  void _onScaleUpdate(ScaleUpdateDetails d) {
    if (d.pointerCount >= 2) {
      _drag = _Drag.pan;
      widget.onZoom((_z0 * d.scale).clamp(0.5, 3.0).toDouble());
      return;
    }
    switch (_drag) {
      case _Drag.colResize:
        final dx = (_rtl ? -1 : 1) * (d.localFocalPoint.dx - _resizeStart) / _z;
        _tempColW = math.max(16.0, _resizeValue + dx);
        _tempCols = _resizeSet;
        _repaint();
      case _Drag.rowResize:
        _tempRowH = math.max(8.0, _resizeValue + (d.localFocalPoint.dy - _resizeStart) / _z);
        _tempRows = _resizeSet;
        _repaint();
      case _Drag.handle:
        final cell = _cellAt(Offset(d.localFocalPoint.dx.clamp(_headW + 1, _size.width - 1).toDouble(), d.localFocalPoint.dy.clamp(_headH + 1, _size.height - 1).toDouble()));
        if (cell != null) widget.onHandleDrag(XRange.of(_rangeAnchorC, _rangeAnchorR, cell.$1, cell.$2));
      case _Drag.range:
        break;
      default:
        final delta = d.localFocalPoint - _lastPointer;
        _lastPointer = d.localFocalPoint;
        _ox -= (_rtl ? -delta.dx : delta.dx) / _z;
        _oy -= delta.dy / _z;
        _clamp();
        _checkMore();
        _repaint();
    }
  }

  double? _tempColW, _tempRowH;
  Set<int> _tempCols = {}, _tempRows = {};

  void _onScaleEnd(ScaleEndDetails d) {
    if (_drag == _Drag.colResize && _tempColW != null) {
      widget.onResizeCols(_tempCols, _tempColW!);
    } else if (_drag == _Drag.rowResize && _tempRowH != null) {
      widget.onResizeRows(_tempRows, _tempRowH!);
    } else if (_drag == _Drag.pan && d.pointerCount == 0) {
      final v = d.velocity.pixelsPerSecond;
      if (v.distance > 200) {
        final vx = (_rtl ? v.dx : -v.dx) / _z, vy = -v.dy / _z;
        _simX = ClampingScrollSimulation(position: _ox, velocity: vx);
        _simY = ClampingScrollSimulation(position: _oy, velocity: vy);
        if (!_ticker.isActive) _ticker.start();
      }
    }
    _tempColW = null;
    _tempRowH = null;
    _tempCols = {};
    _tempRows = {};
    if (_drag != _Drag.range) _drag = _Drag.none;
  }

  void _onFling(Duration elapsed) {
    final t = elapsed.inMicroseconds / 1e6;
    final sx = _simX, sy = _simY;
    if (sx == null || sy == null) {
      _ticker.stop();
      return;
    }
    _ox = sx.x(t);
    _oy = sy.x(t);
    _clamp();
    _checkMore();
    _repaint();
    if (sx.isDone(t) && sy.isDone(t)) _ticker.stop();
  }

  void _checkMore() {
    final needRows = _oy > _maxOy() - 300;
    final needCols = _ox > _maxOx() - 300;
    if (needRows || needCols) widget.onNeedMore(needRows, needCols);
  }

  // ------------------------------------------------------------------ build
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final ns = Size(box.maxWidth, box.maxHeight);
      if (ns != _size) {
        _size = ns;
        _clamp();
      }
      final _ = g; // make sure geometry is current
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: _onTapUp,
        onDoubleTapDown: (d) => _doubleTapAt = d.localPosition,
        onDoubleTap: _onDoubleTap,
        onLongPressStart: _onLongPressStart,
        onLongPressMoveUpdate: _onLongPressMove,
        onLongPressEnd: _onLongPressEnd,
        onScaleStart: _onScaleStart,
        onScaleUpdate: _onScaleUpdate,
        onScaleEnd: _onScaleEnd,
        child: ClipRect(child: CustomPaint(size: ns, painter: _SheetPainter(this, _tick))),
      );
    });
  }

  // ------------------------------------------------------------------ painting helpers
  TextPainter _tp(String text, TextStyle style, TextDirection dir, double? maxW, {int? maxLines}) {
    final key = Object.hash(text, style.fontSize, style.fontWeight, style.fontStyle, style.color, style.fontFamily, style.decoration, dir, maxW?.round(), maxLines);
    final hit = _tpCache[key];
    if (hit != null) return hit;
    if (_tpCache.length > 1500) _tpCache.clear();
    final tp = TextPainter(text: TextSpan(text: text, style: style), textDirection: dir, maxLines: maxLines, ellipsis: maxLines == null ? null : '…')..layout(maxWidth: maxW ?? double.infinity);
    return _tpCache[key] = tp;
  }
}

bool _isArabic(String s) => RegExp(r'[\u0590-\u08FF\uFB50-\uFEFF]').hasMatch(s);

class _SheetPainter extends CustomPainter {
  final XlsxCanvasState s;
  _SheetPainter(this.s, Listenable repaint) : super(repaint: repaint);

  XlsxFile get file => s.widget.file;
  XSheet get sh => s.widget.sheet;
  double get z => s.widget.zoom;

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;

  @override
  void paint(Canvas canvas, Size size) {
    final g = s.g;
    final bg = OfficePrefs.c('cell');
    canvas.drawRect(Offset.zero & size, Paint()..color = bg);
    final fc = s._fc, fr = s._fr;
    // visible scrolling ranges
    final firstC = math.max(fc, _search(g.cx, g.cx[fc] + s._ox));
    var lastC = firstC;
    while (lastC < g.cols - 1 && s._lx(lastC) < size.width) {
      lastC++;
    }
    final firstR = math.max(fr + 1, _search(g.ry, g.ry[fr] + s._oy) + 1);
    var lastR = firstR;
    while (lastR < g.rows && s._ty(lastR) < size.height) {
      lastR++;
    }
    final frozenR = s._mirror(_headW + g.cx[fc] * z, _headH + g.ry[fr] * z, size.width, size.height); // scroll area
    // regions: scroll, frozen cols, frozen rows, corner
    _region(canvas, firstC, lastC, firstR, lastR, frozenR, bg);
    if (fc > 0) _region(canvas, 0, fc - 1, firstR, lastR, s._mirror(_headW, _headH + g.ry[fr] * z, _headW + g.cx[fc] * z, size.height), bg);
    if (fr > 0) _region(canvas, firstC, lastC, 1, fr, s._mirror(_headW + g.cx[fc] * z, _headH, size.width, _headH + g.ry[fr] * z), bg);
    if (fc > 0 && fr > 0) _region(canvas, 0, fc - 1, 1, fr, s._mirror(_headW, _headH, _headW + g.cx[fc] * z, _headH + g.ry[fr] * z), bg);
    // freeze separator
    final sep = Paint()
      ..color = OfficePrefs.c('green')
      ..strokeWidth = 1.6;
    if (fc > 0) {
      final x = s._mirror(_headW + g.cx[fc] * z, 0, _headW + g.cx[fc] * z, 0).left;
      canvas.drawLine(Offset(x, _headH), Offset(x, size.height), sep);
    }
    if (fr > 0) {
      final y = _headH + g.ry[fr] * z;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), sep);
    }
    // charts
    canvas.save();
    canvas.clipRect(s._bodyClip);
    for (final ch in sh.charts) {
      final r = s.chartRect(ch);
      if (r.right < 0 || r.left > size.width || r.bottom < 0 || r.top > size.height) continue;
      paintXChart(canvas, r, ch, bg: bg, ink: OfficePrefs.c('cellInk'), line: OfficePrefs.c('line'), selected: identical(ch, s.widget.selectedChart));
    }
    // selection
    _selection(canvas);
    canvas.restore();
    _headers(canvas, size, firstC, lastC, firstR, lastR);
  }

  void _region(Canvas canvas, int c0, int c1, int r0, int r1, Rect clip, Color bg) {
    if (clip.width <= 0 || clip.height <= 0 || c1 < c0 || r1 < r0) return;
    canvas.save();
    canvas.clipRect(clip);
    canvas.drawRect(clip, Paint()..color = bg);
    if (sh.showGrid) {
      final line = Paint()
        ..color = OfficePrefs.c('line')
        ..strokeWidth = 1;
      final top = s._ty(r0), bottom = s._ty(r1) + sh.rowH(r1) * z;
      for (var c = c0; c <= c1; c++) {
        final cr = s.cellRect(c, r0);
        final x = s._rtl ? cr.left : cr.right;
        canvas.drawLine(Offset(x, top), Offset(x, bottom), line);
      }
      final l = s.cellRect(c0, r0), rr = s.cellRect(c1, r0);
      final xl = math.min(l.left, rr.left), xr = math.max(l.right, rr.right);
      for (var r = r0; r <= r1; r++) {
        final y = s._ty(r) + sh.rowH(r) * z;
        canvas.drawLine(Offset(xl, y), Offset(xr, y), line);
      }
    }
    for (var r = r0; r <= r1; r++) {
      if (sh.rowH(r) == 0) continue;
      for (var c = c0; c <= c1; c++) {
        if (sh.colW(c) == 0) continue;
        if (sh.mergeAt(c, r) != null) continue;
        _cell(canvas, s.cellRect(c, r), c, r, bg);
      }
    }
    for (final m in sh.merges) {
      if (m.c2 < c0 || m.c1 > c1 || m.r2 < r0 || m.r1 > r1) continue;
      final rect = s.blockRect(m);
      canvas.drawRect(rect, Paint()..color = bg);
      if (sh.showGrid) {
        canvas.drawRect(
            rect,
            Paint()
              ..color = OfficePrefs.c('line')
              ..style = PaintingStyle.stroke);
      }
      _cell(canvas, rect, m.c1, m.r1, bg, merged: m);
    }
    // filter buttons
    final f = sh.filter;
    if (f != null && f.r1 >= r0 && f.r1 <= r1) {
      for (var c = math.max(c0, f.c1); c <= math.min(c1, f.c2); c++) {
        final r = s.cellRect(c, f.r1);
        final btn = Rect.fromLTWH(s._rtl ? r.left + 3 : r.right - 25, r.center.dy - 11, 22, 22);
        final active = sh.filterValues.containsKey(c);
        canvas.drawRRect(RRect.fromRectAndRadius(btn, const Radius.circular(4)), Paint()..color = active ? OfficePrefs.c('green') : OfficePrefs.c('head'));
        final path = Path()
          ..moveTo(btn.center.dx - 5, btn.center.dy - 2)
          ..lineTo(btn.center.dx + 5, btn.center.dy - 2)
          ..lineTo(btn.center.dx, btn.center.dy + 4)
          ..close();
        canvas.drawPath(path, Paint()..color = active ? Colors.white : OfficePrefs.c('ink'));
      }
    }
    canvas.restore();
  }

  void _cell(Canvas canvas, Rect rect, int c, int r, Color bg, {XRange? merged}) {
    final ref = refOf(c, r);
    final st = sh.styles[ref];
    final cond = file.condFormat(sh, c, r);
    final fill = cond?.fill ?? st?.fill;
    if (fill != null) canvas.drawRect(rect, Paint()..color = Color(0xFF000000 | fill));
    final ink = OfficePrefs.c('cellInk');
    final bits = st?.border ?? 0;
    if (bits != 0) {
      final p = Paint()
        ..color = ink
        ..strokeWidth = 1.4;
      final lBit = s._rtl ? XBorder.right : XBorder.left, rBit = s._rtl ? XBorder.left : XBorder.right;
      if (bits & lBit != 0) canvas.drawLine(rect.topLeft, rect.bottomLeft, p);
      if (bits & rBit != 0) canvas.drawLine(rect.topRight, rect.bottomRight, p);
      if (bits & XBorder.top != 0) canvas.drawLine(rect.topLeft, rect.topRight, p);
      if (bits & XBorder.bottom != 0) canvas.drawLine(rect.bottomLeft, rect.bottomRight, p);
    }
    final raw = sh.cells[ref];
    if (raw == null || raw.isEmpty) return;
    final isF = sh.formulas.containsKey(ref);
    final text = s.widget.showFormulas && isF ? '=${sh.formulas[ref]}' : file.displayText(sh, ref);
    if (text.isEmpty) return;
    final value = file.cellValue(sh, ref);
    final isNum = value is num && !(s.widget.showFormulas && isF);
    final isErr = value is String && XlsxFormulaEngine.errors.contains(value);
    final size = (st?.size ?? 11) * 1.3 * z;
    var color = cond?.color != null ? Color(0xFF000000 | cond!.color!) : (st?.color != null ? Color(0xFF000000 | st!.color!) : ink);
    if (isErr) color = const Color(0xFFD13438);
    // text color on dark fills stays as chosen; auto-contrast only when no explicit colour is set
    if (st?.color == null && cond?.color == null && fill != null && !isErr) {
      color = ((fill >> 16) & 255) * 0.299 + ((fill >> 8) & 255) * 0.587 + (fill & 255) * 0.114 < 140 ? Colors.white : const Color(0xFF1B1B1B);
    }
    final style = TextStyle(
      fontSize: size,
      color: color,
      fontWeight: (st?.bold == true || cond?.bold == true) ? FontWeight.w700 : FontWeight.w400,
      fontStyle: st?.italic == true ? FontStyle.italic : FontStyle.normal,
      fontFamily: (st?.font ?? '').isEmpty ? null : st!.font,
      decoration: TextDecoration.combine([if (st?.underline == true) TextDecoration.underline, if (st?.strike == true) TextDecoration.lineThrough]),
      height: 1.15,
    );
    final dir = _isArabic(text) ? TextDirection.rtl : TextDirection.ltr;
    final wrap = st?.wrap == true;
    final pad = 4.0 + (st?.indent ?? 0) * 8 * z;
    String h = st?.h ?? '';
    if (h.isEmpty) h = isNum ? (s._rtl ? 'left' : 'right') : (isErr ? 'center' : (s._rtl ? 'right' : 'left'));
    if (value is bool) h = 'center';
    final innerW = math.max(4.0, rect.width - pad - 4);
    TextPainter tp;
    var clip = rect;
    if (wrap) {
      tp = s._tp(text, style, dir, innerW);
    } else {
      tp = s._tp(text, style, dir, null, maxLines: 1);
      if (isNum && tp.width > innerW) {
        tp = s._tp('#' * math.max(1, (innerW / (size * 0.6)).floor()), style, TextDirection.ltr, null, maxLines: 1);
      } else if (tp.width > innerW && h != 'center') {
        // overflow into empty neighbours (like Excel)
        final step = (h == 'left') == !s._rtl ? 1 : -1;
        var extra = 0.0;
        var cc = c + (merged == null ? 0 : (step > 0 ? merged.c2 - merged.c1 : 0));
        for (var k = 0; k < 12 && extra + innerW < tp.width; k++) {
          cc += step;
          if (cc < 0 || cc >= s.g.cols || sh.cells.containsKey(refOf(cc, r)) || sh.mergeAt(cc, r) != null) break;
          extra += sh.colW(cc) * z;
        }
        if (extra > 0) {
          clip = h == 'left' ? Rect.fromLTRB(rect.left, rect.top, rect.right + extra, rect.bottom) : Rect.fromLTRB(rect.left - extra, rect.top, rect.right, rect.bottom);
        }
      }
    }
    final textW = tp.width, textH = tp.height;
    double x;
    switch (h) {
      case 'center':
        x = rect.left + (rect.width - textW) / 2;
      case 'right':
        x = rect.right - textW - (s._rtl ? 4 : pad);
      case 'justify':
        x = rect.left + pad;
      default:
        x = rect.left + (s._rtl ? 4 : pad);
    }
    if (h == 'left' && !wrap && textW > innerW && clip == rect) x = rect.left + pad;
    final double y;
    switch (st?.v ?? '') {
      case 'top':
        y = rect.top + 2;
      case 'bottom':
        y = rect.bottom - textH - 2;
      default:
        y = wrap && textH > rect.height ? rect.top + 1 : rect.top + (rect.height - textH) / 2;
    }
    canvas.save();
    canvas.clipRect(clip);
    tp.paint(canvas, Offset(x, y));
    canvas.restore();
  }

  void _selection(Canvas canvas) {
    final sel = s.widget.sel;
    final sc = OfficePrefs.c('green');
    final tl = s.cellRect(sel.c1, sel.r1), br = s.cellRect(sel.c2, sel.r2);
    final rect = Rect.fromLTRB(math.min(tl.left, br.left), math.min(tl.top, br.top), math.max(tl.right, br.right), math.max(tl.bottom, br.bottom));
    final multi = !sel.isCell && sh.mergeAt(sel.c1, sel.r1) != sel;
    if (multi) {
      canvas.drawRect(rect, Paint()..color = sc.withAlpha(36));
      final cur = s.cellRect(s.widget.curC, s.widget.curR);
      canvas.drawRect(cur, Paint()..color = OfficePrefs.c('cell').withAlpha(150));
      canvas.drawRect(
          cur,
          Paint()
            ..color = sc
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.5);
    }
    canvas.drawRect(
        rect,
        Paint()
          ..color = sc
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.4);
    final end = s.cellRect(sel.c2, sel.r2);
    final hp = Offset(s._rtl ? end.left : end.right, end.bottom);
    canvas.drawCircle(hp, 7, Paint()..color = Colors.white);
    canvas.drawCircle(hp, 5, Paint()..color = sc);
    // validation arrow of the active cell
    final v = file.validationAt(sh, s.widget.curC, s.widget.curR);
    if (v != null && v.type == 'list' && v.dropdown) {
      final c = s.cellRect(s.widget.curC, s.widget.curR);
      final b = Rect.fromLTWH(s._rtl ? c.left : c.right - 24, c.top + 2, 22, math.max(10.0, c.height - 4));
      canvas.drawRect(b, Paint()..color = OfficePrefs.c('head'));
      final path = Path()
        ..moveTo(b.center.dx - 5, b.center.dy - 2)
        ..lineTo(b.center.dx + 5, b.center.dy - 2)
        ..lineTo(b.center.dx, b.center.dy + 4)
        ..close();
      canvas.drawPath(path, Paint()..color = OfficePrefs.c('ink'));
    }
  }

  void _headers(Canvas canvas, Size size, int firstC, int lastC, int firstR, int lastR) {
    final g = s.g;
    final head = OfficePrefs.c('head'), ink = OfficePrefs.c('ink'), line = OfficePrefs.c('line'), green = OfficePrefs.c('green');
    final sel = s.widget.sel;
    final fc = s._fc, fr = s._fr;
    final fill = Paint()..color = head;
    final stroke = Paint()
      ..color = line
      ..strokeWidth = 1;
    void label(String t, Rect r, bool active) {
      canvas.drawRect(r, Paint()..color = active ? green.withAlpha(50) : head);
      canvas.drawRect(
          r,
          stroke
            ..style = PaintingStyle.stroke);
      final tp = TextPainter(
        text: TextSpan(text: t, style: TextStyle(fontSize: 12.5, color: active ? green : ink, fontWeight: active ? FontWeight.w700 : FontWeight.w500)),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: math.max(4.0, r.width));
      tp.paint(canvas, Offset(r.center.dx - tp.width / 2, r.center.dy - tp.height / 2));
    }

    // column header strip (scrolling columns first, frozen ones on top)
    final scrollCols = s._mirror(_headW + g.cx[fc] * z, 0, size.width, _headH);
    canvas.save();
    canvas.clipRect(s._mirror(_headW, 0, size.width, _headH));
    canvas.drawRect(s._mirror(_headW, 0, size.width, _headH), fill);
    canvas.save();
    canvas.clipRect(scrollCols);
    for (var c = firstC; c <= lastC; c++) {
      if (sh.colW(c) == 0) continue;
      final cr = s.cellRect(c, 1);
      label(colName(c), Rect.fromLTRB(cr.left, 0, cr.right, _headH), c >= sel.c1 && c <= sel.c2);
    }
    canvas.restore();
    for (var c = 0; c < fc; c++) {
      if (sh.colW(c) == 0) continue;
      final cr = s.cellRect(c, 1);
      label(colName(c), Rect.fromLTRB(cr.left, 0, cr.right, _headH), c >= sel.c1 && c <= sel.c2);
    }
    canvas.restore();
    // row header strip
    final left = s._mirror(0, 0, _headW, 0).left;
    canvas.save();
    canvas.clipRect(s._mirror(0, _headH, _headW, size.height));
    canvas.drawRect(s._mirror(0, _headH, _headW, size.height), fill);
    canvas.save();
    canvas.clipRect(s._mirror(0, _headH + g.ry[fr] * z, _headW, size.height));
    for (var r = firstR; r <= lastR; r++) {
      if (sh.rowH(r) == 0) continue;
      final cr = s.cellRect(0, r);
      label('$r', Rect.fromLTWH(left, cr.top, _headW, cr.height), r >= sel.r1 && r <= sel.r2);
    }
    canvas.restore();
    for (var r = 1; r <= fr; r++) {
      if (sh.rowH(r) == 0) continue;
      final cr = s.cellRect(0, r);
      label('$r', Rect.fromLTWH(left, cr.top, _headW, cr.height), r >= sel.r1 && r <= sel.r2);
    }
    canvas.restore();
    // corner
    final corner = s._mirror(0, 0, _headW, _headH);
    canvas.drawRect(corner, fill);
    canvas.drawRect(
        corner,
        stroke
          ..style = PaintingStyle.stroke);
    final tri = Path()
      ..moveTo(corner.right - 6, corner.bottom - 6)
      ..lineTo(corner.right - 6, corner.bottom - 16)
      ..lineTo(corner.right - 16, corner.bottom - 6)
      ..close();
    canvas.drawPath(tri, Paint()..color = ink.withAlpha(120));
    // live resize guide
    if (s._tempColW != null && s._resizeIndex >= 0 && s._tempCols.isNotEmpty) {
      final c = s._resizeIndex;
      final cr = s.cellRect(c, 1);
      final x = s._rtl ? cr.right - s._tempColW! * z : cr.left + s._tempColW! * z;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), Paint()..color = green..strokeWidth = 2);
    }
    if (s._tempRowH != null && s._resizeIndex >= 1 && s._tempRows.isNotEmpty) {
      final y = s._ty(s._resizeIndex) + s._tempRowH! * z;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), Paint()..color = green..strokeWidth = 2);
    }
  }
}
