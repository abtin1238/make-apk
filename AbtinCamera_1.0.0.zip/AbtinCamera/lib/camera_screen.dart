import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sensors_plus/sensors_plus.dart';
import 'doc_scanner.dart';
import 'gallery.dart';
import 'modes.dart';
import 'more_screen.dart';
import 'processing.dart';
import 'settings.dart';
import 'settings_screen.dart';
import 'theme.dart';
import 'widgets.dart';

const _wbNames = ['AUTO', 'DAY', 'CLOUD', 'SHADE', 'TUNG', 'FLUOR'];
const _wbTemps = [0.0, 0.1, 0.35, 0.5, -0.7, -0.3];

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});
  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> with WidgetsBindingObserver {
  final s = AppSettings.I;
  List<CameraDescription> _cams = [];
  CameraController? _c;
  bool _front = false, _denied = false, _micOk = false, _booting = false;
  Mode _mode = Mode.photo;
  double _zoom = 1, _minZoom = 1, _maxZoom = 1, _baseZoom = 1;
  double _ev = 0, _minEv = 0, _maxEv = 0;
  FlashMode _flash = FlashMode.off;
  bool _busy = false, _processing = false, _recording = false, _zooming = false, _flashFx = false;
  int _countdown = 0;
  Duration _recDur = Duration.zero;
  Timer? _recTimer, _focusTimer;
  Offset? _focusPt;
  File? _last;
  String? _hint;
  String? _scene, _sceneCand;
  bool _streaming = false;
  DateTime _lastFrame = DateTime.fromMillisecondsSinceEpoch(0);
  bool _panoRunning = false, _panoShooting = false;
  double _panoAngle = 0, _lastShot = 0;
  final List<Uint8List> _panoFrames = [];
  StreamSubscription<GyroscopeEvent>? _gyro;
  DateTime? _gyroT;
  final GlobalKey _moreKey = GlobalKey();

  String _proTab = 'ev';
  String _fxTab = 'con';
  int _wbIdx = 0;
  int? _lensIdx;
  double _pTemp = 0, _pContrast = 0, _pSat = 0, _pSharp = 0;
  bool _afLock = false, _aeLock = false;

  StreamSubscription<AccelerometerEvent>? _acc;
  double _roll = 0, _jit = 0;
  bool _steady = true, _tiltOk = true;
  DateTime _lastSensorUi = DateTime.now();

  final Map<Mode, GlobalKey> _modeKeys = {for (final m in Mode.values) m: GlobalKey()};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    s.addListener(_onSettings);
    _boot();
    _loadLast();
    _listenSensors();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    s.removeListener(_onSettings);
    _recTimer?.cancel();
    _focusTimer?.cancel();
    _acc?.cancel();
    _gyro?.cancel();
    _c?.dispose();
    super.dispose();
  }

  void _onSettings() {
    if (!s.ai) _scene = null;
    if (mounted) setState(() {});
    _syncStream();
  }

  void _toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m), duration: const Duration(seconds: 2)));
  }

  // ───────────── lifecycle / camera setup ─────────────

  @override
  void didChangeAppLifecycleState(AppLifecycleState st) {
    if (st == AppLifecycleState.inactive) {
      if (_c != null && !_recording) {
        final old = _c;
        setState(() => _c = null);
        old?.dispose();
      }
    } else if (st == AppLifecycleState.resumed) {
      if (_denied) {
        _boot();
      } else if (_c == null && _cams.isNotEmpty && !_recording) {
        _startCamera();
      }
    }
  }

  Future<void> _boot() async {
    if (_booting) return;
    _booting = true;
    try {
      final st = await [Permission.camera, Permission.microphone].request();
      _micOk = st[Permission.microphone]?.isGranted ?? false;
      if (!(st[Permission.camera]?.isGranted ?? false)) {
        if (mounted) setState(() => _denied = true);
        return;
      }
      try {
        _cams = await availableCameras();
      } catch (_) {
        _cams = [];
      }
      if (_cams.isEmpty) {
        if (mounted) setState(() => _denied = true);
        return;
      }
      if (mounted) setState(() => _denied = false);
      await _startCamera();
    } finally {
      _booting = false;
    }
  }

  Future<void> _loadLast() async {
    final l = await listCaptures();
    if (mounted) setState(() => _last = l.isEmpty ? null : l.first);
  }

  ResolutionPreset _preset() {
    if (_mode == Mode.hires) return ResolutionPreset.max;
    switch (s.resolution) {
      case 0:
        return ResolutionPreset.high;
      case 1:
        return ResolutionPreset.veryHigh;
      case 2:
        return ResolutionPreset.ultraHigh;
      default:
        return ResolutionPreset.max;
    }
  }

  CameraDescription _desc() {
    if (!_front && _lensIdx != null && _lensIdx! < _cams.length) return _cams[_lensIdx!];
    final dir = _front ? CameraLensDirection.front : CameraLensDirection.back;
    final i = _cams.indexWhere((c) => c.lensDirection == dir);
    return _cams[i < 0 ? 0 : i];
  }

  Future<void> _startCamera() async {
    final old = _c;
    _streaming = false;
    if (mounted) setState(() => _c = null);
    await old?.dispose();
    var preset = _preset();
    CameraController? c;
    for (var attempt = 0; attempt < 2; attempt++) {
      final ctrl = CameraController(_desc(), preset, enableAudio: _micOk, imageFormatGroup: ImageFormatGroup.yuv420);
      try {
        await ctrl.initialize();
        c = ctrl;
        break;
      } on CameraException {
        await ctrl.dispose();
        preset = ResolutionPreset.high;
      }
    }
    if (c == null || !mounted) {
      if (mounted) setState(() => _denied = true);
      return;
    }
    try {
      _minZoom = await c.getMinZoomLevel();
      _maxZoom = await c.getMaxZoomLevel();
    } catch (_) {
      _minZoom = 1;
      _maxZoom = 1;
    }
    try {
      _minEv = await c.getMinExposureOffset();
      _maxEv = await c.getMaxExposureOffset();
    } catch (_) {
      _minEv = 0;
      _maxEv = 0;
    }
    _zoom = 1.0.clamp(_minZoom, _maxZoom).toDouble();
    _ev = 0;
    try {
      await c.setZoomLevel(_zoom);
      await c.setExposureOffset(0);
      await c.setFlashMode(_flash);
    } catch (_) {}
    if (!mounted) {
      await c.dispose();
      return;
    }
    setState(() => _c = c);
    _applyMode(_mode, _mode);
    _syncStream();
  }

  Future<void> _flip() async {
    if (_recording || _busy || _cams.length < 2) return;
    _front = !_front;
    _lensIdx = null;
    await _startCamera();
  }

  Future<void> _cycleRes() async {
    if (_recording || _busy) return;
    s.update(() => s.resolution = (s.resolution + 1) % 4);
    await _startCamera();
  }

  Future<void> _cycleFlash() async {
    const order = [FlashMode.off, FlashMode.auto, FlashMode.always, FlashMode.torch];
    final next = order[(order.indexOf(_flash) + 1) % order.length];
    await _setFlash(next);
  }

  Future<void> _setFlash(FlashMode f) async {
    _flash = f;
    try {
      await _c?.setFlashMode(f);
    } catch (_) {}
    if (mounted) setState(() {});
  }

  Future<void> _setZoom(double v) async {
    final c = _c;
    if (c == null) return;
    v = v.clamp(_minZoom, _maxZoom).toDouble();
    try {
      await c.setZoomLevel(v);
    } catch (_) {}
    if (mounted) setState(() => _zoom = v);
  }

  Future<void> _setEv(double v) async {
    final c = _c;
    if (c == null || _maxEv - _minEv < 0.01) return;
    v = v.clamp(_minEv, _maxEv).toDouble();
    try {
      await c.setExposureOffset(v);
    } catch (_) {}
    if (mounted) setState(() => _ev = v);
  }

  Future<void> _applyMode(Mode m, Mode prev) async {
    final c = _c;
    if (c == null || _recording) return;
    try {
      if (m == Mode.moon) {
        await _setFlash(FlashMode.off);
        await _setZoom(math.min(_maxZoom, 8.0));
        await _setEv(math.max(_minEv, -2.0));
        await c.setFocusMode(FocusMode.auto);
      } else if (m == Mode.pano) {
        await _setFlash(FlashMode.off);
        await _setZoom(1.0);
        await _setEv(0);
      } else if (m == Mode.night) {
        await _setFlash(FlashMode.off);
        if (prev == Mode.moon) await _setZoom(1.0);
        await _setEv(math.min(_maxEv, 1.0));
      } else {
        if (prev == Mode.moon) await _setZoom(1.0);
        if (prev == Mode.moon || prev == Mode.night) await _setEv(0);
      }
    } catch (_) {}
  }

  Future<void> _selectMode(Mode m) async {
    if (_recording || _busy || _panoRunning || m == _mode) return;
    final prev = _mode;
    final restart = (m == Mode.hires) != (prev == Mode.hires);
    setState(() => _mode = m);
    if (restart) {
      await _startCamera();
    } else {
      await _applyMode(m, prev);
    }
    _syncStream();
    final ctx = (moreModes.contains(m) ? _moreKey : _modeKeys[m])?.currentContext;
    if (ctx != null) {
      Scrollable.ensureVisible(ctx, alignment: 0.5, duration: const Duration(milliseconds: 220));
    }
  }

  // ───────────── sensors ─────────────

  void _listenSensors() {
    try {
      _acc = accelerometerEventStream(samplingPeriod: SensorInterval.uiInterval).listen((e) {
        final mag = math.sqrt(e.x * e.x + e.y * e.y + e.z * e.z);
        _jit = _jit * 0.9 + (mag - 9.81).abs() * 0.1;
        final now = DateTime.now();
        if (now.difference(_lastSensorUi).inMilliseconds < 120 || !mounted) return;
        _lastSensorUi = now;
        final roll = math.atan2(e.x, e.y);
        final st = _jit < 0.12;
        final tilt = e.y > 4;
        if ((roll - _roll).abs() > 0.004 || st != _steady || tilt != _tiltOk) {
          setState(() {
            _roll = roll;
            _steady = st;
            _tiltOk = tilt;
          });
        }
      }, onError: (_) {});
    } catch (_) {}
  }

  // ───────────── gestures ─────────────

  void _onScaleUpdate(ScaleUpdateDetails d) {
    if (d.pointerCount < 2 || _zooming) return;
    _zooming = true;
    _setZoom(_baseZoom * d.scale).whenComplete(() => _zooming = false);
  }

  Future<void> _focusAt(Offset local, Size box) async {
    final c = _c;
    if (c == null) return;
    setState(() => _focusPt = local);
    _focusTimer?.cancel();
    _focusTimer = Timer(const Duration(seconds: 2), () {
      if (mounted) setState(() => _focusPt = null);
    });
    final n = Offset((local.dx / box.width).clamp(0.0, 1.0).toDouble(),
        (local.dy / box.height).clamp(0.0, 1.0).toDouble());
    try {
      if (c.value.focusPointSupported) await c.setFocusPoint(n);
      if (c.value.exposurePointSupported) await c.setExposurePoint(n);
    } catch (_) {}
  }

  // ───────────── capture ─────────────

  Future<bool> _runTimer() async {
    final t = s.timer;
    if (t == 0) return true;
    for (var i = t; i > 0; i--) {
      if (!mounted) return false;
      setState(() => _countdown = i);
      await Future.delayed(const Duration(seconds: 1));
    }
    if (mounted) setState(() => _countdown = 0);
    return true;
  }

  Future<void> _onShutter() async {
    final c = _c;
    if (c == null || !c.value.isInitialized || _busy) return;
    if (_isVideo) {
      await _toggleRecord();
      return;
    }
    if (_mode == Mode.pano) {
      await _togglePano();
      return;
    }
    setState(() => _busy = true);
    await _syncStream();
    try {
      if (!await _runTimer()) return;
      HapticFeedback.mediumImpact();
      if (_mode == Mode.doc) {
        await _captureDoc();
      } else {
        await _capturePhoto();
      }
    } catch (e) {
      _toast('Capture failed: ${e is CameraException ? e.description : e}');
    } finally {
      Future.microtask(_syncStream);
      if (mounted) {
        setState(() {
          _busy = false;
          _processing = false;
          _hint = null;
          _countdown = 0;
        });
      }
    }
  }

  Future<Uint8List> _shoot() async {
    final f = await _c!.takePicture();
    return f.readAsBytes();
  }

  Future<void> _capturePhoto() async {
    var kind = _mode == Mode.moon
        ? 'moon'
        : _mode == Mode.night
            ? 'night'
            : _mode == Mode.portrait
                ? 'portrait'
                : (s.hdr && _mode == Mode.photo)
                    ? 'hdr'
                    : 'photo';
    if (s.ai && kind == 'photo' && _mode == Mode.photo) {
      if (_scene == 'Moon') {
        kind = 'moon';
      } else if (_scene == 'Night') {
        kind = 'night';
      }
    }
    final frames = <Uint8List>[];
    if (kind == 'night') {
      final prevFlash = _flash;
      await _setFlash(FlashMode.off);
      const n = 6;
      for (var i = 0; i < n; i++) {
        if (mounted) setState(() => _hint = 'Hold steady… ${i + 1}/$n');
        frames.add(await _shoot());
      }
      await _setFlash(prevFlash);
    } else if (kind == 'hdr') {
      final base = _ev;
      final prevFlash = _flash;
      await _setFlash(FlashMode.off);
      var i = 0;
      for (final d in const [-2.0, 0.0, 2.0]) {
        if (mounted) setState(() => _hint = 'HDR+ ${++i}/3');
        await _setEv(base + d);
        await Future.delayed(const Duration(milliseconds: 300));
        frames.add(await _shoot());
      }
      await _setEv(base);
      await _setFlash(prevFlash);
    } else {
      frames.add(await _shoot());
    }
    if (mounted) {
      setState(() {
        _flashFx = true;
        _hint = null;
      });
    }
    Future.delayed(const Duration(milliseconds: 140), () {
      if (mounted) setState(() => _flashFx = false);
    });

    final pro = _mode == Mode.pro;
    final mirror = _front && s.mirrorFront;
    final adj = pro && (_pTemp != 0 || _pContrast != 0 || _pSat != 0 || _pSharp != 0);
    final needs = kind != 'photo' || s.ai || s.beauty > 0 || mirror || s.watermark || adj;

    Uint8List out;
    if (!needs) {
      out = frames.first;
    } else {
      if (mounted) setState(() => _processing = true);
      out = await processPhoto(PhotoJob(
        frames: frames,
        mode: kind,
        ai: s.ai,
        mirror: mirror,
        moonCrop: s.moonCrop,
        watermark: s.watermark,
        beauty: s.beauty,
        blur: s.portraitBlur,
        temp: pro ? _pTemp : 0,
        contrast: pro ? _pContrast : 0,
        sat: pro ? _pSat : 0,
        sharp: pro ? _pSharp : 0,
        quality: s.jpegQuality,
        maxSide: (_mode == Mode.hires || s.resolution == 3) ? 9000 : 4400,
      ));
    }
    final saved = await saveJpeg(out, toGallery: s.autoSave);
    if (mounted) setState(() => _last = saved);
  }

  Future<void> _captureDoc() async {
    final bytes = await _shoot();
    if (!mounted) return;
    final res = await Navigator.of(context)
        .push<DocEditResult>(MaterialPageRoute(builder: (_) => DocEditorScreen(bytes: bytes)));
    if (res == null) return;
    docSession.add(res.page);
    if (res.finish && mounted) {
      await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DocPagesScreen()));
    }
  }

  Future<void> _toggleRecord() async {
    if (!_recording && (_mode == Mode.slowmo || _mode == Mode.timelapse)) {
      _toast(_mode == Mode.slowmo
          ? 'Native high-frame-rate capture is not supported by the active camera backend.'
          : 'Interval-based time-lapse capture is not supported by the active camera backend.');
      return;
    }
    final c = _c!;
    try {
      if (_recording) {
        _recTimer?.cancel();
        final f = await c.stopVideoRecording();
        setState(() => _recording = false);
        final saved = await saveVideo(f.path, toGallery: s.autoSave, tag: _videoTag());
        if (mounted) setState(() => _last = saved);
        _toast('Video saved');
        _syncStream();
      } else {
        await _stopStream();
        await c.startVideoRecording();
        setState(() {
          _recording = true;
          _recDur = Duration.zero;
        });
        _recTimer = Timer.periodic(const Duration(seconds: 1), (_) {
          if (!mounted) return;
          setState(() => _recDur += const Duration(seconds: 1));
          if (_mode == Mode.shortVideo && _recDur.inSeconds >= 15) _toggleRecord();
        });
      }
    } catch (e) {
      _recTimer?.cancel();
      if (mounted) setState(() => _recording = false);
      _toast('Video error: ${e is CameraException ? e.description : e}');
    }
  }

  // ───────────── AI scene detection ─────────────

  bool get _isVideo =>
      _mode == Mode.video || _mode == Mode.shortVideo || _mode == Mode.slowmo || _mode == Mode.timelapse;

  String _videoTag() => _mode == Mode.slowmo ? 'SLO' : (_mode == Mode.timelapse ? 'TLP' : '');

  bool get _wantStream =>
      s.ai &&
      !_recording &&
      !_busy &&
      !_panoRunning &&
      _c != null &&
      const [Mode.photo, Mode.pro, Mode.portrait, Mode.hires].contains(_mode);

  Future<void> _stopStream() async {
    final c = _c;
    if (c == null || !_streaming) return;
    _streaming = false;
    try {
      await c.stopImageStream();
    } catch (_) {}
  }

  Future<void> _syncStream() async {
    final c = _c;
    if (c == null || !c.value.isInitialized) return;
    try {
      if (_wantStream && !_streaming) {
        _streaming = true;
        await c.startImageStream(_analyze);
      } else if (!_wantStream && _streaming) {
        await _stopStream();
      }
    } catch (_) {
      _streaming = false;
    }
  }

  void _analyze(CameraImage im) {
    final now = DateTime.now();
    if (now.difference(_lastFrame).inMilliseconds < 700) return;
    _lastFrame = now;
    try {
      final pl = im.planes[0];
      final y = pl.bytes;
      final w = im.width, h = im.height, stride = pl.bytesPerRow;
      const step = 12;
      var sum = 0, n = 0, bright = 0, minX = w, maxX = 0, minY = h, maxY = 0;
      for (var yy = 0; yy < h; yy += step) {
        for (var xx = 0; xx < w; xx += step) {
          final v = y[yy * stride + xx];
          sum += v;
          n++;
          if (v > 200) {
            bright++;
            if (xx < minX) minX = xx;
            if (xx > maxX) maxX = xx;
            if (yy < minY) minY = yy;
            if (yy > maxY) maxY = yy;
          }
        }
      }
      if (n == 0) return;
      final mean = sum / n;
      var sc = 'Auto';
      if (mean < 70 && bright >= 3) {
        final area = ((maxX - minX) / step + 1) * ((maxY - minY) / step + 1);
        final fill = bright / area;
        final frac = bright / n;
        if (frac > 0.001 && frac < 0.12 && fill > 0.45) sc = 'Moon';
      }
      if (sc == 'Auto' && mean < 50) sc = 'Night';
      if (sc == _sceneCand && _scene != sc && mounted) setState(() => _scene = sc);
      _sceneCand = sc;
    } catch (_) {}
  }

  // ───────────── Panorama ─────────────

  static const _panoStepDeg = 10.0;

  Future<void> _togglePano() async {
    if (_panoRunning) {
      await _finishPano();
      return;
    }
    setState(() {
      _panoRunning = true;
      _panoFrames.clear();
      _panoAngle = 0;
      _lastShot = 0;
      _gyroT = null;
      _hint = 'Panorama · pan slowly';
    });
    _gyro = gyroscopeEventStream(samplingPeriod: SensorInterval.gameInterval).listen(_onGyro, onError: (_) {});
    await _panoShot();
  }

  void _onGyro(GyroscopeEvent e) {
    final now = DateTime.now();
    final last = _gyroT;
    _gyroT = now;
    if (last == null || !_panoRunning) return;
    _panoAngle += e.y * (now.difference(last).inMicroseconds / 1e6);
    if (((_panoAngle - _lastShot).abs() * 180 / math.pi) >= _panoStepDeg && !_panoShooting) {
      _panoShot();
    }
  }

  Future<void> _panoShot() async {
    if (_panoShooting || !_panoRunning) return;
    _panoShooting = true;
    try {
      final b = await _shoot();
      _panoFrames.add(b);
      _lastShot = _panoAngle;
      if (mounted) setState(() => _hint = 'Panorama · ${_panoFrames.length} shots · tap to finish');
    } catch (_) {
    } finally {
      _panoShooting = false;
    }
    if (_panoFrames.length >= 20) await _finishPano();
  }

  Future<void> _finishPano() async {
    if (!_panoRunning) return;
    _gyro?.cancel();
    _gyro = null;
    final frames = List<Uint8List>.of(_panoFrames);
    final reverse = _panoAngle > 0;
    setState(() {
      _panoRunning = false;
      _hint = null;
    });
    _panoFrames.clear();
    if (frames.length < 2) {
      _toast('Pan the phone while shooting');
      return;
    }
    setState(() {
      _processing = true;
      _busy = true;
    });
    try {
      final out = await processPano(PanoJob(frames: frames, strip: 0.21, reverse: reverse, quality: s.jpegQuality));
      final saved = await saveJpeg(out, toGallery: s.autoSave);
      if (mounted) setState(() => _last = saved);
      _toast('Panorama saved');
    } catch (e) {
      _toast('Panorama failed: $e');
    } finally {
      if (mounted) {
        setState(() {
          _processing = false;
          _busy = false;
        });
      }
      _syncStream();
    }
  }

  Future<void> _openMore() async {
    if (_recording || _busy || _panoRunning) return;
    final m = await Navigator.of(context).push<Mode>(MaterialPageRoute(builder: (_) => const MoreScreen()));
    if (m != null) await _selectMode(m);
  }

  String? _infoText() {
    switch (_mode) {
      case Mode.hires:
        return 'Max resolution';
      case Mode.shortVideo:
        return 'Short video · up to 15 s';
      case Mode.slowmo:
        return 'High-FPS capture is not available through the active camera backend';
      case Mode.timelapse:
        return 'Interval capture is not available through the active camera backend';
      case Mode.pano:
        return _panoRunning ? null : 'Tap shutter, then pan slowly';
      default:
        return null;
    }
  }

  // ───────────── navigation ─────────────

  Future<void> _openSettings() async {
    final before = s.resolution;
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen()));
    if (s.resolution != before) await _startCamera();
  }

  Future<void> _openGallery() async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => const GalleryScreen()));
    _loadLast();
  }

  void _openTune() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AT.panel,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => StatefulBuilder(builder: (ctx, setM) {
        void upd(VoidCallback f) {
          s.update(f);
          setM(() {});
        }

        return Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Quick settings', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 4, children: [
              FilterChip(label: const Text('HDR+'), selected: s.hdr, onSelected: (v) => upd(() => s.hdr = v)),
              FilterChip(label: const Text('Grid'), selected: s.grid, onSelected: (v) => upd(() => s.grid = v)),
              FilterChip(label: const Text('Level'), selected: s.level, onSelected: (v) => upd(() => s.level = v)),
              FilterChip(label: const Text('AI Enhance'), selected: s.ai, onSelected: (v) => upd(() => s.ai = v)),
            ]),
            const SizedBox(height: 12),
            const Text('Timer', style: TextStyle(color: Colors.white70)),
            Wrap(spacing: 8, children: [
              for (final t in const [0, 3, 5, 10])
                ChoiceChip(
                  label: Text(t == 0 ? 'Off' : '${t}s'),
                  selected: s.timer == t,
                  selectedColor: AT.purple,
                  onSelected: (_) => upd(() => s.timer = t),
                ),
            ]),
            const SizedBox(height: 8),
            Text('Beauty: ${(s.beauty * 100).round()}%', style: const TextStyle(color: Colors.white70)),
            Slider(value: s.beauty, onChanged: (v) => upd(() => s.beauty = v)),
            Text('Portrait blur: ${(s.portraitBlur * 100).round()}%', style: const TextStyle(color: Colors.white70)),
            Slider(value: s.portraitBlur, onChanged: (v) => upd(() => s.portraitBlur = v)),
          ]),
        );
      }),
    );
  }

  // ───────────── UI ─────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Column(children: [
          _topBar(),
          Expanded(child: _previewArea()),
          if (_mode == Mode.pro) _proPanel(),
          _modeRow(),
          _controls(),
        ]),
      ),
    );
  }

  Widget _topBar() {
    IconData flashIcon() {
      switch (_flash) {
        case FlashMode.auto:
          return Icons.flash_auto;
        case FlashMode.always:
          return Icons.flash_on;
        case FlashMode.torch:
          return Icons.flashlight_on;
        default:
          return Icons.flash_off;
      }
    }

    final l = AppSettings.resLabels[s.resolution];
    return SizedBox(
      height: 56,
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
        IconButton(onPressed: _openSettings, icon: const Icon(Icons.settings_outlined, size: 26)),
        GestureDetector(
          onTap: _cycleRes,
          behavior: HitTestBehavior.opaque,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 6),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(l[0], style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, height: 1)),
              Text(l[1], style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, height: 1.1)),
            ]),
          ),
        ),
        IconButton(
            onPressed: _cycleFlash,
            icon: Icon(flashIcon(), size: 26, color: _flash == FlashMode.off ? Colors.white : const Color(0xFFFFD60A))),
        GestureDetector(
          onTap: () => s.update(() => s.ai = !s.ai),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
              border: Border.all(color: s.ai ? AT.purple : Colors.white, width: 2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Text('AI',
                style: TextStyle(fontWeight: FontWeight.w800, color: s.ai ? AT.purple : Colors.white)),
          ),
        ),
        IconButton(onPressed: _openTune, icon: const Icon(Icons.tune, size: 26)),
      ]),
    );
  }

  Widget _deniedView() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ClipRRect(borderRadius: BorderRadius.circular(24), child: Image.asset('assets/icon.png', width: 96)),
          const SizedBox(height: 20),
          const Text('Camera access is required', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          const Text('Allow camera permission to start Abtin Camera.',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.white60)),
          const SizedBox(height: 20),
          FilledButton(
              style: FilledButton.styleFrom(backgroundColor: AT.purple),
              onPressed: () async {
                final st = await Permission.camera.status;
                if (st.isPermanentlyDenied) {
                  await openAppSettings();
                } else {
                  _boot();
                }
              },
              child: const Text('Allow')),
        ]),
      ),
    );
  }

  Widget _previewArea() {
    if (_denied) return _deniedView();
    final c = _c;
    if (c == null || !c.value.isInitialized) {
      return const Center(child: CircularProgressIndicator(color: AT.purple));
    }
    final ar = c.value.aspectRatio;
    final portraitAr = ar > 1 ? 1 / ar : ar;
    final showEv = (_mode == Mode.pro || _mode == Mode.moon || _mode == Mode.night) && _maxEv - _minEv > 0.01;
    return Stack(fit: StackFit.expand, children: [
      Center(
        child: AspectRatio(
          aspectRatio: portraitAr,
          child: LayoutBuilder(builder: (ctx, cons) {
            final box = Size(cons.maxWidth, cons.maxHeight);
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onScaleStart: (_) => _baseZoom = _zoom,
              onScaleUpdate: _onScaleUpdate,
              onTapUp: (d) => _focusAt(d.localPosition, box),
              child: Stack(fit: StackFit.expand, children: [
                CameraPreview(c),
                if (s.grid) const CustomPaint(painter: GridPainter()),
                if (s.level && _tiltOk && _mode != Mode.moon) CustomPaint(painter: LevelPainter(_roll)),
                if (_mode == Mode.moon) const CustomPaint(painter: ReticlePainter()),
                if (_mode == Mode.doc) const CustomPaint(painter: DocGuidePainter()),
                if (_focusPt != null)
                  Positioned(left: _focusPt!.dx - 32, top: _focusPt!.dy - 32, child: const FocusRing()),
              ]),
            );
          }),
        ),
      ),
      if (_infoText() != null)
        Positioned(left: 12, top: 10, child: _chip(Icons.info_outline, _infoText()!, Colors.white70)),
      if (s.ai && _scene != null && !_isVideo && _mode != Mode.doc && _mode != Mode.pano)
        Positioned(right: 12, top: 10, child: _chip(Icons.auto_awesome, 'AI · $_scene', AT.purple)),
      if (_mode == Mode.moon || _mode == Mode.night)
        Positioned(
          left: 12,
          top: 10,
          child: _chip(
            _steady ? Icons.check_circle : Icons.vibration,
            _steady ? 'Steady' : 'Hold still · use a tripod',
            _steady ? Colors.greenAccent : Colors.orangeAccent,
          ),
        ),
      if (_mode == Mode.doc)
        Positioned(
          left: 12,
          top: 10,
          child: ListenableBuilder(
            listenable: docSession,
            builder: (context, _) => docSession.pages.isEmpty
                ? _chip(Icons.crop_free, 'Align the document in the frame', Colors.white70)
                : GestureDetector(
                    onTap: () => Navigator.of(context)
                        .push(MaterialPageRoute(builder: (_) => const DocPagesScreen())),
                    child: _chip(Icons.description_outlined, 'Pages (${docSession.pages.length}) ›', AT.purple),
                  ),
          ),
        ),
      if (_recording)
        Positioned(
          top: 10,
          left: 0,
          right: 0,
          child: Center(child: _chip(Icons.fiber_manual_record, _fmt(_recDur), Colors.redAccent)),
        ),
      if (showEv)
        Positioned(
          right: 4,
          top: 60,
          child: Column(children: [
            const Icon(Icons.wb_sunny_outlined, size: 18, color: Colors.white70),
            SizedBox(
              width: 40,
              height: 200,
              child: RotatedBox(
                quarterTurns: 3,
                child: Slider(min: _minEv, max: _maxEv, value: _ev.clamp(_minEv, _maxEv).toDouble(), onChanged: _setEv),
              ),
            ),
            Text(_ev >= 0 ? '+${_ev.toStringAsFixed(1)}' : _ev.toStringAsFixed(1),
                style: const TextStyle(fontSize: 11, color: Colors.white70)),
          ]),
        ),
      Positioned(left: 0, right: 0, bottom: 12, child: Center(child: _zoomPill())),
      if (_countdown > 0)
        Positioned.fill(
          child: IgnorePointer(
            child: Center(
                child: Text('$_countdown',
                    style: const TextStyle(fontSize: 110, fontWeight: FontWeight.w200, color: Colors.white))),
          ),
        ),
      Positioned.fill(
        child: IgnorePointer(
          child: AnimatedOpacity(
            opacity: _flashFx ? 0.85 : 0,
            duration: const Duration(milliseconds: 80),
            child: const ColoredBox(color: Colors.white),
          ),
        ),
      ),
      if (_processing || _hint != null)
        Positioned.fill(
          child: Container(
            color: _processing ? Colors.black54 : Colors.transparent,
            child: Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                if (_processing) const CircularProgressIndicator(color: AT.purple),
                const SizedBox(height: 14),
                _chip(Icons.auto_awesome, _hint ?? 'Processing…', Colors.white),
              ]),
            ),
          ),
        ),
    ]);
  }

  Widget _chip(IconData i, String t, Color col) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(16)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(i, size: 15, color: col),
          const SizedBox(width: 5),
          Text(t, style: TextStyle(fontSize: 12.5, color: col, fontWeight: FontWeight.w600)),
        ]),
      );

  String _fmt(Duration d) {
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.inMinutes)}:${two(d.inSeconds % 60)}';
  }

  Widget _zoomPill() {
    final entries = <List<double>>[]; // [label, target]
    if (_minZoom < 0.95) entries.add([double.parse(_minZoom.toStringAsFixed(1)), _minZoom]);
    for (final v in const [1.0, 2.0, 5.0, 10.0]) {
      if (v <= _maxZoom + 0.05) entries.add([v, v]);
    }
    var selected = -1;
    for (var i = 0; i < entries.length; i++) {
      if ((_zoom - entries[i][1]).abs() < entries[i][1] * 0.06) selected = i;
    }
    String fmt(double v) => v == v.roundToDouble() ? '${v.round()}' : v.toStringAsFixed(1);
    final items = <Widget>[];
    for (var i = 0; i < entries.length; i++) {
      if (selected < 0 && _zoom < entries[i][1] && (i == 0 || _zoom > entries[i - 1][1])) {
        items.add(_zoomChip('${fmt(double.parse(_zoom.toStringAsFixed(1)))}x', true, () {}));
      }
      final sel = i == selected;
      items.add(_zoomChip(fmt(entries[i][0]) + (sel ? 'x' : ''), sel, () => _setZoom(entries[i][1])));
    }
    if (selected < 0 && entries.isNotEmpty && _zoom > entries.last[1]) {
      items.add(_zoomChip('${fmt(double.parse(_zoom.toStringAsFixed(1)))}x', true, () {}));
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(30)),
      child: Row(mainAxisSize: MainAxisSize.min, children: items),
    );
  }

  Widget _zoomChip(String t, bool sel, VoidCallback f) => GestureDetector(
        onTap: f,
        behavior: HitTestBehavior.opaque,
        child: Container(
          width: 44,
          height: 40,
          alignment: Alignment.center,
          margin: const EdgeInsets.symmetric(horizontal: 2),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: sel ? Colors.black : Colors.transparent,
            border: sel ? Border.all(color: AT.purple, width: 2) : null,
          ),
          child: Text(t,
              style: TextStyle(
                  fontSize: sel ? 14 : 15,
                  fontWeight: sel ? FontWeight.w800 : FontWeight.w500,
                  color: sel ? Colors.white : Colors.white70)),
        ),
      );

  List<int> _backIdx() => [
        for (var i = 0; i < _cams.length; i++)
          if (_cams[i].lensDirection == CameraLensDirection.back) i
      ];

  String _lensLabel() {
    if (_front || _cams.isEmpty) return _front ? 'FRONT' : 'WIDE';
    final n = _backIdx().indexOf(_cams.indexOf(_desc()));
    return n <= 0 ? 'WIDE' : 'CAM ${n + 1}';
  }

  Future<void> _pickLens(int idx) async {
    if (_busy || _recording) return;
    _front = false;
    _lensIdx = idx;
    await _startCamera();
  }

  void _proTap(String k) {
    if (k == 'f' || k == 's' || k == 'iso') {
      _toast('F / Shutter / ISO are set automatically by the camera on this build');
      return;
    }
    setState(() => _proTab = _proTab == k ? '' : k);
  }

  Widget _proPanel() {
    const yellow = Color(0xFFFFC928);
    final evText = _ev == 0 ? '0' : (_ev > 0 ? '+${_ev.toStringAsFixed(1)}' : _ev.toStringAsFixed(1));
    final wbText = _wbIdx >= 0 ? _wbNames[_wbIdx] : 'CUSTOM';
    final items = <List<String>>[
      ['wb', 'WB', wbText],
      ['f', 'F', 'AUTO'],
      ['s', 'S', 'AUTO'],
      ['iso', 'ISO', 'AUTO'],
      ['ev', 'EV', evText],
      ['lens', 'LENS', _lensLabel()],
      ['fx', 'FX', '•••'],
    ];
    return Container(
      color: const Color(0xFF0B0A18),
      padding: const EdgeInsets.fromLTRB(4, 6, 4, 4),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        _proControl(),
        Row(children: [
          for (final it in items)
            Expanded(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () => _proTap(it[0]),
                child: Column(children: [
                  Text(it[1],
                      style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w800, color: _proTab == it[0] ? yellow : Colors.white)),
                  const SizedBox(height: 4),
                  Text(it[2],
                      style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                          color: _proTab == it[0]
                              ? yellow
                              : (const ['f', 's', 'iso'].contains(it[0]) ? Colors.white38 : Colors.white))),
                ]),
              ),
            ),
        ]),
      ]),
    );
  }

  Widget _proControl() {
    switch (_proTab) {
      case 'ev':
        final ok = _maxEv - _minEv > 0.01;
        final mx = ok ? _maxEv : _minEv + 0.01;
        return Row(children: [
          Expanded(
            child: Slider(
              min: _minEv,
              max: mx,
              value: _ev.clamp(_minEv, mx).toDouble(),
              onChanged: ok ? _setEv : null,
            ),
          ),
          IconButton(icon: const Icon(Icons.restart_alt, size: 20), onPressed: () => _setEv(0)),
        ]);
      case 'wb':
        return Column(children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              for (var i = 0; i < _wbNames.length; i++)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: ChoiceChip(
                    label: Text(_wbNames[i], style: const TextStyle(fontSize: 12)),
                    selected: _wbIdx == i,
                    selectedColor: AT.purple,
                    visualDensity: VisualDensity.compact,
                    onSelected: (_) => setState(() {
                      _wbIdx = i;
                      _pTemp = _wbTemps[i];
                    }),
                  ),
                ),
            ]),
          ),
          Slider(
            min: -1,
            max: 1,
            value: _pTemp.clamp(-1.0, 1.0).toDouble(),
            onChanged: (v) => setState(() {
              _pTemp = v;
              _wbIdx = -1;
            }),
          ),
        ]);
      case 'lens':
        final b = _backIdx();
        final cur = _cams.isEmpty ? -1 : _cams.indexOf(_desc());
        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [
            if (_front)
              const Padding(
                padding: EdgeInsets.all(10),
                child: Text('Front camera', style: TextStyle(color: Colors.white54)),
              ),
            if (!_front)
              for (var n = 0; n < b.length; n++)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: ChoiceChip(
                    label: Text(n == 0 ? 'WIDE' : 'CAM ${n + 1}', style: const TextStyle(fontSize: 12)),
                    selected: b[n] == cur,
                    selectedColor: AT.purple,
                    visualDensity: VisualDensity.compact,
                    onSelected: (_) => _pickLens(b[n]),
                  ),
                ),
            if (!_front && _minZoom < 0.95)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 3),
                child: ActionChip(
                  label: Text('${_minZoom.toStringAsFixed(1)}x ULTRA', style: const TextStyle(fontSize: 12)),
                  visualDensity: VisualDensity.compact,
                  onPressed: () => _setZoom(_minZoom),
                ),
              ),
          ]),
        );
      case 'fx':
        const tabs = {'con': 'Contrast', 'sat': 'Saturation', 'sh': 'Sharpness', 'af': 'Focus'};
        double val = 0, min = -1, max = 1;
        String label = '';
        void Function(double) changed = (_) {};
        switch (_fxTab) {
          case 'con':
            val = _pContrast;
            label = 'Contrast ${(_pContrast * 100).round()}';
            changed = (v) => setState(() => _pContrast = v);
            break;
          case 'sat':
            val = _pSat;
            label = 'Saturation ${(_pSat * 100).round()}';
            changed = (v) => setState(() => _pSat = v);
            break;
          case 'sh':
            val = _pSharp;
            min = 0;
            label = 'Sharpness ${(_pSharp * 100).round()}';
            changed = (v) => setState(() => _pSharp = v);
            break;
        }
        return Column(children: [
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              for (final e in tabs.entries)
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 3),
                  child: ChoiceChip(
                    label: Text(e.value, style: const TextStyle(fontSize: 12)),
                    selected: _fxTab == e.key,
                    selectedColor: AT.purple,
                    visualDensity: VisualDensity.compact,
                    onSelected: (_) => setState(() => _fxTab = e.key),
                  ),
                ),
              IconButton(
                icon: const Icon(Icons.restart_alt, size: 20),
                onPressed: () {
                  setState(() {
                    _pTemp = 0;
                    _wbIdx = 0;
                    _pContrast = _pSat = _pSharp = 0;
                  });
                  _setEv(0);
                },
              ),
            ]),
          ),
          if (_fxTab == 'af')
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              FilterChip(
                label: const Text('AF Lock'),
                selected: _afLock,
                onSelected: (v) async {
                  setState(() => _afLock = v);
                  try {
                    await _c?.setFocusMode(v ? FocusMode.locked : FocusMode.auto);
                  } catch (_) {}
                },
              ),
              const SizedBox(width: 10),
              FilterChip(
                label: const Text('AE Lock'),
                selected: _aeLock,
                onSelected: (v) async {
                  setState(() => _aeLock = v);
                  try {
                    await _c?.setExposureMode(v ? ExposureMode.locked : ExposureMode.auto);
                  } catch (_) {}
                },
              ),
            ])
          else
            Row(children: [
              SizedBox(width: 110, child: Text(label, style: const TextStyle(fontSize: 12, color: Colors.white70))),
              Expanded(child: Slider(min: min, max: max, value: val.clamp(min, max).toDouble(), onChanged: changed)),
            ]),
        ]);
      default:
        return const SizedBox.shrink();
    }
  }

  Widget _modeRow() {
    final isMore = moreModes.contains(_mode);
    return SizedBox(
      height: 44,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: EdgeInsets.symmetric(horizontal: MediaQuery.of(context).size.width / 2 - 40),
        child: Row(children: [
          for (final m in mainModes)
            if (!s.hidden.contains(m.name) || m == _mode) _modeItem(m),
          _moreItem(isMore),
        ]),
      ),
    );
  }

  Widget _moreItem(bool sel) {
    const yellow = Color(0xFFFFC928);
    return GestureDetector(
      key: _moreKey,
      behavior: HitTestBehavior.opaque,
      onTap: _openMore,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(sel ? modeLabels[_mode]! : 'More',
              style: TextStyle(
                  fontSize: 15, fontWeight: sel ? FontWeight.w700 : FontWeight.w500, color: sel ? yellow : Colors.white70)),
          const SizedBox(height: 3),
          Container(
              width: 5, height: 5, decoration: BoxDecoration(shape: BoxShape.circle, color: sel ? yellow : Colors.transparent)),
        ]),
      ),
    );
  }

  Widget _modeItem(Mode m) {
    final sel = m == _mode;
    return GestureDetector(
      key: _modeKeys[m],
      behavior: HitTestBehavior.opaque,
      onTap: () => _selectMode(m),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(modeLabels[m]!,
              style: TextStyle(
                  fontSize: 15,
                  fontWeight: sel ? FontWeight.w700 : FontWeight.w500,
                  color: sel ? AT.purple : Colors.white70)),
          const SizedBox(height: 3),
          Container(
              width: 5,
              height: 5,
              decoration: BoxDecoration(shape: BoxShape.circle, color: sel ? AT.purple : Colors.transparent)),
        ]),
      ),
    );
  }

  Widget _controls() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(28, 8, 28, 12),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [_thumb(), _shutterBtn(), _flipBtn()]),
    );
  }

  Widget _thumb() {
    final f = _last;
    return GestureDetector(
      onTap: _recording ? null : _openGallery,
      child: Container(
        width: 54,
        height: 54,
        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white54, width: 2), color: AT.panel),
        clipBehavior: Clip.antiAlias,
        child: f == null
            ? const Icon(Icons.photo_library_outlined, color: Colors.white54)
            : isVideoFile(f)
                ? const Icon(Icons.play_arrow, color: Colors.white)
                : Image.file(f, fit: BoxFit.cover, cacheWidth: 160, errorBuilder: (_, __, ___) => const SizedBox()),
      ),
    );
  }

  Widget _shutterBtn() {
    final isVideo = _isVideo;
    final stop = _recording || _panoRunning;
    return GestureDetector(
      onTap: _onShutter,
      child: Stack(alignment: Alignment.center, children: [
        if (_mode == Mode.shortVideo && _recording)
          SizedBox(
            width: 90,
            height: 90,
            child: CircularProgressIndicator(
              value: (_recDur.inSeconds / 15).clamp(0.0, 1.0).toDouble(),
              strokeWidth: 4,
              color: Colors.redAccent,
              backgroundColor: Colors.white24,
            ),
          ),
        Container(
          width: 78,
          height: 78,
          padding: const EdgeInsets.all(5),
          decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white70, width: 4)),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            margin: EdgeInsets.all(stop ? 16 : 0),
            decoration: BoxDecoration(
              color: isVideo ? Colors.redAccent : Colors.white,
              borderRadius: BorderRadius.circular(stop ? 8 : 40),
            ),
            child: _busy && !stop
                ? const Padding(
                    padding: EdgeInsets.all(20), child: CircularProgressIndicator(strokeWidth: 3, color: AT.purple))
                : null,
          ),
        ),
      ]),
    );
  }

  Widget _flipBtn() {
    return GestureDetector(
      onTap: _flip,
      child: Container(
        width: 54,
        height: 54,
        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white38, width: 2)),
        child: const Icon(Icons.flip_camera_android, color: Colors.white, size: 26),
      ),
    );
  }
}
