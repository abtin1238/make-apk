# Build fix notes — AbtinFileManager 0.44.2

- Added `android.newDsl=false` to `android/gradle.properties` to keep the legacy `android {}` DSL active while this project still uses it. This addresses the AGP 9 DSL deprecation errors reported at `android/app/build.gradle.kts:18`.
- Replaced deprecated `kotlinOptions { jvmTarget = "17" }` with Kotlin's typed `compilerOptions` DSL targeting JVM 17.
- Kept existing app dependencies, packaging rules, signing behavior, and Flutter configuration unchanged.

Validation: source-level checks confirm the new DSL flag and compiler target. A Flutter/Gradle build was not run in this environment because Flutter and Dart SDKs are not installed.

## Fix 2 — video_thumbnail (Gradle 9 failure)
- Build failed in `:video_thumbnail` (v0.5.6): its `build.gradle` calls `jcenter()` (removed in Gradle 9) and applies the old `kotlin-android` plugin before AGP.
- Removed the `video_thumbnail` dependency. Video thumbnails are now produced natively (`MediaMetadataRetriever`) through a new `video` method on the existing `abtin/thumb` channel (`ImageThumbNative.kt`), wrapped by `lib/services/video_thumb.dart` (`VideoThumb.data`).
- Call sites updated: `lib/services/thumbs.dart`, `lib/screens/media_screen.dart`, `lib/screens/video_player_screen.dart`. Plugin registration removed from `GeneratedPluginRegistrant.java` and `pubspec.lock`.
- `flutter analyze` had 0 errors (only warnings/infos), so this was the only blocking error.
