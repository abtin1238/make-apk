package ir.abtin.sms

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.provider.Telephony
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

// =====================================================================
// Scheduled sending (AlarmManager) – messages are stored in SharedPreferences and re-armed after reboot.
// =====================================================================
object Scheduler {
    const val ACTION = "ir.abtin.sms.SCHEDULED_SEND"
    private const val KEY = "sched_v1"
    /** Bumped whenever the stored list changes so Compose screens can refresh. */
    val rev = mutableIntStateOf(0)

    /** state: 0 = waiting, 1 = sent, 2 = failed */
    class Item(val id: Long, val addrs: List<String>, val body: String, val at: Long, val sim: Int, val state: Int)

    @Synchronized
    fun load(ctx: Context): List<Item> {
        Prefs.init(ctx)
        val raw = Prefs.sp.getString(KEY, "[]") ?: "[]"
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                val ad = o.getJSONArray("a")
                Item(o.getLong("id"), (0 until ad.length()).map { ad.getString(it) }, o.getString("b"), o.getLong("at"), o.optInt("sim", -1), o.optInt("st", 0))
            }
        } catch (e: Exception) { emptyList() }
    }

    @Synchronized
    private fun save(ctx: Context, l: List<Item>) {
        Prefs.init(ctx)
        val a = JSONArray()
        l.forEach { it2 ->
            a.put(JSONObject().put("id", it2.id).put("a", JSONArray(it2.addrs)).put("b", it2.body).put("at", it2.at).put("sim", it2.sim).put("st", it2.state))
        }
        Prefs.sp.edit().putString(KEY, a.toString()).apply()
        rev.intValue++
    }

    fun add(ctx: Context, addrs: List<String>, body: String, at: Long, sim: Int): Item {
        val it2 = Item(System.currentTimeMillis() * 1000 + (0..999).random(), addrs, body, at, sim, 0)
        save(ctx, load(ctx) + it2)
        arm(ctx, it2)
        return it2
    }

    private fun pending(ctx: Context, id: Long): PendingIntent =
        PendingIntent.getBroadcast(ctx, (id % Int.MAX_VALUE).toInt(),
            Intent(ctx, ScheduledReceiver::class.java).setAction(ACTION).setData(Uri.parse("abtin://sched/$id")).putExtra("id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    fun arm(ctx: Context, it2: Item) {
        if (it2.state != 0) return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, it2.id)
        val at = maxOf(it2.at, System.currentTimeMillis() + 1000)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun cancel(ctx: Context, id: Long) {
        (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending(ctx, id))
        save(ctx, load(ctx).filter { it.id != id })
    }

    fun clearFinished(ctx: Context) = save(ctx, load(ctx).filter { it.state == 0 })

    fun rearmAll(ctx: Context) { load(ctx).filter { it.state == 0 }.forEach { arm(ctx, it) } }

    private fun mark(ctx: Context, id: Long, state: Int) {
        save(ctx, load(ctx).map { if (it.id == id) Item(it.id, it.addrs, it.body, it.at, it.sim, state) else it })
    }

    /** Sends one stored item (each recipient gets its own SMS) – called from the alarm receiver. */
    fun fire(ctx: Context, id: Long) {
        Prefs.init(ctx)
        // The receiver can run in a process last used by the Phone surface. Always
        // use SMS settings, and resolve the configured SIM when the alarm fires so
        // a changed default SIM is honored by already-scheduled messages.
        Prefs.withProfile(false) {
            val item = load(ctx).firstOrNull { it.id == id && it.state == 0 } ?: return@withProfile
            val repo = SmsRepo(ctx)
            val sendSim = Prefs.sim.value
            var ok = 0
            for (a in item.addrs) {
                try { repo.send(a, item.body, sendSim); ok++ } catch (e: Exception) { }
                Thread.sleep(200)
            }
            mark(ctx, id, if (ok > 0) 1 else 2)
        }
    }
}

class ScheduledReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val pr = goAsync()
        Thread {
            try {
                Prefs.init(c)
                when (i.action) {
                    Scheduler.ACTION -> Scheduler.fire(c, i.getLongExtra("id", -1L))
                    Intent.ACTION_BOOT_COMPLETED, "android.intent.action.MY_PACKAGE_REPLACED" -> {
                        val now = System.currentTimeMillis()
                        Scheduler.load(c).filter { it.state == 0 }.forEach { if (it.at <= now) Scheduler.fire(c, it.id) else Scheduler.arm(c, it) }
                    }
                    AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED -> Scheduler.rearmAll(c)
                }
            } catch (e: Exception) { } finally { pr.finish() }
        }.start()
    }
}

// =====================================================================
// Groups of contacts (used for group sending)
// =====================================================================
class Grp(val id: Long, val name: String, val nums: List<String>)

object GroupsStore {
    private const val KEY = "groups_v1"
    fun load(ctx: Context): List<Grp> {
        Prefs.init(ctx)
        return try {
            val a = JSONArray(Prefs.sp.getString(KEY, "[]") ?: "[]")
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i); val n = o.getJSONArray("n")
                Grp(o.getLong("id"), o.getString("name"), (0 until n.length()).map { n.getString(it) })
            }
        } catch (e: Exception) { emptyList() }
    }
    fun save(ctx: Context, l: List<Grp>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("n", JSONArray(it.nums))) }
        Prefs.sp.edit().putString(KEY, a.toString()).apply()
    }
}

/** Opens the SMS app's group-send screen (works from the Phone app too). */
fun openGroupSend(ctx: Context, numbers: List<String>) {
    ctx.startActivity(Intent(ctx, MainActivity::class.java).putExtra("send_to", numbers.joinToString(",")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

// =====================================================================
// Counting helpers
// =====================================================================
fun SmsRepo.countType(type: Int): Int = try {
    cr.query(Telephony.Sms.CONTENT_URI, arrayOf("_id"), "type=?", arrayOf(type.toString()), null)?.use { it.count } ?: 0
} catch (e: Exception) { 0 }

/** Recent outgoing SMS records, including messages still in the outbox and failed sends. */
fun SmsRepo.outgoingMessages(): List<Msg> = try {
    val result = ArrayList<Msg>()
    val types = listOf(Telephony.Sms.MESSAGE_TYPE_SENT, Telephony.Sms.MESSAGE_TYPE_OUTBOX, Telephony.Sms.MESSAGE_TYPE_FAILED)
    cr.query(Telephony.Sms.CONTENT_URI,
        arrayOf("_id", "thread_id", "address", "body", "date", "type", "status"),
        "type IN (?, ?, ?)", types.map { it.toString() }.toTypedArray(), "date DESC LIMIT 1000")?.use { c ->
        while (c.moveToNext()) result += Msg(c.getLong(0), c.getLong(1), c.getString(2) ?: "", c.getString(3) ?: "", c.getLong(4), c.getInt(5), c.getInt(6))
    }
    result
} catch (e: Exception) { emptyList() }

fun smsParts(t: String): Pair<Int, Int> {
    if (t.isEmpty()) return 0 to 1
    val uni = t.any { it.code > 127 }
    val single = if (uni) 70 else 160; val multi = if (uni) 67 else 153
    val parts = if (t.length <= single) 1 else (t.length + multi - 1) / multi
    return t.length to parts
}

// =====================================================================
// Date / time picker dialog (Jalali in Persian mode)
// =====================================================================
private fun icalFor(ms: Long): android.icu.util.Calendar {
    val locale = if (isFa()) android.icu.util.ULocale("fa_IR@calendar=persian")
                 else android.icu.util.ULocale.getDefault()
    return android.icu.util.Calendar.getInstance(locale).apply { timeInMillis = ms }
}

private fun shiftMs(ms: Long, field: Int, n: Int): Long { val c = icalFor(ms); c.add(field, n); return c.timeInMillis }

fun icuFmt(ms: Long, pattern: String): String = try {
    val loc = if (isFa()) android.icu.util.ULocale("fa_IR@calendar=persian") else android.icu.util.ULocale.getDefault()
    android.icu.text.DateFormat.getPatternInstance(pattern, loc).format(Date(ms))
} catch (e: Exception) { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(ms)) }

fun fmtFull(ms: Long) = listNum(icuFmt(ms, "yMMMMd") + "  " + fmtClock(ms))

private fun atHour(h: Int, addDays: Int): Long = Calendar.getInstance().apply {
    add(Calendar.DAY_OF_YEAR, addDays); set(Calendar.HOUR_OF_DAY, h); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

private fun roundMinute(ms: Long) = ms - ms % 60_000L

@Composable
private fun Stepper(label: String, value: String, onUp: () -> Unit, onDown: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPal.current
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.KeyboardArrowUp, null, tint = p.primary, modifier = Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onUp))
        Text(value, color = p.text, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, style = FaStyle.copy(textAlign = TextAlign.Center), modifier = Modifier.padding(vertical = 4.dp))
        Icon(Icons.Default.KeyboardArrowDown, null, tint = p.primary, modifier = Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onDown))
        Text(label, color = p.sub, fontSize = 11.sp, maxLines = 1)
    }
}

@Composable
fun ScheduleDialog(onDismiss: () -> Unit, onPick: (Long) -> Unit) {
    val p = LocalPal.current
    var at by remember { mutableLongStateOf(roundMinute(System.currentTimeMillis() + 3_600_000L)) }
    val valid = at > System.currentTimeMillis() + 20_000L
    AlertDialog(onDismissRequest = onDismiss, containerColor = p.surface, titleContentColor = p.text, textContentColor = p.sub,
        title = { Text(tr("زمان ارسال", "Send time")) },
        text = {
            Column {
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChipX(tr("۱ ساعت دیگر", "In 1 hour"), null, false) { at = roundMinute(System.currentTimeMillis() + 3_600_000L) }
                    FilterChipX(tr("امشب ۲۱:۰۰", "Tonight 21:00"), null, false) { at = atHour(21, if (Calendar.getInstance().get(Calendar.HOUR_OF_DAY) >= 21) 1 else 0) }
                    FilterChipX(tr("فردا ۰۹:۰۰", "Tomorrow 09:00"), null, false) { at = atHour(9, 1) }
                }
                Spacer(Modifier.height(14.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Stepper(tr("سال", "Year"), listNum(icuFmt(at, "y")), { at = shiftMs(at, Calendar.YEAR, 1) }, { at = shiftMs(at, Calendar.YEAR, -1) }, Modifier.weight(1.2f))
                    Stepper(tr("ماه", "Month"), icuFmt(at, "MMMM"), { at = shiftMs(at, Calendar.MONTH, 1) }, { at = shiftMs(at, Calendar.MONTH, -1) }, Modifier.weight(1.4f))
                    Stepper(tr("روز", "Day"), listNum(icuFmt(at, "d")), { at = shiftMs(at, Calendar.DAY_OF_MONTH, 1) }, { at = shiftMs(at, Calendar.DAY_OF_MONTH, -1) }, Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Stepper(tr("ساعت", "Hour"), listNum(SimpleDateFormat("HH", Locale.US).format(Date(at))), { at = shiftMs(at, Calendar.HOUR_OF_DAY, 1) }, { at = shiftMs(at, Calendar.HOUR_OF_DAY, -1) }, Modifier.weight(1f))
                    Stepper(tr("دقیقه", "Minute"), listNum(SimpleDateFormat("mm", Locale.US).format(Date(at))), { at = shiftMs(at, Calendar.MINUTE, 5) }, { at = shiftMs(at, Calendar.MINUTE, -5) }, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Text(fmtFull(at), color = if (valid) p.primary else p.danger, fontWeight = FontWeight.Bold, fontSize = 15.sp, style = FaStyle)
                if (!valid) Text(tr("زمان باید در آینده باشد", "Time must be in the future"), color = p.danger, fontSize = 12.sp, style = FaStyle)
            }
        },
        confirmButton = { TextButton(onClick = { if (valid) onPick(at) }, enabled = valid) { Text(tr("تأیید", "OK"), color = if (valid) p.primary else p.sub) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel"), color = p.text) } })
}

// =====================================================================
// Send screen: single / group / scheduled
// =====================================================================
@Composable
fun SendScreen(repo: SmsRepo, act: ComponentActivity, nav: MutableState<Screen>, s: Screen.Send) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    val sel = remember { mutableStateListOf<String>().apply { addAll(s.to.split(',').map { it.trim() }.filter { it.isNotEmpty() }) } }
    var text by remember { mutableStateOf(s.text) }
    var q by remember { mutableStateOf("") }
    var scheduled by remember { mutableStateOf(s.mode == 1) }
    var at by remember { mutableLongStateOf(0L) }
    var pickAt by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var contacts by remember { mutableStateOf<List<ContactItem>>(emptyList()) }
    val groups = remember { GroupsStore.load(act) }
    LaunchedEffect(Unit) { contacts = withContext(Dispatchers.IO) { runCatching { repo.contacts() }.getOrDefault(emptyList()) } }
    fun nameOf(n: String) = contacts.firstOrNull { norm(it.number) == norm(n) }?.name ?: n
    fun has(n: String) = sel.any { norm(it) == norm(n) }
    fun toggle(n: String) { val ex = sel.firstOrNull { norm(it) == norm(n) }; if (ex != null) sel.remove(ex) else sel.add(n) }
    val title = when (s.mode) { 1 -> tr("ارسال زمان‌بندی شده گروهی", "Scheduled / group send"); 2 -> tr("ارسال گروهی", "Group send"); else -> tr("ارسال پیامک", "Send SMS") }
    val canSend = sel.isNotEmpty() && text.isNotBlank() && !busy && (!scheduled || at > System.currentTimeMillis() + 20_000L)
    val (chars, parts) = smsParts(text)

    fun submit() {
        val body = text.trim()
        val addrs = sel.map { cleanAddr(it) }.filter { it.isNotEmpty() }.distinct()
        if (addrs.isEmpty() || body.isEmpty()) return
        if (scheduled) {
            Scheduler.add(act, addrs, body, at, Prefs.sim.value)
            Toast.makeText(act, tr("پیامک زمان‌بندی شد", "Message scheduled"), Toast.LENGTH_SHORT).show()
            if (Build.VERSION.SDK_INT >= 31) {
                val alarms = act.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                if (!alarms.canScheduleExactAlarms()) runCatching {
                    act.startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${act.packageName}")))
                }
            }
            nav.value = Screen.Scheduled
        } else {
            busy = true
            scope.launch(Dispatchers.IO) {
                var ok = 0
                for (a in addrs) { try { repo.send(a, body); ok++ } catch (e: Exception) { }; delay(150) }
                withContext(Dispatchers.Main) {
                    busy = false
                    if (ok > 0) {
                        Toast.makeText(act, tr("${listNum(ok.toString())} پیامک ارسال شد", "$ok message(s) sent"), Toast.LENGTH_SHORT).show()
                        nav.value = Screen.Dash
                    } else Toast.makeText(act, tr("ابتدا آبتین SMS را برنامه پیش‌فرض کنید", "Set Abtin SMS as default first"), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
        PageHeader(title, { nav.value = Screen.Dash })
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp)) {
            item {
                Column(Modifier.padding(horizontal = 18.dp)) {
                    Text(tr("گیرندگان", "Recipients") + " (" + listNum(sel.size.toString()) + ")", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, style = FaStyle)
                    if (sel.isNotEmpty()) Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        sel.toList().forEach { n ->
                            Text(fixNum(nameOf(n)) + "  ✕", color = Color.White, fontSize = 13.sp, style = FaStyle,
                                modifier = Modifier.clip(RoundedCornerShape(50)).background(p.primary).clickable { sel.remove(n) }.padding(horizontal = 12.dp, vertical = 6.dp))
                        }
                    } else Text(tr("هنوز گیرنده‌ای انتخاب نشده", "No recipients yet"), color = p.sub, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp), style = FaStyle)
                    Spacer(Modifier.height(4.dp))
                    Text(tr("متن پیام", "Message"), color = Cyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, style = FaStyle)
                    Box(Modifier.fillMaxWidth().padding(top = 8.dp).glass(RoundedCornerShape(20.dp)).padding(14.dp)) {
                        BasicTextField(text, { text = it }, textStyle = TextStyle(color = p.text, fontSize = 16.sp, textDirection = TextDirection.Content),
                            cursorBrush = SolidColor(p.primary), modifier = Modifier.fillMaxWidth().heightIn(min = 110.dp),
                            decorationBox = { inner -> Box { if (text.isEmpty()) Text(tr("پیام خود را بنویسید...", "Write your message..."), color = p.sub, fontSize = 16.sp, style = FaStyle); inner() } })
                    }
                    Text(tr("${listNum(chars.toString())} کاراکتر · ${listNum(parts.toString())} پیامک", "$chars chars · $parts SMS"), color = p.sub, fontSize = 12.sp,
                        modifier = Modifier.padding(top = 6.dp, bottom = 10.dp), style = FaStyle)
                }
            }
            item {
                Column(Modifier.padding(horizontal = 18.dp).fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Schedule, null, tint = Color(0xFFB06BFF), modifier = Modifier.size(24.dp))
                        Text(tr("ارسال در زمان مشخص", "Send at a set time"), color = p.text, fontWeight = FontWeight.Bold, style = FaStyle, modifier = Modifier.weight(1f).padding(horizontal = 10.dp))
                        Switch(scheduled, { scheduled = it; if (it && at == 0L) pickAt = true },
                            colors = SwitchDefaults.colors(checkedTrackColor = p.primary, checkedThumbColor = Color.White))
                    }
                    if (scheduled) Row(Modifier.fillMaxWidth().padding(top = 10.dp).clip(RoundedCornerShape(14.dp)).background(p.bg.copy(alpha = .5f)).clickable { pickAt = true }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.DateRange, null, tint = p.primary, modifier = Modifier.size(20.dp))
                        Text(if (at == 0L) tr("انتخاب تاریخ و ساعت", "Pick date & time") else fmtFull(at), color = p.text, style = FaStyle, modifier = Modifier.padding(horizontal = 10.dp))
                    }
                }
            }
            if (groups.isNotEmpty()) item {
                Column(Modifier.padding(top = 14.dp)) {
                    Text(tr("گروه‌ها", "Groups"), color = Cyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, style = FaStyle, modifier = Modifier.padding(horizontal = 18.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        groups.forEach { g -> FilterChipX(g.name + " (" + listNum(g.nums.size.toString()) + ")", null, g.nums.isNotEmpty() && g.nums.all { has(it) }) {
                            val all = g.nums.all { has(it) }
                            g.nums.forEach { n -> if (all) { sel.firstOrNull { x -> norm(x) == norm(n) }?.let { x -> sel.remove(x) } } else if (!has(n)) sel.add(n) }
                        } }
                    }
                }
            }
            item {
                Column(Modifier.padding(horizontal = 18.dp).padding(top = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(tr("مخاطبین", "Contacts"), color = Cyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, style = FaStyle, modifier = Modifier.weight(1f))
                        TextButton(onClick = { val l = contacts.filter { q.isBlank() || it.name.contains(q, true) || it.number.contains(q) }
                            val all = l.all { has(it.number) }
                            l.forEach { c -> if (all) sel.firstOrNull { x -> norm(x) == norm(c.number) }?.let { x -> sel.remove(x) } else if (!has(c.number)) sel.add(c.number) } }) {
                            Text(tr("انتخاب همه", "Select all"), color = p.primary)
                        }
                    }
                    PillField(q, { q = it }, tr("جستجو یا شماره دستی...", "Search or type a number..."), Modifier.fillMaxWidth(), Icons.Default.Search,
                        androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Done),
                        androidx.compose.foundation.text.KeyboardActions(onDone = { if (q.count { it.isDigit() } >= 3 && !has(q.trim())) { sel.add(q.trim()); q = "" } }))
                    if (q.count { it.isDigit() } >= 3) Text(tr("افزودن شماره ", "Add number ") + ltr(q.trim()), color = p.primary, fontSize = 14.sp, style = FaStyle,
                        modifier = Modifier.fillMaxWidth().clickable { if (!has(q.trim())) sel.add(q.trim()); q = "" }.padding(vertical = 10.dp))
                }
            }
            items(contacts.filter { q.isBlank() || it.name.contains(q, true) || it.number.contains(q) }, key = { "sc" + it.id + it.number }) { c ->
                val on = has(c.number)
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 3.dp).glass(RoundedCornerShape(18.dp), androidx.compose.ui.graphics.Brush.linearGradient(
                    listOf(if (on) Color(0x593D7BFF) else Color(0x385A64E6), Color(0x40141964)))).clickable { toggle(c.number) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(repo, c.number, c.name, 42.dp); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name, color = p.text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, style = FaStyle)
                        Text(c.number, color = p.sub, fontSize = 13.sp, style = TextStyle(textDirection = TextDirection.Ltr))
                    }
                    Icon(if (on) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, null, tint = if (on) p.primary else p.sub, modifier = Modifier.size(26.dp))
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp)) {
            GlowButton(if (scheduled) tr("زمان‌بندی ارسال", "Schedule") else if (sel.size > 1) tr("ارسال به ${listNum(sel.size.toString())} نفر", "Send to ${sel.size}") else tr("ارسال", "Send"),
                if (scheduled) Icons.Default.Schedule else Icons.Default.Send, { submit() }, Modifier.fillMaxWidth().height(52.dp), enabled = canSend)
        }
    }
    if (pickAt) ScheduleDialog({ pickAt = false; if (at == 0L) scheduled = false }, { at = it; scheduled = true; pickAt = false })
}

// =====================================================================
// Scheduled messages list
// =====================================================================
@Composable
fun ScheduledScreen(repo: SmsRepo, act: ComponentActivity, nav: MutableState<Screen>) {
    val p = LocalPal.current
    val rev = Scheduler.rev.intValue
    var list by remember { mutableStateOf<List<Scheduler.Item>>(emptyList()) }
    LaunchedEffect(rev, Bus.tick.intValue) { list = withContext(Dispatchers.IO) { Scheduler.load(act).sortedBy { it.at } } }
    val waiting = list.filter { it.state == 0 }; val done = list.filter { it.state != 0 }.sortedByDescending { it.at }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        PageHeader(tr("ارسال زمان‌بندی شده", "Scheduled messages"), { nav.value = Screen.Dash }) {
            CircleBtn(Icons.Default.Add, { nav.value = Screen.Send(1) })
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 20.dp)) {
            if (list.isEmpty()) item { Text(tr("پیامی زمان‌بندی نشده است", "Nothing scheduled"), color = p.sub, modifier = Modifier.fillMaxWidth().padding(32.dp), textAlign = TextAlign.Center) }
            if (waiting.isNotEmpty()) item { ListHead(tr("در انتظار ارسال", "Waiting"), listNum(waiting.size.toString()), Icons.Default.Schedule) }
            items(waiting, key = { it.id }) { it2 -> SchedRow(repo, it2) { Scheduler.cancel(act, it2.id) } }
            if (done.isNotEmpty()) item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f)) { ListHead(tr("ارسال‌شده", "Finished"), listNum(done.size.toString()), Icons.Default.Done) }
                    TextButton(onClick = { Scheduler.clearFinished(act) }) { Text(tr("پاک‌کردن", "Clear"), color = p.primary) }
                }
            }
            items(done, key = { it.id }) { it2 -> SchedRow(repo, it2) { Scheduler.cancel(act, it2.id) } }
        }
    }
}

@Composable
fun SentScreen(repo: SmsRepo, nav: MutableState<Screen>) {
    val p = LocalPal.current
    var messages by remember { mutableStateOf<List<Msg>>(emptyList()) }
    LaunchedEffect(Bus.tick.intValue) {
        messages = withContext(Dispatchers.IO) { repo.outgoingMessages() }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        PageHeader(tr("پیام‌های ارسالی", "Sent messages"), { nav.value = Screen.Dash })
        if (messages.isEmpty()) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(tr("پیام ارسالی‌ای وجود ندارد", "No outgoing messages"), color = p.sub, textAlign = TextAlign.Center)
            }
        } else {
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(messages, key = { it.id }) { m ->
                    val recipient = repo.name(m.address) ?: m.address
                    val stateText = when (m.type) {
                        Telephony.Sms.MESSAGE_TYPE_SENT -> tr("ارسال شد", "Sent")
                        Telephony.Sms.MESSAGE_TYPE_FAILED -> tr("ناموفق", "Failed")
                        else -> tr("در انتظار ارسال", "Pending")
                    }
                    val stateColor = if (m.type == Telephony.Sms.MESSAGE_TYPE_FAILED) p.danger else Cyan
                    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp)
                        .glass(RoundedCornerShape(18.dp)).clickable { nav.value = Screen.Chat(m.threadId, m.address) }.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        Icon(if (m.type == Telephony.Sms.MESSAGE_TYPE_FAILED) Icons.Default.ErrorOutline else Icons.Default.Send,
                            null, tint = stateColor, modifier = Modifier.size(24.dp))
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(fixNum(recipient), color = p.text, fontWeight = FontWeight.Bold, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, style = FaStyle)
                            Text(m.body, color = p.sub, fontSize = 13.sp, maxLines = 2,
                                overflow = TextOverflow.Ellipsis, style = FaStyle)
                            Text("${fmtDay(m.date)} ${fmtClock(m.date)} · $stateText", color = stateColor,
                                fontSize = 12.sp, style = FaStyle, modifier = Modifier.padding(top = 3.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SchedRow(repo: SmsRepo, it2: Scheduler.Item, onDelete: () -> Unit) {
    val p = LocalPal.current
    val names = it2.addrs.map { fixNum(repo.name(it) ?: it) }
    val who = if (names.size > 3) names.take(2).joinToString("، ") + tr(" و ${listNum((names.size - 2).toString())} نفر دیگر", " +${names.size - 2} more") else names.joinToString("، ")
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).glass(RoundedCornerShape(20.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(44.dp).clip(CircleShape).background(OrbBrush), contentAlignment = Alignment.Center) {
            Icon(if (it2.addrs.size > 1) Icons.Default.People else Icons.Default.Schedule, null, tint = Color.White, modifier = Modifier.size(22.dp))
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(who, color = p.text, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, style = FaStyle)
            Text(it2.body, color = p.sub, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, style = FaStyle)
            Text(fmtFull(it2.at) + when (it2.state) { 1 -> "  ✓ " + tr("ارسال شد", "Sent"); 2 -> "  ✗ " + tr("ناموفق", "Failed"); else -> "" },
                color = when (it2.state) { 1 -> Color(0xFF34C77B); 2 -> p.danger; else -> Cyan }, fontSize = 12.sp, style = FaStyle, modifier = Modifier.padding(top = 3.dp))
        }
        CircleBtn(Icons.Default.Delete, onDelete, size = 40.dp, tint = p.danger)
    }
}

// =====================================================================
// Contact groups
// =====================================================================
@Composable
private fun GroupDialog(contacts: List<ContactItem>, initName: String, initSel: List<String>, onSave: (String, List<String>) -> Unit, onDismiss: () -> Unit) {
    val p = LocalPal.current
    var name by remember { mutableStateOf(initName) }
    val sel = remember { mutableStateListOf<String>().apply { addAll(initSel) } }
    fun has(n: String) = sel.any { norm(it) == norm(n) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = p.surface, titleContentColor = p.text, textContentColor = p.sub,
        title = { Text(if (initName.isEmpty()) tr("گروه جدید", "New group") else tr("ویرایش گروه", "Edit group")) },
        text = {
            Column {
                PillField(name, { name = it }, tr("نام گروه", "Group name"), Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Text(tr("${listNum(sel.size.toString())} نفر انتخاب شده", "${sel.size} selected"), color = p.primary, fontSize = 13.sp, style = FaStyle)
                LazyColumn(Modifier.heightIn(max = 320.dp)) {
                    items(contacts, key = { "g" + it.id + it.number }) { c ->
                        Row(Modifier.fillMaxWidth().clickable { val ex = sel.firstOrNull { x -> norm(x) == norm(c.number) }; if (ex != null) sel.remove(ex) else sel.add(c.number) }.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (has(c.number)) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked, null, tint = if (has(c.number)) p.primary else p.sub)
                            Column(Modifier.padding(start = 12.dp)) {
                                Text(c.name, color = p.text, maxLines = 1, overflow = TextOverflow.Ellipsis, style = FaStyle)
                                Text(c.number, color = p.sub, fontSize = 12.sp, style = TextStyle(textDirection = TextDirection.Ltr))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onSave(name.trim(), sel.toList()) }, enabled = name.isNotBlank()) { Text(tr("ذخیره", "Save"), color = p.primary) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tr("لغو", "Cancel"), color = p.text) } })
}

@Composable
fun GroupsScreen(repo: SmsRepo, act: ComponentActivity, nav: MutableState<Screen>) {
    val p = LocalPal.current
    var groups by remember { mutableStateOf(GroupsStore.load(act)) }
    var contacts by remember { mutableStateOf<List<ContactItem>>(emptyList()) }
    LaunchedEffect(Unit) { contacts = withContext(Dispatchers.IO) { runCatching { repo.contacts() }.getOrDefault(emptyList()) } }
    var editing by remember { mutableStateOf<Grp?>(null) }
    var creating by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<Grp?>(null) }
    fun persist(l: List<Grp>) { groups = l; GroupsStore.save(act, l) }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        PageHeader(tr("گروه‌ها", "Groups"), { nav.value = Screen.Contacts }) { CircleBtn(Icons.Default.GroupAdd, { creating = true }) }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 20.dp)) {
            if (groups.isEmpty()) item { Text(tr("هنوز گروهی نساخته‌اید. با دکمه بالا یک گروه بسازید.", "No groups yet. Use the button above."), color = p.sub, modifier = Modifier.fillMaxWidth().padding(32.dp), textAlign = TextAlign.Center) }
            items(groups, key = { it.id }) { g ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp).glass(RoundedCornerShape(22.dp)).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(46.dp).clip(CircleShape).background(OrbBrush), contentAlignment = Alignment.Center) { Icon(Icons.Default.People, null, tint = Color.White) }
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(g.name, color = p.text, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, style = FaStyle)
                            Text(tr("${listNum(g.nums.size.toString())} عضو", "${g.nums.size} members"), color = p.sub, fontSize = 13.sp, style = FaStyle)
                        }
                        CircleBtn(Icons.Default.Edit, { editing = g }, size = 40.dp); Spacer(Modifier.width(6.dp))
                        CircleBtn(Icons.Default.Delete, { deleting = g }, size = 40.dp, tint = p.danger)
                    }
                    Spacer(Modifier.height(10.dp))
                    GlowButton(tr("ارسال پیامک به گروه", "Message this group"), Icons.Default.Send, { openGroupSend(act, g.nums) }, Modifier.fillMaxWidth(), enabled = g.nums.isNotEmpty())
                    Spacer(Modifier.height(8.dp))
                    GlowButton(tr("ارسال زمان‌بندی شده به گروه", "Schedule for this group"), Icons.Default.Schedule, { nav.value = Screen.Send(1, g.nums.joinToString(",")) }, Modifier.fillMaxWidth(), enabled = g.nums.isNotEmpty())
                }
            }
        }
    }
    if (creating) GroupDialog(contacts, "", emptyList(), { n, l -> persist(groups + Grp(System.currentTimeMillis(), n, l)); creating = false }, { creating = false })
    editing?.let { g -> GroupDialog(contacts, g.name, g.nums, { n, l -> persist(groups.map { x -> if (x.id == g.id) Grp(g.id, n, l) else x }); editing = null }, { editing = null }) }
    deleting?.let { g ->
        AlertDialog(onDismissRequest = { deleting = null }, containerColor = p.surface, titleContentColor = p.text, textContentColor = p.sub,
            title = { Text(tr("حذف گروه", "Delete group")) }, text = { Text(tr("گروه «${g.name}» حذف شود؟ (مخاطبین حذف نمی‌شوند)", "Delete group \"${g.name}\"? Contacts stay.")) },
            confirmButton = { TextButton({ persist(groups.filter { it.id != g.id }); deleting = null }) { Text(tr("حذف", "Delete"), color = p.danger) } },
            dismissButton = { TextButton({ deleting = null }) { Text(tr("لغو", "Cancel"), color = p.text) } })
    }
}

// =====================================================================
// Statistics
// =====================================================================
@Composable
fun StatsScreen(repo: SmsRepo, act: ComponentActivity, nav: MutableState<Screen>) {
    val p = LocalPal.current
    var recv by remember { mutableIntStateOf(0) }; var sent by remember { mutableIntStateOf(0) }
    var top by remember { mutableStateOf<List<Pair<String, Int>>>(emptyList()) }
    val waiting = Scheduler.rev.intValue.let { Scheduler.load(act).count { it.state == 0 } }
    LaunchedEffect(Bus.tick.intValue) {
        withContext(Dispatchers.IO) {
            recv = repo.countType(1); sent = repo.countType(2)
            val m = HashMap<String, Int>(); val shown = HashMap<String, String>()
            runCatching {
                repo.cr.query(Telephony.Sms.CONTENT_URI, arrayOf("address"), null, null, "date DESC LIMIT 5000")?.use { c ->
                    while (c.moveToNext()) { val a = c.getString(0) ?: continue; val k = norm(a); m[k] = (m[k] ?: 0) + 1; shown.putIfAbsent(k, a) }
                }
            }
            top = m.entries.sortedByDescending { it.value }.take(5).map { (repo.name(shown[it.key] ?: it.key) ?: shown[it.key] ?: it.key) to it.value }
        }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        PageHeader(tr("آمار پیامک", "Statistics"), { nav.value = Screen.Dash })
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 20.dp)) {
            item {
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    listOf(Triple(tr("دریافتی", "Received"), recv, Icons.Default.Download), Triple(tr("ارسالی", "Sent"), sent, Icons.Default.Send), Triple(tr("زمان‌بندی شده", "Scheduled"), waiting, Icons.Default.Schedule)).forEach { (l, n, ic) ->
                        Column(Modifier.weight(1f).glass(RoundedCornerShape(20.dp)).padding(vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(ic, null, tint = Cyan, modifier = Modifier.size(28.dp))
                            Text(listNum(n.toString()), color = p.text, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            Text(l, color = p.sub, fontSize = 12.sp, style = FaStyle.copy(textAlign = TextAlign.Center))
                        }
                    }
                }
            }
            item { ListHead(tr("بیشترین گفتگو", "Most active"), "", Icons.Default.BarChart) }
            val mx = (top.maxOfOrNull { it.second } ?: 1).coerceAtLeast(1)
            items(top.size) { i ->
                val (n, c) = top[i]
                Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 4.dp).glass(RoundedCornerShape(18.dp)).padding(12.dp)) {
                    Row { Text(n, color = p.text, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = FaStyle); Text(listNum(c.toString()), color = Cyan, fontWeight = FontWeight.Bold) }
                    Box(Modifier.padding(top = 8.dp).fillMaxWidth().height(6.dp).clip(CircleShape).background(p.line)) {
                        Box(Modifier.fillMaxWidth(c.toFloat() / mx).fillMaxHeight().clip(CircleShape).background(OrbBrush))
                    }
                }
            }
        }
    }
}
