package ir.abtin.sms

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap

data class LinkMeta(val url: String, val host: String, val title: String, val desc: String, val image: Bitmap?)

object LinkPreviews {
    private val cache = ConcurrentHashMap<String, LinkMeta>()
    private val failed = ConcurrentHashMap.newKeySet<String>()
    private val urlRx = Regex("(https?://[^\\s]+|www\\.[^\\s]+)", RegexOption.IGNORE_CASE)
    private const val MAX_HTML = 256 * 1024
    private const val MAX_IMG = 2 * 1024 * 1024

    fun firstUrl(t: String): String? {
        val m = urlRx.find(t)?.value ?: return null
        val s = m.trimEnd('.', ',', ')', ']', '!', '?', '؟', '،', ';', ':', '"', '\'')
        return if (s.startsWith("www.", true)) "https://$s" else s
    }

    private fun open(u: String, accept: String): HttpURLConnection {
        var url = u
        repeat(4) {
            val c = (URL(url).openConnection() as HttpURLConnection).apply {
                connectTimeout = 6000; readTimeout = 6000; instanceFollowRedirects = false
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AbtinSMS LinkPreview")
                setRequestProperty("Accept", accept)
                setRequestProperty("Accept-Language", "fa,en;q=0.8")
            }
            val code = c.responseCode
            if (code in 300..399) {
                val loc = c.getHeaderField("Location") ?: error("redirect")
                url = URL(URL(url), loc).toString(); c.disconnect()
                if (!url.startsWith("http", true)) error("scheme")
            } else return c
        }
        error("too many redirects")
    }

    private fun meta(html: String, vararg names: String): String? {
        for (n in names) {
            val a = Regex("<meta[^>]+(?:property|name)\\s*=\\s*[\"']$n[\"'][^>]*content\\s*=\\s*[\"']([^\"']*)[\"']", RegexOption.IGNORE_CASE).find(html)
            val b = Regex("<meta[^>]+content\\s*=\\s*[\"']([^\"']*)[\"'][^>]*(?:property|name)\\s*=\\s*[\"']$n[\"']", RegexOption.IGNORE_CASE).find(html)
            val v = (a ?: b)?.groupValues?.get(1)?.trim()
            if (!v.isNullOrEmpty()) return unescape(v)
        }
        return null
    }

    private fun unescape(s: String) = s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&#x27;", "'")
        .replace("&lt;", "<").replace("&gt;", ">").replace(Regex("\\s+"), " ").trim()

    /** Offline card built from the URL alone, shown at once and kept when the site gives no usable metadata. */
    fun fallback(url: String): LinkMeta {
        val u = runCatching { URL(url) }.getOrNull() ?: return LinkMeta(url, url.take(40), "", "", null)
        val host = u.host.removePrefix("www.")
        val path = runCatching { Uri.decode(u.path.replace("+", " ")) }.getOrDefault(u.path)
        val last = path.trimEnd('/').substringAfterLast('/')
        val isMaps = (host.endsWith("google.com") && path.startsWith("/maps")) || host == "maps.app.goo.gl" || host == "goo.gl"
        val title = when {
            isMaps && path.contains("/place/") -> path.substringAfter("/place/").substringBefore('/').substringBefore(',').trim()
            isMaps -> "Google Maps"
            last.contains('.') && last.substringAfterLast('.').length in 2..5 -> last
            else -> last.take(80)
        }
        val desc = when {
            isMaps -> tr("مکان در نقشه گوگل", "Location on Google Maps")
            last.substringAfterLast('.', "").lowercase() in setOf("zip", "apk", "pdf", "rar", "7z", "mp4", "mp3") -> tr("فایل قابل دانلود", "Downloadable file")
            else -> ""
        }
        return LinkMeta(url, host, title, desc, null)
    }

    suspend fun load(url: String): LinkMeta? {
        cache[url]?.let { return it }
        if (url in failed) return null
        return withContext(Dispatchers.IO) {
            runCatching {
                val c = open(url, "text/html,application/xhtml+xml")
                val ct = c.contentType ?: ""
                if (c.responseCode !in 200..299 || !ct.contains("html", true)) error("not html")
                val raw = c.inputStream.use { readLimited(it, MAX_HTML) }
                val cs = Regex("charset=([\\w-]+)", RegexOption.IGNORE_CASE).find(ct)?.groupValues?.get(1)
                    ?: Regex("charset\\s*=\\s*[\"']?([\\w-]+)", RegexOption.IGNORE_CASE).find(String(raw, Charsets.ISO_8859_1))?.groupValues?.get(1) ?: "UTF-8"
                val html = String(raw, runCatching { charset(cs) }.getOrDefault(Charsets.UTF_8))
                val host = URL(url).host.removePrefix("www.")
                val title = meta(html, "og:title", "twitter:title")
                    ?: Regex("<title[^>]*>([^<]*)</title>", RegexOption.IGNORE_CASE).find(html)?.groupValues?.get(1)?.let { unescape(it) } ?: ""
                val desc = meta(html, "og:description", "twitter:description", "description") ?: ""
                if (title.isEmpty() && desc.isEmpty()) error("empty")
                val img = meta(html, "og:image", "twitter:image")?.let { runCatching { URL(URL(url), it).toString() }.getOrNull() }?.let { loadImage(it) }
                LinkMeta(url, host, title.take(120), desc.take(200), img).also { cache[url] = it }
            }.getOrElse { failed.add(url); null }
        }
    }

    private fun readLimited(i: java.io.InputStream, max: Int): ByteArray {
        val out = java.io.ByteArrayOutputStream(); val b = ByteArray(8192)
        while (out.size() < max) { val n = i.read(b); if (n < 0) break; out.write(b, 0, n) }
        return out.toByteArray()
    }

    private fun loadImage(u: String): Bitmap? = runCatching {
        val c = open(u, "image/*")
        if (c.responseCode !in 200..299) error("http")
        val bytes = c.inputStream.use { readLimited(it, MAX_IMG) }
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1
        while (o.outWidth / (s * 2) >= 640) s *= 2
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
    }.getOrNull()
}

@Composable
fun LinkPreviewCard(body: String, fg: Color, p: Pal) {
    if (!Prefs.linkPreview.value) return
    val url = remember(body) { LinkPreviews.firstUrl(body) } ?: return
    var meta by remember(url) { mutableStateOf(LinkPreviews.fallback(url)) }
    LaunchedEffect(url) { LinkPreviews.load(url)?.let { meta = it } }
    val m = meta
    val ctx = LocalContext.current
    Column(Modifier.padding(top = 6.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.Black.copy(alpha = .22f))
        .clickable { runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(m.url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } }) {
        m.image?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 150.dp), contentScale = ContentScale.Crop) }
        Column(Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) {
            Text(m.host, color = p.sub, fontSize = 11.sp, maxLines = 1)
            if (m.title.isNotEmpty()) Text(m.title, color = fg, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content))
            if (m.desc.isNotEmpty()) Text(m.desc, color = fg.copy(alpha = .8f), fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, style = TextStyle(textDirection = TextDirection.Content))
        }
    }
}
