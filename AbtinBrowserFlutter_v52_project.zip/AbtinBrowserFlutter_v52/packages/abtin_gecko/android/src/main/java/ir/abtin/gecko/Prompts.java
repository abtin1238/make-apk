package ir.abtin.gecko;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.Autocomplete;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSession.PromptDelegate;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** JS dialogs, choices, auth, file pickers, date pickers, popups and Android runtime permissions. */
final class Prompts implements PromptDelegate {
    static final int REQ_FILE = 0x4A11;
    static final int REQ_PERMS = 0x4A12;

    private final Engine e;
    private GeckoResult<PromptResponse> fileResult;
    private FilePrompt filePrompt;
    private Activity fileAct; // the activity that showed the picker (browser or installed web app): the result must go back there
    private GeckoSession.PermissionDelegate.Callback permCallback;

    Prompts(Engine e) { this.e = e; }

    private interface Done { void run(Object v); }

    private GeckoResult<PromptResponse> dart(Map<String, Object> args, final BasePrompt p, final java.util.function.Function<Object, PromptResponse> map) {
        final GeckoResult<PromptResponse> res = new GeckoResult<>();
        e.ask("prompt", args, v -> {
            PromptResponse r;
            try { r = v == null ? p.dismiss() : map.apply(v); } catch (Throwable t) { r = p.dismiss(); }
            res.complete(r);
        });
        return res;
    }

    private static Map<String, Object> args(String kind, String title, String msg) {
        final Map<String, Object> a = new HashMap<>();
        a.put("kind", kind);
        a.put("title", title);
        a.put("message", msg);
        return a;
    }

    @Nullable @Override
    public GeckoResult<PromptResponse> onAlertPrompt(@NonNull GeckoSession s, @NonNull AlertPrompt p) {
        return dart(args("alert", p.title, p.message), p, v -> p.dismiss());
    }

    @Nullable @Override
    public GeckoResult<PromptResponse> onButtonPrompt(@NonNull GeckoSession s, @NonNull ButtonPrompt p) {
        return dart(args("confirm", p.title, p.message), p,
                v -> Boolean.TRUE.equals(v) ? p.confirm(ButtonPrompt.Type.POSITIVE) : p.confirm(ButtonPrompt.Type.NEGATIVE));
    }

    @Nullable @Override
    public GeckoResult<PromptResponse> onTextPrompt(@NonNull GeckoSession s, @NonNull TextPrompt p) {
        final Map<String, Object> a = args("text", p.title, p.message);
        a.put("default", p.defaultValue);
        return dart(a, p, v -> v instanceof String ? p.confirm((String) v) : p.dismiss());
    }

    @Nullable @Override
    public GeckoResult<PromptResponse> onAuthPrompt(@NonNull GeckoSession s, @NonNull AuthPrompt p) {
        final Map<String, Object> a = args("auth", p.title, p.message);
        a.put("host", p.authOptions.uri);
        a.put("onlyPassword", (p.authOptions.flags & AuthPrompt.AuthOptions.Flags.ONLY_PASSWORD) != 0);
        return dart(a, p, v -> {
            if (!(v instanceof Map)) return p.dismiss();
            final Map<?, ?> m = (Map<?, ?>) v;
            final String pw = String.valueOf(m.get("pass"));
            if ((p.authOptions.flags & AuthPrompt.AuthOptions.Flags.ONLY_PASSWORD) != 0) return p.confirm(pw);
            return p.confirm(String.valueOf(m.get("user")), pw);
        });
    }

    // ---- saved passwords: "save this password?" and the autofill picker ----

    @Nullable @Override
    public GeckoResult<PromptResponse> onLoginSave(@NonNull GeckoSession s, @NonNull AutocompleteRequest<Autocomplete.LoginSaveOption> p) {
        if (!e.savePasswords || e.logins == null || p.options == null || p.options.length == 0) return GeckoResult.fromValue(p.dismiss());
        final Autocomplete.LoginSaveOption o = p.options[0];
        final Autocomplete.LoginEntry le = o.value;
        final String host = Logins.hostOf(le.origin);
        if (e.logins.isNever(host)) return GeckoResult.fromValue(p.dismiss());
        final Map<String, Object> a = args("loginSave", null, null);
        a.put("host", host);
        a.put("user", le.username == null ? "" : le.username);
        a.put("update", le.guid != null || e.logins.hasUser(le.origin, le.username));
        return dart(a, p, v -> {
            if ("save".equals(v)) return p.confirm(o);
            if ("never".equals(v)) e.logins.setNever(host);
            return p.dismiss();
        });
    }

    @Nullable @Override
    public GeckoResult<PromptResponse> onLoginSelect(@NonNull GeckoSession s, @NonNull AutocompleteRequest<Autocomplete.LoginSelectOption> p) {
        if (!e.savePasswords || p.options == null || p.options.length == 0) return GeckoResult.fromValue(p.dismiss());
        final List<Integer> saved = new ArrayList<>();
        for (int i = 0; i < p.options.length; i++) {
            final String guid = p.options[i].value.guid;
            // Gecko may include a generated strong password in the same callback; never offer it.
            if (guid != null && !guid.isEmpty()) saved.add(i);
        }
        if (saved.isEmpty()) return GeckoResult.fromValue(p.dismiss());
        final String host = Logins.hostOf(p.options[saved.get(0)].value.origin);
        if (!e.bioLogin) return showSavedLoginPicker(s, p, saved, host, false);

        final GeckoResult<PromptResponse> result = new GeckoResult<>();
        e.authenticateBiometric(host, authenticated -> {
            if (Boolean.FALSE.equals(authenticated)) {
                result.complete(p.dismiss());
            } else if (saved.size() == 1) {
                final PromptResponse response = p.confirm(p.options[saved.get(0)]);
                if (Boolean.TRUE.equals(authenticated)) submitLoginForm(s, host);
                result.complete(response);
            } else {
                showSavedLoginPicker(s, p, saved, host, Boolean.TRUE.equals(authenticated), result::complete);
            }
        });
        return result;
    }

    private GeckoResult<PromptResponse> showSavedLoginPicker(@NonNull GeckoSession s,
            @NonNull AutocompleteRequest<Autocomplete.LoginSelectOption> p, List<Integer> saved,
            String host, boolean authenticated) {
        final GeckoResult<PromptResponse> result = new GeckoResult<>();
        showSavedLoginPicker(s, p, saved, host, authenticated, result::complete);
        return result;
    }

    private void showSavedLoginPicker(@NonNull GeckoSession s,
            @NonNull AutocompleteRequest<Autocomplete.LoginSelectOption> p, List<Integer> saved,
            String host, boolean authenticated, java.util.function.Consumer<PromptResponse> done) {
        final List<Map<String, Object>> items = new ArrayList<>();
        for (int original : saved) {
            final Map<String, Object> m = new HashMap<>();
            m.put("user", p.options[original].value.username == null ? "" : p.options[original].value.username);
            items.add(m);
        }
        final Map<String, Object> a = args("loginSelect", null, null);
        a.put("host", host);
        a.put("items", items);
        e.ask("prompt", a, v -> {
            PromptResponse response = p.dismiss();
            if (v instanceof Number) {
                final int i = ((Number) v).intValue();
                if (i >= 0 && i < saved.size()) {
                    response = p.confirm(p.options[saved.get(i)]);
                    if (authenticated) submitLoginForm(s, host);
                }
            }
            done.accept(response);
        });
    }

    /** Submit only a single-password form whose action stays on the credential's exact origin. */
    private void submitLoginForm(@NonNull GeckoSession s, String host) {
        final String quotedHost = JSONObject.quote(host == null ? "" : host);
        final String js = "(function(){try{" +
                "if(location.hostname.toLowerCase()!==" + quotedHost + ".toLowerCase())return false;" +
                "var ps=Array.from(document.querySelectorAll('input[type=password]:not([disabled]):not([readonly])'));" +
                "if(ps.length!==1||!ps[0].value||!ps[0].form)return false;" +
                "var f=ps[0].form,a=new URL(f.getAttribute('action')||location.href,location.href);" +
                "if(a.origin!==location.origin)return false;" +
                "if(typeof f.requestSubmit==='function')f.requestSubmit();else f.submit();return true;" +
                "}catch(e){return false;}})()";
        e.main.postDelayed(() -> { try { s.evaluateJS(js); } catch (Throwable t) { Log.w("AbtinLogins", "auto-submit unavailable", t); } }, 600);
    }

    @Nullable @Override
    public GeckoResult<PromptResponse> onBeforeUnloadPrompt(@NonNull GeckoSession s, @NonNull BeforeUnloadPrompt p) {
        return dart(args("beforeUnload", p.title, null), p, v -> p.confirm(Boolean.TRUE.equals(v) ? AllowOrDeny.ALLOW : AllowOrDeny.DENY));
    }

    @Nullable @Override
    public GeckoResult<PromptResponse> onRepostConfirmPrompt(@NonNull GeckoSession s, @NonNull RepostConfirmPrompt p) {
        return dart(args("repost", p.title, null), p, v -> p.confirm(Boolean.TRUE.equals(v) ? AllowOrDeny.ALLOW : AllowOrDeny.DENY));
    }

    @Nullable @Override
    public GeckoResult<PromptResponse> onRedirectPrompt(@NonNull GeckoSession s, @NonNull RedirectPrompt p) {
        return GeckoResult.fromValue(p.confirm(AllowOrDeny.ALLOW));
    }

    @Nullable @Override
    public GeckoResult<PromptResponse> onPopupPrompt(@NonNull GeckoSession s, @NonNull PopupPrompt p) {
        return GeckoResult.fromValue(p.confirm(e.blockPopups ? AllowOrDeny.DENY : AllowOrDeny.ALLOW));
    }

    @Nullable @Override
    public GeckoResult<PromptResponse> onChoicePrompt(@NonNull GeckoSession s, @NonNull ChoicePrompt p) {
        final List<Map<String, Object>> flat = new ArrayList<>();
        flatten(p.choices, 0, flat);
        final Map<String, Object> a = args("choice", p.title, p.message);
        a.put("multiple", p.type == ChoicePrompt.Type.MULTIPLE);
        a.put("choices", flat);
        return dart(a, p, v -> {
            if (!(v instanceof List)) return p.dismiss();
            final List<?> ids = (List<?>) v;
            if (p.type == ChoicePrompt.Type.MULTIPLE) {
                final String[] arr = new String[ids.size()];
                for (int i = 0; i < arr.length; i++) arr[i] = String.valueOf(ids.get(i));
                return p.confirm(arr);
            }
            return ids.isEmpty() ? p.dismiss() : p.confirm(String.valueOf(ids.get(0)));
        });
    }

    private static void flatten(ChoicePrompt.Choice[] cs, int depth, List<Map<String, Object>> out) {
        if (cs == null) return;
        for (ChoicePrompt.Choice c : cs) {
            final Map<String, Object> m = new HashMap<>();
            m.put("id", c.id);
            m.put("label", c.label);
            m.put("selected", c.selected);
            m.put("disabled", c.disabled || c.items != null);
            m.put("separator", c.separator);
            m.put("depth", depth);
            out.add(m);
            if (c.items != null) flatten(c.items, depth + 1, out);
        }
    }

    @Nullable @Override
    public GeckoResult<PromptResponse> onColorPrompt(@NonNull GeckoSession s, @NonNull ColorPrompt p) {
        return GeckoResult.fromValue(p.dismiss());
    }

    @Nullable @Override
    public GeckoResult<PromptResponse> onSharePrompt(@NonNull GeckoSession s, @NonNull SharePrompt p) {
        try {
            final Intent it = new Intent(Intent.ACTION_SEND).setType("text/plain");
            it.putExtra(Intent.EXTRA_TEXT, p.uri != null ? p.uri : p.text);
            final Activity act = e.act();
            if (act == null) return GeckoResult.fromValue(p.confirm(SharePrompt.Result.FAILURE));
            act.startActivity(Intent.createChooser(it, null));
            return GeckoResult.fromValue(p.confirm(SharePrompt.Result.SUCCESS));
        } catch (Throwable t) {
            return GeckoResult.fromValue(p.confirm(SharePrompt.Result.FAILURE));
        }
    }

    // ------------------------------------------------------------------ date / time
    @Nullable @Override
    public GeckoResult<PromptResponse> onDateTimePrompt(@NonNull GeckoSession s, @NonNull DateTimePrompt p) {
        final Activity act = e.act();
        if (act == null || p.type == DateTimePrompt.Type.WEEK) return GeckoResult.fromValue(p.dismiss());
        final GeckoResult<PromptResponse> res = new GeckoResult<>();
        final Calendar c = Calendar.getInstance();
        parseInto(c, p.defaultValue);
        final boolean[] done = {false};
        final Runnable cancel = () -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } };
        try {
            if (p.type == DateTimePrompt.Type.TIME) {
                final TimePickerDialog d = new TimePickerDialog(act, (v, h, m) -> {
                    done[0] = true;
                    res.complete(p.confirm(String.format(Locale.US, "%02d:%02d", h, m)));
                }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true);
                d.setOnCancelListener(x -> cancel.run());
                d.show();
            } else {
                final DatePickerDialog d = new DatePickerDialog(act, (v, y, mo, day) -> {
                    if (p.type == DateTimePrompt.Type.DATETIME_LOCAL) {
                        final TimePickerDialog td = new TimePickerDialog(act, (v2, h, m) -> {
                            done[0] = true;
                            res.complete(p.confirm(String.format(Locale.US, "%04d-%02d-%02dT%02d:%02d", y, mo + 1, day, h, m)));
                        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true);
                        td.setOnCancelListener(x -> cancel.run());
                        td.show();
                    } else {
                        done[0] = true;
                        if (p.type == DateTimePrompt.Type.MONTH) res.complete(p.confirm(String.format(Locale.US, "%04d-%02d", y, mo + 1)));
                        else res.complete(p.confirm(String.format(Locale.US, "%04d-%02d-%02d", y, mo + 1, day)));
                    }
                }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
                d.setOnCancelListener(x -> cancel.run());
                d.show();
            }
        } catch (Throwable t) {
            return GeckoResult.fromValue(p.dismiss());
        }
        return res;
    }

    private static void parseInto(Calendar c, @Nullable String v) {
        if (v == null || v.isEmpty()) return;
        try {
            final String[] dt = v.split("T");
            final String[] d = dt[0].contains("-") ? dt[0].split("-") : new String[0];
            if (d.length >= 2) { c.set(Calendar.YEAR, Integer.parseInt(d[0])); c.set(Calendar.MONTH, Integer.parseInt(d[1]) - 1); }
            if (d.length >= 3) c.set(Calendar.DAY_OF_MONTH, Integer.parseInt(d[2]));
            final String tm = dt.length > 1 ? dt[1] : (dt[0].contains(":") ? dt[0] : null);
            if (tm != null) {
                final String[] h = tm.split(":");
                c.set(Calendar.HOUR_OF_DAY, Integer.parseInt(h[0]));
                c.set(Calendar.MINUTE, Integer.parseInt(h[1]));
            }
        } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------------ files
    @Nullable @Override
    public GeckoResult<PromptResponse> onFilePrompt(@NonNull GeckoSession s, @NonNull FilePrompt p) {
        final Activity act = e.act();
        if (act == null || p.type == FilePrompt.Type.FOLDER) return GeckoResult.fromValue(p.dismiss());
        final Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        String type = null, sub = null;
        if (p.mimeTypes != null) {
            for (String raw : p.mimeTypes) {
                final String n = raw.trim().toLowerCase(Locale.ROOT);
                int slash = n.indexOf('/');
                if (slash < 0) slash = n.length();
                final String a = n.substring(0, slash);
                final String b = n.substring(Math.min(slash + 1, n.length()));
                type = type == null ? a : (type.equals(a) ? type : "*");
                sub = sub == null ? b : (sub.equals(b) ? sub : "*");
            }
        }
        intent.setType((type != null && !type.isEmpty() ? type : "*") + "/" + (sub != null && !sub.isEmpty() ? sub : "*"));
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
        if (p.type == FilePrompt.Type.MULTIPLE) intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        if (p.mimeTypes != null && p.mimeTypes.length > 0) intent.putExtra(Intent.EXTRA_MIME_TYPES, p.mimeTypes);
        final GeckoResult<PromptResponse> res = new GeckoResult<>();
        try {
            fileResult = res;
            filePrompt = p;
            fileAct = act;
            act.startActivityForResult(intent, REQ_FILE);
        } catch (ActivityNotFoundException ex) {
            fileResult = null;
            return GeckoResult.fromValue(p.dismiss());
        }
        return res;
    }

    boolean onActivityResult(int req, int resCode, Intent data) {
        if (req != REQ_FILE) return false;
        final GeckoResult<PromptResponse> res = fileResult;
        final FilePrompt p = filePrompt;
        fileResult = null;
        filePrompt = null;
        if (res == null || p == null) return true;
        final Activity act = fileAct != null ? fileAct : e.act();
        fileAct = null;
        if (resCode != Activity.RESULT_OK || data == null || act == null) { res.complete(p.dismiss()); return true; }
        try {
            final ClipData clip = data.getClipData();
            final List<Uri> uris = new ArrayList<>();
            if (clip != null) for (int i = 0; i < clip.getItemCount(); i++) uris.add(clip.getItemAt(i).getUri());
            else if (data.getData() != null) uris.add(data.getData());
            final List<Uri> files = new ArrayList<>();
            for (Uri u : uris) { final Uri f = toFileUri(act, u); if (f != null) files.add(f); }
            if (files.isEmpty()) res.complete(p.dismiss());
            else if (p.type == FilePrompt.Type.MULTIPLE) res.complete(p.confirm(act, files.toArray(new Uri[0])));
            else res.complete(p.confirm(act, files.get(0)));
        } catch (Throwable t) {
            Log.e(Engine.TAG, "file result", t);
            res.complete(p.dismiss());
        }
        return true;
    }

    private static Uri toFileUri(Context c, Uri uri) {
        if ("file".equalsIgnoreCase(uri.getScheme())) return uri;
        String name = null;
        try (Cursor cur = c.getContentResolver().query(uri, null, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                final int i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) name = cur.getString(i);
            }
        } catch (Exception ignored) { }
        if (name == null || name.isEmpty()) name = "file_" + System.currentTimeMillis();
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        final File dir = new File(c.getCacheDir(), "uploads/" + System.nanoTime());
        if (!dir.mkdirs()) return null;
        final File out = new File(dir, name);
        try (InputStream in = c.getContentResolver().openInputStream(uri); OutputStream os = new FileOutputStream(out)) {
            if (in == null) return null;
            final byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        } catch (Exception ex) {
            return null;
        }
        return Uri.fromFile(out);
    }

    // ------------------------------------------------------------------ android runtime permissions
    void requestAndroidPermissions(@Nullable String[] perms, GeckoSession.PermissionDelegate.Callback cb) {
        final Activity act = e.act();
        if (act == null || perms == null || perms.length == 0) { cb.reject(); return; }
        final List<String> need = new ArrayList<>();
        for (String p : perms) if (!Engine.hasPermission(act, p)) need.add(p);
        if (need.isEmpty()) { cb.grant(); return; }
        permCallback = cb;
        act.requestPermissions(need.toArray(new String[0]), REQ_PERMS);
    }

    boolean onPermissionsResult(int req, String[] perms, int[] results) {
        if (req != REQ_PERMS) return false;
        final GeckoSession.PermissionDelegate.Callback cb = permCallback;
        permCallback = null;
        if (cb == null) return true;
        boolean ok = results.length > 0;
        for (int r : results) if (r != android.content.pm.PackageManager.PERMISSION_GRANTED) ok = false;
        if (ok) cb.grant(); else cb.reject();
        return true;
    }
}
