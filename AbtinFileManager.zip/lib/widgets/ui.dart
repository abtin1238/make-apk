import 'package:flutter/material.dart' hide Icon;
import 'app_icon.dart';
import '../core/l10n.dart';
import '../core/icon_prefs.dart';
import '../core/looks.dart';
import '../core/theme.dart';
import '../services/file_ops.dart';

String iconKey(String path, bool dir) {
  if (dir) return 'folder';
  switch (FileOps.catOf(path)) {
    case Cat.images: return 'images';
    case Cat.videos: return 'videos';
    case Cat.audio: return 'audio';
    case Cat.docs: return FileOps.ext(path) == 'pdf' ? 'pdf' : 'docs';
    case Cat.apps: return 'apps';
    case Cat.archives: return 'archives';
    default: return 'other';
  }
}

IconData iconFor(String path, bool dir) {
  if (dir) return IconPrefs.icon('folder');
  final ext = FileOps.ext(path).toLowerCase();
  return _extensionIcons[ext] ?? IconPrefs.icon(iconKey(path, false));
}

Color colorFor(String path, bool dir) => IconPrefs.color(iconKey(path, dir));

// Give common formats recognisable, format-specific glyphs rather than one
// generic document icon for every file in the same category.
({String letter, Color color})? _officeMark(String ext) {
  if ({'doc', 'docx', 'docm', 'dot', 'dotx', 'dotm'}.contains(ext)) {
    return (letter: 'W', color: const Color(0xFF2B579A));
  }
  if ({'xls', 'xlsx', 'xlsm', 'xlsb', 'xlt', 'xltx', 'xltm', 'csv'}.contains(ext)) {
    return (letter: 'X', color: const Color(0xFF217346));
  }
  if ({'ppt', 'pptx', 'pptm', 'pps', 'ppsx', 'ppsm', 'pot', 'potx', 'potm'}.contains(ext)) {
    return (letter: 'P', color: const Color(0xFFD24726));
  }
  return null;
}

final Map<String, IconData> _extensionIcons = {
  // Office documents
  'doc': Icons.description_rounded, 'docx': Icons.description_rounded,
  'docm': Icons.article_rounded, 'dotx': Icons.article_rounded,
  'dotm': Icons.article_rounded,
  'ppt': Icons.slideshow_rounded, 'pptx': Icons.slideshow_rounded,
  'pptm': Icons.slideshow_outlined, 'ppsx': Icons.slideshow_outlined,
  'xls': Icons.table_chart_rounded, 'xlsx': Icons.table_chart_rounded,
  'xlsm': Icons.table_chart_outlined, 'csv': Icons.table_chart_rounded,
  'pdf': Icons.picture_as_pdf_rounded, 'epub': Icons.menu_book_rounded,
  'odt': Icons.article_rounded, 'ods': Icons.grid_on_rounded,
  'odp': Icons.slideshow_rounded, 'rtf': Icons.text_snippet_rounded,
  'txt': Icons.text_snippet_rounded, 'md': Icons.article_rounded,
  'log': Icons.article_rounded,
  // Structured data, web and source files
  'json': Icons.code_rounded, 'xml': Icons.code_rounded,
  'html': Icons.code_rounded, 'htm': Icons.code_rounded,
  'css': Icons.code_rounded, 'js': Icons.code_rounded,
  'ts': Icons.code_rounded, 'dart': Icons.code_rounded,
  'py': Icons.code_rounded, 'java': Icons.code_rounded,
  'kt': Icons.code_rounded, 'kts': Icons.code_rounded,
  'c': Icons.code_rounded, 'h': Icons.code_rounded,
  'cpp': Icons.code_rounded, 'cs': Icons.code_rounded,
  'php': Icons.code_rounded, 'sql': Icons.storage_rounded,
  'yaml': Icons.settings_rounded, 'yml': Icons.settings_rounded,
  'ini': Icons.settings_rounded, 'conf': Icons.settings_rounded,
  'sh': Icons.terminal_rounded, 'bat': Icons.terminal_rounded,
  // Images
  'jpg': Icons.image_rounded, 'jpeg': Icons.image_rounded,
  'png': Icons.image_outlined, 'webp': Icons.photo_rounded,
  'gif': Icons.photo_rounded, 'bmp': Icons.image_rounded,
  'heic': Icons.photo_library_rounded, 'heif': Icons.photo_library_rounded,
  'svg': Icons.image_rounded, 'tiff': Icons.photo_camera_rounded,
  'ico': Icons.image_rounded,
  // Video
  'mp4': Icons.movie_rounded, 'mkv': Icons.video_library_rounded,
  'avi': Icons.movie_rounded, 'mov': Icons.movie_rounded,
  'wmv': Icons.videocam_rounded, 'flv': Icons.smart_display_rounded,
  'webm': Icons.play_circle_rounded, 'm4v': Icons.movie_rounded,
  '3gp': Icons.videocam_rounded, 'ts': Icons.movie_rounded,
  'mpg': Icons.movie_rounded, 'mpeg': Icons.movie_rounded,
  'vob': Icons.video_library_rounded, 'ogv': Icons.play_circle_rounded,
  // Audio
  'mp3': Icons.audiotrack_rounded, 'wav': Icons.graphic_eq_rounded,
  'flac': Icons.equalizer_rounded, 'aac': Icons.music_note_rounded,
  'm4a': Icons.album_rounded, 'ogg': Icons.library_music_rounded,
  'opus': Icons.headphones_rounded, 'wma': Icons.equalizer_rounded,
  'amr': Icons.mic_rounded, 'mid': Icons.music_note_rounded,
  'midi': Icons.music_note_rounded, 'ape': Icons.library_music_rounded,
  'aiff': Icons.equalizer_rounded,
  // Packages and archives
  'apk': Icons.android_rounded, 'aab': Icons.android_rounded,
  'xapk': Icons.install_mobile_rounded, 'apks': Icons.install_mobile_rounded,
  'apkm': Icons.install_mobile_rounded,
  'zip': Icons.folder_zip_rounded, 'rar': Icons.archive_rounded,
  '7z': Icons.inventory_2_rounded, 'tar': Icons.folder_zip_rounded,
  'gz': Icons.compress_rounded, 'tgz': Icons.compress_rounded,
  'bz2': Icons.compress_rounded, 'tbz': Icons.compress_rounded,
  'tbz2': Icons.compress_rounded, 'xz': Icons.compress_rounded,
  'txz': Icons.compress_rounded, 'jar': Icons.archive_rounded,
  'cbz': Icons.menu_book_rounded, 'cbr': Icons.menu_book_rounded,
  'lzma': Icons.compress_rounded, 'z': Icons.compress_rounded,
};

/// Folder / file icon. Folders retain the configurable folder icon; files use
/// their own extension glyph and the established category colour.
class TypeIcon extends StatelessWidget {
  final String path;
  final bool dir;
  final double? size;
  const TypeIcon(this.path, this.dir, {super.key, this.size});
  @override
  Widget build(BuildContext context) {
    if (dir) return KeyIcon('folder', size: size);
    final ext = FileOps.ext(path).toLowerCase();
    final office = _officeMark(ext);
    if (office != null) {
      return _OfficeFileMark(letter: office.letter, color: office.color, size: size ?? 24);
    }
    final glyph = _extensionIcons[ext] ?? IconPrefs.icon(iconKey(path, false));
    return Icon(glyph, size: size, color: colorFor(path, false));
  }
}

class _OfficeFileMark extends StatelessWidget {
  final String letter;
  final Color color;
  final double size;
  const _OfficeFileMark({required this.letter, required this.color, required this.size});

  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(size * .2),
          boxShadow: [BoxShadow(color: color.withOpacity(.22), blurRadius: size * .2, offset: Offset(0, size * .06))],
        ),
        child: Text(letter, style: TextStyle(color: Colors.white, fontSize: size * .58, fontWeight: FontWeight.w800, height: 1)),
      );
}

void snack(BuildContext c, String m) {
  ScaffoldMessenger.of(c).hideCurrentSnackBar();
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));
}

Future<String?> promptText(BuildContext c, String title, {String initial = '', bool obscure = false}) {
  final ctl = TextEditingController(text: initial);
  final dot = initial.lastIndexOf('.');
  ctl.selection = TextSelection(baseOffset: 0, extentOffset: dot > 0 ? dot : initial.length);
  return showDialog<String>(
    context: c,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: TextField(
        controller: ctl, autofocus: true, obscureText: obscure,
        onSubmitted: (v) => Navigator.pop(c, v.trim()),
      ),
      actions: [
        CancelButton(onPressed: () => Navigator.pop(c)),
        FilledButton(onPressed: () => Navigator.pop(c, ctl.text.trim()), child: Text(L.t('ok'))),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext c, String msg) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      content: Text(msg),
      actions: [
        CancelButton(onPressed: () => Navigator.pop(c, false)),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(L.t('ok'))),
      ],
    ),
  );
  return r ?? false;
}

/// Runs [job] behind a blocking spinner; shows error in a snackbar.
Future<bool> busy(BuildContext c, Future<void> Function() job) async {
  showDialog(
    context: c,
    barrierDismissible: false,
    builder: (_) => const PopScope(canPop: false, child: Center(child: CircularProgressIndicator())),
  );
  var ok = true;
  try {
    await job();
  } catch (e) {
    ok = false;
    final msg = e is OpError ? (e.arg == null ? L.t(e.key) : '${L.t(e.key)}: ${e.arg}') : '${L.t('error')}: $e';
    if (c.mounted) snack(c, msg);
  }
  if (c.mounted) Navigator.of(c, rootNavigator: true).pop();
  return ok;
}

/// Like [busy] but shows a title and a percentage bar. The job reports its
/// progress through the callback: 0..1, or null for "unknown" (indeterminate).
Future<bool> busyProgress(BuildContext c, String title, Future<void> Function(void Function(double?) report) job) async {
  final prog = ValueNotifier<double?>(null);
  showDialog(
    context: c,
    barrierDismissible: false,
    builder: (_) => PopScope(
      canPop: false,
      child: AlertDialog(
        title: Text(title),
        content: ValueListenableBuilder<double?>(
          valueListenable: prog,
          builder: (_, v, __) => Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            LinearProgressIndicator(value: v, minHeight: 8, borderRadius: BorderRadius.circular(6)),
            const SizedBox(height: 8),
            Text(v == null ? '…' : '${(v * 100).clamp(0, 100).round()}%'),
          ]),
        ),
      ),
    ),
  );
  var ok = true;
  try {
    await job((v) => prog.value = v);
  } catch (e) {
    ok = false;
    final msg = e is OpError ? (e.arg == null ? L.t(e.key) : '${L.t(e.key)}: ${e.arg}') : '${L.t('error')}: $e';
    if (c.mounted) snack(c, msg);
  }
  if (c.mounted) Navigator.of(c, rootNavigator: true).pop();
  prog.dispose();
  return ok;
}

class GradCard extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  final double radius;
  const GradCard({super.key, required this.child, this.onTap, this.padding = const EdgeInsets.all(14), this.radius = 18});
  @override
  Widget build(BuildContext context) {
    AppStyleScope.watch(context); // repaint when the look changes
    final r = BorderRadius.circular(radius);
    return DecoratedBox(
      decoration: Looks.card(context, radius: radius),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(borderRadius: r, onTap: onTap, child: Padding(padding: padding, child: child)),
      ),
    );
  }
}


/// Red "cancel" button used in every dialog, so cancelling is always easy to spot.
class CancelButton extends StatelessWidget {
  final VoidCallback? onPressed;
  final String? label;
  final bool icon;
  const CancelButton({super.key, required this.onPressed, this.label, this.icon = false});
  @override
  Widget build(BuildContext context) {
    final st = TextButton.styleFrom(foregroundColor: AppColors.danger, backgroundColor: AppColors.danger.withOpacity(.16));
    final t = Text(label ?? L.t('cancel'), maxLines: 1, overflow: TextOverflow.ellipsis);
    return icon
        ? TextButton.icon(onPressed: onPressed, style: st, icon: const Icon(Icons.close_rounded, size: 18), label: t)
        : TextButton(onPressed: onPressed, style: st, child: t);
  }
}

/// Slider that always runs left (min) -> right (max), also in Persian / RTL, so values and colour tracks never flip.
class LSlider extends StatelessWidget {
  final double value, min, max;
  final int? divisions;
  final Color? activeColor;
  final String? label;
  final ValueChanged<double>? onChanged;
  final ValueChanged<double>? onChangeEnd;
  const LSlider({super.key, required this.value, this.min = 0, this.max = 1, this.divisions, this.activeColor, this.label, this.onChanged, this.onChangeEnd});
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: TextDirection.ltr,
        child: Slider(value: value, min: min, max: max, divisions: divisions, label: label, activeColor: activeColor, onChanged: onChanged, onChangeEnd: onChangeEnd),
      );
}
