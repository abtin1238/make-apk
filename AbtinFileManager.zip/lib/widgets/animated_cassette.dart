import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

/// Artwork bounds in design units (the flat cassette illustration).
const Rect _kBounds = Rect.fromLTWH(58, 84, 684, 432);

/// width / height of the cassette artwork.
const double kCassetteAspect = 684 / 432;

// ---- palette (taken from the reference illustration) ----
const Color _kBody = Color(0xFF43444E);
const Color _kInk = Color(0xFF2C2D33);
const Color _kGroove = Color(0xFF6B6C78);
const Color _kRed = Color(0xFFE24B43);
const Color _kGlass = Color(0xFF6FD0E3);
const Color _kMetal = Color(0xFFA9A9AE);
const Color _kBand = Color(0xFF3D3D44);

// ---- tape mechanics (design units) ----
const double _kOpening = 44; // radius of the reel opening
const double _kHub = 36; // radius of the toothed hub
const double _kPackMin = 37.1; // tape pack radius when the reel is empty
const double _kTapeSpeed = 150; // tape linear speed at 1.0x, units / second

const Rect _kWinInner = Rect.fromLTRB(322, 242, 478, 318);
const Offset _kLeftReel = Offset(258, 280);
const Offset _kRightReel = Offset(541, 280);

/// Radius of the tape pack that holds [fill] (0..1) of the whole tape.
/// Tape area is conserved, so r^2 grows linearly with the amount of tape.
double _packRadius(double fill) {
  final f = fill.clamp(0.0, 1.0).toDouble();
  return math.sqrt(_kPackMin * _kPackMin +
      (_kOpening * _kOpening - _kPackMin * _kPackMin) * f);
}

bool _hasRtl(String s) => RegExp(r'[֐-ࣿ]').hasMatch(s);

class _CassetteModel extends ChangeNotifier {
  double leftAngle = 0;
  double rightAngle = math.pi; // the red marker of the right reel starts at the bottom
  double progress = 0;
  double travel = 0; // distance the tape has travelled (design units)
  void ping() => notifyListeners();
}

/// A flat cassette whose reels turn, whose tape moves from the left reel to the
/// right reel and whose tape packs grow / shrink with the song position.
///
/// The speed follows the playback rate: tape linear speed is constant
/// (`_kTapeSpeed * rate`) so a reel turns faster while it is nearly empty and
/// slower when it is full, exactly like a real cassette.
class AnimatedCassette extends StatefulWidget {
  final bool playing;
  final double rate;

  /// Song position as 0..1, read every frame.
  final double Function() progress;
  final String title;
  final String artist;
  final Uint8List? art;

  const AnimatedCassette({
    super.key,
    required this.playing,
    required this.rate,
    required this.progress,
    required this.title,
    this.artist = '',
    this.art,
  });

  @override
  State<AnimatedCassette> createState() => _AnimatedCassetteState();
}

class _AnimatedCassetteState extends State<AnimatedCassette>
    with SingleTickerProviderStateMixin {
  final _CassetteModel _m = _CassetteModel();
  late final Ticker _ticker;
  Duration _last = Duration.zero;

  @override
  void initState() {
    super.initState();
    _m.progress = widget.progress();
    _ticker = createTicker(_tick)..start();
  }

  void _tick(Duration t) {
    var dt = (t - _last).inMicroseconds / 1000000.0;
    _last = t;
    if (dt < 0 || dt > .1) dt = .016;
    final p = widget.progress().clamp(0.0, 1.0).toDouble();
    final moved = (p - _m.progress).abs() > .0002;
    _m.progress = p;
    if (widget.playing) {
      final rate = widget.rate.clamp(.25, 4.0).toDouble();
      final v = _kTapeSpeed * rate;
      // angular speed = linear speed / radius of the pack
      _m.leftAngle += v / _packRadius(1 - p) * dt;
      _m.rightAngle += v / _packRadius(p) * dt;
      _m.travel += v * dt;
    }
    if (widget.playing || moved) _m.ping();
  }

  @override
  void dispose() {
    _ticker.dispose();
    _m.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: kCassetteAspect,
      child: LayoutBuilder(builder: (context, bc) {
        final sx = bc.maxWidth / _kBounds.width;
        double x(double v) => (v - _kBounds.left) * sx;
        double y(double v) => (v - _kBounds.top) * sx;
        final hasArt = widget.art != null;
        final textLeft = hasArt ? 209.0 : 165.0;
        final title = widget.title.trim();
        final artist = widget.artist.trim();
        return Stack(clipBehavior: Clip.none, children: [
          const Positioned.fill(
              child: RepaintBoundary(
                  child: CustomPaint(painter: _CassetteBodyPainter()))),
          Positioned.fill(
              child: RepaintBoundary(
                  child: CustomPaint(painter: _CassetteMechPainter(_m)))),
          if (hasArt)
            Positioned(
              left: x(165),
              top: y(154),
              width: 36 * sx,
              height: 36 * sx,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(3 * sx),
                child: Image.memory(widget.art!,
                    fit: BoxFit.cover,
                    gaplessPlayback: true,
                    errorBuilder: (_, __, ___) => const SizedBox.shrink()),
              ),
            ),
          Positioned(
            left: x(textLeft),
            top: y(148),
            width: (685 - textLeft) * sx,
            height: 26 * sx,
            child: Align(
              alignment: _hasRtl(title)
                  ? Alignment.centerRight
                  : Alignment.centerLeft,
              child: Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textDirection:
                    _hasRtl(title) ? TextDirection.rtl : TextDirection.ltr,
                style: TextStyle(
                    fontFamily: 'Vazir',
                    fontSize: 19 * sx,
                    height: 1.15,
                    fontWeight: FontWeight.w700,
                    color: _kInk),
              ),
            ),
          ),
          if (artist.isNotEmpty)
            Positioned(
              left: x(textLeft),
              top: y(175),
              width: (395 - textLeft) * sx,
              height: 16 * sx,
              child: Align(
                alignment: _hasRtl(artist)
                    ? Alignment.centerRight
                    : Alignment.centerLeft,
                child: Text(
                  artist,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textDirection:
                      _hasRtl(artist) ? TextDirection.rtl : TextDirection.ltr,
                  style: TextStyle(
                      fontFamily: 'Vazir',
                      fontSize: 12 * sx,
                      height: 1.1,
                      color: _kGroove),
                ),
              ),
            ),
        ]);
      }),
    );
  }
}

// ---------------------------------------------------------------------------
// Static layer: shell, label, stripes, Persian printing. Painted only once.
// ---------------------------------------------------------------------------
class _CassetteBodyPainter extends CustomPainter {
  const _CassetteBodyPainter();

  void _text(Canvas c, String s, Offset anchor, double size, Color color,
      {FontWeight weight = FontWeight.w500,
      TextAlign align = TextAlign.center}) {
    final tp = TextPainter(
      text: TextSpan(
          text: s,
          style: TextStyle(
              fontFamily: 'Vazir',
              fontSize: size,
              color: color,
              fontWeight: weight,
              height: 1.0)),
      textDirection: TextDirection.rtl,
    )..layout();
    double dx;
    switch (align) {
      case TextAlign.right:
        dx = anchor.dx - tp.width;
        break;
      case TextAlign.left:
        dx = anchor.dx;
        break;
      default:
        dx = anchor.dx - tp.width / 2;
    }
    tp.paint(c, Offset(dx, anchor.dy - tp.height / 2));
  }

  void _screw(Canvas c, Offset o) {
    c.drawCircle(o, 9, Paint()..color = const Color(0xFF4D4E5A));
    c.drawCircle(
        o,
        9,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5
          ..color = _kInk);
    c.drawLine(
        o + const Offset(-5, 5),
        o + const Offset(5, -5),
        Paint()
          ..strokeWidth = 2.5
          ..strokeCap = StrokeCap.round
          ..color = _kInk);
  }

  void _hole(Canvas c, Offset o) {
    c.drawCircle(o, 14, Paint()..color = _kGlass);
    c.drawCircle(
        o,
        14,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..color = _kInk);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final s = math.min(size.width / _kBounds.width, size.height / _kBounds.height);
    canvas.save();
    canvas.scale(s);
    canvas.translate(-_kBounds.left, -_kBounds.top);

    final fill = Paint()..color = _kBody;
    final edge = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..strokeJoin = StrokeJoin.round
      ..color = _kInk;
    final groove = Paint()
      ..strokeWidth = 3
      ..strokeCap = StrokeCap.round
      ..color = _kGroove;

    // soft drop shadow
    canvas.drawRRect(
        RRect.fromLTRBR(74, 98, 726, 516, const Radius.circular(16)),
        Paint()
          ..color = Colors.black.withOpacity(.38)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 14));

    // side nubs
    for (final x in const [62.0, 724.0]) {
      final r = RRect.fromLTRBR(x, 352, x + 14, 506, const Radius.circular(5));
      canvas.drawRRect(r, fill);
      canvas.drawRRect(r, edge);
    }

    // shell
    final shell =
        RRect.fromLTRBR(70, 88, 730, 506, const Radius.circular(14));
    canvas.drawRRect(shell, fill);
    canvas.drawRRect(shell, edge);

    // bottom trapezoid
    final trap = Path()
      ..moveTo(190, 416)
      ..lineTo(610, 416)
      ..quadraticBezierTo(618, 416, 620, 424)
      ..lineTo(642, 504)
      ..quadraticBezierTo(644, 512, 636, 512)
      ..lineTo(164, 512)
      ..quadraticBezierTo(156, 512, 158, 504)
      ..lineTo(180, 424)
      ..quadraticBezierTo(182, 416, 190, 416)
      ..close();
    canvas.drawPath(trap, fill);
    canvas.drawPath(trap, edge);

    canvas.drawLine(const Offset(110, 105), const Offset(690, 105), groove);
    canvas.drawLine(const Offset(200, 425), const Offset(600, 425), groove);

    // label
    final label = RRect.fromLTRBR(107, 128, 693, 390, const Radius.circular(6));
    canvas.drawRRect(label, Paint()..color = Colors.white);
    canvas.save();
    canvas.clipRRect(label);
    canvas.drawRect(const Rect.fromLTRB(107, 128, 693, 143), Paint()..color = _kRed);
    canvas.drawRect(const Rect.fromLTRB(107, 206, 693, 219),
        Paint()..color = const Color(0xFFF2F2F2));
    // striped side panels
    final stripe = Paint()
      ..strokeWidth = 1.6
      ..color = const Color(0xFF7D7D85);
    for (final x0 in const [107.0, 597.0]) {
      for (var yy = 222.0; yy < 338; yy += 6) {
        canvas.drawLine(Offset(x0, yy), Offset(x0 + 96, yy), stripe);
      }
    }
    // window frame
    final frame =
        RRect.fromLTRBR(205, 219, 597, 340, const Radius.circular(6));
    canvas.drawRRect(frame, fill);
    canvas.drawRRect(
        frame,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = _kInk);
    // bottom band
    canvas.drawRect(const Rect.fromLTRB(107, 340, 693, 390), Paint()..color = _kBand);
    canvas.drawRect(const Rect.fromLTRB(497, 348, 592, 386), Paint()..color = _kRed);
    canvas.restore();
    canvas.drawRRect(label, edge);

    // ---- Persian printing ----
    // side indicator box ("ب" instead of "B")
    canvas.drawRRect(
        RRect.fromLTRBR(121, 154, 157, 190, const Radius.circular(3)), fill);
    _text(canvas, 'ب', const Offset(139, 174), 27, Colors.white,
        weight: FontWeight.w800);

    // noise reduction row: "کاهش نویز [      ] ☐ ورودی ☐ خروجی"
    _text(canvas, 'کاهش نویز', const Offset(683, 194), 13.5, _kInk,
        weight: FontWeight.w700, align: TextAlign.right);
    final bracket = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..color = _kInk;
    final br = Path()
      ..moveTo(546, 187)
      ..lineTo(541, 187)
      ..lineTo(541, 200)
      ..lineTo(546, 200)
      ..moveTo(610, 187)
      ..lineTo(615, 187)
      ..lineTo(615, 200)
      ..lineTo(610, 200);
    canvas.drawPath(br, bracket);
    for (final bx in const [531.0, 466.0]) {
      canvas.drawRect(Rect.fromLTWH(bx - 11, 188, 11, 11), bracket);
    }
    _text(canvas, 'ورودی', const Offset(516, 194), 13.5, _kInk,
        weight: FontWeight.w700, align: TextAlign.right);
    _text(canvas, 'خروجی', const Offset(451, 194), 13.5, _kInk,
        weight: FontWeight.w700, align: TextAlign.right);

    // bottom band
    _text(canvas, 'بایاس معمولی ۱۲۰ میکروثانیه EQ', const Offset(487, 366), 14.5,
        Colors.white,
        align: TextAlign.right);
    _text(canvas, 'الف', const Offset(522, 367), 25, Colors.white,
        weight: FontWeight.w800);
    canvas.drawLine(
        const Offset(545, 354),
        const Offset(545, 380),
        Paint()
          ..strokeWidth = 1.8
          ..color = Colors.white.withOpacity(.85));
    _text(canvas, '۶۰', const Offset(569, 367), 25, Colors.white,
        weight: FontWeight.w800);

    // holes + screws
    for (final o in const [
      Offset(243, 485),
      Offset(307, 479),
      Offset(493, 479),
      Offset(558, 485)
    ]) {
      _hole(canvas, o);
    }
    for (final o in const [
      Offset(90, 103),
      Offset(710, 103),
      Offset(90, 487),
      Offset(710, 487),
      Offset(400, 447)
    ]) {
      _screw(canvas, o);
    }
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _CassetteBodyPainter old) => false;
}

// ---------------------------------------------------------------------------
// Moving layer: reels, tape packs and the tape in the centre window.
// ---------------------------------------------------------------------------
class _CassetteMechPainter extends CustomPainter {
  final _CassetteModel m;
  _CassetteMechPainter(this.m) : super(repaint: m);

  void _reel(Canvas c, Offset center, double angle, double pack) {
    c.save();
    c.translate(center.dx, center.dy);
    // opening ring
    c.drawCircle(Offset.zero, _kOpening + 3, Paint()..color = _kBody);
    c.drawCircle(
        Offset.zero,
        _kOpening + 3,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..color = _kInk);
    c.drawCircle(Offset.zero, _kOpening, Paint()..color = _kGlass);
    // tape pack (grows when the reel fills, shrinks when it empties)
    c.drawCircle(Offset.zero, pack, Paint()..color = _kBody);
    final wind = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .9
      ..color = Colors.white.withOpacity(.12);
    for (var r = pack - 2.6; r > _kHub + 1.5; r -= 2.6) {
      c.drawCircle(Offset.zero, r, wind);
    }
    // hub
    c.rotate(angle);
    c.drawCircle(Offset.zero, _kHub, Paint()..color = _kMetal);
    c.drawCircle(
        Offset.zero,
        _kHub,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = _kBody);
    c.drawCircle(Offset.zero, 26, Paint()..color = _kGlass);
    c.drawCircle(
        Offset.zero,
        26,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = _kBody);
    final tooth = Paint()..color = _kMetal;
    final toothEdge = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..color = _kBody;
    for (var i = 0; i < 6; i++) {
      c.save();
      c.rotate(i * math.pi / 3);
      final r = RRect.fromLTRBR(-3.5, -27, 3.5, -18, const Radius.circular(1.5));
      c.drawRRect(r, tooth);
      c.drawRRect(r, toothEdge);
      c.restore();
    }
    // red marker on the ring so the rotation is easy to see
    c.drawRRect(
        RRect.fromLTRBR(-8, -(_kHub - 1), 8, -(_kHub - 8), const Radius.circular(2)),
        Paint()..color = _kRed);
    c.restore();
  }

  void _window(Canvas c) {
    final frame = RRect.fromLTRBR(318, 238, 482, 322, const Radius.circular(4));
    c.drawRRect(frame, Paint()..color = _kInk);
    c.save();
    c.clipRect(_kWinInner);
    c.drawRect(_kWinInner, Paint()..color = _kGlass);

    final p = m.progress.clamp(0.0, 1.0).toDouble();
    final wl = 14 + 40 * (1 - p);
    final wr = 14 + 40 * p;
    final left = Rect.fromLTRB(_kWinInner.left, _kWinInner.top,
        _kWinInner.left + wl, _kWinInner.bottom);
    final right = Rect.fromLTRB(_kWinInner.right - wr, _kWinInner.top,
        _kWinInner.right, _kWinInner.bottom);
    final packPaint = Paint()..color = _kBody;
    c.drawRect(left, packPaint);
    c.drawRect(right, packPaint);

    // winding lines scroll with the tape; left pack face moves up, right pack face moves down
    final line = Paint()
      ..strokeWidth = 1.2
      ..color = Colors.white.withOpacity(.16);
    final off = m.travel % 6;
    for (var yy = _kWinInner.top - 6; yy < _kWinInner.bottom + 6; yy += 6) {
      final yl = yy - off + 6;
      final yr = yy + off;
      c.drawLine(Offset(left.left, yl), Offset(left.right, yl), line);
      c.drawLine(Offset(right.left, yr), Offset(right.right, yr), line);
    }

    // the tape itself, running from the left pack to the right pack
    final tape = Rect.fromLTRB(left.right, 305, right.left, 313);
    if (tape.width > 0) {
      c.drawRect(tape, Paint()..color = _kInk);
      final tick = Paint()
        ..strokeWidth = 1.4
        ..color = Colors.white.withOpacity(.28);
      c.save();
      c.clipRect(tape);
      final shift = m.travel % 10;
      for (var xx = tape.left - 10; xx < tape.right + 10; xx += 10) {
        c.drawLine(Offset(xx + shift, 306), Offset(xx + shift, 312), tick);
      }
      c.restore();
    }

    // glass reflections
    c.drawRect(const Rect.fromLTRB(322, 256, 478, 270),
        Paint()..color = Colors.white.withOpacity(.35));
    c.drawRect(const Rect.fromLTRB(322, 274, 478, 278),
        Paint()..color = Colors.white.withOpacity(.2));
    c.restore();
  }

  @override
  void paint(Canvas canvas, Size size) {
    final s = math.min(size.width / _kBounds.width, size.height / _kBounds.height);
    canvas.save();
    canvas.scale(s);
    canvas.translate(-_kBounds.left, -_kBounds.top);
    final p = m.progress.clamp(0.0, 1.0).toDouble();
    _window(canvas);
    _reel(canvas, _kLeftReel, m.leftAngle, _packRadius(1 - p));
    _reel(canvas, _kRightReel, m.rightAngle, _packRadius(p));
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _CassetteMechPainter old) => old.m != m;
}
