import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import '../widgets/abtin_global_rail.dart';
import 'package:flutter/services.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:media_kit/media_kit.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:permission_handler/permission_handler.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../core/theme.dart';
import '../widgets/tonearm.dart';
import '../widgets/animated_cassette.dart';
import '../services/player_service.dart';
import 'audio_options_screen.dart';
import 'equalizer_screen.dart';
import 'tag_editor_screen.dart';
import 'viewer_delete.dart';
import '../widgets/ui.dart';

class AudioPlayerScreen extends StatefulWidget {
  const AudioPlayerScreen({super.key});
  @override
  State<AudioPlayerScreen> createState() => _AudioPlayerScreenState();
}

class _AudioPlayerScreenState extends State<AudioPlayerScreen>
    with SingleTickerProviderStateMixin {
  static const _vizChannel = EventChannel('abtin/audio_viz');
  static const _specChannel = MethodChannel('abtin/audio_spec');
  // Offline spectrum (works on every phone): decoded once natively, then read by playback position.
  Timer? _specTimer;
  Uint8List? _specData;
  int _specFps = 30, _specBands = 40;
  String _specPath = '';
  bool _specBusy = false;
  bool _sim =
      false; // last-resort animated bars when the file can't be analysed
  int _simRetryAt =
      0; // ms timestamp: when the demo mode may try the real analysis again
  static final Map<String, (Uint8List, int, int)> _specCache = {};
  String _specErr = '';
  late final AnimationController spin =
      AnimationController(vsync: this, duration: const Duration(seconds: 12));
  final lyrCtl = ScrollController();
  StreamSubscription<dynamic>? _vizSub;
  List<double> _spectrum = List.filled(40, 0);
  bool visualizerOn = false;
  List<(Duration, String)>? lrc;
  String? lrcFor;
  bool showLyrics = false;
  int _lastIdx = -1;
  double? _drag;
  bool remainFlip =
      false; // swaps total / remaining time in the classic & warm styles
  String _musicTheme = 'original';

  static const _musicThemes = <String, String>{
    'original': 'تم فعلی',
    'classic': 'کلاسیک',
    'cyber': 'سایبرپانک',
    'neo': 'کاست',
  };

  Color get _musicAccent => switch (_musicTheme) {
        'classic' => const Color(0xFFFFB52E),
        'cyber' => const Color(0xFF00D9FF),
        'neo' => const Color(0xFFB57BFF),
        _ => const Color(0xFF3D9BFF),
      };

  Color get _musicAccent2 => switch (_musicTheme) {
        'classic' => const Color(0xFFFF6A00),
        'cyber' => const Color(0xFFFF35D3),
        'neo' => const Color(0xFF42D9FF),
        _ => const Color(0xFF8B5CF6),
      };

  Future<void> _loadMusicTheme() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('musicPlayerTheme') ?? 'original';
    if (mounted && _musicThemes.containsKey(saved))
      setState(() => _musicTheme = saved);
  }

  Future<void> _setMusicTheme(String id) async {
    if (!_musicThemes.containsKey(id)) return;
    setState(() => _musicTheme = id);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('musicPlayerTheme', id);
  }

  @override
  void initState() {
    super.initState();
    _loadMusicTheme();
    // pre-analyse the current file so the visualizer starts instantly when it is switched on
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final pl = context.read<PlayerService>();
      if (pl.hasQueue && !pl.current.startsWith('http')) _analyze(pl.current);
    });
  }

  Future<void> _addLyrics(PlayerService pl) async {
    if (pl.current.startsWith('http')) return;
    final r = await FilePicker.platform.pickFiles();
    final f = r?.files.single.path;
    if (f == null || !mounted) return;
    if (!await ensureSdAll(context, [pl.current])) return;
    await Saf.copyTo(f, '${p.withoutExtension(pl.current)}.lrc');
    lrcFor = null;
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    spin.dispose();
    lyrCtl.dispose();
    _vizSub?.cancel();
    _specTimer?.cancel();
    super.dispose();
  }

  Future<void> _toggleVisualizer() async {
    if (visualizerOn) {
      await _vizSub?.cancel();
      _vizSub = null;
      _specTimer?.cancel();
      _specTimer = null;
      if (mounted)
        setState(() {
          visualizerOn = false;
          _spectrum = List.filled(40, 0);
        });
      return;
    }
    final pl = context.read<PlayerService>();
    if (!pl.hasQueue) return;
    setState(() => visualizerOn = true);
    // Use the app's device-independent, pre-decoded spectrum path. Do not use
    // android.media.audiofx.Visualizer: many devices block it and it requires
    // microphone permission. initState pre-analyzes the current local track;
    // cached analysis therefore starts on the first visualizer frame.
    _sim = false;
    _specTimer?.cancel();
    _specTimer = null;
    _spectrum = List.filled(_specBands, 0.0);
    final ready = await _startOfflineSpectrum(pl);
    if (!ready && mounted && visualizerOn) {
      setState(() => visualizerOn = false);
      final reason = pl.current.startsWith('http')
          ? 'تحلیل طیف برای فایل‌های آنلاین در این روش پشتیبانی نمی‌شود.'
          : 'تحلیل صوت این فایل انجام نشد: $_specErr';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(reason)),
      );
    }
  }

  /// true = ready, false = this file can't be analysed, null = another analysis is still running.
  Future<bool?> _analyze(String path) async {
    if (_specPath == path && _specData != null) return true;
    final c = _specCache[path];
    if (c != null) {
      _specData = c.$1;
      _specFps = c.$2;
      _specBands = c.$3;
      _specPath = path;
      return true;
    }
    if (_specBusy) return null;
    _specBusy = true;
    try {
      if (!File(path).existsSync()) {
        _specErr = 'file not found';
        return false;
      }
      final r = await _specChannel.invokeMethod<Map>('analyze', {'path': path});
      final data = r?['data'];
      if (data is! Uint8List || data.isEmpty) {
        _specErr = 'empty result';
        return false;
      }
      _specData = data;
      _specFps = (r?['fps'] as num?)?.toInt() ?? 30;
      _specBands = (r?['bands'] as num?)?.toInt() ?? 40;
      _specPath = path;
      if (_specCache.length >= 4) _specCache.remove(_specCache.keys.first);
      _specCache[path] = (data, _specFps, _specBands);
      return true;
    } on PlatformException catch (e) {
      _specErr = '${e.code}: ${e.message}';
      return false;
    } catch (e) {
      _specErr = '$e';
      return false;
    } finally {
      _specBusy = false;
    }
  }

  Future<bool> _startOfflineSpectrum(PlayerService pl) async {
    final path = pl.current;
    bool? ok = await _analyze(path);
    // another analysis is still running (e.g. the previous track): wait for it, don't fall back to the demo
    for (var i = 0; ok == null && i < 120 && mounted && visualizerOn; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      ok = await _analyze(path);
    }
    if (ok != true || !mounted || !visualizerOn) return false;
    _specTimer?.cancel();
    _specTimer =
        Timer.periodic(const Duration(milliseconds: 40), (_) => _specTick());
    return true;
  }

  void _specTick() {
    if (!mounted || !visualizerOn) return;
    final pl = context.read<PlayerService>();
    if (!pl.hasQueue) return;
    if (_sim) {
      final nowMs = DateTime.now().millisecondsSinceEpoch;
      if (!pl.current.startsWith('http') &&
          !_specBusy &&
          nowMs >= _simRetryAt) {
        _simRetryAt = nowMs + 4000;
        final p0 = pl.current;
        _analyze(p0).then((ok) {
          if (ok == true && mounted && visualizerOn && pl.current == p0)
            _sim = false;
        });
      }
      final tt = nowMs / 1000.0;
      const n = 40;
      final prev = _spectrum.length == n ? _spectrum : List.filled(n, 0.0);
      final out = List<double>.filled(n, 0);
      for (var i = 0; i < n; i++) {
        final x = i / (n - 1);
        final env = math.exp(-math.pow((x - .35) / .38, 2).toDouble());
        final wob = .5 + .5 * math.sin(tt * (.78 + i * .065) + i * 1.7);
        final pulse = .65 + .35 * math.sin(tt * 1.15);
        final target = pl.playing ? (.08 + .8 * env * wob * pulse) : 0.04;
        final old = prev[i];
        out[i] = target > old
            ? old + (target - old) * .34
            : old + (target - old) * .13;
      }
      setState(() => _spectrum = out);
      return;
    }
    if (pl.current != _specPath) {
      // track changed: analyse the new one (keep showing the old frame fading out)
      final path = pl.current;
      _analyze(path).then((ok) {
        if (ok == false && mounted && visualizerOn && _specPath != path)
          _sim = true;
      });
      setState(() => _spectrum = [for (final v in _spectrum) v * .8]);
      return;
    }
    final data = _specData;
    if (data == null) return;
    final bands = _specBands;
    final frames = data.length ~/ bands;
    final idx = (pl.player.state.position.inMilliseconds * _specFps / 1000)
        .round()
        .clamp(0, frames - 1);
    final prev =
        _spectrum.length == bands ? _spectrum : List.filled(bands, 0.0);
    final out = List<double>.filled(bands, 0);
    for (var i = 0; i < bands; i++) {
      final target = pl.playing ? data[idx * bands + i] / 255.0 : 0.0;
      final old = prev[i];
      // fast attack, slower release: looks like a real analyser
      out[i] =
          target > old ? old + (target - old) * .7 : old + (target - old) * .132;
    }
    setState(() => _spectrum = out);
  }


  File? _lrcFile(String song) {
    if (song.startsWith('http')) return null;
    final base = p.withoutExtension(song);
    for (final e in ['lrc', 'LRC', 'txt']) {
      final f = File('$base.$e');
      if (f.existsSync()) return f;
    }
    return null;
  }

  Future<void> _loadLrc(String song) async {
    lrcFor = song;
    _lastIdx = -1;
    final f = _lrcFile(song);
    if (f == null) {
      lrc = null;
      return;
    }
    final out = <(Duration, String)>[];
    final re = RegExp(r'\[(\d+):(\d+(?:\.\d+)?)\]');
    try {
      for (final line in await f.readAsLines()) {
        final ms = re.allMatches(line).toList();
        final text = line.replaceAll(re, '').trim();
        for (final m in ms) {
          out.add((
            Duration(
                milliseconds:
                    (int.parse(m[1]!) * 60000 + double.parse(m[2]!) * 1000)
                        .round()),
            text
          ));
        }
      }
    } catch (_) {}
    out.sort((a, b) => a.$1.compareTo(b.$1));
    lrc = out.isEmpty ? null : out;
    if (mounted) setState(() {});
  }

  String _t(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  Widget _disc(PlayerService pl) {
    final art = pl.meta?.art;
    final albumArt = art != null
        ? Image.memory(art,
            fit: BoxFit.cover,
            gaplessPlayback: true,
            errorBuilder: (_, __, ___) => const Icon(Icons.music_note_rounded,
                color: Colors.white, size: 54))
        : const Icon(Icons.music_note_rounded, color: Colors.white, size: 54);

    if (_musicTheme == 'classic') {
      // Laid out on the 1672 x 941 reference canvas (Luxurious Golden Gramophone player); f = scale factor.
      return Center(
        child: LayoutBuilder(builder: (context, c) {
          if (c.maxHeight > c.maxWidth * .9) {
            // portrait: gramophone art at full width, the visualizer fills the rest down to the controls
            final aw = c.maxWidth, ah = aw * 650 / 910;
            final rest = math.max(c.maxHeight - ah, 0.0);
            final shh = rest / 1.4;
            final base = ah + rest * .04 + shh;
            return SizedBox(
              width: aw,
              height: c.maxHeight,
              child: Stack(clipBehavior: Clip.hardEdge, children: [
                Positioned(
                  left: 0,
                  top: 0,
                  width: aw,
                  height: ah,
                  child: ClipRect(
                    child: OverflowBox(
                      alignment: Alignment.centerLeft,
                      minWidth: 0,
                      maxWidth: double.infinity,
                      minHeight: 0,
                      maxHeight: double.infinity,
                      child: SizedBox(
                          width: aw * 1530 / 910,
                          height: ah,
                          child: Image.asset(
                              'assets/images/classic_gramophone.png',
                              fit: BoxFit.fill,
                              filterQuality: FilterQuality.high)),
                    ),
                  ),
                ),
                Positioned(
                    left: 0,
                    top: 0,
                    width: aw * 1530 / 910,
                    height: ah,
                    child: IgnorePointer(
                        child: RepaintBoundary(
                            child: CustomPaint(
                                painter: _ClassicRecordPainter(spin))))),
                Positioned(
                    left: 0,
                    right: 0,
                    top: base,
                    height: 2.5,
                    child: DecoratedBox(
                        decoration: BoxDecoration(
                            gradient: LinearGradient(colors: [
                              Colors.transparent,
                              _musicAccent.withOpacity(.9),
                              _musicAccent,
                              _musicAccent.withOpacity(.9),
                              Colors.transparent
                            ]),
                            boxShadow: [
                          BoxShadow(
                              color: _musicAccent.withOpacity(.6),
                              blurRadius: 8)
                        ]))),
                Positioned(
                    left: 0,
                    right: 0,
                    top: ah + rest * .04,
                    height: shh,
                    child: CustomPaint(
                        painter: _MusicSpectrumPainter(_spectrum,
                            const Color(0xFFFFE08A), const Color(0xFFF5A300),
                            reflection: true))),
              ]),
            );
          }
          final w = math.min(c.maxWidth, c.maxHeight * 1672 / 941).toDouble();
          final f = w / 1672;
          return SizedBox(
              width: w,
              height: 941 * f,
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Positioned(
                      left: 70 * f,
                      top: 0,
                      width: 1530 * f,
                      height: 650 * f,
                      child: Image.asset('assets/images/classic_gramophone.png',
                          fit: BoxFit.fill, filterQuality: FilterQuality.high)),
                  Positioned(
                      left: 70 * f,
                      top: 0,
                      width: 1530 * f,
                      height: 650 * f,
                      child: IgnorePointer(
                          child: RepaintBoundary(
                              child: CustomPaint(
                                  painter: _ClassicRecordPainter(spin))))),
                  // glowing floor line under the gramophone and the bars
                  Positioned(
                      left: 60 * f,
                      right: 60 * f,
                      top: 609 * f,
                      height: 2.5 * f,
                      child: DecoratedBox(
                          decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [
                                Colors.transparent,
                                _musicAccent.withOpacity(.9),
                                _musicAccent,
                                _musicAccent.withOpacity(.9),
                                Colors.transparent
                              ]),
                              boxShadow: [
                            BoxShadow(
                                color: _musicAccent.withOpacity(.6),
                                blurRadius: 10 * f)
                          ]))),
                  Positioned(
                      left: 1008 * f,
                      top: 318 * f,
                      width: 470 * f,
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(pl.title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: 44 * f,
                                    height: 1.2,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.white)),
                            SizedBox(height: 4 * f),
                            Text(pl.artist,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                    fontSize: 34 * f,
                                    height: 1.2,
                                    color: const Color(0xFFE8B84A))),
                          ])),
                  // the one visualizer of this theme
                  Positioned(
                      left: 705 * f,
                      top: 425 * f,
                      width: 770 * f,
                      height: 185 * f,
                      child: CustomPaint(
                          painter: _MusicSpectrumPainter(_spectrum,
                              const Color(0xFFFFE08A), const Color(0xFFF5A300),
                              reflection: true))),
                ],
              ));
        }),
      );
    }

    if (_musicTheme == 'cyber') {
      return Center(child: LayoutBuilder(builder: (context, c) {
        final d = math
            .min(c.maxWidth * .70, c.maxHeight * .70)
            .clamp(190.0, 330.0)
            .toDouble();
        return SizedBox(
            width: d + 44,
            height: d + 44,
            child: Stack(alignment: Alignment.center, children: [
              CustomPaint(
                  size: Size(d + 44, d + 44),
                  painter: _CircularSpectrumPainter(
                      _spectrum, _musicAccent, _musicAccent2)),
              RotationTransition(
                  turns: spin,
                  child: Container(
                      width: d,
                      height: d,
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: _musicAccent, width: 2),
                          boxShadow: [
                            BoxShadow(
                                color: _musicAccent.withOpacity(.45),
                                blurRadius: 28)
                          ]),
                      child: ClipOval(child: albumArt))),
              Container(
                  width: d * .19,
                  height: d * .19,
                  decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: const Color(0xFF080A14),
                      border: Border.all(color: _musicAccent2, width: 2))),
            ]));
      }));
    }

    if (_musicTheme == 'neo') {
      return Center(child: LayoutBuilder(builder: (context, c) {
        // Flat animated cassette: reels, tape packs and tape follow the song
        // position and the playback speed; all printing is Persian.
        final specH = math.min(88.0, c.maxHeight * .2).toDouble();
        final w = math
            .min(c.maxWidth * .96,
                math.max(150.0, c.maxHeight - specH - 14) * kCassetteAspect)
            .toDouble();
        double progress() {
          final d = pl.player.state.duration;
          if (d <= Duration.zero) return 0.0;
          return (pl.player.state.position.inMilliseconds / d.inMilliseconds)
              .clamp(0.0, 1.0)
              .toDouble();
        }

        return Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          SizedBox(
            width: w,
            child: AnimatedCassette(
              playing: pl.playing,
              rate: pl.player.state.rate,
              progress: progress,
              title: pl.title,
              artist: pl.artist,
              art: art,
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: specH,
            width: c.maxWidth * .96,
            child: CustomPaint(
              painter: _MusicSpectrumPainter(
                _spectrum,
                _musicAccent,
                _musicAccent2,
                reflection: true,
              ),
            ),
          ),
        ]);
      }));
    }

    if (_musicTheme == 'original') {
      final record = RotationTransition(
        turns: spin,
        child: Container(
          width: 300,
          height: 300,
          decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                  colors: [Color(0xFF222222), Color(0xFF050505)]),
              boxShadow: [BoxShadow(color: Color(0x553D9BFF), blurRadius: 40)]),
          child: Center(
              child: Container(
            width: art != null ? 190 : 120,
            height: art != null ? 190 : 120,
            clipBehavior: Clip.antiAlias,
            decoration: const BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                    colors: [Color(0xFF4DA8FF), Color(0xFF6D3BEA)])),
            child: art != null
                ? albumArt
                : const Icon(Icons.music_note_rounded,
                    size: 56, color: Color(0xFF0A1233)),
          )),
        ),
      );
      return Center(
          child: FittedBox(
              fit: BoxFit.scaleDown,
              child: SizedBox(
                width: Tonearm.size.width,
                height: Tonearm.size.height,
                child: Stack(children: [
                  Positioned(left: 0, top: 45, child: record),
                  Positioned.fill(child: IgnorePointer(child: Tonearm(pl: pl))),
                ]),
              )));
    }
    final record = RotationTransition(
        turns: spin, child: _VinylDisc(accent: _musicAccent, art: art));
    return Center(
        child: FittedBox(
            fit: BoxFit.scaleDown,
            child: SizedBox(width: 300, height: 300, child: record)));
  }

  Widget _lyrics(PlayerService pl, {Color? hi}) => StreamBuilder<Duration>(
        stream: pl.player.stream.position,
        builder: (c, snap) {
          final pos = snap.data ?? Duration.zero;
          var idx = lrc!.lastIndexWhere((e) => e.$1 <= pos);
          if (idx < 0) idx = 0;
          if (idx != _lastIdx) {
            _lastIdx = idx;
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (lyrCtl.hasClients) {
                final target =
                    (idx * 52.0 - lyrCtl.position.viewportDimension / 2 + 26)
                        .clamp(0.0, lyrCtl.position.maxScrollExtent)
                        .toDouble();
                lyrCtl.animateTo(target,
                    duration: const Duration(milliseconds: 350),
                    curve: Curves.easeOut);
              }
            });
          }
          return ListView.builder(
            controller: lyrCtl,
            itemExtent: 52,
            itemCount: lrc!.length,
            itemBuilder: (_, i) => InkWell(
              onTap: () => pl.player.seek(lrc![i].$1),
              child: Center(
                child: Text(lrc![i].$2,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: i == idx ? 22 : 16,
                        color: i == idx ? (hi ?? _musicAccent) : Colors.white54,
                        fontWeight:
                            i == idx ? FontWeight.bold : FontWeight.normal)),
              ),
            ),
          );
        },
      );

  Future<void> _sleepMenu(PlayerService pl) async {
    final r = await showModalBottomSheet<int>(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          ListTile(
              title: Text(L.t('sleepTimer'),
                  style: const TextStyle(fontWeight: FontWeight.bold))),
          if (pl.sleepActive)
            ListTile(
                leading: const Icon(Icons.timer_off_rounded),
                title: Text(L.t('off')),
                onTap: () => Navigator.pop(context, -1)),
          for (final m in [5, 10, 15, 30, 45, 60, 90])
            ListTile(
                leading: const Icon(Icons.timer_rounded),
                title: Text('$m ${L.t('minutes')}'),
                onTap: () => Navigator.pop(context, m)),
          ListTile(
              leading: const Icon(Icons.music_off_rounded),
              title: Text(L.t('endOfTrack')),
              onTap: () => Navigator.pop(context, 0)),
        ]),
      ),
    );
    if (r == null) return;
    if (r < 0) {
      pl.setSleep(null);
    } else if (r == 0) {
      pl.setSleep(null, endOfTrack: true);
    } else {
      pl.setSleep(Duration(minutes: r));
    }
  }

  void _queue() {
    final initial = context.read<PlayerService>();
    const bg = Color(0xFF090D14), panel = Color(0xFF111824), fg = Color(0xFFE8EEF8), accent = Color(0xFF08B9F5), muted = Color(0xFF77869B), danger = Color(0xFFFF5964);
    const rowExtent = 76.0;
    final controller = ScrollController(initialScrollOffset: math.max(0, (initial.index - 2) * rowExtent).toDouble());
    final selected = <int>{};
    final screen = MediaQuery.sizeOf(context);

    // Adds audio files picked by the user: [next] = right after the current track, otherwise at the end.
    Future<void> addTracks(BuildContext ctx, {required bool next}) async {
      final result = await FilePicker.platform.pickFiles(type: FileType.audio, allowMultiple: true);
      if (result == null || !ctx.mounted) return;
      final paths = result.files.map((f) => f.path).whereType<String>().where((e) => e.isNotEmpty).toList();
      final service = ctx.read<PlayerService>();
      // inserting "next" one by one reverses the order, so walk the list backwards
      for (final path in (next && service.hasQueue ? paths.reversed : paths)) {
        await service.enqueue(path, next: next);
      }
    }

    Future<void> deleteSelected(BuildContext ctx, void Function(VoidCallback) setSheetState) async {
      final service = ctx.read<PlayerService>();
      final indexes = selected.toList()..sort((a, b) => b.compareTo(a));
      for (final i in indexes) {
        if (i >= 0 && i < service.queue.length) await service.removeAt(i);
      }
      setSheetState(selected.clear);
      // everything was removed: nothing left to show, close the sheet and the player
      if (!service.hasQueue && ctx.mounted) {
        Navigator.pop(ctx);
        if (mounted) Navigator.pop(context);
      }
    }

    showModalBottomSheet<void>(
      context: context, isScrollControlled: true, useSafeArea: true, backgroundColor: bg,
      barrierColor: Colors.black54, constraints: BoxConstraints(maxHeight: screen.height, minWidth: screen.width),
      clipBehavior: Clip.antiAlias,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
      builder: (sheetContext) => StatefulBuilder(builder: (sheetContext, setSheetState) => SizedBox.expand(
        child: Material(color: bg, child: SafeArea(top: false, child: Column(children: [
          const SizedBox(height: 10),
          Container(width: 46, height: 5, decoration: BoxDecoration(color: muted.withOpacity(.55), borderRadius: BorderRadius.circular(8))),
          Padding(padding: const EdgeInsets.fromLTRB(18, 15, 18, 14), child: Consumer<PlayerService>(builder: (c, pl, _) {
            final allChosen = pl.queue.isNotEmpty && selected.length == pl.queue.length;
            return Row(children: [
              Container(width: 46, height: 46, decoration: BoxDecoration(color: const Color(0xFF142333), borderRadius: BorderRadius.circular(15), border: Border.all(color: accent.withOpacity(.35))), child: const Icon(Icons.queue_music_rounded, color: accent, size: 27)),
              const SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('${L.t('nextQueue')} (${pl.queue.length})', style: const TextStyle(color: fg, fontSize: 19, fontWeight: FontWeight.w800)),
                Text(selected.isEmpty ? 'برای انتخاب، روی دایره‌ی آهنگ بزنید یا نگه دارید' : '${selected.length} آهنگ انتخاب شده', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: muted, fontSize: 12)),
              ])),
              TextButton(onPressed: pl.queue.isEmpty ? null : () => setSheetState(() {
                  if (allChosen) { selected.clear(); } else { selected..clear()..addAll(List<int>.generate(pl.queue.length, (i) => i)); }
                }),
                style: TextButton.styleFrom(foregroundColor: accent, backgroundColor: panel, padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                child: Text(allChosen ? 'لغو انتخاب' : 'انتخاب همه')),
              const SizedBox(width: 8),
              TextButton(onPressed: pl.queue.isEmpty ? null : () { pl.stopAll(); Navigator.pop(c); Navigator.pop(context); },
                style: TextButton.styleFrom(foregroundColor: const Color(0xFF9BAFC2), backgroundColor: panel, padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), child: Text(L.t('clear'))),
            ]);
          })),
          Divider(height: 1, color: muted.withOpacity(.22)),
          Expanded(child: Consumer<PlayerService>(builder: (c, pl, _) {
            if (pl.queue.isEmpty) return const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.queue_music_rounded, size: 54, color: muted), SizedBox(height: 10), Text('صف پخش خالی است', style: TextStyle(color: muted))]));
            // selection indexes can be stale if the queue changed from outside (e.g. a track was removed)
            selected.removeWhere((i) => i >= pl.queue.length);
            return ScrollConfiguration(behavior: const _NoGlowScrollBehavior(), child: ReorderableListView.builder(
              scrollController: controller, physics: const ClampingScrollPhysics(), padding: const EdgeInsets.fromLTRB(12, 12, 12, 18), itemExtent: rowExtent,
              buildDefaultDragHandles: false,
              itemCount: pl.queue.length,
              onReorder: (a, b) { pl.moveItem(a, b > a ? b - 1 : b); setSheetState(selected.clear); },
              itemBuilder: (c, i) {
                final current = i == pl.index, chosen = selected.contains(i);
                final title = p.basenameWithoutExtension(Uri.decodeFull(pl.queue[i]));
                final rtl = RegExp(r'[֐-ࣿ]').hasMatch(title);
                void toggle() => setSheetState(() { chosen ? selected.remove(i) : selected.add(i); });
                return Container(key: ValueKey('${pl.queue[i]}-$i'), margin: const EdgeInsets.only(bottom: 8),
                  decoration: BoxDecoration(color: chosen ? const Color(0xFF102B3C) : panel, borderRadius: BorderRadius.circular(19),
                    border: Border.all(color: chosen ? accent : current ? accent.withOpacity(.55) : const Color(0xFF263242), width: chosen || current ? 1.4 : 1),
                    boxShadow: chosen ? [BoxShadow(color: accent.withOpacity(.10), blurRadius: 14)] : null),
                  child: Row(children: [
                    const SizedBox(width: 10), ReorderableDragStartListener(index: i, child: const Icon(Icons.drag_indicator_rounded, color: muted, size: 22)), const SizedBox(width: 9),
                    InkWell(borderRadius: BorderRadius.circular(30), onTap: toggle,
                      child: Container(width: 38, height: 38, alignment: Alignment.center, decoration: BoxDecoration(shape: BoxShape.circle, color: chosen ? accent : const Color(0xFF202B3A)),
                        child: Icon(chosen ? Icons.check_rounded : current ? Icons.equalizer_rounded : Icons.music_note_rounded, color: chosen ? Colors.black : fg, size: 20))),
                    const SizedBox(width: 12), Expanded(child: InkWell(
                      // while something is selected a tap toggles the row; otherwise it plays the track
                      onTap: () { if (selected.isNotEmpty) { toggle(); } else { pl.jumpTo(i); Navigator.pop(c); } },
                      onLongPress: toggle,
                      child: Align(alignment: rtl ? Alignment.centerRight : Alignment.centerLeft, child: Text(title, textDirection: rtl ? TextDirection.rtl : TextDirection.ltr, maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: TextStyle(color: chosen ? Colors.white : fg, fontSize: 15.5, fontWeight: current ? FontWeight.w700 : FontWeight.w500))))),
                    Padding(padding: const EdgeInsetsDirectional.only(start: 6, end: 14), child: current ? const Icon(Icons.volume_up_rounded, color: accent, size: 20) : Text('${i + 1}', style: const TextStyle(color: muted, fontWeight: FontWeight.w700))),
                  ]));
              },
            ));
          })),
          Container(padding: const EdgeInsets.fromLTRB(16, 13, 16, 12), decoration: BoxDecoration(color: const Color(0xFF0E1520), border: Border(top: BorderSide(color: muted.withOpacity(.2)))),
            child: Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: selected.isEmpty ? null : () => deleteSelected(sheetContext, setSheetState),
                icon: const Icon(Icons.delete_outline_rounded), label: Text(selected.isEmpty ? 'حذف انتخاب‌شده‌ها' : 'حذف ${selected.length} آهنگ'),
                style: OutlinedButton.styleFrom(foregroundColor: danger, disabledForegroundColor: muted, side: BorderSide(color: selected.isEmpty ? muted.withOpacity(.4) : danger.withOpacity(.7)), minimumSize: const Size(0, 54), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17))))),
              const SizedBox(width: 12),
              Expanded(child: PopupMenuButton<bool>(
                tooltip: 'افزودن آهنگ',
                color: panel,
                position: PopupMenuPosition.over,
                onSelected: (next) => addTracks(sheetContext, next: next),
                itemBuilder: (_) => const [
                  PopupMenuItem<bool>(value: false, child: Text('افزودن به انتهای صف', style: TextStyle(color: fg))),
                  PopupMenuItem<bool>(value: true, child: Text('پخش بعد از آهنگ فعلی', style: TextStyle(color: fg))),
                ],
                child: Container(height: 54, alignment: Alignment.center,
                  decoration: BoxDecoration(color: accent, borderRadius: BorderRadius.circular(17)),
                  child: const Row(mainAxisSize: MainAxisSize.min, children: [
                    Icon(Icons.add_rounded, size: 23, color: Color(0xFF06121B)), SizedBox(width: 8),
                    Text('افزودن آهنگ', style: TextStyle(color: Color(0xFF06121B), fontWeight: FontWeight.w800, fontSize: 14)),
                  ])),
              )),
            ])),
        ]))),
      )),
    ).whenComplete(controller.dispose);
  }

  Widget _moreMenu(PlayerService pl,
      {Color? color, bool full = false, bool theme = false}) {
    final rate = pl.player.state.rate;
    return PopupMenuButton<String>(
      iconColor: color,
      onSelected: (v) async {
        if (v == 'share' && pl.hasQueue && !pl.current.startsWith('http'))
          Share.shareXFiles([XFile(pl.current)]);
        if (v == 'sleep') _sleepMenu(pl);
        if (v == 'viz' && pl.hasQueue) _toggleVisualizer();
        if (v == 'ab') pl.toggleAB();
        if (v == 'opts')
          Navigator.push(context,
              MaterialPageRoute(builder: (_) => const AudioOptionsScreen()));
        if (v == 'tags' && pl.hasQueue && !pl.current.startsWith('http'))
          Navigator.push(
              context,
              abtinPageRoute((_) => TagEditorScreen(path: pl.current),
                  hideRail: true));
        if (v == 'delete' && pl.hasQueue && !pl.current.startsWith('http')) {
          final path = pl.current;
          final i = pl.index;
          final wasPlaying = pl.playing;
          await pl.player.pause();
          if (!mounted) return;
          final ok = await deleteFromViewer(context, path);
          if (!mounted) return;
          if (!ok) {
            if (wasPlaying) pl.player.play();
          } else if (pl.queue.length <= 1) {
            await pl.stopAll();
            if (mounted) Navigator.pop(context);
          } else {
            await pl.removeAt(i);
            pl.player.play();
          }
        }
        if (v.startsWith('r')) pl.setRate(double.parse(v.substring(1)));
      },
      itemBuilder: (_) => [
        if (theme) ...[
          const PopupMenuDivider(),
        ],
        if (full) ...[
          PopupMenuItem(value: 'sleep', child: Text(L.t('sleepTimer'))),
          PopupMenuItem(value: 'viz', child: Text(L.t('visualizer'))),
          const PopupMenuDivider(),
        ],
        PopupMenuItem(
            value: 'ab',
            child: Text(
                'A-B ${L.t('loop')}${pl.abStage == 0 ? '' : pl.abStage == 1 ? '  (A)' : '  (A-B ✓)'}')),
        PopupMenuItem(value: 'tags', child: Text(L.t('tagEdit'))),
        PopupMenuItem(value: 'opts', child: Text(L.t('playOpts'))),
        PopupMenuItem(value: 'share', child: Text(L.t('share'))),
        if (pl.hasQueue && !pl.current.startsWith('http'))
          PopupMenuItem(value: 'delete', child: Text(L.t('delete'))),
        const PopupMenuDivider(),
        for (final v in [0.5, 0.75, 1.0, 1.25, 1.5, 2.0])
          PopupMenuItem(
              value: 'r$v',
              child: Text('${L.t('speed')} ${v}x${rate == v ? '  ✓' : ''}')),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final pl = context.watch<PlayerService>();
    final s = context.watch<AppSettings>();
    if (pl.playing) {
      if (!spin.isAnimating) spin.repeat();
    } else {
      spin.stop();
    }
    if (pl.hasQueue && lrcFor != pl.current) _loadLrc(pl.current);
    final hasLrc = lrc != null;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final pageBackground = isDark ? const Color(0xFF0A0D14) : const Color(0xFFF4F6FB);
    final primaryText = isDark ? const Color(0xFFE9EDF7) : const Color(0xFF182235);
    final secondaryText = isDark ? const Color(0xFF9AA3B2) : const Color(0xFF596579);
    return Scaffold(
      backgroundColor: pageBackground,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: IconButton(
            icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32),
            onPressed: () => Navigator.pop(context)),
        centerTitle: true,
        title: Text.rich(
            TextSpan(children: [
              TextSpan(text: 'Abtin '),
              TextSpan(text: 'Media', style: TextStyle(color: _musicAccent))
            ]),
            style: TextStyle(fontWeight: FontWeight.bold, color: primaryText)),
        actions: [
          IconButton(
              icon: Icon(Icons.bedtime_rounded,
                  color: pl.sleepActive ? _musicAccent : null),
              tooltip: L.t('sleepTimer'),
              onPressed: () => _sleepMenu(pl)),
          IconButton(
              icon: Icon(Icons.graphic_eq_rounded,
                  color: visualizerOn ? _musicAccent : null),
              tooltip: L.t('visualizer'),
              onPressed: pl.hasQueue ? _toggleVisualizer : null),
          IconButton(
              icon: const Icon(Icons.equalizer_rounded),
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const EqualizerScreen()))),
          PopupMenuButton<String>(
            tooltip: 'تم پخش موسیقی',
            icon: const Icon(Icons.palette_outlined),
            initialValue: _musicTheme,
            onSelected: _setMusicTheme,
            itemBuilder: (_) => _musicThemes.entries
                .map((e) => PopupMenuItem<String>(
                      value: e.key,
                      child: Row(children: [
                        if (_musicTheme == e.key)
                          const Icon(Icons.check, size: 18),
                        if (_musicTheme == e.key) const SizedBox(width: 8),
                        Text(e.value)
                      ]),
                    ))
                .toList(),
          ),
          _moreMenu(pl),
        ],
      ),
      body: !pl.hasQueue
          ? const SizedBox()
          : Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(children: [
                Expanded(child: showLyrics && hasLrc ? _lyrics(pl) : _disc(pl)),
                Row(children: [
                  Expanded(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(pl.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 24, fontWeight: FontWeight.bold)),
                          Text(
                              [pl.artist, pl.album]
                                  .where((e) => e.isNotEmpty)
                                  .join(' • '),
                              textDirection: TextDirection.rtl,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(color: secondaryText)),
                        ]),
                  ),
                  IconButton(
                    icon: Icon(
                        s.isFav(pl.current)
                            ? Icons.star_rounded
                            : Icons.star_border_rounded,
                        color: _musicAccent,
                        size: 30),
                    onPressed: () => s.toggleFav(pl.current),
                  ),
                ]),
                const SizedBox(height: 6),
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Wrap(spacing: 8, children: [
                    ActionChip(
                      avatar: const Icon(Icons.article_outlined, size: 18),
                      label: Text(hasLrc
                          ? (showLyrics ? L.t('disc') : L.t('lyrics'))
                          : L.t('addLyrics')),
                      onPressed: hasLrc
                          ? () => setState(() => showLyrics = !showLyrics)
                          : () => _addLyrics(pl),
                    ),
                    if (pl.abStage != 0)
                      ActionChip(
                          avatar: const Icon(Icons.repeat_rounded, size: 18),
                          label: Text(pl.abStage == 1 ? 'A…' : 'A-B'),
                          onPressed: pl.toggleAB),
                    if (pl.sleepActive)
                      ActionChip(
                        avatar: const Icon(Icons.bedtime_rounded, size: 18),
                        label: Text(pl.sleepEndOfTrack
                            ? L.t('endOfTrack')
                            : '${pl.sleepAt!.difference(DateTime.now()).inMinutes + 1} ${L.t('minutes')}'),
                        onPressed: () => pl.setSleep(null),
                      ),
                  ]),
                ),
                // one visualizer per theme: classic / cyber / neo draw their own inside the artwork,
                // so this strip is only for the original theme
                if (visualizerOn && _musicTheme == 'original')
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: SizedBox(
                        height: 44,
                        width: double.infinity,
                        child: CustomPaint(
                            painter: _SpectrumPainter(_spectrum,
                                lo: const Color(0xFF5B3FD6),
                                hi: _musicAccent))),
                  ),
                StreamBuilder<Duration>(
                  stream: pl.player.stream.position,
                  builder: (c, snap) {
                    final pos = snap.data ?? Duration.zero;
                    final dur = pl.player.state.duration;
                    final max = dur.inMilliseconds
                        .toDouble()
                        .clamp(1, double.infinity)
                        .toDouble();
                    final v = (_drag ?? pos.inMilliseconds.toDouble())
                        .clamp(0, max)
                        .toDouble();
                    return Directionality(
                        textDirection: TextDirection.ltr,
                        child: Column(children: [
                          LSlider(
                            activeColor: _musicAccent,
                            value: v,
                            max: max,
                            onChanged: (x) => setState(() => _drag = x),
                            onChangeEnd: (x) {
                              pl.player.seek(Duration(milliseconds: x.round()));
                              setState(() => _drag = null);
                            },
                          ),
                          Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(_t(Duration(milliseconds: v.round()))),
                                Text(_t(dur))
                              ]),
                        ]));
                  },
                ),
                // transport controls: always LTR (shuffle, prev, play, next, repeat) in every language
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        IconButton(
                            icon: Icon(Icons.shuffle_rounded,
                                color:
                                    pl.shuffle ? _musicAccent : primaryText),
                            onPressed: pl.toggleShuffle),
                        IconButton(
                            iconSize: 38,
                            icon: const Icon(Icons.skip_previous_rounded),
                            onPressed: pl.previous),
                        Container(
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border:
                                  Border.all(color: _musicAccent, width: 3)),
                          child: IconButton(
                              iconSize: 48,
                              icon: Icon(pl.playing
                                  ? Icons.pause_rounded
                                  : Icons.play_arrow_rounded),
                              onPressed: pl.player.playOrPause),
                        ),
                        IconButton(
                            iconSize: 38,
                            icon: const Icon(Icons.skip_next_rounded),
                            onPressed: pl.next),
                        IconButton(
                          icon: Icon(
                              pl.mode == PlaylistMode.single
                                  ? Icons.repeat_one_rounded
                                  : Icons.repeat_rounded,
                              color: pl.mode == PlaylistMode.none
                                  ? primaryText
                                  : _musicAccent),
                          onPressed: pl.cycleMode,
                        ),
                      ]),
                ),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(children: [
                    IconButton(
                        icon: const Icon(Icons.replay_10_rounded),
                        onPressed: () =>
                            pl.seekBy(const Duration(seconds: -10))),
                    Icon(
                        pl.volume == 0
                            ? Icons.volume_off_rounded
                            : Icons.volume_up_rounded,
                        size: 20),
                    Expanded(
                        child: LSlider(
                            value: pl.volume,
                            max: 100,
                            onChanged: pl.setVolume)),
                    IconButton(
                        icon: const Icon(Icons.forward_10_rounded),
                        onPressed: () =>
                            pl.seekBy(const Duration(seconds: 10))),
                  ]),
                ),
                ListTile(
                  tileColor: Colors.white10,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                  leading: const Icon(Icons.queue_music_rounded),
                  title: Text('${L.t('nextQueue')} (${pl.queue.length})'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: _queue,
                ),
                const SizedBox(height: 12),
              ]),
            ),
    );
  }
}


class _NoGlowScrollBehavior extends ScrollBehavior {
  const _NoGlowScrollBehavior();
  @override
  Widget buildOverscrollIndicator(BuildContext context, Widget child, ScrollableDetails details) => child;
}

class _CassetteLabelClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final p = Path();
    p.moveTo(size.width * .035, size.height * .10);
    p.lineTo(size.width * .075, size.height * .015);
    p.lineTo(size.width * .925, size.height * .015);
    p.lineTo(size.width * .965, size.height * .10);
    p.lineTo(size.width * .965, size.height * .90);
    p.lineTo(size.width * .925, size.height * .985);
    p.lineTo(size.width * .075, size.height * .985);
    p.lineTo(size.width * .035, size.height * .90);
    p.close();
    return p;
  }

  @override
  bool shouldReclip(covariant _CassetteLabelClipper oldClipper) => false;
}

class _VinylDisc extends StatelessWidget {
  final Color accent;
  final Uint8List? art;
  const _VinylDisc({required this.accent, this.art});
  @override
  Widget build(BuildContext context) => Container(
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: const RadialGradient(colors: [
              Color(0xFF55545A),
              Color(0xFF16151A),
              Color(0xFF030305)
            ], stops: [
              0,
              .34,
              1
            ]),
            border: Border.all(color: accent.withOpacity(.8), width: 2),
            boxShadow: [
              BoxShadow(color: accent.withOpacity(.38), blurRadius: 28)
            ]),
        child: Stack(alignment: Alignment.center, children: [
          for (double r in [.30, .40, .50, .60, .70, .80, .90])
            Container(
                width: 300 * r,
                height: 300 * r,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: Colors.white.withOpacity(.09), width: 1))),
          Container(
              width: 92,
              height: 92,
              clipBehavior: Clip.antiAlias,
              decoration: BoxDecoration(shape: BoxShape.circle, color: accent),
              child: art == null
                  ? Icon(Icons.music_note_rounded,
                      color: Colors.black.withOpacity(.7), size: 42)
                  : Image.memory(art!, fit: BoxFit.cover)),
          Positioned(
              top: 8,
              left: 48,
              right: 48,
              child: Container(
                  height: 2,
                  decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [
                    Colors.transparent,
                    Colors.white.withOpacity(.55),
                    Colors.transparent
                  ])))),
        ]),
      );
}

class _MusicSpectrumPainter extends CustomPainter {
  final List<double> values;
  final Color a, b;
  final bool reflection;

  _MusicSpectrumPainter(
    this.values,
    this.a,
    this.b, {
    this.reflection = false,
  });

  double _audioAt(double t) {
    if (values.isEmpty) return .28;
    final x = t.clamp(0.0, 1.0) * (values.length - 1);
    final i = x.floor().clamp(0, values.length - 1);
    final j = (i + 1).clamp(0, values.length - 1);
    final f = x - i;
    return (values[i] * (1 - f) + values[j] * f)
        .clamp(0.0, 1.0)
        .toDouble();
  }

  @override
  void paint(Canvas canvas, Size size) {
    if (size.width <= 0 || size.height <= 0) return;

    const steps = 280;
    final centerY = size.height * .50;
    // Keep the ribbon controlled: the previous gain made the whole wave
    // jump too aggressively on loud transients.
    final maxAmp = size.height * .34;
    final paths = <Path>[];
    final count = 9;

    // Nine individually staggered audio-reactive strands form one flowing
    // neon ribbon. Their tiny phase and signal offsets create visible depth.
    for (var lane = 0; lane < count; lane++) {
      final path = Path();
      final spread = (lane - (count - 1) / 2) / ((count - 1) / 2);
      for (var i = 0; i <= steps; i++) {
        final t = i / steps;
        final x = size.width * t;
        final edge = math.pow(math.sin(math.pi * t), .72).toDouble();
        // Each strand follows the same live music signal with a tiny stagger.
        // Sampling a slightly earlier band position creates the layered,
        // flowing ribbon instead of nine coincident parallel traces.
        // Adjacent strands sample the live spectrum with a small stagger.
        // Alternating signed phase offsets make neighboring strands travel
        // in opposite apparent directions instead of marching as one bundle.
        final signedLane = lane.isEven ? lane.toDouble() : -lane.toDouble();
        final laneDelay = signedLane * .014;
        final audio = _audioAt((t - laneDelay).clamp(0.0, 1.0).toDouble());
        final audioGain = .24 + audio * .52;
        final envelope = maxAmp * edge * audioGain;
        final phase = t * math.pi * 2 + signedLane * .19;
        final fundamental =
            math.sin(phase * 2.15 + .12 * math.sin(phase * 1.3));
        final detail = math.sin(phase * 4.25 + .55) * .16 +
            math.sin(phase * 6.1 - .8) * .055;
        final y = centerY +
            (fundamental + detail) * envelope +
            spread * size.height * (.018 + audio * .012) * edge;
        if (i == 0) {
          path.moveTo(x, y);
        } else {
          path.lineTo(x, y);
        }
      }
      paths.add(path);
    }

    // Broad soft bloom behind the strands.
    final glowPath = Path();
    for (var i = 0; i <= steps; i++) {
      final t = i / steps;
      final x = size.width * t;
      final edge = math.pow(math.sin(math.pi * t), .72).toDouble();
      final env = maxAmp * edge * (.48 + _audioAt(t) * .72);
      final ph = t * math.pi * 2;
      final wave = math.sin(ph * 2.15 + .12 * math.sin(ph * 1.3)) +
          math.sin(ph * 4.25 + .55) * .20 +
          math.sin(ph * 6.1 - .8) * .075;
      final y = centerY + wave * env;
      if (i == 0) {
        glowPath.moveTo(x, y);
      } else {
        glowPath.lineTo(x, y);
      }
    }
    canvas.drawPath(
      glowPath,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = size.height * .16
        ..strokeCap = StrokeCap.round
        ..color = a.withOpacity(.12)
        ..maskFilter = MaskFilter.blur(
          BlurStyle.normal,
          math.max(3, size.height * .12).toDouble(),
        ),
    );

    for (var lane = 0; lane < paths.length; lane++) {
      final mix = lane / (paths.length - 1);
      final color = Color.lerp(a, b, mix)!;
      canvas.drawPath(
        paths[lane],
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = lane == 4 ? 1.8 : 1.15
          ..strokeCap = StrokeCap.round
          ..color = color.withOpacity(lane == 4 ? .96 : .72)
          ..maskFilter = MaskFilter.blur(
            BlurStyle.normal,
            lane == 4 ? 2.4 : 1.2,
          ),
      );
      canvas.drawPath(
        paths[lane],
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = lane == 4 ? 1.35 : .72
          ..strokeCap = StrokeCap.round
          ..shader = LinearGradient(
            colors: [
              a.withOpacity(.12),
              color,
              b.withOpacity(.95),
              a.withOpacity(.8),
            ],
          ).createShader(Offset.zero & size),
      );
    }

    // Sparse luminous particles around the wave, not equal-height bars.
    final particlePaint = Paint()..style = PaintingStyle.fill;
    for (var i = 0; i < 34; i++) {
      final t = ((i * 37) % 101) / 100;
      final edge = math.pow(math.sin(math.pi * t), .72).toDouble();
      final audio = _audioAt(t);
      final yOffset = (i.isEven ? 1 : -1) *
          (size.height * (.12 + edge * (.10 + audio * .20)));
      final radius = i % 5 == 0 ? 1.65 : .9;
      particlePaint.color =
          Color.lerp(a, b, (i % 9) / 8)!.withOpacity(.25 + audio * .55);
      canvas.drawCircle(
        Offset(size.width * t, centerY + yOffset),
        radius,
        particlePaint,
      );
    }

    if (reflection) {
      canvas.save();
      canvas.translate(0, centerY * 2);
      canvas.scale(1, -1);
      canvas.drawPath(
        glowPath,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = a.withOpacity(.09),
      );
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _MusicSpectrumPainter old) =>
      old.values != values ||
      old.a != a ||
      old.b != b ||
      old.reflection != reflection;
}

class _CircularSpectrumPainter extends CustomPainter {
  final List<double> values;
  final Color a, b;
  _CircularSpectrumPainter(this.values, this.a, this.b);
  @override
  void paint(Canvas c, Size s) {
    final center = s.center(Offset.zero);
    final base = math.min(s.width, s.height) * .39;
    final n = math.max(values.length, 48);
    for (int i = 0; i < n; i++) {
      final v = (values.isEmpty ? .12 : values[i % values.length])
          .clamp(0.0, 1.0)
          .toDouble();
      final ang = 2 * math.pi * i / n;
      final p1 = center + Offset(math.cos(ang) * base, math.sin(ang) * base);
      final p2 = center +
          Offset(math.cos(ang) * (base + 7 + v * 18),
              math.sin(ang) * (base + 7 + v * 18));
      c.drawLine(
          p1,
          p2,
          Paint()
            ..color = Color.lerp(a, b, i / n)!.withOpacity(.9)
            ..strokeWidth = 2.4
            ..strokeCap = StrokeCap.round);
    }
  }

  @override
  bool shouldRepaint(covariant _CircularSpectrumPainter old) =>
      old.values != values || old.a != a || old.b != b;
}

class _SpectrumPainter extends CustomPainter {
  final List<double> values;
  final Color lo, hi;
  _SpectrumPainter(this.values,
      {this.lo = const Color(0xFF805A20), this.hi = AppColors.gold});

  @override
  void paint(Canvas canvas, Size size) {
    if (values.isEmpty || size.width <= 0 || size.height <= 0) return;
    final gap = 2.0;
    final width = (size.width - gap * (values.length - 1)) / values.length;
    for (var i = 0; i < values.length; i++) {
      final v = values[i].clamp(0.0, 1.0).toDouble();
      final h =
          (size.height * (0.08 + v * .92)).clamp(2.0, size.height).toDouble();
      final rect = RRect.fromRectAndRadius(
          Rect.fromLTWH(i * (width + gap), size.height - h, width, h),
          Radius.circular(width / 2));
      canvas.drawRRect(rect, Paint()..color = Color.lerp(lo, hi, v)!);
    }
  }

  @override
  bool shouldRepaint(covariant _SpectrumPainter oldDelegate) =>
      oldDelegate.values != values ||
      oldDelegate.lo != lo ||
      oldDelegate.hi != hi;
}

/// Spinning record drawn over the turntable of classic_gramophone.png (image space 1148 x 488).
class _ClassicRecordPainter extends CustomPainter {
  final Animation<double> spin;
  _ClassicRecordPainter(this.spin) : super(repaint: spin);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.scale(size.width / 1148, size.height / 488);
    const cx = 362.0, cy = 320.0, r = 140.0, ry = 27.0;
    final rect = Rect.fromCircle(center: Offset.zero, radius: r);
    canvas.save();
    canvas.translate(cx, cy);
    canvas.rotate(0.06);
    canvas.scale(1, ry / r);
    canvas.clipPath(Path()..addOval(rect));
    canvas.drawCircle(
        Offset.zero,
        r,
        Paint()
          ..shader = const RadialGradient(
              colors: [Color(0xFF2A2A2E), Color(0xFF0B0B0D), Color(0xFF020203)],
              stops: [0, .45, 1]).createShader(rect));
    canvas.save();
    canvas.rotate(spin.value * 2 * math.pi * 3);
    final g = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = .8
      ..color = Colors.white.withOpacity(.07);
    for (double rr = 52; rr < r - 2; rr += 4.5) {
      canvas.drawCircle(Offset.zero, rr, g);
    }
    canvas.drawCircle(
        Offset.zero,
        r,
        Paint()
          ..shader = SweepGradient(colors: [
            Colors.transparent,
            Colors.white.withOpacity(.18),
            Colors.transparent,
            Colors.transparent,
            Colors.white.withOpacity(.12),
            Colors.transparent,
            Colors.transparent
          ], stops: const [
            0,
            .06,
            .14,
            .5,
            .56,
            .64,
            1
          ]).createShader(rect));
    final lr = Rect.fromCircle(center: Offset.zero, radius: 48);
    canvas.drawCircle(
        Offset.zero,
        48,
        Paint()
          ..shader = const RadialGradient(
              colors: [Color(0xFFE53935), Color(0xFFB71C1C)]).createShader(lr));
    canvas.drawCircle(
        Offset.zero,
        48,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = const Color(0xFFE9C46A));
    final m = Paint()
      ..color = Colors.white.withOpacity(.6)
      ..strokeWidth = 2.4
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(const Offset(-30, -14), const Offset(-6, -14), m);
    canvas.drawLine(const Offset(-30, -6), const Offset(-14, -6), m);
    canvas.drawLine(const Offset(10, 18), const Offset(32, 18), m);
    canvas.drawCircle(
        const Offset(30, -4), 4, Paint()..color = const Color(0xFFFFE08A));
    canvas.restore();
    canvas.drawCircle(
        Offset.zero,
        r,
        Paint()
          ..shader = LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white.withOpacity(.10),
                Colors.transparent,
                Colors.transparent,
                Colors.white.withOpacity(.05)
              ],
              stops: const [
                0,
                .4,
                .7,
                1
              ]).createShader(rect));
    canvas.restore();
    canvas.drawRRect(
        RRect.fromRectAndRadius(
            Rect.fromLTWH(cx - 3, cy - 26, 6, 26), const Radius.circular(3)),
        Paint()..color = const Color(0xFFD9A441));
    canvas.drawCircle(
        const Offset(cx, cy - 27), 4, Paint()..color = const Color(0xFFF3D27A));
  }

  @override
  bool shouldRepaint(covariant _ClassicRecordPainter old) => false;
}

class _CassetteReel extends StatelessWidget {
  final Animation<double> spin;
  final Color accent;
  const _CassetteReel({required this.spin, required this.accent});

  @override
  Widget build(BuildContext context) => RotationTransition(
    turns: spin,
    child: Container(
      width: 46, height: 46,
      decoration: BoxDecoration(shape: BoxShape.circle,
        gradient: const RadialGradient(colors: [Color(0xFFBCC8D5), Color(0xFF566477), Color(0xFF17202D)]),
        border: Border.all(color: accent.withOpacity(.8), width: 2),
        boxShadow: [BoxShadow(color: accent.withOpacity(.35), blurRadius: 8)]),
      child: Center(child: Container(width: 20, height: 20,
        decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF101722),
          border: Border.all(color: Colors.white70, width: 2)),
        child: Icon(Icons.settings_rounded, size: 12, color: accent))),
    ),
  );
}
