import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/file_ops.dart';
import 'package:abtin_file_manager/widgets/ui.dart';

void main() {
  testWidgets('Word, Excel, and PowerPoint use distinct dedicated marks', (t) async {
    await t.pumpWidget(const MaterialApp(
      home: Scaffold(
        body: Column(children: [
          TypeIcon('/files/letter.DOCX', false, size: 36),
          TypeIcon('/files/budget.xlsx', false, size: 36),
          TypeIcon('/files/talk.ppsx', false, size: 36),
        ]),
      ),
    ));

    expect(find.text('W'), findsOneWidget);
    expect(find.text('X'), findsOneWidget);
    expect(find.text('P'), findsOneWidget);
    expect(FileOps.catOf('/files/slides.pptm'), Cat.docs);
    expect(FileOps.catOf('/files/sheet.xlsm'), Cat.docs);
  });
}
