import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../services/player_service.dart';

/// Gramophone tonearm drawn over a 340 x 350 area (the record is 300 px at top 45, centre (150,195)).
/// Play  -> the arm swings in and drops the needle on the outer groove,
///          then creeps towards the label while the song advances.
/// Pause -> the arm lifts and swings back to its rest post.
class Tonearm extends StatefulWidget {
  final PlayerService pl;
  const Tonearm({super.key, required this.pl});
  static const size = Size(340, 350);
  @override
  State<Tonearm> createState() => _TonearmState();
}

class _TonearmState extends State<Tonearm> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 1100), value: widget.pl.playing ? 1 : 0);

  @override
  void didUpdateWidget(Tonearm old) {
    super.didUpdateWidget(old);
    _sync();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    _sync();
  }

  void _sync() {
    if (widget.pl.playing) {
      if (_c.status != AnimationStatus.forward && _c.value < 1) _c.forward();
    } else {
      if (_c.status != AnimationStatus.reverse && _c.value > 0) _c.reverse();
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.pl.player;
    return StreamBuilder<Duration>(
      stream: p.stream.position,
      builder: (_, snap) {
        final d = p.state.duration.inMilliseconds;
        final pos = (snap.data ?? p.state.position).inMilliseconds;
        final prog = d <= 0 ? 0.0 : (pos / d).clamp(0.0, 1.0).toDouble();
        return TweenAnimationBuilder<double>(
          tween: Tween<double>(end: prog),
          duration: const Duration(milliseconds: 600),
          builder: (_, sm, __) => AnimatedBuilder(
            animation: _c,
            builder: (_, __) => CustomPaint(
              size: Tonearm.size,
              painter: _ArmPainter(Curves.easeInOutCubic.transform(_c.value), sm),
            ),
          ),
        );
      },
    );
  }
}

class _ArmPainter extends CustomPainter {
  final double engaged; // 0 = resting, 1 = needle on the record
  final double progress; // 0..1 position in the song
  _ArmPainter(this.engaged, this.progress);

  static const pivot = Offset(300, 52);
  static const center = Offset(150, 195);
  static const armLen = 235.0;
  static const restAngle = 82 * math.pi / 180;

  /// Arm angle for which the needle touches the circle of radius [r] around the record centre.
  static double phiFor(double r) {
    final d = (center - pivot).distance;
    final base = math.atan2(center.dy - pivot.dy, center.dx - pivot.dx);
    final ca = ((armLen * armLen + d * d - r * r) / (2 * armLen * d)).clamp(-1.0, 1.0).toDouble();
    return base - math.acos(ca);
  }

  @override
  void paint(Canvas canvas, Size s) {
    final play = ui.lerpDouble(phiFor(142), phiFor(106), progress)!;
    final phi = ui.lerpDouble(restAngle, play, engaged)!;
    final dir = Offset(math.cos(phi), math.sin(phi));
    final tip = pivot + dir * armLen;
    final tail = pivot - dir * 44;
    final lift = 1 - engaged; // shadow gets longer while the arm is up
    final so = Offset(3 + 7 * lift, 5 + 9 * lift);

    // rest post
    final restTip = pivot + Offset(math.cos(restAngle), math.sin(restAngle)) * armLen;
    canvas.drawRRect(
        RRect.fromRectAndRadius(Rect.fromCenter(center: restTip + const Offset(0, 6), width: 18, height: 30), const Radius.circular(8)),
        Paint()..color = const Color(0xFF2A2D34));

    // shadow
    final sh = Paint()
      ..color = Colors.black.withOpacity(.45)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, 5 + 5 * lift)
      ..strokeWidth = 8
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(tail + so, tip + so, sh);

    // counterweight
    canvas.save();
    canvas.translate(tail.dx, tail.dy);
    canvas.rotate(phi);
    canvas.drawRRect(
        RRect.fromRectAndRadius(const Rect.fromLTWH(-24, -14, 28, 28), const Radius.circular(6)),
        Paint()..color = const Color(0xFF3A3F48));
    canvas.drawRRect(
        RRect.fromRectAndRadius(const Rect.fromLTWH(-24, -14, 28, 28), const Radius.circular(6)),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = const Color(0xFF6B717C));
    canvas.restore();

    // arm tube
    canvas.drawLine(tail, tip, Paint()..color = const Color(0xFF8E96A3)..strokeWidth = 8..strokeCap = StrokeCap.round);
    canvas.drawLine(tail, tip, Paint()..color = const Color(0xFFD9DEE6)..strokeWidth = 3..strokeCap = StrokeCap.round);

    // base
    canvas.drawCircle(pivot, 26, Paint()..color = const Color(0xFF16181D));
    canvas.drawCircle(pivot, 26, Paint()..style = PaintingStyle.stroke..strokeWidth = 2..color = const Color(0xFF4A505B));
    canvas.drawCircle(pivot, 13, Paint()..color = const Color(0xFFF5A623));
    canvas.drawCircle(pivot, 5, Paint()..color = const Color(0xFF3A2A08));

    // head shell (cartridge) ends exactly at the needle point
    canvas.save();
    canvas.translate(tip.dx, tip.dy);
    canvas.rotate(phi + 0.42);
    final head = RRect.fromRectAndRadius(const Rect.fromLTWH(-34, -8, 34, 16), const Radius.circular(4));
    canvas.drawRRect(head, Paint()..color = const Color(0xFFF5A623));
    canvas.drawRRect(head, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = const Color(0xFF7A4E08));
    canvas.drawLine(const Offset(-6, 0), const Offset(2, 0), Paint()..color = Colors.white..strokeWidth = 2..strokeCap = StrokeCap.round);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _ArmPainter o) => o.engaged != engaged || o.progress != progress;
}
