package ir.abtin.gecko;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import org.json.JSONObject;
import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.BasicSelectionActionDelegate;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.WebRequestError;
import org.mozilla.geckoview.WebResponse;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * An installed web app (PWA): a screen of its own, in its own task (its own entry in Recents), exactly like a Chrome / Firefox
 * web app. It shares Gecko's runtime (cookies, logins, storage) with the browser but has no tabs, no address bar and does
 * not appear in the browser. Links that leave the site are handed to the browser.
 */
public final class PwaActivity extends Activity {
    private static final String TAG = "AbtinPwa";

    private Engine e;
    private GeckoView gv;
    private GeckoSession session;
    private FrameLayout root;
    private View bar;
    private String startUrl = "";
    private String curUrl = "";
    private boolean canGoBack;
    private boolean fullscreen;
    private int barColor;
    private boolean pageColor; // the page told us its own colour: the manifest colour no longer overrides it
    private boolean loaded;

    private boolean fa() { return e != null && "fa".equals(e.lang); }
    private String tr(String f, String en) { return fa() ? f : en; }

    @Override
    protected void onCreate(@Nullable android.os.Bundle b) {
        super.onCreate(b);
        e = Engine.get(this);
        e.ensureRuntime();

        final Uri d = getIntent() == null ? null : getIntent().getData();
        if (d == null || d.getScheme() == null || !d.getScheme().toLowerCase(Locale.ROOT).startsWith("http")) { finish(); return; }
        startUrl = d.toString();
        curUrl = startUrl;
        final String title = getIntent().getStringExtra("abtin_title");
        setLabel(title != null && !title.isEmpty() ? title : d.getHost());

        barColor = e.dark ? 0xFF111318 : 0xFFFFFFFF;
        // the colour this web app had last time: no white flash in the notch area while the page loads
        try {
            final int saved = getSharedPreferences("abtin_pwa_colors", MODE_PRIVATE).getInt(String.valueOf(d.getHost()), 0);
            if (saved != 0) barColor = saved;
        } catch (Throwable ignored) { }
        getWindow().setBackgroundDrawable(new ColorDrawable(barColor));
        // Edge-to-edge: the app's own root view (painted with the page colour) sits under the status bar, the camera cut-out and the
        // navigation bar, so the notch area is never the system's white / black; the insets below keep the page itself clear of them.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        // Paint the notch / camera cut-out area (also the side strips in landscape) with the app colour instead of
        // leaving it white or black, and keep the system from tinting the bars with its own contrast scrim.
        if (Build.VERSION.SDK_INT >= 28) {
            final android.view.WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                    ? android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            getWindow().setStatusBarContrastEnforced(false);
            getWindow().setNavigationBarContrastEnforced(false);
        }

        root = new FrameLayout(this);
        root.setBackgroundColor(barColor);
        gv = new GeckoView(this);
        root.addView(gv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        bar = new View(this);
        bar.setBackgroundColor(e.accent);
        bar.setVisibility(View.GONE);
        root.addView(bar, new FrameLayout.LayoutParams(0, dp(3), Gravity.TOP | Gravity.START));
        setContentView(root);
        // Edge-to-edge devices draw under the system bars: keep the page clear of them (and above the keyboard).
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            final Insets sb = insets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.displayCutout());
            final Insets ime = insets.getInsets(WindowInsetsCompat.Type.ime());
            v.setPadding(sb.left, fullscreen ? 0 : sb.top, sb.right, fullscreen ? ime.bottom : Math.max(sb.bottom, ime.bottom));
            return insets;
        });
        applyBarColor(barColor);

        // Back: on Android 13+ the system only calls an OnBackInvokedCallback (onBackPressed is skipped, and on newer
        // releases the opt-out is ignored, which made Back close the web app at once). Older versions use onBackPressed.
        if (Build.VERSION.SDK_INT >= 33) {
            backCb = this::handleBack;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCb);
        }

        final GeckoSessionSettings.Builder sb = new GeckoSessionSettings.Builder()
                .usePrivateMode(false)
                .suspendMediaWhenInactive(false) // calls / voice messages keep playing when the app is in the background
                .userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_MOBILE)
                .viewportMode(GeckoSessionSettings.VIEWPORT_MODE_MOBILE);
        if (!e.uaOverride.isEmpty()) sb.userAgentOverride(e.uaOverride);
        session = new GeckoSession(sb.build());
        session.setProgressDelegate(progress);
        session.setNavigationDelegate(navigation);
        session.setContentDelegate(content);
        session.setPermissionDelegate(permission);
        session.setPromptDelegate(new PwaPrompts());
        session.setSelectionActionDelegate(new BasicSelectionActionDelegate(this));
        session.open(e.runtime);
        gv.setSession(session);
        session.setActive(true);
        // The first page load waits for the built-in core extension (same rule as the browser's tabs).
        e.whenCoreReady(() -> {
            if (!loaded && session != null) {
                loaded = true;
                if (e.extensions != null) e.extensions.wireSession(session, contentMsgs);
                session.loadUri(startUrl);
            }
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Same site opened again (shortcut tapped while running): this task is simply brought to the front.
        setIntent(intent);
    }

    @Override protected void onResume() {
        super.onResume();
        if (e != null) {
            e.pwaActivity = this;
            // a login code may have arrived while the user was in the SMS app
            ui.postDelayed(() -> { if (e != null && e.pwaActivity == this) e.smsOtp.pushForeground(); }, 500);
        }
    }

    /** An SMS login code for the page on screen (see SmsOtp). */
    void deliverOtp(JSONObject j) {
        if (cport == null) return;
        try { cport.postMessage(j); } catch (Throwable t) { Log.w(TAG, "otp", t); }
    }

    @Override protected void onPause() {
        if (e != null && e.pwaActivity == this) e.pwaActivity = null;
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (Build.VERSION.SDK_INT >= 33 && backCb != null) {
            try { getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCb); } catch (Throwable ignored) { }
            backCb = null;
        }
        if (e != null && e.pwaActivity == this) e.pwaActivity = null;
        try {
            if (gv != null && gv.getSession() != null) gv.releaseSession();
            if (session != null && session.isOpen()) session.close();
        } catch (Throwable t) { Log.w(TAG, "close", t); }
        session = null;
        super.onDestroy();
    }

    private android.window.OnBackInvokedCallback backCb;

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() { handleBack(); }

    private void handleBack() {
        if (fullscreen && session != null) { session.exitFullScreen(); return; }
        if (canGoBack && session != null) { session.goBack(); return; }
        // No page history left: chat web apps keep their screens in-page. Ask the page's content script to close the open
        // chat / dialog (Escape + a visible back/close button); only when it did nothing does the double-Back exit apply.
        if (cport != null) {
            final int id = ++backId;
            try {
                cport.postMessage(new JSONObject().put("cmd", "back").put("id", id));
                backTimeout = () -> { backTimeout = null; if (backId == id) exitOnDoubleBack(); };
                ui.postDelayed(backTimeout, 1200);
                return;
            } catch (Throwable t) { Log.w(TAG, "back msg", t); }
        }
        exitOnDoubleBack();
    }

    private void exitOnDoubleBack() {
        final long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastBackAt < 2000) { finish(); return; }
        lastBackAt = now;
        Engine.sendEscape(gv);
        Toast.makeText(this, tr("برای خروج، دوباره بازگشت را بزنید", "Press back again to exit"), Toast.LENGTH_SHORT).show();
    }

    private long lastBackAt;
    private int backId;
    private Runnable backTimeout;
    private org.mozilla.geckoview.WebExtension.Port cport;
    private final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());

    private final org.mozilla.geckoview.WebExtension.MessageDelegate contentMsgs = new org.mozilla.geckoview.WebExtension.MessageDelegate() {
        @Override public void onConnect(@NonNull final org.mozilla.geckoview.WebExtension.Port port) {
            if (!port.sender.isTopLevel()) return;
            cport = port;
            port.setDelegate(new org.mozilla.geckoview.WebExtension.PortDelegate() {
                @Override public void onPortMessage(@NonNull Object message, @NonNull org.mozilla.geckoview.WebExtension.Port p) {
                    if (!(message instanceof JSONObject)) return;
                    final JSONObject j = (JSONObject) message;
                    final String type = j.optString("t");
                    if ("otpField".equals(type)) { e.smsOtp.onField(p); return; }
                    if ("otpUsed".equals(type)) { e.smsOtp.clear(); return; }
                    if ("pwaColor".equals(type)) {
                        final Integer pc = cssColor(j.optString("c", null));
                        if (pc != null) {
                            pageColor = true;
                            final int col = pc | 0xFF000000;
                            try { getSharedPreferences("abtin_pwa_colors", MODE_PRIVATE).edit().putInt(String.valueOf(Uri.parse(startUrl).getHost()), col).apply(); } catch (Throwable ignored) { }
                            runOnUiThread(() -> applyBarColor(col));
                        }
                        return;
                    }
                    if (!"backDone".equals(type)) return;
                    final int id = j.optInt("id", -1);
                    final boolean handled = j.optBoolean("handled", false);
                    runOnUiThread(() -> {
                        if (id != backId) return;
                        if (backTimeout != null) { ui.removeCallbacks(backTimeout); backTimeout = null; }
                        if (!handled) exitOnDoubleBack();
                    });
                }
                @Override public void onDisconnect(@NonNull org.mozilla.geckoview.WebExtension.Port p) { if (cport == p) cport = null; }
            });
        }
    };

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (e == null || !e.onActivityResult(req, res, data)) super.onActivityResult(req, res, data);
    }

    @Override
    public void onRequestPermissionsResult(int req, @NonNull String[] perms, @NonNull int[] results) {
        if (e == null || !e.onPermissionsResult(req, perms, results)) super.onRequestPermissionsResult(req, perms, results);
    }

    // ------------------------------------------------------------------ look

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @SuppressWarnings("deprecation")
    private void setLabel(String label) {
        try { setTaskDescription(new ActivityManager.TaskDescription(label == null || label.isEmpty() ? null : label)); } catch (Throwable ignored) { }
    }

    private void applyBarColor(int color) {
        barColor = color;
        root.setBackgroundColor(color);
        getWindow().setBackgroundDrawable(new ColorDrawable(color));
        try {
            getWindow().setStatusBarColor(color);
            getWindow().setNavigationBarColor(color);
            getWindow().getDecorView().setBackgroundColor(color);
        } catch (Throwable ignored) { }
        final boolean light = androidx.core.graphics.ColorUtils.calculateLuminance(color) > 0.5;
        final WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), root);
        if (c != null) {
            c.setAppearanceLightStatusBars(light);
            c.setAppearanceLightNavigationBars(light);
        }
    }

    private void setFullscreen(boolean on) {
        fullscreen = on;
        final WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), root);
        if (c != null) {
            if (on) {
                c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                c.hide(WindowInsetsCompat.Type.systemBars());
            } else {
                c.show(WindowInsetsCompat.Type.systemBars());
            }
        }
        root.requestApplyInsets();
    }

    @Nullable
    private static Integer cssColor(@Nullable String s) {
        if (s == null || s.trim().isEmpty()) return null;
        try { return Color.parseColor(s.trim()); } catch (Throwable ignored) { }
        return null;
    }

    // ------------------------------------------------------------------ scope / external links

    private static String baseDomain(@Nullable String host) {
        if (host == null) return "";
        final String h = host.toLowerCase(Locale.ROOT);
        final String[] p = h.split("\\.");
        if (p.length <= 2) return h;
        // co.ir / ac.ir / com.au ...: the registrable domain has three labels
        final boolean shortTld = p[p.length - 1].length() == 2 && p[p.length - 2].length() <= 3;
        final int n = shortTld ? 3 : 2;
        final StringBuilder sb = new StringBuilder();
        for (int i = p.length - n; i < p.length; i++) { if (sb.length() > 0) sb.append('.'); sb.append(p[i]); }
        return sb.toString();
    }

    private boolean inScope(@Nullable String url) {
        try { return baseDomain(Uri.parse(url).getHost()).equals(baseDomain(Uri.parse(startUrl).getHost())); } catch (Throwable t) { return true; }
    }

    private void openInBrowser(String url) {
        try {
            final Intent launch = getPackageManager().getLaunchIntentForPackage(getPackageName());
            final Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            if (launch != null && launch.getComponent() != null) it.setComponent(launch.getComponent()); else it.setPackage(getPackageName());
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(it);
        } catch (Throwable t) { Log.w(TAG, "openInBrowser", t); }
    }

    // ------------------------------------------------------------------ delegates

    private final GeckoSession.ProgressDelegate progress = new GeckoSession.ProgressDelegate() {
        @Override public void onPageStart(@NonNull GeckoSession s, @NonNull String url) { runOnUiThread(() -> { bar.setVisibility(View.VISIBLE); setBar(5); }); }
        @Override public void onPageStop(@NonNull GeckoSession s, boolean ok) { runOnUiThread(() -> bar.setVisibility(View.GONE)); }
        @Override public void onProgressChange(@NonNull GeckoSession s, int p) { runOnUiThread(() -> { if (p >= 100) bar.setVisibility(View.GONE); else { bar.setVisibility(View.VISIBLE); setBar(p); } }); }
    };

    private void setBar(int pct) {
        final ViewGroup.LayoutParams lp = bar.getLayoutParams();
        lp.width = Math.max(dp(8), root.getWidth() * Math.max(0, Math.min(100, pct)) / 100);
        bar.setLayoutParams(lp);
    }

    private final GeckoSession.NavigationDelegate navigation = new GeckoSession.NavigationDelegate() {
        @Override
        public void onLocationChange(@NonNull GeckoSession s, @Nullable String url,
                                     @NonNull List<GeckoSession.PermissionDelegate.ContentPermission> perms, @NonNull Boolean gesture) {
            if (url != null && !url.startsWith("data:text/html")) curUrl = url;
        }

        @Override public void onCanGoBack(@NonNull GeckoSession s, boolean can) { canGoBack = can; }

        @Nullable @Override
        public GeckoResult<AllowOrDeny> onLoadRequest(@NonNull GeckoSession s, @NonNull LoadRequest req) {
            final Uri u = Uri.parse(req.uri);
            final String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase(Locale.ROOT);
            switch (sc) {
                case "http": case "https":
                    // From inside the app a tapped link to another site opens in the browser; redirects / sign-in flows stay here.
                    if (req.hasUserGesture && inScope(curUrl) && !inScope(req.uri)) {
                        openInBrowser(req.uri);
                        return GeckoResult.deny();
                    }
                    return GeckoResult.allow();
                case "about": case "data": case "blob": case "javascript": case "moz-extension": case "view-source": case "ws": case "wss":
                    return GeckoResult.allow();
                case "file": case "content": case "chrome": case "resource": case "jar":
                    return GeckoResult.deny();
                case "intent": {
                    try {
                        final Intent it = Intent.parseUri(req.uri, Intent.URI_INTENT_SCHEME);
                        final String fb = it.getStringExtra("browser_fallback_url");
                        if (fb != null && (fb.startsWith("https://") || fb.startsWith("http://"))) runOnUiThread(() -> s.loadUri(fb));
                    } catch (Exception ignored) { }
                    return GeckoResult.deny();
                }
                default: {
                    final boolean direct = sc.equals("tel") || sc.equals("mailto") || sc.equals("sms");
                    if (!req.hasUserGesture && !direct && !req.isDirectNavigation) return GeckoResult.deny();
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Throwable ignored) { }
                    return GeckoResult.deny();
                }
            }
        }

        @Nullable @Override
        public GeckoResult<GeckoSession> onNewSession(@NonNull GeckoSession s, @NonNull String uri) {
            // window.open / target=_blank: pages of the app itself replace the current one, other sites go to the browser.
            if (inScope(uri)) runOnUiThread(() -> s.loadUri(uri)); else openInBrowser(uri);
            return null;
        }

        @Nullable @Override
        public GeckoResult<String> onLoadError(@NonNull GeckoSession s, @Nullable String uri, @NonNull WebRequestError error) {
            return GeckoResult.fromValue(ErrorPage.build(e.lang, e.dark, e.accent, uri, error));
        }
    };

    private final GeckoSession.ContentDelegate content = new GeckoSession.ContentDelegate() {
        @Override public void onTitleChange(@NonNull GeckoSession s, @Nullable String title) {
            if (title != null && !title.isEmpty()) runOnUiThread(() -> setLabel(title));
        }

        @Override public void onFullScreen(@NonNull GeckoSession s, boolean on) { runOnUiThread(() -> setFullscreen(on)); }

        @Override public void onCloseRequest(@NonNull GeckoSession s) { runOnUiThread(PwaActivity.this::finish); }

        @Override public void onExternalResponse(@NonNull GeckoSession s, @NonNull WebResponse r) { saveDownload(r); }

        @Override public void onCrash(@NonNull GeckoSession s) { reopen(); }
        @Override public void onKill(@NonNull GeckoSession s) { reopen(); }

        // Web app manifest (theme_color / background_color): colours the status bar like an installed app.
        // No @Override: older GeckoView builds do not have this callback.
        public void onWebAppManifest(@NonNull GeckoSession s, @NonNull JSONObject manifest) {
            Integer c = cssColor(manifest.optString("theme_color", null));
            if (c == null) c = cssColor(manifest.optString("background_color", null));
            if (c == null) return;
            final int col = c | 0xFF000000;
            runOnUiThread(() -> { if (!pageColor) applyBarColor(col); });
        }

        private void reopen() {
            runOnUiThread(() -> {
                try {
                    session.open(e.runtime);
                    gv.releaseSession();
                    gv.setSession(session);
                    session.loadUri(curUrl.isEmpty() ? startUrl : curUrl);
                } catch (Throwable t) { Log.e(TAG, "reopen", t); }
            });
        }
    };

    private final GeckoSession.PermissionDelegate permission = new GeckoSession.PermissionDelegate() {
        @Override
        public void onAndroidPermissionsRequest(@NonNull GeckoSession s, @Nullable String[] perms, @NonNull Callback cb) {
            runOnUiThread(() -> e.prompts.requestAndroidPermissions(perms, cb));
        }

        @Nullable @Override
        public GeckoResult<Integer> onContentPermissionRequest(@NonNull GeckoSession s, @NonNull ContentPermission perm) {
            switch (perm.permission) {
                case PERMISSION_GEOLOCATION: {
                    final GeckoResult<Integer> res = new GeckoResult<>();
                    final String host = Engine.hostOf(perm.uri);
                    yesNo(tr("دسترسی به مکان", "Location"), host + "\n" + tr("اجازه‌ی دسترسی به مکان شما؟", "Allow access to your location?"),
                            ok -> res.complete(ok ? ContentPermission.VALUE_ALLOW : ContentPermission.VALUE_DENY));
                    return res;
                }
                case PERMISSION_STORAGE_ACCESS: case PERMISSION_PERSISTENT_STORAGE: case PERMISSION_MEDIA_KEY_SYSTEM_ACCESS:
                    return GeckoResult.fromValue(ContentPermission.VALUE_ALLOW);
                default:
                    return GeckoResult.fromValue(ContentPermission.VALUE_PROMPT);
            }
        }

        @Override
        public void onMediaPermissionRequest(@NonNull GeckoSession s, @NonNull String uri, @Nullable MediaSource[] video,
                                             @Nullable MediaSource[] audio, @NonNull MediaCallback cb) {
            final boolean v = video != null && video.length > 0, a = audio != null && audio.length > 0;
            if (!v && !a) { cb.reject(); return; }
            final String what = v && a ? tr("دوربین و میکروفون", "camera and microphone") : v ? tr("دوربین", "camera") : tr("میکروفون", "microphone");
            yesNo(Engine.hostOf(uri), tr("اجازه‌ی استفاده از ", "Allow use of the ") + what + (fa() ? "؟" : "?"), ok -> {
                if (ok) cb.grant(v ? video[0] : null, a ? audio[0] : null); else cb.reject();
            });
        }
    };

    private interface Yes { void run(boolean ok); }

    private void yesNo(String title, String msg, Yes cb) {
        runOnUiThread(() -> {
            final boolean[] done = {false};
            try {
                new AlertDialog.Builder(this).setTitle(title).setMessage(msg)
                        .setPositiveButton(tr("اجازه", "Allow"), (d, w) -> { if (!done[0]) { done[0] = true; cb.run(true); } })
                        .setNegativeButton(tr("رد", "Block"), (d, w) -> { if (!done[0]) { done[0] = true; cb.run(false); } })
                        .setOnCancelListener(d -> { if (!done[0]) { done[0] = true; cb.run(false); } })
                        .show();
            } catch (Throwable t) { if (!done[0]) { done[0] = true; cb.run(false); } }
        });
    }

    // ------------------------------------------------------------------ prompts (native dialogs; files / dates / share reuse the browser's code)

    private final class PwaPrompts implements GeckoSession.PromptDelegate {
        @Nullable @Override
        public GeckoResult<PromptResponse> onAlertPrompt(@NonNull GeckoSession s, @NonNull AlertPrompt p) {
            final GeckoResult<PromptResponse> res = new GeckoResult<>();
            runOnUiThread(() -> {
                final boolean[] done = {false};
                try {
                    new AlertDialog.Builder(PwaActivity.this).setTitle(p.title).setMessage(p.message)
                            .setPositiveButton("OK", (d, w) -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } })
                            .setOnCancelListener(d -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } })
                            .show();
                } catch (Throwable t) { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } }
            });
            return res;
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onButtonPrompt(@NonNull GeckoSession s, @NonNull ButtonPrompt p) {
            final GeckoResult<PromptResponse> res = new GeckoResult<>();
            runOnUiThread(() -> {
                final boolean[] done = {false};
                try {
                    new AlertDialog.Builder(PwaActivity.this).setTitle(p.title).setMessage(p.message)
                            .setPositiveButton(tr("تأیید", "OK"), (d, w) -> { if (!done[0]) { done[0] = true; res.complete(p.confirm(ButtonPrompt.Type.POSITIVE)); } })
                            .setNegativeButton(tr("انصراف", "Cancel"), (d, w) -> { if (!done[0]) { done[0] = true; res.complete(p.confirm(ButtonPrompt.Type.NEGATIVE)); } })
                            .setOnCancelListener(d -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } })
                            .show();
                } catch (Throwable t) { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } }
            });
            return res;
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onTextPrompt(@NonNull GeckoSession s, @NonNull TextPrompt p) {
            final GeckoResult<PromptResponse> res = new GeckoResult<>();
            runOnUiThread(() -> {
                final boolean[] done = {false};
                try {
                    final EditText et = new EditText(PwaActivity.this);
                    et.setInputType(InputType.TYPE_CLASS_TEXT);
                    if (p.defaultValue != null) et.setText(p.defaultValue);
                    new AlertDialog.Builder(PwaActivity.this).setTitle(p.title).setMessage(p.message).setView(et)
                            .setPositiveButton(tr("تأیید", "OK"), (d, w) -> { if (!done[0]) { done[0] = true; res.complete(p.confirm(et.getText().toString())); } })
                            .setNegativeButton(tr("انصراف", "Cancel"), (d, w) -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } })
                            .setOnCancelListener(d -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } })
                            .show();
                } catch (Throwable t) { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } }
            });
            return res;
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onChoicePrompt(@NonNull GeckoSession s, @NonNull ChoicePrompt p) {
            final GeckoResult<PromptResponse> res = new GeckoResult<>();
            final List<ChoicePrompt.Choice> list = new ArrayList<>();
            flat(p.choices, list);
            if (list.isEmpty()) return GeckoResult.fromValue(p.dismiss());
            final CharSequence[] labels = new CharSequence[list.size()];
            final boolean[] checked = new boolean[list.size()];
            int sel = -1;
            for (int i = 0; i < labels.length; i++) {
                labels[i] = list.get(i).label;
                checked[i] = list.get(i).selected;
                if (checked[i] && sel < 0) sel = i;
            }
            final int selected = sel;
            runOnUiThread(() -> {
                final boolean[] done = {false};
                try {
                    final AlertDialog.Builder b = new AlertDialog.Builder(PwaActivity.this);
                    if (p.title != null && !p.title.isEmpty()) b.setTitle(p.title);
                    if (p.type == ChoicePrompt.Type.MULTIPLE) {
                        b.setMultiChoiceItems(labels, checked, (d, i, on) -> checked[i] = on)
                                .setPositiveButton(tr("تأیید", "OK"), (d, w) -> {
                                    if (done[0]) return;
                                    done[0] = true;
                                    final List<String> ids = new ArrayList<>();
                                    for (int i = 0; i < checked.length; i++) if (checked[i]) ids.add(list.get(i).id);
                                    res.complete(p.confirm(ids.toArray(new String[0])));
                                });
                    } else {
                        b.setSingleChoiceItems(labels, selected, (d, i) -> {
                            if (done[0]) return;
                            done[0] = true;
                            res.complete(p.confirm(list.get(i).id));
                            d.dismiss();
                        });
                    }
                    b.setOnCancelListener(d -> { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } });
                    b.show();
                } catch (Throwable t) { if (!done[0]) { done[0] = true; res.complete(p.dismiss()); } }
            });
            return res;
        }

        private void flat(@Nullable ChoicePrompt.Choice[] cs, List<ChoicePrompt.Choice> out) {
            if (cs == null) return;
            for (ChoicePrompt.Choice c : cs) {
                if (c.separator) continue;
                if (c.items != null) { flat(c.items, out); continue; }
                if (!c.disabled) out.add(c);
            }
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onBeforeUnloadPrompt(@NonNull GeckoSession s, @NonNull BeforeUnloadPrompt p) {
            return GeckoResult.fromValue(p.confirm(AllowOrDeny.ALLOW));
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onRepostConfirmPrompt(@NonNull GeckoSession s, @NonNull RepostConfirmPrompt p) {
            return GeckoResult.fromValue(p.confirm(AllowOrDeny.ALLOW));
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onRedirectPrompt(@NonNull GeckoSession s, @NonNull RedirectPrompt p) {
            return GeckoResult.fromValue(p.confirm(AllowOrDeny.ALLOW));
        }

        @Nullable @Override
        public GeckoResult<PromptResponse> onPopupPrompt(@NonNull GeckoSession s, @NonNull PopupPrompt p) { return e.prompts.onPopupPrompt(s, p); }

        @Nullable @Override
        public GeckoResult<PromptResponse> onFilePrompt(@NonNull GeckoSession s, @NonNull FilePrompt p) { return e.prompts.onFilePrompt(s, p); }

        @Nullable @Override
        public GeckoResult<PromptResponse> onDateTimePrompt(@NonNull GeckoSession s, @NonNull DateTimePrompt p) { return e.prompts.onDateTimePrompt(s, p); }

        @Nullable @Override
        public GeckoResult<PromptResponse> onSharePrompt(@NonNull GeckoSession s, @NonNull SharePrompt p) { return e.prompts.onSharePrompt(s, p); }

        @Nullable @Override
        public GeckoResult<PromptResponse> onColorPrompt(@NonNull GeckoSession s, @NonNull ColorPrompt p) { return GeckoResult.fromValue(p.dismiss()); }
    }

    // ------------------------------------------------------------------ downloads (saved straight to the Downloads folder)

    private static String header(@Nullable Map<String, String> h, String name) {
        if (h == null) return null;
        for (Map.Entry<String, String> en : h.entrySet()) if (en.getKey() != null && en.getKey().equalsIgnoreCase(name)) return en.getValue();
        return null;
    }

    private static String fileName(WebResponse r) {
        String name = null;
        final String cd = header(r.headers, "Content-Disposition");
        if (cd != null) {
            final java.util.regex.Matcher m5 = java.util.regex.Pattern.compile("filename\\*\\s*=\\s*[^']*'[^']*'([^;]+)", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(cd);
            final java.util.regex.Matcher m = java.util.regex.Pattern.compile("filename\\s*=\\s*\"?([^\";]+)\"?", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(cd);
            if (m5.find()) { try { name = Uri.decode(m5.group(1).trim()); } catch (Throwable ignored) { } }
            if ((name == null || name.isEmpty()) && m.find()) name = m.group(1).trim();
        }
        if (name == null || name.isEmpty()) {
            try { name = Uri.parse(r.uri).getLastPathSegment(); } catch (Throwable ignored) { }
        }
        if (name == null || name.isEmpty()) name = "download_" + System.currentTimeMillis();
        return name.replaceAll("[\\\\/:*?\"<>|]", "_");
    }

    private void saveDownload(final WebResponse r) {
        final InputStream in = r.body;
        if (in == null) return;
        final String name = fileName(r);
        String mime = header(r.headers, "Content-Type");
        if (mime != null && mime.contains(";")) mime = mime.substring(0, mime.indexOf(';')).trim();
        final String type = mime == null || mime.isEmpty() ? "application/octet-stream" : mime;
        runOnUiThread(() -> Toast.makeText(this, tr("دانلود شروع شد: ", "Downloading: ") + name, Toast.LENGTH_SHORT).show());
        new Thread(() -> {
            boolean ok = false;
            try (InputStream src = in) {
                OutputStream out;
                Uri item = null;
                if (Build.VERSION.SDK_INT >= 29) {
                    final ContentValues cv = new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE, type);
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
                    item = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (item == null) throw new IllegalStateException("no MediaStore item");
                    out = getContentResolver().openOutputStream(item);
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    if (dir == null) dir = getFilesDir();
                    dir.mkdirs();
                    out = new FileOutputStream(new File(dir, name));
                }
                if (out == null) throw new IllegalStateException("no output");
                try (OutputStream o = out) {
                    final byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = src.read(buf)) > 0) o.write(buf, 0, n);
                }
                if (item != null) {
                    final ContentValues done = new ContentValues();
                    done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                    getContentResolver().update(item, done, null, null);
                }
                ok = true;
            } catch (Throwable t) {
                Log.e(TAG, "download", t);
            }
            final boolean fin = ok;
            runOnUiThread(() -> Toast.makeText(this, (fin ? tr("ذخیره شد در دانلودها: ", "Saved to Downloads: ") : tr("دانلود ناموفق: ", "Download failed: ")) + name, Toast.LENGTH_LONG).show());
        }, "abtin-pwa-download").start();
    }
}
