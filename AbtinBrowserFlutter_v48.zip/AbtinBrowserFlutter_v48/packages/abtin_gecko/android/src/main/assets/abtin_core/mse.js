// Runs in the PAGE's own JS world (manifest "world":"MAIN") at document_start.
// Blob / MSE players (Instagram, Facebook, ...) give a <video> a blob: URL, so the real stream cannot be read from the element.
// Here we follow the data: fetch/XHR -> ArrayBuffer -> SourceBuffer.appendBuffer -> MediaSource -> blob URL -> <video>,
// and publish the stream URLs of each video in its `data-abtin-u` attribute (JSON array). The content script reads it when a
// video button is tapped, so each button downloads / plays exactly its own video.
(function () {
  'use strict';
  try {
    if (window.__abtinMse || typeof MediaSource === 'undefined') return;
    window.__abtinMse = 1;
    var bufUrl = new WeakMap(), msOfSb = new WeakMap(), msUrls = new WeakMap(), msBlob = new WeakMap();
    var blobMs = {}, blobOrder = [];

    function clean(u) {
      try {
        var o = new URL(u, location.href), h = o.hostname;
        if (/(^|\.)(fbcdn\.net|cdninstagram\.com)$/.test(h)) { o.searchParams.delete('bytestart'); o.searchParams.delete('byteend'); }
        else if (/googlevideo\.com$/.test(h) && o.pathname === '/videoplayback') { ['range', 'rn', 'rbuf'].forEach(function (k) { o.searchParams.delete(k); }); }
        return o.toString();
      } catch (e) { return String(u); }
    }

    var oCreate = URL.createObjectURL;
    URL.createObjectURL = function (obj) {
      var u = oCreate.apply(this, arguments);
      try {
        if (obj instanceof MediaSource) {
          blobMs[u] = obj; blobOrder.push(u); msBlob.set(obj, u);
          if (blobOrder.length > 60) delete blobMs[blobOrder.shift()];
        }
      } catch (e) {}
      return u;
    };

    var oAdd = MediaSource.prototype.addSourceBuffer;
    MediaSource.prototype.addSourceBuffer = function () {
      var sb = oAdd.apply(this, arguments);
      try { msOfSb.set(sb, this); } catch (e) {}
      return sb;
    };

    var oAB = Response.prototype.arrayBuffer;
    Response.prototype.arrayBuffer = function () {
      var url = this.url;
      return oAB.apply(this, arguments).then(function (b) { try { if (url) bufUrl.set(b, url); } catch (e) {} return b; });
    };

    var oOpen = XMLHttpRequest.prototype.open;
    XMLHttpRequest.prototype.open = function (m, url) {
      var u = url;
      try {
        this.addEventListener('load', function () {
          try { if (this.responseType === 'arraybuffer' && this.response) bufUrl.set(this.response, this.responseURL || String(u)); } catch (e) {}
        });
      } catch (e) {}
      return oOpen.apply(this, arguments);
    };

    var oAppend = SourceBuffer.prototype.appendBuffer;
    SourceBuffer.prototype.appendBuffer = function (data) {
      try {
        var ab = data instanceof ArrayBuffer ? data : (data && data.buffer);
        var url = ab && bufUrl.get(ab);
        var ms = msOfSb.get(this);
        if (url && ms) {
          var l = msUrls.get(ms);
          if (!l) { l = []; msUrls.set(ms, l); }
          var c = clean(url);
          if (l.indexOf(c) < 0) { l.push(c); if (l.length > 40) l.shift(); }
        }
      } catch (e) {}
      return oAppend.apply(this, arguments);
    };

    document.addEventListener('__abtin_refresh', function () {
      var vs = document.getElementsByTagName('video');
      for (var i = 0; i < vs.length; i++) {
        var v = vs[i], s = v.currentSrc || v.src, ms = s && blobMs[s], l = ms && msUrls.get(ms);
        if (l && l.length) v.setAttribute('data-abtin-u', JSON.stringify(l));
        else if (v.hasAttribute('data-abtin-u')) v.removeAttribute('data-abtin-u');
      }
    }, true);
  } catch (e) {}
})();
