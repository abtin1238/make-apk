import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../app_state.dart';
import '../models.dart';
import '../services.dart';
import 'glass.dart';
import 'site_icon.dart';
import 'video_player_page.dart';

typedef OpenUrl = void Function(String url, {bool newTab});

Widget _empty(String s) => Center(child: Padding(padding: const EdgeInsets.all(30), child: Text(s, textAlign: TextAlign.center)));

class BookmarksPage extends StatefulWidget {
  const BookmarksPage({super.key, required this.onOpen});
  final OpenUrl onOpen;
  @override
  State<BookmarksPage> createState() => _BookmarksPageState();
}

class _BookmarksPageState extends State<BookmarksPage> {
  String q = '', folder = '';

  Future<void> _edit(Bookmark b) async {
    final t = TextEditingController(text: b.title), f = TextEditingController(text: b.folder);
    final ok = await showGlassDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('ویرایش نشانک', 'Edit bookmark')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: t, decoration: InputDecoration(labelText: tr('عنوان', 'Title'))),
          TextField(controller: f, decoration: InputDecoration(labelText: tr('پوشه', 'Folder'))),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('ذخیره', 'Save')))],
      ),
    );
    if (ok == true) { setState(() { b.title = t.text; b.folder = f.text.trim(); }); app.saveBookmarks(); }
  }

  @override
  Widget build(BuildContext context) {
    final folders = app.bookmarks.map((b) => b.folder).where((f) => f.isNotEmpty).toSet().toList();
    final list = app.bookmarks.where((b) => (folder.isEmpty || b.folder == folder) && (q.isEmpty || b.title.toLowerCase().contains(q.toLowerCase()) || b.url.toLowerCase().contains(q.toLowerCase()))).toList();
    return GlassScaffold(
      appBar: AppBar(title: Text(tr('نشانک‌ها', 'Bookmarks'))),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: TextField(onChanged: (v) => setState(() => q = v), decoration: InputDecoration(hintText: tr('جست‌وجو', 'Search'), prefixIcon: const Icon(Icons.search), filled: true, fillColor: Theme.of(context).cardColor, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)))),
        if (folders.isNotEmpty) SizedBox(height: 40, child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
          Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ChoiceChip(label: Text(tr('همه', 'All')), selected: folder.isEmpty, onSelected: (_) => setState(() => folder = ''))),
          for (final f in folders) Padding(padding: const EdgeInsets.symmetric(horizontal: 4), child: ChoiceChip(label: Text(f), selected: folder == f, onSelected: (_) => setState(() => folder = f))),
        ])),
        Expanded(
          child: list.isEmpty ? _empty(tr('نشانکی وجود ندارد', 'No bookmarks')) : ListView.builder(
            itemCount: list.length,
            itemBuilder: (_, i) {
              final b = list[i];
              return GlassTile(
                leading: SiteIcon(b.url, title: b.title), title: Text(b.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text(b.url, maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr),
                onTap: () { Navigator.pop(context); widget.onOpen(b.url); },
                trailing: PopupMenuButton<String>(
                  onSelected: (v) {
                    if (v == 'tab') { Navigator.pop(context); widget.onOpen(b.url, newTab: true); }
                    if (v == 'edit') _edit(b);
                    if (v == 'copy') Clipboard.setData(ClipboardData(text: b.url));
                    if (v == 'del') { setState(() => app.bookmarks.remove(b)); app.saveBookmarks(); }
                  },
                  itemBuilder: (_) => [
                    PopupMenuItem(value: 'tab', child: Text(tr('تب جدید', 'New tab'))), PopupMenuItem(value: 'edit', child: Text(tr('ویرایش', 'Edit'))),
                    PopupMenuItem(value: 'copy', child: Text(tr('کپی لینک', 'Copy link'))), PopupMenuItem(value: 'del', child: Text(tr('حذف', 'Delete'))),
                  ],
                ),
              );
            },
          ),
        ),
      ]),
    );
  }
}

class HistoryPage extends StatefulWidget {
  const HistoryPage({super.key, required this.onOpen});
  final OpenUrl onOpen;
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  String q = '';

  String _day(int ms) {
    final d = DateTime.fromMillisecondsSinceEpoch(ms), n = DateTime.now();
    final diff = DateTime(n.year, n.month, n.day).difference(DateTime(d.year, d.month, d.day)).inDays;
    if (diff == 0) return tr('امروز', 'Today');
    if (diff == 1) return tr('دیروز', 'Yesterday');
    return '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final list = app.history.where((h) => q.isEmpty || h.title.toLowerCase().contains(q.toLowerCase()) || h.url.toLowerCase().contains(q.toLowerCase())).take(500).toList();
    final children = <Widget>[];
    String? last;
    for (final h in list) {
      final d = _day(h.time);
      if (d != last) { last = d; children.add(Padding(padding: const EdgeInsets.fromLTRB(16, 14, 16, 4), child: Text(d, style: TextStyle(fontWeight: FontWeight.bold, color: Theme.of(context).colorScheme.primary)))); }
      children.add(Dismissible(
        key: ValueKey('${h.url}${h.time}'),
        onDismissed: (_) { app.history.remove(h); app.saveHistory(); setState(() {}); },
        background: Container(margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4), decoration: BoxDecoration(color: Colors.redAccent.withAlpha(170), borderRadius: BorderRadius.circular(18))),
        child: GlassTile(
          dense: true, leading: SiteIcon(h.url, title: h.title), title: Text(h.title, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text(h.url, maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr),
          onTap: () { Navigator.pop(context); widget.onOpen(h.url); },
          onLongPress: () { Navigator.pop(context); widget.onOpen(h.url, newTab: true); },
        ),
      ));
    }
    return GlassScaffold(
      appBar: AppBar(title: Text(tr('تاریخچه', 'History')), actions: [
        IconButton(
          icon: const Icon(Icons.delete_sweep_outlined),
          onPressed: () async {
            final ok = await showGlassDialog<bool>(context: context, builder: (d) => AlertDialog(
                title: Text(tr('پاک کردن تاریخچه؟', 'Clear history?')),
                actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('پاک کردن', 'Clear')))]));
            if (ok == true) { setState(() => app.history.clear()); app.saveHistory(); }
          },
        ),
      ]),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(12), child: TextField(onChanged: (v) => setState(() => q = v), decoration: InputDecoration(hintText: tr('جست‌وجو در تاریخچه', 'Search history'), prefixIcon: const Icon(Icons.search), filled: true, fillColor: Theme.of(context).cardColor, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)))),
        Expanded(child: list.isEmpty ? _empty(tr('تاریخچه خالی است', 'History is empty')) : ListView(children: children)),
      ]),
    );
  }
}

class _FileKind {
  const _FileKind(this.icon, this.color, this.label);
  final IconData icon;
  final Color color;
  final String label;
}

const _imgExt = {'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'avif', 'heic'};

String _extOf(String name) {
  final i = name.lastIndexOf('.');
  return i < 0 || i == name.length - 1 ? '' : name.substring(i + 1).toLowerCase();
}

_FileKind _kindOf(String name) {
  final e = _extOf(name);
  if (_imgExt.contains(e)) return const _FileKind(Icons.image_rounded, Color(0xFF8B5CF6), 'IMG');
  if (e == 'apk' || e == 'xapk' || e == 'apks' || e == 'aab') return const _FileKind(Icons.android_rounded, Color(0xFF22C55E), 'APK');
  if (const {'zip', 'rar', '7z', 'tar', 'gz', 'tgz', 'bz2', 'xz', 'zst'}.contains(e)) return const _FileKind(Icons.folder_zip_rounded, Color(0xFFF59E0B), 'ZIP');
  if (const {'mp4', 'm4v', 'webm', 'mkv', 'mov', '3gp', 'avi', 'ts', 'm3u8'}.contains(e)) return const _FileKind(Icons.movie_rounded, Color(0xFFEF4444), 'VID');
  if (const {'mp3', 'm4a', 'aac', 'ogg', 'oga', 'opus', 'flac', 'wav', 'weba'}.contains(e)) return const _FileKind(Icons.audiotrack_rounded, Color(0xFFEC4899), 'AUD');
  if (e == 'pdf') return const _FileKind(Icons.picture_as_pdf_rounded, Color(0xFFDC2626), 'PDF');
  if (const {'doc', 'docx', 'odt', 'rtf'}.contains(e)) return const _FileKind(Icons.description_rounded, Color(0xFF3B82F6), 'DOC');
  if (const {'xls', 'xlsx', 'ods', 'csv'}.contains(e)) return const _FileKind(Icons.table_chart_rounded, Color(0xFF16A34A), 'XLS');
  if (const {'ppt', 'pptx', 'odp'}.contains(e)) return const _FileKind(Icons.slideshow_rounded, Color(0xFFEA580C), 'PPT');
  if (const {'txt', 'md', 'log', 'json', 'xml', 'html', 'htm'}.contains(e)) return const _FileKind(Icons.article_rounded, Color(0xFF64748B), 'TXT');
  if (const {'epub', 'mobi'}.contains(e)) return const _FileKind(Icons.menu_book_rounded, Color(0xFF0EA5E9), 'BOOK');
  return const _FileKind(Icons.insert_drive_file_rounded, Color(0xFF94A3B8), 'FILE');
}

const _thumbExt = {'jpg', 'jpeg', 'png', 'gif', 'webp', 'bmp', 'heic', 'avif', 'mp4', 'm4v', 'webm', 'mkv', 'mov', '3gp', 'avi', 'ts', 'mp3', 'm4a', 'aac', 'ogg', 'opus', 'flac', 'wav', 'apk', 'pdf'};
final Map<String, Future<Uint8List?>> _thumbFut = {};

Future<Uint8List?> _thumbOf(String path, int size) => _thumbFut.putIfAbsent('$path@$size', () async {
      final r = await gecko.call<Uint8List>('thumb', {'path': path, 'size': size});
      if (r == null) _thumbFut.remove('$path@$size');
      return r;
    });

/// Native thumbnail (image / video frame / audio cover / APK icon / PDF page) with a file-type badge as fallback.
class _Thumb extends StatelessWidget {
  const _Thumb({required this.d, required this.size, this.radius = 12});
  final DownloadItem d;
  final double size, radius;

  @override
  Widget build(BuildContext context) {
    final k = _kindOf(d.name);
    final fallback = Container(
      width: size, height: size, alignment: Alignment.center,
      decoration: BoxDecoration(color: k.color, borderRadius: BorderRadius.circular(radius)),
      child: Icon(k.icon, color: Colors.white, size: size * .5),
    );
    if (d.status != 'done' || d.path == null || !_thumbExt.contains(_extOf(d.name))) return fallback;
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: SizedBox(
        width: size, height: size,
        child: FutureBuilder<Uint8List?>(
          future: _thumbOf(d.path!, (size * 3).round().clamp(96, 512)),
          builder: (_, s) => s.data == null
              ? fallback
              : Stack(fit: StackFit.expand, children: [
                  Image.memory(s.data!, fit: BoxFit.cover, gaplessPlayback: true),
                  if (k.label == 'VID') Center(child: Container(padding: const EdgeInsets.all(3), decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle), child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: size * .3))),
                ]),
        ),
      ),
    );
  }
}

Widget _dlLeading(DownloadItem d) {
  if (d.status == 'failed' || d.status == 'canceled') {
    return _badge(const Icon(Icons.error_outline_rounded, color: Colors.white, size: 24), Colors.redAccent);
  }
  if (d.status == 'running' || d.status == 'paused') {
    return _badge(Icon(d.status == 'paused' ? Icons.pause_rounded : Icons.downloading_rounded, color: Colors.white, size: 24), _kindOf(d.name).color);
  }
  return _Thumb(d: d, size: 44);
}

Widget _badge(Widget icon, Color c) => Container(
      width: 44, height: 44,
      decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(12)),
      alignment: Alignment.center,
      child: icon,
    );

class DownloadsPage extends StatefulWidget {
  const DownloadsPage({super.key});
  @override
  State<DownloadsPage> createState() => _DownloadsPageState();
}

class _DownloadsPageState extends State<DownloadsPage> {
  final Set<String> _sel = {};
  bool get _selecting => _sel.isNotEmpty;

  void _toggle(DownloadItem d) => setState(() { if (!_sel.remove(d.id)) _sel.add(d.id); });
  List<DownloadItem> _selected() => app.downloads.where((d) => _sel.contains(d.id)).toList();
  void _snack(String m) { if (mounted) snackTop(context, m); }

  Future<void> _rename(DownloadItem d) async {
    final c = TextEditingController(text: d.name);
    final dot = d.name.lastIndexOf('.');
    c.selection = TextSelection(baseOffset: 0, extentOffset: dot > 0 ? dot : d.name.length);
    final v = await showGlassDialog<String>(
      context: context,
      builder: (x) => AlertDialog(
        title: Text(tr('تغییر نام فایل', 'Rename file')),
        content: TextField(controller: c, autofocus: true, textDirection: TextDirection.ltr, onSubmitted: (t) => Navigator.pop(x, t), decoration: InputDecoration(labelText: tr('نام جدید', 'New name'))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(x), child: Text(tr('لغو', 'Cancel'))),
          TextButton(onPressed: () => Navigator.pop(x, c.text), child: Text(tr('تغییر نام', 'Rename'))),
        ],
      ),
    );
    if (v == null) return;
    final err = await dlMgr.rename(d, v);
    if (err == null) {
      if (mounted) setState(() => _sel.clear());
      return;
    }
    _snack(switch (err) {
      'invalid' => tr('نام معتبر نیست', 'Invalid name'),
      'nofile' => tr('فایل پیدا نشد؛ شاید حذف یا جابه‌جا شده', 'File not found; it may have been moved or deleted'),
      'exists' => tr('فایلی با این نام وجود دارد', 'A file with this name already exists'),
      'active' => tr('فقط فایل‌های کامل‌شده را می‌شود تغییر نام داد', 'Only finished downloads can be renamed'),
      _ => tr('تغییر نام ممکن نشد', 'Could not rename'),
    });
  }

  Future<void> _redownload(List<DownloadItem> items) async {
    final ok = items.where(dlMgr.canRedownload).toList();
    if (ok.isEmpty) { _snack(tr('این مورد را نمی‌شود دوباره دانلود کرد (پیوند اصلی در دسترس نیست)', 'This item cannot be downloaded again (original link unavailable)')); return; }
    bool? replace = false;
    if (ok.any((d) => d.status == 'done' && d.path != null)) {
      replace = await showGlassDialog<bool>(
        context: context,
        builder: (x) => AlertDialog(
          title: Text(tr('دانلود مجدد', 'Download again')),
          content: Text(ok.length == 1
              ? tr('فایل قبلی جایگزین شود یا نسخهٔ جدید کنار آن ذخیره شود؟', 'Replace the old file, or keep both?')
              : tr('${ok.length} فایل از نو دانلود می‌شوند. فایل‌های قبلی جایگزین شوند یا هر دو نگه داشته شوند؟', '${ok.length} files will be downloaded again. Replace the old files, or keep both?')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(x), child: Text(tr('لغو', 'Cancel'))),
            TextButton(onPressed: () => Navigator.pop(x, false), child: Text(tr('نگه‌داشتن هر دو', 'Keep both'))),
            TextButton(onPressed: () => Navigator.pop(x, true), child: Text(tr('جایگزینی', 'Replace'))),
          ],
        ),
      );
      if (replace == null) return;
    }
    for (final d in ok) { await dlMgr.redownload(d, replaceFile: replace == true); }
    if (!mounted) return;
    setState(() => _sel.clear());
    final skipped = items.length - ok.length;
    _snack(skipped == 0
        ? tr('دانلود دوباره شروع شد', 'Download restarted')
        : tr('${ok.length} مورد شروع شد، $skipped مورد قابل دانلود مجدد نبود', '${ok.length} started, $skipped could not be downloaded again'));
  }

  Future<void> _removeSelected({required bool files}) async {
    final items = _selected();
    if (items.isEmpty) return;
    if (files) {
      final yes = await showGlassDialog<bool>(
        context: context,
        builder: (x) => AlertDialog(
          title: Text(tr('حذف فایل‌ها؟', 'Delete files?')),
          content: Text(tr('${items.length} فایل برای همیشه از گوشی پاک می‌شود.', '${items.length} file(s) will be permanently deleted from the phone.')),
          actions: [
            TextButton(onPressed: () => Navigator.pop(x, false), child: Text(tr('لغو', 'Cancel'))),
            TextButton(onPressed: () => Navigator.pop(x, true), child: Text(tr('حذف', 'Delete'))),
          ],
        ),
      );
      if (yes != true) return;
    }
    for (final d in items) { await dlMgr.remove(d, deleteFile: files); }
    if (mounted) setState(() => _sel.clear());
  }

  PreferredSizeWidget _selectionBar() {
    final items = _selected();
    final one = items.length == 1 ? items.first : null;
    return AppBar(
      leading: IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(() => _sel.clear())),
      title: Text('${items.length} ${tr('انتخاب شده', 'selected')}'),
      actions: [
        IconButton(tooltip: tr('انتخاب همه', 'Select all'), icon: const Icon(Icons.select_all_rounded), onPressed: () => setState(() => _sel..clear()..addAll(app.downloads.map((d) => d.id)))),
        if (one != null && one.status == 'done' && one.path != null) IconButton(tooltip: tr('تغییر نام', 'Rename'), icon: const Icon(Icons.drive_file_rename_outline_rounded), onPressed: () => _rename(one)),
        IconButton(tooltip: tr('دانلود مجدد', 'Download again'), icon: const Icon(Icons.refresh_rounded), onPressed: () => _redownload(items)),
        PopupMenuButton<String>(
          onSelected: (v) => _removeSelected(files: v == 'delete'),
          itemBuilder: (_) => [
            PopupMenuItem(value: 'remove', child: Text(tr('حذف از فهرست', 'Remove from list'))),
            PopupMenuItem(value: 'delete', child: Text(tr('حذف فایل‌ها', 'Delete files'))),
          ],
        ),
      ],
    );
  }

  Widget _checkBadge(bool on, {double size = 22}) => Container(
        width: size, height: size,
        decoration: BoxDecoration(color: on ? Theme.of(context).colorScheme.primary : Colors.black45, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 1.5)),
        child: on ? Icon(Icons.check_rounded, color: Colors.white, size: size * .7) : null,
      );

  String _size(int b) {
    if (b < 1024) return '$b B';
    if (b < 1048576) return '${(b / 1024).toStringAsFixed(1)} KB';
    if (b < 1073741824) return '${(b / 1048576).toStringAsFixed(1)} MB';
    return '${(b / 1073741824).toStringAsFixed(2)} GB';
  }

  String _detail(DownloadItem d) {
    final sz = d.total > 0 ? '${_size(d.received)} / ${_size(d.total)}' : _size(d.received);
    if (d.status == 'paused') return '${tr('متوقف', 'Paused')} · $sz';
    final parts = <String>[sz];
    if (d.speed > 1) {
      parts.add('${_size(d.speed.round())}/s');
      if (d.total > 0) {
        final sec = ((d.total - d.received) / d.speed).round();
        parts.add(sec >= 3600 ? '${sec ~/ 3600}:${((sec % 3600) ~/ 60).toString().padLeft(2, '0')}:${(sec % 60).toString().padLeft(2, '0')}' : '${(sec ~/ 60)}:${(sec % 60).toString().padLeft(2, '0')}');
      }
    }
    if (d.conns > 1) parts.add('${d.conns} ${tr('اتصال', 'conn')}');
    return parts.join(' · ');
  }

  String _doneText(DownloadItem d) => d.status == 'done' ? _size(d.total > 0 ? d.total : d.received) : d.status == 'canceled' ? tr('لغو شد', 'Canceled') : tr('ناموفق', 'Failed');

  void _open(BuildContext ctx, DownloadItem d) {
    if (isPlayableFile(d.path!)) {
      Navigator.of(ctx).push(MaterialPageRoute(builder: (_) => PlayerPage(file: d.path, title: d.name)));
    } else {
      _external(ctx, d);
    }
  }

  Future<void> _external(BuildContext ctx, DownloadItem d) async {
    final r = await dlMgr.openPath(d.path!);
    if (r == 'ok' || !ctx.mounted) return;
    final msg = switch (r) {
      'nofile' => tr('فایل پیدا نشد؛ شاید حذف یا جابه‌جا شده', 'File not found; it may have been moved or deleted'),
      'nohandler' => tr('برنامه‌ای برای باز کردن این نوع فایل نصب نیست', 'No app installed can open this file type'),
      'installperm' => tr('اجازهٔ نصب برنامه را برای آبتین فعال کنید و دوباره بزنید', 'Allow Abtin to install apps, then tap again'),
      _ => tr('باز کردن فایل ممکن نشد', 'Could not open the file'),
    };
    snackTop(ctx, msg);
  }

  Widget _menu(BuildContext ctx, DownloadItem d, {Color? color}) {
    final running = d.status == 'running', paused = d.status == 'paused', active = running || paused;
    return PopupMenuButton<String>(
      iconColor: color,
      onSelected: (v) async {
        if (v == 'open' && d.path != null) _open(ctx, d);
        if (v == 'external' && d.path != null) _external(ctx, d);
        if (v == 'rename') _rename(d);
        if (v == 'redownload') _redownload([d]);
        if (v == 'select') _toggle(d);
        if (v == 'pause') dlMgr.pause(d);
        if (v == 'resume') dlMgr.resume(d);
        if (v == 'cancel') dlMgr.cancel(d);
        if (v == 'retry') dlMgr.retry(d);
        if (v == 'copy') Clipboard.setData(ClipboardData(text: d.url));
        if (v == 'remove') dlMgr.remove(d);
        if (v == 'delete') dlMgr.remove(d, deleteFile: true);
      },
      itemBuilder: (_) => [
        if (d.status == 'done') PopupMenuItem(value: 'open', child: Text(d.path != null && isPlayableFile(d.path!) ? tr('پخش', 'Play') : tr('باز کردن', 'Open'))),
        if (d.status == 'done' && d.path != null && isPlayableFile(d.path!)) PopupMenuItem(value: 'external', child: Text(tr('باز کردن با برنامهٔ دیگر', 'Open with another app'))),
        if (d.status == 'done' && d.path != null) PopupMenuItem(value: 'rename', child: Text(tr('تغییر نام', 'Rename'))),
        if (dlMgr.canRedownload(d)) PopupMenuItem(value: 'redownload', child: Text(tr('دانلود مجدد', 'Download again'))),
        PopupMenuItem(value: 'select', child: Text(tr('انتخاب', 'Select'))),
        if (d.canPause) PopupMenuItem(value: 'pause', child: Text(tr('توقف', 'Pause'))),
        if (paused) PopupMenuItem(value: 'resume', child: Text(tr('ادامه', 'Resume'))),
        if (active) PopupMenuItem(value: 'cancel', child: Text(tr('لغو', 'Cancel'))),
        if (d.status == 'failed' || d.status == 'canceled') PopupMenuItem(value: 'retry', child: Text(tr('تلاش دوباره', 'Retry'))),
        PopupMenuItem(value: 'copy', child: Text(tr('کپی لینک', 'Copy link'))),
        PopupMenuItem(value: 'remove', child: Text(tr('حذف از فهرست', 'Remove from list'))),
        if (d.status == 'done') PopupMenuItem(value: 'delete', child: Text(tr('حذف فایل', 'Delete file'))),
      ],
    );
  }

  /// Chrome-style round button: progress ring around a pause / play icon.
  Widget _ctrl(DownloadItem d, {Color? color, double size = 24}) {
    final paused = d.status == 'paused', retry = d.status == 'failed' && d.native && d.path != null;
    final canPause = d.canPause;
    if (!canPause && !paused && !retry) return const SizedBox.shrink();
    final c = color ?? Theme.of(context).colorScheme.primary;
    final box = size + 16;
    return Tooltip(
      message: canPause ? tr('توقف', 'Pause') : tr('ادامه', 'Resume'),
      child: InkResponse(
        radius: box / 2,
        onTap: () => canPause ? dlMgr.pause(d) : dlMgr.resume(d),
        child: SizedBox(
          width: box, height: box,
          child: Stack(alignment: Alignment.center, children: [
            SizedBox(width: box - 6, height: box - 6, child: CircularProgressIndicator(value: d.total > 0 ? d.fraction : (paused ? 0 : null), strokeWidth: 2.5, color: c, backgroundColor: c.withOpacity(.2))),
            Icon(canPause ? Icons.pause_rounded : Icons.play_arrow_rounded, color: c, size: size * .85),
          ]),
        ),
      ),
    );
  }

  Widget _listTile(BuildContext ctx, DownloadItem d) {
    final active = d.status == 'running' || d.status == 'paused';
    return GlassTile(
      leading: _selecting ? Stack(clipBehavior: Clip.none, children: [_dlLeading(d), Positioned(right: -6, bottom: -6, child: _checkBadge(_sel.contains(d.id)))]) : _dlLeading(d),
      title: Text(d.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: active
          ? Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SizedBox(height: 4),
              LinearProgressIndicator(value: d.total > 0 ? d.fraction : null),
              const SizedBox(height: 2),
              Text(_detail(d), style: const TextStyle(fontSize: 11)),
            ])
          : Text(_doneText(d), style: const TextStyle(fontSize: 12)),
      onTap: _selecting ? () => _toggle(d) : (d.status == 'done' && d.path != null ? () => _open(ctx, d) : null),
      onLongPress: () => _toggle(d),
      trailing: _selecting ? null : Row(mainAxisSize: MainAxisSize.min, children: [_ctrl(d), _menu(ctx, d)]),
    );
  }

  Widget _gridCard(BuildContext ctx, DownloadItem d) {
    final active = d.status == 'running' || d.status == 'paused';
    final k = _kindOf(d.name);
    final cs = Theme.of(ctx).colorScheme;
    final picked = _sel.contains(d.id);
    return Material(
      color: Theme.of(ctx).cardColor,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: BorderSide(color: picked ? cs.primary : Colors.transparent, width: 2.5)),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: _selecting ? () => _toggle(d) : (d.status == 'done' && d.path != null ? () => _open(ctx, d) : null),
        onLongPress: () => _toggle(d),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Expanded(
            child: Stack(fit: StackFit.expand, children: [
              LayoutBuilder(builder: (_, c) {
                final side = c.biggest.shortestSide;
                final bad = d.status == 'failed' || d.status == 'canceled';
                if (d.status == 'done') return _Thumb(d: d, size: side, radius: 0);
                return Container(color: bad ? Colors.redAccent : k.color, alignment: Alignment.center,
                    child: Icon(bad ? Icons.error_outline_rounded : d.status == 'paused' ? Icons.pause_rounded : k.icon, color: Colors.white, size: side * .4));
              }),
              if (_selecting) Positioned(top: 8, left: 8, child: _checkBadge(picked, size: 24)) else Positioned(
                top: 2, right: 2,
                child: Container(
                  decoration: const BoxDecoration(color: Colors.black38, shape: BoxShape.circle),
                  child: _menu(ctx, d, color: Colors.white),
                ),
              ),
              if (active) Positioned(left: 4, bottom: 4, child: Container(decoration: const BoxDecoration(color: Colors.black45, shape: BoxShape.circle), child: _ctrl(d, color: Colors.white))),
            ]),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
              Text(d.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: cs.onSurface)),
              const SizedBox(height: 3),
              if (active) ...[
                LinearProgressIndicator(value: d.total > 0 ? d.fraction : null),
                const SizedBox(height: 3),
                Text(d.speed > 1 && d.status == 'running' ? '${_size(d.speed.round())}/s' : _detail(d), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
              ] else
                Text(_doneText(d), style: const TextStyle(fontSize: 11)),
            ]),
          ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final grid = app.flag('dlGrid');
    _sel.removeWhere((id) => !app.downloads.any((d) => d.id == id));
    return PopScope(
      canPop: !_selecting,
      onPopInvoked: (didPop) { if (!didPop) setState(() => _sel.clear()); },
      child: GlassScaffold(
      appBar: _selecting ? _selectionBar() : AppBar(
        title: Text(tr('دانلودها', 'Downloads')),
        actions: [
          IconButton(
            tooltip: grid ? tr('نمایش فهرستی', 'List view') : tr('نمایش تصویر بندانگشتی', 'Thumbnail view'),
            icon: Icon(grid ? Icons.view_list_rounded : Icons.grid_view_rounded),
            onPressed: () { app.set('dlGrid', !grid); setState(() {}); },
          ),
        ],
      ),
      body: ValueListenableBuilder<int>(
        valueListenable: dlMgr.tick,
        builder: (_, __, ___) {
          final l = app.downloads;
          if (l.isEmpty) return _empty(tr('دانلودی وجود ندارد', 'No downloads'));
          if (grid) {
            return GridView.builder(
              padding: const EdgeInsets.all(12),
              gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 180, mainAxisSpacing: 10, crossAxisSpacing: 10, childAspectRatio: .82),
              itemCount: l.length,
              itemBuilder: (ctx, i) => _gridCard(ctx, l[i]),
            );
          }
          return ListView.builder(itemCount: l.length, itemBuilder: (ctx, i) => _listTile(ctx, l[i]));
        },
      ),
    ));
  }
}
