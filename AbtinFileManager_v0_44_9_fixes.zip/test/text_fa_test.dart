import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/core/text_fa.dart';

void main() {
  test('safeDecode never throws', () {
    expect(safeDecode('50% off'), isNotEmpty);
    expect(safeDecode('a%20b'), 'a b');
  });
  test('latinToPersian', () {
    expect(latinToPersian('Arezou'), 'آرزو');
    expect(latinToPersian('Siavash Ghomayshi'), 'سیاوش قمیشی');
    expect(latinToPersian('Sargozasht'), 'سرگزشت');
    expect(latinToPersian('01 Arezou'), '۰۱ آرزو');
  });
}
