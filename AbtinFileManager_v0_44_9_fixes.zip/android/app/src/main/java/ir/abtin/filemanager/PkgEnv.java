package ir.abtin.filemanager;

import java.io.File;
import java.io.IOException;

/** Prepares the private package prefix and the shell init file used by the app terminal. */
public final class PkgEnv {
    private PkgEnv() {}

    /**
     * Creates $filesDir/usr, (re)writes etc/shrc and etc/aliases.sh and returns the extra
     * environment for the PTY child ("KEY=VALUE" lines; PATH_PREPEND is handled natively).
     */
    public static String prepare(String filesDir, String apkPath, String androidAbi) throws IOException {
        return prepare(filesDir, apkPath, androidAbi, "");
    }

    /** nativeDir = ApplicationInfo.nativeLibraryDir (executable even on Android 10+; holds libproot.so if bundled). */
    public static String prepare(String filesDir, String apkPath, String androidAbi, String nativeDir) throws IOException {
        File prefix = new File(filesDir, "usr");
        PkgCli cli = new PkgCli(prefix);
        cli.ensureDirs();
        String linker = new File("/system/bin/linker64").exists() ? "/system/bin/linker64" : "/system/bin/linker";
        String p = prefix.getPath();
        String shrc =
                "# Abtin terminal init (generated at every session start; put your own settings in $PREFIX/etc/shrc.local)\n"
                        + "export PREFIX='" + p + "'\n"
                        + "export ABTIN_LINKER='" + linker + "'\n"
                        + "export ABTIN_ABI='" + androidAbi.replace("'", "'\\''") + "'\n"
                        + "export ABTIN_APK='" + apkPath.replace("'", "'\\''") + "'\n"
                        + "export ABTIN_NATIVE='" + nativeDir.replace("'", "'\\''") + "'\n"
                        + "export LD_LIBRARY_PATH=\"$PREFIX/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}\"\n"
                        + "pkg() {\n"
                        + "  CLASSPATH=\"$ABTIN_APK\" /system/bin/app_process /system/bin ir.abtin.filemanager.PkgCli \"$@\"\n"
                        + "  _pkg_rc=$?\n"
                        + "  [ -r \"$PREFIX/etc/aliases.sh\" ] && . \"$PREFIX/etc/aliases.sh\"\n"
                        + "  return $_pkg_rc\n"
                        + "}\n"
                        + "alias apt=pkg\n"
                        + "_alpine_run() {\n"
                        + "  _AR=\"$PREFIX/alpine\"\n"
                        + "  [ -f \"$_AR/etc/alpine-release\" ] || { echo 'alpine: not installed (run: alpine setup)' >&2; return 1; }\n"
                        + "  if [ -n \"$ABTIN_NATIVE\" ] && [ -x \"$ABTIN_NATIVE/libproot.so\" ]; then\n"
                        + "    _PR=\"$ABTIN_NATIVE/libproot.so\"; _PX=''\n"
                        + "    [ -x \"$ABTIN_NATIVE/libproot-loader.so\" ] && export PROOT_LOADER=\"$ABTIN_NATIVE/libproot-loader.so\"\n"
                        + "    [ -x \"$ABTIN_NATIVE/libproot-loader32.so\" ] && export PROOT_LOADER_32=\"$ABTIN_NATIVE/libproot-loader32.so\"\n"
                        + "  elif [ -f \"$PREFIX/bin/proot\" ]; then _PR=\"$PREFIX/bin/proot\"; _PX=\"$ABTIN_LINKER\"\n"
                        + "  else echo 'alpine: proot missing (run: alpine bootstrap)' >&2; return 1; fi\n"
                        + "  export PROOT_TMP_DIR=\"$PREFIX/tmp\"\n"
                        + "  [ -n \"$_PX\" ] && [ -f \"$PREFIX/libexec/proot-loader\" ] && export PROOT_LOADER=\"$PREFIX/libexec/proot-loader\"\n"
                        + "  [ -d \"$_AR/workspace\" ] || mkdir -p \"$_AR/workspace\"\n"
                        + "  $_PX \"$_PR\" --kill-on-exit --link2symlink -0 -r \"$_AR\" -b /dev -b /proc -b /sys -b \"$PWD:/workspace\" -w /workspace /usr/bin/env -i HOME=/root USER=root LANG=C.UTF-8 PIP_BREAK_SYSTEM_PACKAGES=1 TERM=\"${TERM:-xterm-256color}\" PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \"$@\"\n"
                        + "}\n"
                        + "_alpine_aliases() {\n"
                        + "  [ -f \"$PREFIX/alpine/etc/alpine-release\" ] || return 0\n"
                        + "  for _c in apk python3 python pip pip3 git node npm npx curl wget nano vim make gcc; do\n"
                        + "    for _p in /sbin /usr/bin /bin /usr/local/bin; do\n"
                        + "      if [ -e \"$PREFIX/alpine$_p/$_c\" ] || [ -L \"$PREFIX/alpine$_p/$_c\" ]; then alias \"$_c=_alpine_run $_c\"; break; fi\n"
                        + "    done\n"
                        + "  done\n"
                        + "  [ -x \"$PREFIX/alpine/usr/bin/python3\" ] && alias python='_alpine_run python3'\n"
                        + "  [ -x \"$PREFIX/alpine/usr/bin/pip3\" ] && alias pip='_alpine_run pip3'\n"
                        + "}\n"
                        + "alpine() {\n"
                        + "  case \"$1\" in\n"
                        + "    setup|status|proot|remove|doctor)\n"
                        + "      CLASSPATH=\"$ABTIN_APK\" /system/bin/app_process /system/bin ir.abtin.filemanager.AlpineCli \"$@\"\n"
                        + "      _a_rc=$?; _alpine_aliases; return $_a_rc ;;\n"
                        + "    ''|shell) _alpine_run /bin/sh -l ;;\n"
                        + "    run) shift; _alpine_run \"$@\" ;;\n"
                        + "    update) _alpine_run apk update ;;\n"
                        + "    upgrade) _alpine_run apk upgrade ;;\n"
                        + "    install|add) shift; _alpine_run apk add --no-cache \"$@\"; _a_rc=$?; _alpine_aliases; return $_a_rc ;;\n"
                        + "    uninstall|del) shift; _alpine_run apk del \"$@\"; _a_rc=$?; _alpine_aliases; return $_a_rc ;;\n"
                        + "    bootstrap)\n"
                        + "      if [ -f \"$PREFIX/alpine/.abtin-alpine\" ] && ! grep -q '^branch=v3\\.22$' \"$PREFIX/alpine/.abtin-alpine\"; then\n"
                        + "        echo 'Replacing the installed Alpine (apk v3 fails under proot) with Alpine v3.22 (apk 2)...'\n"
                        + "        alpine remove -y || return 1\n"
                        + "      fi\n"
                        + "      [ -f \"$PREFIX/alpine/etc/alpine-release\" ] || alpine setup -y || return 1\n"
                        + "      if [ ! -x \"$PREFIX/bin/proot\" ] && [ ! -x \"$ABTIN_NATIVE/libproot.so\" ]; then\n"
                        + "        _abi=\"$ABTIN_ABI\"\n"
                        + "        case \"$_abi\" in arm64-v8a) _pa=aarch64 ;; armeabi-v7a) _pa=armv7 ;; x86_64) _pa=x86_64 ;; x86) _pa=x86 ;; *) echo \"Unsupported Android ABI: $_abi\" >&2; return 1 ;; esac\n"
                        + "        alpine proot \"https://skirsten.github.io/proot-portable-android-binaries/$_pa/proot\" || return 1\n"
                        + "      fi\n"
                        + "      _alpine_run apk update && _alpine_run apk add --no-cache python3 py3-pip git nodejs npm; _a_rc=$?; _alpine_aliases; return $_a_rc ;;\n"
                        + "    *) echo 'usage: alpine [shell|run CMD|install PKG..|uninstall PKG..|update|upgrade|bootstrap|setup|proot FILE|status|remove|doctor]' >&2; return 2 ;;\n"
                        + "  esac\n"
                        + "}\n"
                        + "_abtin_need_alpine() {\n"
                        + "  _cmd=\"$1\"; shift\n"
                        + "  echo \"$_cmd: Python / Node.js is not installed yet.\" >&2\n"
                        + "  printf 'Install it now (alpine bootstrap, ~100-200 MB download)? [Y/n] ' >&2\n"
                        + "  read _ans\n"
                        + "  case \"$_ans\" in n|N|no|NO) return 1 ;; esac\n"
                        + "  alpine bootstrap || return 1\n"
                        + "  _alpine_run \"$_cmd\" \"$@\"\n"
                        + "}\n"
                        + "python() { _abtin_need_alpine python3 \"$@\"; }\n"
                        + "python3() { _abtin_need_alpine python3 \"$@\"; }\n"
                        + "pip() { _abtin_need_alpine pip3 \"$@\"; }\n"
                        + "pip3() { _abtin_need_alpine pip3 \"$@\"; }\n"
                        + "node() { _abtin_need_alpine node \"$@\"; }\n"
                        + "npm() { _abtin_need_alpine npm \"$@\"; }\n"
                        + "npx() { _abtin_need_alpine npx \"$@\"; }\n"
                        + "alias ll='ls -lA'\n"
                        + "[ -r \"$PREFIX/etc/aliases.sh\" ] && . \"$PREFIX/etc/aliases.sh\"\n"
                        + "_alpine_aliases\n"
                        + "[ -r \"$PREFIX/etc/shrc.local\" ] && . \"$PREFIX/etc/shrc.local\"\n";
        PkgCli.writeText(new File(prefix, "etc/shrc"), shrc);
        cli.regenAliases(java.util.Collections.<String>emptySet());
        String ld = System.getenv("LD_LIBRARY_PATH");
        StringBuilder env = new StringBuilder();
        env.append("PREFIX=").append(p).append('\n');
        env.append("ENV=").append(p).append("/etc/shrc\n");
        env.append("ABTIN_APK=").append(apkPath).append('\n');
        env.append("ABTIN_ABI=").append(androidAbi).append('\n');
        env.append("ABTIN_LINKER=").append(linker).append('\n');
        env.append("LD_LIBRARY_PATH=").append(p).append("/lib").append(ld == null || ld.isEmpty() ? "" : ":" + ld).append('\n');
        env.append("PATH_PREPEND=").append(p).append("/bin\n");
        return env.toString();
    }
}
