/// Text helpers for Persian display.

/// Like [Uri.decodeFull] but never throws (file names such as "50% off" contain an
/// invalid escape and made the queue row crash, which showed up as a grey gap).
String safeDecode(String s) {
  try {
    return Uri.decodeFull(s);
  } catch (_) {
    try {
      return Uri.decodeComponent(s);
    } catch (_) {
      return s;
    }
  }
}

const _faDigits = '۰۱۲۳۴۵۶۷۸۹';

bool hasPersian(String t) => RegExp(r'[\u0600-\u06FF]').hasMatch(t);
bool hasLatin(String t) => RegExp(r'[A-Za-z]').hasMatch(t);

String toPersianDigits(String s) => s.replaceAllMapped(
    RegExp(r'[0-9]'), (m) => _faDigits[int.parse(m[0]!)]);

/// Best-effort Latin ("Finglish") -> Persian transliteration, e.g.
/// "Arezou" -> "آرزو", "Siavash Ghomayshi" -> "سیاوش قمیشی".
/// It is an approximation: short vowels are not written in Persian, so some names
/// will need a manual edit (long-press the cassette).
String latinToPersian(String input) {
  final words = RegExp(r"[A-Za-z']+|[^A-Za-z']+");
  final b = StringBuffer();
  for (final m in words.allMatches(input)) {
    final w = m[0]!;
    if (RegExp(r'^[A-Za-z]').hasMatch(w)) {
      b.write(_word(w.toLowerCase()));
    } else {
      b.write(toPersianDigits(w).replaceAll('-', '–'));
    }
  }
  return b.toString().trim();
}

String _word(String w) {
  w = w.replaceAll("'", '');
  const vowels = 'aeiou';
  bool isV(int i) => i >= 0 && i < w.length && vowels.contains(w[i]);
  final out = StringBuffer();
  var i = 0;
  while (i < w.length) {
    final c = w[i];
    final two = i + 1 < w.length ? w.substring(i, i + 2) : '';
    final first = i == 0;
    final last = i == w.length - 1;
    String? digraph;
    switch (two) {
      case 'kh': digraph = 'خ'; break;
      case 'sh': digraph = 'ش'; break;
      case 'ch': digraph = 'چ'; break;
      case 'gh': digraph = 'ق'; break;
      case 'zh': digraph = 'ژ'; break;
      case 'ou': case 'oo': digraph = 'و'; break;
      case 'ee': case 'ii': digraph = 'ی'; break;
      case 'aa': digraph = first ? 'آ' : 'ا'; break;
      case 'ei': case 'ey': digraph = 'ی'; break;
    }
    if (digraph != null) {
      out.write(digraph);
      i += 2;
      continue;
    }
    switch (c) {
      case 'a':
        if (first) {
          out.write('آ');
        } else if (last || isV(i - 1)) {
          out.write('ا');
        }
        break;
      case 'e':
        if (first) {
          out.write('ا');
        } else if (last) {
          out.write('ه');
        }
        break;
      case 'o':
        if (first) {
          out.write('ا');
        } else if (last || isV(i - 1)) {
          out.write('و');
        }
        break;
      case 'i':
        out.write(first ? 'ای' : 'ی');
        break;
      case 'u': out.write('و'); break;
      case 'b': out.write('ب'); break;
      case 'p': out.write('پ'); break;
      case 't': out.write('ت'); break;
      case 'j': out.write('ج'); break;
      case 'd': out.write('د'); break;
      case 'r': out.write('ر'); break;
      case 'z': out.write('ز'); break;
      case 's': out.write('س'); break;
      case 'f': out.write('ف'); break;
      case 'k': case 'c': out.write('ک'); break;
      case 'g': out.write('گ'); break;
      case 'l': out.write('ل'); break;
      case 'm': out.write('م'); break;
      case 'n': out.write('ن'); break;
      case 'v': case 'w': out.write('و'); break;
      case 'h': out.write('ه'); break;
      case 'y': out.write('ی'); break;
      case 'q': out.write('ق'); break;
      case 'x': out.write('کس'); break;
    }
    i++;
  }
  return out.toString();
}
