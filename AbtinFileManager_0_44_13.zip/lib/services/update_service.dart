import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'archive_service.dart';
import 'file_ops.dart' show OpError;
import 'native.dart';

/// A GitHub release that carries an installable build.
class UpdateInfo {
  final String tag;
  final String name;
  final String notes;
  final String assetName;
  final String assetUrl;
  final int assetSize;
  final DateTime assetTime;
  const UpdateInfo(this.tag, this.name, this.notes, this.assetName, this.assetUrl, this.assetSize, this.assetTime);
}

/// Checks https://github.com/abtin1238/make-apk/releases. Only the asset NAME and the version in it
/// of it matter (AbtinFileManager_0_44_12.zip -> 0.44.12; a .zip wrapping the APK or a plain .apk).
/// The release tag, the build number (versionCode) and upload times are ignored: an update is offered
/// when the highest version found in the asset names is greater than this app's versionName.
class _Cand {
  final Map<String, dynamic> r, a;
  final List<int> v;
  final String label;
  const _Cand(this.r, this.a, this.v, this.label);
}

class UpdateService {
  static const repo = 'abtin1238/make-apk';
  static const releasesPage = 'https://github.com/$repo/releases';
  static const _kAuto = 'upd_auto';
  static const _kLast = 'upd_last_check';
  static const _kSkip = 'upd_skip_tag';

  static Future<bool> autoEnabled() async => (await SharedPreferences.getInstance()).getBool(_kAuto) ?? true;
  static Future<void> setAuto(bool v) async => (await SharedPreferences.getInstance()).setBool(_kAuto, v);

  /// true at most once per [every] on app start, when the user has not switched it off.
  static Future<bool> dueForAutoCheck({Duration every = const Duration(hours: 6)}) async {
    final sp = await SharedPreferences.getInstance();
    if (!(sp.getBool(_kAuto) ?? true)) return false;
    final last = sp.getInt(_kLast) ?? 0;
    return DateTime.now().millisecondsSinceEpoch - last >= every.inMilliseconds;
  }

  static Future<void> skip(String tag) async => (await SharedPreferences.getInstance()).setString(_kSkip, tag);

  static Future<String> currentVersion() async {
    final i = await Native.selfInfo();
    return i == null ? '' : '${i['versionName']} (${i['versionCode']})';
  }

  static bool _isApk(String n) => n.toLowerCase().endsWith('.apk');
  static bool _isZip(String n) => n.toLowerCase().endsWith('.zip');

  /// Best APK among [names]: arm64 first (modern phones), then universal / release, then anything.
  static String? pickApk(List<String> names) {
    final apks = names.where(_isApk).toList();
    if (apks.isEmpty) return null;
    int score(String n) {
      final l = n.toLowerCase();
      var s = 0;
      if (l.contains('arm64') || l.contains('v8a')) s += 8;
      if (l.contains('universal') || l.contains('fat')) s += 4;
      if (l.contains('release')) s += 2;
      if (l.contains('debug')) s -= 3;
      if (l.contains('x86') || l.contains('armeabi') || l.contains('v7a')) s -= 6;
      return s;
    }
    apks.sort((a, b) => score(b).compareTo(score(a)));
    return apks.first;
  }

  static final _nameRx = RegExp(r'^AbtinFileManager.*\.(zip|apk)$', caseSensitive: false);

  // CPU-architecture / build tokens that contain digits and must never be read as a version
  // (x86_64 used to be read as "86.64", which beat 0.44.12 and offered a bogus update).
  static final _abiRx = RegExp(
      r'(x86[_-]?64|x86|arm64[_-]?v8a|armeabi[_-]?v7a|armeabi|arm64|armv7|v8a|v7a|aarch64|win64|win32|64[_-]?bit|32[_-]?bit|build[_-]?\d+|run[_-]?\d+|r\d+)',
      caseSensitive: false);

  /// Version in an asset name: AbtinFileManager_0_44_12.zip -> "0.44.12", AbtinFileManager_0_44_12_x86_64.zip
  /// -> "0.44.12". Needs at least two numeric parts (major.minor); the part with the most numbers wins,
  /// ties go to the first one. null when the name carries no version.
  static String? versionOfAsset(String name) {
    if (!_nameRx.hasMatch(name)) return null;
    var n = name.replaceFirst(RegExp(r'\.(zip|apk)$', caseSensitive: false), '');
    n = n.replaceFirst(RegExp(r'^AbtinFileManager', caseSensitive: false), '');
    n = n.replaceAll(_abiRx, '_');
    String? best;
    var bestParts = 0;
    for (final m in RegExp(r'\d+(?:[._]\d+)+').allMatches(n)) {
      final parts = RegExp(r'\d+').allMatches(m[0]!).length;
      if (parts > bestParts) {
        best = m[0]!.replaceAll('_', '.');
        bestParts = parts;
      }
    }
    return best;
  }

  static List<int> _ver(String v) => [for (final m in RegExp(r'\d+').allMatches(v)) int.parse(m[0]!)];

  static int _cmp(List<int> a, List<int> b) {
    for (var i = 0; i < (a.length > b.length ? a.length : b.length); i++) {
      final d = (i < a.length ? a[i] : 0).compareTo(i < b.length ? b[i] : 0);
      if (d != 0) return d;
    }
    return 0;
  }

  /// Among assets of the same version: arm64 first, then universal / release, then anything.
  static Map<String, dynamic> _pickAsset(List<Map<String, dynamic>> ok) {
    int score(Map a) {
      final n = '${a['name']}'.toLowerCase();
      var s = _isApk(n) ? 1 : 0;
      if (n.contains('arm64') || n.contains('v8a')) s += 8;
      if (n.contains('universal') || n.contains('fat')) s += 4;
      if (n.contains('release')) s += 2;
      if (n.contains('x86') || n.contains('armeabi') || n.contains('v7a')) s -= 6;
      if (n.contains('debug')) s -= 3;
      return s;
    }
    final l = [...ok]..sort((a, b) => score(b).compareTo(score(a)));
    return l.first;
  }

  static Future<dynamic> _getJson(String url) async {
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 15);
    try {
      final rq = await c.getUrl(Uri.parse(url));
      rq.headers.set('Accept', 'application/vnd.github+json');
      rq.headers.set('User-Agent', 'AbtinFileManager');
      final rs = await rq.close().timeout(const Duration(seconds: 25));
      final body = await rs.transform(utf8.decoder).join();
      if (rs.statusCode != 200) throw OpError('updFailed', 'HTTP ${rs.statusCode}');
      return jsonDecode(body);
    } finally {
      c.close(force: true);
    }
  }

  /// Highest AbtinFileManager_<version>.zip over the recent releases. Returns null when this app is
  /// already at that version or newer. [force] ignores a version the user chose to skip.
  static Future<UpdateInfo?> check({bool force = false}) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setInt(_kLast, DateTime.now().millisecondsSinceEpoch);
    final data = await _getJson('https://api.github.com/repos/$repo/releases?per_page=30');
    if (data is! List) throw const OpError('updFailed');
    final me = await Native.selfInfo();
    final local = _ver('${me?['versionName'] ?? ''}');
    if (local.isEmpty) return null;
    final cands = <_Cand>[];
    for (final r in data) {
      if (r is! Map || r['draft'] == true) continue;
      for (final a in (r['assets'] as List?) ?? const []) {
        if (a is! Map || a['state'] == 'starter') continue;
        final label = versionOfAsset('${a['name']}');
        if (label == null) continue;
        cands.add(_Cand(Map<String, dynamic>.from(r), Map<String, dynamic>.from(a), _ver(label), label));
      }
    }
    if (cands.isEmpty) return null;
    var best = cands.first.v;
    for (final c in cands) {
      if (_cmp(c.v, best) > 0) best = c.v;
    }
    if (_cmp(best, local) <= 0) return null; // installed version is already the newest
    final top = [for (final c in cands) if (_cmp(c.v, best) == 0) c];
    final pickA = _pickAsset([for (final c in top) c.a]);
    final c = top.firstWhere((x) => identical(x.a, pickA));
    if (!force && sp.getString(_kSkip) == c.label) return null;
    final t = DateTime.tryParse('${c.a['updated_at'] ?? c.a['created_at']}')?.toUtc() ?? DateTime.fromMillisecondsSinceEpoch(0, isUtc: true);
    return UpdateInfo(c.label, c.label, '${c.r['body'] ?? ''}', '${c.a['name']}', '${c.a['browser_download_url']}', (c.a['size'] as num?)?.toInt() ?? 0, t);
  }

  /// Downloads the asset (following GitHub's redirect) and returns the path of the APK to install.
  static Future<String> download(UpdateInfo u, void Function(double?) onProgress) async {
    final tmp = await getTemporaryDirectory();
    final dir = Directory(p.join(tmp.path, 'abtin_update'));
    if (dir.existsSync()) dir.deleteSync(recursive: true);
    dir.createSync(recursive: true);
    final file = File(p.join(dir.path, u.assetName));
    final c = HttpClient()..connectionTimeout = const Duration(seconds: 20);
    try {
      var uri = Uri.parse(u.assetUrl);
      HttpClientResponse? rs;
      for (var hop = 0; hop < 6; hop++) {
        final rq = await c.getUrl(uri);
        rq.followRedirects = false;
        rq.headers.set('User-Agent', 'AbtinFileManager');
        rs = await rq.close();
        if (rs.isRedirect) {
          final loc = rs.headers.value(HttpHeaders.locationHeader);
          await rs.drain<void>();
          if (loc == null) throw const OpError('updFailed');
          uri = uri.resolve(loc);
          continue;
        }
        break;
      }
      if (rs == null || rs.statusCode != 200) throw OpError('updFailed', 'HTTP ${rs?.statusCode}');
      final total = rs.contentLength > 0 ? rs.contentLength : u.assetSize;
      final sink = file.openWrite();
      var got = 0;
      try {
        await for (final chunk in rs) {
          sink.add(chunk);
          got += chunk.length;
          onProgress(total > 0 ? (got / total).clamp(0.0, 1.0) : null);
        }
      } finally {
        await sink.close();
      }
    } finally {
      c.close(force: true);
    }
    if (_isApk(file.path)) return file.path;
    // a zip that wraps the APK(s): unpack only the best one
    final list = await ArchiveService.list(file.path);
    final pick = pickApk([for (final e in list) if (!e.dir) e.name]);
    if (pick == null) throw const OpError('updNoApk');
    final out = Directory(p.join(dir.path, 'apk'));
    await ArchiveService.extract(file.path, out.path, only: [pick]);
    final apk = File(p.join(out.path, ArchiveService.normName(pick)));
    if (!apk.existsSync()) throw const OpError('updNoApk');
    return apk.path;
  }
}
