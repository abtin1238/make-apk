import 'package:flutter/material.dart';
import '../widgets/abtin_global_rail.dart';
import 'package:open_filex/open_filex.dart';
import 'package:provider/provider.dart';
import '../core/settings.dart';
import '../services/file_ops.dart';
import '../services/player_service.dart';
import '../widgets/ui.dart';
import 'apk_info_screen.dart';
import 'bundle_install_screen.dart';
import 'archive_dialog.dart';
import 'audio_player_screen.dart';
import 'image_viewer_screen.dart';
import 'text_editor_screen.dart';
import 'doc_legacy_screen.dart';
import 'docx_editor_screen.dart';
import 'office_screens.dart';
import 'pdf_viewer_screen.dart';
import 'video_player_screen.dart';

class Opener {
  /// [siblings] = list of file paths in same view (used for playlists/galleries).
  static Future<void> open(BuildContext c, String path,
      {List<String>? siblings, VoidCallback? onChanged}) async {
    context_(c).addRecent(path);
    final cat = FileOps.catOf(path);
    final sib = siblings ?? [path];
    // Opener.open now completes when the opened screen is closed (so callers can refresh right away).
    Future<void>? closed;
    void push(Widget w, {bool hideRail = false}) =>
        closed = Navigator.push(c, abtinPageRoute((_) => w, hideRail: hideRail))
            .then((_) => onChanged?.call());
    final e = FileOps.ext(path);
    if (e == 'pdf') {
      push(PdfViewerScreen(path: path));
    } else if (e == 'apk') {
      push(ApkInfoScreen(path: path));
    } else if (const {'xapk', 'apks', 'apkm'}.contains(e)) {
      push(BundleInstallScreen(path: path));
    } else if (e == 'doc') {
      push(DocLegacyScreen(path: path), hideRail: true);
    } else if (const {'docx', 'docm', 'dotx', 'dotm'}.contains(e)) {
      push(DocxEditorScreen(path: path), hideRail: true);
    } else if (e == 'xlsx' || e == 'xlsm') {
      push(XlsxScreen(path: path), hideRail: true);
    } else if (e == 'pptx' || e == 'ppsx' || e == 'pptm') {
      push(PptxScreen(path: path), hideRail: true);
    } else if (e == 'xls') {
      push(XlsScreen(path: path));
    } else if (e == 'ppt') {
      push(PptScreen(path: path));
    } else if (e == 'ods') {
      push(OdsScreen(path: path));
    } else if (e == 'odp') {
      push(OdpScreen(path: path));
    } else if (e == 'odt') {
      push(OdtScreen(path: path));
    } else if (e == 'rtf') {
      push(RtfScreen(path: path));
    } else if (cat == Cat.audio) {
      final list = sib.where((e) => FileOps.isCat(e, Cat.audio)).toList();
      await Provider.of<PlayerService>(c, listen: false)
          .playList(list, list.indexOf(path).clamp(0, list.length - 1));
      push(const AudioPlayerScreen(), hideRail: true);
    } else if (cat == Cat.videos) {
      final list = sib.where((e) => FileOps.isCat(e, Cat.videos)).toList();
      push(
          VideoPlayerScreen(
              paths: list, index: list.indexOf(path).clamp(0, list.length - 1)),
          hideRail: true);
    } else if (cat == Cat.images && FileOps.ext(path) != 'svg') {
      final list = sib.where((e) => FileOps.isCat(e, Cat.images)).toList();
      push(ImageViewerScreen(
          paths: list, index: list.indexOf(path).clamp(0, list.length - 1)));
    } else if (cat == Cat.archives &&
        !path.toLowerCase().endsWith('.apk') &&
        !path.toLowerCase().endsWith('.epub')) {
      await showArchiveDialog(c, path, onChanged);
    } else if (FileOps.isText(path)) {
      push(TextEditorScreen(path: path), hideRail: true);
    } else {
      final r = await OpenFilex.open(path);
      if (r.type != ResultType.done && c.mounted) {
        snack(c, r.message);
      }
    }
    if (closed != null) await closed;
  }

  static AppSettings context_(BuildContext c) =>
      Provider.of<AppSettings>(c, listen: false);
}
