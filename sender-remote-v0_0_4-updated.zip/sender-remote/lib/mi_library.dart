import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'ir.dart';
import 'theme.dart';

/// کتابخانه‌ی کدهای IR برگرفته از دیتابیس Mi Remote (پروژه‌ی mi_remote_database، AGPL-3.0).
/// داده‌ها به‌صورت فشرده در assets/mi_ir_db.gz هستند؛ هر برند یک خط JSON است و فقط همان لحظه خوانده می‌شود.

const List<MapEntry<String, String>> kMiDevices = [
  MapEntry('tv', 'TV'),
  MapEntry('stb', 'Set-top box'),
  MapEntry('box', 'Android Box'),
  MapEntry('av', 'A/V receiver'),
  MapEntry('dvd', 'DVD'),
  MapEntry('proj', 'Projector'),
  MapEntry('cable', 'Cable / Sat'),
];

/// کلید دکمه‌ی اپ ← نام‌های Mi به ترتیب اولویت
const Map<String, List<String>> _appToMi = {
  'POWER': ['power'],
  'POWER_ON': ['power'],
  'MUTE': ['mute'],
  'HOME': ['home'],
  'BACK': ['back'],
  'RECENTS': ['menu'],
  'QUICK_SETTINGS': ['set'],
  'NOTIFICATIONS': ['tv_av', 'AV'],
  'INPUT': ['input', 'source', 'tv_av', 'AV'],
  'TV_SAT': ['tv_sat', 'tv/sat', 'sat'],
  'TV_RADIO': ['tv_radio', 'tv/radio', 'tv', 'radio'],
  'P_MODE': ['picture_mode', 'p_mode', 'pic_mode', 'picture'],
  'S_MODE': ['sound_mode', 's_mode', 'audio_mode', 'sound'],
  'ZOOM': ['zoom', 'aspect'],
  'T_SHIFT': ['t_shift', 'timeshift', 'time_shift'],
  'EXIT': ['exit'],
  'MEDIA': ['media', 'source'],
  'SLEEP': ['sleep', 'sleep_timer'],
  'FREEZE': ['freeze', 'still'],
  'REC_LIST': ['rec_list', 'record_list', 'recordings'],
  'SUBTITLE': ['subtitle', 'subtitles', 'sub'],
  'AUDIO': ['audio', 'sap', 'audio_track'],
  'FAV': ['fav', 'favorite', 'favorites'],
  'LIST': ['list', 'channel_list'],
  'REWIND': ['rewind', 'rew', 'reverse'],
  'STOP': ['stop'],
  'PAUSE': ['pause'],
  'RECORD': ['record', 'rec'],
  'FAST_FORWARD': ['fast_forward', 'ff', 'forward'],
  'UP': ['up'],
  'DOWN': ['down'],
  'LEFT': ['left'],
  'RIGHT': ['right'],
  'ENTER': ['ok', 'enter', 'sel'],
  'VOL_UP': ['vol+'],
  'VOL_DOWN': ['vol-'],
  'CH_UP': ['ch+'],
  'CH_DOWN': ['ch-'],
  'PLAY_PAUSE': ['play', 'play_pause'],
  'PREV': ['previous'],
  'NEXT': ['next'],
  'RED': ['red'],
  'GREEN': ['green'],
  'YELLOW': ['yellow'],
  'BLUE': ['blue'],
  'INFO': ['info', 'display'],
  'TEXT': ['teletext'],
  'EPG': ['guide'],
  '0': ['0'],
  '1': ['1'],
  '2': ['2'],
  '3': ['3'],
  '4': ['4'],
  '5': ['5'],
  '6': ['6'],
  '7': ['7'],
  '8': ['8'],
  '9': ['9'],
};

class MiBrand {
  final String name;
  final int line;
  final int sets;
  const MiBrand(this.name, this.line, this.sets);
}

/// یک مجموعه‌کد (مثل یک «پروفایل» داخل Mi Remote)
class MiSet {
  /// نام دکمه در Mi ← کد
  final Map<String, IrCode> byName;
  const MiSet(this.byName);

  IrCode? get power => byName['power'];

  /// کلید(های) پروفایل اپ برای دکمه‌ی Mi با نام [name] (همان منطق toProfileCodes).
  List<String> appKeysFor(String name) {
    final out = <String>[];
    for (final e in _appToMi.entries) {
      final first = e.value.firstWhere(byName.containsKey, orElse: () => '');
      if (first == name) out.add(e.key);
    }
    return out.isEmpty ? ['x:$name'] : out;
  }

  /// تبدیل به کدهای پروفایل اپ: دکمه‌های هم‌نام + بقیه‌ی دکمه‌ها با پیشوند x:
  Map<String, IrCode> toProfileCodes() {
    final out = <String, IrCode>{};
    final used = <String>{};
    for (final e in _appToMi.entries) {
      for (final n in e.value) {
        final c = byName[n];
        if (c != null) {
          out[e.key] = c;
          used.add(n);
          break;
        }
      }
    }
    for (final e in byName.entries) {
      if (!used.contains(e.key)) out['x:${e.key}'] = e.value;
    }
    return out;
  }
}

List<Object> _unpack(Uint8List gz) {
  final raw = gzip.decode(gz);
  final bytes = raw is Uint8List ? raw : Uint8List.fromList(raw);
  final starts = <int>[0];
  for (var i = 0; i < bytes.length; i++) {
    if (bytes[i] == 10) starts.add(i + 1);
  }
  return [bytes, Int32List.fromList(starts)];
}

class MiDb {
  static final MiDb instance = MiDb._();
  MiDb._();

  Uint8List? _bytes;
  Int32List _starts = Int32List(0);
  final Map<String, List<MiBrand>> index = {};
  Future<void>? _loading;

  Future<void> load() => _loading ??= _load();

  Future<void> _load() async {
    final data = await rootBundle.load('assets/mi_ir_db.gz');
    final res = await compute(_unpack, data.buffer.asUint8List(data.offsetInBytes, data.lengthInBytes));
    _bytes = res[0] as Uint8List;
    _starts = res[1] as Int32List;
    final head = jsonDecode(utf8.decode(Uint8List.sublistView(_bytes!, 0, _starts[1] - 1))) as Map;
    index.clear();
    for (final e in head.entries) {
      index[e.key as String] = [
        for (final b in (e.value as List)) MiBrand(b[0] as String, b[1] as int, b[2] as int),
      ];
    }
  }

  /// حافظه را آزاد می‌کند (با بستن پنجره).
  void release() {
    _bytes = null;
    _starts = Int32List(0);
    index.clear();
    _loading = null;
  }

  List<MiSet> sets(MiBrand b) {
    final bytes = _bytes;
    if (bytes == null) return const [];
    final s = _starts[b.line];
    final e = (b.line + 1 < _starts.length) ? _starts[b.line + 1] - 1 : bytes.length;
    final j = jsonDecode(utf8.decode(Uint8List.sublistView(bytes, s, e))) as Map;
    final pats = j['p'] as List;
    List<int> pat(int i) {
      final p = pats[i] as List;
      return [for (var k = 1; k < p.length; k++) (p[k] as int) * 10];
    }

    IrCode code(Object ref) {
      if (ref is List) {
        final i = ref[0] as int;
        return IrCode('raw', 0, 0, raw: pat(i), rawAlt: pat(ref[1] as int), rawFreq: (pats[i] as List)[0] as int);
      }
      final i = ref as int;
      return IrCode('raw', 0, 0, raw: pat(i), rawFreq: (pats[i] as List)[0] as int);
    }

    return [
      for (final m in (j['s'] as List)) MiSet({for (final e in (m as Map).entries) e.key as String: code(e.value as Object)}),
    ];
  }
}

Future<void> showMiLibrary(BuildContext context, IrController ir) {
  return showDialog<void>(
    context: context,
    builder: (_) => Dialog(
      backgroundColor: const Color(0xff0c1124),
      insetPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: kBlue.withOpacity(0.6)),
      ),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 560, maxHeight: MediaQuery.of(context).size.height * 0.85),
        child: Padding(padding: const EdgeInsets.all(14), child: MiLibraryPanel(ir: ir)),
      ),
    ),
  ).whenComplete(MiDb.instance.release);
}

class MiLibraryPanel extends StatefulWidget {
  final IrController ir;
  const MiLibraryPanel({super.key, required this.ir});
  @override
  State<MiLibraryPanel> createState() => _MiLibraryPanelState();
}

class _MiLibraryPanelState extends State<MiLibraryPanel> {
  String dev = 'tv';
  String query = '';
  bool loading = true;
  String? error;

  MiBrand? brand;
  List<MiSet> sets = const [];
  int n = 0;
  String note = '';
  String target = 'power';
  String appTarget = 'POWER';
  bool appTargetChosen = false;
  bool running = false;
  double interval = 600;
  final Set<String> _saved = {};

  @override
  void dispose() {
    running = false;
    super.dispose();
  }

  IrController get ir => widget.ir;

  @override
  void initState() {
    super.initState();
    MiDb.instance.load().then((_) {
      if (mounted) setState(() => loading = false);
    }).catchError((Object e) {
      if (mounted) {
        setState(() {
          loading = false;
          error = 'خواندن کتابخانه ناموفق بود: $e';
        });
      }
    });
  }

  void _open(MiBrand b) {
    final s = MiDb.instance.sets(b);
    setState(() {
      brand = b;
      sets = s;
      n = 0;
      note = '';
      target = 'power';
      appTarget = 'POWER';
      appTargetChosen = false;
      running = false;
      _saved.clear();
    });
  }

  Future<void> _send(IrCode? c) async {
    if (c == null) return;
    if (!ir.hasEmitter) {
      setState(() => note = 'این گوشی فرستنده‌ی IR ندارد');
      return;
    }
    await ir.sendCode(c);
  }

  Future<void> _save() async {
    final b = brand;
    if (b == null || sets.isEmpty) return;
    final ctl = TextEditingController(text: '${b.name} ${n + 1}');
    final name = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xff0c1124),
        title: const Text('نام پروفایل', style: TextStyle(fontSize: 15)),
        content: TextField(controller: ctl, autofocus: true),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('لغو')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(ctl.text), child: const Text('ذخیره')),
        ],
      ),
    );
    if (name == null) return;
    ir.addMiProfile(name.trim().isEmpty ? '${b.name} ${n + 1}' : name.trim(), sets[n].toProfileCodes());
    if (mounted) Navigator.of(context).pop();
    irMessengerKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(const SnackBar(content: Text('پروفایل ساخته و فعال شد؛ هر دکمه را می‌توانید جداگانه تست و تنظیم کنید.')));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const SizedBox(height: 160, child: Center(child: CircularProgressIndicator()));
    }
    if (error != null) {
      return Column(mainAxisSize: MainAxisSize.min, children: [
        Text(error!, style: const TextStyle(color: Color(0xffffa23c))),
        TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('بستن')),
      ]);
    }
    return brand == null ? _brandList() : _setsPage();
  }

  Widget _brandList() {
    final all = MiDb.instance.index[dev] ?? const <MiBrand>[];
    final q = query.trim().toLowerCase();
    final list = q.isEmpty ? all : all.where((b) => b.name.toLowerCase().contains(q)).toList();
    return Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Text('کتابخانه‌ی کدهای Mi Remote',
          textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      Wrap(spacing: 6, runSpacing: 4, alignment: WrapAlignment.center, children: [
        for (final d in kMiDevices)
          ChoiceChip(
            label: Text(d.value, style: const TextStyle(fontSize: 12)),
            selected: dev == d.key,
            onSelected: (_) => setState(() => dev = d.key),
          ),
      ]),
      const SizedBox(height: 6),
      TextField(
        decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'نام برند (مثلاً philips)'),
        onChanged: (v) => setState(() => query = v),
      ),
      const SizedBox(height: 4),
      Text('${list.length} برند', style: const TextStyle(fontSize: 11, color: kHint), textAlign: TextAlign.center),
      Flexible(
        child: ListView.builder(
          shrinkWrap: true,
          itemCount: list.length,
          itemBuilder: (_, i) => ListTile(
            dense: true,
            title: Text(list[i].name),
            trailing: Text('${list[i].sets} مجموعه', style: const TextStyle(fontSize: 11, color: kHint)),
            onTap: () => _open(list[i]),
          ),
        ),
      ),
      TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('بستن')),
    ]);
  }

  static const _tests = <MapEntry<String, String>>[
    MapEntry('vol+', 'صدا +'),
    MapEntry('vol-', 'صدا −'),
    MapEntry('ch+', 'کانال +'),
    MapEntry('ch-', 'کانال −'),
    MapEntry('mute', 'بی‌صدا'),
    MapEntry('up', 'بالا'),
    MapEntry('down', 'پایین'),
    MapEntry('left', 'چپ'),
    MapEntry('right', 'راست'),
    MapEntry('ok', 'OK'),
    MapEntry('enter', 'Enter'),
    MapEntry('menu', 'منو'),
    MapEntry('tv_av', 'ورودی'),
    MapEntry('input', 'Input'),
    MapEntry('source', 'Source'),
    MapEntry('back', 'برگشت'),
    MapEntry('home', 'خانه'),
    MapEntry('zoom', 'ZOOM'),
    MapEntry('sleep', 'SLEEP'),
    MapEntry('freeze', 'FREEZE'),
    MapEntry('record', 'ضبط'),
    MapEntry('rec', 'ضبط'),
    MapEntry('stop', 'توقف'),
    MapEntry('pause', 'مکث'),
    MapEntry('rewind', 'عقب‌بردن'),
    MapEntry('rew', 'عقب‌بردن'),
    MapEntry('fast_forward', 'جلو‌بردن'),
    MapEntry('subtitle', 'زیرنویس'),
    MapEntry('audio', 'صدا / SAP'),
    MapEntry('fav', 'FAV'),
    MapEntry('list', 'LIST'),
    MapEntry('tv_radio', 'TV / RADIO'),
    MapEntry('tv_sat', 'TV / SAT'),
    MapEntry('rec_list', 'REC LIST'),
    MapEntry('t_shift', 'T.SHIFT'),
  ];

  String _labelFor(String k) {
    if (k == 'power') return 'پاور';
    for (final t in _tests) {
      if (t.key == k) return t.value;
    }
    return k;
  }

  /// همه‌ی دکمه‌ها: اول دکمه‌های شناخته‌شده، بعد بقیه (عددها، رنگی‌ها، ...) به ترتیب نام.
  List<String> _allKeys() {
    final seen = <String>{};
    for (final m in sets) {
      seen.addAll(m.byName.keys);
    }
    final known = [for (final t in _tests) if (seen.contains(t.key)) t.key];
    final rest = seen.where((k) => !known.contains(k) && k != 'power').toList()..sort();
    return [...known, ...rest];
  }

  IrCode? _codeOf(int i) => (i < 0 || i >= sets.length) ? null : sets[i].byName[target];

  /// نزدیک‌ترین مجموعه‌ی بعدی/قبلی که این دکمه را دارد (-1 اگر نبود)
  int _nextWith(int from, int d) {
    for (var i = from + d; i >= 0 && i < sets.length; i += d) {
      if (sets[i].byName.containsKey(target)) return i;
    }
    return -1;
  }

  int get _countWith => sets.where((m) => m.byName.containsKey(target)).length;
  int get _posWith => sets.take(n + 1).where((m) => m.byName.containsKey(target)).length;

  String? _suggestAppKey(String miKey) {
    for (final e in _appToMi.entries) {
      if (e.value.contains(miKey)) return e.key;
    }
    return null;
  }

  String? _suggestMiKey(String appKey) {
    final candidates = _appToMi[appKey] ?? const <String>[];
    for (final candidate in candidates) {
      if (sets.any((s) => s.byName.containsKey(candidate))) return candidate;
    }
    return null;
  }

  void _pick(String k) {
    final first = sets.indexWhere((m) => m.byName.containsKey(k));
    final suggested = _suggestAppKey(k);
    setState(() {
      target = k;
      running = false;
      note = '';
      if (!appTargetChosen && suggested != null) appTarget = suggested;
      if (!(sets.isNotEmpty && sets[n].byName.containsKey(k)) && first >= 0) n = first;
    });
    _send(_codeOf(n));
  }

  Future<void> _run() async {
    if (running) return;
    if (!ir.hasEmitter) {
      setState(() => note = 'این گوشی فرستنده‌ی IR ندارد');
      return;
    }
    setState(() {
      running = true;
      note = 'در حال اسکن... وقتی دستگاه واکنش نشان داد «توقف» را بزنید';
    });
    while (running && mounted) {
      await _send(_codeOf(n));
      await Future<void>.delayed(Duration(milliseconds: interval.round()));
      if (!running || !mounted) break;
      final nx = _nextWith(n, 1);
      if (nx < 0) {
        setState(() {
          running = false;
          note = 'اسکن تمام شد';
        });
        break;
      }
      setState(() => n = nx);
    }
  }

  void _pause() => setState(() {
        running = false;
        note = 'متوقف شد. با ◀ ▶ قدم‌به‌قدم برگردید تا مجموعه‌ی درست را پیدا کنید، بعد «این بود».';
      });

  Future<void> _step(int d) async {
    final i = _nextWith(n, d);
    if (i < 0) return;
    setState(() {
      running = false;
      n = i;
      note = '';
    });
    await _send(_codeOf(i));
  }

  void _saveButton() {
    final c = _codeOf(n);
    if (c == null) return;
    ir.setCode(appTarget, c);
    setState(() {
      running = false;
      _saved.add(appTarget);
      note = 'ذخیره شد: ${irButtonLabel(appTarget)} ← فرمان ${_labelFor(target)}، مجموعه‌ی ${n + 1} از ${sets.length}';
    });
  }

  Widget _setsPage() {
    final b = brand!;
    final cur = sets.isEmpty ? null : sets[n];
    final hasCode = _codeOf(n) != null;
    final isPower = target == 'power';
    return SingleChildScrollView(
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          IconButton(
            onPressed: () => setState(() {
              running = false;
              brand = null;
            }),
            icon: const Icon(Icons.arrow_back),
          ),
          Expanded(
            child: Text(b.name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          const SizedBox(width: 48),
        ]),
        const SizedBox(height: 6),
        Text(
          'اول دکمهٔ مقصد را انتخاب کنید؛ سپس فرمان را برای آزمایش برگزینید. مثلاً برای فرستادن صدای + با دکمهٔ کانال، '
          'دکمهٔ کانال را مقصد بگذارید و فرمان صدای + را انتخاب کنید. با «شروع» یا ◀ ▶ مجموعه‌ها را یکی‌یکی تست کنید؛ '
          'وقتی تلویزیون واکنش نشان داد، «این بود» را بزنید تا کد فقط روی همان دکمه در پروفایل «${ir.active.name}» ذخیره شود.',
          textAlign: TextAlign.center,
          style: const TextStyle(fontSize: 12, color: kHint),
        ),
        const SizedBox(height: 10),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          IconButton.outlined(
            onPressed: _nextWith(n, -1) >= 0 ? () => _step(-1) : null,
            icon: const Icon(Icons.chevron_left),
            tooltip: 'قبلی',
          ),
          const SizedBox(width: 16),
          InkWell(
            onTap: () => _pick('power'),
            customBorder: const CircleBorder(),
            child: Container(
              width: 88,
              height: 88,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: const Color(0xff00a878),
                border: Border.all(color: isPower ? kCyan : Colors.transparent, width: 3),
              ),
              child: const Icon(Icons.power_settings_new, size: 44, color: Colors.white),
            ),
          ),
          const SizedBox(width: 16),
          IconButton.outlined(
            onPressed: _nextWith(n, 1) >= 0 ? () => _step(1) : null,
            icon: const Icon(Icons.chevron_right),
            tooltip: 'بعدی',
          ),
        ]),
        const SizedBox(height: 10),
        const Text('دکمهٔ ریموتی که کد روی آن ذخیره می‌شود',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: kHint)),
        const SizedBox(height: 4),
        DropdownButton<String>(
          isExpanded: true,
          value: appTarget,
          dropdownColor: const Color(0xff141a33),
          items: [
            for (final e in kIrButtons)
              DropdownMenuItem(
                value: e.key,
                child: Text(_saved.contains(e.key) || ir.codes.containsKey(e.key) ? '${e.value}  ✓' : e.value),
              ),
          ],
          onChanged: (v) {
            if (v == null) return;
            final suggested = _suggestMiKey(v);
            final first = suggested == null ? -1 : sets.indexWhere((s) => s.byName.containsKey(suggested));
            setState(() {
              appTarget = v;
              appTargetChosen = true;
              running = false;
              note = '';
              if (first >= 0 && suggested != null) {
                target = suggested;
                n = first;
              }
            });
            if (first >= 0) _send(_codeOf(n));
          },
        ),
        const SizedBox(height: 4),
        const Text('فرمان مورد آزمایش از پروفایل‌های Mi',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: kHint)),
        const SizedBox(height: 4),
        Wrap(spacing: 6, runSpacing: 2, alignment: WrapAlignment.center, children: [
          for (final k in _allKeys())
            ChoiceChip(
              label: Text(_labelFor(k), style: const TextStyle(fontSize: 11)),
              selected: target == k,
              showCheckmark: false,
              onSelected: (_) => _pick(k),
            ),
        ]),
        const Divider(height: 18),
        Row(children: [
          const Text('فاصله', style: TextStyle(fontSize: 12)),
          Expanded(
            child: Slider(
              min: 150,
              max: 900,
              divisions: 15,
              label: '${interval.round()} ms',
              value: interval,
              onChanged: (v) => setState(() => interval = v),
            ),
          ),
          Text('${interval.round()} ms', style: const TextStyle(fontSize: 12)),
        ]),
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: kCyan.withOpacity(0.5)),
          ),
          child: Column(children: [
            Text(
              hasCode ? '${_labelFor(target)} • مجموعه‌ی ${n + 1} از ${sets.length}' : 'این مجموعه دکمه‌ی «${_labelFor(target)}» ندارد',
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 2),
            Text('${hasCode ? _posWith : 0} / $_countWith  •  ${hasCode ? (cur?.byName[target]?.label ?? '') : ''}',
                style: const TextStyle(fontSize: 11, color: kHint)),
            LinearProgressIndicator(value: _countWith == 0 ? 0 : (hasCode ? _posWith / _countWith : 0)),
          ]),
        ),
        const SizedBox(height: 8),
        Wrap(spacing: 8, runSpacing: 4, alignment: WrapAlignment.center, children: [
          running
              ? FilledButton.icon(onPressed: _pause, icon: const Icon(Icons.pause), label: const Text('توقف'))
              : FilledButton.icon(onPressed: hasCode ? _run : null, icon: const Icon(Icons.play_arrow), label: const Text('شروع')),
          FilledButton.icon(
            onPressed: hasCode ? _saveButton : null,
            icon: const Icon(Icons.save_outlined),
            label: Text('این بود → ${_labelFor(target)}'),
            style: FilledButton.styleFrom(backgroundColor: const Color(0xff1f9d55)),
          ),
        ]),
        if (note.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(note, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: kHint)),
          ),
        const Divider(height: 18),
        OutlinedButton(
          onPressed: cur == null ? null : _save,
          child: const Text('ذخیره‌ی کل این مجموعه به‌عنوان پروفایل جدید'),
        ),
      ]),
    );
  }
}
