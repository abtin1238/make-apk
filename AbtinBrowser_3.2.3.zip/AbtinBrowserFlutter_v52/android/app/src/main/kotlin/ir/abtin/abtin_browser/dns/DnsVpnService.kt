package ir.abtin.abtin_browser.dns

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import ir.abtin.abtin_browser.R
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * System-wide DNS changer. A VPN whose only route is one virtual DNS address: the whole phone sends its DNS queries
 * there, this service forwards them (UDP, sockets protect()ed so they leave outside the VPN) to the chosen servers
 * and writes the answers back. No other traffic enters the tunnel.
 */
class DnsVpnService : VpnService() {
    companion object {
        const val ACTION_START = "ir.abtin.abtin_browser.DNS_START"
        const val ACTION_STOP = "ir.abtin.abtin_browser.DNS_STOP"
        private const val TAG = "AbtinDnsVpn"
        private const val CHANNEL = "abtin_dns"
        private const val NOTIFICATION_ID = 7789
        private const val VIRTUAL_DNS = "10.255.255.2"
        @Volatile var running = false
        @Volatile var lastError = ""
        var listener: ((Boolean, String) -> Unit)? = null

        fun notifyState() {
            val r = running; val e = lastError
            Handler(Looper.getMainLooper()).post { listener?.invoke(r, e) }
        }
    }

    private var tun: ParcelFileDescriptor? = null
    private var loop: Thread? = null
    private var pool: ExecutorService? = null
    @Volatile private var stopping = false
    private var servers: List<String> = emptyList()
    private val writeLock = Any()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, notification(""))
        if (intent?.action == ACTION_STOP) { shutdown(""); return START_NOT_STICKY }
        if (intent?.action != ACTION_START) { shutdown(""); return START_NOT_STICKY }
        val list = (intent.getStringExtra("servers") ?: "").split(',').map { it.trim() }.filter { it.isNotEmpty() && !it.contains(':') }
        if (list.isEmpty()) { shutdown("no_servers"); return START_NOT_STICKY }
        closeTun()
        servers = list
        try {
            val b = Builder()
            b.setSession("Abtin DNS")
            b.setMtu(1500)
            b.addAddress("10.255.255.1", 30)
            b.addRoute(VIRTUAL_DNS, 32)
            b.addDnsServer(VIRTUAL_DNS)
            b.setBlocking(true)
            b.setMetered(false)
            val fd = b.establish() ?: throw IllegalStateException("vpn_denied")
            tun = fd
            stopping = false
            pool = Executors.newFixedThreadPool(16)
            loop = Thread { runLoop(fd) }.also { it.isDaemon = true; it.name = "abtin-dns"; it.start() }
            running = true
            lastError = ""
            getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, notification(list.joinToString(" , ")))
            notifyState()
        } catch (t: Throwable) {
            Log.e(TAG, "start failed", t)
            shutdown(t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName)
        }
        return START_NOT_STICKY
    }

    override fun onRevoke() { shutdown("") }

    override fun onDestroy() {
        stopping = true
        running = false
        closeTun()
        pool?.shutdownNow()
        notifyState()
        super.onDestroy()
    }

    private fun closeTun() {
        stopping = true
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        loop?.interrupt()
        loop = null
    }

    private fun shutdown(error: String) {
        closeTun()
        pool?.shutdownNow()
        pool = null
        running = false
        lastError = error
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        notifyState()
    }

    private fun runLoop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        while (!stopping) {
            val n = try { input.read(buf) } catch (_: Exception) { break }
            if (n <= 0) continue
            if (n < 28 || (buf[0].toInt() shr 4) != 4) continue
            val ihl = (buf[0].toInt() and 0x0F) * 4
            if (ihl < 20 || n < ihl + 8 || buf[9].toInt() != 17) continue
            val dstPort = ((buf[ihl + 2].toInt() and 0xFF) shl 8) or (buf[ihl + 3].toInt() and 0xFF)
            if (dstPort != 53) continue
            val srcPort = ((buf[ihl].toInt() and 0xFF) shl 8) or (buf[ihl + 1].toInt() and 0xFF)
            val payload = buf.copyOfRange(ihl + 8, n)
            val srcIp = buf.copyOfRange(12, 16)
            val dstIp = buf.copyOfRange(16, 20)
            try {
                pool?.execute { answer(output, payload, srcIp, dstIp, srcPort) }
            } catch (_: Exception) { break }
        }
    }

    private fun answer(output: FileOutputStream, query: ByteArray, clientIp: ByteArray, dnsIp: ByteArray, clientPort: Int) {
        val key = cacheKey(query)
        val hit = if (key == null) null else synchronized(cache) { cache[key] }
        val resp: ByteArray = if (hit != null && hit.expires > System.currentTimeMillis()) {
            // cached answer: same data, the caller's own transaction id
            hit.resp.copyOf().also { it[0] = query[0]; it[1] = query[1] }
        } else {
            val r = forward(query) ?: return
            if (key != null) store(key, r)
            r
        }
        val total = 28 + resp.size
        val p = ByteArray(total)
        p[0] = 0x45
        p[2] = (total shr 8).toByte(); p[3] = total.toByte()
        p[6] = 0x40 // don't fragment
        p[8] = 64; p[9] = 17
        System.arraycopy(dnsIp, 0, p, 12, 4)
        System.arraycopy(clientIp, 0, p, 16, 4)
        var sum = 0
        for (i in 0 until 20 step 2) sum += ((p[i].toInt() and 0xFF) shl 8) or (p[i + 1].toInt() and 0xFF)
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val cs = sum.inv() and 0xFFFF
        p[10] = (cs shr 8).toByte(); p[11] = cs.toByte()
        p[20] = 0; p[21] = 53
        p[22] = (clientPort shr 8).toByte(); p[23] = clientPort.toByte()
        val ul = 8 + resp.size
        p[24] = (ul shr 8).toByte(); p[25] = ul.toByte()
        System.arraycopy(resp, 0, p, 28, resp.size) // UDP checksum 0 = none (valid for IPv4)
        synchronized(writeLock) { try { output.write(p) } catch (_: Exception) {} }
    }

    // ---- answer cache: pages ask for dozens of names (A + AAAA); repeated lookups no longer cost a round trip to a far DNS server ----
    private class Cached(val resp: ByteArray, val expires: Long)
    private val cache = object : LinkedHashMap<String, Cached>(256, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Cached>?): Boolean = size > 600
    }

    /** Everything after the 2-byte transaction id (flags, counts, question, EDNS) identifies the question. */
    private fun cacheKey(q: ByteArray): String? = if (q.size < 17) null else String(q, 2, q.size - 2, Charsets.ISO_8859_1)

    private fun skipName(b: ByteArray, p0: Int): Int {
        var p = p0
        while (true) {
            val l = b[p].toInt() and 0xFF
            if (l == 0) return p + 1
            if ((l and 0xC0) == 0xC0) return p + 2
            p += l + 1
        }
    }

    /** Seconds the answer may be kept (smallest record TTL, 20..300 s), or 0 when it must not be cached. */
    private fun cacheSeconds(r: ByteArray): Int {
        try {
            if (r.size < 12 || (r[2].toInt() and 0x02) != 0) return 0          // truncated
            if ((r[3].toInt() and 0x0F) != 0) return 0                          // errors (SERVFAIL, NXDOMAIN...) are not kept
            val qd = ((r[4].toInt() and 0xFF) shl 8) or (r[5].toInt() and 0xFF)
            val an = ((r[6].toInt() and 0xFF) shl 8) or (r[7].toInt() and 0xFF)
            if (an == 0) return 20                                              // NODATA (e.g. no AAAA record)
            var p = 12
            repeat(qd) { p = skipName(r, p) + 4 }
            var min = Int.MAX_VALUE
            repeat(an) {
                p = skipName(r, p)
                val ttl = ((r[p + 4].toLong() and 0xFF) shl 24) or ((r[p + 5].toLong() and 0xFF) shl 16) or ((r[p + 6].toLong() and 0xFF) shl 8) or (r[p + 7].toLong() and 0xFF)
                val rd = ((r[p + 8].toInt() and 0xFF) shl 8) or (r[p + 9].toInt() and 0xFF)
                if (ttl < min) min = if (ttl > 3600) 3600 else ttl.toInt()
                p += 10 + rd
            }
            return min.coerceIn(20, 300)
        } catch (_: Exception) { return 0 }
    }

    private fun store(key: String, r: ByteArray) {
        val sec = cacheSeconds(r)
        if (sec <= 0) return
        synchronized(cache) { cache[key] = Cached(r, System.currentTimeMillis() + sec * 1000L) }
    }

    // Index of the server that answered last: tried first, so one dead server does not add a timeout to every lookup.
    @Volatile private var firstIdx = 0

    /**
     * The preferred server gets the query first; if it has not answered within 400 ms the next one is asked as well
     * (same socket, first valid answer wins), so one slow or blocked server costs ~0.4 s instead of 1.5 s per lookup.
     */
    private fun forward(query: ByteArray): ByteArray? {
        val list = servers
        if (list.isEmpty()) return null
        val start = firstIdx % list.size
        val sock = DatagramSocket()
        try {
            protect(sock)
            val deadline = System.currentTimeMillis() + 2500
            var sent = 0
            fun sendNext() {
                val idx = (start + sent) % list.size
                sent++
                try { sock.send(DatagramPacket(query, query.size, InetAddress.getByName(list[idx]), 53)) } catch (_: Exception) {}
            }
            sendNext()
            val rb = ByteArray(4096)
            while (true) {
                val left = (deadline - System.currentTimeMillis()).toInt()
                if (left <= 0) return null
                sock.soTimeout = if (sent < list.size) minOf(400, left) else left
                try {
                    val rp = DatagramPacket(rb, rb.size)
                    sock.receive(rp)
                    if (rp.length >= 12 && rb[0] == query[0] && rb[1] == query[1]) {
                        val ix = list.indexOf(rp.address?.hostAddress)
                        if (ix >= 0) firstIdx = ix
                        return rb.copyOf(rp.length)
                    }
                } catch (_: SocketTimeoutException) {
                    if (sent < list.size) sendNext()
                } catch (_: Exception) { return null }
            }
        } catch (_: Exception) {
            return null
        } finally {
            try { sock.close() } catch (_: Exception) {}
        }
    }

    private fun notification(status: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm?.createNotificationChannel(NotificationChannel(CHANNEL, "DNS", NotificationManager.IMPORTANCE_LOW))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val open = if (launch != null) PendingIntent.getActivity(this, 0, launch, flags) else null
        val stop = PendingIntent.getService(this, 2, Intent(this, DnsVpnService::class.java).setAction(ACTION_STOP), flags)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_v2ray_notif)
            .setContentTitle("Abtin DNS")
            .setContentText(status)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(open)
            .addAction(0, "قطع / Stop", stop)
            .build()
    }
}
