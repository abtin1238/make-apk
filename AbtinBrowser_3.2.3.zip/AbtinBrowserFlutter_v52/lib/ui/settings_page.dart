import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../app_state.dart';
import '../services.dart';
import 'extensions_page.dart';
import 'library_pages.dart';
import 'v2ray_page.dart';
import 'dns_page.dart';
import 'passwords_page.dart';
import 'personal_vault_page.dart';
import 'webapps_page.dart';
import 'site_settings_page.dart';
import 'glass.dart';

typedef ClearFn = Future<void> Function({
  bool history,
  bool cookies,
  bool cache,
  bool downloads,
  bool perms,
  int sinceMs,
});

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key, required this.onClear, required this.onOpen});
  final ClearFn onClear;
  final void Function(String url) onOpen;
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  @override
  void initState() {
    super.initState();
    app.addListener(_r);
    googleAccount.addListener(_r);
    v2ray.addListener(_r);
  }

  @override
  void dispose() {
    app.removeListener(_r);
    googleAccount.removeListener(_r);
    v2ray.removeListener(_r);
    super.dispose();
  }

  void _r() {
    if (mounted) setState(() {});
  }

  Widget _sec(String t, IconData i, Color c) => _Sec(t, i, c);

  Widget _header(_Sec h) => Padding(
    padding: const EdgeInsets.fromLTRB(22, 22, 22, 10),
    child: Row(
      children: [
        IconChip(h.icon, h.color, size: 32),
        const SizedBox(width: 10),
        Text(
          h.title,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
        ),
      ],
    ),
  );

  /// Turns the flat list (section markers + tiles) into one glass card per section.
  List<Widget> _grouped(List<Widget> items) {
    final out = <Widget>[];
    var cur = <Widget>[];
    _Sec? head;
    void flush() {
      if (head != null) out.add(_header(head));
      if (cur.isNotEmpty) {
        out.add(
          Glass(
            radius: 24,
            margin: const EdgeInsets.symmetric(horizontal: 12),
            child: Column(
              children: [
                for (var i = 0; i < cur.length; i++) ...[
                  if (i > 0)
                    Divider(
                      height: 1,
                      indent: 16,
                      endIndent: 16,
                      color: alpha(Colors.white, .10),
                    ),
                  cur[i],
                ],
              ],
            ),
          ),
        );
      }
      cur = <Widget>[];
    }

    for (final w in items) {
      if (w is _Sec) {
        flush();
        head = w;
      } else {
        cur.add(w);
      }
    }
    flush();
    return out;
  }

  Widget _sw(String key, String title, {String? sub}) => SwitchListTile(
    value: app.flag(key),
    onChanged: (v) => app.set(key, v),
    title: Text(title),
    subtitle: sub == null
        ? null
        : Text(sub, style: const TextStyle(fontSize: 12)),
  );

  Widget _choice(
    String key,
    String title,
    Map<String, String> opts, {
    void Function(String v)? onPick,
    String? sub,
  }) => ListTile(
    title: Text(title),
    subtitle: Text(sub ?? opts[app.str(key)] ?? ''),
    trailing: const Icon(Icons.chevron_right),
    onTap: () => showGlassSheet<void>(
      context: context,
      builder: (ctx) => SafeArea(
        child: RadioGroup<String>(
          groupValue: app.str(key),
          onChanged: (v) {
            if (v == null) return;
            app.set(key, v);
            Navigator.pop(ctx);
            onPick?.call(v);
          },
          child: ListView(
            shrinkWrap: true,
            children: [
              for (final e in opts.entries)
                RadioListTile<String>(value: e.key, title: Text(e.value)),
            ],
          ),
        ),
      ),
    ),
  );

  /// Folder picker row: default / common folders / any folder.
  Widget _dirTile(String key, String title, List<(String, String)> presets) =>
      ListTile(
        leading: const Icon(Icons.folder_open_rounded),
        title: Text(title),
        subtitle: Text(
          app.str(key).isEmpty ? tr('پیش‌فرض', 'Default') : app.str(key),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          textDirection: TextDirection.ltr,
        ),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => showGlassSheet<void>(
          context: context,
          builder: (ctx) => SafeArea(
            child: ListView(
              shrinkWrap: true,
              children: [
                ListTile(
                  leading: const Icon(Icons.restore),
                  title: Text(tr('پیش‌فرض', 'Default')),
                  onTap: () {
                    app.set(key, '');
                    Navigator.pop(ctx);
                  },
                ),
                for (final p in presets)
                  ListTile(
                    leading: const Icon(Icons.folder_outlined),
                    title: Text(p.$1),
                    subtitle: Text(p.$2, textDirection: TextDirection.ltr),
                    onTap: () {
                      app.set(key, p.$2);
                      Navigator.pop(ctx);
                    },
                  ),
                ListTile(
                  leading: const Icon(Icons.drive_folder_upload_outlined),
                  title: Text(tr('انتخاب پوشه…', 'Choose folder…')),
                  onTap: () async {
                    Navigator.pop(ctx);
                    final p = await FilePicker.platform.getDirectoryPath();
                    if (p != null && p.isNotEmpty) app.set(key, p);
                  },
                ),
              ],
            ),
          ),
        ),
      );

  Future<void> _clearDialog() async {
    var history = true,
        cookies = true,
        cache = true,
        downloads = false,
        perms = false;
    var range = 3600000;
    await showGlassDialog<void>(
      context: context,
      builder: (d) => StatefulBuilder(
        builder: (d, set) => AlertDialog(
          title: Text(tr('پاک‌سازی داده‌های مرور', 'Clear browsing data')),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                DropdownButton<int>(
                  value: range,
                  isExpanded: true,
                  onChanged: (v) => set(() => range = v!),
                  items: [
                    DropdownMenuItem(
                      value: 3600000,
                      child: Text(tr('ساعت گذشته', 'Last hour')),
                    ),
                    DropdownMenuItem(
                      value: 86400000,
                      child: Text(tr('۲۴ ساعت گذشته', 'Last 24 hours')),
                    ),
                    DropdownMenuItem(
                      value: 604800000,
                      child: Text(tr('۷ روز گذشته', 'Last 7 days')),
                    ),
                    DropdownMenuItem(
                      value: 0,
                      child: Text(tr('همه', 'All time')),
                    ),
                  ],
                ),
                CheckboxListTile(
                  value: history,
                  onChanged: (v) => set(() => history = v!),
                  title: Text(tr('تاریخچه', 'History')),
                  dense: true,
                ),
                CheckboxListTile(
                  value: cookies,
                  onChanged: (v) => set(() => cookies = v!),
                  title: Text(
                    tr(
                      'کوکی‌ها و داده‌های سایت (همه)',
                      'Cookies and site data (all)',
                    ),
                  ),
                  dense: true,
                ),
                CheckboxListTile(
                  value: cache,
                  onChanged: (v) => set(() => cache = v!),
                  title: Text(tr('حافظهٔ پنهان', 'Cache')),
                  dense: true,
                ),
                CheckboxListTile(
                  value: downloads,
                  onChanged: (v) => set(() => downloads = v!),
                  title: Text(tr('فهرست دانلودها', 'Download list')),
                  dense: true,
                ),
                CheckboxListTile(
                  value: perms,
                  onChanged: (v) => set(() => perms = v!),
                  title: Text(tr('مجوزهای سایت‌ها', 'Site permissions')),
                  dense: true,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(d),
              child: Text(tr('لغو', 'Cancel')),
            ),
            TextButton(
              onPressed: () async {
                Navigator.pop(d);
                await widget.onClear(
                  history: history,
                  cookies: cookies,
                  cache: cache,
                  downloads: downloads,
                  perms: perms,
                  sinceMs: range,
                );
                if (mounted) snackTop(context, tr('پاک شد', 'Cleared'));
              },
              child: Text(tr('پاک کردن', 'Clear')),
            ),
          ],
        ),
      ),
    );
  }

  static const String _googleWebClientId =
      '124913979442-v9kt0r2oj5rjgq1t56iro264vpqbvisu.apps.googleusercontent.com';

  Future<void> _googleSignIn() async {
    final err = await googleAccount.signIn(app, _googleWebClientId);
    if (!mounted || err == null || err == 'cancelled') return;
    final msg = switch (err) {
      'no_account' => tr(
        'هیچ حساب گوگلی روی این گوشی نیست؛ ابتدا از تنظیمات اندروید یک حساب اضافه کنید.',
        'No Google account on this phone. Add one in Android settings first.',
      ),
      'unavailable' => tr(
        'ورود گوگل فقط روی اندروید در دسترس است.',
        'Google sign-in is only available on Android.',
      ),
      'no_client_id' => tr('شناسهٔ کلاینت تنظیم نشده', 'Client ID is not set'),
      _ => tr(
        'ورود ناموفق بود (شناسهٔ کلاینت و SHA-1 و Google Play Services را بررسی کنید)',
        'Sign-in failed (check client ID, SHA-1 and Google Play services)',
      ),
    };
    snackTop(context, msg);
  }

  /// Normal web sign-in: cookies live in the browser profile, so every site's "Sign in with Google" sees the session.
  void _googleWebSignIn() {
    final hint = googleAccount.email.isEmpty
        ? ''
        : '&Email=${Uri.encodeQueryComponent(googleAccount.email)}';
    final url =
        'https://accounts.google.com/ServiceLogin?continue=${Uri.encodeQueryComponent('https://myaccount.google.com/')}$hint';
    Navigator.of(context).pop();
    widget.onOpen(url);
  }

  Future<void> _sitePerms() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => StatefulBuilder(
          builder: (c, set) {
            final hosts = app.perms.keys.toList();
            return GlassScaffold(
              appBar: AppBar(
                title: Text(tr('مجوزهای سایت‌ها', 'Site permissions')),
              ),
              body: hosts.isEmpty
                  ? Center(child: Text(tr('موردی ذخیره نشده', 'Nothing saved')))
                  : ListView(
                      children: [
                        for (final h in hosts)
                          ListTile(
                            title: Text(h, textDirection: TextDirection.ltr),
                            subtitle: Text(
                              (app.perms[h] as Map).entries
                                  .map((e) => '${e.key}: ${e.value}')
                                  .join('  '),
                            ),
                            trailing: IconButton(
                              icon: const Icon(Icons.delete_outline),
                              onPressed: () {
                                app.perms.remove(h);
                                app.prefs.setString(
                                  'perms_v2',
                                  jsonEncode(app.perms),
                                );
                                set(() {});
                              },
                            ),
                          ),
                      ],
                    ),
            );
          },
        ),
      ),
    );
  }

  Future<void> _export() async {
    final d = await dlMgr.dir();
    final f = File('${d.path}/abtin_backup.json');
    await f.writeAsString(app.exportJson());
    if (mounted) snackTop(context, '${tr('ذخیره شد', 'Saved')}: ${f.path}');
  }

  Future<void> _import() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.any);
    final p = r?.files.single.path;
    if (p == null) return;
    try {
      app.importJson(await File(p).readAsString());
    } catch (_) {
      if (mounted) snackTop(context, tr('فایل نامعتبر', 'Invalid file'));
    }
  }

  @override
  Widget build(BuildContext context) {
    final accents = [
      0xFF3977F6,
      0xFF8B5CF6,
      0xFF10B981,
      0xFFF59E0B,
      0xFFEF4444,
      0xFF06B6D4,
      0xFFEC4899,
    ];
    return GlassScaffold(
      appBar: AppBar(title: Text(tr('تنظیمات', 'Settings'))),
      body: ListView(
        children: [
          ..._grouped([
            _sec(
              tr('ظاهر', 'Appearance'),
              Icons.palette_rounded,
              const Color(0xFFEC4899),
            ),
            const PalettePicker(),
            _choice('uiStyle', tr('سبک طراحی رابط', 'Interface design'), {
              'minimal': tr('مینیمال — ساده و خلوت', 'Minimal — clean and quiet'),
              'neu': tr('نئومورفیسم — برجستگی نرم', 'Neumorphism — soft raised surfaces'),
              'uc': tr('الهام‌گرفته از UC Browser', 'UC Browser inspired'),
              'samsung': tr('الهام‌گرفته از Samsung Internet', 'Samsung Internet inspired'),
            }, sub: tr('چهار چیدمان مات و مستقل؛ بدون شفافیت و بلور', 'Four opaque visual styles; no transparency or blur')),
            _choice('menuStyle', tr('سبک منوی اصلی', 'Main menu style'), {
              'firefox': tr(
                'برگهٔ پایین (شبیه فایرفاکس)',
                'Bottom sheet (Firefox-like)',
              ),
              'chrome': tr(
                'کشویی بالا (شبیه کروم)',
                'Top dropdown (Chrome-like)',
              ),
            }),
            _choice(
              'topBtn',
              tr('دکمهٔ کنار منو در نوار بالا', 'Button next to the menu'),
              {
                'tabs': tr('تعداد تب‌ها', 'Tab count'),
                'newtab': tr('تب جدید', 'New tab'),
                'private': tr('تب خصوصی', 'Private tab'),
                'home': tr('صفحهٔ شروع', 'Start page'),
                'reload': tr('بازخوانی', 'Reload'),
                'bookmark': tr('نشانک', 'Bookmark'),
                'bookmarks': tr('فهرست نشانک‌ها', 'Bookmarks list'),
                'downloads': tr('دانلودها', 'Downloads'),
                'screenshot': tr('عکس از صفحه', 'Screenshot'),
                'desktop': tr('نسخهٔ دسکتاپ', 'Desktop site'),
                'find': tr('جست‌وجو در صفحه', 'Find in page'),
                'settings': tr('تنظیمات', 'Settings'),
                'vpn': tr('روشن/خاموش VPN', 'VPN on/off'),
                'share': tr('اشتراک‌گذاری', 'Share'),
                'reader': tr('حالت خواندن', 'Reader mode'),
                'video': tr('ویدیوهای صفحه', 'Page videos'),
                'qr': tr('اسکن QR', 'Scan QR'),
                'none': tr('هیچ (حذف دکمه)', 'None (hide)'),
              },
            ),
            SwitchListTile(
              value: app.perf,
              onChanged: app.setPerf,
              title: Text(tr('حالت سبک (گوشی ضعیف)', 'Lite performance mode')),
              subtitle: Text(
                tr(
                  'بلور و انیمیشن خاموش، مصرف رم و کش موتور کمتر',
                  'No blur or animations, less RAM and engine cache use',
                ),
                style: const TextStyle(fontSize: 12),
              ),
            ),
            _sw(
              'uiAnim',
              tr('انیمیشن‌های مرورگر', 'Browser animations'),
              sub: tr(
                'خاموش: صفحه‌ها، منوها و پنجره‌ها بدون انیمیشن و فوراً باز می‌شوند',
                'Off: pages, menus and dialogs open instantly, without animation',
              ),
            ),
            ListTile(
              title: Text(tr('رنگ تأکیدی', 'Accent color')),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  for (final c in accents)
                    GestureDetector(
                      onTap: () => app.set('accent', c),
                      child: Container(
                        width: 22,
                        height: 22,
                        margin: const EdgeInsets.symmetric(horizontal: 3),
                        decoration: BoxDecoration(
                          color: Color(c),
                          shape: BoxShape.circle,
                          border: app.num_('accent') == c
                              ? Border.all(color: Colors.white, width: 2)
                              : null,
                        ),
                      ),
                    ),
                ],
              ),
            ),
            _choice('lang', tr('زبان', 'Language'), {
              'fa': 'فارسی',
              'en': 'English',
            }),
            ListTile(
              title: Text(
                '${tr('اندازهٔ متن صفحات', 'Page text size')}: ${app.num_('textZoom')}%',
              ),
              subtitle: Slider(
                min: 70,
                max: 200,
                divisions: 13,
                value: app.num_('textZoom').toDouble(),
                onChanged: (v) => app.set('textZoom', v.round()),
              ),
            ),
            _sw(
              'pullRefresh',
              tr('کشیدن صفحه به پایین برای رفرش', 'Pull down to refresh'),
              sub: tr(
                'در بالای صفحه، انگشت را به پایین بکشید',
                'Drag down while at the top of a page',
              ),
            ),
            _sw(
              'scrollBtn',
              tr(
                'دکمهٔ رفتن به بالا / پایین صفحه',
                'Jump to top / bottom button',
              ),
              sub: tr(
                'مثل اپرا: هنگام اسکرول، دکمهٔ شناور نشان داده می‌شود (بالا‌رفتن ↑ و پایین‌رفتن ↓)',
                'Like Opera: a floating button appears while scrolling (↑ to top, ↓ to bottom)',
              ),
            ),
            _sw(
              'mediaBtn',
              tr(
                'دکمهٔ دانلود و پلیر روی ویدیو',
                'Download & player buttons on videos',
              ),
              sub: tr(
                'روی ویدیوهای صفحه نمایش داده می‌شود؛ با ✕ برای هر سایت مخفی می‌شود',
                'Shown on page videos; the ✕ hides it for that site',
              ),
            ),
            _sec(
              tr('جست‌وجو و صفحهٔ اصلی', 'Search and home'),
              Icons.search_rounded,
              const Color(0xFF3B82F6),
            ),
            _choice('engine', tr('موتور جست‌وجو', 'Search engine'), {
              for (final e in engines.entries) e.key: e.value.name,
            }),
            _sw(
              'suggest',
              tr('پیشنهاد جست‌وجو', 'Search suggestions'),
              sub: tr(
                'نوشته‌های شما به موتور جست‌وجو ارسال می‌شود (در تب خصوصی نه)',
                'Typed text is sent to the search engine (not in private tabs)',
              ),
            ),
            ListTile(
              title: Text(tr('صفحهٔ شروع', 'Homepage')),
              subtitle: Text(
                app.str('homepage').isEmpty
                    ? tr('صفحهٔ تب جدید', 'New tab page')
                    : app.str('homepage'),
                textDirection: TextDirection.ltr,
              ),
              onTap: () async {
                final c = TextEditingController(text: app.str('homepage'));
                final ok = await showGlassDialog<bool>(
                  context: context,
                  builder: (d) => AlertDialog(
                    title: Text(tr('صفحهٔ شروع', 'Homepage')),
                    content: TextField(
                      controller: c,
                      textDirection: TextDirection.ltr,
                      decoration: InputDecoration(
                        hintText: tr('خالی = تب جدید', 'empty = new tab page'),
                      ),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(d, false),
                        child: Text(tr('لغو', 'Cancel')),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(d, true),
                        child: Text(tr('ذخیره', 'Save')),
                      ),
                    ],
                  ),
                );
                if (ok == true) app.set('homepage', c.text.trim());
              },
            ),
            _sec(
              tr('حریم خصوصی و امنیت', 'Privacy and security'),
              Icons.shield_rounded,
              const Color(0xFF22C55E),
            ),
            _choice(
              'track',
              tr('محافظت در برابر ردیابی', 'Tracking protection'),
              {
                'off': tr('خاموش', 'Off'),
                'standard': tr('استاندارد', 'Standard'),
                'strict': tr(
                  'سخت‌گیرانه (ضد اثر انگشت)',
                  'Strict (anti-fingerprinting)',
                ),
              },
            ),
            _sw('adblock', tr('مسدودکنندهٔ تبلیغات', 'Ad blocker')),
            _sw(
              'httpsOnly',
              tr('حالت فقط HTTPS', 'HTTPS-only mode'),
              sub: tr(
                'ارتقای خودکار http به https',
                'Automatically upgrade http to https',
              ),
            ),
            _sw(
              'tpc',
              tr('مسدودکردن کوکی‌های شخص ثالث', 'Block third-party cookies'),
            ),
            _sw(
              'gpc',
              tr('ارسال سیگنال Do Not Track / GPC', 'Send Do Not Track / GPC'),
            ),
            _sw(
              'fingerprint',
              tr(
                'محافظت در برابر اثر انگشت مرورگر',
                'Fingerprinting protection',
              ),
            ),
            _choice(
              'netMode',
              tr(
                'سازگاری با VPN (HTTP/3 و IPv6)',
                'VPN compatibility (HTTP/3 and IPv6)',
              ),
              {
                'auto': tr('خودکار (پیشنهادی)', 'Automatic (recommended)'),
                'on': tr(
                  'همیشه خاموش‌کردن HTTP/3 و IPv6',
                  'Always turn HTTP/3 and IPv6 off',
                ),
                'off': tr('همیشه روشن', 'Always on'),
              },
              sub: tr(
                'خودکار: بدون فیلترشکن HTTP/3 و IPv6 روشن‌اند؛ با فیلترشکن فعال (یا اگر اتصال ناموفق بود) خودکار خاموش می‌شوند تا صفحه‌ها سریع و کامل باز شوند',
                'Automatic: on without a VPN; switched off while a VPN is active (or after a failed connection) so pages load fast and complete',
              ),
            ),
            _sw(
              'passkeys',
              tr(
                'کلید عبور / اثرانگشت (آزمایشی)',
                'Passkeys / fingerprint (experimental)',
              ),
              sub: tr(
                'برای ورود با گوگل خاموش بماند؛ گوگل فقط به مرورگرهای مجاز اجازهٔ اثرانگشت می‌دهد. خاموش: سایت‌ها مستقیم رمز عبور می‌خواهند',
                'Off: sites ask for a password instead of waiting for a fingerprint',
              ),
            ),
            _sw(
              'savePw',
              tr(
                'ذخیره و پر کردن خودکار رمز عبور',
                'Save and autofill passwords',
              ),
              sub: tr(
                'پس از ورود، پیشنهاد ذخیرهٔ رمز داده می‌شود و دفعهٔ بعد خودکار پر می‌شود. رمزها رمزنگاری‌شده و فقط روی همین گوشی نگهداری می‌شوند (در تب خصوصی ذخیره نمی‌شود)',
                'Offers to save passwords after you sign in and fills them next time. Passwords are encrypted and kept only on this phone (never saved in private tabs)',
              ),
            ),
            _sw(
              'bioLogin',
              tr(
                'ورود خودکار با اثر انگشت',
                'Autofill and sign in with biometrics',
              ),
              sub: tr(
                'پس از تأیید اثر انگشت، اطلاعات ذخیره‌شده پر و فرم ورود همان سایت ارسال می‌شود؛ برای چند حساب، نام کاربری را انتخاب کنید.',
                'After biometric confirmation, saved credentials are filled and that site’s login form is submitted. Choose a username if multiple accounts are saved.',
              ),
            ),
            ListTile(
              leading: const Icon(Icons.account_balance_wallet_rounded),
              title: Text(
                tr(
                  'کارت‌ها و نشانی‌های ذخیره‌شده',
                  'Saved cards and addresses',
                ),
              ),
              subtitle: Text(
                tr(
                  'رمزنگاری‌شده؛ نیازمند اثر انگشت',
                  'Encrypted; biometric protected',
                ),
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const PersonalVaultPage(),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.install_mobile),
              title: Text(tr('وب‌اپ‌های نصب‌شده', 'Installed web apps')),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const WebAppsPage()),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.key_rounded),
              title: Text(tr('رمزهای عبور ذخیره‌شده', 'Saved passwords')),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const PasswordsPage()),
              ),
            ),
            _sw(
              'webrtc',
              tr('جلوگیری از نشت IP در WebRTC', 'Prevent WebRTC IP leak'),
            ),
            _sw(
              'safeBrowsing',
              tr('مرور امن (Safe Browsing)', 'Safe Browsing'),
            ),
            _sw('popups', tr('مسدودکردن پنجره‌های بازشو', 'Block pop-ups')),
            SwitchListTile(
              value: app.flag('smsOtp'),
              onChanged: (v) {
                app.set('smsOtp', v);
                if (v) gecko.call('smsPerm', {});
              },
              title: Text(tr('خواندن کد پیامکی ورود', 'Read SMS login codes')),
              subtitle: Text(
                tr(
                  'کد تأیید پیامک‌شده را خودکار در کادر کد سایت می‌گذارد. فقط خود کد استفاده می‌شود و ذخیره نمی‌شود (نیاز به مجوز پیامک)',
                  'Fills the verification code from an incoming SMS into the site\'s code box. Only the code is used, nothing is stored (needs SMS permission)',
                ),
                style: const TextStyle(fontSize: 12),
              ),
            ),
            _sw('js', 'JavaScript'),
            _sw('saveHistory', tr('ذخیرهٔ تاریخچه', 'Save history')),
            _sw(
              'clearOnExit',
              tr('پاک‌سازی داده‌ها هنگام خروج', 'Clear data on exit'),
            ),
            ListTile(
              leading: const Icon(Icons.delete_outline),
              title: Text(tr('پاک‌سازی داده‌های مرور', 'Clear browsing data')),
              onTap: _clearDialog,
            ),
            ListTile(
              leading: const Icon(Icons.admin_panel_settings_outlined),
              title: Text(tr('تنظیمات سایت‌ها', 'Site settings')),
              subtitle: Text(
                tr(
                  'دوربین، میکروفون، موقعیت و کوکی هر سایت',
                  'Camera, microphone, location and cookies per site',
                ),
              ),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SiteSettingsPage()),
              ),
            ),
            _sec(
              tr('عمومی', 'General'),
              Icons.tune_rounded,
              const Color(0xFFF59E0B),
            ),
            _sw(
              'dlAsk',
              tr('پرسش قبل از دانلود', 'Ask before downloading'),
              sub: tr(
                'برای دانلودهایی که خود صفحه شروع می‌کند، نام و حجم فایل را نشان بده و تأیید بگیر',
                'Show the file name and size and ask first when a page starts a download',
              ),
            ),
            _choice(
              'dlConns',
              tr(
                'تعداد اتصال همزمان برای هر دانلود',
                'Connections per download',
              ),
              {
                '1': tr('۱ (بدون تکه‌تکه کردن)', '1 (no splitting)'),
                '2': '2',
                '4': '4',
                '8': '8',
                '16': '16',
              },
            ),
            _dirTile(
              'downloadDir',
              tr('پوشهٔ دانلود', 'Download folder'),
              const [
                ('Download', '/storage/emulated/0/Download'),
                ('Download/Abtin', '/storage/emulated/0/Download/Abtin'),
              ],
            ),
            _dirTile(
              'screenshotDir',
              tr('پوشهٔ عکس‌های صفحه', 'Screenshot folder'),
              const [
                ('Pictures/Abtin', '/storage/emulated/0/Pictures/Abtin'),
                ('DCIM/Screenshots', '/storage/emulated/0/DCIM/Screenshots'),
                ('Download', '/storage/emulated/0/Download'),
              ],
            ),
            _sw(
              'siteCache',
              tr(
                'کش سایت‌ها و استفاده در بارگذاری مجدد',
                'Cache sites and reuse on reload',
              ),
              sub: tr(
                'تصاویر، فونت‌ها، CSS و JavaScript در کش دیسکی پایدار مرورگر ذخیره می‌شوند و پس از بستن برنامه هم باقی می‌مانند؛ محتوای منقضی طبق دستور سایت تازه می‌شود.',
                'Images, fonts, CSS and JavaScript are kept in the persistent disk cache, even after closing the app; expired content is revalidated according to the site’s rules.',
              ),
            ),
            _sw(
              'lite',
              tr(
                'حالت اینترنت کند (صرفه‌جویی در داده)',
                'Slow connection mode (data saver)',
              ),
              sub: tr(
                'پخش خودکار ویدیو خاموش می‌شود (مثلاً در فید اینستاگرام)، سایت‌ها نسخهٔ سبک‌تر را می‌گیرند و اتصال‌های موازی کمتر می‌شود. پیش‌نمایش خودکار ویدیوها هم متوقف می‌شود. بعد از تغییر، صفحه را دوباره بارگذاری کنید',
                'Turns off video autoplay (e.g. the Instagram feed), asks sites for lighter content and uses fewer parallel connections. Video previews stop auto-playing too. Reload the page after changing it',
              ),
            ),
            _sw(
              'restore',
              tr('بازیابی تب‌ها هنگام شروع', 'Restore tabs on start'),
            ),
            _sw(
              'sleeping',
              tr(
                'تب‌های خوابیده (صرفه‌جویی باتری/حافظه)',
                'Sleeping tabs (save battery/memory)',
              ),
            ),
            _sw(
              'autoDiscard',
              tr(
                'آزادسازی تب‌های پس‌زمینه (کم‌رم)',
                'Free background tabs (low RAM)',
              ),
              sub: tr(
                'وقتی حافظه کم می‌شود یا تعداد تب‌ها از ظرفیت RAM گوشی بیشتر است، تب‌های قدیمی بسته می‌شوند و هنگام بازگشت با تاریخچه‌شان برمی‌گردند. تب خصوصی و تب فعال هرگز آزاد نمی‌شود',
                'When memory runs low or there are more tabs than this phone\'s RAM allows, the oldest background tabs are freed and come back with their history when you open them. Private and the current tab are never freed',
              ),
            ),
            if (app.flag('autoDiscard'))
              FutureBuilder<Map?>(
                future: gecko.call<Map>('memInfo'),
                builder: (c, snap) {
                  final m = snap.data;
                  if (m == null) return const SizedBox.shrink();
                  return ListTile(
                    dense: true,
                    leading: const Icon(Icons.memory_rounded),
                    title: Text(
                      tr(
                        'RAM گوشی: ${m['totalMb']} MB · حداکثر تب زنده: ${m['limit']}',
                        'Phone RAM: ${m['totalMb']} MB · live tabs allowed: ${m['limit']}',
                      ),
                    ),
                    subtitle: Text(
                      tr(
                        'الان: ${m['live']} زنده، ${m['discarded']} آزادشده',
                        'Now: ${m['live']} live, ${m['discarded']} freed',
                      ),
                    ),
                  );
                },
              ),
            _sw(
              'chromeUa',
              tr(
                'معرفی مرورگر به‌عنوان Chrome (خودکار)',
                'Identify as Chrome (automatic)',
              ),
              sub: tr(
                'فقط برای سایت‌هایی که Chrome لازم دارند (فهرست داخلی، سایت‌هایی که خودشان «فقط Chrome» می‌گویند، و سایت‌هایی که شما از منو اضافه می‌کنید). بقیهٔ سایت‌ها هویت اصلی Gecko را می‌بینند. بعد از تغییر صفحه را دوباره بارگذاری کنید',
                'Only for sites that need Chrome (built-in list, sites that say "Chrome only" themselves, and sites you add from the menu). Every other site sees the normal Gecko identity. Reload the page after changing it',
              ),
            ),
            if (app.flag('chromeUa'))
              _sw(
                'chromeAll',
                tr('Chrome برای همهٔ سایت‌ها', 'Chrome for all sites'),
                sub: tr(
                  'معمولاً لازم نیست؛ فقط اگر سایتی را نمی‌شناسید که مشکل دارد. ممکن است بعضی سایت‌ها را مختل کند',
                  'Usually not needed; may break some sites',
                ),
              ),
            if (app.flag('chromeUa'))
              ListTile(
                title: Text(tr('سایت‌های Chrome', 'Chrome sites')),
                subtitle: Text(
                  app.chromeList.isEmpty
                      ? tr(
                          'خالی (یک سایت در هر خط؛ با ! خاموش می‌شود)',
                          'Empty (one site per line; prefix ! to turn off)',
                        )
                      : app.chromeList.join('، '),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                onTap: () async {
                  final c = TextEditingController(
                    text: app.chromeList.join('\n'),
                  );
                  final ok = await showGlassDialog<bool>(
                    context: context,
                    builder: (d) => AlertDialog(
                      title: Text(
                        tr('سایت‌های Chrome', 'Chrome sites'),
                        style: const TextStyle(fontSize: 16),
                      ),
                      content: TextField(
                        controller: c,
                        maxLines: 6,
                        textDirection: TextDirection.ltr,
                        decoration: InputDecoration(
                          hintText: 'example.com\n!other.com',
                          helperText: tr(
                            '! = هرگز برای این سایت',
                            '! = never for this site',
                          ),
                        ),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(d, false),
                          child: Text(tr('لغو', 'Cancel')),
                        ),
                        TextButton(
                          onPressed: () => Navigator.pop(d, true),
                          child: Text(tr('ذخیره', 'Save')),
                        ),
                      ],
                    ),
                  );
                  if (ok == true) app.set('chromeHosts', c.text.trim());
                },
              ),
            ListTile(
              title: Text(tr('User-Agent سفارشی', 'Custom user agent')),
              subtitle: Text(
                app.str('ua').isEmpty
                    ? tr('پیش‌فرض', 'Default')
                    : app.str('ua'),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                textDirection: TextDirection.ltr,
              ),
              onTap: () async {
                final c = TextEditingController(text: app.str('ua'));
                final ok = await showGlassDialog<bool>(
                  context: context,
                  builder: (d) => AlertDialog(
                    title: const Text('User-Agent'),
                    content: TextField(
                      controller: c,
                      maxLines: 3,
                      textDirection: TextDirection.ltr,
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(d, false),
                        child: Text(tr('لغو', 'Cancel')),
                      ),
                      TextButton(
                        onPressed: () => Navigator.pop(d, true),
                        child: Text(tr('ذخیره', 'Save')),
                      ),
                    ],
                  ),
                );
                if (ok == true) app.set('ua', c.text.trim());
              },
            ),
            _sec(
              tr('حساب گوگل', 'Google account'),
              Icons.account_circle_rounded,
              const Color(0xFF4285F4),
            ),
            if (googleAccount.signedIn)
              ListTile(
                leading: CircleAvatar(
                  backgroundImage: googleAccount.photo.isEmpty
                      ? null
                      : NetworkImage(googleAccount.photo),
                  child: googleAccount.photo.isEmpty
                      ? const Icon(Icons.person)
                      : null,
                ),
                title: Text(
                  googleAccount.name.isEmpty
                      ? googleAccount.email
                      : googleAccount.name,
                ),
                subtitle: Text(
                  googleAccount.email,
                  textDirection: TextDirection.ltr,
                ),
                trailing: TextButton(
                  onPressed: () => googleAccount.signOut(app),
                  child: Text(tr('خروج', 'Sign out')),
                ),
              )
            else
              ListTile(
                leading: googleAccount.busy
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : const Icon(Icons.login_rounded),
                title: Text(
                  tr('ورود یک‌لمسی با گوگل', 'One-tap sign in with Google'),
                ),
                subtitle: Text(
                  tr(
                    'لیست حساب‌های گوشی نمایش داده می‌شود؛ روی یکی بزنید و گوگل تأیید را کنترل می‌کند',
                    'Shows the accounts on this phone; tap one and Google handles the confirmation',
                  ),
                ),
                onTap: googleAccount.busy ? null : _googleSignIn,
              ),
            ListTile(
              leading: const Icon(Icons.public_rounded),
              title: Text(
                tr(
                  'ورود به گوگل برای سایت‌ها',
                  'Sign in to Google for websites',
                ),
              ),
              subtitle: Text(
                tr(
                  'صفحهٔ ورود گوگل در یک تب باز می‌شود؛ نشست آن بین همهٔ سایت‌ها مشترک است (مثل کروم) و دکمهٔ «ورود با گوگل» در سایت‌ها کار می‌کند. اگر پیشنهاد «ادامه با …» نشان داده نشد، «مسدودکردن کوکی‌های شخص ثالث» را خاموش کنید.',
                  'Opens the Google sign-in page in a tab; the session is shared by all sites (like Chrome) so "Sign in with Google" works on websites. If the "Continue as…" prompt does not appear, turn off "Block third-party cookies".',
                ),
              ),
              onTap: _googleWebSignIn,
            ),
            _sec(
              tr('افزونه‌ها', 'Extensions'),
              Icons.extension_rounded,
              const Color(0xFFF97316),
            ),
            ListTile(
              leading: const Icon(Icons.extension_outlined),
              title: Text(
                tr('مدیریت و فروشگاه افزونه‌ها', 'Manage extensions and store'),
              ),
              subtitle: Text(
                '${extMgr.list.length} ${tr('افزونه نصب‌شده', 'installed')}',
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => ExtensionsPage(host: extMgr.bridge!),
                ),
              ),
            ),
            _sec(
              tr('دادهها', 'Data'),
              Icons.folder_rounded,
              const Color(0xFF14B8A6),
            ),
            ListTile(
              leading: const Icon(Icons.star_border),
              title: Text(tr('نشانک‌ها', 'Bookmarks')),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => BookmarksPage(
                    onOpen: (u, {bool newTab = false}) {
                      Navigator.of(context).pop();
                      widget.onOpen(u);
                    },
                  ),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.history),
              title: Text(tr('تاریخچه', 'History')),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => HistoryPage(
                    onOpen: (u, {bool newTab = false}) {
                      Navigator.of(context).pop();
                      widget.onOpen(u);
                    },
                  ),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.download_outlined),
              title: Text(tr('دانلودها', 'Downloads')),
              onTap: () => Navigator.of(
                context,
              ).push(MaterialPageRoute(builder: (_) => const DownloadsPage())),
            ),
            ListTile(
              leading: const Icon(Icons.upload_outlined),
              title: Text(
                tr(
                  'پشتیبان‌گیری (نشانک‌ها و تنظیمات)',
                  'Backup (bookmarks and settings)',
                ),
              ),
              onTap: _export,
            ),
            ListTile(
              leading: const Icon(Icons.download_for_offline_outlined),
              title: Text(tr('بازیابی از پشتیبان', 'Restore from backup')),
              onTap: _import,
            ),
            _sec(
              'v2ray / VPN',
              Icons.vpn_lock_rounded,
              const Color(0xFF10B981),
            ),
            ListTile(
              leading: Icon(
                v2ray.connected ? Icons.shield_rounded : Icons.shield_outlined,
                color: v2ray.connected ? Colors.greenAccent : null,
              ),
              title: Text(
                tr(
                  'v2ray (VPN برای کل گوشی)',
                  'v2ray (VPN for the whole phone)',
                ),
              ),
              subtitle: Text(
                v2ray.connected
                    ? tr(
                        'متصل: ${v2ray.selected?.name ?? ''}',
                        'Connected: ${v2ray.selected?.name ?? ''}',
                      )
                    : tr(
                        'کانفیگ، اشتراک و اتصال',
                        'Configs, subscriptions and connection',
                      ),
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute<void>(builder: (_) => const V2rayPage()),
              ),
            ),
            ListTile(
              leading: Icon(
                dnsMgr.on ? Icons.dns_rounded : Icons.dns_outlined,
                color: dnsMgr.on ? Colors.greenAccent : null,
              ),
              title: Text(
                tr('تغییر DNS (برای کل گوشی)', 'DNS changer (whole phone)'),
              ),
              subtitle: Text(
                dnsMgr.on
                    ? tr(
                        'فعال: ${dnsMgr.servers.join(', ')}',
                        'Active: ${dnsMgr.servers.join(', ')}',
                      )
                    : tr(
                        'شکن، الکترو، رادار، گوگل و …',
                        'Shecan, Electro, Radar, Google …',
                      ),
              ),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => Navigator.of(
                context,
              ).push(MaterialPageRoute<void>(builder: (_) => const DnsPage())),
            ),
            _sec(
              tr('دربارهٔ آبتین', 'About'),
              Icons.info_rounded,
              const Color(0xFF06B6D4),
            ),
            ListTile(
              title: Text(tr('آبتین نسخهٔ ۳٫۰', 'Abtin version 3.0')),
              subtitle: Text(
                tr(
                  'موتور وب: GeckoView (Firefox)',
                  'Web engine: GeckoView (Firefox)',
                ),
              ),
            ),
          ]),
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}

class _Sec extends StatelessWidget {
  const _Sec(this.title, this.icon, this.color);
  final String title;
  final IconData icon;
  final Color color;
  @override
  Widget build(BuildContext context) => const SizedBox.shrink();
}
