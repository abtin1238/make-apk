part of 'browser_page.dart';
// ignore_for_file: invalid_use_of_protected_member

extension _Chrome on _BrowserPageState {
  /// Icon shown for an empty "new tab" (instead of a '+' / letter).
  Widget _mapsIcon(double size) => ClipRRect(borderRadius: BorderRadius.circular(size * .22), child: AbtinLogo(size: size));

  Widget _fav(BrowserTab t, {double size = 18}) {
    if (t.isNewTab && !t.private) return _mapsIcon(size);
    final f = t.faviconUrl ?? (t.private ? null : app.faviconFor(t.url.isNotEmpty ? t.url : (t.lazyUrl ?? '')));
    if (f != null && f.isNotEmpty) return _iconFrom(f, t.displayTitle, size);
    if (t.private) return Icon(Icons.visibility_off, size: size, color: const Color(0xFFB794F6));
    return _letter(t.displayTitle.isEmpty ? '+' : t.displayTitle, size);
  }

  Widget _iconFrom(String f, String title, double size) => siteIconFrom(f, title, size);

  Widget _siteIcon(String url, String title, double size) => SiteIcon(url, title: title, size: size);

  Widget _letter(String s, double size) => siteLetter(s, size);

  // ---------------- tab strip ----------------
  /// Tabs keep a fixed minimum width; with many tabs the strip scrolls horizontally.
  /// Tab strip + address bar drawn as ONE piece: the selected tab has the same colour as the toolbar below it.
  Color _activeFill() {
    final cs = Theme.of(context).colorScheme;
    final accent = current.private ? const Color(0xFF8B5CF6) : cs.primary;
    return Color.alphaBlend(accent.withValues(alpha: Theme.of(context).brightness == Brightness.dark ? .30 : .22), cs.surface);
  }

  Widget _topChrome() {
    final cs = Theme.of(context).colorScheme;
    final strip = Color.alphaBlend(cs.onSurface.withValues(alpha: .07), cs.surface);
    return Column(mainAxisSize: MainAxisSize.min, children: [
      Container(color: strip, padding: const EdgeInsets.only(top: 2), child: _tabStrip()),
      Container(color: _activeFill(), padding: const EdgeInsets.only(top: 3, bottom: 2), child: _addressBar()),
    ]);
  }

  Widget _tabStrip() {
    return SizedBox(
      height: 32,
      child: Row(children: [
        Expanded(
          child: LayoutBuilder(builder: (ctx, box) {
            final n = tabs.length;
            // Fixed-size tabs (never shrink): few tabs share the width, many tabs scroll sideways by touch.
            const minW = 110.0, maxW = 150.0;
            final w = (box.maxWidth / n).clamp(minW, maxW).toDouble();
            // Bring the selected tab (or a newly opened one) into view.
            if (_lastCur != cur || _lastTabCount != n) {
              final grew = n > _lastTabCount;
              _lastCur = cur; _lastTabCount = n;
              WidgetsBinding.instance.addPostFrameCallback((_) {
                if (!tabScroll.hasClients) return;
                final pos = tabScroll.position;
                final target = grew && cur == n - 1 ? pos.maxScrollExtent : (cur * w - (box.maxWidth - w) / 2).clamp(0.0, pos.maxScrollExtent);
                tabScroll.animateTo(target.toDouble(), duration: const Duration(milliseconds: 220), curve: Curves.easeOut);
              });
            }
            return ListView.builder(
              controller: tabScroll,
              scrollDirection: Axis.horizontal, itemCount: n,
              physics: const BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
              itemExtent: w,
              itemBuilder: (_, i) => _tabChip(tabs[i], i == cur, w),
            );
          }),
        ),
        InkWell(onTap: () => openTab(''), borderRadius: BorderRadius.circular(10), child: const SizedBox(width: 30, height: 30, child: Icon(Icons.add, size: 18))),
      ]),
    );
  }

  Widget _tabChip(BrowserTab t, bool sel, double w) {
    final cs = Theme.of(context).colorScheme;
    final g = t.groupId == null ? null : app.groups.where((x) => x.id == t.groupId).firstOrNull;
    final close = InkWell(
      onTap: () => closeTab(t), borderRadius: BorderRadius.circular(10),
      child: const Padding(padding: EdgeInsets.all(4), child: Icon(Icons.close, size: 14)),
    );
    final stripColor = g != null ? Color(g.color) : null;
    return GestureDetector(
      onTap: () => selectTab(t),
      child: Container(
        margin: const EdgeInsets.fromLTRB(2, 3, 2, 0),
        padding: const EdgeInsetsDirectional.only(start: 8),
        decoration: BoxDecoration(
          color: sel ? _activeFill() : Colors.transparent,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(10)),
        ),
        child: Stack(children: [
          if (stripColor != null) Positioned(left: 8, right: 8, top: 0, height: 2, child: DecoratedBox(decoration: BoxDecoration(color: stripColor, borderRadius: BorderRadius.circular(2)))),
          Row(mainAxisAlignment: MainAxisAlignment.start, children: [
            _fav(t, size: 16),
            ...[
              const SizedBox(width: 5),
              Expanded(child: Text(t.isNewTab ? tr('تب جدید', 'New tab') : t.displayTitle, maxLines: 1, overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 12, fontWeight: sel ? FontWeight.w600 : FontWeight.normal, color: sel ? null : cs.onSurface.withValues(alpha: .7)))),
            ],
            close,
          ]),
        ]),
      ),
    );
  }

  // ---------------- address bar ----------------
  Widget _barBtn(IconData i, VoidCallback? f, {double size = 20}) => IconButton(
        onPressed: f, icon: Icon(i, size: size), padding: EdgeInsets.zero,
        constraints: const BoxConstraints.tightFor(width: 34, height: 32), visualDensity: VisualDensity.compact,
      );

  /// The button next to the menu. What it does is chosen in Settings > Appearance (or it can be hidden).
  Widget _topButton() {
    final t = current;
    final mode = app.str('topBtn');
    final page = t.started && !t.showHome;
    final web = page && t.url.startsWith('http');
    switch (mode) {
      case 'none':
        return const SizedBox(width: 4);
      case 'newtab':
        return _barBtn(Icons.add_rounded, () => openTab(''));
      case 'private':
        return _barBtn(Icons.visibility_off_outlined, () => openTab('', private: true), size: 20);
      case 'home':
        return _barBtn(Icons.home_outlined, page ? () { setState(() => t.showHome = true); _syncAddr(); } : null);
      case 'reload':
        return _barBtn(t.loading ? Icons.close : Icons.refresh, page ? () => gecko.call(t.loading ? 'stop' : 'reload', {'id': t.nid}) : null);
      case 'bookmark':
        return _barBtn(app.isBookmarked(t.url) ? Icons.star : Icons.star_border, web ? () {
          setState(() => app.toggleBookmark(t.url, t.title));
          toast(app.isBookmarked(t.url) ? tr('به نشانک‌ها افزوده شد', 'Bookmarked') : tr('از نشانک‌ها حذف شد', 'Bookmark removed'));
        } : null);
      case 'vpn':
        return _vpnButton();
      case 'share':
        return _barBtn(Icons.share_outlined, page ? () => Share.share(t.url) : null, size: 20);
      case 'reader':
        return _barBtn(Icons.chrome_reader_mode_outlined, page && !t.failed ? _toggleReader : null, size: 20);
      case 'video':
        return _barBtn(Icons.smart_display_outlined, page ? _openMediaSheet : null, size: 21);
      case 'qr':
        return _barBtn(Icons.qr_code_scanner_rounded, _scanQr, size: 21);
      case 'bookmarks':
        return _barBtn(Icons.bookmarks_outlined, _openBookmarks, size: 20);
      case 'downloads':
        return _barBtn(Icons.download_outlined, _openDownloads, size: 20);
      case 'screenshot':
        return _barBtn(Icons.photo_camera_outlined, page ? _takeScreenshot : null, size: 20);
      case 'desktop':
        return _barBtn(Icons.desktop_windows_outlined, page ? () { setState(() => t.desktop = !t.desktop); gecko.call('setDesktop', {'id': t.nid, 'desktop': t.desktop}); } : null, size: 20);
      case 'find':
        return _barBtn(Icons.find_in_page_outlined, page ? () => setState(() => finding = true) : null, size: 20);
      case 'settings':
        return _barBtn(Icons.settings_outlined, _openSettings, size: 20);
      case 'tabs':
      default:
        final cs = Theme.of(context).colorScheme;
        return InkWell(
          onTap: _openSwitcher, borderRadius: BorderRadius.circular(8),
          child: Container(
            width: 24, height: 24, margin: const EdgeInsets.symmetric(horizontal: 5), alignment: Alignment.center,
            decoration: BoxDecoration(border: Border.all(color: cs.onSurface.withValues(alpha: .8), width: 1.5), borderRadius: BorderRadius.circular(7)),
            child: Text('${tabs.length}', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
          ),
        );
    }
  }

  /// VPN on/off in the top bar: tap = connect with the selected config / disconnect.
  Widget _vpnButton() {
    final cs = Theme.of(context).colorScheme;
    final on = v2ray.connected, busy = v2ray.connecting;
    return IconButton(
      onPressed: () async {
        if (v2ray.connected || v2ray.connecting) { await v2ray.disconnect(); toast(tr('VPN قطع شد', 'VPN off')); return; }
        final e = await v2ray.connect();
        if (e == 'no_profile') { toast(tr('ابتدا یک کانفیگ اضافه و انتخاب کنید', 'Add and select a config first')); }
        else if (e == 'vpn_denied') { toast(tr('مجوز VPN داده نشد', 'VPN permission was denied')); }
        else if (e != null) { toast(tr('شروع اتصال ناموفق بود', 'Could not start the connection')); }
      },
      icon: busy
          ? SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: cs.primary))
          : Icon(on ? Icons.vpn_key : Icons.vpn_key_off_outlined, size: 20, color: on ? Colors.greenAccent.shade400 : null),
      tooltip: on ? tr('قطع VPN', 'Turn VPN off') : tr('روشن کردن VPN', 'Turn VPN on'),
      padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 34, height: 32), visualDensity: VisualDensity.compact,
    );
  }

  Future<void> _toggleReader() async {
    final t = current;
    final ok = await gecko.call<bool>('contentCmd', {'id': t.nid, 'cmd': {'cmd': 'reader', 'dark': app.dark, 'lang': app.lang}});
    if (ok != true) toast(tr('حالت خواندن برای این صفحه آماده نیست؛ چند ثانیه بعد دوباره امتحان کنید', 'Reader mode is not ready for this page yet'));
  }

  /// Inspect element: toggles the in-page inspector (tap an element to see / edit its attributes, styles, box model and HTML).
  Future<void> _inspectElement() async {
    final t = current;
    final ok = await gecko.call<bool>('contentCmd', {'id': t.nid, 'cmd': {'cmd': 'inspect', 'lang': app.lang}});
    if (ok != true) toast(tr('بازرسی المنت برای این صفحه آماده نیست؛ چند ثانیه بعد دوباره امتحان کنید', 'Inspector is not ready for this page yet'));
  }

  Widget _addressBar() {
    final t = current;
    IconData lockIcon; Color? lockColor;
    if (t.showHome) { lockIcon = Icons.search; lockColor = null; }
    else if (t.failed) { lockIcon = Icons.warning_amber_rounded; lockColor = Colors.orange; }
    else if (t.secure) { lockIcon = Icons.lock; lockColor = const Color(0xFF34C759); }
    else { lockIcon = Icons.lock_open; lockColor = Colors.redAccent; }
    return Padding(
      padding: const EdgeInsets.fromLTRB(2, 0, 2, 2),
      child: Row(children: [
        _barBtn(Icons.arrow_back, () async { if (await _back()) {} }),
        Expanded(
          child: Glass(
            radius: 16, borderColor: t.private ? const Color(0xFF8B5CF6) : null, borderWidth: t.private ? 1.4 : 1,
            child: Row(children: [
              IconButton(
                visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 30, height: 32),
                onPressed: t.showHome ? null : _siteInfo, icon: Icon(lockIcon, size: 15, color: lockColor),
              ),
              Expanded(
                child: TextField(
                  controller: addr, focusNode: addrFocus, textDirection: TextDirection.ltr, textInputAction: TextInputAction.go,
                  keyboardType: TextInputType.url, autocorrect: false, enableSuggestions: false, style: const TextStyle(fontSize: 14),
                  onChanged: _onAddrChanged, onSubmitted: (v) => navigate(current, v),
                  decoration: InputDecoration(border: InputBorder.none, isDense: true, hintText: tr('جست‌وجو یا وارد کردن آدرس', 'Search or enter address'), contentPadding: const EdgeInsets.symmetric(vertical: 6)),
                ),
              ),
              if (editing && addr.text.isNotEmpty)
                IconButton(visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 30, height: 32), onPressed: () { addr.clear(); _onAddrChanged(''); }, icon: const Icon(Icons.close, size: 17))
              else if (editing || t.showHome)
                IconButton(visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 30, height: 32), tooltip: tr('اسکن QR', 'Scan QR'), onPressed: _scanQr, icon: const Icon(Icons.qr_code_scanner_rounded, size: 19))
              else ...[
                if (t.media.isNotEmpty)
                  IconButton(
                    visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 34, height: 32), tooltip: tr('ویدیوهای صفحه', 'Page videos'),
                    onPressed: _openMediaSheet,
                    icon: Badge(label: Text('${t.media.length}', style: const TextStyle(fontSize: 9)), child: Icon(Icons.smart_display_rounded, size: 21, color: Theme.of(context).colorScheme.primary)),
                  ),
                IconButton(visualDensity: VisualDensity.compact, padding: EdgeInsets.zero, constraints: const BoxConstraints.tightFor(width: 30, height: 32), onPressed: () => gecko.call(t.loading ? 'stop' : 'reload', {'id': t.nid}), icon: Icon(t.loading ? Icons.close : Icons.refresh, size: 18)),
              ],
            ]),
          ),
        ),
        _topButton(),
        _barBtn(Icons.more_vert, _openMenu),
      ]),
    );
  }

  Color? _cssColor(String? c) {
    if (c == null) return null;
    var h = c.trim();
    if (!h.startsWith('#')) return null;
    h = h.substring(1);
    if (h.length == 3) h = h.split('').map((x) => '$x$x').join();
    if (h.length != 6) return null;
    final v = int.tryParse(h, radix: 16);
    return v == null ? null : Color(0xFF000000 | v);
  }

  Widget _progressBar() {
    final t = current;
    return SizedBox(height: 2, child: t.loading && t.progress > 0 && t.progress < 1 ? LinearProgressIndicator(value: t.progress, minHeight: 2) : null);
  }

  // ---------------- suggestions ----------------
  void _onAddrChanged(String v) {
    _sugT?.cancel();
    setState(() {});
    if (v.trim().isEmpty) { setState(() => sugg = []); return; }
    _sugT = Timer(const Duration(milliseconds: 180), () async {
      final q = v.trim().toLowerCase();
      final local = <Suggestion>[];
      for (final b in app.bookmarks) {
        if (local.length >= 3) break;
        if (b.url.toLowerCase().contains(q) || b.title.toLowerCase().contains(q)) local.add(Suggestion('bookmark', b.title, b.url));
      }
      for (final h in app.history) {
        if (local.length >= 6) break;
        if ((h.url.toLowerCase().contains(q) || h.title.toLowerCase().contains(q)) && !local.any((x) => x.url == h.url)) local.add(Suggestion('history', h.title, h.url));
      }
      if (!mounted) return;
      setState(() => sugg = [Suggestion('search', v.trim(), v.trim()), ...local]);
      final se = engines[app.str('engine')]!;
      if (app.flag('suggest') && !current.private && se.suggest.isNotEmpty) {
        try {
          final r = await _dio.get<String>(se.suggest.replaceFirst('%s', Uri.encodeComponent(v)), options: Options(responseType: ResponseType.plain, receiveTimeout: const Duration(seconds: 2), sendTimeout: const Duration(seconds: 2)));
          final j = jsonDecode(r.data ?? '[]');
          if (j is List && j.length > 1 && j[1] is List && mounted && addr.text == v) {
            final web = (j[1] as List).take(5).map((e) => Suggestion('web', '$e', '$e')).toList();
            setState(() => sugg = [sugg.first, ...web, ...sugg.skip(1)]);
          }
        } catch (_) {}
      }
    });
  }

  Widget _suggestionsPanel() => Positioned.fill(
        child: GlassBackground(child: Material(
          type: MaterialType.transparency,
          child: sugg.isEmpty
              ? const SizedBox()
              : ListView.builder(
                  keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag, itemCount: sugg.length,
                  itemBuilder: (_, i) {
                    final s = sugg[i];
                    final icon = {'search': Icons.search, 'web': Icons.search, 'history': Icons.history, 'bookmark': Icons.star_border}[s.type]!;
                    return ListTile(
                      dense: true, leading: Icon(icon, size: 20),
                      title: Text(s.type == 'search' ? s.title : s.title.isEmpty ? s.url : s.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: s.type == 'history' || s.type == 'bookmark' ? Text(s.url, maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr) : null,
                      trailing: IconButton(icon: const Icon(Icons.north_west, size: 16), onPressed: () { addr.text = s.url; addr.selection = TextSelection.collapsed(offset: addr.text.length); _onAddrChanged(addr.text); }),
                      onTap: () => navigate(current, s.url),
                    );
                  },
                ),
        )),
      );

  // ---------------- find in page ----------------
  void _closeFind() {
    gecko.call('findClear', {'id': current.nid});
    setState(() { finding = false; findCount = 0; findIdx = 0; });
    findCtl.clear();
  }

  Widget _findBar() => Glass(
        radius: 18, margin: const EdgeInsets.fromLTRB(8, 4, 8, 6),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Row(children: [
            Expanded(child: TextField(controller: findCtl, autofocus: true, decoration: InputDecoration(hintText: tr('جست‌وجو در صفحه', 'Find in page'), border: InputBorder.none), onChanged: (v) => v.isEmpty ? gecko.call('findClear', {'id': current.nid}) : gecko.call('find', {'id': current.nid, 'text': v, 'backwards': false}))),
            Text(findCount == 0 ? '0' : '$findIdx/$findCount', style: const TextStyle(fontSize: 12)),
            IconButton(onPressed: () => gecko.call('find', {'id': current.nid, 'text': findCtl.text, 'backwards': true}), icon: const Icon(Icons.keyboard_arrow_up)),
            IconButton(onPressed: () => gecko.call('find', {'id': current.nid, 'text': findCtl.text, 'backwards': false}), icon: const Icon(Icons.keyboard_arrow_down)),
            IconButton(onPressed: _closeFind, icon: const Icon(Icons.close)),
          ]),
        ),
      );

  // ---------------- home / error ----------------
  Widget _home(BrowserTab t) {
    final cs = Theme.of(context).colorScheme;
    if (t.private) {
      Widget row(IconData i, String s) => Container(
            margin: const EdgeInsets.only(top: 10), padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(14)),
            child: Row(children: [Icon(i, color: const Color(0xFFB794F6)), const SizedBox(width: 12), Expanded(child: Text(s))]),
          );
      return GlassBackground(child: Padding(
        padding: const EdgeInsets.all(24),
        child: ListView(children: [
          const SizedBox(height: 30),
          const Icon(Icons.visibility_off, size: 72, color: Color(0xFFB794F6)),
          const SizedBox(height: 14),
          Center(child: Text(tr('حالت ناشناس', 'Private mode'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold))),
          const SizedBox(height: 10),
          Text(tr('هیچ تاریخچه‌ای ذخیره نمی‌شود و کوکی‌های ساخته‌شده در این نشست هنگام بستن تب پاک می‌شوند.', 'No history is saved, and cookies created in this session are removed when the tab closes.'), textAlign: TextAlign.center),
          const SizedBox(height: 18),
          row(Icons.history_toggle_off, tr('عدم ذخیرهٔ تاریخچه', 'No history saved')),
          row(Icons.cookie_outlined, tr('پاک‌سازی کوکی‌های نشست', 'Session cookies cleared')),
          row(Icons.gpp_good_outlined, tr('محافظت در برابر ردیاب‌ها', 'Tracker protection')),
        ]),
      ));
    }
    Widget tile(IconData i, String s, VoidCallback f) => ListTile(dense: true, leading: Icon(i, color: cs.primary), title: Text(s), onTap: f);
    final mv = app.mostVisited(4);
    return GlassBackground(
      child: ListView(padding: const EdgeInsets.fromLTRB(16, 20, 16, 30), children: [
        Center(child: _mapsIcon(64)),
        const SizedBox(height: 8),
        Center(child: Text('آبتین', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: cs.onSurface))),
        const SizedBox(height: 16),
        InkWell(
          onTap: () => addrFocus.requestFocus(), borderRadius: BorderRadius.circular(26),
          child: Glass(
            radius: 26, padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            child: Row(children: [const Icon(Icons.search), const SizedBox(width: 10), Text('${tr('جست‌وجو در', 'Search with')} ${engines[app.str('engine')]!.name}', style: TextStyle(color: cs.onSurface.withValues(alpha: .6)))]),
          ),
        ),
        const SizedBox(height: 20),
        GridView.count(
          crossAxisCount: 4, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), childAspectRatio: .85,
          children: [
            for (var i = 0; i < app.dials.length; i++) _dial(app.dials[i], i),
            InkWell(onTap: _addDialDialog, child: Column(children: [
              Container(width: 52, height: 52, decoration: BoxDecoration(color: Theme.of(context).cardColor, borderRadius: BorderRadius.circular(16)), child: const Icon(Icons.add)),
              const SizedBox(height: 6), Text(tr('افزودن', 'Add'), style: const TextStyle(fontSize: 12)),
            ])),
          ],
        ),
        if (mv.isNotEmpty) ...[
          Padding(padding: const EdgeInsets.only(top: 12, bottom: 4), child: Text(tr('پربازدیدها', 'Most visited'), style: const TextStyle(fontWeight: FontWeight.bold))),
          for (final h in mv) ListTile(dense: true, leading: _siteIcon(h.url, hostOf(h.url), 30), title: Text(h.title, maxLines: 1, overflow: TextOverflow.ellipsis), subtitle: Text(hostOf(h.url), maxLines: 1), onTap: () => navigate(t, h.url)),
        ],
        const SizedBox(height: 12),
        GlassCard(margin: EdgeInsets.zero, child: Column(children: [
          tile(Icons.star_border, tr('نشانک‌ها', 'Bookmarks'), _openBookmarks),
          tile(Icons.history, tr('تاریخچه', 'History'), _openHistory),
          tile(Icons.download_outlined, tr('دانلودها', 'Downloads'), _openDownloads),
          tile(Icons.extension_outlined, tr('افزونه‌ها', 'Extensions'), _openExtensions),
          tile(Icons.settings_outlined, tr('تنظیمات', 'Settings'), _openSettings),
        ])),
      ]),
    );
  }

  Widget _dial(SpeedDial d, int i) => InkWell(
        onTap: () => navigate(current, d.url),
        onLongPress: () async {
          final del = await _ask(tr('حذف میان‌بر؟', 'Remove shortcut?'), d.title);
          if (del) { setState(() => app.dials.removeAt(i)); app.saveDials(); }
        },
        child: Column(children: [
          _siteIcon(d.url, d.title, 52),
          const SizedBox(height: 6), Text(d.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
        ]),
      );

  Future<void> _addDialDialog({String? title, String? url}) async {
    final t = TextEditingController(text: title), u = TextEditingController(text: url);
    final ok = await showGlassDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('افزودن میان‌بر', 'Add shortcut')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: t, decoration: InputDecoration(labelText: tr('عنوان', 'Title'))),
          TextField(controller: u, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'URL')),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), TextButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('افزودن', 'Add')))],
      ),
    );
    if (ok == true && u.text.trim().isNotEmpty) {
      var url2 = u.text.trim();
      if (!url2.contains('://')) url2 = 'https://$url2';
      setState(() => app.dials.add(SpeedDial(t.text.trim().isEmpty ? hostOf(url2) : t.text.trim(), url2)));
      app.saveDials();
    }
  }
}
