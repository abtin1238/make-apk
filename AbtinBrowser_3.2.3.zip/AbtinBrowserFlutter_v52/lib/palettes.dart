/// Selectable glass themes. Colors are plain ARGB ints so this file has no dependencies.
class AbtinPalette {
  const AbtinPalette(this.id, this.fa, this.en, this.dark, this.bg, this.blobs, this.accent);
  final String id, fa, en;
  final bool dark;
  final List<int> bg;    // 3-stop background gradient
  final List<int> blobs; // 3 soft glows painted over the gradient
  final int accent;
}

const palettes = <AbtinPalette>[
  AbtinPalette('ocean', 'اقیانوس', 'Ocean', true,
      [0xFF03102A, 0xFF0A2A5E, 0xFF06304F], [0xFF3B82F6, 0xFF06B6D4, 0xFF8B5CF6], 0xFF4C8DFF),
  AbtinPalette('aurora', 'شفق', 'Aurora', true,
      [0xFF110828, 0xFF2B1160, 0xFF0B2E4A], [0xFF8B5CF6, 0xFFEC4899, 0xFF22D3EE], 0xFFA78BFA),
  AbtinPalette('sunset', 'غروب', 'Sunset', true,
      [0xFF2B0F20, 0xFF54173A, 0xFF3D1A0A], [0xFFFF7A45, 0xFFEC4899, 0xFFFBBF24], 0xFFFF8A5B),
  AbtinPalette('forest', 'جنگل', 'Forest', true,
      [0xFF03211B, 0xFF0A3F31, 0xFF0A2C3C], [0xFF10B981, 0xFF34D399, 0xFF06B6D4], 0xFF34D399),
  AbtinPalette('neon', 'نئون', 'Neon', true,
      [0xFF05040E, 0xFF14062B, 0xFF021D22], [0xFF00E5FF, 0xFFFF2BD6, 0xFF7C3AED], 0xFF22E3FF),
  AbtinPalette('midnight', 'نیمه‌شب', 'Midnight', true,
      [0xFF000000, 0xFF060912, 0xFF02030A], [0xFF3B82F6, 0xFF6D28D9, 0xFF0EA5E9], 0xFF6EA8FF),
  AbtinPalette('ice', 'یخ', 'Ice', false,
      [0xFFEAF3FF, 0xFFD6E7FF, 0xFFE9F8FF], [0xFF60A5FA, 0xFF22D3EE, 0xFFA78BFA], 0xFF2563EB),
  AbtinPalette('blossom', 'شکوفه', 'Blossom', false,
      [0xFFFFEFF6, 0xFFF2E6FF, 0xFFFFF0E4], [0xFFF472B6, 0xFFC084FC, 0xFFFB923C], 0xFFDB2777),
  AbtinPalette('mint', 'نعنا', 'Mint', false,
      [0xFFE7FFF5, 0xFFD5F4FF, 0xFFF1FFE6], [0xFF34D399, 0xFF38BDF8, 0xFFA3E635], 0xFF059669),
  AbtinPalette('amoled', 'مشکی خالص', 'AMOLED Black', true,
      [0xFF000000, 0xFF000000, 0xFF050505], [0xFF2563EB, 0xFF7C3AED, 0xFF0891B2], 0xFF5B9DFF),
  AbtinPalette('graphite', 'گرافیت', 'Graphite', true,
      [0xFF101214, 0xFF1B1F24, 0xFF14171B], [0xFF64748B, 0xFF94A3B8, 0xFF475569], 0xFF9DB4D0),
  AbtinPalette('ruby', 'یاقوت', 'Ruby', true,
      [0xFF1F0509, 0xFF4A0B16, 0xFF2A0A12], [0xFFEF4444, 0xFFF43F5E, 0xFFFB7185], 0xFFFF5A70),
  AbtinPalette('gold', 'طلایی', 'Gold', true,
      [0xFF1A1204, 0xFF3A2808, 0xFF2A1C06], [0xFFF59E0B, 0xFFFACC15, 0xFFEA580C], 0xFFFBBF24),
  AbtinPalette('coffee', 'قهوه‌ای', 'Coffee', true,
      [0xFF150E0A, 0xFF2E1D14, 0xFF1F1410], [0xFFA16207, 0xFFB45309, 0xFFD6A370], 0xFFD6A370),
  AbtinPalette('turquoise', 'فیروزه‌ای', 'Turquoise', true,
      [0xFF021A1C, 0xFF053C40, 0xFF03282D], [0xFF14B8A6, 0xFF22D3EE, 0xFF2DD4BF], 0xFF2DD4BF),
  AbtinPalette('lavender', 'اسطوخودوس', 'Lavender', false,
      [0xFFF3EEFF, 0xFFE6DDFF, 0xFFF6F0FF], [0xFFA78BFA, 0xFFC4B5FD, 0xFFF0ABFC], 0xFF7C3AED),
  AbtinPalette('sand', 'ماسه', 'Sand', false,
      [0xFFFFF8EC, 0xFFF6E8CF, 0xFFFFF3DD], [0xFFFBBF24, 0xFFF59E0B, 0xFFFDBA74], 0xFFB45309),
  AbtinPalette('sky', 'آسمان', 'Sky', false,
      [0xFFEAF6FF, 0xFFD2EBFF, 0xFFF0FAFF], [0xFF38BDF8, 0xFF7DD3FC, 0xFF60A5FA], 0xFF0284C7),
  AbtinPalette('peach', 'هلو', 'Peach', false,
      [0xFFFFF1EA, 0xFFFFE1D3, 0xFFFFF5EE], [0xFFFB923C, 0xFFFDA4AF, 0xFFFCD34D], 0xFFEA580C),
];
