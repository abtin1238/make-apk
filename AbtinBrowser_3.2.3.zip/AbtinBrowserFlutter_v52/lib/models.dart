import 'dart:typed_data';

int _nid = 1;
int _now() => DateTime.now().millisecondsSinceEpoch;

String hostOf(String url) {
  try { return Uri.parse(url).host; } catch (_) { return url; }
}

class HistoryEntry {
  HistoryEntry(this.url, this.title, {int? time, this.visits = 1}) : time = time ?? _now();
  String url, title;
  int time, visits;
  Map<String, dynamic> toJson() => {'u': url, 't': title, 'd': time, 'v': visits};
  factory HistoryEntry.fromJson(Map<String, dynamic> j) =>
      HistoryEntry('${j['u']}', '${j['t']}', time: (j['d'] as num?)?.toInt(), visits: (j['v'] as num?)?.toInt() ?? 1);
}

class Bookmark {
  Bookmark(this.url, this.title, {this.folder = '', int? time}) : time = time ?? _now();
  String url, title, folder;
  int time;
  Map<String, dynamic> toJson() => {'u': url, 't': title, 'f': folder, 'd': time};
  factory Bookmark.fromJson(Map<String, dynamic> j) =>
      Bookmark('${j['u']}', '${j['t']}', folder: '${j['f'] ?? ''}', time: (j['d'] as num?)?.toInt());
}

class DownloadItem {
  DownloadItem({required this.id, required this.url, required this.name, this.path, this.total = -1, this.received = 0, this.status = 'running', int? time, this.private = false})
      : time = time ?? _now();
  final String id;
  final String url;
  String name;
  String? path;
  int total, received, time;
  String status; // running | done | failed | canceled
  final bool private;
  double speed = 0; // bytes/s
  int conns = 0;
  bool resumable = false;
  bool get native => !id.startsWith('x');
  /// Managed (segmented) native downloads can be paused; ids start with 'n'.
  bool get canPause => status == 'running' && id.startsWith('n');
  double get fraction => total > 0 ? (received / total).clamp(0.0, 1.0) : 0;
  Map<String, dynamic> toJson() => {'id': id, 'u': url, 'n': name, 'p': path, 'tot': total, 'rec': received, 's': status, 'd': time};
  factory DownloadItem.fromJson(Map<String, dynamic> j) => DownloadItem(
      id: '${j['id']}', url: '${j['u']}', name: '${j['n']}', path: j['p'] as String?, total: (j['tot'] as num?)?.toInt() ?? -1,
      received: (j['rec'] as num?)?.toInt() ?? 0, status: (j['s'] == 'running' || j['s'] == 'paused') ? ((j['p'] != null && '${j['u']}'.startsWith('http') && !'${j['id']}'.startsWith('x')) ? 'paused' : 'failed') : '${j['s']}', time: (j['d'] as num?)?.toInt());
}

/// A playable stream found on a page (kind: video | audio | hls; part: '' | video | audio for separate DASH tracks).
class MediaItem {
  MediaItem({required this.url, required this.kind, this.part = '', this.mime = '', this.size = -1, this.page = '', this.title = '', this.poster = '', this.ts = 0});
  final String url, kind, part, mime, page, title, poster;
  int size;
  final int ts; // when the stream was first seen (ms since epoch)

  String get ext {
    final path = url.split('#').first.split('?').first.toLowerCase();
    final dot = path.lastIndexOf('.');
    if (dot > 0) {
      final e = path.substring(dot + 1);
      if (const {'mp4', 'm4v', 'webm', 'mkv', 'mov', 'mp3', 'm4a', 'ogg', 'oga', 'opus', 'flac', 'wav'}.contains(e)) return e;
    }
    final mm = mime.toLowerCase();
    if (mm.contains('webm')) return mm.startsWith('audio') ? 'weba' : 'webm';
    if (mm.startsWith('audio/mpeg')) return 'mp3';
    if (mm.startsWith('audio/')) return 'm4a';
    return kind == 'audio' ? 'm4a' : 'mp4';
  }

  String get label {
    try {
      final seg = Uri.parse(url).pathSegments.where((s) => s.isNotEmpty).toList();
      if (seg.isNotEmpty) return Uri.decodeComponent(seg.last);
    } catch (_) {}
    return hostOf(url);
  }
}

class SpeedDial {
  SpeedDial(this.title, this.url);
  String title, url;
  Map<String, dynamic> toJson() => {'t': title, 'u': url};
  factory SpeedDial.fromJson(Map<String, dynamic> j) => SpeedDial('${j['t']}', '${j['u']}');
}

class TabGroup {
  TabGroup(this.id, this.name, this.color);
  final String id;
  String name;
  int color;
  Map<String, dynamic> toJson() => {'id': id, 'n': name, 'c': color};
  factory TabGroup.fromJson(Map<String, dynamic> j) => TabGroup('${j['id']}', '${j['n']}', (j['c'] as num?)?.toInt() ?? 0xFF3977F6);
}

class Suggestion {
  Suggestion(this.type, this.title, this.url);
  final String type; // search | web | history | bookmark
  final String title, url;
}

class BrowserTab {
  /// [nativeId] is set for tabs created by the engine itself (window.open, extensions).
  BrowserTab({this.url = '', this.title = '', this.private = false, this.groupId, int? nativeId, this.started = false})
      : nid = nativeId ?? _nid++;
  final int nid;
  String get id => 'tab$nid';
  String url, title;
  final bool private;
  String? groupId;
  Uint8List? thumb;
  String? faviconUrl, themeColor, pageColor;
  bool started;
  /// Streams the page loaded (filled by the built-in extension); [mediaBlob] = the page plays a blob: source we cannot read.
  final List<MediaItem> media = [];
  bool mediaBlob = false;
  bool showHome = true, loading = false, desktop = false;
  /// Opened from an installed web app (PWA) shortcut: shown full-screen without tab strip / address bar.
  bool pwa = false;
  /// The page's origin has a registered service worker (reported by the core extension; [swHost] = which host it was measured on).
  bool hasSw = false;
  String swHost = '';
  bool canBack = false, canForward = false, secure = false, failed = false;
  double progress = 0;
  int blocked = 0;
  String? lazyUrl;
  /// Serialized engine history (back/forward list) used to restore the tab after a restart.
  String? state;
  /// A really empty "new tab". A tab restored from the last session / freed from memory is not one: it has a [lazyUrl] and
  /// keeps its site name and icon until it is woken up.
  bool get isNewTab => showHome && lazyUrl == null;
  String get displayTitle {
    if (title.isNotEmpty) return title;
    final u = url.isNotEmpty ? url : (lazyUrl ?? '');
    return u.isEmpty ? '' : hostOf(u);
  }
}
