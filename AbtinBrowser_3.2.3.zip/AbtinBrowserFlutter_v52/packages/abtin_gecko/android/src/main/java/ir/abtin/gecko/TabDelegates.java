package ir.abtin.gecko;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import org.mozilla.geckoview.AllowOrDeny;
import org.mozilla.geckoview.BasicSelectionActionDelegate;
import org.mozilla.geckoview.ContentBlocking;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.WebRequestError;
import org.mozilla.geckoview.WebResponse;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Installs and implements every per-session delegate for one tab. */
final class TabDelegates {
    private final Engine e;
    private final Tab t;

    TabDelegates(Engine e, Tab t) { this.e = e; this.t = t; }

    void install() {
        final GeckoSession s = t.session;
        s.setProgressDelegate(progress);
        s.setNavigationDelegate(navigation);
        s.setContentDelegate(content);
        s.setPermissionDelegate(permission);
        s.setPromptDelegate(e.prompts);
        s.setHistoryDelegate(history);
        s.setContentBlockingDelegate(blocking);
        if (e.activity != null) s.setSelectionActionDelegate(new BasicSelectionActionDelegate(e.activity));
    }

    private Map<String, Object> ev(String type) { return Engine.ev(type, t.id); }

    // ------------------------------------------------------------------ progress
    private final GeckoSession.ProgressDelegate progress = new GeckoSession.ProgressDelegate() {
        @Override public void onSessionStateChange(@NonNull GeckoSession session, @NonNull GeckoSession.SessionState state) {
            t.sessionState = state;
            t.stateDirty = true;
        }

        @Override public void onPageStart(@NonNull GeckoSession session, @NonNull String url) {
            t.blocked = 0;
            final Map<String, Object> m = ev("loadStart");
            m.put("url", url);
            e.emit(m);
        }

        @Override public void onPageStop(@NonNull GeckoSession session, boolean success) {
            final Map<String, Object> m = ev("loadStop");
            m.put("ok", success);
            e.emit(m);
        }

        @Override public void onProgressChange(@NonNull GeckoSession session, int p) {
            final Map<String, Object> m = ev("progress");
            m.put("p", p);
            e.emit(m);
        }

        @Override public void onSecurityChange(@NonNull GeckoSession session, @NonNull SecurityInformation info) {
            final Map<String, Object> m = ev("security");
            m.put("secure", info.isSecure);
            m.put("host", info.host);
            e.emit(m);
        }
    };

    // ------------------------------------------------------------------ navigation
    private final GeckoSession.NavigationDelegate navigation = new GeckoSession.NavigationDelegate() {
        @Override
        public void onLocationChange(@NonNull GeckoSession session, @Nullable String url,
                                     @NonNull List<GeckoSession.PermissionDelegate.ContentPermission> perms, @NonNull Boolean gesture) {
            if (url == null) return;
            final Map<String, Object> m = ev("url");
            if (url.startsWith("data:text/html") && t.failedUri != null) {
                m.put("url", t.failedUri);
                m.put("error", true);
            } else {
                t.failedUri = null;
                t.url = url;
                m.put("url", url);
                m.put("error", false);
            }
            e.emit(m);
        }

        @Override public void onCanGoBack(@NonNull GeckoSession session, boolean can) {
            final Map<String, Object> m = ev("nav");
            m.put("back", can);
            e.emit(m);
        }

        @Override public void onCanGoForward(@NonNull GeckoSession session, boolean can) {
            final Map<String, Object> m = ev("nav");
            m.put("fwd", can);
            e.emit(m);
        }

        @Nullable @Override
        public GeckoResult<AllowOrDeny> onLoadRequest(@NonNull GeckoSession session, @NonNull LoadRequest req) {
            final Uri u = Uri.parse(req.uri);
            final String sc = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
            if (sc.equals("http") || sc.equals("https")) e.syncUa(t, u.getHost());
            switch (sc) {
                case "http": case "https": case "about": case "data": case "blob": case "javascript":
                case "moz-extension": case "view-source": case "ws": case "wss":
                    return GeckoResult.allow();
                case "file": case "content": case "chrome": case "resource": case "jar":
                    return GeckoResult.deny();
                case "intent": {
                    try {
                        final Intent it = Intent.parseUri(req.uri, Intent.URI_INTENT_SCHEME);
                        final String fb = it.getStringExtra("browser_fallback_url");
                        if (fb != null && (fb.startsWith("https://") || fb.startsWith("http://"))) {
                            e.main.post(() -> session.loadUri(fb));
                        }
                    } catch (Exception ignored) { }
                    return GeckoResult.deny();
                }
                default: {
                    final boolean direct = sc.equals("tel") || sc.equals("mailto") || sc.equals("sms");
                    if (!req.hasUserGesture && !direct && !req.isDirectNavigation) return GeckoResult.deny();
                    final Map<String, Object> a = new HashMap<>();
                    a.put("url", req.uri);
                    e.ask("external", a, v -> { });
                    return GeckoResult.deny();
                }
            }
        }

        @Nullable @Override
        public GeckoResult<GeckoSession> onNewSession(@NonNull GeckoSession session, @NonNull String uri) {
            final Tab nt = e.createForeignTab(t.privateMode);
            final Map<String, Object> m = Engine.ev("tabCreated", nt.id);
            m.put("url", uri);
            m.put("private", t.privateMode);
            m.put("opener", t.id);
            e.emit(m);
            return GeckoResult.fromValue(nt.session);
        }

        @Nullable @Override
        public GeckoResult<String> onLoadError(@NonNull GeckoSession session, @Nullable String uri, @NonNull WebRequestError error) {
            t.failedUri = uri;
            final Map<String, Object> m = ev("error");
            m.put("uri", uri);
            m.put("category", error.category);
            m.put("code", error.code);
            e.emit(m);
            if (uri != null && e.netAutoFallback(error.category, error.code)) {
                // Connection failed with HTTP/3 + IPv6 on: they are off now, retry the page once without them.
                final String retry = uri;
                new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> {
                    try { t.session.loadUri(retry); } catch (Throwable ignored) { }
                }, 300);
            }
            return GeckoResult.fromValue(ErrorPage.build(e.lang, e.dark, e.accent, uri, error));
        }
    };

    // ------------------------------------------------------------------ content
    private final GeckoSession.ContentDelegate content = new GeckoSession.ContentDelegate() {
        @Override public void onTitleChange(@NonNull GeckoSession session, @Nullable String title) {
            final Map<String, Object> m = ev("title");
            m.put("title", title == null ? "" : title);
            e.emit(m);
        }

        @Override public void onFullScreen(@NonNull GeckoSession session, boolean on) {
            final Map<String, Object> m = ev("fullscreen");
            m.put("on", on);
            e.emit(m);
        }

        @Override
        public void onContextMenu(@NonNull GeckoSession session, int x, int y, @NonNull ContextElement el) {
            if (el.linkUri == null && el.srcUri == null) return;
            final Map<String, Object> m = ev("contextMenu");
            m.put("link", el.linkUri);
            m.put("src", el.srcUri);
            m.put("type", el.type);
            m.put("title", el.title);
            m.put("text", linkText(el));
            e.emit(m);
        }

        /** Visible text of the long-pressed link (ContextElement.textContent; read by reflection so older GeckoView builds still compile). */
        private String linkText(ContextElement el) {
            String s = null;
            try {
                final Object v = ContextElement.class.getField("textContent").get(el);
                if (v instanceof String) s = (String) v;
            } catch (Throwable ignored) { }
            if (s == null || s.trim().isEmpty()) {
                try {
                    final Object v = ContextElement.class.getField("altText").get(el);
                    if (v instanceof String) s = (String) v;
                } catch (Throwable ignored) { }
            }
            if (s == null || s.trim().isEmpty()) s = el.title;
            return s == null ? "" : s.replaceAll("\\s+", " ").trim();
        }

        @Override public void onExternalResponse(@NonNull GeckoSession session, @NonNull WebResponse response) {
            e.downloads.handle(t, response);
        }

        @Override public void onCloseRequest(@NonNull GeckoSession session) {
            e.emit(ev("closeRequest"));
        }

        @Override public void onCrash(@NonNull GeckoSession session) { reopen(); }

        @Override public void onKill(@NonNull GeckoSession session) { reopen(); }

        private void reopen() {
            Log.w(Engine.TAG, "content process lost, tab " + t.id);
            // Background tabs (or the whole app in the background) are NOT reopened now: Android / MIUI killed them to free memory,
            // and starting every process again at once only gets them killed again (black page when coming back). They are
            // rebuilt, with their history, when shown.
            if (e.current != t || !e.appForeground) t.needsRestore = true;
            else e.recover(t);
            e.emit(ev("crash"));
        }

        private GeckoSession session() { return t.session; }
    };

    // ------------------------------------------------------------------ permissions
    private final GeckoSession.PermissionDelegate permission = new GeckoSession.PermissionDelegate() {
        @Override
        public void onAndroidPermissionsRequest(@NonNull GeckoSession session, @Nullable String[] perms, @NonNull Callback callback) {
            e.prompts.requestAndroidPermissions(perms, callback);
        }

        @Nullable @Override
        public GeckoResult<Integer> onContentPermissionRequest(@NonNull GeckoSession session, @NonNull ContentPermission perm) {
            String kind = null;
            switch (perm.permission) {
                case PERMISSION_GEOLOCATION: kind = "geolocation"; break;
                case PERMISSION_STORAGE_ACCESS: kind = "storage_access"; break;
                case PERMISSION_PERSISTENT_STORAGE:
                case PERMISSION_MEDIA_KEY_SYSTEM_ACCESS:
                    return GeckoResult.fromValue(ContentPermission.VALUE_ALLOW);
                default:
                    return GeckoResult.fromValue(ContentPermission.VALUE_PROMPT);
            }
            final GeckoResult<Integer> res = new GeckoResult<>();
            final Map<String, Object> a = new HashMap<>();
            a.put("host", Engine.hostOf(perm.uri));
            a.put("kind", kind);
            e.ask("permission", a, v -> {
                if ("allow".equals(v)) res.complete(ContentPermission.VALUE_ALLOW);
                else if ("block".equals(v)) res.complete(ContentPermission.VALUE_DENY);
                else res.complete(ContentPermission.VALUE_PROMPT);
            });
            return res;
        }

        @Override
        public void onMediaPermissionRequest(@NonNull GeckoSession session, @NonNull String uri, @Nullable MediaSource[] video,
                                             @Nullable MediaSource[] audio, @NonNull MediaCallback callback) {
            final Map<String, Object> a = new HashMap<>();
            a.put("host", Engine.hostOf(uri));
            a.put("video", video != null && video.length > 0);
            a.put("audio", audio != null && audio.length > 0);
            e.ask("mediaPermission", a, v -> {
                if (!(v instanceof Map)) { callback.reject(); return; }
                final Map<?, ?> r = (Map<?, ?>) v;
                final MediaSource vs = Boolean.TRUE.equals(r.get("video")) && video != null && video.length > 0 ? video[0] : null;
                final MediaSource as = Boolean.TRUE.equals(r.get("audio")) && audio != null && audio.length > 0 ? audio[0] : null;
                if (vs == null && as == null) callback.reject();
                else callback.grant(vs, as);
            });
        }
    };

    // ------------------------------------------------------------------ history (visited links)
    private final GeckoSession.HistoryDelegate history = new GeckoSession.HistoryDelegate() {
        @Nullable @Override
        public GeckoResult<boolean[]> getVisited(@NonNull GeckoSession session, @NonNull String[] urls) {
            final boolean[] r = new boolean[urls.length];
            for (int i = 0; i < urls.length; i++) r[i] = e.visited.contains(urls[i]);
            return GeckoResult.fromValue(r);
        }

        @Nullable @Override
        public GeckoResult<Boolean> onVisited(@NonNull GeckoSession session, @NonNull String url, @Nullable String last, int flags) {
            if (!t.privateMode) e.visited.add(url);
            return GeckoResult.fromValue(Boolean.TRUE);
        }
    };

    // ------------------------------------------------------------------ content blocking counters
    private final ContentBlocking.Delegate blocking = new ContentBlocking.Delegate() {
        @Override public void onContentBlocked(@NonNull GeckoSession session, @NonNull ContentBlocking.BlockEvent ev) {
            t.blocked++;
            final long now = System.currentTimeMillis();
            if (now - t.lastBlockedEmit > 700) {
                t.lastBlockedEmit = now;
                final Map<String, Object> m = Engine.ev("blocked", t.id);
                m.put("n", t.blocked);
                e.emit(m);
            }
        }
    };
}
