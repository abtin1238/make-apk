package ir.abtin.gecko;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Installed web apps. Two kinds, both pinned launcher shortcuts:
 * "pwa" = own window (PwaActivity, no browser UI); "shortcut" = plain shortcut that opens in the browser.
 * "real" = the site really is a PWA (web manifest + service worker); otherwise it is only a web shortcut shown in its own window.
 * The registry (files/webapps.json) keeps what Android's ShortcutManager does not: kind, flags, original URL and icon.
 */
final class WebApps {
    private static final String TAG = "AbtinWebApps";
    private final Engine e;
    private final File file, iconDir;

    WebApps(Engine e) {
        this.e = e;
        this.file = new File(e.app.getFilesDir(), "webapps.json");
        this.iconDir = new File(e.app.getFilesDir(), "webapp_icons");
    }

    // ---------------------------------------------------------------- storage
    private synchronized JSONArray load() {
        try {
            if (!file.exists()) return new JSONArray();
            return new JSONArray(new String(java.nio.file.Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8));
        } catch (Throwable t) { return new JSONArray(); }
    }

    private synchronized void save(JSONArray a) {
        try {
            final File tmp = new File(file.getPath() + ".tmp");
            try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(a.toString().getBytes(StandardCharsets.UTF_8)); }
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file); }
        } catch (Throwable t) { Log.w(TAG, "save", t); }
    }

    static String origin(String url) {
        try {
            final Uri u = Uri.parse(url);
            final String sc = u.getScheme() == null ? "https" : u.getScheme().toLowerCase(Locale.ROOT);
            final String h = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
            return sc + "://" + h + (u.getPort() > 0 ? ":" + u.getPort() : "");
        } catch (Throwable t) { return url; }
    }

    private static String idFor(boolean pwa, String url) {
        return pwa ? "abtin_pwa_" + Integer.toHexString(origin(url).hashCode()) : "abtin_" + Integer.toHexString(url.hashCode());
    }

    private File iconFile(String id) { return new File(iconDir, id.replaceAll("[^A-Za-z0-9_]", "_") + ".png"); }

    private void saveIcon(String id, Bitmap b) {
        try {
            iconDir.mkdirs();
            final ByteArrayOutputStream bo = new ByteArrayOutputStream();
            Bitmap.createScaledBitmap(b, 384, 384, true).compress(Bitmap.CompressFormat.PNG, 100, bo);
            try (FileOutputStream o = new FileOutputStream(iconFile(id))) { o.write(bo.toByteArray()); }
        } catch (Throwable t) { Log.w(TAG, "icon", t); }
    }

    @Nullable private ShortcutManager sm() {
        try {
            if (Build.VERSION.SDK_INT < 26) return null;
            return e.app.getSystemService(ShortcutManager.class);
        } catch (Throwable t) { return null; }
    }

    // ---------------------------------------------------------------- intents
    private Intent intentFor(String url, String title, boolean pwa) {
        final Intent launch = e.app.getPackageManager().getLaunchIntentForPackage(e.app.getPackageName());
        final Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        if (pwa) {
            // Own activity in its own task (own entry in Recents), no browser tabs around it. Cookies / login are the browser's own profile.
            it.setClass(e.app, PwaActivity.class);
            it.putExtra("abtin_title", title);
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
        } else {
            if (launch != null && launch.getComponent() != null) it.setComponent(launch.getComponent());
            else it.setPackage(e.app.getPackageName());
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        }
        return it;
    }

    // ---------------------------------------------------------------- reconcile with what is really pinned
    private JSONArray reconcile(JSONArray reg) {
        final ShortcutManager sm = sm();
        if (sm == null || Build.VERSION.SDK_INT < 26) return reg;
        try {
            final Map<String, ShortcutInfo> pinned = new HashMap<>();
            for (ShortcutInfo si : sm.getPinnedShortcuts()) if (si.isEnabled() && si.getId().startsWith("abtin_")) pinned.put(si.getId(), si);
            final long now = System.currentTimeMillis();
            final JSONArray out = new JSONArray();
            final Set<String> have = new HashSet<>();
            boolean changed = false;
            for (int i = 0; i < reg.length(); i++) {
                final JSONObject o = reg.getJSONObject(i);
                final String id = o.optString("id");
                // A pin the user has not confirmed yet is not in the list: keep new entries for two minutes.
                if (!pinned.containsKey(id) && now - o.optLong("created", 0) > 120_000L) {
                    iconFile(id).delete();
                    changed = true;
                    continue;
                }
                have.add(id);
                out.put(o);
            }
            // Shortcuts pinned by older versions (before the registry existed).
            for (Map.Entry<String, ShortcutInfo> en : pinned.entrySet()) {
                if (have.contains(en.getKey())) continue;
                final ShortcutInfo si = en.getValue();
                final Intent it = si.getIntent();
                if (it == null || it.getData() == null) continue;
                final JSONObject o = new JSONObject();
                o.put("id", en.getKey());
                o.put("title", si.getLongLabel() != null ? si.getLongLabel().toString() : String.valueOf(si.getShortLabel()));
                o.put("url", it.getDataString());
                o.put("kind", en.getKey().startsWith("abtin_pwa_") ? "pwa" : "shortcut");
                o.put("real", false); o.put("manifest", false); o.put("sw", false); o.put("created", 0);
                out.put(o);
                changed = true;
            }
            if (changed) save(out);
            return out;
        } catch (Throwable t) { Log.w(TAG, "reconcile", t); return reg; }
    }

    // ---------------------------------------------------------------- API used by Engine
    /** Result: ok | exists | unsupported | error. A site already installed (same origin for web apps) is not installed twice; only its name / icon are refreshed. */
    synchronized String install(@Nullable String url, @Nullable String title0, @Nullable byte[] icon, boolean pwa, boolean real, boolean manifest, boolean sw, boolean maskable) {
        try {
            if (url == null || url.isEmpty()) return "error";
            final ShortcutManager sm = sm();
            if (sm == null || !sm.isRequestPinShortcutSupported()) return "unsupported";
            final String title = title0 == null || title0.trim().isEmpty() ? Engine.hostOf(url) : title0.trim();
            final JSONArray reg = reconcile(load());
            final String kind = pwa ? "pwa" : "shortcut";
            for (int i = 0; i < reg.length(); i++) {
                final JSONObject o = reg.getJSONObject(i);
                final boolean same = kind.equals(o.optString("kind")) && (pwa ? origin(o.optString("url")).equals(origin(url)) : o.optString("url").equals(url));
                if (!same) continue;
                final String id = o.optString("id");
                // Already installed: refresh the label / icon of the pinned shortcut instead of adding a second one.
                final Built b = buildIcon(icon, title, maskable, pwa);
                o.put("title", title); o.put("real", real); o.put("manifest", manifest); o.put("sw", sw);
                save(reg);
                saveIcon(id, b.bmp);
                try {
                    sm.enableShortcuts(Collections.singletonList(id));
                    sm.updateShortcuts(Collections.singletonList(new ShortcutInfo.Builder(e.app, id)
                            .setShortLabel(title.length() > 24 ? title.substring(0, 24) : title).setLongLabel(title)
                            .setIcon(b.icon()).build()));
                } catch (Throwable ignored) { }
                return "exists";
            }
            final String id = idFor(pwa, url);
            final Built b = buildIcon(icon, title, maskable, pwa);
            final Bitmap bmp = b.bmp;
            // A shortcut of this site that was removed earlier stays "disabled" in the system: enable it again, or the new icon is dead.
            try { sm.enableShortcuts(Collections.singletonList(id)); } catch (Throwable ignored) { }
            final ShortcutInfo info = new ShortcutInfo.Builder(e.app, id)
                    .setShortLabel(title.length() > 24 ? title.substring(0, 24) : title)
                    .setLongLabel(title)
                    .setIcon(b.icon())
                    .setIntent(intentFor(url, title, pwa))
                    .build();
            if (!sm.requestPinShortcut(info, null)) return "refused";
            final JSONObject o = new JSONObject();
            o.put("id", id); o.put("title", title); o.put("url", url); o.put("kind", kind);
            o.put("real", real); o.put("manifest", manifest); o.put("sw", sw); o.put("created", System.currentTimeMillis());
            reg.put(o);
            save(reg);
            saveIcon(id, bmp);
            return "ok";
        } catch (Throwable t) { Log.e(TAG, "install", t); return "error:" + t.getClass().getSimpleName() + (t.getMessage() == null ? "" : " " + t.getMessage()); }
    }

    /** A finished launcher icon; [adaptive] = drawn for the launcher's own mask (web app "maskable" icon, like Chrome does). */
    static final class Built {
        final Bitmap bmp; final boolean adaptive;
        Built(Bitmap b, boolean a) { bmp = b; adaptive = a; }
        Icon icon() {
            return adaptive && Build.VERSION.SDK_INT >= 26 ? Icon.createWithAdaptiveBitmap(bmp) : Icon.createWithBitmap(bmp);
        }
    }

    private static int avgEdgeColor(Bitmap f) {
        long r = 0, g = 0, b = 0, n = 0;
        final int w = f.getWidth(), h = f.getHeight();
        final int step = Math.max(1, Math.min(w, h) / 24);
        for (int i = 0; i < w; i += step) for (int j = 0; j < 3; j++) {
            for (int px : new int[]{f.getPixel(i, Math.min(j, h - 1)), f.getPixel(i, Math.max(0, h - 1 - j))}) {
                if (((px >>> 24) & 0xFF) < 200) continue;
                r += (px >> 16) & 0xFF; g += (px >> 8) & 0xFF; b += px & 0xFF; n++;
            }
        }
        for (int j = 0; j < h; j += step) for (int i = 0; i < 3; i++) {
            for (int px : new int[]{f.getPixel(Math.min(i, w - 1), j), f.getPixel(Math.max(0, w - 1 - i), j)}) {
                if (((px >>> 24) & 0xFF) < 200) continue;
                r += (px >> 16) & 0xFF; g += (px >> 8) & 0xFF; b += px & 0xFF; n++;
            }
        }
        if (n == 0) return 0xFFFFFFFF;
        return 0xFF000000 | ((int) (r / n) << 16) | ((int) (g / n) << 8) | (int) (b / n);
    }

    private static boolean opaqueCorners(Bitmap f) {
        final int w = f.getWidth(), h = f.getHeight();
        final int[] px = {f.getPixel(1, 1), f.getPixel(w - 2, 1), f.getPixel(1, h - 2), f.getPixel(w - 2, h - 2)};
        for (int p : px) if (((p >>> 24) & 0xFF) < 250) return false;
        return true;
    }

    /**
     * Sharp launcher icon from whatever the site offers:
     * - installed PWA -> adaptive icon so Android/MIUI applies the same launcher mask used for native apps and Chrome;
     * - maskable web app icon -> adaptive icon (432 px, safe zone respected);
     * - big icon (>= 96 px) -> full size, rounded when it is an opaque square, transparency kept otherwise;
     * - small icon (a low-resolution favicon) -> centred on a light rounded tile at a modest scale instead of a blurry full-size stretch;
     * - nothing usable -> coloured tile with the first letter.
     */
    Built buildIcon(@Nullable byte[] data, String title, boolean maskable, boolean pwa) {
        Bitmap fav = null;
        if (data != null && data.length > 0) {
            try {
                final android.graphics.BitmapFactory.Options bo = new android.graphics.BitmapFactory.Options();
                bo.inJustDecodeBounds = true;
                android.graphics.BitmapFactory.decodeByteArray(data, 0, data.length, bo);
                int sample = 1;
                while (Math.max(bo.outWidth, bo.outHeight) / (sample * 2) >= 1024) sample *= 2;
                final android.graphics.BitmapFactory.Options o2 = new android.graphics.BitmapFactory.Options();
                o2.inSampleSize = sample;
                fav = android.graphics.BitmapFactory.decodeByteArray(data, 0, data.length, o2);
            } catch (Throwable ignored) { }
        }
        final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG | android.graphics.Paint.FILTER_BITMAP_FLAG | android.graphics.Paint.DITHER_FLAG);
        // Render at exactly the size the system keeps: a bigger bitmap is shrunk again by the system (blurry).
        // Keep a high-resolution source bitmap. Android launchers downsample it for their
        // density/mask; feeding them a 192px bitmap (as older builds did) made icons soft.
        int maxPx = 432;
        try {
            final ShortcutManager sm = e.app.getSystemService(ShortcutManager.class);
            if (sm != null) maxPx = Math.max(384, Math.min(512, Math.max(432, sm.getIconMaxWidth())));
        } catch (Throwable ignored) { }
        // Preserve the Xiaomi-specific bitmap behavior for plain shortcuts only. Installed PWAs must be adaptive on MIUI too,
        // otherwise their launcher icon has a different frame/padding from native apps and Chrome.
        final String man = (Build.MANUFACTURER + " " + Build.BRAND).toLowerCase();
        final boolean xiaomi = man.contains("xiaomi") || man.contains("redmi") || man.contains("poco");
        if (fav != null && fav.getWidth() >= 16 && fav.getHeight() >= 16) {
            final int fw = fav.getWidth(), fh = fav.getHeight(), big = Math.min(fw, fh);
            // Only use adaptive artwork when the source has enough pixels to stay crisp at launcher size.
            if ((pwa && Build.VERSION.SDK_INT >= 26 && big >= 96) || (maskable && !xiaomi && Build.VERSION.SDK_INT >= 26 && big >= 96)) {
                final int size = maxPx;
                final Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
                final android.graphics.Canvas cv = new android.graphics.Canvas(out);
                cv.drawColor(avgEdgeColor(fav));
                // Maskable artwork maps its 80% safe zone to Android's 66/108 safe zone.
                final float side = size * (maskable ? 0.764f : (pwa ? 0.82f : 0.611f)), l = (size - side) / 2f;
                final float scale = side / Math.max(fw, fh), w = fw * scale, h = fh * scale;
                cv.drawBitmap(fav, null, new android.graphics.RectF((size - w) / 2f, (size - h) / 2f, (size + w) / 2f, (size + h) / 2f), p);
                return new Built(out, true);
            }
            final int size = maxPx;
            final Bitmap out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            final android.graphics.Canvas cv = new android.graphics.Canvas(out);
            if (big >= 96) {
                if (maskable) {
                    // full-bleed brand square (what Chrome shows for a maskable icon); the launcher rounds the corners
                    cv.drawColor(avgEdgeColor(fav));
                    cv.drawBitmap(fav, null, new android.graphics.RectF(0, 0, size, size), p);
                } else {
                    final float k = Math.min((float) size / fw, (float) size / fh);
                    final float w = fw * k, h = fh * k, l = (size - w) / 2f, t = (size - h) / 2f;
                    final android.graphics.RectF dst = new android.graphics.RectF(l, t, l + w, t + h);
                    if (opaqueCorners(fav) && !xiaomi) {
                        final android.graphics.Path clip = new android.graphics.Path();
                        clip.addRoundRect(dst, Math.min(w, h) * .22f, Math.min(w, h) * .22f, android.graphics.Path.Direction.CW);
                        cv.save(); cv.clipPath(clip);
                        cv.drawBitmap(fav, null, dst, p);
                        cv.restore();
                    } else cv.drawBitmap(fav, null, dst, p);
                }
            } else {
                final float r = size * .22f;
                p.setColor(0xFFFFFFFF);
                cv.drawRoundRect(0, 0, size, size, r, r, p);
                final float target = Math.min(size * .56f, Math.max(fw, fh) * 2f);
                final float k = target / Math.max(fw, fh), w = fw * k, h = fh * k, l = (size - w) / 2f, t = (size - h) / 2f;
                cv.drawBitmap(fav, null, new android.graphics.RectF(l, t, l + w, t + h), p);
            }
            return new Built(out, false);
        }
        return new Built(e.shortcutIcon(null, title), false);
    }

    synchronized List<Map<String, Object>> list() {
        final List<Map<String, Object>> out = new ArrayList<>();
        try {
            final JSONArray reg = reconcile(load());
            for (int i = 0; i < reg.length(); i++) {
                final JSONObject o = reg.getJSONObject(i);
                final Map<String, Object> m = new HashMap<>();
                final String id = o.optString("id");
                m.put("id", id);
                m.put("title", o.optString("title"));
                m.put("url", o.optString("url"));
                m.put("host", Engine.hostOf(o.optString("url")));
                m.put("kind", o.optString("kind", "shortcut"));
                m.put("real", o.optBoolean("real", false));
                m.put("manifest", o.optBoolean("manifest", false));
                m.put("sw", o.optBoolean("sw", false));
                try {
                    final File f = iconFile(id);
                    if (f.exists()) m.put("icon", java.nio.file.Files.readAllBytes(f.toPath()));
                } catch (Throwable ignored) { }
                out.add(m);
            }
        } catch (Throwable t) { Log.w(TAG, "list", t); }
        return out;
    }

    synchronized boolean remove(@Nullable String id) {
        if (id == null) return false;
        try {
            final JSONArray reg = load();
            final JSONArray out = new JSONArray();
            for (int i = 0; i < reg.length(); i++) if (!id.equals(reg.getJSONObject(i).optString("id"))) out.put(reg.get(i));
            save(out);
            iconFile(id).delete();
            // Android cannot delete a pinned icon from the home screen by itself: it is disabled (greyed, "no longer available").
            final ShortcutManager sm = sm();
            if (sm != null) { try { sm.disableShortcuts(Collections.singletonList(id), "Removed"); } catch (Throwable ignored) { } }
            return true;
        } catch (Throwable t) { return false; }
    }

    synchronized boolean edit(@Nullable String id, @Nullable String title0) {
        if (id == null || title0 == null || title0.trim().isEmpty()) return false;
        final String title = title0.trim();
        try {
            final JSONArray reg = load();
            boolean found = false;
            for (int i = 0; i < reg.length(); i++) {
                final JSONObject o = reg.getJSONObject(i);
                if (id.equals(o.optString("id"))) { o.put("title", title); found = true; }
            }
            if (!found) return false;
            save(reg);
            final ShortcutManager sm = sm();
            if (sm != null) {
                try {
                    sm.updateShortcuts(Collections.singletonList(new ShortcutInfo.Builder(e.app, id)
                            .setShortLabel(title.length() > 24 ? title.substring(0, 24) : title).setLongLabel(title).build()));
                } catch (Throwable ignored) { }
            }
            return true;
        } catch (Throwable t) { return false; }
    }

    synchronized boolean open(@Nullable String id) {
        if (id == null) return false;
        try {
            final JSONArray reg = load();
            for (int i = 0; i < reg.length(); i++) {
                final JSONObject o = reg.getJSONObject(i);
                if (!id.equals(o.optString("id"))) continue;
                final Intent it = intentFor(o.optString("url"), o.optString("title"), "pwa".equals(o.optString("kind")));
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                final Context c = e.activity != null ? e.activity : e.app;
                c.startActivity(it);
                return true;
            }
        } catch (Throwable t) { Log.w(TAG, "open", t); }
        return false;
    }
}
