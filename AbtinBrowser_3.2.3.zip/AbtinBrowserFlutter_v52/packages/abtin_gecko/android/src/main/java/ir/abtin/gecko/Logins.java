package ir.abtin.gecko;

import android.content.Context;
import android.net.Uri;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Log;

import androidx.annotation.NonNull;

import org.json.JSONArray;
import org.json.JSONObject;
import org.mozilla.geckoview.Autocomplete;
import org.mozilla.geckoview.GeckoResult;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/**
 * Saved passwords are encrypted with AES-256-GCM using a key in Android Keystore. Browser and PWA
 * processes use separate files and aliases. Gecko asks this delegate for site logins and reports saves.
 */
final class Logins implements Autocomplete.StorageDelegate {
    private static final String TAG = "AbtinLogins";
    private final String alias;
    private final File file, neverFile;
    private final List<JSONObject> items = new ArrayList<>();
    private final Set<String> never = new HashSet<>();
    private boolean loaded;

    Logins(Context c) { this(c, "browser"); }

    Logins(Context c, String profile) {
        final String suffix = "pwa".equals(profile) ? "_pwa" : "";
        alias = "abtin_logins" + suffix + "_v1";
        file = new File(c.getFilesDir(), "logins" + suffix + ".enc");
        neverFile = new File(c.getFilesDir(), "logins_never" + suffix + ".txt");
    }

    // ------------------------------------------------------------------ crypto

    private SecretKey key() throws Exception {
        final KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(alias)) {
            final KeyGenerator g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
            g.init(new KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build());
            return g.generateKey();
        }
        return (SecretKey) ks.getKey(alias, null);
    }

    private byte[] encrypt(byte[] plain) throws Exception {
        final Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, key());
        final byte[] iv = c.getIV();
        final byte[] ct = c.doFinal(plain);
        final byte[] out = new byte[1 + iv.length + ct.length];
        out[0] = (byte) iv.length;
        System.arraycopy(iv, 0, out, 1, iv.length);
        System.arraycopy(ct, 0, out, 1 + iv.length, ct.length);
        return out;
    }

    private byte[] decrypt(byte[] data) throws Exception {
        final int n = data[0] & 0xff;
        final Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, data, 1, n));
        return c.doFinal(data, 1 + n, data.length - 1 - n);
    }

    // ------------------------------------------------------------------ persistence

    private synchronized void load() {
        if (loaded) return;
        loaded = true;
        try {
            if (file.exists()) {
                final byte[] buf = new byte[(int) file.length()];
                try (FileInputStream in = new FileInputStream(file)) {
                    int off = 0;
                    while (off < buf.length) { final int r = in.read(buf, off, buf.length - off); if (r < 0) break; off += r; }
                }
                final JSONArray a = new JSONArray(new String(decrypt(buf), "UTF-8"));
                for (int i = 0; i < a.length(); i++) items.add(a.getJSONObject(i));
            }
        } catch (Throwable t) {
            Log.e(TAG, "load failed (key lost or file damaged): " + t);
        }
        try {
            if (neverFile.exists()) {
                final byte[] buf = new byte[(int) neverFile.length()];
                try (FileInputStream in = new FileInputStream(neverFile)) { in.read(buf); }
                for (String l : new String(buf, "UTF-8").split("\n")) if (!l.trim().isEmpty()) never.add(l.trim());
            }
        } catch (Throwable ignored) { }
    }

    private synchronized void persist() {
        try {
            final JSONArray a = new JSONArray();
            for (JSONObject o : items) a.put(o);
            final File tmp = new File(file.getPath() + ".tmp");
            try (FileOutputStream out = new FileOutputStream(tmp)) { out.write(encrypt(a.toString().getBytes("UTF-8"))); out.getFD().sync(); }
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file); }
        } catch (Throwable t) {
            Log.e(TAG, "persist failed", t);
        }
    }

    private synchronized void persistNever() {
        try {
            final StringBuilder sb = new StringBuilder();
            for (String h : never) sb.append(h).append('\n');
            try (FileOutputStream out = new FileOutputStream(neverFile)) { out.write(sb.toString().getBytes("UTF-8")); }
        } catch (Throwable ignored) { }
    }

    // ------------------------------------------------------------------ helpers

    static String hostOf(String origin) {
        if (origin == null) return "";
        try {
            final String h = Uri.parse(origin).getHost();
            return h == null ? origin : h.toLowerCase(Locale.ROOT);
        } catch (Throwable t) { return origin; }
    }

    private static String s(JSONObject o, String k) { final String v = o.optString(k, ""); return v == null ? "" : v; }

    private static boolean sameSite(String hostA, String hostB) {
        if (hostA.isEmpty() || hostB.isEmpty()) return false;
        return hostA.equals(hostB) || hostA.endsWith("." + hostB) || hostB.endsWith("." + hostA);
    }

    private static Autocomplete.LoginEntry toEntry(JSONObject o) {
        final Autocomplete.LoginEntry.Builder b = new Autocomplete.LoginEntry.Builder()
                .guid(s(o, "guid"))
                .origin(s(o, "origin"))
                .username(s(o, "user"))
                .password(s(o, "pass"));
        final String fa = s(o, "formAction"), realm = s(o, "realm");
        if (!fa.isEmpty()) b.formActionOrigin(fa);
        if (!realm.isEmpty()) b.httpRealm(realm);
        return b.build();
    }

    private JSONObject find(String guid) {
        if (guid == null) return null;
        for (JSONObject o : items) if (guid.equals(s(o, "guid"))) return o;
        return null;
    }

    // ------------------------------------------------------------------ Gecko storage delegate

    @NonNull
    public GeckoResult<Autocomplete.LoginEntry[]> onLoginFetch(@NonNull String domain) {
        load();
        String d = domain == null ? "" : domain.trim().toLowerCase(Locale.ROOT);
        if (d.startsWith(".")) d = d.substring(1);
        if (d.endsWith(".")) d = d.substring(0, d.length() - 1);
        final String requestedHost = hostOf(d).toLowerCase(Locale.ROOT);
        final List<Autocomplete.LoginEntry> out = new ArrayList<>();
        synchronized (this) {
            for (JSONObject o : items) {
                final String savedHost = hostOf(s(o, "origin"));
                if (sameSite(savedHost, requestedHost)) out.add(toEntry(o));
            }
        }
        return GeckoResult.fromValue(out.toArray(new Autocomplete.LoginEntry[0]));
    }

    @NonNull
    public GeckoResult<Autocomplete.LoginEntry[]> onLoginFetch() {
        load();
        final List<Autocomplete.LoginEntry> out = new ArrayList<>();
        synchronized (this) { for (JSONObject o : items) out.add(toEntry(o)); }
        return GeckoResult.fromValue(out.toArray(new Autocomplete.LoginEntry[0]));
    }

    public void onLoginSave(@NonNull Autocomplete.LoginEntry l) {
        load();
        synchronized (this) {
            try {
                JSONObject o = find(l.guid);
                if (o == null) {
                    for (JSONObject x : items) {
                        if (s(x, "origin").equals(l.origin == null ? "" : l.origin) && s(x, "user").equals(l.username == null ? "" : l.username)
                                && s(x, "realm").equals(l.httpRealm == null ? "" : l.httpRealm)) { o = x; break; }
                    }
                }
                final long now = System.currentTimeMillis();
                if (o == null) {
                    o = new JSONObject();
                    o.put("guid", UUID.randomUUID().toString());
                    o.put("created", now);
                    o.put("times", 0);
                    items.add(o);
                }
                if (!s(o, "pass").equals(l.password == null ? "" : l.password)) o.put("changed", now);
                o.put("origin", l.origin == null ? "" : l.origin);
                o.put("formAction", l.formActionOrigin == null ? "" : l.formActionOrigin);
                o.put("realm", l.httpRealm == null ? "" : l.httpRealm);
                o.put("user", l.username == null ? "" : l.username);
                o.put("pass", l.password == null ? "" : l.password);
                if (!o.has("changed")) o.put("changed", now);
                o.put("used", now);
                persist();
            } catch (Throwable t) { Log.e(TAG, "save failed", t); }
        }
    }

    public void onLoginUsed(@NonNull Autocomplete.LoginEntry l, int usedFields) {
        load();
        synchronized (this) {
            try {
                final JSONObject o = find(l.guid);
                if (o == null) return;
                o.put("used", System.currentTimeMillis());
                o.put("times", o.optInt("times") + 1);
                persist();
            } catch (Throwable ignored) { }
        }
    }

    // ------------------------------------------------------------------ used by Prompts / the Dart UI

    synchronized boolean hasUser(String origin, String user) {
        load();
        for (JSONObject o : items) if (s(o, "origin").equals(origin == null ? "" : origin) && s(o, "user").equals(user == null ? "" : user)) return true;
        return false;
    }

    /**
     * GeckoView normally returns the stored GUID with a login option, but some
     * form/autocomplete paths omit it. Match the option against our encrypted
     * store so multi-account sites do not lose every suggestion just because
     * the GUID was omitted. A username match alone is not enough when it is
     * empty; in that case the password must also match.
     */
    synchronized boolean isSavedEntry(Autocomplete.LoginEntry candidate) {
        load();
        if (candidate == null) return false;
        final String guid = candidate.guid == null ? "" : candidate.guid;
        final String origin = candidate.origin == null ? "" : candidate.origin;
        final String user = candidate.username == null ? "" : candidate.username;
        final String pass = candidate.password == null ? "" : candidate.password;
        final String realm = candidate.httpRealm == null ? "" : candidate.httpRealm;
        for (JSONObject saved : items) {
            if (!guid.isEmpty() && guid.equals(s(saved, "guid"))) return true;
            if (!origin.equals(s(saved, "origin")) || !realm.equals(s(saved, "realm"))) continue;
            if (!user.isEmpty() && user.equals(s(saved, "user"))) return true;
            if (user.isEmpty() && !pass.isEmpty() && pass.equals(s(saved, "pass"))) return true;
        }
        return false;
    }

    synchronized boolean isNever(String host) { load(); return never.contains(host); }

    synchronized void setNever(String host) { load(); if (never.add(host)) persistNever(); }

    synchronized List<String> neverList() { load(); return new ArrayList<>(never); }

    synchronized void removeNever(String host) { load(); if (never.remove(host)) persistNever(); }

    synchronized List<Map<String, Object>> list() {
        load();
        final List<Map<String, Object>> out = new ArrayList<>();
        for (JSONObject o : items) {
            final Map<String, Object> m = new HashMap<>();
            m.put("guid", s(o, "guid"));
            m.put("origin", s(o, "origin"));
            m.put("host", hostOf(s(o, "origin")));
            m.put("realm", s(o, "realm"));
            m.put("user", s(o, "user"));
            m.put("pass", s(o, "pass"));
            m.put("created", o.optLong("created"));
            m.put("used", o.optLong("used"));
            out.add(m);
        }
        return out;
    }

    /** Add or edit by hand (guid empty = add). Returns false when the origin or password is empty. */
    synchronized boolean put(String guid, String origin, String user, String pass) {
        load();
        if (origin == null || origin.trim().isEmpty() || pass == null || pass.isEmpty()) return false;
        String o = origin.trim();
        if (!o.contains("://")) o = "https://" + o;
        try {
            final Uri u = Uri.parse(o);
            if (u.getHost() == null) return false;
            o = u.getScheme() + "://" + u.getHost() + (u.getPort() > 0 ? ":" + u.getPort() : "");
        } catch (Throwable t) { return false; }
        final Autocomplete.LoginEntry.Builder b = new Autocomplete.LoginEntry.Builder()
                .origin(o).username(user == null ? "" : user).password(pass);
        if (guid != null && !guid.isEmpty()) b.guid(guid);
        onLoginSave(b.build());
        return true;
    }

    synchronized void delete(String guid) {
        load();
        final JSONObject o = find(guid);
        if (o != null) { items.remove(o); persist(); }
    }

    synchronized void clear() {
        load();
        items.clear();
        persist();
    }
}
