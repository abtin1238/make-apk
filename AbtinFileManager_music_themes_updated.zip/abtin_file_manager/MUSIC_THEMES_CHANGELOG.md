# Music player themes

Added a persistent music-player-only theme selector (`musicPlayerTheme`) with four options:
- original: keeps the existing record + tonearm layout and original accent colour.
- classic: warm gold gramophone-inspired composition with spinning vinyl and reflected equalizer.
- cyber: circular album artwork with a radial spectrum ring.
- neo: soft glass-like album presentation and reflected equalizer.

The selection is stored with SharedPreferences. Existing playback/player service logic, queue, lyrics, seek, shuffle/repeat, EQ, visualizer, sleep timer, and other actions are unchanged.
