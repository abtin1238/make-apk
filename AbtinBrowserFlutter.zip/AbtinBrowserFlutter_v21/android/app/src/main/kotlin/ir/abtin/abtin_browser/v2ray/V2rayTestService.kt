package ir.abtin.abtin_browser.v2ray

import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Real-delay test of a config through a temporary Xray instance, in its own process (":v2raytest"). */
class V2rayTestService : Service() {
    private val pool = Executors.newFixedThreadPool(4)
    private val pending = AtomicInteger(0)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val id = intent?.getStringExtra("id")
        val path = intent?.getStringExtra("path")
        val url = intent?.getStringExtra("url") ?: "https://www.gstatic.com/generate_204"
        if (id == null || path == null) {
            if (pending.get() == 0) stopSelf()
            return START_NOT_STICKY
        }
        pending.incrementAndGet()
        pool.execute {
            var ms = -1L
            try {
                val f = File(path)
                val config = f.readText()
                f.delete()
                ms = V2rayCore.measureDelay(applicationContext, config, url)
            } catch (t: Throwable) {
                Log.e("AbtinV2rayTest", "delay test failed", t)
            }
            V2rayEvents.send(applicationContext) {
                putExtra("type", "ping")
                putExtra("id", id)
                putExtra("ms", ms)
            }
            if (pending.decrementAndGet() == 0) {
                stopSelf()
                // Free the Go runtime when the batch is over (nothing else lives in this process).
                Handler(Looper.getMainLooper()).postDelayed({
                    if (pending.get() == 0) android.os.Process.killProcess(android.os.Process.myPid())
                }, 5000)
            }
        }
        return START_NOT_STICKY
    }
}
