package ir.abtin.abtin_browser.dns

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.Log
import androidx.core.app.NotificationCompat
import ir.abtin.abtin_browser.R
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * System-wide DNS changer. A VPN whose only route is one virtual DNS address: the whole phone sends its DNS queries
 * there, this service forwards them (UDP, sockets protect()ed so they leave outside the VPN) to the chosen servers
 * and writes the answers back. No other traffic enters the tunnel.
 */
class DnsVpnService : VpnService() {
    companion object {
        const val ACTION_START = "ir.abtin.abtin_browser.DNS_START"
        const val ACTION_STOP = "ir.abtin.abtin_browser.DNS_STOP"
        private const val TAG = "AbtinDnsVpn"
        private const val CHANNEL = "abtin_dns"
        private const val NOTIFICATION_ID = 7789
        private const val VIRTUAL_DNS = "10.255.255.2"
        @Volatile var running = false
        @Volatile var lastError = ""
        var listener: ((Boolean, String) -> Unit)? = null

        fun notifyState() {
            val r = running; val e = lastError
            Handler(Looper.getMainLooper()).post { listener?.invoke(r, e) }
        }
    }

    private var tun: ParcelFileDescriptor? = null
    private var loop: Thread? = null
    private var pool: ExecutorService? = null
    @Volatile private var stopping = false
    private var servers: List<String> = emptyList()
    private val writeLock = Any()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, notification(""))
        if (intent?.action == ACTION_STOP) { shutdown(""); return START_NOT_STICKY }
        if (intent?.action != ACTION_START) { shutdown(""); return START_NOT_STICKY }
        val list = (intent.getStringExtra("servers") ?: "").split(',').map { it.trim() }.filter { it.isNotEmpty() && !it.contains(':') }
        if (list.isEmpty()) { shutdown("no_servers"); return START_NOT_STICKY }
        closeTun()
        servers = list
        try {
            val b = Builder()
            b.setSession("Abtin DNS")
            b.setMtu(1500)
            b.addAddress("10.255.255.1", 30)
            b.addRoute(VIRTUAL_DNS, 32)
            b.addDnsServer(VIRTUAL_DNS)
            b.setBlocking(true)
            b.setMetered(false)
            val fd = b.establish() ?: throw IllegalStateException("vpn_denied")
            tun = fd
            stopping = false
            pool = Executors.newFixedThreadPool(8)
            loop = Thread { runLoop(fd) }.also { it.isDaemon = true; it.name = "abtin-dns"; it.start() }
            running = true
            lastError = ""
            getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, notification(list.joinToString(" , ")))
            notifyState()
        } catch (t: Throwable) {
            Log.e(TAG, "start failed", t)
            shutdown(t.message?.takeIf { it.isNotBlank() } ?: t.javaClass.simpleName)
        }
        return START_NOT_STICKY
    }

    override fun onRevoke() { shutdown("") }

    override fun onDestroy() {
        stopping = true
        running = false
        closeTun()
        pool?.shutdownNow()
        notifyState()
        super.onDestroy()
    }

    private fun closeTun() {
        stopping = true
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        loop?.interrupt()
        loop = null
    }

    private fun shutdown(error: String) {
        closeTun()
        pool?.shutdownNow()
        pool = null
        running = false
        lastError = error
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        notifyState()
    }

    private fun runLoop(fd: ParcelFileDescriptor) {
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        while (!stopping) {
            val n = try { input.read(buf) } catch (_: Exception) { break }
            if (n <= 0) continue
            if (n < 28 || (buf[0].toInt() shr 4) != 4) continue
            val ihl = (buf[0].toInt() and 0x0F) * 4
            if (ihl < 20 || n < ihl + 8 || buf[9].toInt() != 17) continue
            val dstPort = ((buf[ihl + 2].toInt() and 0xFF) shl 8) or (buf[ihl + 3].toInt() and 0xFF)
            if (dstPort != 53) continue
            val srcPort = ((buf[ihl].toInt() and 0xFF) shl 8) or (buf[ihl + 1].toInt() and 0xFF)
            val payload = buf.copyOfRange(ihl + 8, n)
            val srcIp = buf.copyOfRange(12, 16)
            val dstIp = buf.copyOfRange(16, 20)
            try {
                pool?.execute { answer(output, payload, srcIp, dstIp, srcPort) }
            } catch (_: Exception) { break }
        }
    }

    private fun answer(output: FileOutputStream, query: ByteArray, clientIp: ByteArray, dnsIp: ByteArray, clientPort: Int) {
        val resp = forward(query) ?: return
        val total = 28 + resp.size
        val p = ByteArray(total)
        p[0] = 0x45
        p[2] = (total shr 8).toByte(); p[3] = total.toByte()
        p[6] = 0x40 // don't fragment
        p[8] = 64; p[9] = 17
        System.arraycopy(dnsIp, 0, p, 12, 4)
        System.arraycopy(clientIp, 0, p, 16, 4)
        var sum = 0
        for (i in 0 until 20 step 2) sum += ((p[i].toInt() and 0xFF) shl 8) or (p[i + 1].toInt() and 0xFF)
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        val cs = sum.inv() and 0xFFFF
        p[10] = (cs shr 8).toByte(); p[11] = cs.toByte()
        p[20] = 0; p[21] = 53
        p[22] = (clientPort shr 8).toByte(); p[23] = clientPort.toByte()
        val ul = 8 + resp.size
        p[24] = (ul shr 8).toByte(); p[25] = ul.toByte()
        System.arraycopy(resp, 0, p, 28, resp.size) // UDP checksum 0 = none (valid for IPv4)
        synchronized(writeLock) { try { output.write(p) } catch (_: Exception) {} }
    }

    private fun forward(query: ByteArray): ByteArray? {
        for (s in servers) {
            var sock: DatagramSocket? = null
            try {
                sock = DatagramSocket()
                protect(sock)
                sock.soTimeout = 3000
                val addr = InetAddress.getByName(s)
                sock.send(DatagramPacket(query, query.size, addr, 53))
                val rb = ByteArray(4096)
                val rp = DatagramPacket(rb, rb.size)
                sock.receive(rp)
                return rb.copyOf(rp.length)
            } catch (_: Exception) {
            } finally {
                try { sock?.close() } catch (_: Exception) {}
            }
        }
        return null
    }

    private fun notification(status: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm?.createNotificationChannel(NotificationChannel(CHANNEL, "DNS", NotificationManager.IMPORTANCE_LOW))
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        val open = if (launch != null) PendingIntent.getActivity(this, 0, launch, flags) else null
        val stop = PendingIntent.getService(this, 2, Intent(this, DnsVpnService::class.java).setAction(ACTION_STOP), flags)
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_v2ray_notif)
            .setContentTitle("Abtin DNS")
            .setContentText(status)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(open)
            .addAction(0, "قطع / Stop", stop)
            .build()
    }
}
