import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../app_state.dart';

/// Camera QR / barcode scanner. Pops with the scanned text.
class QrScannerPage extends StatefulWidget {
  const QrScannerPage({super.key});
  @override
  State<QrScannerPage> createState() => _QrScannerPageState();
}

class _QrScannerPageState extends State<QrScannerPage> {
  final MobileScannerController ctl = MobileScannerController(detectionSpeed: DetectionSpeed.noDuplicates);
  bool _done = false;

  @override
  void dispose() {
    ctl.dispose();
    super.dispose();
  }

  void _finish(String v) {
    if (_done || !mounted) return;
    _done = true;
    HapticFeedback.mediumImpact();
    Navigator.of(context).pop(v);
  }

  void _hit(BarcodeCapture cap) {
    for (final b in cap.barcodes) {
      final v = b.rawValue;
      if (v != null && v.isNotEmpty) {
        _finish(v);
        return;
      }
    }
  }

  Future<void> _fromGallery() async {
    final r = await FilePicker.platform.pickFiles(type: FileType.image);
    final path = r?.files.single.path;
    if (path == null) return;
    final cap = await ctl.analyzeImage(path);
    String? v;
    if (cap != null) {
      for (final b in cap.barcodes) {
        if (b.rawValue != null && b.rawValue!.isNotEmpty) { v = b.rawValue; break; }
      }
    }
    if (v == null) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr('کد QR در عکس پیدا نشد', 'No QR code found in the image'))));
      return;
    }
    _finish(v);
  }

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Stack(fit: StackFit.expand, children: [
          MobileScanner(controller: ctl, onDetect: _hit),
          IgnorePointer(child: CustomPaint(painter: _FramePainter(Theme.of(context).colorScheme.primary))),
          Positioned(
            top: top + 4, left: 4, right: 4,
            child: Row(children: [
              IconButton(onPressed: () => Navigator.of(context).maybePop(), icon: const Icon(Icons.arrow_back, color: Colors.white)),
              Expanded(child: Text(tr('اسکن QR', 'Scan QR code'), style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600))),
              ValueListenableBuilder<MobileScannerState>(
                valueListenable: ctl,
                builder: (_, s, __) => IconButton(
                  onPressed: () => ctl.toggleTorch(),
                  icon: Icon(s.torchState == TorchState.on ? Icons.flash_on : Icons.flash_off, color: Colors.white),
                ),
              ),
              IconButton(onPressed: () => ctl.switchCamera(), icon: const Icon(Icons.cameraswitch_outlined, color: Colors.white)),
            ]),
          ),
          Positioned(
            left: 0, right: 0, bottom: MediaQuery.of(context).padding.bottom + 28,
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text(tr('کد را داخل کادر بگیرید', 'Point the camera at a QR code'), style: const TextStyle(color: Colors.white70)),
              const SizedBox(height: 14),
              FilledButton.tonalIcon(onPressed: _fromGallery, icon: const Icon(Icons.image_outlined), label: Text(tr('انتخاب از گالری', 'Pick from gallery'))),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _FramePainter extends CustomPainter {
  _FramePainter(this.color);
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final side = size.shortestSide * .66;
    final rect = RRect.fromRectAndRadius(Rect.fromCenter(center: Offset(size.width / 2, size.height * .44), width: side, height: side), const Radius.circular(22));
    final dim = Path()
      ..fillType = PathFillType.evenOdd
      ..addRect(Offset.zero & size)
      ..addRRect(rect);
    canvas.drawPath(dim, Paint()..color = Colors.black.withValues(alpha: .55));
    canvas.drawRRect(rect, Paint()..color = color..style = PaintingStyle.stroke..strokeWidth = 3);
  }

  @override
  bool shouldRepaint(covariant _FramePainter old) => old.color != color;
}
