import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../app_state.dart';
import '../engine/v2ray/v2ray_manager.dart';
import '../services.dart';
import 'glass.dart';
import 'qr_scanner_page.dart';

String _fmtBytes(int b) {
  if (b < 1024) return '$b B';
  if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} KB';
  if (b < 1024 * 1024 * 1024) return '${(b / 1048576).toStringAsFixed(1)} MB';
  return '${(b / 1073741824).toStringAsFixed(2)} GB';
}

/// v2ray (Xray, PattNG core): server list, subscriptions and the system-wide VPN switch.
class V2rayPage extends StatefulWidget {
  const V2rayPage({super.key});
  @override
  State<V2rayPage> createState() => _V2rayPageState();
}

class _V2rayPageState extends State<V2rayPage> {
  @override
  void initState() {
    super.initState();
    v2ray.addListener(_r);
    v2ray.init();
  }

  @override
  void dispose() {
    v2ray.removeListener(_r);
    super.dispose();
  }

  void _r() {
    if (mounted) setState(() {});
  }

  void _snack(String m) {
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  String _err(String e) => switch (e) {
        'no_profile' => tr('ابتدا یک کانفیگ اضافه و انتخاب کنید', 'Add and select a config first'),
        'unsupported' => tr('این نوع کانفیگ در این نسخه پشتیبانی نمی‌شود', 'This config type is not supported in this build'),
        'vpn_denied' => tr('مجوز VPN داده نشد', 'VPN permission was denied'),
        'start_failed' => tr('شروع اتصال ناموفق بود', 'Could not start the connection'),
        _ => e,
      };

  Future<void> _toggle() async {
    if (v2ray.connected || v2ray.connecting) {
      await v2ray.disconnect();
      return;
    }
    final e = await v2ray.connect();
    if (e != null) _snack(_err(e));
  }

  void _added(int n) => _snack(n > 0 ? tr('$n کانفیگ اضافه شد', '$n config(s) added') : tr('کانفیگ معتبری پیدا نشد', 'No valid config found'));

  Future<void> _paste() async {
    final d = await Clipboard.getData('text/plain');
    _added(v2ray.addText(d?.text ?? ''));
  }

  Future<void> _scan() async {
    final t = await Navigator.of(context).push<String>(MaterialPageRoute(builder: (_) => const QrScannerPage()));
    if (t != null && t.isNotEmpty) _added(v2ray.addText(t));
  }

  Future<void> _typeText() async {
    final c = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('افزودن کانفیگ', 'Add config')),
        content: TextField(controller: c, minLines: 4, maxLines: 8, textDirection: TextDirection.ltr, decoration: InputDecoration(hintText: tr('لینک‌ها (هر خط یکی) یا JSON کامل Xray', 'Links (one per line) or a full Xray JSON'))),
        actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), FilledButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('افزودن', 'Add')))],
      ),
    );
    if (ok == true) _added(v2ray.addText(c.text));
  }

  Future<void> _addSub() async {
    final name = TextEditingController(), url = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (d) => AlertDialog(
        title: Text(tr('افزودن اشتراک (Subscription)', 'Add subscription')),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: InputDecoration(labelText: tr('نام', 'Name'))),
          TextField(controller: url, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'URL')),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(d, false), child: Text(tr('لغو', 'Cancel'))), FilledButton(onPressed: () => Navigator.pop(d, true), child: Text(tr('افزودن', 'Add')))],
      ),
    );
    if (ok != true || url.text.trim().isEmpty) return;
    _snack(tr('در حال دریافت…', 'Fetching…'));
    final n = await v2ray.addSub(name.text.trim(), url.text.trim());
    _snack(n < 0 ? tr('دریافت اشتراک ناموفق بود', 'Could not fetch the subscription') : tr('$n کانفیگ دریافت شد', '$n config(s) fetched'));
  }

  Future<void> _updateSubs() async {
    if (v2ray.subs.isEmpty) {
      _snack(tr('اشتراکی ثبت نشده', 'No subscriptions'));
      return;
    }
    _snack(tr('به‌روزرسانی اشتراک‌ها…', 'Updating subscriptions…'));
    var bad = 0;
    for (final s in List<V2Sub>.from(v2ray.subs)) {
      if (await v2ray.refreshSub(s) < 0) bad++;
    }
    _snack(bad == 0 ? tr('به‌روز شد', 'Updated') : tr('$bad اشتراک ناموفق بود', '$bad subscription(s) failed'));
  }

  void _settings() {
    showGlassSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(builder: (ctx, set) {
        Widget sw(String k, String t, String sub) => SwitchListTile(value: app.flag(k), onChanged: (v) { app.set(k, v); set(() {}); }, title: Text(t), subtitle: Text(sub, style: const TextStyle(fontSize: 12)));
        Widget field(String k, String t) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: TextFormField(initialValue: app.str(k), textDirection: TextDirection.ltr, decoration: InputDecoration(labelText: t), onChanged: (v) => app.set(k, v.trim())),
            );
        return SafeArea(
          child: Padding(
            padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom),
            child: ListView(shrinkWrap: true, children: [
              sw('v2BypassIran', tr('دور زدن سایت‌ها و آی‌پی‌های ایران', 'Bypass Iranian sites and IPs'), tr('مستقیم، بدون پروکسی (geosite/geoip ایران)', 'Direct, not proxied (Iran geosite/geoip)')),
              sw('v2BlockUdp', tr('مسدودکردن QUIC (UDP 443)', 'Block QUIC (UDP 443)'), tr('برنامه‌ها به TCP برمی‌گردند؛ معمولاً پایدارتر است', 'Apps fall back to TCP; usually more reliable')),
              sw('v2BlockAds', tr('مسدودکردن تبلیغات', 'Block ads'), tr('با geosite تبلیغات', 'Using the ads geosite')),
              sw('v2BypassLan', tr('عدم عبور شبکهٔ محلی از VPN', 'Keep LAN out of the VPN'), tr('پرینتر، کست و دستگاه‌های خانه', 'Printers, casting, home devices')),
              sw('v2Ipv6', 'IPv6', tr('خاموش: ترافیک IPv6 ممکن است بیرون از VPN برود', 'Off: IPv6 traffic may bypass the VPN')),
              field('v2Dns', tr('DNS برنامه‌ها (با کاما جدا کنید)', 'DNS for apps (comma separated)')),
              field('v2Mtu', 'MTU'),
              field('v2TestUrl', tr('نشانی تست تأخیر', 'Delay test URL')),
              Padding(padding: const EdgeInsets.all(16), child: Text(tr('تغییرات با اتصال بعدی اعمال می‌شود.', 'Changes apply on the next connection.'), style: const TextStyle(fontSize: 12))),
            ]),
          ),
        );
      }),
    );
  }

  Widget _header() {
    final p = v2ray.selected;
    final on = v2ray.connected, busy = v2ray.connecting;
    final cs = Theme.of(context).colorScheme;
    final label = on
        ? tr('متصل', 'Connected')
        : busy
            ? tr('در حال اتصال…', 'Connecting…')
            : v2ray.status == 'error'
                ? tr('خطا', 'Error')
                : tr('قطع', 'Disconnected');
    return Container(
      margin: const EdgeInsets.all(12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: cs.primary.withAlpha(on ? 40 : 18), borderRadius: BorderRadius.circular(22), border: Border.all(color: cs.primary.withAlpha(on ? 140 : 50))),
      child: Column(children: [
        Row(children: [
          Icon(on ? Icons.shield_rounded : Icons.shield_outlined, size: 34, color: on ? Colors.greenAccent : null),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text(p?.name ?? tr('کانفیگی انتخاب نشده', 'No config selected'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
          ])),
          FilledButton.icon(
            onPressed: busy && !on ? null : _toggle,
            icon: Icon(on || busy ? Icons.stop_rounded : Icons.power_settings_new_rounded),
            label: Text(on || busy ? tr('قطع', 'Stop') : tr('اتصال', 'Connect')),
          ),
        ]),
        if (on) ...[
          const SizedBox(height: 10),
          Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
            Text('↑ ${_fmtBytes(v2ray.up)}/s', textDirection: TextDirection.ltr),
            Text('↓ ${_fmtBytes(v2ray.down)}/s', textDirection: TextDirection.ltr),
            Text('Σ ${_fmtBytes(v2ray.totalUp + v2ray.totalDown)}', textDirection: TextDirection.ltr),
          ]),
          const SizedBox(height: 6),
          Text(tr('کل گوشی از این کانفیگ عبور می‌کند', 'The whole phone goes through this config'), style: const TextStyle(fontSize: 11)),
        ],
        if (v2ray.error.isNotEmpty && !on && !busy) ...[
          const SizedBox(height: 8),
          Text(_err(v2ray.error), textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, color: Colors.redAccent)),
        ],
      ]),
    );
  }

  Widget _tile(V2Profile p) {
    final sel = v2ray.selectedId == p.id;
    final ping = p.testing
        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
        : p.ping == null
            ? const SizedBox.shrink()
            : Text(p.ping! < 0 ? '✕' : '${p.ping} ms', textDirection: TextDirection.ltr, style: TextStyle(color: p.ping! < 0 ? Colors.redAccent : p.ping! < 600 ? Colors.greenAccent : Colors.orangeAccent));
    return ListTile(
      leading: Icon(sel ? Icons.radio_button_checked : Icons.radio_button_off, color: sel ? Theme.of(context).colorScheme.primary : null),
      title: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: Text('${p.type.toUpperCase()}${p.server.isEmpty ? '' : ' · ${p.server}:${p.port}'}', maxLines: 1, overflow: TextOverflow.ellipsis, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 12)),
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        ping,
        PopupMenuButton<String>(
          onSelected: (v) async {
            switch (v) {
              case 'ping':
                v2ray.ping(p);
              case 'connect':
                final e = await v2ray.connect(p);
                if (e != null) _snack(_err(e));
              case 'copy':
                await Clipboard.setData(ClipboardData(text: p.entry));
                _snack(tr('کپی شد', 'Copied'));
              case 'del':
                v2ray.removeProfile(p);
            }
          },
          itemBuilder: (_) => [
            PopupMenuItem(value: 'connect', child: Text(tr('اتصال با این', 'Connect with this'))),
            PopupMenuItem(value: 'ping', child: Text(tr('تست تأخیر', 'Test delay'))),
            PopupMenuItem(value: 'copy', child: Text(tr('کپی لینک', 'Copy link'))),
            PopupMenuItem(value: 'del', child: Text(tr('حذف', 'Delete'))),
          ],
        ),
      ]),
      onTap: () => v2ray.select(p),
    );
  }

  /// Lowest ping first; untested after tested; failed (✕) last. Stable otherwise.
  List<V2Profile> _sorted(List<V2Profile> l) {
    if (!app.flag('v2SortPing')) return l;
    int key(V2Profile p) => p.ping == null ? 1000000 : (p.ping! < 0 ? 2000000 : p.ping!);
    final idx = {for (var i = 0; i < l.length; i++) l[i]: i};
    return [...l]..sort((a, b) { final c = key(a).compareTo(key(b)); return c != 0 ? c : idx[a]!.compareTo(idx[b]!); });
  }

  @override
  Widget build(BuildContext context) {
    final groups = <String?, List<V2Profile>>{};
    for (final p in v2ray.profiles) {
      groups.putIfAbsent(p.subId, () => []).add(p);
    }
    String subName(String? id) => id == null ? tr('کانفیگ‌های من', 'My configs') : (v2ray.subs.where((s) => s.id == id).map((s) => s.name).firstOrNull ?? id);
    return GlassScaffold(
      appBar: AppBar(
        title: const Text('v2ray'),
        actions: [
          IconButton(
            tooltip: app.flag('v2SortPing') ? tr('ترتیب اصلی', 'Original order') : tr('مرتب‌سازی بر اساس پینگ', 'Sort by ping'),
            icon: Icon(Icons.sort_rounded, color: app.flag('v2SortPing') ? Theme.of(context).colorScheme.primary : null),
            onPressed: v2ray.profiles.isEmpty ? null : () => setState(() => app.set('v2SortPing', !app.flag('v2SortPing'))),
          ),
          IconButton(tooltip: tr('تست همه', 'Test all'), icon: const Icon(Icons.speed_rounded), onPressed: v2ray.profiles.isEmpty ? null : v2ray.pingAll),
          IconButton(tooltip: tr('تنظیمات', 'Settings'), icon: const Icon(Icons.tune_rounded), onPressed: _settings),
          PopupMenuButton<String>(
            icon: const Icon(Icons.add_rounded),
            onSelected: (v) {
              switch (v) {
                case 'paste':
                  _paste();
                case 'scan':
                  _scan();
                case 'text':
                  _typeText();
                case 'sub':
                  _addSub();
                case 'upd':
                  _updateSubs();
              }
            },
            itemBuilder: (_) => [
              PopupMenuItem(value: 'paste', child: Text(tr('چسباندن از کلیپ‌بورد', 'Paste from clipboard'))),
              PopupMenuItem(value: 'scan', child: Text(tr('اسکن QR', 'Scan QR'))),
              PopupMenuItem(value: 'text', child: Text(tr('وارد کردن دستی / JSON', 'Enter manually / JSON'))),
              PopupMenuItem(value: 'sub', child: Text(tr('افزودن اشتراک', 'Add subscription'))),
              PopupMenuItem(value: 'upd', child: Text(tr('به‌روزرسانی اشتراک‌ها', 'Update subscriptions'))),
            ],
          ),
        ],
      ),
      body: ListView(children: [
        _header(),
        if (v2ray.profiles.isEmpty)
          Padding(
            padding: const EdgeInsets.all(28),
            child: Text(tr('هنوز کانفیگی ندارید. از دکمهٔ + لینک vless / vmess / trojan / ss / hysteria2، اشتراک یا JSON اضافه کنید.', 'No configs yet. Use + to add a vless / vmess / trojan / ss / hysteria2 link, a subscription or a JSON.'), textAlign: TextAlign.center),
          ),
        for (final e in groups.entries) ...[
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 2),
            child: Row(children: [
              Expanded(child: Text(subName(e.key), style: const TextStyle(fontWeight: FontWeight.bold))),
              if (e.key != null) ...[
                IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.refresh_rounded, size: 20), onPressed: () async {
                  final s = v2ray.subs.firstWhere((s) => s.id == e.key);
                  final n = await v2ray.refreshSub(s);
                  _snack(n < 0 ? tr('ناموفق', 'Failed') : tr('$n کانفیگ', '$n config(s)'));
                }),
                IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.delete_outline_rounded, size: 20), onPressed: () => v2ray.removeSub(v2ray.subs.firstWhere((s) => s.id == e.key))),
              ],
            ]),
          ),
          for (final p in _sorted(e.value)) _tile(p),
        ],
        Padding(
          padding: const EdgeInsets.all(16),
          child: Text(
            tr('هستهٔ PattNG (Xray). اتصال، کل برنامه‌های گوشی را از VPN رد می‌کند؛ مرورگر آبتین هم از همین هسته استفاده می‌کند.', 'PattNG core (Xray). Connecting routes every app on the phone through the VPN; the Abtin browser uses the same core.'),
            style: const TextStyle(fontSize: 11),
            textAlign: TextAlign.center,
          ),
        ),
        const SizedBox(height: 30),
      ]),
    );
  }
}
