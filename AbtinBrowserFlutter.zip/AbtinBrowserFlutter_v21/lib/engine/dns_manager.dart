import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import '../app_state.dart';

class DnsPreset {
  const DnsPreset(this.id, this.fa, this.en, this.servers);
  final String id, fa, en;
  final List<String> servers;
}

const dnsPresets = <DnsPreset>[
  DnsPreset('shecan', 'شکن', 'Shecan', ['178.22.122.100', '185.51.200.2']),
  DnsPreset('electro', 'الکترو', 'Electro', ['78.157.42.100', '78.157.42.101']),
  DnsPreset('radar', 'رادار گیم', 'Radar Game', ['10.202.10.10', '10.202.10.11']),
  DnsPreset('403', '403.online', '403.online', ['10.202.10.202', '10.202.10.102']),
  DnsPreset('begzar', 'بگذر', 'Begzar', ['185.55.226.26', '185.55.225.25']),
  DnsPreset('google', 'گوگل', 'Google DNS', ['8.8.8.8', '8.8.4.4']),
  DnsPreset('cloudflare', 'کلودفلر', 'Cloudflare DNS', ['1.1.1.1', '1.0.0.1']),
  DnsPreset('cf_mal', 'کلودفلر (ضد بدافزار)', 'Cloudflare (malware blocking)', ['1.1.1.2', '1.0.0.2']),
  DnsPreset('cf_fam', 'کلودفلر (خانواده)', 'Cloudflare (family)', ['1.1.1.3', '1.0.0.3']),
  DnsPreset('quad9', 'Quad9', 'Quad9', ['9.9.9.9', '149.112.112.112']),
  DnsPreset('opendns', 'OpenDNS', 'OpenDNS', ['208.67.222.222', '208.67.220.220']),
  DnsPreset('opendns_fam', 'OpenDNS (Family Shield)', 'OpenDNS (Family Shield)', ['208.67.222.123', '208.67.220.123']),
  DnsPreset('adguard', 'AdGuard (بدون تبلیغ)', 'AdGuard (ad-free)', ['94.140.14.14', '94.140.15.15']),
  DnsPreset('adguard_fam', 'AdGuard (خانواده)', 'AdGuard (family)', ['94.140.14.15', '94.140.15.16']),
  DnsPreset('cira', 'CIRA Canadian Shield', 'CIRA Canadian Shield', ['149.112.121.10', '149.112.122.10']),
  DnsPreset('cira_fam', 'CIRA Canadian Shield (Family)', 'CIRA Canadian Shield (Family)', ['149.112.121.30', '149.112.122.30']),
  DnsPreset('cleanb_sec', 'CleanBrowsing (Security)', 'CleanBrowsing (Security)', ['185.228.168.9', '185.228.169.9']),
  DnsPreset('cleanb_fam', 'CleanBrowsing (Family Shield)', 'CleanBrowsing (Family Shield)', ['185.228.168.168', '185.228.169.168']),
  DnsPreset('comodo', 'Comodo Secure DNS', 'Comodo Secure DNS', ['8.26.56.26', '8.20.247.20']),
  DnsPreset('controld', 'Control D', 'Control D', ['76.76.2.0', '76.76.10.0']),
  DnsPreset('controld_fam', 'Control D (Family Friendly)', 'Control D (Family Friendly)', ['76.76.2.4', '76.76.10.4']),
  DnsPreset('dnsfamily', 'DNS for Family', 'DNS for Family', ['94.130.180.225', '78.47.64.161']),
  DnsPreset('dnssb', 'DNS.SB', 'DNS.SB', ['185.222.222.222', '45.11.45.11']),
  DnsPreset('dnswatch', 'DNS.Watch', 'DNS.Watch', ['84.200.69.80', '84.200.70.40']),
  DnsPreset('fdn', 'French Data Network (FDN)', 'French Data Network (FDN)', ['80.67.169.12', '80.67.169.40']),
  DnsPreset('level3', 'Level3 / Lumen', 'Level3 / Lumen', ['4.2.2.1', '4.2.2.2']),
  DnsPreset('neustar', 'Neustar UltraDNS', 'Neustar UltraDNS', ['156.154.70.1', '156.154.71.1']),
  DnsPreset('neustar_fam', 'Neustar UltraDNS (Family Shield)', 'Neustar UltraDNS (Family Shield)', ['156.154.70.3', '156.154.71.3']),
  DnsPreset('neustar_safe', 'Neustar UltraDNS (Safe)', 'Neustar UltraDNS (Safe)', ['156.154.70.2', '156.154.71.2']),
  DnsPreset('safedns', 'SafeDNS', 'SafeDNS', ['195.46.39.39', '195.46.39.40']),
  DnsPreset('yandex', 'Yandex DNS', 'Yandex DNS', ['77.88.8.8', '77.88.8.1']),
  DnsPreset('yandex_safe', 'Yandex DNS (Safe)', 'Yandex DNS (Safe)', ['77.88.8.88', '77.88.8.2']),
  DnsPreset('yandex_fam', 'Yandex DNS (Family Shield)', 'Yandex DNS (Family Shield)', ['77.88.8.7', '77.88.8.3']),
];

/// System-wide DNS changer (a local VPN that only carries DNS queries). Android allows one VPN at a time.
class DnsManager extends ChangeNotifier {
  DnsManager(this.app);
  final AppState app;
  static const MethodChannel _m = MethodChannel('abtin/dns');

  bool on = false;
  bool busy = false;
  String error = '';
  bool _ready = false;

  String get selected => app.str('dnsPreset').isEmpty ? 'shecan' : app.str('dnsPreset');
  /// User-added entries: [{n: name, s: "ip1,ip2"}].
  List<Map<String, String>> get customs {
    try {
      return (jsonDecode(app.str('dnsCustoms').isEmpty ? '[]' : app.str('dnsCustoms')) as List).map((e) => {'n': '${(e as Map)['n']}', 's': '${e['s']}'}).toList();
    } catch (_) { return []; }
  }

  static List<String> parseIps(String v) => v.split(RegExp(r'[\s,;]+')).where((e) => RegExp(r'^\d{1,3}(\.\d{1,3}){3}$').hasMatch(e)).toList();

  /// Returns false when no valid IPv4 was found.
  bool addCustom(String name, String ips) {
    final ok = parseIps(ips);
    if (ok.isEmpty) return false;
    final n = name.trim().isEmpty ? ok.first : name.trim();
    final l = customs..removeWhere((e) => e['n'] == n);
    l.add({'n': n, 's': ok.join(',')});
    app.set('dnsCustoms', jsonEncode(l));
    select('c:$n');
    return true;
  }

  void removeCustom(String name) {
    app.set('dnsCustoms', jsonEncode(customs..removeWhere((e) => e['n'] == name)));
    if (selected == 'c:$name') { app.set('dnsPreset', 'shecan'); if (on) connect(); }
    notifyListeners();
  }

  List<String> get servers {
    if (selected.startsWith('c:')) {
      final n = selected.substring(2);
      return parseIps(customs.where((e) => e['n'] == n).map((e) => e['s']!).firstOrNull ?? '');
    }
    return (dnsPresets.where((p) => p.id == selected).firstOrNull ?? dnsPresets.first).servers;
  }

  Future<void> init() async {
    if (_ready) return;
    _ready = true;
    // First run: start from the DNS the user already entered in this app (v2ray DNS field, or the DoH provider).
    if (app.str('dnsPreset').isEmpty) {
      final v2 = app.str('v2Dns').trim();
      final doh = app.str('doh');
      if (v2.isNotEmpty && v2 != '8.8.8.8,8.8.4.4') {
        addCustom('Custom', v2);
      } else if (dnsPresets.any((p) => p.id == doh)) {
        app.set('dnsPreset', doh);
      } else {
        app.set('dnsPreset', 'shecan');
      }
    }
    _m.setMethodCallHandler((c) async {
      if (c.method == 'state' && c.arguments is Map) {
        final a = Map<String, dynamic>.from(c.arguments as Map);
        on = a['on'] == true;
        error = '${a['error'] ?? ''}';
        busy = false;
        notifyListeners();
      }
      return null;
    });
    try {
      final r = await _m.invokeMethod<Map>('query');
      on = r?['on'] == true;
    } catch (_) {}
    notifyListeners();
  }

  void select(String id) {
    app.set('dnsPreset', id);
    notifyListeners();
    if (on) connect(); // switch servers on the fly
  }

  /// Returns an error key or null.
  Future<String?> connect() async {
    final s = servers;
    if (s.isEmpty) return 'no_servers';
    busy = true;
    error = '';
    notifyListeners();
    try {
      await _m.invokeMethod('start', {'servers': s.join(',')});
    } catch (e) {
      busy = false;
      error = '$e';
      notifyListeners();
      return 'start_failed';
    }
    return null;
  }

  Future<void> disconnect() async {
    try {
      await _m.invokeMethod('stop');
    } catch (_) {}
    on = false;
    busy = false;
    notifyListeners();
  }
}
