import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import '../../app_state.dart';
import '../app_proxy.dart';
import 'v2ray_config.dart';
import 'v2ray_parser.dart';

class V2Profile {
  V2Profile({required this.id, required this.name, required this.type, required this.entry, this.subId, this.server = '', this.port = 0});
  final String id;
  String name, type, entry, server;
  String? subId;
  int port;
  int? ping; // ms, -1 = failed, null = not tested
  bool testing = false;

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'type': type, 'entry': entry, 'subId': subId, 'server': server, 'port': port};
  factory V2Profile.fromJson(Map<String, dynamic> j) => V2Profile(
        id: j['id'] as String, name: j['name'] as String, type: j['type'] as String, entry: j['entry'] as String,
        subId: j['subId'] as String?, server: (j['server'] ?? '') as String, port: (j['port'] ?? 0) as int,
      );
}

class V2Sub {
  V2Sub({required this.id, required this.name, required this.url, this.updated = 0});
  final String id;
  String name, url;
  int updated;
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'url': url, 'updated': updated};
  factory V2Sub.fromJson(Map<String, dynamic> j) => V2Sub(id: j['id'] as String, name: j['name'] as String, url: j['url'] as String, updated: (j['updated'] ?? 0) as int);
}

/// v2ray / Xray tunnel: profiles, subscriptions, system-wide VPN control. The native side lives in the ":v2ray" process.
class V2rayManager extends ChangeNotifier {
  V2rayManager(this.app);
  final AppState app;

  static const MethodChannel _m = MethodChannel('abtin/v2ray');
  static const EventChannel _e = EventChannel('abtin/v2ray/events');

  List<V2Profile> profiles = [];
  List<V2Sub> subs = [];
  String? selectedId;
  String status = 'disconnected'; // disconnected | connecting | connected | error
  String error = '';
  int up = 0, down = 0, totalUp = 0, totalDown = 0;
  DateTime? since;
  int _socksPort = V2Config.socksPort;
  bool _ready = false;
  String? busyMsg;
  VoidCallback? onProxyChanged;
  Completer<void>? _waitDown;
  final Map<String, Timer> _pingTimers = {};

  bool get connected => status == 'connected';
  bool get connecting => status == 'connecting';
  V2Profile? get selected {
    for (final p in profiles) {
      if (p.id == selectedId) return p;
    }
    return null;
  }

  V2Options get options => V2Options(
        bypassIran: app.flag('v2BypassIran'), blockAds: app.flag('v2BlockAds'), blockUdp443: app.flag('v2BlockUdp'),
        bypassLan: app.flag('v2BypassLan'), ipv6: app.flag('v2Ipv6'),
        mtu: int.tryParse(app.str('v2Mtu').trim()) ?? 1500, vpnDns: app.str('v2Dns'),
      );

  Future<void> init() async {
    if (_ready) return;
    _ready = true;
    final p = app.prefs;
    try {
      profiles = (jsonDecode(p.getString('v2_profiles_v1') ?? '[]') as List).map((e) => V2Profile.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      subs = (jsonDecode(p.getString('v2_subs_v1') ?? '[]') as List).map((e) => V2Sub.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) {}
    selectedId = p.getString('v2_sel');
    _socksPort = p.getInt('v2_socks') ?? V2Config.socksPort;
    try {
      _e.receiveBroadcastStream().listen(_onEvent, onError: (Object _) {});
      await _m.invokeMethod('query');
    } catch (e) {
      debugPrint('v2ray init: $e');
    }
    notifyListeners();
  }

  void _save() {
    final p = app.prefs;
    p.setString('v2_profiles_v1', jsonEncode(profiles.map((e) => e.toJson()).toList()));
    p.setString('v2_subs_v1', jsonEncode(subs.map((e) => e.toJson()).toList()));
    if (selectedId != null) p.setString('v2_sel', selectedId!);
  }

  void _onEvent(dynamic d) {
    if (d is! Map) return;
    switch (d['type']) {
      case 'state':
        status = '${d['state']}';
        error = '${d['error'] ?? ''}';
        if (status == 'connected') {
          since ??= DateTime.now();
        } else {
          since = null;
          up = down = 0;
          if (status == 'disconnected' || status == 'error') totalUp = totalDown = 0;
        }
        final port = status == 'connected' ? _socksPort : 0;
        AppProxy.on = status == 'connected';
        if (port != app.proxyPort) {
          app.proxyPort = port;
          onProxyChanged?.call();
        }
        if ((status == 'disconnected' || status == 'error') && _waitDown != null && !_waitDown!.isCompleted) _waitDown!.complete();
        notifyListeners();
      case 'stats':
        up = (d['up'] ?? 0) as int;
        down = (d['down'] ?? 0) as int;
        totalUp = (d['totalUp'] ?? 0) as int;
        totalDown = (d['totalDown'] ?? 0) as int;
        notifyListeners();
      case 'ping':
        final id = '${d['id']}';
        _pingTimers.remove(id)?.cancel();
        for (final pr in profiles) {
          if (pr.id == id) {
            pr.ping = (d['ms'] ?? -1) as int;
            pr.testing = false;
          }
        }
        notifyListeners();
    }
  }

  // ---- import ----
  String _newId() => '${DateTime.now().microsecondsSinceEpoch}${profiles.length}';

  /// Adds every link / JSON config found in [text]. Returns how many were new.
  int addText(String text, {String? subId}) {
    var n = 0;
    for (final entry in V2Parser.extract(text)) {
      if (profiles.any((p) => p.entry == entry && p.subId == subId)) continue;
      final d = V2Config.describe(entry);
      if (d == null) continue;
      profiles.add(V2Profile(id: _newId(), name: d.name, type: d.type, entry: entry, subId: subId, server: d.server, port: d.port));
      n++;
    }
    if (n > 0) {
      selectedId ??= profiles.first.id;
      _save();
      notifyListeners();
    }
    return n;
  }

  Future<String> _fetch(String url) async {
    final r = await Dio().get<String>(url,
        options: Options(responseType: ResponseType.plain, headers: {'User-Agent': 'v2rayNG/2.3.13'}, receiveTimeout: const Duration(seconds: 25), sendTimeout: const Duration(seconds: 15)));
    return r.data ?? '';
  }

  /// Returns the number of profiles after the update, or -1 on failure.
  Future<int> addSub(String name, String url) async {
    final s = V2Sub(id: _newId(), name: name.isEmpty ? Uri.tryParse(url)?.host ?? 'sub' : name, url: url.trim());
    subs.add(s);
    _save();
    return refreshSub(s);
  }

  Future<int> refreshSub(V2Sub s) async {
    try {
      final body = await _fetch(s.url);
      final entries = V2Parser.extract(body);
      if (entries.isEmpty) return -1;
      final keepSel = selected?.entry;
      profiles.removeWhere((p) => p.subId == s.id);
      addText(entries.join('\n'), subId: s.id);
      if (keepSel != null) {
        for (final p in profiles) {
          if (p.entry == keepSel) selectedId = p.id;
        }
      }
      if (selected == null && profiles.isNotEmpty) selectedId = profiles.first.id;
      s.updated = DateTime.now().millisecondsSinceEpoch;
      _save();
      notifyListeners();
      return entries.length;
    } catch (e) {
      debugPrint('sub refresh: $e');
      return -1;
    }
  }

  void removeProfile(V2Profile p) {
    profiles.remove(p);
    if (selectedId == p.id) selectedId = profiles.isEmpty ? null : profiles.first.id;
    _save();
    notifyListeners();
  }

  void removeSub(V2Sub s) {
    subs.remove(s);
    profiles.removeWhere((p) => p.subId == s.id);
    if (selected == null) selectedId = profiles.isEmpty ? null : profiles.first.id;
    _save();
    notifyListeners();
  }

  void select(V2Profile p) {
    selectedId = p.id;
    _save();
    notifyListeners();
  }

  // ---- connection ----
  /// Starts the system-wide tunnel with [p] (default: the selected one). Returns an error key or null.
  Future<String?> connect([V2Profile? p]) async {
    p ??= selected;
    if (p == null) return 'no_profile';
    final b = V2Config.build(p.entry, options);
    if (b == null) return 'unsupported';
    if (status == 'connected' || status == 'connecting') {
      _waitDown = Completer<void>();
      await _m.invokeMethod('stop');
      await _waitDown!.future.timeout(const Duration(seconds: 6), onTimeout: () {});
      await Future<void>.delayed(const Duration(milliseconds: 400));
    }
    selectedId = p.id;
    _socksPort = b.socksPort;
    app.prefs.setInt('v2_socks', _socksPort);
    _save();
    status = 'connecting';
    error = '';
    notifyListeners();
    try {
      await _m.invokeMethod('start', {
        'config': b.json,
        'name': p.name,
        'mtu': options.mtu,
        'ipv6': options.ipv6,
        'bypassLan': options.bypassLan,
        'dns': options.vpnDns,
      });
    } catch (e) {
      status = 'error';
      error = '$e';
      notifyListeners();
      return 'start_failed';
    }
    return null;
  }

  Future<void> disconnect() async {
    try {
      await _m.invokeMethod('stop');
    } catch (_) {}
  }

  // ---- delay test ----
  Future<void> ping(V2Profile p) async {
    final cfg = V2Config.forTest(p.entry);
    if (cfg == null) {
      p.ping = -1;
      notifyListeners();
      return;
    }
    p.testing = true;
    p.ping = null;
    notifyListeners();
    _pingTimers[p.id]?.cancel();
    _pingTimers[p.id] = Timer(const Duration(seconds: 20), () {
      p.testing = false;
      p.ping ??= -1;
      notifyListeners();
    });
    try {
      await _m.invokeMethod('ping', {'id': p.id, 'config': cfg, 'url': app.str('v2TestUrl')});
    } catch (_) {
      p.testing = false;
      p.ping = -1;
      notifyListeners();
    }
  }

  Future<void> pingAll() async {
    for (final p in List<V2Profile>.from(profiles)) {
      unawaited(ping(p));
      await Future<void>.delayed(const Duration(milliseconds: 120));
    }
  }
}
