import 'dart:convert';

/// A parsed share link: the same fields PattNG's ProfileItem keeps (cipherSuites, ech, finalMask, dialMode, ...).
class V2Item {
  V2Item(this.type);
  String type; // vless | vmess | trojan | shadowsocks | socks | hysteria2
  String remarks = '';
  String server = '';
  int port = 0;
  String password = ''; // uuid / password / auth
  String method = ''; // vmess security / vless encryption / ss cipher
  String? username, flow;
  String network = 'tcp';
  String? headerType, host, path, seed, mode, serviceName, authority, xhttpMode, xhttpExtra, finalMask, dialMode;
  int? kcpMtu, kcpTti;
  String? security; // tls | reality | null
  bool insecure = false;
  String? sni, fingerPrint, alpn, cipherSuites, echConfigList, verifyPeerCertByName, pinnedCA256;
  String? publicKey, shortId, spiderX, mldsa65Verify;
  String? obfsPassword, portHopping;
}

class V2Parser {
  static const schemes = ['vless://', 'vmess://', 'trojan://', 'ss://', 'socks://', 'socks5://', 'hysteria2://', 'hy2://'];

  static String _dec(String s) {
    try {
      return Uri.decodeComponent(s.replaceAll('+', '%2B'));
    } catch (_) {
      return s;
    }
  }

  /// Base64 (standard or URL-safe, with or without padding) -> utf8 text, or '' when it is not base64.
  static String b64(String s) {
    try {
      var t = s.trim().replaceAll('-', '+').replaceAll('_', '/').replaceAll(RegExp(r'\s'), '');
      t = t.replaceAll('=', '');
      while (t.length % 4 != 0) {
        t += '=';
      }
      return utf8.decode(base64.decode(t), allowMalformed: true);
    } catch (_) {
      return '';
    }
  }

  static Map<String, String> _query(String q) {
    final m = <String, String>{};
    if (q.isEmpty) return m;
    for (final part in q.split('&')) {
      if (part.isEmpty) continue;
      final i = part.indexOf('=');
      if (i < 0) {
        m[part] = '';
      } else {
        m[part.substring(0, i)] = _dec(part.substring(i + 1));
      }
    }
    return m;
  }

  /// scheme://user@host:port/path?query#fragment, tolerant of base64 in the user part.
  static _U? _split(String link) {
    final m = RegExp(r'^([A-Za-z0-9+.\-]+)://(.*)$', dotAll: true).firstMatch(link.trim());
    if (m == null) return null;
    final u = _U()..scheme = m.group(1)!.toLowerCase();
    var rest = m.group(2)!;
    final h = rest.indexOf('#');
    if (h >= 0) {
      u.frag = _dec(rest.substring(h + 1));
      rest = rest.substring(0, h);
    }
    final qi = rest.indexOf('?');
    if (qi >= 0) {
      u.q = _query(rest.substring(qi + 1));
      rest = rest.substring(0, qi);
    }
    final at = rest.lastIndexOf('@');
    u.user = at >= 0 ? _dec(rest.substring(0, at)) : '';
    var hp = at >= 0 ? rest.substring(at + 1) : rest;
    final slash = hp.indexOf('/');
    if (slash >= 0) hp = hp.substring(0, slash);
    if (hp.startsWith('[')) {
      final e = hp.indexOf(']');
      if (e < 0) return null;
      u.host = hp.substring(1, e);
      if (e + 1 < hp.length && hp[e + 1] == ':') u.port = int.tryParse(hp.substring(e + 2)) ?? 0;
    } else {
      final c = hp.lastIndexOf(':');
      if (c >= 0) {
        u.host = hp.substring(0, c);
        u.port = int.tryParse(hp.substring(c + 1)) ?? 0;
      } else {
        u.host = hp;
      }
    }
    return u;
  }

  /// FmtBase.getItemFormQuery
  static void _fromQuery(V2Item c, Map<String, String> q) {
    c.network = q['type'] ?? 'tcp';
    c.headerType = q['headerType'];
    c.host = q['host'];
    c.path = q['path'];
    c.seed = q['seed'];
    c.kcpMtu = int.tryParse(q['mtu'] ?? '');
    c.kcpTti = int.tryParse(q['tti'] ?? '');
    c.mode = q['mode'];
    c.serviceName = q['serviceName'];
    c.authority = q['authority'];
    c.xhttpMode = q['mode'];
    c.xhttpExtra = q['extra'];
    c.finalMask = q['fm'];
    c.dialMode = q['dialMode'];
    c.security = q['security'];
    if (c.security != 'tls' && c.security != 'reality') c.security = null;
    const keys = ['insecure', 'allowInsecure', 'allow_insecure'];
    c.insecure = keys.any((k) => q[k] == '1');
    c.sni = q['sni'];
    c.fingerPrint = q['fp'];
    c.alpn = q['alpn'];
    c.cipherSuites = q['cs'];
    c.echConfigList = q['ech'];
    c.verifyPeerCertByName = q['vcn'];
    c.pinnedCA256 = q['pcs'];
    c.publicKey = q['pbk'];
    c.shortId = q['sid'];
    c.spiderX = q['spx'];
    c.mldsa65Verify = q['pqv'];
    c.flow = q['flow'];
  }

  static V2Item? parse(String link) {
    link = link.trim();
    final l = link.toLowerCase();
    try {
      if (l.startsWith('vmess://')) return _vmess(link);
      if (l.startsWith('vless://')) return _vless(link);
      if (l.startsWith('trojan://')) return _trojan(link);
      if (l.startsWith('ss://')) return _ss(link);
      if (l.startsWith('socks://') || l.startsWith('socks5://')) return _socks(link);
      if (l.startsWith('hysteria2://') || l.startsWith('hy2://')) return _hy2(link);
    } catch (_) {}
    return null;
  }

  static V2Item? _vless(String link) {
    final u = _split(link);
    if (u == null || u.q.isEmpty || u.host.isEmpty) return null;
    final c = V2Item('vless')
      ..remarks = u.frag.isEmpty ? 'none' : u.frag
      ..server = u.host
      ..port = u.port
      ..password = u.user
      ..method = u.q['encryption'] ?? 'none';
    _fromQuery(c, u.q);
    return c;
  }

  static V2Item? _trojan(String link) {
    final u = _split(link);
    if (u == null || u.host.isEmpty) return null;
    final c = V2Item('trojan')
      ..remarks = u.frag.isEmpty ? 'none' : u.frag
      ..server = u.host
      ..port = u.port
      ..password = u.user;
    if (u.q.isEmpty) {
      c.network = 'tcp';
      c.security = 'tls';
    } else {
      _fromQuery(c, u.q);
      c.security = u.q['security'] ?? 'tls';
    }
    return c;
  }

  static V2Item? _hy2(String link) {
    final u = _split(link);
    if (u == null || u.host.isEmpty) return null;
    final c = V2Item('hysteria2')
      ..remarks = u.frag.isEmpty ? 'none' : u.frag
      ..server = u.host
      ..port = u.port == 0 ? 443 : u.port
      ..password = u.user
      ..security = 'tls'
      ..network = 'hysteria';
    if (u.q.isNotEmpty) {
      _fromQuery(c, u.q);
      c.network = 'hysteria';
      c.security = u.q['security'] ?? 'tls';
      c.obfsPassword = u.q['obfs-password'];
      c.portHopping = u.q['mport'];
      c.pinnedCA256 = u.q['pinSHA256'];
    }
    return c;
  }

  static V2Item? _socks(String link) {
    final u = _split(link);
    if (u == null || u.host.isEmpty || u.port <= 0) return null;
    final c = V2Item('socks')
      ..remarks = u.frag.isEmpty ? 'none' : u.frag
      ..server = u.host
      ..port = u.port;
    if (u.user.isNotEmpty) {
      final parts = (u.user.contains(':') ? u.user : b64(u.user)).split(':');
      if (parts.length >= 2) {
        c.username = parts.first;
        c.password = parts.sublist(1).join(':');
      }
    }
    return c;
  }

  static V2Item? _ss(String link) {
    final sip = _ssSip002(link);
    return sip ?? _ssLegacy(link);
  }

  static V2Item? _ssSip002(String link) {
    final u = _split(link);
    if (u == null || u.host.isEmpty || u.port <= 0 || u.user.isEmpty) return null;
    final c = V2Item('shadowsocks')
      ..remarks = u.frag.isEmpty ? 'none' : u.frag
      ..server = u.host
      ..port = u.port;
    final up = (u.user.contains(':') ? u.user : b64(u.user)).split(':');
    if (up.length < 2) return null;
    c.method = up.first;
    c.password = up.sublist(1).join(':');
    final plugin = u.q['plugin'];
    if (plugin != null && plugin.contains('obfs=http')) {
      final pairs = <String, String>{};
      for (final p in plugin.split(';')) {
        final kv = p.split('=');
        if (kv.length == 2) pairs[kv[0]] = kv[1];
      }
      c.network = 'tcp';
      c.headerType = 'http';
      c.host = pairs['obfs-host'];
      c.path = pairs['path'];
    }
    return c;
  }

  static V2Item? _ssLegacy(String link) {
    var r = link.substring(5);
    final c = V2Item('shadowsocks');
    final hi = r.indexOf('#');
    if (hi > 0) {
      c.remarks = _dec(r.substring(hi + 1));
      r = r.substring(0, hi);
    }
    final at = r.indexOf('@');
    r = at > 0 ? b64(r.substring(0, at)) + r.substring(at) : b64(r);
    final m = RegExp(r'^(.+?):(.*)@(.+?):(\d+?)/?$').firstMatch(r);
    if (m == null) return null;
    c.server = m.group(3)!.replaceAll('[', '').replaceAll(']', '');
    c.port = int.parse(m.group(4)!);
    c.password = m.group(2)!;
    c.method = m.group(1)!.toLowerCase();
    if (c.remarks.isEmpty) c.remarks = 'none';
    return c;
  }

  static V2Item? _vmess(String link) {
    if (link.contains('?') && link.contains('&')) {
      final u = _split(link);
      if (u == null || u.host.isEmpty) return null;
      final c = V2Item('vmess')
        ..remarks = u.frag.isEmpty ? 'none' : u.frag
        ..server = u.host
        ..port = u.port
        ..password = u.user
        ..method = u.q['encryption'] ?? 'auto';
      _fromQuery(c, u.q);
      return c;
    }
    final text = b64(link.substring(8));
    if (text.isEmpty) return null;
    final j = jsonDecode(text);
    if (j is! Map) return null;
    String s(String k) => (j[k] ?? '').toString();
    if (s('add').isEmpty || s('port').isEmpty || s('id').isEmpty || s('net').isEmpty) return null;
    final c = V2Item('vmess')
      ..remarks = s('ps')
      ..server = s('add')
      ..port = int.tryParse(s('port')) ?? 0
      ..password = s('id')
      ..method = s('scy').isEmpty ? 'auto' : s('scy')
      ..network = s('net').isEmpty ? 'tcp' : s('net')
      ..headerType = s('type')
      ..host = s('host')
      ..path = s('path');
    switch (c.network) {
      case 'kcp':
        c.seed = s('path');
      case 'grpc':
        c.mode = s('type');
        c.serviceName = s('path');
        c.authority = s('host');
    }
    final tls = s('tls');
    c.security = (tls == 'tls' || tls == 'reality') ? tls : null;
    c.sni = s('sni');
    c.fingerPrint = s('fp');
    c.alpn = s('alpn');
    c.cipherSuites = s('cs');
    c.insecure = s('insecure') == '1';
    c.verifyPeerCertByName = s('vcn');
    c.pinnedCA256 = s('pcs');
    c.dialMode = s('dialMode');
    return c;
  }

  /// Splits pasted text into importable entries: share links, or one JSON config. Also accepts a base64 subscription body.
  static List<String> extract(String text) {
    text = text.trim();
    if (text.isEmpty) return [];
    if (text.startsWith('{') || text.startsWith('[')) {
      try {
        final j = jsonDecode(text);
        if (j is Map && (j.containsKey('outbounds') || j.containsKey('inbounds'))) return [text];
        if (j is List) {
          return [for (final e in j) if (e is Map && e.containsKey('outbounds')) jsonEncode(e)];
        }
      } catch (_) {}
      return [];
    }
    var out = _links(text);
    if (out.isEmpty) {
      final d = b64(text);
      if (d.isNotEmpty) out = _links(d);
    }
    return out;
  }

  static List<String> _links(String text) {
    final out = <String>[];
    for (final raw in text.split(RegExp(r'[\r\n\s]+'))) {
      final t = raw.trim();
      if (t.isEmpty) continue;
      final l = t.toLowerCase();
      if (schemes.any(l.startsWith) && parse(t) != null) out.add(t);
    }
    return out;
  }

  static String typeOf(String entry) {
    final l = entry.trimLeft().toLowerCase();
    if (l.startsWith('{')) return 'custom';
    if (l.startsWith('vless')) return 'vless';
    if (l.startsWith('vmess')) return 'vmess';
    if (l.startsWith('trojan')) return 'trojan';
    if (l.startsWith('ss://')) return 'shadowsocks';
    if (l.startsWith('socks')) return 'socks';
    return 'hysteria2';
  }
}

class _U {
  String scheme = '', user = '', host = '', frag = '';
  int port = 0;
  Map<String, String> q = {};
}
