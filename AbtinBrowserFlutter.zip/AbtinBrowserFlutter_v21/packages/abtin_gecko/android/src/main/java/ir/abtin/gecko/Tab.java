package ir.abtin.gecko;

import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.WebExtension;

import java.util.HashMap;
import java.util.Map;

/** One browser tab = one GeckoSession plus bookkeeping. */
final class Tab {
    final int id;
    final GeckoSession session;
    final boolean privateMode;
    String url = "";
    String failedUri;          // set while Gecko shows our error page
    int blocked = 0;
    long lastBlockedEmit = 0;
    boolean popup = false;
    String popupExtId;
    WebExtension.Port contentPort;
    final Map<String, WebExtension.Action> actions = new HashMap<>();

    Tab(int id, GeckoSession session, boolean privateMode) {
        this.id = id;
        this.session = session;
        this.privateMode = privateMode;
    }
}
