// ignore_for_file: invalid_use_of_protected_member
import '../engine/app_proxy.dart';
import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../app_state.dart';
import '../engine/ext_manager.dart';
import '../engine/gecko.dart';
import '../engine/media_dl.dart';
import '../models.dart';
import '../services.dart';
import 'extensions_page.dart';
import 'glass.dart';
import 'library_pages.dart';
import 'qr_scanner_page.dart';
import 'settings_page.dart';
import 'site_icon.dart';
import 'site_settings_page.dart';
import 'splash.dart';
import 'video_player_page.dart';
import '../storage_dirs.dart';

part 'browser_chrome.dart';
part 'browser_menu.dart';
part 'browser_dialogs.dart';
part 'browser_media.dart';
part 'tab_switcher.dart';

class BrowserPage extends StatefulWidget {
  const BrowserPage({super.key});
  @override
  State<BrowserPage> createState() => _BrowserPageState();
}

class _BrowserPageState extends State<BrowserPage> with WidgetsBindingObserver implements BrowserApi {
  @override
  final tabs = <BrowserTab>[];
  int cur = 0;
  final addr = TextEditingController();
  final addrFocus = FocusNode();
  final tabScroll = ScrollController();
  int _lastTabCount = 0, _lastCur = -1;
  final findCtl = TextEditingController();
  bool editing = false, fullscreen = false, finding = false;
  bool _lastChromeEditing = false;
  int findIdx = 0, findCount = 0;
  List<Suggestion> sugg = [];
  Timer? _sugT, _applyT;
  final _dio = AppProxy.dio();
  final _snapAt = <int, int>{};
  StreamSubscription<Map<String, dynamic>>? _evSub;

  @override
  BrowserTab get current => tabs[cur.clamp(0, tabs.length - 1)];

  BrowserTab? _byId(int id) {
    for (final t in tabs) {
      if (t.nid == id) return t;
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    extMgr.bridge = this;
    gecko.onAsk = _onAsk;
    _evSub = gecko.events.listen(_onEvent);
    _snapT = Timer.periodic(Duration(seconds: app.perf ? 30 : 12), (_) { if (WidgetsBinding.instance.lifecycleState == AppLifecycleState.resumed) _snapStates(); });
    dlMgr.onStarted = (it) => toast(tr('دانلود شروع شد', 'Download started'));
    dlMgr.onFinished = (it) {
      if (it.status == 'done') {
        toast('${tr('دانلود شد', 'Downloaded')}: ${it.name}');
      } else if (it.status == 'failed') {
        toast(tr('دانلود ناموفق بود', 'Download failed'));
      }
    };
    addrFocus.addListener(() {
      if (addrFocus.hasFocus) {
        addr.selection = TextSelection(baseOffset: 0, extentOffset: addr.text.length);
        setState(() => editing = true);
      } else {
        setState(() { editing = false; sugg = []; });
        _syncAddr();
      }
    });
    app.addListener(_scheduleApply);
    v2ray.addListener(_v2Changed);
    _restore();
    WidgetsBinding.instance.addPostFrameCallback((_) => _takeExternalUrl());
  }

  /// Link opened from another app or from a pinned home-screen shortcut.
  Future<void> _takeExternalUrl() async {
    final m = await gecko.call<Map<Object?, Object?>>('takeLaunch');
    final u = '${m?['url'] ?? ''}';
    final pwa = m?['pwa'] == true;
    if (u.isEmpty || u == 'null' || !mounted) return;
    if (pwa) {
      // Re-use the already open web-app tab of the same site instead of stacking duplicates.
      final host = hostOf(u);
      final same = tabs.where((t) => t.pwa && hostOf(t.url.isNotEmpty ? t.url : (t.lazyUrl ?? '')) == host).firstOrNull;
      if (same != null) { selectTab(same); _wake(same); return; }
    }
    final cur0 = current;
    if (cur0.showHome && !cur0.started && cur0.url.isEmpty && cur0.lazyUrl == null) { cur0.pwa = pwa; navigate(cur0, u); } else { openTab(u, pwa: pwa); }
  }

  void _v2Changed() { if (mounted && app.str('topBtn') == 'vpn') setState(() {}); }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    app.removeListener(_scheduleApply);
    v2ray.removeListener(_v2Changed);
    _evSub?.cancel();
    if (extMgr.bridge == this) extMgr.bridge = null;
    if (gecko.onAsk == _onAsk) gecko.onAsk = null;
    _snapT?.cancel();
    tabScroll.dispose(); addr.dispose(); addrFocus.dispose(); findCtl.dispose(); _sugT?.cancel(); _applyT?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) gecko.call('appActive', {'active': true});
    if (s == AppLifecycleState.paused) {
      gecko.call('appActive', {'active': false});
      _snapStates();
      app.saveTabs(tabs, cur);
      app.flush();
      if (app.flag('clearOnExit')) { clearBrowsingData(history: true, cookies: true, cache: true); }
    }
  }

  void _restore() {
    final saved = app.flag('restore') ? app.loadTabs() : null;
    final l = (saved?['tabs'] as List?) ?? [];
    if (l.isEmpty) {
      tabs.add(BrowserTab());
      final hp = app.str('homepage');
      if (hp.isNotEmpty) WidgetsBinding.instance.addPostFrameCallback((_) => navigate(current, hp));
      return;
    }
    for (final m in l) {
      final t = BrowserTab(title: '${m['t'] ?? ''}', groupId: m['g'] as String?)..lazyUrl = '${m['u']}'..pwa = m['p'] == true..state = m['s'] as String?;
      tabs.add(t);
    }
    cur = ((saved!['cur'] as num?)?.toInt() ?? 0).clamp(0, tabs.length - 1);
    // Starting the app itself must show the browser, never a saved web-app (PWA) tab, even with "restore tabs" on.
    if (current.pwa) {
      final normal = tabs.lastIndexWhere((t) => !t.pwa);
      if (normal >= 0) { cur = normal; } else { tabs.add(BrowserTab()); cur = tabs.length - 1; }
    }
    WidgetsBinding.instance.addPostFrameCallback((_) => _wake(current));
  }

  /// The app was opened from its own icon while a web-app (PWA) tab was on screen: go back to the normal browser.
  BrowserTab? _lastBrowserTab;
  void _leavePwa() {
    if (!current.pwa) return;
    var t = _lastBrowserTab != null && tabs.contains(_lastBrowserTab) && !_lastBrowserTab!.pwa ? _lastBrowserTab : tabs.where((x) => !x.pwa).lastOrNull;
    if (t == null) { t = BrowserTab(); setState(() => tabs.add(t!)); }
    selectTab(t);
  }

  Timer? _snapT;
  Future<void> _snapStates() async {
    try {
      final m = await gecko.call<Map<Object?, Object?>>('tabStates');
      if (m == null || m.isEmpty) return;
      for (final e in m.entries) {
        final t = tabs.where((x) => '${x.nid}' == '${e.key}').firstOrNull;
        if (t != null && !t.private) t.state = '${e.value}';
      }
      app.saveTabs(tabs, cur);
    } catch (_) {}
  }

  void _wake(BrowserTab t) {
    final u = t.lazyUrl;
    if (u == null || t.started) return;
    final st = t.state;
    if (st != null && st.isNotEmpty) {
      // reopen the tab with its whole back/forward history
      setState(() { t.showHome = false; t.lazyUrl = null; t.url = u; t.failed = false; t.loading = true; });
      t.started = true;
      gecko.call('createTab', {'id': t.nid, 'private': t.private, 'desktop': t.desktop, 'url': u, 'state': st, 'select': t == current});
      if (t == current) { addr.text = u; addrFocus.unfocus(); }
      return;
    }
    t.lazyUrl = null;
    navigate(t, u);
  }

  void _scheduleApply() {
    _applyT?.cancel();
    _applyT = Timer(const Duration(milliseconds: 300), () async {
      await gecko.call('apply', app.geckoSettings());
      if (mounted) setState(() {});
    });
  }

  // ---------------- engine events ----------------
  void _onEvent(Map<String, dynamic> e) {
    if (!mounted) return;
    final type = '${e['t']}';
    final id = (e['tab'] as num?)?.toInt() ?? 0;
    switch (type) {
      case 'passkey': toast('${tr('اثرانگشت/کلید عبور در این مرورگر کار نکرد؛ در صفحهٔ گوگل «روش‌های دیگر» را بزنید', 'Passkey/fingerprint failed here; pick "Try another way" on the Google page')} (${e['err']})'); return;
      case 'ext': extMgr.refresh(); return;
      case 'download': dlMgr.onEvent(e); return;
      case 'dlConfirm': _dlConfirm(e); return;
      case 'dlAction': dlMgr.onAction('${e['id']}', '${e['action']}'); return;
      case 'tabCreated': _onTabCreated(e, id); return;
      case 'openUrl': _takeExternalUrl(); return;
      case 'launcherOpen': _leavePwa(); return;
      case 'tabSelect': {
        final t = _byId(id);
        if (t != null) selectTab(t);
        return;
      }
    }
    final t = _byId(id);
    if (t == null) return;
    switch (type) {
      case 'closeRequest': closeTab(t); return;
      case 'contextMenu': _hitMenu(t, e); return;
      case 'crash': toast(tr('صفحه از نو بارگذاری شد', 'Page process restarted')); return;
      case 'error': return;
      case 'media': _onMedia(t, e); return;
      case 'pageSaved': {
        dlMgr.onPageHtml(e, private: t.private).then((v) {
          if (mounted) toast(v ? tr('صفحه در دانلودها ذخیره شد', 'Page saved to Downloads') : tr('ذخیرهٔ صفحه ممکن نشد', 'Could not save the page'));
        });
        return;
      }
      case 'mediaAct': _onMediaAct(t, e); return;
    }
    if (type == 'progress') {
      // Gecko reports progress very often; rebuilding the whole page for each tick made scrolling and loading choppy.
      final np = ((e['p'] as num?)?.toDouble() ?? 0) / 100;
      if ((np - t.progress).abs() < .06 && np < 1 && np > 0) return;
    }
    var finished = false;
    setState(() {
      switch (type) {
        case 'loadStart':
          t.loading = true; t.progress = 0; t.blocked = 0; t.failed = false;
          t.media.clear(); t.mediaBlob = false;
          if ('${e['url']}'.startsWith('http')) {
            if (hostOf('${e['url']}') != hostOf(t.url)) t.faviconUrl = null;
            t.url = '${e['url']}';
          }
          break;
        case 'loadStop':
          t.loading = false; t.progress = 0; finished = true;
          break;
        case 'progress':
          t.progress = ((e['p'] as num?)?.toDouble() ?? 0) / 100;
          break;
        case 'security':
          t.secure = e['secure'] == true;
          break;
        case 'url':
          t.url = '${e['url']}';
          t.failed = e['error'] == true;
          t.showHome = false;
          break;
        case 'nav':
          if (e.containsKey('back')) t.canBack = e['back'] == true;
          if (e.containsKey('fwd')) t.canForward = e['fwd'] == true;
          break;
        case 'title':
          final ti = '${e['title'] ?? ''}';
          if (ti.isNotEmpty) t.title = ti;
          break;
        case 'fullscreen':
          if (t == current) {
            fullscreen = e['on'] == true;
            SystemChrome.setEnabledSystemUIMode(fullscreen ? SystemUiMode.immersiveSticky : SystemUiMode.edgeToEdge);
          }
          break;
        case 'pwaColor':
          final pc = '${e['c'] ?? ''}';
          t.pageColor = pc.isEmpty ? null : pc;
          break;
        case 'blocked':
          t.blocked = (e['n'] as num?)?.toInt() ?? t.blocked;
          break;
        case 'find':
          if (t == current) { findIdx = (e['current'] as num?)?.toInt() ?? 0; findCount = (e['total'] as num?)?.toInt() ?? 0; }
          break;
        case 'page':
          final data = '${e['iconData'] ?? ''}';
          final ic = data.startsWith('data:image') ? data : '${e['icon'] ?? ''}';
          if (ic.startsWith('http') || ic.startsWith('data:image')) { t.faviconUrl = ic; if (!t.private) app.rememberFavicon(t.url, ic); }
          final th = '${e['theme'] ?? ''}';
          t.themeColor = th.isEmpty ? null : th;
          break;
      }
    });
    if (t == current && !addrFocus.hasFocus && (type == 'url' || type == 'loadStart')) addr.text = t.url;
    if (finished) {
      if (!t.private && !t.failed && t.url.startsWith('http')) {
        app.addHistory(t.url, t.title);
        gecko.call('addVisited', {'url': t.url});
      }
      app.saveTabs(tabs, cur);
    }
  }

  void _onTabCreated(Map<String, dynamic> e, int id) {
    if (_byId(id) != null) return;
    final opener = _byId((e['opener'] as num?)?.toInt() ?? -1);
    final bg = e['background'] == true;
    final t = BrowserTab(nativeId: id, private: e['private'] == true, url: '${e['url'] ?? ''}', title: '${e['title'] ?? ''}', groupId: opener?.groupId, started: true)
      ..showHome = false;
    if (!bg) _snap(current);
    setState(() {
      tabs.add(t);
      if (!bg) cur = tabs.length - 1;
    });
    if (!bg) {
      gecko.call('selectTab', {'id': t.nid});
      _syncAddr();
    }
    app.saveTabs(tabs, cur);
  }

  // ---------------- BrowserApi ----------------
  @override
  BrowserTab openTab(String url, {bool active = true, bool private = false, bool pwa = false}) {
    final t = BrowserTab(private: private)..pwa = pwa;
    if (active && !current.pwa) _lastBrowserTab = current;
    if (active) _snap(current);
    setState(() { tabs.add(t); if (active) cur = tabs.length - 1; });
    if (url.isNotEmpty) navigate(t, url);
    if (active) _syncAddr();
    return t;
  }

  @override
  void closeTab(BrowserTab t) {
    final i = tabs.indexOf(t);
    if (i < 0) return;
    if (t.started) gecko.call('closeTab', {'id': t.nid});
    setState(() {
      if (tabs.length == 1) { tabs[0] = BrowserTab(); cur = 0; }
      else { tabs.removeAt(i); if (cur > i || cur >= tabs.length) cur = (cur - 1).clamp(0, tabs.length - 1); }
    });
    final c = current;
    if (c.started) gecko.call('selectTab', {'id': c.nid});
    _wake(c);
    _syncAddr();
    app.saveTabs(tabs, cur);
  }

  @override
  void selectTab(BrowserTab t) {
    final i = tabs.indexOf(t);
    if (i < 0 || i == cur) return;
    if (!current.pwa) _lastBrowserTab = current;
    _snap(current);
    setState(() => cur = i);
    if (t.started) gecko.call('selectTab', {'id': t.nid});
    _wake(t);
    _syncAddr();
  }

  /// Menu action: save the page as a single .html file (styles + images inlined) or as a PDF.
  Future<void> savePage(BrowserTab t, {required bool pdf}) async {
    toast(tr('در حال ذخیرهٔ صفحه…', 'Saving page…'));
    if (pdf) {
      final ok = await dlMgr.savePagePdf(t.nid, t.displayTitle, t.url, private: t.private);
      if (mounted) toast(ok ? tr('صفحه در دانلودها ذخیره شد', 'Page saved to Downloads') : tr('ذخیره ممکن نشد', 'Could not save'));
      return;
    }
    final sent = await gecko.call<bool>('contentCmd', {'id': t.nid, 'cmd': {'cmd': 'savePage'}});
    if (sent != true && mounted) toast(tr('ذخیرهٔ صفحه ممکن نشد', 'Could not save the page'));
  }

  @override
  void toast(String msg) {
    if (!mounted) return;
    snackTop(context, msg);
  }

  /// Thumbnail of the visible page (only possible for the tab currently shown in the GeckoView).
  Future<void> _snap(BrowserTab t, {bool force = false}) async {
    if (!t.started || t.showHome || t != current) return;
    final now = DateTime.now().millisecondsSinceEpoch;
    if (!force && t.thumb != null && now - (_snapAt[t.nid] ?? 0) < 15000) return;
    _snapAt[t.nid] = now;
    final b = await gecko.call<Uint8List>('capture', {'width': app.perf ? 160 : 300, 'png': false});
    if (b != null) t.thumb = b;
  }

  // ---------------- navigation ----------------
  String _resolve(String raw) {
    final v = raw.trim();
    if (v.isEmpty) return '';
    if (v.toLowerCase().startsWith('javascript:')) return '';
    if (RegExp(r'^[a-zA-Z][a-zA-Z0-9+.-]*://').hasMatch(v) || v.startsWith('about:') || v.startsWith('data:')) return v;
    final hostish = RegExp(r'^([\w-]+\.)+[\w-]{2,}(:\d+)?([/?#].*)?$');
    final local = RegExp(r'^(localhost|\d{1,3}(\.\d{1,3}){3})(:\d+)?([/?#].*)?$');
    if (!v.contains(' ') && local.hasMatch(v)) return 'http://$v';
    if (!v.contains(' ') && hostish.hasMatch(v)) return 'https://$v';
    return engines[app.str('engine')]!.url.replaceFirst('%s', Uri.encodeComponent(v));
  }

  @override
  void navigate(BrowserTab t, String raw) {
    final url = _resolve(raw);
    if (url.isEmpty) return;
    setState(() { t.showHome = false; t.lazyUrl = null; t.url = url; t.failed = false; t.loading = true; });
    if (!t.started) {
      t.started = true;
      gecko.call('createTab', {'id': t.nid, 'private': t.private, 'desktop': t.desktop, 'url': url, 'select': t == current});
    } else {
      gecko.call('loadUrl', {'id': t.nid, 'url': url});
      if (t == current) gecko.call('selectTab', {'id': t.nid});
    }
    if (t == current) { addr.text = url; addrFocus.unfocus(); }
  }

  void _syncAddr() {
    if (!mounted || tabs.isEmpty) return;
    if (!addrFocus.hasFocus) addr.text = current.showHome ? '' : current.url;
  }

  Future<bool> _back() async {
    if (editing) { addrFocus.unfocus(); return false; }
    if (finding) { _closeFind(); return false; }
    final t = current;
    if (fullscreen) { gecko.call('exitFullscreen', {'id': t.nid}); return false; }
    if (t.started && !t.showHome && t.canBack) { gecko.call('back', {'id': t.nid}); return false; }
    if (t.pwa) {
      if (tabs.length > 1) { closeTab(t); return false; }
      // Same as the installed-app window: first Back = Escape to the page (closes the open chat), second within 2 s = exit.
      final now = DateTime.now();
      if (_lastPwaBack != null && now.difference(_lastPwaBack!) < const Duration(seconds: 2)) return true;
      _lastPwaBack = now;
      gecko.call('escape', {'id': t.nid});
      snackTop(context, tr('برای خروج، دوباره بازگشت را بزنید', 'Press back again to exit'));
      return false;
    }
    if (t.started && !t.showHome) { setState(() { t.showHome = true; }); _syncAddr(); return false; }
    if (tabs.length > 1) { closeTab(t); return false; }
    return _confirmExit();
  }

  /// Back on the last page of the last tab: exit only when pressed twice within 2 s.
  bool _confirmExit() {
    final now = DateTime.now();
    if (_lastPwaBack != null && now.difference(_lastPwaBack!) < const Duration(seconds: 2)) return true;
    _lastPwaBack = now;
    snackTop(context, tr('برای خروج، دوباره بازگشت را بزنید', 'Press back again to exit'));
    return false;
  }

  Future<void> clearBrowsingData({bool history = false, bool cookies = false, bool cache = false, bool downloads = false, bool perms = false, int sinceMs = 0}) async {
    final cut = sinceMs == 0 ? 0 : DateTime.now().millisecondsSinceEpoch - sinceMs;
    if (history) { app.history.removeWhere((h) => h.time >= cut); app.saveHistory(); }
    if (cookies || cache || perms) await gecko.call('clearData', {'cookies': cookies, 'cache': cache, 'perms': perms});
    if (downloads) { app.downloads.removeWhere((d) => d.time >= cut && d.status != 'running'); app.saveDownloads(); }
    if (perms) { app.perms.clear(); app.prefs.setString('perms_v2', '{}'); }
  }

  // ---------------- build ----------------
  final GlobalKey _chromeKey = GlobalKey();
  DateTime? _lastPwaBack;

  @override
  Widget build(BuildContext context) {
    // Message bars appear under the top bar, not over the address bar.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final box = _chromeKey.currentContext?.findRenderObject();
      snackTopInset = (box is RenderBox && box.hasSize && !fullscreen) ? box.size.height : 0;
    });
    // Tell the native side when a Flutter text field (address / find bar) owns the keyboard, so GeckoView doesn't fight for focus.
    final chromeEditing = editing || finding;
    if (chromeEditing != _lastChromeEditing) {
      _lastChromeEditing = chromeEditing;
      gecko.call('chromeEditing', {'on': chromeEditing});
    }
    final pwaMode = current.pwa && !current.showHome;
    final pwaBg = pwaMode ? (_cssColor(current.pageColor) ?? _cssColor(current.themeColor) ?? Theme.of(context).colorScheme.surface) : null;
    final pwaIcons = (pwaBg != null && pwaBg.computeLuminance() > .5) ? Brightness.dark : Brightness.light;
    final page = PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async { if (!didPop && await _back()) SystemNavigator.pop(); },
      child: GlassScaffold(
        resizeToAvoidBottomInset: false, // SettledKeyboardInset below resizes the page once, after the keyboard has settled
        body: SettledKeyboardInset(
          immediate: chromeEditing,
          child: ColoredBox(
          color: (pwaBg != null && current.pwa && !current.showHome) ? pwaBg : Colors.transparent,
          child: SafeArea(
          child: Column(children: [
            if (!fullscreen && current.pwa && !current.showHome) ...[_progressBar()]
            else if (!fullscreen) ...[KeyedSubtree(key: _chromeKey, child: _topChrome()), _progressBar()],
            Expanded(child: Stack(children: [
              const Positioned.fill(child: GeckoViewWidget()),
              if (current.showHome) Positioned.fill(child: _home(current)),
              if (editing) _suggestionsPanel(),
            ])),
            if (finding && !fullscreen) _findBar(),
          ]),
        ))),
      ),
    );
    if (!pwaMode) return page;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle(
        statusBarColor: Colors.transparent, systemNavigationBarColor: Colors.transparent, systemNavigationBarContrastEnforced: false,
        statusBarIconBrightness: pwaIcons, systemNavigationBarIconBrightness: pwaIcons,
      ),
      child: page,
    );
  }
}
