import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'icon_prefs.dart';
import 'layouts.dart';
import 'looks.dart';
import 'color_spec.dart';
import '../services/copy_job.dart';
import 'l10n.dart';

class AppSettings extends ChangeNotifier {
  late SharedPreferences _p;
  bool dark = true, showHidden = false, confirmDelete = true, asc = true, trashEnabled = true, grid = false, folderSizes = true, dual = false, bgCopy = true;
  int themeId = 0;
  String layoutId = 'classic'; // app structure: classic | drawer | dashboard | rail | tabs (core/layouts.dart)
  int btnColor = 0, btnText = 0; // 0 = follow palette / automatic
  String look = 'classic'; // visual theme: classic | neon | glass | gradient (core/looks.dart)
  bool accentGradient = true; // accent surfaces use a primary -> secondary gradient (false = solid primary)
  Map<String, int> themeOv = {}; // the user's own colours on top of the palette (keys: themeOvKeys)
  int styleVer = 0; // bumped on every visual-style change; AppStyleScope repaints const widgets with it
  String audioStyle = 'vinyl'; // music player look: 'vinyl' | 'neon'
  int sortBy = 0; // 0 name 1 size 2 date 3 type
  bool sortPerFolder = false; // new sort choices apply to the current folder only
  final Map<String, List<int>> folderSort = {}; // path -> [sortBy, asc ? 1 : 0]
  List<String> favorites = [], recents = [];

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    dark = _p.getBool('dark') ?? true;
    themeId = _p.getInt('themeId') ?? 0;
    final lid = _p.getString('layout') ?? 'classic';
    layoutId = appLayouts.any((l) => l.id == lid) ? lid : 'classic';
    final lk = _p.getString('look') ?? 'classic';
    look = appLooks.any((l) => l.id == lk) ? lk : 'classic';
    accentGradient = _p.getBool('accentGrad') ?? true;
    try {
      final m = jsonDecode(_p.getString('themeOv') ?? '{}') as Map;
      themeOv = {for (final e in m.entries) '${e.key}': (e.value as num).toInt()};
    } catch (_) {
      themeOv = {};
    }
    Looks.current = look;
    Looks.accentGradient = accentGradient;
    btnColor = _p.getInt('btnColor') ?? 0;
    btnText = _p.getInt('btnText') ?? 0;
    audioStyle = _p.getString('audioStyle') ?? 'vinyl';
    showHidden = _p.getBool('hidden') ?? false;
    confirmDelete = _p.getBool('confirm') ?? true;
    asc = _p.getBool('asc') ?? true;
    trashEnabled = _p.getBool('trash') ?? true;
    grid = _p.getBool('grid') ?? false;
    folderSizes = _p.getBool('fsize') ?? true;
    dual = _p.getBool('dual') ?? false;
    bgCopy = _p.getBool('bgCopy') ?? true;
    CopyJob.background = bgCopy;
    try {
      IconPrefs.fromJson(jsonDecode(_p.getString('iconPrefs') ?? '{}') as Map);
    } catch (_) {}
    sortBy = _p.getInt('sort') ?? 0;
    sortPerFolder = _p.getBool('sortPerFolder') ?? false;
    try {
      final m = jsonDecode(_p.getString('folderSort') ?? '{}') as Map;
      folderSort..clear()..addAll({for (final e in m.entries) '${e.key}': [for (final x in (e.value as List)) (x as num).toInt()]});
    } catch (_) {}
    L.use(_p.getString('lang') ?? 'fa');
    favorites = _p.getStringList('fav') ?? [];
    recents = _p.getStringList('recent') ?? [];
  }

  void _save() => notifyListeners();
  void setDark(bool v) { dark = v; _p.setBool('dark', v); _save(); }
  void setAudioStyle(String v) { audioStyle = v; _p.setString('audioStyle', v); _save(); }
  void setBtnColor(int v) { btnColor = v; _p.setInt('btnColor', v); _save(); }
  void setBtnText(int v) { btnText = v; _p.setInt('btnText', v); _save(); }
  /// Dense lists (rail layout).
  bool get dense => layoutId == 'rail';
  /// Switches the app structure; also applies the file view (list / grid) that suits it.
  void setLayout(String id) {
    final l = layoutById(id);
    layoutId = l.id;
    grid = l.grid;
    _p.setString('layout', l.id);
    _p.setBool('grid', grid);
    _save();
  }
  /// Picks a palette; the user's own colour changes on top of the previous palette are dropped.
  void setThemeId(int v) {
    themeId = v;
    _p.setInt('themeId', v);
    themeOv = {};
    _p.setString('themeOv', '{}');
    _saveStyle();
  }
  void setHidden(bool v) { showHidden = v; _p.setBool('hidden', v); _save(); }
  void setConfirm(bool v) { confirmDelete = v; _p.setBool('confirm', v); _save(); }
  void setBgCopy(bool v) { bgCopy = v; CopyJob.background = v; _p.setBool('bgCopy', v); _save(); }
  void setDual(bool v) { dual = v; _p.setBool('dual', v); _save(); }
  void _saveIcons() {
    _p.setString('iconPrefs', jsonEncode(IconPrefs.toJson()));
    styleVer++;
    _save();
  }
  /// Colour (solid or gradient) of a file-type icon; null = default.
  void setIconSpec(String key, ColorSpec? c) { c == null ? IconPrefs.specs.remove(key) : IconPrefs.specs[key] = c; _saveIcons(); }
  void setIconShape(String key, int? i) { i == null ? IconPrefs.shapes.remove(key) : IconPrefs.shapes[key] = i; _saveIcons(); }
  /// Colour of one icon of the icon sheet (applies everywhere the icon is used); null = back to the app default.
  void setIconOverride(String id, ColorSpec? c) { c == null ? IconPrefs.overrides.remove(id) : IconPrefs.overrides[id] = c; _saveIcons(); }
  /// App-wide icon style: 0 = theme's own, 1 = theme gradient, 2 = custom gradient.
  void setIconMode(int m) { IconPrefs.mode = m; _saveIcons(); }
  void setIconCustom(ColorSpec c) { IconPrefs.custom = c; IconPrefs.mode = 2; _saveIcons(); }
  void resetIcons() { IconPrefs.specs.clear(); IconPrefs.shapes.clear(); IconPrefs.overrides.clear(); _saveIcons(); }
  void resetIconOverrides() { IconPrefs.overrides.clear(); _saveIcons(); }

  // ---- looks and theme colours
  void _saveStyle() { styleVer++; _save(); }
  /// Applies a look: its palette, layout and icon style. Colour changes of the previous look are dropped.
  void setLook(String id) {
    final l = lookById(id);
    look = l.id;
    Looks.current = look;
    _p.setString('look', look);
    if (l.palette >= 0) { themeId = l.palette; _p.setInt('themeId', themeId); }
    if (l.layout != null) {
      final lay = layoutById(l.layout!);
      layoutId = lay.id;
      grid = lay.grid;
      _p.setString('layout', layoutId);
      _p.setBool('grid', grid);
    }
    themeOv = {};
    _p.setString('themeOv', '{}');
    // the look themes come with the gradient icon set; the classic look keeps the icons as they were
    IconPrefs.mode = look == 'classic' ? 0 : 1;
    _p.setString('iconPrefs', jsonEncode(IconPrefs.toJson()));
    _saveStyle();
  }
  void setAccentGradient(bool v) { accentGradient = v; Looks.accentGradient = v; _p.setBool('accentGrad', v); _saveStyle(); }
  /// One of the theme colours (keys: themeOvKeys); null = follow the palette again.
  void setThemeColor(String key, int? c) {
    c == null ? themeOv.remove(key) : themeOv[key] = c;
    _p.setString('themeOv', jsonEncode(themeOv));
    _saveStyle();
  }
  void resetThemeColors() { themeOv = {}; _p.setString('themeOv', '{}'); _saveStyle(); }
  void setGrid(bool v) { grid = v; _p.setBool('grid', v); _save(); }
  void setFolderSizes(bool v) { folderSizes = v; _p.setBool('fsize', v); _save(); }
  void setTrash(bool v) { trashEnabled = v; _p.setBool('trash', v); _save(); }
  void setLang(String v) { L.use(v); _p.setString('lang', v); _save(); }
  void setSort(int s, bool a) { sortBy = s; asc = a; _p.setInt('sort', s); _p.setBool('asc', a); _save(); }
  /// Sort of [path]: its own setting when it has one, else the global one.
  (int, bool) sortFor(String path) {
    final o = folderSort[path];
    return o == null || o.length < 2 ? (sortBy, asc) : (o[0], o[1] == 1);
  }

  bool hasFolderSort(String path) => folderSort.containsKey(path);
  void _saveFolderSort() { _p.setString('folderSort', jsonEncode(folderSort)); _save(); }
  void setFolderSort(String path, int s, bool a) { folderSort[path] = [s, a ? 1 : 0]; _saveFolderSort(); }
  void clearFolderSort(String path) { folderSort.remove(path); _saveFolderSort(); }
  void setSortPerFolder(bool v) { sortPerFolder = v; _p.setBool('sortPerFolder', v); _save(); }
  bool isFav(String path) => favorites.contains(path);
  void toggleFav(String path) {
    isFav(path) ? favorites.remove(path) : favorites.add(path);
    _p.setStringList('fav', favorites);
    _save();
  }
  void renamePath(String from, String to) {
    String m(String x) => x == from ? to : (x.startsWith('$from/') ? to + x.substring(from.length) : x);
    favorites = favorites.map(m).toList();
    recents = recents.map(m).toList();
    _p.setStringList('fav', favorites);
    _p.setStringList('recent', recents);
    if (folderSort.keys.any((k) => m(k) != k)) {
      final moved = {for (final e in folderSort.entries) m(e.key): e.value};
      folderSort..clear()..addAll(moved);
      _p.setString('folderSort', jsonEncode(folderSort));
    }
    _save();
  }
  void removePath(String path) {
    bool g(String x) => x == path || x.startsWith('$path/');
    favorites.removeWhere(g);
    recents.removeWhere(g);
    _p.setStringList('fav', favorites);
    _p.setStringList('recent', recents);
    if (folderSort.keys.any(g)) {
      folderSort.removeWhere((k, _) => g(k));
      _p.setString('folderSort', jsonEncode(folderSort));
    }
    _save();
  }
  void addRecent(String path) {
    recents.remove(path);
    recents.insert(0, path);
    if (recents.length > 60) recents.removeLast();
    _p.setStringList('recent', recents);
    notifyListeners();
  }
}
