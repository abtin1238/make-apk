import 'package:flutter/material.dart' hide Icon;
import '../core/color_spec.dart';
import '../core/icon_prefs.dart';
import '../core/layouts.dart';
import '../widgets/app_icon.dart';

String hexOf(Color c) => '#${(c.value & 0xFFFFFF).toRadixString(16).padLeft(6, '0').toUpperCase()}';

Color? _parseHex(String t) {
  var h = t.trim().replaceAll('#', '');
  if (h.length == 6) h = 'FF$h';
  if (h.length != 8) return null;
  final v = int.tryParse(h, radix: 16);
  return v == null ? null : Color(v);
}

/// Slider whose track is painted with [colors].
class _GSlider extends StatelessWidget {
  final double value, min, max;
  final List<Color> colors;
  final ValueChanged<double> onChanged;
  final ValueChanged<double> onEnd;
  const _GSlider({required this.value, required this.min, required this.max, required this.colors, required this.onChanged, required this.onEnd});

  @override
  Widget build(BuildContext context) => SizedBox(
        height: 34,
        child: Stack(alignment: Alignment.center, children: [
          Container(
            height: 14,
            margin: const EdgeInsets.symmetric(horizontal: 14),
            decoration: BoxDecoration(gradient: LinearGradient(colors: colors), borderRadius: BorderRadius.circular(7), border: Border.all(color: Colors.white24)),
          ),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              trackHeight: 14,
              activeTrackColor: Colors.transparent,
              inactiveTrackColor: Colors.transparent,
              thumbColor: Colors.white,
              overlayColor: Colors.white24,
              thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 11, elevation: 3),
              overlayShape: const RoundSliderOverlayShape(overlayRadius: 14),
            ),
            child: Slider(value: value.clamp(min, max).toDouble(), min: min, max: max, onChanged: onChanged, onChangeEnd: onEnd),
          ),
        ]),
      );
}

/// Hue / saturation / brightness sliders, a hex field and quick swatches.
/// [onChanged] fires while dragging (use it for a local preview), [onCommit] when the choice is final.
class ColorPickerPanel extends StatefulWidget {
  final Color color;
  final ValueChanged<Color> onChanged;
  final ValueChanged<Color> onCommit;
  const ColorPickerPanel({super.key, required this.color, required this.onChanged, required this.onCommit});
  @override
  State<ColorPickerPanel> createState() => _ColorPickerPanelState();
}

class _ColorPickerPanelState extends State<ColorPickerPanel> {
  late HSVColor hsv;
  late final TextEditingController hex;

  @override
  void initState() {
    super.initState();
    hsv = HSVColor.fromColor(widget.color);
    hex = TextEditingController(text: hexOf(widget.color));
  }

  @override
  void dispose() {
    hex.dispose();
    super.dispose();
  }

  Color get _c => hsv.toColor();

  void _set(HSVColor v, {bool commit = false, bool text = true}) {
    setState(() => hsv = v);
    if (text) hex.text = hexOf(_c);
    widget.onChanged(_c);
    if (commit) widget.onCommit(_c);
  }

  @override
  Widget build(BuildContext context) {
    final h = hsv.hue;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _GSlider(
        value: h, min: 0, max: 360,
        colors: [for (var i = 0; i <= 6; i++) HSVColor.fromAHSV(1, i * 60.0, 1, 1).toColor()],
        onChanged: (v) => _set(hsv.withHue(v)),
        onEnd: (_) => widget.onCommit(_c),
      ),
      _GSlider(
        value: hsv.saturation, min: 0, max: 1,
        colors: [HSVColor.fromAHSV(1, h, 0, hsv.value).toColor(), HSVColor.fromAHSV(1, h, 1, hsv.value).toColor()],
        onChanged: (v) => _set(hsv.withSaturation(v)),
        onEnd: (_) => widget.onCommit(_c),
      ),
      _GSlider(
        value: hsv.value, min: 0, max: 1,
        colors: [Colors.black, HSVColor.fromAHSV(1, h, hsv.saturation, 1).toColor()],
        onChanged: (v) => _set(hsv.withValue(v)),
        onEnd: (_) => widget.onCommit(_c),
      ),
      const SizedBox(height: 6),
      Row(children: [
        SizedBox(
          width: 130,
          child: TextField(
            controller: hex,
            textDirection: TextDirection.ltr,
            decoration: const InputDecoration(isDense: true, prefixText: ''),
            onChanged: (t) {
              final c = _parseHex(t);
              if (c != null) _set(HSVColor.fromColor(c), commit: true, text: false);
            },
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Wrap(spacing: 6, runSpacing: 6, children: [
            for (final c in [...IconPrefs.palette, 0xFF000000])
              GestureDetector(
                onTap: () => _set(HSVColor.fromColor(Color(c)), commit: true),
                child: Container(
                  width: 24, height: 24,
                  decoration: BoxDecoration(color: Color(c), shape: BoxShape.circle, border: Border.all(color: Colors.white38)),
                ),
              ),
          ]),
        ),
      ]),
    ]);
  }
}

/// Edits a [ColorSpec]: solid colour or a two-colour gradient with direction and ready-made gradients.
/// [onCommit] is called when a choice is final (so the app is not rebuilt on every drag tick).
class ColorSpecEditor extends StatefulWidget {
  final ColorSpec initial;
  final bool allowGradient;
  final ValueChanged<ColorSpec> onCommit;
  const ColorSpecEditor({super.key, required this.initial, required this.onCommit, this.allowGradient = true});
  @override
  State<ColorSpecEditor> createState() => _ColorSpecEditorState();
}

class _ColorSpecEditorState extends State<ColorSpecEditor> {
  late ColorSpec spec = widget.initial;
  int which = 0; // 0 = first colour, 1 = second colour (gradient only)

  void _commit(ColorSpec s) {
    setState(() => spec = s);
    widget.onCommit(s);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final grad = spec.isGradient;
    final cur = which == 1 && grad ? spec.color2 : spec.color1;
    Widget dirBtn(int d, IconData ic) => IconButton(
          isSelected: spec.dir == d,
          style: IconButton.styleFrom(backgroundColor: spec.dir == d ? cs.primary.withOpacity(.2) : null),
          icon: Icon(ic, size: 20, color: spec.dir == d ? cs.primary : cs.onSurfaceVariant),
          onPressed: () => _commit(spec.withDir(d)),
        );
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
      Container(
        height: 56,
        decoration: spec.decoration(radius: BorderRadius.circular(16)).copyWith(border: Border.all(color: Colors.white24)),
      ),
      const SizedBox(height: 12),
      if (widget.allowGradient)
        Row(children: [
          ChoiceChip(label: Text(tr2('تک‌رنگ', 'Solid')), selected: !grad, onSelected: (_) {
            which = 0;
            _commit(ColorSpec(spec.c1, null, spec.dir));
          }),
          const SizedBox(width: 8),
          ChoiceChip(label: Text(tr2('گرادیانت', 'Gradient')), selected: grad, onSelected: (_) {
            if (grad) return;
            final hsv = HSVColor.fromColor(spec.color1);
            final second = hsv.withHue((hsv.hue + 50) % 360).withSaturation(hsv.saturation < .35 ? .7 : hsv.saturation).withValue(hsv.value < .4 ? .9 : hsv.value).toColor();
            _commit(ColorSpec(spec.c1, second.value, spec.dir));
          }),
          const Spacer(),
          if (grad) ...[
            dirBtn(0, Icons.south_east_rounded),
            dirBtn(1, Icons.south_rounded),
            dirBtn(2, Icons.east_rounded),
            dirBtn(3, Icons.north_east_rounded),
          ],
        ]),
      if (widget.allowGradient && grad) ...[
        const SizedBox(height: 8),
        SizedBox(
          height: 40,
          child: ListView(scrollDirection: Axis.horizontal, children: [
            for (final g in IconPrefs.gradients)
              GestureDetector(
                onTap: () => _commit(ColorSpec(g[0], g[1], spec.dir)),
                child: Container(
                  width: 40, height: 40,
                  margin: const EdgeInsetsDirectional.only(end: 8),
                  decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [Color(g[0]), Color(g[1])], begin: Alignment.topLeft, end: Alignment.bottomRight), border: Border.all(color: Colors.white38)),
                ),
              ),
          ]),
        ),
        const SizedBox(height: 8),
        Row(children: [
          ChoiceChip(label: Text(tr2('رنگ اول', 'Colour 1')), selected: which == 0, onSelected: (_) => setState(() => which = 0)),
          const SizedBox(width: 8),
          ChoiceChip(label: Text(tr2('رنگ دوم', 'Colour 2')), selected: which == 1, onSelected: (_) => setState(() => which = 1)),
        ]),
      ],
      const SizedBox(height: 10),
      ColorPickerPanel(
        key: ValueKey('$which-$grad'),
        color: cur,
        onChanged: (c) => setState(() => spec = which == 1 && grad ? spec.withC2(c.value) : spec.withC1(c.value)),
        onCommit: (c) {
          final s = which == 1 && grad ? spec.withC2(c.value) : spec.withC1(c.value);
          _commit(s);
        },
      ),
    ]);
  }
}

/// Bottom sheet with a [ColorSpecEditor]; changes are applied through [onCommit] as soon as they are final.
Future<void> showColorSpecSheet(
  BuildContext context, {
  required String title,
  required ColorSpec initial,
  required ValueChanged<ColorSpec> onCommit,
  VoidCallback? onReset,
  bool allowGradient = true,
  Widget? leading,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => SafeArea(
      child: SingleChildScrollView(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(ctx).viewInsets.bottom),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, mainAxisSize: MainAxisSize.min, children: [
          Row(children: [
            if (leading != null) ...[leading, const SizedBox(width: 12)],
            Expanded(child: Text(title, style: Theme.of(ctx).textTheme.titleMedium)),
            if (onReset != null)
              TextButton(
                onPressed: () {
                  onReset();
                  Navigator.pop(ctx);
                },
                child: Text(tr2('بازنشانی', 'Reset')),
              ),
          ]),
          const SizedBox(height: 12),
          ColorSpecEditor(initial: initial, allowGradient: allowGradient, onCommit: onCommit),
        ]),
      ),
    ),
  );
}
