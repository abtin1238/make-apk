import 'package:flutter/material.dart' hide Icon;
import 'package:path/path.dart' as p;
import 'package:xml/xml.dart' show XmlElement;
import '../core/l10n.dart';
import '../core/layouts.dart';
import '../services/native.dart';
import '../services/office_service.dart';
import '../widgets/app_icon.dart';
import '../widgets/ui.dart';
import 'color_editor.dart';
import 'saf_prompt.dart';

/// .pptx / .ppsx viewer + editor. Every slide is drawn as it is laid out (text boxes, placeholders, pictures);
/// tap a shape to select it, double-tap (or the pencil) edits its text, the bar below moves / resizes / formats /
/// deletes it. Slides can be added, duplicated, reordered, deleted. Save overwrites the file, "save copy" writes
/// "<name> (edited).pptx".
class PptxScreen extends StatefulWidget {
  final String path;
  const PptxScreen({super.key, required this.path});
  @override
  State<PptxScreen> createState() => _PptxScreenState();
}

class _PptxScreenState extends State<PptxScreen> {
  PptxFile? x;
  int selSlide = -1, selShape = -1;

  @override
  void initState() {
    super.initState();
    PptxFile.open(widget.path).then((v) {
      if (mounted) setState(() => x = v);
    }).catchError((e) {
      if (mounted) {
        snack(context, '$e');
        Navigator.pop(context);
      }
    });
  }

  PShape? get _sel {
    final f = x;
    if (f == null || selSlide < 0 || selSlide >= f.slides.length) return null;
    final sl = f.slides[selSlide];
    return selShape >= 0 && selShape < sl.shapes.length ? sl.shapes[selShape] : null;
  }

  void _clear() {
    selSlide = -1;
    selShape = -1;
  }

  Future<void> _save({required bool copy}) async {
    final f = x;
    if (f == null) return;
    if (!await ensureSdAll(context, [f.z.path])) return;
    try {
      if (copy) {
        final t = await f.z.saveCopy();
        Native.scan(t);
        if (mounted) snack(context, '${L.t('saved')}: ${p.basename(t)}');
      } else {
        await f.z.saveInPlace();
        Native.scan(f.z.path);
        if (mounted) {
          setState(() {});
          snack(context, '${L.t('saved')}: ${p.basename(f.z.path)}');
        }
      }
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
  }

  Future<void> _editText(PSlide s, PShape sh) async {
    final f = x!;
    if (sh.paras.isEmpty) return;
    final res = await showDialog<List<({int src, String text})>>(
      context: context,
      builder: (_) => _ParasDialog(initial: [for (final para in sh.paras) f.text(para)]),
    );
    if (res == null) return;
    setState(() => f.applyParas(s, sh, res));
  }

  Future<void> _format(PSlide s, PShape sh) async {
    final f = x!;
    final info = sh.paras.isEmpty ? null : f.paraInfo(sh, sh.paras.first);
    final r = await showDialog<_Fmt>(
      context: context,
      builder: (_) => _FormatDialog(size: info?.sizePt ?? 18, bold: info?.bold ?? false, rgb: info?.rgb),
    );
    if (r == null) return;
    setState(() => f.setFormat(s, sh, sizePt: r.size, bold: r.bold, rgb: r.rgb));
  }

  Future<void> _addTextBox(PSlide s, int si) async {
    final f = x!;
    final ctl = TextEditingController();
    final t = await showDialog<String>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(tr2('افزودن کادر متن', 'Add text box')),
        content: TextField(controller: ctl, autofocus: true, minLines: 1, maxLines: 6),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(c)),
          FilledButton(onPressed: () => Navigator.pop(c, ctl.text), child: Text(L.t('ok'))),
        ],
      ),
    );
    if (t == null || t.trim().isEmpty) return;
    setState(() {
      final i = f.addTextBox(s, t);
      selSlide = si;
      selShape = i;
    });
  }

  Widget _bar(PSlide s, PShape sh) {
    final f = x!;
    final cs = Theme.of(context).colorScheme;
    Widget b(IconData ic, String tip, VoidCallback? on) => IconButton(icon: Icon(ic), tooltip: tip, onPressed: on);
    void nudge(double dx, double dy) => setState(() => f.moveShape(s, sh, dx, dy));
    return Material(
      color: cs.surfaceContainerHigh,
      elevation: 6,
      child: SafeArea(
        top: false,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [
            if (!sh.isPic) b(Icons.edit_rounded, tr2('ویرایش متن', 'Edit text'), sh.paras.isEmpty ? null : () => _editText(s, sh)),
            if (!sh.isPic) b(Icons.format_size_rounded, tr2('قالب‌بندی', 'Format'), sh.paras.isEmpty ? null : () => _format(s, sh)),
            b(Icons.arrow_back_rounded, tr2('چپ', 'Left'), () => nudge(-.01, 0)),
            b(Icons.arrow_upward_rounded, tr2('بالا', 'Up'), () => nudge(0, -.01)),
            b(Icons.arrow_downward_rounded, tr2('پایین', 'Down'), () => nudge(0, .01)),
            b(Icons.arrow_forward_rounded, tr2('راست', 'Right'), () => nudge(.01, 0)),
            b(Icons.zoom_in_rounded, tr2('بزرگ‌تر', 'Bigger'), () => setState(() => f.scaleShape(s, sh, 1.1))),
            b(Icons.zoom_out_rounded, tr2('کوچک‌تر', 'Smaller'), () => setState(() => f.scaleShape(s, sh, .9))),
            b(Icons.delete_rounded, L.t('delete'), () async {
              if (await confirm(context, '${L.t('delete')}?')) {
                setState(() {
                  f.deleteShape(s, sh);
                  _clear();
                });
              }
            }),
            b(Icons.close_rounded, tr2('لغو انتخاب', 'Deselect'), () => setState(_clear)),
          ]),
        ),
      ),
    );
  }

  Widget _slideCard(PptxFile f, int i) {
    final s = f.slides[i];
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      clipBehavior: Clip.antiAlias,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(10, 4, 4, 10),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Expanded(child: Text('${i + 1} / ${f.slides.length}', style: const TextStyle(fontSize: 11, color: Colors.grey))),
            IconButton(icon: const Icon(Icons.text_fields_rounded, size: 20), tooltip: tr2('افزودن کادر متن', 'Add text box'), onPressed: () => _addTextBox(s, i)),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert_rounded, size: 20),
              onSelected: (a) async {
                if (a == 'up') {
                  setState(() {
                    f.move(i, -1);
                    _clear();
                  });
                } else if (a == 'down') {
                  setState(() {
                    f.move(i, 1);
                    _clear();
                  });
                } else if (a == 'dup') {
                  setState(() {
                    f.duplicate(i);
                    _clear();
                  });
                } else if (a == 'blank') {
                  setState(() {
                    f.duplicate(i, blank: true);
                    _clear();
                  });
                } else if (a == 'del') {
                  if (f.slides.length > 1 && await confirm(context, '${L.t('delete')}?')) {
                    setState(() {
                      f.delete(i);
                      _clear();
                    });
                  }
                }
              },
              itemBuilder: (_) => [
                PopupMenuItem(value: 'up', child: Text(L.t('moveUp'))),
                PopupMenuItem(value: 'down', child: Text(L.t('moveDown'))),
                PopupMenuItem(value: 'dup', child: Text(L.t('dupSlide'))),
                PopupMenuItem(value: 'blank', child: Text(L.t('newSlide'))),
                PopupMenuItem(value: 'del', child: Text(L.t('delete'))),
              ],
            ),
          ]),
          Padding(padding: const EdgeInsets.only(right: 6), child: _canvas(f, s, i)),
        ]),
      ),
    );
  }

  Widget _canvas(PptxFile f, PSlide s, int si) {
    return LayoutBuilder(builder: (context, cons) {
      final w = cons.maxWidth;
      final k = w / f.slideW; // px per EMU
      final h = f.slideH * k;
      final pt = k * 12700; // px per point
      final bgc = s.bgRgb == null ? Colors.white : Color(0xFF000000 | s.bgRgb!);
      final defText = bgc.computeLuminance() < .4 ? Colors.white : Colors.black;
      final primary = Theme.of(context).colorScheme.primary;
      return SizedBox(
        width: w,
        height: h,
        child: ClipRect(
          child: Stack(children: [
            Positioned.fill(child: GestureDetector(onTap: () => setState(_clear), child: ColoredBox(color: bgc))),
            for (var j = 0; j < s.shapes.length; j++)
              Positioned(
                left: s.shapes[j].x * k,
                top: s.shapes[j].y * k,
                width: s.shapes[j].w * k < 1 ? 1 : s.shapes[j].w * k,
                height: s.shapes[j].h * k < 1 ? 1 : s.shapes[j].h * k,
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => setState(() {
                    selSlide = si;
                    selShape = j;
                  }),
                  onDoubleTap: s.shapes[j].isPic || s.shapes[j].paras.isEmpty ? null : () => _editText(s, s.shapes[j]),
                  child: DecoratedBox(
                    decoration: BoxDecoration(border: Border.all(color: selSlide == si && selShape == j ? primary : Colors.grey.withOpacity(.35), width: selSlide == si && selShape == j ? 2 : .5)),
                    child: s.shapes[j].isPic
                        ? (s.shapes[j].image == null ? const SizedBox() : Image.memory(s.shapes[j].image!, fit: BoxFit.fill, errorBuilder: (_, __, ___) => const SizedBox()))
                        : ClipRect(
                            child: SingleChildScrollView(
                              physics: const NeverScrollableScrollPhysics(),
                              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                                for (final para in s.shapes[j].paras) _para(f, s.shapes[j], para, pt, defText),
                              ]),
                            ),
                          ),
                  ),
                ),
              ),
          ]),
        ),
      );
    });
  }

  Widget _para(PptxFile f, PShape sh, XmlElement para, double pt, Color defText) {
    final i = f.paraInfo(sh, para);
    final align = i.align == 'ctr' ? TextAlign.center : (i.align == 'r' ? TextAlign.right : (i.align == 'just' ? TextAlign.justify : TextAlign.left));
    final t = f.text(para);
    return Text(
      t.isEmpty ? ' ' : t,
      textAlign: align,
      textDirection: i.rtl ? TextDirection.rtl : null,
      style: TextStyle(
        fontSize: i.sizePt * pt,
        height: 1.15,
        fontWeight: i.bold ? FontWeight.bold : FontWeight.normal,
        fontStyle: i.italic ? FontStyle.italic : FontStyle.normal,
        color: i.rgb == null ? defText : Color(0xFF000000 | i.rgb!),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final f = x;
    final sel = _sel;
    return PopScope(
      canPop: f == null || !f.z.changed,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        if (await confirm(context, tr2('تغییرات ذخیره‌نشده از بین می‌رود. خارج می‌شوید؟', 'Unsaved changes will be lost. Leave?')) && context.mounted) {
          Navigator.pop(context);
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(p.basename(widget.path), style: const TextStyle(fontSize: 15)),
          actions: [
            IconButton(
              icon: const Icon(Icons.save_rounded),
              tooltip: tr2('ذخیره', 'Save'),
              onPressed: f == null || !f.z.changed ? null : () => _save(copy: false),
            ),
            PopupMenuButton<String>(
              onSelected: (_) => _save(copy: true),
              itemBuilder: (_) => [PopupMenuItem(value: 'copy', child: Text(L.t('saveCopy')))],
            ),
          ],
        ),
        bottomNavigationBar: f == null || sel == null ? null : _bar(f.slides[selSlide], sel),
        body: f == null
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: f.slides.length,
                itemBuilder: (_, i) => _slideCard(f, i),
              ),
      ),
    );
  }
}

class _ParasDialog extends StatefulWidget {
  final List<String> initial;
  const _ParasDialog({required this.initial});
  @override
  State<_ParasDialog> createState() => _ParasDialogState();
}

class _Row {
  final int src;
  final TextEditingController c;
  _Row(this.src, String t) : c = TextEditingController(text: t);
}

class _ParasDialogState extends State<_ParasDialog> {
  late final List<_Row> rows = [for (var i = 0; i < widget.initial.length; i++) _Row(i, widget.initial[i])];

  @override
  void dispose() {
    for (final r in rows) {
      r.c.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(tr2('ویرایش متن', 'Edit text')),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              for (var i = 0; i < rows.length; i++)
                Row(children: [
                  Expanded(child: TextField(controller: rows[i].c, minLines: 1, maxLines: 6, autofocus: i == 0)),
                  IconButton(
                    icon: const Icon(Icons.remove_circle_outline_rounded, size: 20),
                    tooltip: L.t('delete'),
                    onPressed: rows.length <= 1 ? null : () => setState(() => rows.removeAt(i).c.dispose()),
                  ),
                ]),
              Align(
                alignment: AlignmentDirectional.centerStart,
                child: TextButton.icon(
                  icon: const Icon(Icons.add_rounded, size: 20),
                  label: Text(tr2('پاراگراف جدید', 'New paragraph')),
                  onPressed: () => setState(() => rows.add(_Row(-1, ''))),
                ),
              ),
            ]),
          ),
        ),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(context)),
          FilledButton(
            onPressed: () => Navigator.pop(context, [for (final r in rows) (src: r.src, text: r.c.text)]),
            child: Text(L.t('ok')),
          ),
        ],
      );
}

class _Fmt {
  final double? size;
  final bool? bold;
  final int? rgb;
  const _Fmt(this.size, this.bold, this.rgb);
}

class _FormatDialog extends StatefulWidget {
  final double size;
  final bool bold;
  final int? rgb;
  const _FormatDialog({required this.size, required this.bold, required this.rgb});
  @override
  State<_FormatDialog> createState() => _FormatDialogState();
}

class _FormatDialogState extends State<_FormatDialog> {
  late double size = widget.size.clamp(6, 120).toDouble();
  late bool bold = widget.bold;
  int? rgb;
  bool colorChanged = false;

  @override
  void initState() {
    super.initState();
    rgb = widget.rgb;
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
        title: Text(tr2('قالب‌بندی متن', 'Text format')),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text('${tr2('اندازه', 'Size')}: ${size.round()} pt'),
              Slider(value: size, min: 6, max: 120, onChanged: (v) => setState(() => size = v)),
              SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(tr2('ضخیم', 'Bold')), value: bold, onChanged: (v) => setState(() => bold = v)),
              const SizedBox(height: 6),
              Text(tr2('رنگ متن', 'Text colour')),
              const SizedBox(height: 6),
              ColorPickerPanel(
                color: Color(0xFF000000 | (rgb ?? 0x000000)),
                onChanged: (_) {},
                onCommit: (c) => setState(() {
                  rgb = c.value & 0xFFFFFF;
                  colorChanged = true;
                }),
              ),
            ]),
          ),
        ),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(context)),
          FilledButton(onPressed: () => Navigator.pop(context, _Fmt(size, bold, colorChanged ? rgb : null)), child: Text(L.t('ok'))),
        ],
      );
}
