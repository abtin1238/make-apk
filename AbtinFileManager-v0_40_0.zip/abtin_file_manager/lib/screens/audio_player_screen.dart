import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as ui;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:flutter/services.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import 'package:media_kit/media_kit.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../core/theme.dart';
import '../widgets/tonearm.dart';
import '../core/player_theme.dart';
import '../widgets/player_glass.dart';
import '../services/player_service.dart';
import 'audio_options_screen.dart';
import 'equalizer_screen.dart';
import 'tag_editor_screen.dart';
import 'viewer_delete.dart';
import '../widgets/ui.dart';

part 'audio_player_neon.dart';

class AudioPlayerScreen extends StatefulWidget {
  const AudioPlayerScreen({super.key});
  @override
  State<AudioPlayerScreen> createState() => _AudioPlayerScreenState();
}

class _AudioPlayerScreenState extends State<AudioPlayerScreen>
    with SingleTickerProviderStateMixin {
  static const _vizChannel = EventChannel('abtin/audio_viz');
  static const _specChannel = MethodChannel('abtin/audio_spec');
  // Offline spectrum (works on every phone): decoded once natively, then read by playback position.
  Timer? _specTimer;
  Uint8List? _specData;
  int _specFps = 30, _specBands = 40;
  String _specPath = '';
  bool _specBusy = false;
  bool _sim = false; // last-resort animated bars when the file can't be analysed
  int _simRetryAt = 0; // ms timestamp: when the demo mode may try the real analysis again
  static final Map<String, (Uint8List, int, int)> _specCache = {};
  String _specErr = '';
  late final AnimationController spin =
      AnimationController(vsync: this, duration: const Duration(seconds: 12));
  final lyrCtl = ScrollController();
  StreamSubscription<dynamic>? _vizSub;
  List<double> _spectrum = List.filled(40, 0);
  bool visualizerOn = false;
  List<(Duration, String)>? lrc;
  String? lrcFor;
  bool showLyrics = false;
  int _lastIdx = -1;
  double? _drag;
  bool remainFlip = false; // swaps total / remaining time in the classic & warm styles

  @override
  void initState() {
    super.initState();
    PlayerTheme.I.load();
    // pre-analyse the current file so the visualizer starts instantly when it is switched on
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final pl = context.read<PlayerService>();
      if (pl.hasQueue && !pl.current.startsWith('http')) _analyze(pl.current);
    });
  }

  void _setDrag(double? v) => setState(() => _drag = v);
  void _toggleRemain() => setState(() => remainFlip = !remainFlip);

  Future<void> _pickStyle() async {
    final s = context.read<AppSettings>();
    final r = await showModalBottomSheet<String>(
      context: context,
      builder: (c) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          ListTile(
              title: Text(L.t('audioStyle'),
                  style: const TextStyle(fontWeight: FontWeight.bold))),
          for (final e in [
            ('vinyl', Icons.album_rounded, 'styleVinyl'),
            ('neon', Icons.auto_awesome_rounded, 'styleNeon'),
            ('classic', Icons.nightlight_round, 'styleClassic'),
            ('warm', Icons.wb_twilight_rounded, 'styleWarm'),
          ])
            ListTile(
                leading: Icon(e.$2),
                title: Text(L.t(e.$3)),
                trailing: s.audioStyle == e.$1
                    ? const Icon(Icons.check_rounded)
                    : null,
                onTap: () => Navigator.pop(c, e.$1)),
        ]),
      ),
    );
    if (r != null) s.setAudioStyle(r);
  }

  void _toggleLyrics() => setState(() => showLyrics = !showLyrics);

  Future<void> _addLyrics(PlayerService pl) async {
    if (pl.current.startsWith('http')) return;
    final r = await FilePicker.platform.pickFiles();
    final f = r?.files.single.path;
    if (f == null || !mounted) return;
    if (!await ensureSdAll(context, [pl.current])) return;
    await Saf.copyTo(f, '${p.withoutExtension(pl.current)}.lrc');
    lrcFor = null;
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    spin.dispose();
    lyrCtl.dispose();
    _vizSub?.cancel();
    _specTimer?.cancel();
    super.dispose();
  }

  Future<void> _toggleVisualizer() async {
    if (visualizerOn) {
      await _vizSub?.cancel();
      _vizSub = null;
      _specTimer?.cancel();
      _specTimer = null;
      if (mounted)
        setState(() {
          visualizerOn = false;
          _spectrum = List.filled(40, 0);
        });
      return;
    }
    final pl = context.read<PlayerService>();
    if (!pl.hasQueue) return;
    setState(() => visualizerOn = true);
    final path = pl.current;
    // 1) offline analysis of the file: no microphone, no vendor restrictions
    _sim = false;
    if (!path.startsWith('http') && await _startOfflineSpectrum(pl)) return;
    if (!mounted || !visualizerOn) return;
    // 2) streams: live tap of the audio output (needs the microphone permission)
    if (path.startsWith('http')) {
      await _startLiveSpectrum();
      return;
    }
    // 3) last resort: animated bars, so the visualizer ALWAYS opens
    _sim = true;
    _specTimer?.cancel();
    _specTimer = Timer.periodic(const Duration(milliseconds: 40), (_) => _specTick());
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(L.lang == 'fa'
            ? 'تحلیل طیف این فایل ممکن نشد؛ حالت نمایشی فعال شد. ($_specErr)'
            : 'Could not analyse this file; showing the demo visualizer. ($_specErr)')));
  }

  /// true = ready, false = this file can't be analysed, null = another analysis is still running.
  Future<bool?> _analyze(String path) async {
    if (_specPath == path && _specData != null) return true;
    final c = _specCache[path];
    if (c != null) {
      _specData = c.$1;
      _specFps = c.$2;
      _specBands = c.$3;
      _specPath = path;
      return true;
    }
    if (_specBusy) return null;
    _specBusy = true;
    try {
      if (!File(path).existsSync()) {
        _specErr = 'file not found';
        return false;
      }
      final r = await _specChannel.invokeMethod<Map>('analyze', {'path': path});
      final data = r?['data'];
      if (data is! Uint8List || data.isEmpty) {
        _specErr = 'empty result';
        return false;
      }
      _specData = data;
      _specFps = (r?['fps'] as num?)?.toInt() ?? 30;
      _specBands = (r?['bands'] as num?)?.toInt() ?? 40;
      _specPath = path;
      if (_specCache.length >= 4) _specCache.remove(_specCache.keys.first);
      _specCache[path] = (data, _specFps, _specBands);
      return true;
    } on PlatformException catch (e) {
      _specErr = '${e.code}: ${e.message}';
      return false;
    } catch (e) {
      _specErr = '$e';
      return false;
    } finally {
      _specBusy = false;
    }
  }

  Future<bool> _startOfflineSpectrum(PlayerService pl) async {
    final path = pl.current;
    bool? ok = await _analyze(path);
    // another analysis is still running (e.g. the previous track): wait for it, don't fall back to the demo
    for (var i = 0; ok == null && i < 120 && mounted && visualizerOn; i++) {
      await Future<void>.delayed(const Duration(milliseconds: 250));
      ok = await _analyze(path);
    }
    if (ok != true || !mounted || !visualizerOn) return false;
    _specTimer?.cancel();
    _specTimer = Timer.periodic(const Duration(milliseconds: 40), (_) => _specTick());
    return true;
  }

  void _specTick() {
    if (!mounted || !visualizerOn) return;
    final pl = context.read<PlayerService>();
    if (!pl.hasQueue) return;
    if (_sim) {
      final nowMs = DateTime.now().millisecondsSinceEpoch;
      if (!pl.current.startsWith('http') && !_specBusy && nowMs >= _simRetryAt) {
        _simRetryAt = nowMs + 4000;
        final p0 = pl.current;
        _analyze(p0).then((ok) {
          if (ok == true && mounted && visualizerOn && pl.current == p0) _sim = false;
        });
      }
      final tt = nowMs / 1000.0;
      const n = 40;
      final prev = _spectrum.length == n ? _spectrum : List.filled(n, 0.0);
      final out = List<double>.filled(n, 0);
      for (var i = 0; i < n; i++) {
        final x = i / (n - 1);
        final env = math.exp(-math.pow((x - .35) / .38, 2).toDouble());
        final wob = .5 + .5 * math.sin(tt * (2.1 + i * .17) + i * 1.7);
        final pulse = .65 + .35 * math.sin(tt * 3.1);
        final target = pl.playing ? (.08 + .8 * env * wob * pulse) : 0.04;
        final old = prev[i];
        out[i] = target > old ? old + (target - old) * .6 : old + (target - old) * .2;
      }
      setState(() => _spectrum = out);
      return;
    }
    if (pl.current != _specPath) {
      // track changed: analyse the new one (keep showing the old frame fading out)
      final path = pl.current;
      _analyze(path).then((ok) {
        if (ok == false && mounted && visualizerOn && _specPath != path) _sim = true;
      });
      setState(() => _spectrum = [for (final v in _spectrum) v * .8]);
      return;
    }
    final data = _specData;
    if (data == null) return;
    final bands = _specBands;
    final frames = data.length ~/ bands;
    final idx = (pl.player.state.position.inMilliseconds * _specFps / 1000).round().clamp(0, frames - 1);
    final prev = _spectrum.length == bands ? _spectrum : List.filled(bands, 0.0);
    final out = List<double>.filled(bands, 0);
    for (var i = 0; i < bands; i++) {
      final target = pl.playing ? data[idx * bands + i] / 255.0 : 0.0;
      final old = prev[i];
      // fast attack, slower release: looks like a real analyser
      out[i] = target > old ? old + (target - old) * .7 : old + (target - old) * .22;
    }
    setState(() => _spectrum = out);
  }

  Future<void> _startLiveSpectrum() async {
    final consent = await showDialog<bool>(
        context: context,
        builder: (c) => AlertDialog(
              title: Text(L.t('visualizer')),
              content: Text(L.t('vizPrivacyNotice')),
              actions: [
                CancelButton(onPressed: () => Navigator.pop(c, false)),
                FilledButton(
                    onPressed: () => Navigator.pop(c, true),
                    child: Text(L.t('ok')))
              ],
            ));
    if (consent != true || !mounted) {
      if (mounted) setState(() => visualizerOn = false);
      return;
    }
    final permission = await Permission.microphone.request();
    if (!permission.isGranted) {
      if (mounted) {
        setState(() => visualizerOn = false);
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(L.t('vizPermission'))));
      }
      return;
    }
    _vizSub = _vizChannel.receiveBroadcastStream().listen((event) {
      if (!mounted || event is! List) return;
      final values = event
          .whereType<num>()
          .map((v) => v.toDouble().clamp(0.0, 1.0).toDouble())
          .toList();
      setState(() => _spectrum = values);
    }, onError: (_) {
      final sub = _vizSub;
      _vizSub = null;
      unawaited(sub?.cancel());
      if (mounted) {
        setState(() => visualizerOn = false);
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(L.t('vizUnavailable'))));
      }
    });
  }

  File? _lrcFile(String song) {
    if (song.startsWith('http')) return null;
    final base = p.withoutExtension(song);
    for (final e in ['lrc', 'LRC', 'txt']) {
      final f = File('$base.$e');
      if (f.existsSync()) return f;
    }
    return null;
  }

  Future<void> _loadLrc(String song) async {
    lrcFor = song;
    _lastIdx = -1;
    final f = _lrcFile(song);
    if (f == null) {
      lrc = null;
      return;
    }
    final out = <(Duration, String)>[];
    final re = RegExp(r'\[(\d+):(\d+(?:\.\d+)?)\]');
    try {
      for (final line in await f.readAsLines()) {
        final ms = re.allMatches(line).toList();
        final text = line.replaceAll(re, '').trim();
        for (final m in ms) {
          out.add((
            Duration(
                milliseconds:
                    (int.parse(m[1]!) * 60000 + double.parse(m[2]!) * 1000)
                        .round()),
            text
          ));
        }
      }
    } catch (_) {}
    out.sort((a, b) => a.$1.compareTo(b.$1));
    lrc = out.isEmpty ? null : out;
    if (mounted) setState(() {});
  }

  String _t(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  Widget _disc(PlayerService pl) {
    final art = pl.meta?.art;
    final record = RotationTransition(
        turns: spin,
        child: Container(
          width: 300,
          height: 300,
          decoration: const BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                  colors: [Color(0xFF222222), Color(0xFF050505)]),
              boxShadow: [BoxShadow(color: Color(0x55F5A623), blurRadius: 40)]),
          child: Center(
            child: Container(
              width: art != null ? 190 : 120,
              height: art != null ? 190 : 120,
              clipBehavior: Clip.antiAlias,
              decoration: const BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                      colors: [Color(0xFFF7B544), Color(0xFFD98A12)])),
              child: art != null
                  ? Image.memory(art,
                      fit: BoxFit.cover,
                      gaplessPlayback: true,
                      errorBuilder: (_, __, ___) => const Icon(
                          Icons.music_note_rounded,
                          size: 56,
                          color: Color(0xFF3A2A08)))
                  : const Icon(Icons.music_note_rounded,
                      size: 56, color: Color(0xFF3A2A08)),
            ),
          ),
        ),
      );
    return Center(
      child: FittedBox(
        fit: BoxFit.scaleDown,
        child: SizedBox(
          width: Tonearm.size.width,
          height: Tonearm.size.height,
          child: Stack(children: [
            Positioned(left: 0, top: 45, child: record),
            Positioned.fill(child: IgnorePointer(child: Tonearm(pl: pl))),
          ]),
        ),
      ),
    );
  }

  Widget _lyrics(PlayerService pl, {Color? hi}) => StreamBuilder<Duration>(
        stream: pl.player.stream.position,
        builder: (c, snap) {
          final pos = snap.data ?? Duration.zero;
          var idx = lrc!.lastIndexWhere((e) => e.$1 <= pos);
          if (idx < 0) idx = 0;
          if (idx != _lastIdx) {
            _lastIdx = idx;
            WidgetsBinding.instance.addPostFrameCallback((_) {
              if (lyrCtl.hasClients) {
                final target =
                    (idx * 52.0 - lyrCtl.position.viewportDimension / 2 + 26)
                        .clamp(0.0, lyrCtl.position.maxScrollExtent)
                        .toDouble();
                lyrCtl.animateTo(target,
                    duration: const Duration(milliseconds: 350),
                    curve: Curves.easeOut);
              }
            });
          }
          return ListView.builder(
            controller: lyrCtl,
            itemExtent: 52,
            itemCount: lrc!.length,
            itemBuilder: (_, i) => InkWell(
              onTap: () => pl.player.seek(lrc![i].$1),
              child: Center(
                child: Text(lrc![i].$2,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: i == idx ? 22 : 16,
                        color: i == idx ? (hi ?? AppColors.gold) : Colors.white54,
                        fontWeight:
                            i == idx ? FontWeight.bold : FontWeight.normal)),
              ),
            ),
          );
        },
      );

  Future<void> _sleepMenu(PlayerService pl) async {
    final r = await showModalBottomSheet<int>(
      context: context,
      builder: (_) => SafeArea(
        child: ListView(shrinkWrap: true, children: [
          ListTile(
              title: Text(L.t('sleepTimer'),
                  style: const TextStyle(fontWeight: FontWeight.bold))),
          if (pl.sleepActive)
            ListTile(
                leading: const Icon(Icons.timer_off_rounded),
                title: Text(L.t('off')),
                onTap: () => Navigator.pop(context, -1)),
          for (final m in [5, 10, 15, 30, 45, 60, 90])
            ListTile(
                leading: const Icon(Icons.timer_rounded),
                title: Text('$m ${L.t('minutes')}'),
                onTap: () => Navigator.pop(context, m)),
          ListTile(
              leading: const Icon(Icons.music_off_rounded),
              title: Text(L.t('endOfTrack')),
              onTap: () => Navigator.pop(context, 0)),
        ]),
      ),
    );
    if (r == null) return;
    if (r < 0) {
      pl.setSleep(null);
    } else if (r == 0) {
      pl.setSleep(null, endOfTrack: true);
    } else {
      pl.setSleep(Duration(minutes: r));
    }
  }

  void _queue() {
    final h = MediaQuery.of(context).size.height;
    // open already scrolled to the track that is playing
    final ctl = ScrollController(
        initialScrollOffset:
            math.max(0, (context.read<PlayerService>().index - 2) * 56.0));
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: const Color(0xFF0E1018),
      clipBehavior: Clip.antiAlias,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => Consumer<PlayerService>(
        builder: (c, pl, _) => SizedBox(
          height: h * .7,
          child: Material(
            color: Colors.transparent,
            child: Column(children: [
              const SizedBox(height: 8),
              Container(
                  width: 42,
                  height: 4,
                  decoration: BoxDecoration(
                      color: Colors.white24,
                      borderRadius: BorderRadius.circular(2))),
              ListTile(
                title: Text('${L.t('nextQueue')} (${pl.queue.length})',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                trailing: TextButton(
                    onPressed: () {
                      pl.stopAll();
                      Navigator.pop(c);
                      Navigator.pop(context);
                    },
                    child: Text(L.t('clear'))),
              ),
              const Divider(height: 1, color: Colors.white12),
              Expanded(
                child: ReorderableListView.builder(
                  scrollController: ctl,
                  physics: const ClampingScrollPhysics(),
                  padding: EdgeInsets.only(
                      bottom: MediaQuery.of(c).padding.bottom + 16),
                  itemCount: pl.queue.length,
                  onReorder: (a, b) => pl.moveItem(a, b > a ? b - 1 : b),
                  itemBuilder: (c, i) => ListTile(
                    key: ValueKey('$i-${pl.queue[i]}'),
                    selected: i == pl.index,
                    selectedTileColor: AppColors.gold.withOpacity(.12),
                    selectedColor: AppColors.gold,
                    leading: Text('${i + 1}'),
                    title: Text(
                        p.basenameWithoutExtension(Uri.decodeFull(pl.queue[i])),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                    trailing: IconButton(
                        icon: const Icon(Icons.close_rounded),
                        onPressed: () => pl.removeAt(i)),
                    onTap: () {
                      pl.player.jump(i);
                      Navigator.pop(c);
                    },
                  ),
                ),
              ),
            ]),
          ),
        ),
      ),
    ).whenComplete(ctl.dispose);
  }

  Widget _moreMenu(PlayerService pl, {Color? color, bool full = false, bool theme = false}) {
    final rate = pl.player.state.rate;
    return PopupMenuButton<String>(
            iconColor: color,
            onSelected: (v) async {
              if (v == 'share' && pl.hasQueue && !pl.current.startsWith('http'))
                Share.shareXFiles([XFile(pl.current)]);
              if (v == 'sleep') _sleepMenu(pl);
              if (v == 'viz' && pl.hasQueue) _toggleVisualizer();
              if (v == 'style') _pickStyle();
              if (v == 'vptheme') showPlayerThemeSheet(context);
              if (v == 'ab') pl.toggleAB();
              if (v == 'opts')
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const AudioOptionsScreen()));
              if (v == 'tags' && pl.hasQueue && !pl.current.startsWith('http'))
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => TagEditorScreen(path: pl.current)));
              if (v == 'delete' && pl.hasQueue && !pl.current.startsWith('http')) {
                final path = pl.current;
                final i = pl.index;
                final wasPlaying = pl.playing;
                await pl.player.pause();
                if (!mounted) return;
                final ok = await deleteFromViewer(context, path);
                if (!mounted) return;
                if (!ok) {
                  if (wasPlaying) pl.player.play();
                } else if (pl.queue.length <= 1) {
                  await pl.stopAll();
                  if (mounted) Navigator.pop(context);
                } else {
                  await pl.removeAt(i);
                  pl.player.play();
                }
              }
              if (v.startsWith('r')) pl.setRate(double.parse(v.substring(1)));
            },
            itemBuilder: (_) => [
              if (theme) ...[
                PopupMenuItem(value: 'vptheme', child: Text(L.t('vpTheme'))),
                const PopupMenuDivider(),
              ],
              if (full) ...[
                PopupMenuItem(value: 'sleep', child: Text(L.t('sleepTimer'))),
                PopupMenuItem(value: 'viz', child: Text(L.t('visualizer'))),
                PopupMenuItem(value: 'style', child: Text(L.t('audioStyle'))),
                const PopupMenuDivider(),
              ],
              PopupMenuItem(
                  value: 'ab',
                  child: Text(
                      'A-B ${L.t('loop')}${pl.abStage == 0 ? '' : pl.abStage == 1 ? '  (A)' : '  (A-B ✓)'}')),
              PopupMenuItem(value: 'tags', child: Text(L.t('tagEdit'))),
              PopupMenuItem(value: 'opts', child: Text(L.t('playOpts'))),
              PopupMenuItem(value: 'share', child: Text(L.t('share'))),
              if (pl.hasQueue && !pl.current.startsWith('http')) PopupMenuItem(value: 'delete', child: Text(L.t('delete'))),
              const PopupMenuDivider(),
              for (final v in [0.5, 0.75, 1.0, 1.25, 1.5, 2.0])
                PopupMenuItem(
                    value: 'r$v',
                    child:
                        Text('${L.t('speed')} ${v}x${rate == v ? '  ✓' : ''}')),
            ],
          );
  }

  @override
  Widget build(BuildContext context) {
    final pl = context.watch<PlayerService>();
    final s = context.watch<AppSettings>();
    if (pl.playing) {
      if (!spin.isAnimating) spin.repeat();
    } else {
      spin.stop();
    }
    if (pl.hasQueue && lrcFor != pl.current) _loadLrc(pl.current);
    final hasLrc = lrc != null;
    final cs = Theme.of(context).colorScheme;
    PlayerTheme.I.bindApp(cs.primary, cs.secondary);
    final st = s.audioStyle;
    if (st != 'vinyl') {
      return Scaffold(
        backgroundColor: st == 'warm'
            ? const Color(0xFF0A0A0A)
            : st == 'classic'
                ? const Color(0xFF050912)
                : const Color(0xFF05030F),
        body: !pl.hasQueue
            ? const SizedBox()
            : st == 'neon'
                ? _neonBody(pl, s)
                : _proBody(pl, s,
                    st == 'warm' ? _ProPalette.warm : _ProPalette.dark),
      );
    }
    return Scaffold(
      backgroundColor: const Color(0xFF0A0D14),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        leading: IconButton(
            icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 32),
            onPressed: () => Navigator.pop(context)),
        centerTitle: true,
        title: const Text.rich(
            TextSpan(children: [
              TextSpan(text: 'Abtin '),
              TextSpan(text: 'Media', style: TextStyle(color: AppColors.gold))
            ]),
            style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
              icon: const Icon(Icons.style_rounded),
              tooltip: L.t('audioStyle'),
              onPressed: _pickStyle),
          IconButton(
              icon: Icon(Icons.bedtime_rounded,
                  color: pl.sleepActive ? AppColors.gold : null),
              tooltip: L.t('sleepTimer'),
              onPressed: () => _sleepMenu(pl)),
          IconButton(
              icon: Icon(Icons.graphic_eq_rounded,
                  color: visualizerOn ? AppColors.gold : null),
              tooltip: L.t('visualizer'),
              onPressed: pl.hasQueue ? _toggleVisualizer : null),
          IconButton(
              icon: const Icon(Icons.equalizer_rounded),
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const EqualizerScreen()))),
          _moreMenu(pl),
        ],
      ),
      body: !pl.hasQueue
          ? const SizedBox()
          : Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: Column(children: [
                Expanded(child: showLyrics && hasLrc ? _lyrics(pl) : _disc(pl)),
                Row(children: [
                  Expanded(
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(pl.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  fontSize: 24, fontWeight: FontWeight.bold)),
                          Text(
                              [pl.artist, pl.album]
                                  .where((e) => e.isNotEmpty)
                                  .join(' • '),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: Colors.white54)),
                        ]),
                  ),
                  IconButton(
                    icon: Icon(
                        s.isFav(pl.current)
                            ? Icons.star_rounded
                            : Icons.star_border_rounded,
                        color: AppColors.gold,
                        size: 30),
                    onPressed: () => s.toggleFav(pl.current),
                  ),
                ]),
                const SizedBox(height: 6),
                Align(
                  alignment: AlignmentDirectional.centerStart,
                  child: Wrap(spacing: 8, children: [
                    ActionChip(
                      avatar: const Icon(Icons.article_outlined, size: 18),
                      label: Text(hasLrc
                          ? (showLyrics ? L.t('disc') : L.t('lyrics'))
                          : L.t('addLyrics')),
                      onPressed: hasLrc
                          ? () => setState(() => showLyrics = !showLyrics)
                          : () => _addLyrics(pl),
                    ),
                    if (pl.abStage != 0)
                      ActionChip(
                          avatar: const Icon(Icons.repeat_rounded, size: 18),
                          label: Text(pl.abStage == 1 ? 'A…' : 'A-B'),
                          onPressed: pl.toggleAB),
                    if (pl.sleepActive)
                      ActionChip(
                        avatar: const Icon(Icons.bedtime_rounded, size: 18),
                        label: Text(pl.sleepEndOfTrack
                            ? L.t('endOfTrack')
                            : '${pl.sleepAt!.difference(DateTime.now()).inMinutes + 1} ${L.t('minutes')}'),
                        onPressed: () => pl.setSleep(null),
                      ),
                  ]),
                ),
                if (visualizerOn)
                  Padding(
                    padding: const EdgeInsets.only(top: 5),
                    child: SizedBox(
                        height: 44,
                        width: double.infinity,
                        child:
                            CustomPaint(painter: _SpectrumPainter(_spectrum))),
                  ),
                StreamBuilder<Duration>(
                  stream: pl.player.stream.position,
                  builder: (c, snap) {
                    final pos = snap.data ?? Duration.zero;
                    final dur = pl.player.state.duration;
                    final max = dur.inMilliseconds
                        .toDouble()
                        .clamp(1, double.infinity)
                        .toDouble();
                    final v = (_drag ?? pos.inMilliseconds.toDouble())
                        .clamp(0, max)
                        .toDouble();
                    return Directionality(
                        textDirection: TextDirection.ltr,
                        child: Column(children: [
                      Slider(
                        activeColor: AppColors.gold,
                        value: v,
                        max: max,
                        onChanged: (x) => setState(() => _drag = x),
                        onChangeEnd: (x) {
                          pl.player.seek(Duration(milliseconds: x.round()));
                          setState(() => _drag = null);
                        },
                      ),
                      Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(_t(Duration(milliseconds: v.round()))),
                            Text(_t(dur))
                          ]),
                    ]));
                  },
                ),
                // transport controls: always LTR (shuffle, prev, play, next, repeat) in every language
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                          icon: Icon(Icons.shuffle_rounded,
                              color:
                                  pl.shuffle ? AppColors.gold : Colors.white),
                          onPressed: pl.toggleShuffle),
                      IconButton(
                          iconSize: 38,
                          icon: const Icon(Icons.skip_previous_rounded),
                          onPressed: pl.player.previous),
                      Container(
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border:
                                Border.all(color: AppColors.gold, width: 3)),
                        child: IconButton(
                            iconSize: 48,
                            icon: Icon(pl.playing
                                ? Icons.pause_rounded
                                : Icons.play_arrow_rounded),
                            onPressed: pl.player.playOrPause),
                      ),
                      IconButton(
                          iconSize: 38,
                          icon: const Icon(Icons.skip_next_rounded),
                          onPressed: pl.player.next),
                      IconButton(
                        icon: Icon(
                            pl.mode == PlaylistMode.single
                                ? Icons.repeat_one_rounded
                                : Icons.repeat_rounded,
                            color: pl.mode == PlaylistMode.none
                                ? Colors.white
                                : AppColors.gold),
                        onPressed: pl.cycleMode,
                      ),
                    ]),
                ),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Row(children: [
                  IconButton(
                      icon: const Icon(Icons.replay_10_rounded),
                      onPressed: () => pl.seekBy(const Duration(seconds: -10))),
                  Icon(
                      pl.volume == 0
                          ? Icons.volume_off_rounded
                          : Icons.volume_up_rounded,
                      size: 20),
                  Expanded(
                      child: Slider(
                          value: pl.volume, max: 100, onChanged: pl.setVolume)),
                  IconButton(
                      icon: const Icon(Icons.forward_10_rounded),
                      onPressed: () => pl.seekBy(const Duration(seconds: 10))),
                ]),
                ),
                ListTile(
                  tileColor: Colors.white10,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                  leading: const Icon(Icons.queue_music_rounded),
                  title: Text('${L.t('nextQueue')} (${pl.queue.length})'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: _queue,
                ),
                const SizedBox(height: 12),
              ]),
            ),
    );
  }
}

class _SpectrumPainter extends CustomPainter {
  final List<double> values;
  final Color lo, hi;
  _SpectrumPainter(this.values,
      {this.lo = const Color(0xFF805A20), this.hi = AppColors.gold});

  @override
  void paint(Canvas canvas, Size size) {
    if (values.isEmpty || size.width <= 0 || size.height <= 0) return;
    final gap = 2.0;
    final width = (size.width - gap * (values.length - 1)) / values.length;
    for (var i = 0; i < values.length; i++) {
      final v = values[i].clamp(0.0, 1.0).toDouble();
      final h =
          (size.height * (0.08 + v * .92)).clamp(2.0, size.height).toDouble();
      final rect = RRect.fromRectAndRadius(
          Rect.fromLTWH(i * (width + gap), size.height - h, width, h),
          Radius.circular(width / 2));
      canvas.drawRRect(
          rect,
          Paint()
            ..color = Color.lerp(lo, hi, v)!);
    }
  }

  @override
  bool shouldRepaint(covariant _SpectrumPainter oldDelegate) =>
      oldDelegate.values != values ||
      oldDelegate.lo != lo ||
      oldDelegate.hi != hi;
}
