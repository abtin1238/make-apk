import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:file_picker/file_picker.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../core/layout_scope.dart';
import '../services/archive_service.dart';
import '../services/file_ops.dart';
import '../services/transfer_service.dart';
import '../services/folder_sizes.dart';
import '../services/media_events.dart';
import '../widgets/file_thumb.dart';
import '../widgets/ui.dart';
import 'archive_dialog.dart';
import 'job_dialog.dart';
import '../services/trash_service.dart';
import '../services/saf.dart';
import 'saf_prompt.dart';
import '../services/copy_job.dart';
import 'opener.dart';
import 'hash_screen.dart';
import 'hex_viewer_screen.dart';
import 'search_screen.dart';
import 'batch_rename_dialog.dart';
import 'vault_screen.dart';
import '../services/vault_service.dart';

class ClipState {
  static List<String> paths = [];
  static bool cut = false;
}

class BrowserScreen extends StatefulWidget {
  final String initialPath;
  final bool root, active;
  const BrowserScreen({super.key, required this.initialPath, this.root = false, this.active = true});
  @override
  State<BrowserScreen> createState() => _BrowserScreenState();
}

class _Tab {
  final key = GlobalKey<BrowserPaneState>();
  String path;
  _Tab(this.path);
}

class _BrowserScreenState extends State<BrowserScreen> {
  bool bActive = false; // which pane of the dual view is the source of quick transfers
  String bPath = FileOps.root;
  final a = GlobalKey<BrowserPaneState>(), b = GlobalKey<BrowserPaneState>();
  late final List<_Tab> tabs = [_Tab(widget.initialPath)];
  int cur = 0;

  void _refreshAll() {
    for (final t in tabs) {
      t.key.currentState?.refresh();
    }
    a.currentState?.refresh();
    b.currentState?.refresh();
  }

  /// Folder shown in the active pane / tab (target of the per-folder sort).
  String _activePath() {
    final st = context.read<AppSettings>().dual ? (bActive ? b : a).currentState : tabs[cur].key.currentState;
    return st?.path ?? (bActive && context.read<AppSettings>().dual ? bPath : tabs[cur].path);
  }

  Widget _sortMenu(AppSettings s) {
    // path / current sort are read when the menu opens or an item is chosen: the folder can change without a rebuild
    return PopupMenuButton<int>(
      icon: Icon(Icons.sort_rounded, color: s.hasFolderSort(_activePath()) ? Theme.of(context).colorScheme.primary : null),
      onSelected: (v) {
        final path = _activePath();
        final so = s.sortFor(path);
        if (v == 20) {
          s.setSortPerFolder(!s.sortPerFolder);
          return;
        }
        if (v == 21) {
          s.clearFolderSort(path);
        } else {
          final by = v >= 10 ? so.$1 : v;
          final asc = v >= 10 ? v == 10 : so.$2;
          if (s.sortPerFolder) {
            s.setFolderSort(path, by, asc);
          } else {
            s.setSort(by, asc);
          }
        }
        _refreshAll();
      },
      itemBuilder: (_) {
        final path = _activePath();
        final so = s.sortFor(path);
        return [
          for (final e in [(0, 'byName'), (1, 'bySize'), (2, 'byDate'), (3, 'byType')])
            CheckedPopupMenuItem(value: e.$1, checked: so.$1 == e.$1, child: Text(L.t(e.$2))),
          const PopupMenuDivider(),
          CheckedPopupMenuItem(value: 10, checked: so.$2, child: const Text('A → Z')),
          CheckedPopupMenuItem(value: 11, checked: !so.$2, child: const Text('Z → A')),
          const PopupMenuDivider(),
          CheckedPopupMenuItem(value: 20, checked: s.sortPerFolder, child: Text(L.t('sortThisFolder'))),
          if (s.hasFolderSort(path)) PopupMenuItem(value: 21, child: Text(L.t('sortReset'))),
        ];
      },
    );
  }

  void _addTab(String path) => setState(() {
        tabs.add(_Tab(path));
        cur = tabs.length - 1;
        context.read<AppSettings>().setDual(false);
      });

  void _closeTab(int i) {
    if (tabs.length == 1) return;
    setState(() {
      tabs.removeAt(i);
      if (cur >= tabs.length) {
        cur = tabs.length - 1;
      } else if (i < cur) {
        cur--;
      }
    });
  }

  String _tabName(_Tab t) {
    if (t.path == FileOps.root) return L.t('internal');
    final n = p.basename(t.path);
    return n.isEmpty ? '/' : n;
  }

  Widget _tabBar() => SizedBox(
        height: 46,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
          itemCount: tabs.length,
          itemBuilder: (c, i) => Padding(
            padding: const EdgeInsetsDirectional.only(end: 6),
            child: InputChip(
              label: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 120), child: Text(_tabName(tabs[i]), maxLines: 1, overflow: TextOverflow.ellipsis)),
              selected: i == cur,
              onPressed: () => setState(() => cur = i),
              onDeleted: tabs.length > 1 ? () => _closeTab(i) : null,
            ),
          ),
        ),
      );

  // ---------------------------------------------------------------- dual pane
  Future<void> _xfer(bool move) async {
    var src = bActive ? b : a;
    var dst = bActive ? a : b;
    if (src.currentState?.selecting != true && dst.currentState?.selecting == true) {
      final t = src;
      src = dst;
      dst = t;
    }
    final st = src.currentState;
    if (st == null || !st.selecting) {
      snack(context, L.t('selectFirst'));
      return;
    }
    await st.toOther(move);
  }

  void _swapPanes() {
    final pa = a.currentState?.path, pb = b.currentState?.path;
    if (pa == null || pb == null) return;
    a.currentState!.go(pb);
    b.currentState!.go(pa);
  }

  void _syncPanes() {
    final src = bActive ? b : a, dst = bActive ? a : b;
    final ps = src.currentState?.path;
    if (ps != null) dst.currentState?.go(ps);
  }

  Widget _paneBox(GlobalKey<BrowserPaneState> k, bool isB, TextDirection td) {
    final active = bActive == isB;
    return Expanded(
      child: Listener(
        behavior: HitTestBehavior.translucent,
        onPointerDown: (_) { if (bActive != isB) setState(() => bActive = isB); },
        child: Container(
          decoration: BoxDecoration(border: Border.all(color: active ? Theme.of(context).colorScheme.primary : Colors.transparent, width: 2)),
          child: Directionality(
            textDirection: td,
            child: BrowserPane(
              key: k,
              initialPath: isB ? bPath : tabs[cur].path,
              other: () => (isB ? a : b).currentState?.path,
              refreshOther: () => (isB ? a : b).currentState?.refresh(),
              onPath: (np) { if (isB) { bPath = np; } else { tabs[cur].path = np; } },
            ),
          ),
        ),
      ),
    );
  }

  Widget _dualBody() => LayoutBuilder(builder: (context, cons) {
        final wide = cons.maxWidth >= 700 || cons.maxWidth > cons.maxHeight * 1.1;
        final td = Directionality.of(context);
        final cs = Theme.of(context).colorScheme;
        final btns = <Widget>[
          Icon(wide ? (bActive ? Icons.arrow_back_rounded : Icons.arrow_forward_rounded) : (bActive ? Icons.arrow_upward_rounded : Icons.arrow_downward_rounded), color: cs.primary),
          IconButton(icon: const Icon(Icons.copy_rounded), tooltip: L.t('copyOther'), onPressed: () => _xfer(false)),
          IconButton(icon: const Icon(Icons.drive_file_move_rounded), tooltip: L.t('moveOther'), onPressed: () => _xfer(true)),
          IconButton(icon: const Icon(Icons.swap_vert_rounded), tooltip: L.t('swapPanes'), onPressed: _swapPanes),
          IconButton(icon: const Icon(Icons.sync_alt_rounded), tooltip: L.t('syncPanes'), onPressed: _syncPanes),
        ];
        final barColor = Theme.of(context).cardColor;
        if (wide) {
          // panes side by side: A left, B right regardless of the UI language
          return Directionality(
            textDirection: TextDirection.ltr,
            child: Row(children: [
              _paneBox(a, false, td),
              Container(width: 50, color: barColor, child: Column(mainAxisAlignment: MainAxisAlignment.center, children: btns)),
              _paneBox(b, true, td),
            ]),
          );
        }
        return Column(children: [
          _paneBox(a, false, td),
          Container(height: 44, color: barColor, child: Row(mainAxisAlignment: MainAxisAlignment.center, children: btns)),
          _paneBox(b, true, td),
        ]);
      });

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    final title = p.basename(widget.initialPath).isEmpty ? '/' : p.basename(widget.initialPath);
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: !widget.root,
        leading: widget.root ? menuLeading(context) : null,
        title: Text(widget.root ? L.t('files') : title),
        actions: [
          IconButton(icon: const Icon(Icons.search_rounded), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SearchScreen(start: tabs[cur].key.currentState?.path ?? tabs[cur].path)))),
          IconButton(icon: Icon(s.grid ? Icons.view_list_rounded : Icons.grid_view_rounded), tooltip: s.grid ? L.t('listView') : L.t('gridView'), onPressed: () => s.setGrid(!s.grid)),
          IconButton(icon: const Icon(Icons.tab_rounded), tooltip: L.t('newTab'), onPressed: () => _addTab(tabs[cur].key.currentState?.path ?? tabs[cur].path)),
          IconButton(icon: Icon(s.dual ? Icons.view_agenda_rounded : Icons.splitscreen_rounded), tooltip: L.t('dual'), onPressed: () => s.setDual(!s.dual)),
          _sortMenu(s),
        ],
      ),
      body: s.dual
          ? _dualBody()
          : Column(children: [
              if (tabs.length > 1) _tabBar(),
              Expanded(
                child: IndexedStack(index: cur, children: [
                  for (var i = 0; i < tabs.length; i++)
                    BrowserPane(
                      key: tabs[i].key,
                      initialPath: tabs[i].path,
                      other: () => null,
                      active: widget.active && i == cur,
                      onPath: (np) { if (mounted) setState(() => tabs[i].path = np); },
                      openTab: _addTab,
                    ),
                ]),
              ),
            ]),
    );
  }
}

class BrowserPane extends StatefulWidget {
  final String initialPath;
  final String? Function() other;
  final VoidCallback? refreshOther;
  final void Function(String path)? onPath, openTab;
  final bool active;
  const BrowserPane({super.key, required this.initialPath, required this.other, this.refreshOther, this.onPath, this.openTab, this.active = true});
  @override
  State<BrowserPane> createState() => BrowserPaneState();
}

class BrowserPaneState extends State<BrowserPane> {
  late String path = widget.initialPath;
  List<FItem> items = [];
  final sel = <String>{};
  bool loading = true;
  String? err;
  bool get selecting => sel.isNotEmpty;
  StreamSubscription<Set<String>>? _delSub;

  @override
  void initState() {
    super.initState();
    // files deleted in a viewer vanish from the list immediately (no waiting for a refresh)
    _delSub = MediaEvents.onDeleted.listen((ps) {
      if (!mounted || !items.any((e) => ps.contains(e.path))) return;
      setState(() {
        items = items.where((e) => !ps.contains(e.path)).toList();
        sel.removeAll(ps);
      });
    });
    refresh();
  }

  @override
  void dispose() {
    _delSub?.cancel();
    super.dispose();
  }

  Future<void> refresh() async {
    final s = context.read<AppSettings>();
    try {
      final so = s.sortFor(path);
      final r = await FileOps.list(path, hidden: s.showHidden, sortBy: so.$1, asc: so.$2);
      if (mounted) setState(() { items = r; loading = false; err = null; });
    } catch (e) {
      if (mounted) setState(() { loading = false; err = '$e'; items = []; });
    }
  }

  void go(String np) {
    sel.clear();
    path = np;
    loading = true;
    setState(() {});
    widget.onPath?.call(np);
    refresh();
  }

  bool get atTop => path == FileOps.root || p.dirname(path) == path || FileOps.roots().any((r) => r.path == path);

  List<FItem> get selected => items.where((i) => sel.contains(i.path)).toList();

  Future<void> _op(Future<void> Function() job) async {
    final ok = await busy(context, job);
    if (!mounted) return;
    setState(sel.clear);
    await refresh();
    if (ok && mounted) snack(context, L.t('done'));
  }

  void _undoBar(List<TrashEntry> es) {
    final m = ScaffoldMessenger.of(context);
    m.hideCurrentSnackBar();
    m.showSnackBar(SnackBar(
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 8),
      content: Text('${L.t('movedToTrash')} (${es.length})'),
      action: SnackBarAction(
        label: L.t('undo'),
        onPressed: () async {
          for (final e in es) {
            try { await TrashService.restore(e); } catch (_) {}
          }
          if (mounted) {
            await refresh();
            widget.refreshOther?.call();
          }
        },
      ),
    ));
  }

  Future<void> _toVault() async {
    final list = selected;
    if (list.isEmpty) return;
    if (!VaultService.unlocked) {
      await Navigator.push(context, MaterialPageRoute(builder: (_) => const VaultScreen(popOnUnlock: true)));
      if (!mounted || !VaultService.unlocked) return;
    }
    if (!await confirm(context, '${L.t('toVaultAsk')} (${list.length})')) return;
    if (!mounted) return;
    final ok = await busy(context, () => VaultService.addPaths(list.map((e) => e.path).toList()));
    if (!mounted) return;
    setState(sel.clear);
    await refresh();
    if (ok && mounted) snack(context, L.t('vaultAdded'));
  }

  Future<void> _delete() async {
    final st = context.read<AppSettings>();
    final list = selected;
    if (list.isEmpty) return;
    if (!await ensureSdAll(context, list.map((e) => e.path))) return;
    if (!mounted) return;
    final useTrash = st.trashEnabled;
    if (st.confirmDelete) {
      final msg = useTrash ? '${L.t('moveToTrash')} (${list.length})?' : '${L.t('deletePermanent')} (${list.length})?';
      if (!await confirm(context, msg)) return;
    }
    if (!mounted) return;
    final entries = <TrashEntry>[];
    final failed = <FItem>[];
    final ok = await busy(context, () async {
      final errs = <String>[];
      for (final i in list) {
        try {
          if (useTrash && !TrashService.isInTrash(i.path)) {
            try {
              entries.add(await TrashService.moveToTrash(i.entity));
            } on OpError catch (x) {
              if (x.key == 'trashFail') {
                failed.add(i);
                continue;
              }
              rethrow;
            }
          } else {
            await FileOps.delete(i.entity);
          }
          st.removePath(i.path);
        } catch (e) {
          errs.add('$e');
        }
      }
      if (errs.isNotEmpty) throw OpError('delFail', errs.first);
    });
    if (failed.isNotEmpty && mounted && await confirm(context, L.t('trashFailAsk'))) {
      if (!mounted) return;
      await busy(context, () async {
        for (final i in failed) {
          await FileOps.delete(i.entity);
          st.removePath(i.path);
        }
      });
    }
    if (!mounted) return;
    setState(sel.clear);
    await refresh();
    if (!mounted) return;
    if (entries.isNotEmpty) {
      _undoBar(entries);
    } else if (ok && failed.isEmpty) {
      snack(context, L.t('done'));
    }
  }

  Future<CopyJob?> _transfer(List<FileSystemEntity> list, String dest, bool move) async {
    if (!await ensureSdAll(context, [dest, if (move) ...list.map((e) => e.path)])) return null;
    if (!mounted) return null;
    final job = await runCopyJob(context, list, dest, move: move);
    if (mounted) {
      setState(sel.clear);
      await refresh();
      widget.refreshOther?.call();
      if (mounted) snack(context, jobResultText(job));
    }
    return job;
  }

  Future<void> _paste() async {
    final list = ClipState.paths.map((x) => FileSystemEntity.isDirectorySync(x) ? Directory(x) as FileSystemEntity : File(x)).toList();
    final cut = ClipState.cut;
    final job = await _transfer(list, path, cut);
    if (job == null) return;
    if (cut && !job.cancelled) ClipState.paths = [];
    if (mounted) setState(() {});
  }

  Future<void> toOther(bool move) async {
    final dst = widget.other();
    if (dst == null) return;
    final list = selected.map((i) => i.entity).toList();
    await _transfer(list, dst, move);
  }

  Future<void> _rename() async {
    final i = selected.first;
    final n = await promptText(context, L.t('rename'), initial: i.name);
    if (n == null || n.isEmpty || n == i.name) return;
    if (!mounted || !await ensureSdAll(context, [i.path])) return;
    if (!mounted) return;
    final st = context.read<AppSettings>();
    await _op(() async {
      await FileOps.rename(i.entity, n);
      st.renamePath(i.path, p.join(path, n.trim()));
    });
  }

  Future<void> _batchRename() async {
    final list = selected;
    if (list.length < 2) return;
    if (!await ensureSdAll(context, list.map((e) => e.path))) return;
    if (!mounted) return;
    final plan = await askBatchRename(context, list);
    if (plan == null || plan.isEmpty || !mounted) return;
    final st = context.read<AppSettings>();
    await _op(() async {
      // two-phase (via temp names) only when a new name equals another selected item's old name
      final olds = list.map((e) => e.name.toLowerCase()).toSet();
      final viaTmp = plan.any((r) => olds.contains(r.newName.toLowerCase()));
      final stamp = DateTime.now().microsecondsSinceEpoch;
      final moved = <(RenamePlan, String)>[]; // plan, current path
      try {
        if (viaTmp) {
          var k = 0;
          for (final r in plan) {
            final t = '.abtin_rn_${stamp}_${k++}';
            await FileOps.rename(r.item.entity, t);
            moved.add((r, p.join(path, t)));
          }
          for (final m in List.of(moved)) {
            final e = m.$1.item.isDir ? Directory(m.$2) as FileSystemEntity : File(m.$2);
            await FileOps.rename(e, m.$1.newName);
            st.renamePath(m.$1.item.path, p.join(path, m.$1.newName));
            moved.remove(m);
          }
        } else {
          for (final r in plan) {
            await FileOps.rename(r.item.entity, r.newName);
            st.renamePath(r.item.path, p.join(path, r.newName));
          }
        }
      } catch (_) {
        for (final m in moved) { // put back whatever is still under a temp name
          try {
            final e = m.$1.item.isDir ? Directory(m.$2) as FileSystemEntity : File(m.$2);
            await FileOps.rename(e, m.$1.item.name);
          } catch (_) {}
        }
        rethrow;
      }
    });
  }

  Future<void> _compress() async {
    final list = selected;
    final def = list.length == 1 ? p.basenameWithoutExtension(list.first.name) : p.basename(path);
    final ch = await askCompress(context, def);
    if (ch == null) return;
    if (!mounted || !await ensureSdAll(context, [path])) return;
    final srcs = list.map((e) => e.path).toList();
    final out = FileOps.unique(path, ch.name);
    final ext = ArchiveService.extFor(ch.format);
    final ctx = context;
    final ok = await busyProgress(ctx, L.t('compressing'), (report) async {
      if (await Saf.use(path)) {
        final tmp = p.join(Directory.systemTemp.path, 'abtin_${DateTime.now().microsecondsSinceEpoch}$ext');
        try {
          await ArchiveService.compress(srcs, tmp, ch.format, password: ch.password, volumeMB: ch.volumeMB, onProgress: report);
          for (final part in ArchiveService.outputParts(tmp, ch.format, ch.volumeMB)) {
            await Saf.copyFileIn(part, ArchiveService.partTarget(part, tmp, out));
          }
        } finally {
          for (final part in ArchiveService.outputParts(tmp, ch.format, ch.volumeMB)) {
            try { await File(part).delete(); } catch (_) {}
          }
        }
      } else {
        await ArchiveService.compress(srcs, out, ch.format, password: ch.password, volumeMB: ch.volumeMB, onProgress: report);
      }
    });
    if (!mounted) return;
    setState(sel.clear);
    await refresh();
    if (ok && mounted) snack(context, L.t('done'));
  }

  Future<void> _details(FItem i) async {
    int size = i.size;
    if (i.isDir) size = await FolderSizes.get(i.path, mtime: i.modified, force: true);
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(i.name),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          SelectableText('${L.t('path')}: ${i.path}'),
          const SizedBox(height: 6),
          Text('${L.t('size')}: ${FileOps.fmt(size)}'),
          Text('${L.t('modified')}: ${i.modified.toString().split('.').first}'),
        ]),
        actions: [
          if (!i.isDir) TextButton(onPressed: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => HashScreen(path: i.path))); }, child: Text(L.t('hash'))),
          if (!i.isDir) TextButton(onPressed: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => HexViewerScreen(path: i.path))); }, child: Text(L.t('hex'))),
          TextButton(onPressed: () => Navigator.pop(context), child: Text(L.t('ok'))),
        ],
      ),
    );
  }

  Future<void> _newItem() async {
    if (!await ensureSdAll(context, [path])) return;
    if (!mounted) return;
    final isFolder = await showModalBottomSheet<bool>(
      context: context,
      builder: (_) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(leading: const Icon(Icons.create_new_folder_rounded), title: Text(L.t('newFolder')), onTap: () => Navigator.pop(context, true)),
          ListTile(leading: const Icon(Icons.note_add_rounded), title: Text(L.t('newFile')), onTap: () => Navigator.pop(context, false)),
          ListTile(leading: const Icon(Icons.upload_file_rounded), title: const Text('Import…'), onTap: () async {
            Navigator.pop(context);
            final r = await FilePicker.platform.pickFiles(allowMultiple: true);
            if (r == null) return;
            await _transfer(r.paths.whereType<String>().map((f) => File(f) as FileSystemEntity).toList(), path, false);
          }),
        ]),
      ),
    );
    if (isFolder == null) return;
    if (!mounted) return;
    final n = await promptText(context, isFolder ? L.t('newFolder') : L.t('newFile'));
    if (n == null || n.isEmpty) return;
    await _op(() => isFolder ? FileOps.mkdir(path, n) : FileOps.touch(path, n));
  }

  void _shareLan() {
    final t = context.read<TransferService>();
    t.share(selected.map((e) => e.path).toList());
    snack(context, t.running ? (t.url ?? '') : L.t('startServerFirst'));
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return PopScope(
      canPop: !(widget.active && (selecting || !atTop)),
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        if (selecting) { setState(sel.clear); } else if (!atTop) { go(p.dirname(path)); }
      },
      child: Column(children: [
        _crumbs(),
        if (selecting) _selBar(),
        Expanded(
          child: Stack(children: [
            loading
                ? const Center(child: CircularProgressIndicator())
                : err != null
                    ? Center(child: Text(err!))
                    : RefreshIndicator(
                        onRefresh: refresh,
                        child: items.isEmpty
                            ? ListView(children: [SizedBox(height: 200, child: Center(child: Text(L.t('empty'))))])
                            : s.grid
                                ? GridView.builder(
                                    padding: const EdgeInsets.fromLTRB(8, 8, 8, 90),
                                    gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 120, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: .66),
                                    itemCount: items.length,
                                    itemBuilder: (c, i) => _gridTile(items[i], s),
                                  )
                                : ListView.builder(
                                    padding: const EdgeInsets.only(bottom: 90),
                                    itemCount: items.length,
                                    itemBuilder: (c, i) => _tile(items[i], s),
                                  ),
                      ),
            Positioned(
              bottom: 16, right: 16, left: 16,
              child: Row(mainAxisAlignment: MainAxisAlignment.end, children: [
                if (ClipState.paths.isNotEmpty)
                  FloatingActionButton.extended(heroTag: null, onPressed: _paste, icon: const Icon(Icons.paste_rounded), label: Text('${L.t('paste')} (${ClipState.paths.length})')),
                const SizedBox(width: 10),
                FloatingActionButton(heroTag: null, onPressed: _newItem, child: const Icon(Icons.add_rounded)),
              ]),
            ),
          ]),
        ),
      ]),
    );
  }

  void _toggle(FItem i) => setState(() => sel.contains(i.path) ? sel.remove(i.path) : sel.add(i.path));

  void _tap(FItem i) {
    if (selecting) { _toggle(i); return; }
    if (i.isDir) { go(i.path); return; }
    Opener.open(context, i.path, siblings: items.where((e) => !e.isDir).map((e) => e.path).toList(), onChanged: refresh);
  }

  Widget _crumbs() {
    final parts = p.split(path);
    return SizedBox(
      height: 40,
      child: ListView(
        scrollDirection: Axis.horizontal,
        reverse: false,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        children: [
          for (var i = 0; i < parts.length; i++)
            InkWell(
              onTap: () => go(p.joinAll(parts.sublist(0, i + 1))),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
                child: Text('${parts[i] == '/' ? '/' : parts[i]} ›', style: TextStyle(fontSize: 13, fontWeight: i == parts.length - 1 ? FontWeight.bold : FontWeight.normal)),
              ),
            ),
        ],
      ),
    );
  }

  Widget _selBar() => Container(
        color: Theme.of(context).cardColor,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [
            IconButton(icon: const Icon(Icons.close_rounded), onPressed: () => setState(sel.clear)),
            Text('${sel.length}'),
            IconButton(icon: const Icon(Icons.select_all_rounded), tooltip: L.t('selectAll'), onPressed: () => setState(() => sel.addAll(items.map((e) => e.path)))),
            IconButton(icon: const Icon(Icons.copy_rounded), tooltip: L.t('copy'), onPressed: () { ClipState.paths = sel.toList(); ClipState.cut = false; setState(sel.clear); }),
            IconButton(icon: const Icon(Icons.content_cut_rounded), tooltip: L.t('move'), onPressed: () { ClipState.paths = sel.toList(); ClipState.cut = true; setState(sel.clear); }),
            if (widget.other() != null) ...[
              IconButton(icon: const Icon(Icons.arrow_circle_down_rounded), tooltip: L.t('copyOther'), onPressed: () => toOther(false)),
              IconButton(icon: const Icon(Icons.drive_file_move_rounded), tooltip: L.t('moveOther'), onPressed: () => toOther(true)),
            ],
            IconButton(icon: const Icon(Icons.delete_rounded), tooltip: L.t('delete'), onPressed: _delete),
            IconButton(icon: const Icon(Icons.enhanced_encryption_rounded), tooltip: L.t('toVault'), onPressed: _toVault),
            if (sel.length == 1 && selected.first.isDir && widget.openTab != null)
              IconButton(icon: const Icon(Icons.tab_rounded), tooltip: L.t('openNewTab'), onPressed: () { final d = selected.first.path; setState(sel.clear); widget.openTab!(d); }),
            IconButton(icon: const Icon(Icons.drive_file_rename_outline_rounded), tooltip: sel.length == 1 ? L.t('rename') : L.t('batchRename'), onPressed: sel.length == 1 ? _rename : _batchRename),
            IconButton(icon: const Icon(Icons.folder_zip_rounded), tooltip: L.t('compress'), onPressed: _compress),
            IconButton(
              icon: const Icon(Icons.share_rounded),
              tooltip: L.t('share'),
              onPressed: () => Share.shareXFiles(selected.where((e) => !e.isDir).map((e) => XFile(e.path)).toList()),
            ),
            IconButton(icon: const Icon(Icons.wifi_tethering_rounded), tooltip: 'LAN', onPressed: _shareLan),
            if (sel.length == 1) IconButton(icon: const Icon(Icons.info_outline_rounded), tooltip: L.t('details'), onPressed: () => _details(selected.first)),
            if (sel.length == 1) Builder(builder: (_) {
              final s = context.watch<AppSettings>();
              final f = selected.first.path;
              return IconButton(icon: Icon(s.isFav(f) ? Icons.star_rounded : Icons.star_border_rounded), onPressed: () => s.toggleFav(f));
            }),
          ]),
        ),
      );

  String _date(FItem i) => FileOps.dt(i.modified);

  Widget _tile(FItem i, AppSettings s) {
    final selected = sel.contains(i.path);
    const small = TextStyle(fontSize: 11);
    final dense = s.dense;
    return ListTile(
      dense: dense,
      visualDensity: dense ? VisualDensity.compact : null,
      selected: selected,
      selectedTileColor: Theme.of(context).colorScheme.primary.withOpacity(.18),
      leading: FileThumb(item: i, size: dense ? 34 : 44),
      title: Text(i.name, maxLines: 1, overflow: TextOverflow.ellipsis),
      subtitle: i.isDir
          ? (s.folderSizes ? FolderSizeText(path: i.path, modified: i.modified, suffix: ' • ${_date(i)}', style: small) : Text(_date(i), style: small))
          : Text('${FileOps.fmt(i.size)} • ${_date(i)}', style: small),
      trailing: selecting ? Icon(selected ? Icons.check_circle_rounded : Icons.circle_outlined) : (s.isFav(i.path) ? const Icon(Icons.star_rounded, color: Colors.amber, size: 18) : null),
      onLongPress: () => _toggle(i),
      onTap: () => _tap(i),
    );
  }

  Widget _gridTile(FItem i, AppSettings s) {
    final selected = sel.contains(i.path);
    final cs = Theme.of(context).colorScheme;
    const small = TextStyle(fontSize: 10);
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: () => _tap(i),
      onLongPress: () => _toggle(i),
      child: Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: selected ? cs.primary.withOpacity(.18) : null,
          border: selected ? Border.all(color: cs.primary) : null,
        ),
        child: Column(children: [
          Expanded(
            child: Stack(fit: StackFit.expand, children: [
              LayoutBuilder(builder: (_, c) => Center(child: FileThumb(item: i, size: math.max(24, math.min(c.maxWidth, c.maxHeight))))),
              if (selecting) PositionedDirectional(top: 2, end: 2, child: Icon(selected ? Icons.check_circle_rounded : Icons.circle_outlined, size: 20, color: cs.primary)),
              if (s.isFav(i.path)) const PositionedDirectional(top: 2, start: 2, child: Icon(Icons.star_rounded, color: Colors.amber, size: 16)),
            ]),
          ),
          const SizedBox(height: 4),
          Text(i.name, maxLines: 2, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.5, height: 1.15)),
          if (i.isDir)
            (s.folderSizes ? FolderSizeText(path: i.path, modified: i.modified, style: small) : const SizedBox(height: 12))
          else
            Text(FileOps.fmt(i.size), style: small),
          Text(_date(i), maxLines: 1, style: TextStyle(fontSize: 9.5, color: Theme.of(context).hintColor)),
        ]),
      ),
    );
  }
}
