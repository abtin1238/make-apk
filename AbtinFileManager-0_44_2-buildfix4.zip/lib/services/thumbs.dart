import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'video_thumb.dart';
import 'file_ops.dart';
import 'native.dart';

/// One pending image-thumbnail request; [cancel] it when the widget scrolls away / is disposed.
class ThumbJob {
  final String key, path;
  final int px;
  final void Function(Uint8List?) cb;
  bool cancelled = false;
  ThumbJob(this.key, this.path, this.px, this.cb);
  void cancel() => cancelled = true;
}

/// Video thumbnails and APK icons with an in-memory LRU and a disk cache.
/// Image thumbnails are made natively (`ImageThumbNative.kt`) and queued newest-first.
class Thumbs {
  static final _imgMem = <String, Uint8List>{};
  static final _imgFailed = <String>{};
  static final _imgQueue = <ThumbJob>[];
  static final _imgKeysByPath = <String, Set<String>>{};
  static int _imgRunning = 0;
  static const _imgMax = 4;

  static final _mem = <String, Uint8List>{};
  static final _failed = <String>{};
  static final _inflight = <String, Future<Uint8List?>>{};
  static final _keysByPath = <String, Set<String>>{};
  static Directory? _dir;
  static int _running = 0;
  static final _waiters = <Completer<void>>[];

  static String _hash(String s) {
    var h = 0xcbf29ce484222325;
    for (final c in s.codeUnits) {
      h = (h ^ c) * 0x100000001b3;
    }
    return h.toUnsigned(64).toRadixString(16);
  }

  static Future<void> _acquire() async {
    if (_running < 3) {
      _running++;
      return;
    }
    final c = Completer<void>();
    _waiters.add(c);
    await c.future;
  }

  static void _release() {
    if (_waiters.isNotEmpty) {
      _waiters.removeAt(0).complete();
    } else {
      _running--;
    }
  }

  static Directory _cacheDir() {
    final d = _dir ??= Directory('${Directory.systemTemp.path}/abtin_thumbs');
    if (!d.existsSync()) d.createSync(recursive: true);
    return d;
  }

  static Future<Uint8List?> _cached(FItem it, String kind, Future<Uint8List?> Function() make) {
    final key = '$kind|${it.path}|${it.size}|${it.modified.millisecondsSinceEpoch}';
    (_keysByPath[it.path] ??= <String>{}).add(key);
    final hit = _mem.remove(key);
    if (hit != null) {
      _mem[key] = hit;
      return Future.value(hit);
    }
    if (_failed.contains(key)) return Future.value(null);
    return _inflight.putIfAbsent(key, () async {
      try {
        final file = File('${_cacheDir().path}/${_hash(key)}.img');
        Uint8List? data;
        if (file.existsSync()) {
          try { data = await file.readAsBytes(); } catch (_) {}
        }
        if (data == null || data.isEmpty) {
          await _acquire();
          try {
            data = await make();
          } finally {
            _release();
          }
          if (data != null && data.isNotEmpty) {
            try { await file.writeAsBytes(data); } catch (_) {}
          }
        }
        if (data == null || data.isEmpty) {
          _failed.add(key);
          return null;
        }
        _mem[key] = data;
        if (_mem.length > 400) _mem.remove(_mem.keys.first);
        return data;
      } catch (_) {
        _failed.add(key);
        return null;
      } finally {
        _inflight.remove(key);
      }
    });
  }

  /// Drops every cached preview (memory + disk) of a deleted file.
  static void evict(String path) {
    final ik = _imgKeysByPath.remove(path);
    if (ik != null) {
      for (final k in ik) {
        _imgMem.remove(k);
        _imgFailed.remove(k);
      }
    }
    final keys = _keysByPath.remove(path);
    if (keys == null) return;
    for (final k in keys) {
      _mem.remove(k);
      _failed.remove(k);
      _inflight.remove(k);
      try { File('${_cacheDir().path}/${_hash(k)}.img').deleteSync(); } catch (_) {}
    }
  }

  // ---------------------------------------------------------------- images
  static String imageKey(FItem it, int px) => '${it.path}|${it.size}|${it.modified.millisecondsSinceEpoch}|$px';

  /// Synchronous memory hit (so a cached thumbnail shows on the very first frame, no flicker).
  static Uint8List? peekImage(FItem it, int px) {
    final k = imageKey(it, px);
    final h = _imgMem.remove(k);
    if (h != null) _imgMem[k] = h;
    return h;
  }

  static bool isImageFailed(FItem it, int px) => _imgFailed.contains(imageKey(it, px));

  /// Queues a thumbnail request. The newest request runs first (what you just scrolled to), cancelled ones are skipped.
  static ThumbJob requestImage(FItem it, int px, void Function(Uint8List?) cb) {
    final k = imageKey(it, px);
    (_imgKeysByPath[it.path] ??= <String>{}).add(k);
    final j = ThumbJob(k, it.path, px, cb);
    _imgQueue.add(j);
    _pump();
    return j;
  }

  static void _pump() {
    while (_imgRunning < _imgMax && _imgQueue.isNotEmpty) {
      final j = _imgQueue.removeLast();
      if (j.cancelled) continue;
      _imgRunning++;
      _runImg(j);
    }
  }

  static Future<void> _runImg(ThumbJob j) async {
    Uint8List? data;
    try {
      data = await Native.imageThumb(j.path, j.px);
    } catch (_) {}
    _imgRunning--;
    if (data == null || data.isEmpty) {
      _imgFailed.add(j.key);
      data = null;
    } else {
      _imgMem[j.key] = data;
      if (_imgMem.length > 700) _imgMem.remove(_imgMem.keys.first);
    }
    if (!j.cancelled) j.cb(data);
    _pump();
  }

  static Future<Uint8List?> video(FItem it) => _cached(it, 'v', () async {
        try {
          return await VideoThumb.data(it.path, maxWidth: 256, quality: 60);
        } catch (_) {
          return null;
        }
      });

  static Future<Uint8List?> apkIcon(FItem it) => _cached(it, 'a', () => Native.apkIcon(it.path));
}
