import 'dart:typed_data';
import 'package:flutter/services.dart';

/// Replacement for the `video_thumbnail` plugin (its Gradle script still uses jcenter(),
/// which no longer exists in Gradle 9). Implemented natively in ImageThumbNative.kt.
class VideoThumb {
  static const _ch = MethodChannel('abtin/thumb');

  static Future<Uint8List?> data(String path, {int maxWidth = 256, int timeMs = 0, int quality = 60}) async {
    try {
      final r = await _ch.invokeMethod<Uint8List>('video', {'path': path, 'maxWidth': maxWidth, 'timeMs': timeMs, 'quality': quality});
      return (r == null || r.isEmpty) ? null : r;
    } catch (_) {
      return null;
    }
  }
}
