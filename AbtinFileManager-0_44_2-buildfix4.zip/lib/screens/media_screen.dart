import 'dart:typed_data';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:path/path.dart' as p;
import 'package:provider/provider.dart';
import '../services/video_thumb.dart';
import '../core/l10n.dart';
import '../core/settings.dart';
import '../core/theme.dart';
import '../services/file_ops.dart';
import '../services/media_store.dart';
import '../services/player_service.dart';
import '../services/playlist_store.dart';
import 'playlist_screens.dart';
import '../widgets/ui.dart';
import 'audio_options_screen.dart';
import 'audio_player_screen.dart';
import 'tag_editor_screen.dart';
import 'opener.dart';
import 'video_player_screen.dart';

/// Media library: continue watching, videos, music, folders, favourites, network stream.
class MediaScreen extends StatefulWidget {
  const MediaScreen({super.key});
  @override
  State<MediaScreen> createState() => _MediaScreenState();
}

class _MediaScreenState extends State<MediaScreen> {
  final videos = <FItem>[], audios = <FItem>[];
  bool done = false;
  String q = '';
  static final _thumbs = <String, Future<Uint8List?>>{};

  @override
  void initState() {
    super.initState();
    _scan();
  }

  Future<void> _scan() async {
    var n = 0;
    await for (final f in FileOps.walk(FileOps.root, skipAndroid: true)) {
      if (!mounted) return;
      final c = FileOps.catOf(f.path);
      if (c != Cat.videos && c != Cat.audio) continue;
      try {
        final s = await f.stat();
        (c == Cat.videos ? videos : audios).add(FItem(f, false, s.size, s.modified));
      } catch (_) {}
      if (++n % 25 == 0) setState(() {});
    }
    videos.sort((a, b) => b.modified.compareTo(a.modified));
    audios.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    if (mounted) setState(() => done = true);
    await TagCache.scan([for (final a in audios) MapEntry(a.path, a.size)], () => mounted, () { if (mounted) setState(() {}); });
  }

  bool _match(FItem i) => q.isEmpty || i.name.toLowerCase().contains(q);

  Future<void> _network() async {
    final url = await promptText(context, L.t('networkUrl'), initial: 'https://');
    if (url == null || !RegExp(r'^[a-z]+://', caseSensitive: false).hasMatch(url) || !mounted) return;
    final path = Uri.tryParse(url)?.path ?? url;
    if (FileOps.exts[Cat.audio]!.contains(p.extension(path).toLowerCase().replaceFirst('.', ''))) {
      await context.read<PlayerService>().playList([url], 0);
      if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const AudioPlayerScreen()));
    } else {
      Navigator.push(context, MaterialPageRoute(builder: (_) => VideoPlayerScreen(paths: [url], index: 0)));
    }
  }

  Widget _thumb(FItem it) => FutureBuilder<Uint8List?>(
        future: _thumbs.putIfAbsent(it.path, () async {
          try {
            return await VideoThumb.data(it.path, maxWidth: 192, quality: 55);
          } catch (_) {
            return null;
          }
        }),
        builder: (_, s) => ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: SizedBox(
            width: 96,
            height: 60,
            child: s.data != null ? Image.memory(s.data!, fit: BoxFit.cover) : Container(color: Colors.black26, child: const Icon(Icons.play_circle_rounded, color: AppColors.purple)),
          ),
        ),
      );

  void _menu(FItem it, List<FItem> list) {
    final isAudio = FileOps.isCat(it.path, Cat.audio);
    final pl = context.read<PlayerService>();
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Wrap(children: [
          ListTile(leading: const Icon(Icons.play_arrow_rounded), title: Text(L.t('play')), onTap: () { Navigator.pop(context); Opener.open(context, it.path, siblings: list.map((e) => e.path).toList()); }),
          if (isAudio) ...[
            ListTile(leading: const Icon(Icons.queue_play_next_rounded), title: Text(L.t('playNext')), onTap: () { pl.enqueue(it.path, next: true); Navigator.pop(context); snack(context, L.t('done')); }),
            ListTile(leading: const Icon(Icons.playlist_add_rounded), title: Text(L.t('addToPlaylist')), onTap: () { Navigator.pop(context); addToPlaylist(context, [it.path]); }),
            ListTile(leading: const Icon(Icons.sell_rounded), title: Text(L.t('tagEdit')), onTap: () async { Navigator.pop(context); await Navigator.push(context, MaterialPageRoute(builder: (_) => TagEditorScreen(path: it.path))); TagCache.invalidate(); if (mounted) setState(() {}); }),
            ListTile(leading: const Icon(Icons.add_to_queue_rounded), title: Text(L.t('addQueue')), onTap: () { pl.enqueue(it.path); Navigator.pop(context); snack(context, L.t('done')); }),
          ] else if (MediaStore.state(it.path) != null)
            ListTile(leading: const Icon(Icons.restart_alt_rounded), title: Text(L.t('forgetPos')), onTap: () { MediaStore.clear(it.path); Navigator.pop(context); setState(() {}); }),
        ]),
      ),
    );
  }

  Widget _videoTile(FItem it, List<FItem> list) {
    final st = MediaStore.state(it.path);
    return ListTile(
      leading: _thumb(it),
      title: Text(it.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14)),
      subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('${FileOps.fmt(it.size)} • ${FileOps.dt(it.modified)}', style: const TextStyle(fontSize: 11)),
        if (st != null) Padding(padding: const EdgeInsets.only(top: 4), child: LinearProgressIndicator(value: st[1] == 0 ? 0 : st[0] / st[1], minHeight: 3)),
      ]),
      onTap: () => Opener.open(context, it.path, siblings: list.map((e) => e.path).toList()).then((_) { if (mounted) setState(() {}); }),
      onLongPress: () => _menu(it, list),
    );
  }

  Widget _audioTile(FItem it, List<FItem> list) => ListTile(
        leading: TypeIcon(it.path, false, size: 32),
        title: Text(p.basenameWithoutExtension(it.name), maxLines: 1, overflow: TextOverflow.ellipsis),
        subtitle: Text('${p.basename(p.dirname(it.path))} • ${FileOps.fmt(it.size)} • ${FileOps.dt(it.modified)}', maxLines: 1, style: const TextStyle(fontSize: 11)),
        onTap: () => Opener.open(context, it.path, siblings: list.map((e) => e.path).toList()),
        onLongPress: () => _menu(it, list),
      );

  Widget _list(List<FItem> src, bool video) {
    final list = src.where(_match).toList();
    if (list.isEmpty) return Center(child: done ? Text(L.t('empty')) : const CircularProgressIndicator());
    return ListView.builder(itemCount: list.length, itemBuilder: (_, i) => video ? _videoTile(list[i], list) : _audioTile(list[i], list));
  }

  Widget _continue() {
    final all = [...videos, ...audios];
    final byPath = {for (final i in all) i.path: i};
    final items = MediaStore.all.keys.toList().reversed.where(byPath.containsKey).map((k) => byPath[k]!).where(_match).toList();
    if (items.isEmpty) return Center(child: Text(done ? L.t('noContinue') : L.t('scanning')));
    return ListView.builder(
      itemCount: items.length,
      itemBuilder: (_, i) => FileOps.isCat(items[i].path, Cat.videos) ? _videoTile(items[i], items) : _audioTile(items[i], items),
    );
  }

  Widget _folders() {
    final m = <String, List<FItem>>{};
    for (final i in [...videos, ...audios]) {
      m.putIfAbsent(p.dirname(i.path), () => []).add(i);
    }
    final keys = m.keys.where((k) => q.isEmpty || p.basename(k).toLowerCase().contains(q)).toList()..sort((a, b) => p.basename(a).toLowerCase().compareTo(p.basename(b).toLowerCase()));
    if (keys.isEmpty) return Center(child: done ? Text(L.t('empty')) : const CircularProgressIndicator());
    return ListView.builder(
      itemCount: keys.length,
      itemBuilder: (_, i) => ListTile(
        leading: TypeIcon('', true, size: 36),
        title: Text(p.basename(keys[i])),
        subtitle: Text('${m[keys[i]]!.length}', style: const TextStyle(fontSize: 11)),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _FolderMedia(title: p.basename(keys[i]), items: m[keys[i]]!))),
      ),
    );
  }

  Widget _favs() {
    final s = context.watch<AppSettings>();
    final favs = [...videos, ...audios].where((e) => s.isFav(e.path) && _match(e)).toList();
    if (favs.isEmpty) return Center(child: Text(L.t('empty')));
    return ListView.builder(itemCount: favs.length, itemBuilder: (_, i) => FileOps.isCat(favs[i].path, Cat.videos) ? _videoTile(favs[i], favs) : _audioTile(favs[i], favs));
  }

  Map<String, List<String>> _group(int idx) {
    final m = <String, List<String>>{};
    for (final a in audios) {
      final t = TagCache.get(a.path, a.size);
      var k = t == null ? '' : t[idx];
      if (k.isEmpty && idx == 1) k = p.basename(p.dirname(a.path));
      if (q.isNotEmpty && !k.toLowerCase().contains(q) && !a.name.toLowerCase().contains(q)) continue;
      m.putIfAbsent(k, () => []).add(a.path);
    }
    return m;
  }

  Widget _playBar(List<FItem> audios) => Padding(
        padding: const EdgeInsets.fromLTRB(12, 4, 12, 4),
        child: Row(children: [
          Expanded(
            child: FilledButton.icon(
              icon: const Icon(Icons.play_arrow_rounded),
              label: Text(L.t('playAll')),
              onPressed: audios.isEmpty ? null : () async {
                final pl = context.read<PlayerService>();
                final list = audios.where(_match).map((e) => e.path).toList();
                if (list.isEmpty) return;
                await pl.playList(list, 0);
                if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const AudioPlayerScreen()));
              },
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: OutlinedButton.icon(
              icon: const Icon(Icons.shuffle_rounded),
              label: Text(L.t('shuffle')),
              onPressed: audios.isEmpty ? null : () async {
                final pl = context.read<PlayerService>();
                final list = (audios.where(_match).map((e) => e.path).toList()..shuffle());
                if (list.isEmpty) return;
                await pl.playList(list, 0);
                if (mounted) Navigator.push(context, MaterialPageRoute(builder: (_) => const AudioPlayerScreen()));
              },
            ),
          ),
        ]),
      );

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 8,
        child: Scaffold(
          appBar: AppBar(
            title: Text(L.t('media')),
            actions: [
              IconButton(icon: const Icon(Icons.tune_rounded), tooltip: L.t('playOpts'), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AudioOptionsScreen()))),
              IconButton(icon: const Icon(Icons.link_rounded), tooltip: L.t('networkUrl'), onPressed: _network),
            ],
            bottom: TabBar(isScrollable: true, tabs: [
              Tab(text: L.t('continueWatching')),
              Tab(text: L.t('videos')),
              Tab(text: L.t('music')),
              Tab(text: L.t('folders')),
              Tab(text: L.t('favorites')),
              Tab(text: L.t('playlists')),
              Tab(text: L.t('albums')),
              Tab(text: L.t('artists')),
            ]),
          ),
          body: Column(children: [
            Padding(
              padding: const EdgeInsets.all(8),
              child: TextField(onChanged: (v) => setState(() => q = v.toLowerCase()), decoration: InputDecoration(hintText: L.t('search'), prefixIcon: const Icon(Icons.search_rounded))),
            ),
            if (!done) const LinearProgressIndicator(),
            Expanded(
              child: TabBarView(children: [
                _continue(),
                _list(videos, true),
                Column(children: [_playBar(audios), Expanded(child: _list(audios, false))]),
                _folders(),
                _favs(),
                const PlaylistsTab(),
                GroupTab(groups: _group(2), done: done, grid: true),
                GroupTab(groups: _group(1), done: done),
              ]),
            ),
          ]),
        ),
      );
}

class _FolderMedia extends StatelessWidget {
  final String title;
  final List<FItem> items;
  const _FolderMedia({required this.title, required this.items});
  @override
  Widget build(BuildContext context) {
    final list = [...items]..sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView.builder(
        itemCount: list.length,
        itemBuilder: (_, i) => ListTile(
          leading: TypeIcon(list[i].path, false),
          title: Text(list[i].name, maxLines: 1, overflow: TextOverflow.ellipsis),
          subtitle: Text('${FileOps.fmt(list[i].size)} • ${FileOps.dt(list[i].modified)}', style: const TextStyle(fontSize: 11)),
          onTap: () => Opener.open(context, list[i].path, siblings: list.map((e) => e.path).toList()),
        ),
      ),
    );
  }
}
