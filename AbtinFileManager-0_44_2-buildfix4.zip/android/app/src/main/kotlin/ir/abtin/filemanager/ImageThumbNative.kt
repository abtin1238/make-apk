package ir.abtin.filemanager

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.Executors

/**
 * Fast image thumbnails for the gallery / file lists.
 *  - sub-sampled decode (JPEG DCT scaling, so a 12 MP photo is never fully decoded),
 *  - centre-cropped square, EXIF rotation applied on the small bitmap,
 *  - small JPEG/PNG disk cache (key = path + size + mtime + pixel size), trimmed automatically,
 *  - 3 worker threads; the Dart side decides the order (newest visible first) and cancels off-screen requests.
 */
class ImageThumbNative(cacheRoot: File, messenger: BinaryMessenger) {
    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(3)
    private val dir = File(cacheRoot, "img_thumbs").also { it.mkdirs() }

    init {
        MethodChannel(messenger, "abtin/thumb").setMethodCallHandler { call, result ->
            when (call.method) {
                "image" -> {
                    val path = call.argument<String>("path")
                    val px = call.argument<Int>("px") ?: 256
                    if (path == null) {
                        result.success(null)
                    } else {
                        pool.execute {
                            val bytes = try { make(path, px.coerceIn(48, 768)) } catch (e: Throwable) { null }
                            ui.post { result.success(bytes) }
                        }
                    }
                }
                "video" -> {
                    val path = call.argument<String>("path")
                    val maxW = call.argument<Int>("maxWidth") ?: 256
                    val timeMs = (call.argument<Number>("timeMs") ?: 0).toLong()
                    val quality = call.argument<Int>("quality") ?: 60
                    if (path == null) {
                        result.success(null)
                    } else {
                        pool.execute {
                            val bytes = try { makeVideo(path, maxW.coerceIn(32, 1024), timeMs, quality.coerceIn(1, 100)) } catch (e: Throwable) { null }
                            ui.post { result.success(bytes) }
                        }
                    }
                }
                "clear" -> {
                    pool.execute { try { dir.listFiles()?.forEach { it.delete() } } catch (e: Throwable) {} }
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }
        pool.execute { try { trim() } catch (e: Throwable) {} }
    }

    private fun hash(s: String): String {
        val d = MessageDigest.getInstance("MD5").digest(s.toByteArray())
        val sb = StringBuilder()
        for (b in d) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    private fun matrixFor(o: Int): Matrix? {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return null
        }
        return m
    }

    private fun make(path: String, px: Int): ByteArray? {
        val f = File(path)
        if (!f.exists()) return null
        val cf = File(dir, hash("$path|${f.length()}|${f.lastModified()}|$px"))
        if (cf.exists() && cf.length() > 0) {
            try {
                val b = cf.readBytes()
                cf.setLastModified(System.currentTimeMillis())
                return b
            } catch (e: Throwable) {}
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val minSide = minOf(bounds.outWidth, bounds.outHeight)
        var sample = 1
        while (minSide / (sample * 2) >= px) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        var bmp: Bitmap = BitmapFactory.decodeFile(path, opts) ?: return null

        // centre-crop to a square (cheap, and keeps every cached file the same shape)
        val side = minOf(bmp.width, bmp.height)
        if (bmp.width != bmp.height) {
            val c = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            if (c !== bmp) bmp.recycle()
            bmp = c
        }
        if (bmp.width > px) {
            val s = Bitmap.createScaledBitmap(bmp, px, px, true)
            if (s !== bmp) bmp.recycle()
            bmp = s
        }
        // EXIF orientation (jpeg / heic / webp)
        try {
            val o = ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            val m = matrixFor(o)
            if (m != null) {
                val r = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (r !== bmp) bmp.recycle()
                bmp = r
            }
        } catch (e: Throwable) {}

        val out = ByteArrayOutputStream()
        if (bmp.hasAlpha()) bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        else bmp.compress(Bitmap.CompressFormat.JPEG, 82, out)
        bmp.recycle()
        val bytes = out.toByteArray()
        try { cf.writeBytes(bytes) } catch (e: Throwable) {}
        return bytes
    }

    /** Video frame at [timeMs] (closest sync frame), scaled to [maxW] wide, as JPEG. */
    private fun makeVideo(path: String, maxW: Int, timeMs: Long, quality: Int): ByteArray? {
        if (!File(path).exists()) return null
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(path)
            var bmp: Bitmap = r.getFrameAtTime(timeMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime(-1L) ?: return null
            if (bmp.width > maxW) {
                val h = (bmp.height.toLong() * maxW / bmp.width).toInt().coerceAtLeast(1)
                val sc = Bitmap.createScaledBitmap(bmp, maxW, h, true)
                if (sc !== bmp) bmp.recycle()
                bmp = sc
            }
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
            bmp.recycle()
            return out.toByteArray()
        } finally {
            try { r.release() } catch (e: Throwable) {}
        }
    }

    /** Keeps the disk cache under ~150 MB (deletes the least recently used files first). */
    private fun trim() {
        val files = dir.listFiles() ?: return
        var total = 0L
        for (f in files) total += f.length()
        if (total <= 150L * 1024 * 1024) return
        for (f in files.sortedBy { it.lastModified() }) {
            total -= f.length()
            f.delete()
            if (total <= 100L * 1024 * 1024) break
        }
    }
}
