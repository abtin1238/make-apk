package ir.abtin.gecko;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import androidx.annotation.Nullable;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Installed web apps. Two kinds, both pinned launcher shortcuts:
 * "pwa" = own window (PwaActivity, no browser UI); "shortcut" = plain shortcut that opens in the browser.
 * "real" = the site really is a PWA (web manifest + service worker); otherwise it is only a web shortcut shown in its own window.
 * The registry (files/webapps.json) keeps what Android's ShortcutManager does not: kind, flags, original URL and icon.
 */
final class WebApps {
    private static final String TAG = "AbtinWebApps";
    private final Engine e;
    private final File file, iconDir;

    WebApps(Engine e) {
        this.e = e;
        this.file = new File(e.app.getFilesDir(), "webapps.json");
        this.iconDir = new File(e.app.getFilesDir(), "webapp_icons");
    }

    // ---------------------------------------------------------------- storage
    private synchronized JSONArray load() {
        try {
            if (!file.exists()) return new JSONArray();
            return new JSONArray(new String(java.nio.file.Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8));
        } catch (Throwable t) { return new JSONArray(); }
    }

    private synchronized void save(JSONArray a) {
        try {
            final File tmp = new File(file.getPath() + ".tmp");
            try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(a.toString().getBytes(StandardCharsets.UTF_8)); }
            if (!tmp.renameTo(file)) { file.delete(); tmp.renameTo(file); }
        } catch (Throwable t) { Log.w(TAG, "save", t); }
    }

    static String origin(String url) {
        try {
            final Uri u = Uri.parse(url);
            final String sc = u.getScheme() == null ? "https" : u.getScheme().toLowerCase(Locale.ROOT);
            final String h = u.getHost() == null ? "" : u.getHost().toLowerCase(Locale.ROOT);
            return sc + "://" + h + (u.getPort() > 0 ? ":" + u.getPort() : "");
        } catch (Throwable t) { return url; }
    }

    private static String idFor(boolean pwa, String url) {
        return pwa ? "abtin_pwa_" + Integer.toHexString(origin(url).hashCode()) : "abtin_" + Integer.toHexString(url.hashCode());
    }

    private File iconFile(String id) { return new File(iconDir, id.replaceAll("[^A-Za-z0-9_]", "_") + ".png"); }

    private void saveIcon(String id, Bitmap b) {
        try {
            iconDir.mkdirs();
            final ByteArrayOutputStream bo = new ByteArrayOutputStream();
            Bitmap.createScaledBitmap(b, 128, 128, true).compress(Bitmap.CompressFormat.PNG, 100, bo);
            try (FileOutputStream o = new FileOutputStream(iconFile(id))) { o.write(bo.toByteArray()); }
        } catch (Throwable t) { Log.w(TAG, "icon", t); }
    }

    @Nullable private ShortcutManager sm() {
        try {
            if (Build.VERSION.SDK_INT < 26) return null;
            return e.app.getSystemService(ShortcutManager.class);
        } catch (Throwable t) { return null; }
    }

    // ---------------------------------------------------------------- intents
    private Intent intentFor(String url, String title, boolean pwa) {
        final Intent launch = e.app.getPackageManager().getLaunchIntentForPackage(e.app.getPackageName());
        final Intent it = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        if (pwa) {
            // Own activity in its own task (own entry in Recents), no browser tabs around it. Cookies / login are the browser's own profile.
            it.setClass(e.app, PwaActivity.class);
            it.putExtra("abtin_title", title);
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
        } else {
            if (launch != null && launch.getComponent() != null) it.setComponent(launch.getComponent());
            else it.setPackage(e.app.getPackageName());
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        }
        return it;
    }

    // ---------------------------------------------------------------- reconcile with what is really pinned
    private JSONArray reconcile(JSONArray reg) {
        final ShortcutManager sm = sm();
        if (sm == null || Build.VERSION.SDK_INT < 26) return reg;
        try {
            final Map<String, ShortcutInfo> pinned = new HashMap<>();
            for (ShortcutInfo si : sm.getPinnedShortcuts()) if (si.isEnabled() && si.getId().startsWith("abtin_")) pinned.put(si.getId(), si);
            final long now = System.currentTimeMillis();
            final JSONArray out = new JSONArray();
            final Set<String> have = new HashSet<>();
            boolean changed = false;
            for (int i = 0; i < reg.length(); i++) {
                final JSONObject o = reg.getJSONObject(i);
                final String id = o.optString("id");
                // A pin the user has not confirmed yet is not in the list: keep new entries for two minutes.
                if (!pinned.containsKey(id) && now - o.optLong("created", 0) > 120_000L) {
                    iconFile(id).delete();
                    changed = true;
                    continue;
                }
                have.add(id);
                out.put(o);
            }
            // Shortcuts pinned by older versions (before the registry existed).
            for (Map.Entry<String, ShortcutInfo> en : pinned.entrySet()) {
                if (have.contains(en.getKey())) continue;
                final ShortcutInfo si = en.getValue();
                final Intent it = si.getIntent();
                if (it == null || it.getData() == null) continue;
                final JSONObject o = new JSONObject();
                o.put("id", en.getKey());
                o.put("title", si.getLongLabel() != null ? si.getLongLabel().toString() : String.valueOf(si.getShortLabel()));
                o.put("url", it.getDataString());
                o.put("kind", en.getKey().startsWith("abtin_pwa_") ? "pwa" : "shortcut");
                o.put("real", false); o.put("manifest", false); o.put("sw", false); o.put("created", 0);
                out.put(o);
                changed = true;
            }
            if (changed) save(out);
            return out;
        } catch (Throwable t) { Log.w(TAG, "reconcile", t); return reg; }
    }

    // ---------------------------------------------------------------- API used by Engine
    /** Result: ok | exists | unsupported | error. A site already installed (same origin for web apps) is not installed twice; only its name / icon are refreshed. */
    synchronized String install(@Nullable String url, @Nullable String title0, @Nullable byte[] icon, boolean pwa, boolean real, boolean manifest, boolean sw) {
        try {
            if (url == null || url.isEmpty()) return "error";
            final ShortcutManager sm = sm();
            if (sm == null || !sm.isRequestPinShortcutSupported()) return "unsupported";
            final String title = title0 == null || title0.trim().isEmpty() ? Engine.hostOf(url) : title0.trim();
            final JSONArray reg = reconcile(load());
            final String kind = pwa ? "pwa" : "shortcut";
            for (int i = 0; i < reg.length(); i++) {
                final JSONObject o = reg.getJSONObject(i);
                final boolean same = kind.equals(o.optString("kind")) && (pwa ? origin(o.optString("url")).equals(origin(url)) : o.optString("url").equals(url));
                if (!same) continue;
                final String id = o.optString("id");
                // Already installed: refresh the label / icon of the pinned shortcut instead of adding a second one.
                final Bitmap bmp = shortcutIcon(icon, title);
                o.put("title", title); o.put("real", real); o.put("manifest", manifest); o.put("sw", sw);
                save(reg);
                saveIcon(id, bmp);
                try {
                    sm.updateShortcuts(Collections.singletonList(new ShortcutInfo.Builder(e.app, id)
                            .setShortLabel(title.length() > 24 ? title.substring(0, 24) : title).setLongLabel(title)
                            .setIcon(Icon.createWithBitmap(bmp)).build()));
                } catch (Throwable ignored) { }
                return "exists";
            }
            final String id = idFor(pwa, url);
            final Bitmap bmp = shortcutIcon(icon, title);
            final ShortcutInfo info = new ShortcutInfo.Builder(e.app, id)
                    .setShortLabel(title.length() > 24 ? title.substring(0, 24) : title)
                    .setLongLabel(title)
                    .setIcon(Icon.createWithBitmap(bmp))
                    .setIntent(intentFor(url, title, pwa))
                    .build();
            if (!sm.requestPinShortcut(info, null)) return "error";
            final JSONObject o = new JSONObject();
            o.put("id", id); o.put("title", title); o.put("url", url); o.put("kind", kind);
            o.put("real", real); o.put("manifest", manifest); o.put("sw", sw); o.put("created", System.currentTimeMillis());
            reg.put(o);
            save(reg);
            saveIcon(id, bmp);
            return "ok";
        } catch (Throwable t) { Log.e(TAG, "install", t); return "error"; }
    }

    private Bitmap shortcutIcon(@Nullable byte[] icon, String title) { return e.shortcutIcon(icon, title); }

    synchronized List<Map<String, Object>> list() {
        final List<Map<String, Object>> out = new ArrayList<>();
        try {
            final JSONArray reg = reconcile(load());
            for (int i = 0; i < reg.length(); i++) {
                final JSONObject o = reg.getJSONObject(i);
                final Map<String, Object> m = new HashMap<>();
                final String id = o.optString("id");
                m.put("id", id);
                m.put("title", o.optString("title"));
                m.put("url", o.optString("url"));
                m.put("host", Engine.hostOf(o.optString("url")));
                m.put("kind", o.optString("kind", "shortcut"));
                m.put("real", o.optBoolean("real", false));
                m.put("manifest", o.optBoolean("manifest", false));
                m.put("sw", o.optBoolean("sw", false));
                try {
                    final File f = iconFile(id);
                    if (f.exists()) m.put("icon", java.nio.file.Files.readAllBytes(f.toPath()));
                } catch (Throwable ignored) { }
                out.add(m);
            }
        } catch (Throwable t) { Log.w(TAG, "list", t); }
        return out;
    }

    synchronized boolean remove(@Nullable String id) {
        if (id == null) return false;
        try {
            final JSONArray reg = load();
            final JSONArray out = new JSONArray();
            for (int i = 0; i < reg.length(); i++) if (!id.equals(reg.getJSONObject(i).optString("id"))) out.put(reg.get(i));
            save(out);
            iconFile(id).delete();
            // Android cannot delete a pinned icon from the home screen by itself: it is disabled (greyed, "no longer available").
            final ShortcutManager sm = sm();
            if (sm != null) { try { sm.disableShortcuts(Collections.singletonList(id), "Removed"); } catch (Throwable ignored) { } }
            return true;
        } catch (Throwable t) { return false; }
    }

    synchronized boolean edit(@Nullable String id, @Nullable String title0) {
        if (id == null || title0 == null || title0.trim().isEmpty()) return false;
        final String title = title0.trim();
        try {
            final JSONArray reg = load();
            boolean found = false;
            for (int i = 0; i < reg.length(); i++) {
                final JSONObject o = reg.getJSONObject(i);
                if (id.equals(o.optString("id"))) { o.put("title", title); found = true; }
            }
            if (!found) return false;
            save(reg);
            final ShortcutManager sm = sm();
            if (sm != null) {
                try {
                    sm.updateShortcuts(Collections.singletonList(new ShortcutInfo.Builder(e.app, id)
                            .setShortLabel(title.length() > 24 ? title.substring(0, 24) : title).setLongLabel(title).build()));
                } catch (Throwable ignored) { }
            }
            return true;
        } catch (Throwable t) { return false; }
    }

    synchronized boolean open(@Nullable String id) {
        if (id == null) return false;
        try {
            final JSONArray reg = load();
            for (int i = 0; i < reg.length(); i++) {
                final JSONObject o = reg.getJSONObject(i);
                if (!id.equals(o.optString("id"))) continue;
                final Intent it = intentFor(o.optString("url"), o.optString("title"), "pwa".equals(o.optString("kind")));
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                final Context c = e.activity != null ? e.activity : e.app;
                c.startActivity(it);
                return true;
            }
        } catch (Throwable t) { Log.w(TAG, "open", t); }
        return false;
    }
}
