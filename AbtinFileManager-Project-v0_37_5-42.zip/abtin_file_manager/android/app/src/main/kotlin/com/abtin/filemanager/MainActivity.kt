package com.abtin.filemanager

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.pm.PackageManager
import java.security.MessageDigest
import android.graphics.Bitmap
import android.graphics.Canvas
import java.io.ByteArrayOutputStream
import android.net.Uri
import android.provider.DocumentsContract
import android.webkit.MimeTypeMap
import java.io.IOException
import java.io.OutputStream
import android.content.res.Configuration
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.Settings
import android.util.Rational
import android.view.WindowManager
import com.ryanheise.audioservice.AudioServiceActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileOutputStream

class MainActivity : AudioServiceActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private var sys: MethodChannel? = null
    private var frameShown = false
    private var watchdogOn = false

    override fun onFlutterUiDisplayed() {
        super.onFlutterUiDisplayed()
        frameShown = true
    }

    override fun onResume() {
        super.onResume()
        if (!frameShown && !watchdogOn) {
            watchdogOn = true
            ui.postDelayed({
                if (!frameShown && !isFinishing && !isDestroyed) {
                    val info = "Flutter first frame was not drawn after 12 s.\n" +
                        "Model: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
                        "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
                        "ABIs: ${Build.SUPPORTED_ABIS.joinToString()}"
                    try {
                        android.app.AlertDialog.Builder(this)
                            .setTitle("Abtin File Manager")
                            .setMessage(info)
                            .setPositiveButton("OK", null)
                            .show()
                    } catch (e: Exception) { }
                }
            }, 12000)
        }
    }

    // ---- Storage Access Framework (SD card) ----
    private val safReq = 4711
    private val extDocs = "com.android.externalstorage.documents"
    private val safPrefs by lazy { getSharedPreferences("saf", MODE_PRIVATE) }
    private var safPending: MethodChannel.Result? = null
    private var safPendingUuid: String? = null
    private val safOut = HashMap<Int, OutputStream>()
    private var safNext = 1

    private fun parts(path: String) = path.split("/").filter { it.isNotEmpty() }
    private fun uuidOf(path: String): String {
        val p = parts(path)
        if (p.size >= 2 && p[0] == "storage" && p[1] != "emulated" && p[1] != "self") return p[1]
        throw IllegalArgumentException("Not a removable volume: $path")
    }
    private fun relOf(path: String) = parts(path).drop(2).joinToString("/")
    private fun treeOf(uuid: String): Uri? = safPrefs.getString(uuid, null)?.let { Uri.parse(it) }
    private fun hasPerm(tree: Uri) = contentResolver.persistedUriPermissions.any { it.uri == tree && it.isWritePermission }
    private fun docUri(path: String): Uri {
        val uuid = uuidOf(path)
        val tree = treeOf(uuid) ?: throw IllegalStateException("No SD card access")
        val rel = relOf(path)
        return DocumentsContract.buildDocumentUriUsingTree(tree, "$uuid:$rel")
    }
    private fun docExists(uri: Uri): Boolean = try {
        contentResolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null)?.use { it.count > 0 } ?: false
    } catch (e: Exception) { false }

    private fun safMkdirs(path: String): Uri {
        val uuid = uuidOf(path)
        var cur = "/storage/$uuid"
        var uri = docUri(cur)
        for (name in parts(relOf(path))) {
            cur += "/$name"
            val u = docUri(cur)
            uri = if (docExists(u)) u
            else DocumentsContract.createDocument(contentResolver, uri, DocumentsContract.Document.MIME_TYPE_DIR, name)
                ?: throw IOException("Could not create folder $name")
        }
        return uri
    }

    private fun safCreate(path: String): Uri {
        val f = File(path)
        val existing = docUri(path)
        if (docExists(existing)) return existing
        val parent = safMkdirs(f.parent!!)
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
        return DocumentsContract.createDocument(contentResolver, parent, mime, f.name)
            ?: throw IOException("Could not create ${f.name}")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == safReq) {
            val r = safPending
            val uuid = safPendingUuid
            safPending = null
            var ok = false
            val uri = data?.data
            if (resultCode == RESULT_OK && uri != null && uuid != null) {
                try {
                    if (DocumentsContract.getTreeDocumentId(uri).equals("$uuid:", ignoreCase = true)) {
                        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                        safPrefs.edit().putString(uuid, uri.toString()).apply()
                        ok = true
                    }
                } catch (e: Exception) { ok = false }
            }
            r?.success(ok)
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }
    private var pipAuto = false
    private var pipW = 16
    private var pipH = 9

    private fun enterPip(w: Int, h: Int): Boolean {
        if (Build.VERSION.SDK_INT < 26) return false
        return try {
            enterPictureInPictureMode(PictureInPictureParams.Builder().setAspectRatio(Rational(w.coerceAtLeast(1), h.coerceAtLeast(1))).build())
            true
        } catch (e: Exception) { false }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (pipAuto) enterPip(pipW, pipH)
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        sys?.invokeMethod("pipChanged", isInPictureInPictureMode)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val messenger = flutterEngine.dartExecutor.binaryMessenger
        NearbyNative(this, messenger)
        AudioVisualizerNative(this, messenger).register()

        sys = MethodChannel(messenger, "abtin/sys")
        sys!!.setMethodCallHandler { call, result ->
            when (call.method) {
                "storage" -> try {
                    val st = StatFs(call.argument<String>("path")!!)
                    result.success(listOf(st.totalBytes, st.availableBytes))
                } catch (e: Exception) {
                    result.error("ERR", e.message, null)
                }
                "brightness" -> {
                    val b = window.attributes.screenBrightness
                    if (b >= 0) result.success(b.toDouble()) else {
                        val s = try { Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) } catch (e: Exception) { 128 }
                        result.success(s / 255.0)
                    }
                }
                "setBrightness" -> {
                    val v = call.argument<Double>("v") ?: -1.0
                    runOnUiThread {
                        val lp = window.attributes
                        lp.screenBrightness = if (v < 0) WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE else v.toFloat().coerceIn(0.01f, 1f)
                        window.attributes = lp
                    }
                    result.success(true)
                }
                "sysVolume" -> {
                    val am = getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
                    val mx = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                    result.success(am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC).toDouble() / mx)
                }
                "setSysVolume" -> {
                    val v = (call.argument<Double>("v") ?: 0.0).coerceIn(0.0, 1.0)
                    val am = getSystemService(android.content.Context.AUDIO_SERVICE) as android.media.AudioManager
                    val mx = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                    am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, Math.round(v * mx).toInt(), 0)
                    result.success(true)
                }
                "keepOn" -> {
                    val on = call.argument<Boolean>("on") ?: false
                    runOnUiThread {
                        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                    }
                    result.success(true)
                }
                "pip" -> result.success(enterPip(call.argument<Int>("w") ?: 16, call.argument<Int>("h") ?: 9))
                "pipAuto" -> {
                    pipAuto = call.argument<Boolean>("on") ?: false
                    pipW = call.argument<Int>("w") ?: 16
                    pipH = call.argument<Int>("h") ?: 9
                    result.success(true)
                }
                "scan" -> {
                    MediaScannerConnection.scanFile(this, arrayOf(call.argument<String>("path")), null, null)
                    result.success(true)
                }
                "apkIcon" -> {
                    val apk = call.argument<String>("path")!!
                    Thread {
                        var bytes: ByteArray? = null
                        try {
                            val pm = packageManager
                            val ai = pm.getPackageArchiveInfo(apk, 0)?.applicationInfo
                            if (ai != null) {
                                ai.sourceDir = apk
                                ai.publicSourceDir = apk
                                val d = ai.loadIcon(pm)
                                val size = 128
                                val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
                                d.setBounds(0, 0, size, size)
                                d.draw(Canvas(bmp))
                                val out = ByteArrayOutputStream()
                                bmp.compress(Bitmap.CompressFormat.PNG, 90, out)
                                bytes = out.toByteArray()
                            }
                        } catch (e: Throwable) { bytes = null }
                        ui.post { result.success(bytes) }
                    }.start()
                }
                "canInstall" -> result.success(Build.VERSION.SDK_INT < 26 || packageManager.canRequestPackageInstalls())
                "installSettings" -> {
                    try {
                        val i = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } catch (e: Exception) {}
                    result.success(true)
                }
                "uninstall" -> {
                    try {
                        val i = Intent(Intent.ACTION_DELETE, Uri.parse("package:" + call.argument<String>("pkg")))
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } catch (e: Exception) {}
                    result.success(true)
                }
                "apkInfo" -> {
                    val apk = call.argument<String>("path")!!
                    Thread {
                        var out: Map<String, Any?>? = null
                        try { out = apkInfo(apk) } catch (e: Throwable) { out = null }
                        ui.post { result.success(out) }
                    }.start()
                }
                "scanMany" -> {
                    val l = call.argument<List<String>>("paths") ?: emptyList()
                    if (l.isNotEmpty()) MediaScannerConnection.scanFile(this, l.toTypedArray(), null, null)
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        }

        MethodChannel(messenger, "abtin/saf").setMethodCallHandler { call, result ->
            when (call.method) {
                "has" -> {
                    val t = treeOf(call.argument<String>("uuid")!!)
                    result.success(t != null && hasPerm(t))
                }
                "request" -> {
                    val uuid = call.argument<String>("uuid")!!
                    val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    if (Build.VERSION.SDK_INT >= 26) i.putExtra(DocumentsContract.EXTRA_INITIAL_URI, DocumentsContract.buildTreeDocumentUri(extDocs, "$uuid:"))
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    safPending?.success(false)
                    safPending = result
                    safPendingUuid = uuid
                    startActivityForResult(i, safReq)
                }
                "revoke" -> {
                    val uuid = call.argument<String>("uuid")!!
                    treeOf(uuid)?.let {
                        try { contentResolver.releasePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (e: Exception) {}
                    }
                    safPrefs.edit().remove(uuid).apply()
                    result.success(true)
                }
                else -> Thread {
                    try {
                        val path = call.argument<String>("path")
                        val r: Any? = when (call.method) {
                            "mkdirs" -> { safMkdirs(path!!); true }
                            "create" -> { safCreate(path!!); true }
                            "delete" -> {
                                if (!DocumentsContract.deleteDocument(contentResolver, docUri(path!!))) throw IOException("Delete failed")
                                true
                            }
                            "rename" -> {
                                DocumentsContract.renameDocument(contentResolver, docUri(path!!), call.argument<String>("name")!!)
                                    ?: throw IOException("Rename failed")
                                true
                            }
                            "move" -> {
                                val f = File(path!!)
                                val moved = DocumentsContract.moveDocument(contentResolver, docUri(path), docUri(f.parent!!), safMkdirs(call.argument<String>("dst")!!))
                                    ?: throw IOException("Move failed")
                                val newName = call.argument<String>("name")!!
                                if (newName != f.name) {
                                    DocumentsContract.renameDocument(contentResolver, moved, newName) ?: throw IOException("Rename failed")
                                }
                                true
                            }
                            "open" -> {
                                val os = contentResolver.openOutputStream(safCreate(path!!), "wt") ?: throw IOException("Cannot open for writing")
                                val h = synchronized(safOut) { safNext++ }
                                safOut[h] = os
                                h
                            }
                            "write" -> {
                                val os = safOut[call.argument<Int>("h")!!] ?: throw IOException("Bad handle")
                                os.write(call.argument<ByteArray>("data")!!)
                                true
                            }
                            "close" -> {
                                safOut.remove(call.argument<Int>("h")!!)?.close()
                                true
                            }
                            else -> throw UnsupportedOperationException(call.method)
                        }
                        ui.post { result.success(r) }
                    } catch (e: Throwable) {
                        ui.post { result.error("ERR", e.message ?: e.toString(), null) }
                    }
                }.start()
            }
        }

        PdfNative.register(this, messenger, ui)
        SecurityNative.register(this, messenger, ui)
        FgsNative.register(this, messenger)
        WidgetNative.register(applicationContext, messenger)

        ArchiveNative.register(messenger, ui)
    }

    @Suppress("DEPRECATION")
    private fun apkInfo(apk: String): Map<String, Any?>? {
        val pm = packageManager
        val sigFlag = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val flags = PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES or PackageManager.GET_SERVICES or
            PackageManager.GET_RECEIVERS or PackageManager.GET_PROVIDERS or sigFlag
        val pi = pm.getPackageArchiveInfo(apk, flags) ?: return null
        val ai = pi.applicationInfo ?: return null
        ai.sourceDir = apk
        ai.publicSourceDir = apk
        val code = if (Build.VERSION.SDK_INT >= 28) pi.longVersionCode else pi.versionCode.toLong()
        val sigs = ArrayList<String>()
        try {
            val raw = if (Build.VERSION.SDK_INT >= 28) pi.signingInfo?.apkContentsSigners else pi.signatures
            raw?.forEach { s ->
                val d = MessageDigest.getInstance("SHA-256").digest(s.toByteArray())
                sigs.add(d.joinToString(":") { "%02X".format(it) })
            }
        } catch (e: Throwable) {}
        var instCode: Long? = null
        var instName: String? = null
        try {
            val ip = pm.getPackageInfo(pi.packageName, 0)
            instCode = if (Build.VERSION.SDK_INT >= 28) ip.longVersionCode else ip.versionCode.toLong()
            instName = ip.versionName
        } catch (e: Exception) {}
        return mapOf(
            "label" to ai.loadLabel(pm).toString(),
            "package" to pi.packageName,
            "versionName" to (pi.versionName ?: ""),
            "versionCode" to code,
            "minSdk" to ai.minSdkVersion,
            "targetSdk" to ai.targetSdkVersion,
            "permissions" to (pi.requestedPermissions?.toList() ?: emptyList<String>()),
            "activities" to (pi.activities?.size ?: 0),
            "services" to (pi.services?.size ?: 0),
            "receivers" to (pi.receivers?.size ?: 0),
            "providers" to (pi.providers?.size ?: 0),
            "signatures" to sigs,
            "installedCode" to instCode,
            "installedName" to instName,
        )
    }
}
