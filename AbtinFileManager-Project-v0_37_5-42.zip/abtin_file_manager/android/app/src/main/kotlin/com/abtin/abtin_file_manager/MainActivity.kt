package com.abtin.abtin_file_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
