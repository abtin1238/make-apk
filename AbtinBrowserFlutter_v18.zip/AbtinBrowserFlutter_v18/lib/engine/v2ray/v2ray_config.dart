import 'dart:convert';
import 'v2ray_parser.dart';

class V2Options {
  const V2Options({this.bypassIran = true, this.blockAds = false, this.blockUdp443 = true, this.bypassLan = true, this.ipv6 = true, this.mtu = 1500, this.vpnDns = '8.8.8.8,8.8.4.4'});
  final bool bypassIran, blockAds, blockUdp443, bypassLan, ipv6;
  final int mtu;
  final String vpnDns;
}

class V2Build {
  V2Build(this.json, this.socksPort);
  final String json;
  final int socksPort;
}

/// ProfileItem -> Xray JSON, following PattNG's CoreOutboundBuilder / CoreConfigManager (flat outbound settings,
/// cipherSuites, unsafe fingerprint, finalMask, dialMode, Reality, Hysteria2, XHTTP, ...).
class V2Config {
  static const int socksPort = 10808;
  static const String _ua =
      'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.6478.122 Mobile Safari/537.36';

  static String? _nb(String? s) => (s == null || s.trim().isEmpty) ? null : s;

  static bool _isDomain(String? s) {
    if (s == null || s.isEmpty) return false;
    return RegExp(r'^(?:[A-Za-z0-9](?:[A-Za-z0-9\-]{0,61}[A-Za-z0-9])?\.)+[A-Za-z][A-Za-z0-9\-]*$').hasMatch(s);
  }

  static void _put(Map<String, dynamic> m, String k, Object? v) {
    if (v != null) m[k] = v;
  }

  static List<String> _csv(String? s) => (s ?? '').split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();

  static dynamic _json(String? s) {
    if (_nb(s) == null) return null;
    try {
      return jsonDecode(s!);
    } catch (_) {
      return null;
    }
  }

  /// Transport part of the stream settings; returns the SNI the transport implies.
  static String? _transport(Map<String, dynamic> ss, V2Item p) {
    final net = p.network.isEmpty ? 'tcp' : p.network;
    ss['network'] = net;
    String? sni;
    final host = p.host;
    final path = p.path;
    switch (net) {
      case 'tcp':
        final tcp = <String, dynamic>{};
        if (p.headerType == 'http') {
          final hosts = _csv(host);
          final paths = _csv(path);
          tcp['header'] = {
            'type': 'http',
            'request': {
              'path': paths.isEmpty ? ['/'] : paths,
              'headers': {
                if (hosts.isNotEmpty) 'Host': hosts,
                'User-Agent': [_ua],
                'Accept-Encoding': ['gzip, deflate'],
                'Connection': ['keep-alive'],
                'Pragma': 'no-cache',
              },
              'version': '1.1',
              'method': 'GET',
            },
          };
          sni = hosts.isEmpty ? null : hosts.first;
        } else {
          tcp['header'] = {'type': 'none'};
          sni = host;
        }
        ss['tcpSettings'] = tcp;
      case 'kcp':
        ss['kcpSettings'] = {
          'mtu': p.kcpMtu ?? 1350,
          'tti': p.kcpTti ?? 50,
          'uplinkCapacity': 12,
          'downlinkCapacity': 100,
          'congestion': false,
          'readBufferSize': 1,
          'writeBufferSize': 1,
        };
        final masks = <Map<String, dynamic>>[];
        final ht = p.headerType;
        if (ht != null && ht.isNotEmpty && ht != 'none') {
          final hdr = ht == 'wechat-video' ? 'wechat' : ht;
          masks.add({
            'type': 'mkcp-legacy',
            'settings': {'header': hdr, if (ht == 'dns' && host != null && host.isNotEmpty) 'value': host},
          });
        }
        if (p.seed == null || p.seed!.isEmpty) {
          masks.add({'type': 'mkcp-legacy'});
        } else {
          masks.add({'type': 'mkcp-legacy', 'settings': {'value': p.seed}});
        }
        ss['finalmask'] = {'udp': masks.reversed.toList()};
      case 'ws':
        ss['wsSettings'] = {'path': path ?? '/', 'host': host ?? ''};
        sni = host;
      case 'httpupgrade':
        ss['httpupgradeSettings'] = {'path': path ?? '/', 'host': host ?? ''};
        sni = host;
      case 'xhttp':
        final x = <String, dynamic>{'path': path ?? '/', 'host': host ?? ''};
        _put(x, 'mode', p.xhttpMode);
        _put(x, 'extra', _json(p.xhttpExtra));
        ss['xhttpSettings'] = x;
        sni = host;
      case 'h2' || 'http':
        ss['network'] = 'h2';
        final hosts = _csv(host);
        ss['httpSettings'] = {'host': hosts, 'path': path ?? '/'};
        sni = hosts.isEmpty ? null : hosts.first;
      case 'grpc':
        ss['grpcSettings'] = {
          'serviceName': p.serviceName ?? '',
          'authority': p.authority ?? '',
          'multiMode': p.mode == 'multi',
          'idle_timeout': 60,
          'health_check_timeout': 20,
        };
        sni = p.authority;
      case 'hysteria':
        ss['hysteriaSettings'] = {'version': 2, 'auth': p.password};
        final fm = <String, dynamic>{};
        if (p.portHopping != null && p.portHopping!.isNotEmpty) {
          fm['quicParams'] = {
            'udpHop': {'ports': p.portHopping, 'interval': '30'},
          };
        }
        if (p.obfsPassword != null && p.obfsPassword!.isNotEmpty) {
          fm['udp'] = [
            {'type': 'salamander', 'settings': {'password': p.obfsPassword}},
          ];
        }
        ss['finalmask'] = fm;
    }
    final parsed = _json(p.finalMask);
    if (parsed != null) ss['finalmask'] = parsed;
    return sni;
  }

  static void _tls(Map<String, dynamic> ss, V2Item p, String? sniExt) {
    final sec = p.security ?? '';
    if (sec.isEmpty) return;
    final allowInsecure = p.insecure && (p.pinnedCA256 == null || p.pinnedCA256!.isEmpty);
    String? sni;
    if (p.sni == null || p.sni!.isEmpty) {
      if (_nb(sniExt) != null && _isDomain(sniExt)) {
        sni = sniExt;
      } else if (_isDomain(p.server)) {
        sni = p.server;
      } else {
        sni = sniExt;
      }
    } else {
      sni = p.sni;
    }
    ss['security'] = sec;
    final t = <String, dynamic>{'allowInsecure': allowInsecure};
    _put(t, 'serverName', _nb(sni));
    _put(t, 'fingerprint', _nb(p.fingerPrint));
    final alpn = _csv(p.alpn);
    if (alpn.isNotEmpty) t['alpn'] = alpn;
    _put(t, 'cipherSuites', _nb(p.cipherSuites));
    _put(t, 'echConfigList', _nb(p.echConfigList));
    _put(t, 'verifyPeerCertByName', _nb(p.verifyPeerCertByName));
    _put(t, 'pinnedPeerCertSha256', _nb(p.pinnedCA256));
    _put(t, 'publicKey', _nb(p.publicKey));
    _put(t, 'shortId', _nb(p.shortId));
    _put(t, 'spiderX', _nb(p.spiderX));
    _put(t, 'mldsa65Verify', _nb(p.mldsa65Verify));
    if (sec == 'tls') {
      ss['tlsSettings'] = t;
    } else if (sec == 'reality') {
      ss['realitySettings'] = t;
    }
  }

  /// The outbound of a profile, tagged "proxy"; null when the type needs something this build does not carry.
  static Map<String, dynamic>? outbound(V2Item p) {
    final s = <String, dynamic>{};
    String proto;
    switch (p.type) {
      case 'vmess':
        proto = 'vmess';
        s..['address'] = p.server..['port'] = p.port..['id'] = p.password..['security'] = p.method.isEmpty ? 'auto' : p.method;
      case 'vless':
        proto = 'vless';
        s..['address'] = p.server..['port'] = p.port..['id'] = p.password..['encryption'] = p.method.isEmpty ? 'none' : p.method;
        _put(s, 'flow', _nb(p.flow));
      case 'trojan':
        proto = 'trojan';
        s..['address'] = p.server..['port'] = p.port..['password'] = p.password;
        _put(s, 'flow', _nb(p.flow));
      case 'shadowsocks':
        proto = 'shadowsocks';
        s..['address'] = p.server..['port'] = p.port..['password'] = p.password..['method'] = p.method;
      case 'socks':
        proto = 'socks';
        s..['address'] = p.server..['port'] = p.port;
        if (p.username != null && p.username!.isNotEmpty) {
          s['user'] = p.username;
          s['pass'] = p.password;
        }
      case 'hysteria2':
        proto = 'hysteria';
        p.network = 'hysteria';
        p.alpn = 'h3';
        s..['address'] = p.server..['port'] = p.port..['version'] = 2;
      default:
        return null;
    }
    final ss = <String, dynamic>{};
    if (p.type == 'socks') {
      ss['network'] = 'tcp';
    } else {
      final sni = _transport(ss, p);
      _tls(ss, p, sni);
    }
    final dm = _nb(p.dialMode);
    if (dm != null) ss['sockopt'] = {'dialMode': dm};
    return {
      'tag': 'proxy',
      'protocol': proto,
      'settings': s,
      'streamSettings': ss,
      'mux': {'enabled': false, 'concurrency': -1},
    };
  }

  static Map<String, dynamic> _sniffing() => {
        'enabled': true,
        'destOverride': ['http', 'tls', 'quic'],
        'routeOnly': false,
      };

  static Map<String, dynamic> _tunInbound(int mtu) => {
        'tag': 'tun',
        'protocol': 'tun',
        'settings': {'name': 'xray0', 'MTU': mtu, 'userLevel': 8},
        'sniffing': _sniffing(),
      };

  static Map<String, dynamic> _socksInbound() => {
        'tag': 'socks',
        'port': socksPort,
        'listen': '127.0.0.1',
        'protocol': 'socks',
        'settings': {'auth': 'noauth', 'udp': true},
        'sniffing': _sniffing(),
      };

  static const Map<String, dynamic> _policy = {
    'levels': {
      '0': {'uplinkOnly': 0, 'downlinkOnly': 0},
      '8': {'connIdle': 300, 'uplinkOnly': 1, 'downlinkOnly': 1},
      '12': {'connIdle': 12, 'uplinkOnly': 0, 'downlinkOnly': 0},
    },
    'system': {'statsOutboundUplink': true, 'statsOutboundDownlink': true},
  };

  /// Full config of a share link for the system-wide tunnel (Xray's own TUN inbound + local SOCKS inbound for the browser).
  static V2Build? build(String entry, V2Options o) {
    if (entry.trimLeft().startsWith('{')) return _custom(entry, o);
    final item = V2Parser.parse(entry);
    if (item == null) return null;
    final proxy = outbound(item);
    if (proxy == null) return null;
    final rules = <Map<String, dynamic>>[
      {'type': 'field', 'inboundTag': ['dns-module'], 'outboundTag': 'proxy'},
      if (o.bypassIran) {'type': 'field', 'inboundTag': ['domestic-dns'], 'outboundTag': 'direct'},
      if (o.blockUdp443) {'type': 'field', 'network': 'udp', 'port': '443', 'outboundTag': 'block'},
      if (o.blockAds) {'type': 'field', 'domain': ['geosite:category-ads-all'], 'outboundTag': 'block'},
      {'type': 'field', 'ip': ['geoip:private'], 'outboundTag': 'direct'},
      {'type': 'field', 'domain': ['geosite:private'], 'outboundTag': 'direct'},
      if (o.bypassIran) {'type': 'field', 'domain': ['domain:ir', 'geosite:category-ir'], 'outboundTag': 'direct'},
      if (o.bypassIran) {'type': 'field', 'ip': ['geoip:ir'], 'outboundTag': 'direct'},
    ];
    final cfg = <String, dynamic>{
      'stats': {},
      'log': {'loglevel': 'warning'},
      'policy': _policy,
      'inbounds': [_socksInbound(), _tunInbound(o.mtu)],
      'outbounds': [
        proxy,
        {'protocol': 'freedom', 'tag': 'direct'},
        {'protocol': 'blackhole', 'tag': 'block'},
      ],
      'routing': {'domainStrategy': 'AsIs', 'rules': rules},
      'dns': {
        'servers': [
          'https://8.8.8.8/dns-query',
          if (o.bypassIran) {'address': 'localhost', 'domains': ['domain:ir', 'geosite:category-ir'], 'skipFallback': true, 'tag': 'domestic-dns'},
        ],
        'hosts': {
          'dns.google': ['8.8.8.8', '8.8.4.4'],
          'cloudflare-dns.com': ['1.1.1.1', '1.0.0.1'],
        },
        'tag': 'dns-module',
      },
    };
    return V2Build(jsonEncode(cfg), socksPort);
  }

  /// Custom full Xray config: used as written; stats are switched on, a TUN inbound is added when missing (as PattNG does),
  /// and a local SOCKS inbound is added when it has none so the in-app browser can reach it.
  static V2Build? _custom(String text, V2Options o) {
    final dynamic j;
    try {
      j = jsonDecode(text);
    } catch (_) {
      return null;
    }
    if (j is! Map<String, dynamic>) return null;
    j['stats'] ??= {};
    final pol = j['policy'] is Map ? Map<String, dynamic>.from(j['policy'] as Map) : <String, dynamic>{};
    pol['system'] = {'statsOutboundUplink': true, 'statsOutboundDownlink': true};
    j['policy'] = pol;
    final ins = j['inbounds'] is List ? List<dynamic>.from(j['inbounds'] as List) : <dynamic>[];
    final hasTun = ins.any((e) => e is Map && e['protocol'] == 'tun');
    if (!hasTun) ins.add(_tunInbound(o.mtu));
    int port = 0;
    for (final e in ins) {
      if (e is Map && e['protocol'] == 'socks' && e['port'] is int) {
        final listen = (e['listen'] ?? '127.0.0.1').toString();
        if (listen == '127.0.0.1' || listen == '0.0.0.0' || listen == 'localhost') {
          port = e['port'] as int;
          break;
        }
      }
    }
    if (port == 0) {
      ins.insert(0, _socksInbound());
      port = socksPort;
    }
    j['inbounds'] = ins;
    return V2Build(jsonEncode(j), port);
  }

  /// Config for a delay test: just the outbound(s), no inbounds, DNS or routing rules.
  static String? forTest(String entry) {
    if (entry.trimLeft().startsWith('{')) {
      try {
        final j = jsonDecode(entry);
        if (j is! Map<String, dynamic>) return null;
        j['inbounds'] = <dynamic>[];
        j.remove('stats');
        j['log'] = {'loglevel': 'none'};
        return jsonEncode(j);
      } catch (_) {
        return null;
      }
    }
    final item = V2Parser.parse(entry);
    if (item == null) return null;
    final proxy = outbound(item);
    if (proxy == null) return null;
    return jsonEncode({
      'log': {'loglevel': 'none'},
      'inbounds': <dynamic>[],
      'outbounds': [
        proxy,
        {'protocol': 'freedom', 'tag': 'direct'},
      ],
      'routing': {'domainStrategy': 'AsIs', 'rules': <dynamic>[]},
    });
  }

  /// Name / server / port of an entry for the list (custom configs: from the first proxy-like outbound).
  static ({String name, String server, int port, String type})? describe(String entry) {
    final type = V2Parser.typeOf(entry);
    if (type == 'custom') {
      try {
        final j = jsonDecode(entry) as Map;
        var name = (j['remarks'] ?? '').toString();
        String server = '';
        int port = 0;
        for (final o in (j['outbounds'] as List? ?? [])) {
          if (o is Map && o['protocol'] != 'freedom' && o['protocol'] != 'blackhole' && o['protocol'] != 'dns') {
            final s = o['settings'];
            if (s is Map) {
              server = (s['address'] ?? '').toString();
              port = int.tryParse((s['port'] ?? '').toString()) ?? 0;
              final vn = s['vnext'];
              if (server.isEmpty && vn is List && vn.isNotEmpty && vn.first is Map) {
                server = ((vn.first as Map)['address'] ?? '').toString();
                port = int.tryParse(((vn.first as Map)['port'] ?? '').toString()) ?? 0;
              }
            }
            break;
          }
        }
        if (name.isEmpty) name = server.isEmpty ? 'Custom' : server;
        return (name: name, server: server, port: port, type: 'custom');
      } catch (_) {
        return null;
      }
    }
    final it = V2Parser.parse(entry);
    if (it == null) return null;
    return (name: it.remarks.isEmpty || it.remarks == 'none' ? it.server : it.remarks, server: it.server, port: it.port, type: it.type);
  }
}
