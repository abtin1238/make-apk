import 'package:flutter/material.dart';

/// Shape family used by the browser tab strip. iOS keeps its original Safari shape.
enum BrowserTabShape { ios, capsule, trapezoid, glass, angled, wave, desktop, notched, flat, folder }

/// Whole tab-strip LAYOUT (not only the silhouette): every theme family arranges its tabs differently.
///  ios       Safari: flat tabs, strip above the address pill
///  pills     floating capsules with a round close button, strip above
///  chrome    desktop-Chrome trapezoids joined to the toolbar, separators between inactive tabs
///  cards     glass cards with an icon tile, strip BELOW the address bar
///  underline flat tabs with an accent underline, only the active tab shows ✕
///  angled    parallelogram tabs
///  compact   active tab wide, the others collapse to their site icon
///  folder    folder tabs: the active one is raised, the others sit lower
enum TabLayout { ios, pills, chrome, cards, underline, angled, compact, folder }

extension TabLayoutInfo on TabLayout {
  /// Strip drawn under the address bar instead of above it.
  bool get stripBelow => this == TabLayout.cards;
  /// The active tab shares its colour with the toolbar so both look like one piece.
  bool get joined => this == TabLayout.ios || this == TabLayout.chrome || this == TabLayout.angled || this == TabLayout.compact || this == TabLayout.folder;
  double get stripHeight {
    switch (this) {
      case TabLayout.ios: return 32;
      case TabLayout.pills: return 38;
      case TabLayout.cards: return 42;
      case TabLayout.underline: return 38;
      default: return 36;
    }
  }
}

/// Selectable themes. Colors are plain ARGB ints; the helpers below turn them into the colours the whole UI uses.
class AbtinPalette {
  const AbtinPalette(this.id, this.fa, this.en, this.dark, this.bg, this.blobs, this.accent);
  final String id, fa, en;
  final bool dark;
  final List<int> bg;    // 3-stop background gradient
  final List<int> blobs; // 3 soft glows painted over the gradient
  final int accent;
}

const palettes = <AbtinPalette>[
  // iOS Safari look (system grouped background, white / #1C1C1E bars, system blue).
  AbtinPalette('ios-light', 'iOS روشن', 'iOS Light', false,
      [0xFFF2F2F7, 0xFFF2F2F7, 0xFFF2F2F7], [0xFF007AFF, 0xFF5AC8FA, 0xFF34C759], 0xFF007AFF),
  AbtinPalette('ios-dark', 'iOS تیره', 'iOS Dark', true,
      [0xFF000000, 0xFF000000, 0xFF000000], [0xFF0A84FF, 0xFF64D2FF, 0xFF30D158], 0xFF0A84FF),
  // Browser chrome inspired by the supplied desktop reference: restrained navy surfaces and a cool, quiet light mode.
  AbtinPalette('browser-dark', 'مرورگر تیره', 'Browser Dark', true,
      [0xFF080F1D, 0xFF111C2D, 0xFF0A1423], [0xFF263D62, 0xFF1D3458, 0xFF172B48], 0xFF2878E8),
  AbtinPalette('browser-light', 'مرورگر روشن', 'Browser Light', false,
      [0xFFEAF0F8, 0xFFF4F6FA, 0xFFE8EEF7], [0xFFD6E2F2, 0xFFC8D8EE, 0xFFE0E8F4], 0xFF1769D2),
  AbtinPalette('ocean', 'اقیانوس', 'Ocean', true,
      [0xFF03102A, 0xFF0A2A5E, 0xFF06304F], [0xFF3B82F6, 0xFF06B6D4, 0xFF8B5CF6], 0xFF4C8DFF),
  AbtinPalette('forest', 'جنگل', 'Forest', true,
      [0xFF03211B, 0xFF0A3F31, 0xFF0A2C3C], [0xFF10B981, 0xFF34D399, 0xFF06B6D4], 0xFF34D399),
  AbtinPalette('sunset', 'غروب', 'Sunset', true,
      [0xFF2B0F20, 0xFF54173A, 0xFF3D1A0A], [0xFFFF7A45, 0xFFEC4899, 0xFFFBBF24], 0xFFFF8A5B),
  AbtinPalette('amoled', 'مشکی خالص', 'AMOLED Black', true,
      [0xFF000000, 0xFF000000, 0xFF050505], [0xFF2563EB, 0xFF7C3AED, 0xFF0891B2], 0xFF5B9DFF),
  AbtinPalette('ice', 'یخ', 'Ice', false,
      [0xFFEAF3FF, 0xFFD6E7FF, 0xFFE9F8FF], [0xFF60A5FA, 0xFF22D3EE, 0xFFA78BFA], 0xFF2563EB),
];

/// ONE source of truth for the colours of a palette, used by ThemeData, Glass cards, sheets and the background,
/// so every palette really changes every screen (in every interface style) instead of only the picker preview.
extension PaletteColors on AbtinPalette {
  Color get base => Color(bg[1]);
  bool get isIos => id.startsWith('ios-');

  TabLayout get tabLayout {
    if (isIos) return TabLayout.ios;
    switch (id) {
      case 'browser-dark': return TabLayout.pills;
      case 'browser-light': return TabLayout.chrome;
      case 'ocean': return TabLayout.cards;
      case 'forest': return TabLayout.underline;
      case 'sunset': return TabLayout.angled;
      case 'amoled': return TabLayout.compact;
      case 'ice': return TabLayout.folder;
      default: return TabLayout.pills;
    }
  }

  /// Silhouette used by the theme preview (the live strip draws each layout itself).
  BrowserTabShape get tabShape {
    switch (tabLayout) {
      case TabLayout.ios: return BrowserTabShape.ios;
      case TabLayout.pills: return BrowserTabShape.capsule;
      case TabLayout.chrome: return BrowserTabShape.trapezoid;
      case TabLayout.cards: return BrowserTabShape.glass;
      case TabLayout.underline: return BrowserTabShape.flat;
      case TabLayout.angled: return BrowserTabShape.angled;
      case TabLayout.compact: return BrowserTabShape.desktop;
      case TabLayout.folder: return BrowserTabShape.folder;
    }
  }

  /// Page / scaffold colour. Styles only change how strongly the palette tints it, never replace it.
  Color pageColor(String style) {
    final b = base;
    if (isIos) return b;
    if (style == 'samsung') return Color.lerp(b, dark ? const Color(0xFF111318) : const Color(0xFFF3F5F8), .45)!;
    if (style == 'uc') return Color.lerp(b, Color(accent), dark ? .10 : .08)!;
    return b;
  }

  /// Card / sheet surface.
  Color surfaceColor(String style, {bool strong = false}) {
    final b = base;
    if (isIos) return dark ? (strong ? const Color(0xFF2C2C2E) : const Color(0xFF1C1C1E)) : const Color(0xFFFFFFFF);
    if (style == 'neu') return dark ? Color.lerp(b, const Color(0xFFFFFFFF), .035)! : Color.lerp(b, const Color(0xFFFFFFFF), .35)!;
    if (style == 'samsung') {
      final n = dark ? const Color(0xFF20242B) : const Color(0xFFF7F8FA);
      return Color.lerp(b, n, .55)!;
    }
    if (style == 'uc') return Color.lerp(b, Color(accent), dark ? .14 : .10)!.withAlpha(255);
    if (dark) return Color.lerp(b, const Color(0xFFFFFFFF), strong ? .11 : .07)!;
    return Color.lerp(b, const Color(0xFFFFFFFF), strong ? .85 : .65)!;
  }

  /// Top bar colour of the 'uc' style (accent based); other styles use the page colour.
  Color appBarColor(String style) {
    if (isIos) return dark ? const Color(0xFF1C1C1E) : const Color(0xFFF7F7F7);
    if (style == 'uc') return Color.lerp(base, Color(accent), dark ? .45 : .90)!;
    if (style == 'samsung') return surfaceColor(style, strong: true);
    return pageColor(style);
  }
}


/// Shared tab silhouette so the live browser and theme previews always match.
class BrowserTabClipper extends CustomClipper<Path> {
  const BrowserTabClipper(this.shape);
  final BrowserTabShape shape;

  @override
  Path getClip(Size s) {
    final w = s.width, h = s.height;
    final p = Path();
    switch (shape) {
      case BrowserTabShape.ios:
        p.moveTo(0, h); p.lineTo(0, 13); p.quadraticBezierTo(0, 0, 13, 0);
        p.lineTo(w - 13, 0); p.quadraticBezierTo(w, 0, w, 13); p.lineTo(w, h); p.close();
        break;
      case BrowserTabShape.capsule:
        p.addRRect(RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, w, h), Radius.circular(h / 2)));
        break;
      case BrowserTabShape.glass:
        p.addRRect(RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, w, h), const Radius.circular(11)));
        break;
      case BrowserTabShape.trapezoid:
        p.moveTo(0, h); p.lineTo(12, 8); p.quadraticBezierTo(16, 0, 25, 0);
        p.lineTo(w - 25, 0); p.quadraticBezierTo(w - 16, 0, w - 12, 8); p.lineTo(w, h); p.close();
        break;
      case BrowserTabShape.angled:
        p.moveTo(0, h); p.lineTo(17, 0); p.lineTo(w - 12, 0); p.lineTo(w, h); p.close();
        break;
      case BrowserTabShape.wave:
        p.moveTo(0, h); p.quadraticBezierTo(0, 0, 22, 0); p.lineTo(w - 22, 0);
        p.quadraticBezierTo(w, 0, w, h); p.lineTo(0, h); p.close();
        break;
      case BrowserTabShape.desktop:
        p.moveTo(0, h); p.lineTo(0, 7); p.quadraticBezierTo(0, 0, 7, 0);
        p.lineTo(w - 7, 0); p.quadraticBezierTo(w, 0, w, 7); p.lineTo(w, h); p.close();
        break;
      case BrowserTabShape.flat:
        p.addRect(Rect.fromLTWH(0, 0, w, h));
        break;
      case BrowserTabShape.folder:
        p.moveTo(0, h); p.lineTo(0, 12); p.quadraticBezierTo(0, 0, 12, 0);
        p.lineTo(w - 12, 0); p.quadraticBezierTo(w, 0, w, 12); p.lineTo(w, h); p.close();
        break;
      case BrowserTabShape.notched:
        p.moveTo(0, h); p.lineTo(0, 10); p.quadraticBezierTo(0, 0, 10, 0);
        p.lineTo(w * .34, 0); p.quadraticBezierTo(w * .40, 0, w * .44, 5);
        p.quadraticBezierTo(w * .50, 12, w * .56, 5); p.quadraticBezierTo(w * .60, 0, w * .66, 0);
        p.lineTo(w - 10, 0); p.quadraticBezierTo(w, 0, w, 10); p.lineTo(w, h); p.close();
        break;
    }
    return p;
  }

  @override
  bool shouldReclip(covariant BrowserTabClipper oldClipper) => oldClipper.shape != shape;
}
