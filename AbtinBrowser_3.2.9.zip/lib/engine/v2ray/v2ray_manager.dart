import 'dart:async';
import 'dart:convert';
import 'package:dio/dio.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import '../../app_state.dart';
import '../app_proxy.dart';
import '../../services.dart';
import 'v2ray_config.dart';
import 'v2ray_parser.dart';

class V2Profile {
  V2Profile({required this.id, required this.name, required this.type, required this.entry, this.subId, this.server = '', this.port = 0});
  final String id;
  String name, type, entry, server;
  String? subId;
  int port;
  int? ping; // ms, -1 = failed, null = not tested
  bool testing = false;

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'type': type, 'entry': entry, 'subId': subId, 'server': server, 'port': port};
  factory V2Profile.fromJson(Map<String, dynamic> j) => V2Profile(
        id: j['id'] as String, name: j['name'] as String, type: j['type'] as String, entry: j['entry'] as String,
        subId: j['subId'] as String?, server: (j['server'] ?? '') as String, port: (j['port'] ?? 0) as int,
      );
}

class V2Sub {
  V2Sub({required this.id, required this.name, required this.url, this.updated = 0});
  final String id;
  String name, url;
  int updated;
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'url': url, 'updated': updated};
  factory V2Sub.fromJson(Map<String, dynamic> j) => V2Sub(id: j['id'] as String, name: j['name'] as String, url: j['url'] as String, updated: (j['updated'] ?? 0) as int);
}

/// v2ray / Xray tunnel: profiles, subscriptions, system-wide VPN control. The native side lives in the ":v2ray" process.
class V2rayManager extends ChangeNotifier {
  V2rayManager(this.app);
  final AppState app;

  static const MethodChannel _m = MethodChannel('abtin/v2ray');
  static const EventChannel _e = EventChannel('abtin/v2ray/events');

  List<V2Profile> profiles = [];
  List<V2Sub> subs = [];
  String? selectedId;
  String status = 'disconnected'; // disconnected | connecting | connected | error
  String error = '';
  int up = 0, down = 0, totalUp = 0, totalDown = 0;
  DateTime? since;
  int _socksPort = V2Config.socksPort;
  bool _ready = false;
  String? busyMsg;
  VoidCallback? onProxyChanged;
  Completer<void>? _waitDown;
  final Map<String, Timer> _pingTimers = {};
  final Map<String, Completer<void>> _pingWait = {};
  bool _pingAllRunning = false;
  bool _switching = false; // connect() in progress: a second tap must not start a second sequence

  bool get connected => status == 'connected';
  bool get connecting => status == 'connecting';
  V2Profile? get selected {
    for (final p in profiles) {
      if (p.id == selectedId) return p;
    }
    return null;
  }

  V2Options get options => V2Options(
        bypassIran: app.flag('v2BypassIran'), blockAds: app.flag('v2BlockAds'), blockUdp443: app.flag('v2BlockUdp'),
        bypassLan: app.flag('v2BypassLan'), ipv6: app.flag('v2Ipv6'),
        mtu: int.tryParse(app.str('v2Mtu').trim()) ?? 1500, vpnDns: app.str('v2Dns'),
      );

  Future<void> init() async {
    if (_ready) return;
    _ready = true;
    final p = app.prefs;
    try {
      profiles = (jsonDecode(p.getString('v2_profiles_v1') ?? '[]') as List).map((e) => V2Profile.fromJson(Map<String, dynamic>.from(e as Map))).toList();
      subs = (jsonDecode(p.getString('v2_subs_v1') ?? '[]') as List).map((e) => V2Sub.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (_) {}
    selectedId = p.getString('v2_sel');
    _socksPort = p.getInt('v2_socks') ?? V2Config.socksPort;
    try {
      _e.receiveBroadcastStream().listen(_onEvent, onError: (Object _) {});
      await _m.invokeMethod('query');
    } catch (e) {
      debugPrint('v2ray init: $e');
    }
    notifyListeners();
  }

  void _save() {
    final p = app.prefs;
    p.setString('v2_profiles_v1', jsonEncode(profiles.map((e) => e.toJson()).toList()));
    p.setString('v2_subs_v1', jsonEncode(subs.map((e) => e.toJson()).toList()));
    if (selectedId != null) p.setString('v2_sel', selectedId!);
  }

  void _onEvent(dynamic d) {
    if (d is! Map) return;
    switch (d['type']) {
      case 'state':
        status = '${d['state']}';
        error = '${d['error'] ?? ''}';
        if (status == 'connected') {
          since ??= DateTime.now();
        } else {
          since = null;
          up = down = 0;
          if (status == 'disconnected' || status == 'error') totalUp = totalDown = 0;
        }
        final port = status == 'connected' ? _socksPort : 0;
        AppProxy.on = status == 'connected';
        if (port != app.proxyPort) {
          app.proxyPort = port;
          onProxyChanged?.call();
        }
        if ((status == 'disconnected' || status == 'error') && _waitDown != null && !_waitDown!.isCompleted) _waitDown!.complete();
        notifyListeners();
      case 'stats':
        up = (d['up'] ?? 0) as int;
        down = (d['down'] ?? 0) as int;
        totalUp = (d['totalUp'] ?? 0) as int;
        totalDown = (d['totalDown'] ?? 0) as int;
        notifyListeners();
      case 'ping':
        final id = '${d['id']}';
        for (final pr in profiles) {
          if (pr.id == id) {
            pr.ping = (d['ms'] ?? -1) as int;
            pr.testing = false;
          }
        }
        _finishPing(id);
        // Persist the last measured real Xray delay so the native PWA picker can show
        // the same actual ping values without inventing or sampling throughput.
        try {
          final cache = <String, int>{};
          for (final pr in profiles) { if (pr.ping != null) cache[pr.id] = pr.ping!; }
          app.prefs.setString('v2_ping_cache', jsonEncode(cache));
        } catch (_) {}
        notifyListeners();
    }
  }

  // ---- import ----
  String _newId() => '${DateTime.now().microsecondsSinceEpoch}${profiles.length}';

  /// Adds every link / JSON config found in [text]. Returns how many were new.
  int addText(String text, {String? subId}) {
    var n = 0;
    for (final entry in V2Parser.extract(text)) {
      if (profiles.any((p) => p.entry == entry && p.subId == subId)) continue;
      final d = V2Config.describe(entry);
      if (d == null) continue;
      profiles.add(V2Profile(id: _newId(), name: d.name, type: d.type, entry: entry, subId: subId, server: d.server, port: d.port));
      n++;
    }
    if (n > 0) {
      selectedId ??= profiles.first.id;
      _save();
      notifyListeners();
    }
    return n;
  }

  Future<String> _fetch(String url) async {
    final r = await Dio().get<String>(url,
        options: Options(responseType: ResponseType.plain, headers: {'User-Agent': 'v2rayNG/2.3.13'}, receiveTimeout: const Duration(seconds: 25), sendTimeout: const Duration(seconds: 15)));
    return r.data ?? '';
  }

  /// Returns the number of profiles after the update, or -1 on failure.
  Future<int> addSub(String name, String url) async {
    final s = V2Sub(id: _newId(), name: name.isEmpty ? Uri.tryParse(url)?.host ?? 'sub' : name, url: url.trim());
    subs.add(s);
    _save();
    return refreshSub(s);
  }

  Future<int> refreshSub(V2Sub s) async {
    try {
      final body = await _fetch(s.url);
      final entries = V2Parser.extract(body);
      if (entries.isEmpty) return -1;
      final keepSel = selected?.entry;
      profiles.removeWhere((p) => p.subId == s.id);
      addText(entries.join('\n'), subId: s.id);
      if (keepSel != null) {
        for (final p in profiles) {
          if (p.entry == keepSel) selectedId = p.id;
        }
      }
      if (selected == null && profiles.isNotEmpty) selectedId = profiles.first.id;
      s.updated = DateTime.now().millisecondsSinceEpoch;
      _save();
      notifyListeners();
      return entries.length;
    } catch (e) {
      debugPrint('sub refresh: $e');
      return -1;
    }
  }

  void removeProfile(V2Profile p) {
    profiles.remove(p);
    if (selectedId == p.id) selectedId = profiles.isEmpty ? null : profiles.first.id;
    _save();
    notifyListeners();
  }

  /// Configs whose delay test failed (✕). Untested ones are not counted. The config in use while connected is kept.
  List<V2Profile> get failedProfiles => profiles
      .where((p) => !p.testing && p.ping != null && p.ping! < 0 && !(connected && p.id == selectedId))
      .toList();

  int get untestedCount => profiles.where((p) => p.ping == null && !p.testing).length;

  /// Deletes every config with a failed delay test. Returns how many were removed.
  int removeFailed() {
    final dead = failedProfiles;
    if (dead.isEmpty) return 0;
    final ids = dead.map((p) => p.id).toSet();
    profiles.removeWhere((p) => ids.contains(p.id));
    if (selected == null) selectedId = profiles.isEmpty ? null : profiles.first.id;
    _save();
    notifyListeners();
    return dead.length;
  }

  /// Deletes every config (subscriptions stay in the list; their configs come back on the next update).
  /// Returns how many were removed. Disconnects first when connected, since the config in use goes too.
  Future<int> removeAll() async {
    final n = profiles.length;
    if (n == 0) return 0;
    if (status == 'connected' || status == 'connecting') await disconnect();
    profiles.clear();
    selectedId = null;
    _save();
    notifyListeners();
    return n;
  }

  void removeSub(V2Sub s) {
    subs.remove(s);
    profiles.removeWhere((p) => p.subId == s.id);
    if (selected == null) selectedId = profiles.isEmpty ? null : profiles.first.id;
    _save();
    notifyListeners();
  }

  void select(V2Profile p) {
    selectedId = p.id;
    _save();
    notifyListeners();
  }

  // ---- connection ----
  /// Starts the system-wide tunnel with [p] (default: the selected one). Returns an error key or null.
  Future<String?> connect([V2Profile? p]) async {
    p ??= selected;
    if (p == null) return 'no_profile';
    if (_switching) return null; // a connect is already running: ignore the extra tap
    _switching = true;
    try {
      return await _connect(p);
    } finally {
      _switching = false;
    }
  }

  Future<String?> _connect(V2Profile p) async {
    // Android keeps one VPN only: the system-wide DNS stops when v2ray starts, so its servers carry over into the tunnel.
    final dnsWasOn = dnsMgr.on;
    final carriedDns = dnsMgr.servers.join(',');
    if (dnsWasOn) { await dnsMgr.disconnect(); await Future<void>.delayed(const Duration(milliseconds: 800)); }
    final o = options;
    final eo = dnsWasOn && carriedDns.isNotEmpty
        ? V2Options(bypassIran: o.bypassIran, blockAds: o.blockAds, blockUdp443: o.blockUdp443, bypassLan: o.bypassLan, ipv6: o.ipv6, mtu: o.mtu, vpnDns: carriedDns)
        : o;
    final b = V2Config.build(p.entry, eo);
    if (b == null) return 'unsupported';
    if (status == 'connected' || status == 'connecting') {
      _waitDown = Completer<void>();
      await _m.invokeMethod('stop');
      await _waitDown!.future.timeout(const Duration(seconds: 6), onTimeout: () {});
      await Future<void>.delayed(const Duration(milliseconds: 400));
    }
    selectedId = p.id;
    _socksPort = b.socksPort;
    app.prefs.setInt('v2_socks', _socksPort);
    _save();
    status = 'connecting';
    error = '';
    notifyListeners();
    final skip = await skipCsv();
    try {
      await _m.invokeMethod('start', {
        'config': b.json,
        'name': p.name,
        'mtu': eo.mtu,
        'ipv6': eo.ipv6,
        'bypassLan': eo.bypassLan,
        'bypassIranIp': app.flag('v2BypassIranIp'),
        'skip': skip,
        'dns': eo.vpnDns,
      });
    } catch (e) {
      status = 'error';
      error = e is PlatformException ? (e.message ?? 'start_failed') : '$e';
      notifyListeners();
      return 'start_failed';
    }
    return null;
  }

  // ---- apps outside the VPN (bank apps etc.: they must not see a VPN at all) ----
  /// Launcher apps: [{pkg, label, iran}], `iran` = guessed Iranian app.
  Future<List<Map<String, dynamic>>> listApps() async {
    try {
      final l = await _m.invokeMethod<List<Object?>>('listApps') ?? [];
      return l.map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {
      return [];
    }
  }

  /// Per-app choice made by the user: pkg -> true (outside the VPN) / false (through the VPN). Missing = automatic.
  Map<String, bool> get appOverrides {
    try {
      return (jsonDecode(app.str('v2AppOver')) as Map).map((k, v) => MapEntry(k as String, v == true));
    } catch (_) {
      return {};
    }
  }

  void setAppOverride(String pkg, bool? outside) {
    final o = appOverrides;
    if (outside == null) { o.remove(pkg); } else { o[pkg] = outside; }
    app.set('v2AppOver', jsonEncode(o));
  }

  /// Comma separated packages that bypass the VPN: auto-detected Iranian apps (if enabled) with the user's per-app choices applied.
  Future<String> skipCsv() async {
    final over = appOverrides;
    final out = <String>{};
    if (app.flag('v2SkipIranApps')) {
      for (final a in await listApps()) {
        if (a['iran'] == true) out.add(a['pkg'] as String);
      }
    }
    over.forEach((k, v) { if (v) { out.add(k); } else { out.remove(k); } });
    return out.join(',');
  }

  /// {ignoring: battery optimisation is off for this app, miui: Xiaomi / Redmi / POCO phone}.
  Future<Map<String, bool>> powerStatus() async {
    try {
      final m = await _m.invokeMethod<Map<Object?, Object?>>('batteryStatus');
      return {'ignoring': m?['ignoring'] == true, 'miui': m?['miui'] == true};
    } catch (_) {
      return {'ignoring': true, 'miui': false};
    }
  }

  Future<void> powerAction(String method) async {
    try { await _m.invokeMethod(method); } catch (_) {}
  }

  /// Crash evidence of the VPN process (exit reasons + app logcat), for the "error report" button.
  Future<String> diag() async {
    try {
      return await _m.invokeMethod<String>('diag') ?? '';
    } catch (e) {
      return 'diag failed: $e';
    }
  }

  Future<void> disconnect() async {
    try {
      await _m.invokeMethod('stop');
    } catch (_) {}
  }

  // ---- delay test ----
  void _finishPing(String id) {
    _pingTimers.remove(id)?.cancel();
    final c = _pingWait.remove(id);
    if (c != null && !c.isCompleted) c.complete();
  }

  /// Tests one config. Completes when the result arrived (or after a timeout that starts NOW, not when queued).
  Future<void> ping(V2Profile p) async {
    if (p.testing && _pingWait.containsKey(p.id)) return; // already running: a second tap must not start a second test
    return _pingOne(p);
  }

  Future<void> _pingOne(V2Profile p) async {
    final cfg = V2Config.forTest(p.entry);
    if (cfg == null) {
      p.ping = -1;
      p.testing = false;
      notifyListeners();
      return;
    }
    _finishPing(p.id);
    p.testing = true;
    p.ping = null;
    notifyListeners();
    final done = Completer<void>();
    _pingWait[p.id] = done;
    _pingTimers[p.id] = Timer(const Duration(seconds: 20), () {
      p.testing = false;
      p.ping ??= -1;
      _finishPing(p.id);
      notifyListeners();
    });
    try {
      await _m.invokeMethod('ping', {'id': p.id, 'config': cfg, 'url': app.str('v2TestUrl')});
    } catch (_) {
      p.testing = false;
      p.ping = -1;
      _finishPing(p.id);
      notifyListeners();
    }
    await done.future;
  }

  /// Tests every config, a few at a time (the native side runs 3 cores at once). The old version sent all of them at once,
  /// so the queued ones hit their 20 s timeout before they even started and showed a false failure (✕), and the burst
  /// loaded the phone enough for its task killer to step in.
  Future<void> pingAll() async {
    if (_pingAllRunning) return;
    _pingAllRunning = true;
    try {
      final queue = List<V2Profile>.from(profiles).where((p) => !p.testing).toList();
      for (final p in queue) {
        p.testing = true;
        p.ping = null;
      }
      notifyListeners();
      Future<void> worker() async {
        while (queue.isNotEmpty) {
          await _pingOne(queue.removeAt(0));
        }
      }
      await Future.wait(List.generate(3, (_) => worker()));
    } finally {
      _pingAllRunning = false;
    }
  }
}
