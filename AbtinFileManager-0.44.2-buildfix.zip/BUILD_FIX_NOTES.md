# Build fix notes — AbtinFileManager 0.44.2

- Added `android.newDsl=false` to `android/gradle.properties` to keep the legacy `android {}` DSL active while this project still uses it. This addresses the AGP 9 DSL deprecation errors reported at `android/app/build.gradle.kts:18`.
- Replaced deprecated `kotlinOptions { jvmTarget = "17" }` with Kotlin's typed `compilerOptions` DSL targeting JVM 17.
- Kept existing app dependencies, packaging rules, signing behavior, and Flutter configuration unchanged.

Validation: source-level checks confirm the new DSL flag and compiler target. A Flutter/Gradle build was not run in this environment because Flutter and Dart SDKs are not installed.
