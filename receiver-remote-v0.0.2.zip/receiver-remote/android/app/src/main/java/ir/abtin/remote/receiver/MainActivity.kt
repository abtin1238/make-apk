package ir.abtin.remote.receiver

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var serverBtn: Button
    private lateinit var bluetoothBtn: Button
    private val reqBluetooth = 7711
    @Volatile private var injectorOk = false
    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 2000) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(applicationContext)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(32, 40, 32, 32)

        info = TextView(this)
        info.textSize = 17f
        box.addView(info)

        val accBtn = Button(this)
        accBtn.text = "فعال‌سازی سرویس دسترس‌پذیری (ضروری)"
        accBtn.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        box.addView(accBtn)

        serverBtn = Button(this)
        serverBtn.setOnClickListener {
            if (RemoteServer.isRunning()) {
                RemoteServer.stopWifi()
                if (!RemoteServer.isBluetoothRunning()) ServerService.stop(this)
            } else ServerService.start(this)
            handler.postDelayed({ refresh() }, 400)
        }
        box.addView(serverBtn)

        bluetoothBtn = Button(this)
        bluetoothBtn.text = "فعال‌سازی بلوتوث گیرنده"
        bluetoothBtn.setOnClickListener {
            if (RemoteServer.isBluetoothRunning()) {
                RemoteServer.setBluetoothWanted(this, false)
                RemoteServer.stopBluetooth()
                if (!RemoteServer.isRunning()) ServerService.stop(this)
                refresh()
            } else startBluetoothReceiver()
        }
        box.addView(bluetoothBtn)

        val appInfoBtn = Button(this)
        appInfoBtn.text = "باز کردن اطلاعات برنامه (Allow restricted settings)"
        appInfoBtn.setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (_: Exception) { startActivity(Intent(Settings.ACTION_SETTINGS)) }
        }
        box.addView(appInfoBtn)

        val pinBtn = Button(this)
        pinBtn.text = "ساخت PIN جدید"
        pinBtn.setOnClickListener { RemoteServer.regeneratePin(this); refresh() }
        box.addView(pinBtn)

        val scroll = ScrollView(this)
        scroll.addView(box)
        setContentView(scroll)

        ServerService.start(this)
        tryAutoEnable()
        refresh()
    }

    override fun onResume() {
        super.onResume()
        handler.post(ticker)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun startBluetoothReceiver() {
        if (Build.VERSION.SDK_INT >= 31 &&
            (checkSelfPermission("android.permission.BLUETOOTH_CONNECT") != PackageManager.PERMISSION_GRANTED ||
             checkSelfPermission("android.permission.BLUETOOTH_ADVERTISE") != PackageManager.PERMISSION_GRANTED)) {
            requestPermissions(arrayOf("android.permission.BLUETOOTH_CONNECT", "android.permission.BLUETOOTH_ADVERTISE"), reqBluetooth)
            return
        }
        if (android.bluetooth.BluetoothAdapter.getDefaultAdapter()?.isEnabled != true) {
            try { startActivity(Intent(android.bluetooth.BluetoothAdapter.ACTION_REQUEST_ENABLE)) } catch (_: Exception) {}
            return
        }
        ServerService.start(this) // سرویس پیش‌زمینه تا وقتی اپ بسته است هم RFCOMM زنده بماند
        val ok = RemoteServer.startBluetooth(this)
        if (ok) {
            RemoteServer.setBluetoothWanted(this, true)
            try {
                val i = Intent(android.bluetooth.BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                i.putExtra(android.bluetooth.BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
                startActivity(i)
            } catch (_: Exception) {}
        }
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqBluetooth && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) {
            startBluetoothReceiver()
        }
    }

    private fun accessibilityEnabled(): Boolean {
        if (RemoteAccessibilityService.instance != null) return true
        return try {
            val flat = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val me = ComponentName(this, RemoteAccessibilityService::class.java).flattenToString()
            flat.split(':').any { it.equals(me, ignoreCase = true) }
        } catch (_: Exception) { false }
    }

    private val serviceId: String
        get() = ComponentName(this, RemoteAccessibilityService::class.java).flattenToString()

    /** اگر با adb مجوز WRITE_SECURE_SETTINGS داده شده باشد، سرویس بدون نیاز به صفحه‌ی تنظیمات روشن می‌شود. */
    private fun tryAutoEnable(): Boolean {
        if (accessibilityEnabled()) return true
        if (checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") != PackageManager.PERMISSION_GRANTED) return false
        return try {
            val cur = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
            val list = cur.split(':').filter { it.isNotBlank() }.toMutableList()
            if (list.none { it.equals(serviceId, ignoreCase = true) }) list.add(serviceId)
            Settings.Secure.putString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, list.joinToString(":"))
            Settings.Secure.putInt(contentResolver, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        } catch (_: Exception) { false }
    }

    private fun ips(): String = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { ni ->
                ni.inetAddresses.toList()
                    .filter { it is Inet4Address && !it.isLoopbackAddress }
                    .map { "${it.hostAddress}  (${ni.name})" }
            }
            .joinToString("\n")
            .ifEmpty { "IP نامشخص" }
    } catch (_: Exception) { "IP نامشخص" }

    private fun refresh() {
        thread { injectorOk = InjectorClient.available() }
        val running = RemoteServer.isRunning()
        serverBtn.text = if (running) "توقف سرور شبکه" else "شروع سرور شبکه"
        bluetoothBtn.text = if (RemoteServer.isBluetoothRunning()) "بلوتوث گیرنده فعال است" else "فعال‌سازی بلوتوث گیرنده"
        RemoteServer.restoreBluetooth(this)
        if (!accessibilityEnabled()) tryAutoEnable()
        val accOn = accessibilityEnabled()
        val acc = if (accOn) "✅ فعال" else "❌ غیرفعال (دکمه‌ی بالا را بزنید و Abtin Remote Receiver را روشن کنید)"
        val help = if (accOn) "" else
            "اگر سوییچ در تنظیمات روشن نمی‌شود (Android 13 به بالا، نصب خارج از فروشگاه):\n" +
            "۱) دکمه‌ی «باز کردن اطلاعات برنامه» را بزنید، منوی ⋮ را باز کنید و «Allow restricted settings» را بزنید، سپس دوباره سرویس را روشن کنید.\n" +
            "۲) یا از کامپیوتر با adb:\n" +
            "adb shell pm grant $packageName android.permission.WRITE_SECURE_SETTINGS\n" +
            "adb shell appops set $packageName ACCESS_RESTRICTED_SETTINGS allow\n" +
            "بعد از آن برنامه را دوباره باز کنید تا خودش سرویس را روشن کند.\n\n"
        val inj = if (injectorOk) "✅ فعال (نشانگر، کلیک و Enter واقعیِ خود اندروید)" else
            "⛔ غیرفعال (نشانگر و کلیک از Accessibility استفاده می‌کنند که روی بسیاری از باکس‌ها کار نمی‌کند).\n" +
            "برای فعال شدن، یک بار از adb اجرا کنید:\n" +
            "adb shell 'CLASSPATH=\$(pm path $packageName | cut -d: -f2) nohup app_process /system/bin ir.abtin.remote.receiver.Injector >/data/local/tmp/abtin.log 2>&1 &'"
        info.text = "Abtin Remote Receiver\n\n" +
            "ورودی واقعی: " + inj + "\n\n" +
            "وضعیت سرور Wi-Fi: " + (if (running) "✅ فعال" else "⛔ متوقف") + "\n" +
            "وضعیت سرور بلوتوث RFCOMM: " + (if (RemoteServer.isBluetoothRunning()) "✅ فعال" else "⛔ متوقف") + "\n" +
            "سرویس دسترس‌پذیری: " + acc + "\n\n" + help +
            "آدرس IP باکس:\n" + ips() + "\n\n" +
            "پورت: " + RemoteServer.PORT + "\n" +
            "PIN اتصال: " + RemoteServer.pin(this) + "\n\n" +
            "برای اتصال Wi-Fi، گوشی و باکس باید روی یک شبکه (یا هات‌اسپات گوشی) باشند. برای بلوتوث نیازی به شبکه نیست.\n\n" +
            "برای بلوتوث بدون HID، دکمه‌ی «فعال‌سازی بلوتوث گیرنده» را بزنید و گوشی و تلویزیون را Pair کنید. در اپ گوشی حالت «بلوتوث (گیرنده)» را انتخاب کنید. این مسیر همان فرمان‌های Wi-Fi را با RFCOMM منتقل می‌کند." +
            CrashLog.read(this).let { if (it.isEmpty()) "" else "\n\nآخرین خطای برنامه (این متن را بفرستید):\n$it" }
        info.layoutDirection = View.LAYOUT_DIRECTION_RTL
    }
}
