import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'link.dart';
import 'theme.dart';

/// تنظیمات مشترک (حساسیت و ...)
class PadSettings extends ChangeNotifier {
  double sensitivity = 1.6;
  double scrollSpeed = 1.0;
  bool naturalScroll = false;
  bool haptics = true;
  double gyroSens = 1.0;

  void update({double? sens, double? scroll, bool? natural, bool? hap, double? gyro}) {
    if (gyro != null) gyroSens = gyro;
    if (sens != null) sensitivity = sens;
    if (scroll != null) scrollSpeed = scroll;
    if (natural != null) naturalScroll = natural;
    if (hap != null) haptics = hap;
    notifyListeners();
  }
}

enum _Hint { none, left, right, scroll }

/// تاچ‌پد:
///  • یک انگشت کشیدن = حرکت نشانگر
///  • یک لمس (تپ) = کلیک چپ
///  • دو بار لمس (دابل‌تپ) = کلیک راست
///  • دو انگشت کشیدن = اسکرول
///  • لمس طولانی و کشیدن = درگ
class GestureTouchpad extends StatefulWidget {
  final WifiLink link;
  final PadSettings settings;
  final bool compact;
  const GestureTouchpad({
    super.key,
    required this.link,
    required this.settings,
    this.compact = false,
  });
  @override
  State<GestureTouchpad> createState() => _GestureTouchpadState();
}

class _GestureTouchpadState extends State<GestureTouchpad> {
  static const int tapMaxMs = 230;
  static const int doubleTapMs = 260;
  static const int longPressMs = 380;
  static const double slop = 8;

  final Map<int, Offset> _pos = {};
  final Map<int, Offset> _start = {};
  final Map<int, Offset> _ripples = {};

  bool _moved = false;
  bool _dragging = false;
  bool _scrolling = false;
  int _maxPointers = 0;
  int _downMs = 0;
  int _lastTapMs = 0;
  Timer? _singleTimer;
  Timer? _longTimer;
  Timer? _hintTimer;
  _Hint _hint = _Hint.none;

  int _now() => DateTime.now().millisecondsSinceEpoch;

  void _buzz() {
    if (widget.settings.haptics) HapticFeedback.selectionClick();
  }

  void _flash(_Hint h) {
    _hintTimer?.cancel();
    setState(() => _hint = h);
    _hintTimer = Timer(const Duration(milliseconds: 380), () {
      if (mounted) setState(() => _hint = _Hint.none);
    });
  }

  @override
  void dispose() {
    _singleTimer?.cancel();
    _longTimer?.cancel();
    _hintTimer?.cancel();
    if (_dragging) widget.link.mouseButton('left', false);
    super.dispose();
  }

  void _down(PointerDownEvent e) {
    final now = _now();
    if (_pos.isEmpty) {
      _moved = false;
      _scrolling = false;
      _maxPointers = 0;
      _downMs = now;
      _longTimer?.cancel();
      _longTimer = Timer(const Duration(milliseconds: longPressMs), () {
        if (_pos.length == 1 && !_moved && !_dragging) {
          _dragging = true;
          _singleTimer?.cancel();
          widget.link.mouseButton('left', true);
          _buzz();
          _flash(_Hint.left);
        }
      });
    }
    _pos[e.pointer] = e.localPosition;
    _start[e.pointer] = e.localPosition;
    _maxPointers = math.max(_maxPointers, _pos.length);
    if (_pos.length >= 2) {
      _longTimer?.cancel();
      _singleTimer?.cancel();
      _scrolling = true;
    }
    setState(() => _ripples[e.pointer] = e.localPosition);
  }

  void _move(PointerMoveEvent e) {
    final prev = _pos[e.pointer];
    if (prev == null) return;
    final d = e.localPosition - prev;
    _pos[e.pointer] = e.localPosition;
    final st = _start[e.pointer];
    if (st != null && (e.localPosition - st).distance > slop) {
      _moved = true;
      _longTimer?.cancel();
    }
    final s = widget.settings;
    if (_pos.length >= 2) {
      // اسکرول: فقط با حرکت اولین انگشت تا دوبار شمرده نشود
      if (e.pointer == _pos.keys.first) {
        final k = (s.naturalScroll ? -1.0 : 1.0) * s.scrollSpeed;
        widget.link.scroll(-d.dx / 18 * k, -d.dy / 18 * k);
        if (_hint != _Hint.scroll) setState(() => _hint = _Hint.scroll);
      }
    } else if (_pos.length == 1 && !_scrolling) {
      final speed = d.distance;
      final gain = s.sensitivity * (speed > 9 ? 1.7 : (speed > 4 ? 1.3 : 1.0));
      widget.link.move(d.dx * gain, d.dy * gain);
    }
    setState(() => _ripples[e.pointer] = e.localPosition);
  }

  void _up(PointerUpEvent e) {
    final now = _now();
    _pos.remove(e.pointer);
    _start.remove(e.pointer);
    setState(() => _ripples.remove(e.pointer));
    if (_pos.isNotEmpty) return;
    _longTimer?.cancel();
    if (_hint == _Hint.scroll) setState(() => _hint = _Hint.none);
    if (_dragging) {
      widget.link.mouseButton('left', false);
      _dragging = false;
      _lastTapMs = 0;
      return;
    }
    if (_scrolling || _moved || now - _downMs > tapMaxMs) {
      _scrolling = false;
      return;
    }
    // یک تپ تمیز
    if (now - _lastTapMs < doubleTapMs) {
      // لمس دوم => کلیک راست
      _singleTimer?.cancel();
      _lastTapMs = 0;
      widget.link.click('right');
      _buzz();
      _flash(_Hint.right);
    } else {
      _lastTapMs = now;
      _singleTimer?.cancel();
      _singleTimer = Timer(const Duration(milliseconds: doubleTapMs), () {
        widget.link.click('left');
        _buzz();
        _flash(_Hint.left);
        _lastTapMs = 0;
      });
    }
  }

  void _cancel(PointerCancelEvent e) {
    _pos.remove(e.pointer);
    _start.remove(e.pointer);
    setState(() => _ripples.remove(e.pointer));
    if (_pos.isEmpty) {
      _longTimer?.cancel();
      _scrolling = false;
      if (_dragging) {
        widget.link.mouseButton('left', false);
        _dragging = false;
      }
    }
  }

  Widget _hintItem(IconData icon, String title, String sub, _Hint h, Color c) {
    final on = _hint == h;
    final col = on ? c : c.withOpacity(0.55);
    return Column(mainAxisSize: MainAxisSize.min, children: [
      AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: on ? [BoxShadow(color: c.withOpacity(0.8), blurRadius: 18)] : const [],
        ),
        child: Icon(icon, size: widget.compact ? 26 : 34, color: col),
      ),
      Text(title,
          textDirection: TextDirection.rtl,
          style: TextStyle(fontSize: widget.compact ? 10 : 12, fontWeight: FontWeight.bold, color: on ? Colors.white : const Color(0xffd7e2ff))),
      if (sub.isNotEmpty)
        Text(sub, textDirection: TextDirection.rtl, style: TextStyle(fontSize: widget.compact ? 8 : 10, color: kHint)),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: _down,
      onPointerMove: _move,
      onPointerUp: _up,
      onPointerCancel: _cancel,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xff0a1440), Color(0xff1c0a3c)],
          ),
          border: Border.all(color: kCyan.withOpacity(0.85), width: 1.6),
          boxShadow: [BoxShadow(color: kBlue.withOpacity(0.45), blurRadius: 14)],
        ),
        child: Stack(children: [
          Positioned(
            top: 6,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                width: 34,
                height: 3,
                decoration: BoxDecoration(color: kCyan, borderRadius: BorderRadius.circular(2), boxShadow: [BoxShadow(color: kCyan.withOpacity(0.8), blurRadius: 6)]),
              ),
            ),
          ),
          IgnorePointer(
            child: CustomPaint(painter: _RipplePainter(_ripples.values.toList()), size: Size.infinite),
          ),
          IgnorePointer(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(4, 14, 4, 6),
              child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  _hintItem(Icons.touch_app, 'کلیک چپ', 'یک لمس', _Hint.left, kCyan),
                  _hintItem(Icons.ads_click, 'کلیک راست', 'دو بار لمس', _Hint.right, kMagenta),
                ]),
                _hintItem(Icons.swipe_vertical, 'اسکرول', 'دو انگشتی', _Hint.scroll, kPurple),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

class _RipplePainter extends CustomPainter {
  final List<Offset> pts;
  _RipplePainter(this.pts);
  @override
  void paint(Canvas canvas, Size size) {
    for (final p in pts) {
      canvas.drawCircle(p, 34, Paint()..color = kCyan.withOpacity(0.12));
      canvas.drawCircle(p, 34, Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = kCyan.withOpacity(0.7));
      canvas.drawCircle(p, 8, Paint()..color = Colors.white.withOpacity(0.8));
    }
  }

  @override
  bool shouldRepaint(covariant _RipplePainter old) => true;
}
