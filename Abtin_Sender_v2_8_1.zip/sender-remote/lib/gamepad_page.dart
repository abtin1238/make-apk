import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'link.dart';
import 'theme.dart';
import 'touchpad.dart';

const MethodChannel _device = MethodChannel('abtin/device');

class GamepadPage extends StatefulWidget {
  final WifiLink link;
  final PadSettings settings;
  final VoidCallback onMenu;
  final VoidCallback onConnect;
  final VoidCallback onSettings;
  const GamepadPage({
    super.key,
    required this.link,
    required this.settings,
    required this.onMenu,
    required this.onConnect,
    required this.onSettings,
  });
  @override
  State<GamepadPage> createState() => _GamepadPageState();
}

class _GamepadPageState extends State<GamepadPage> {
  final Map<String, int> _lastStick = {};
  int battery = -1;
  Timer? _bt;

  @override
  void initState() {
    super.initState();
    _readBattery();
    _bt = Timer.periodic(const Duration(seconds: 30), (_) => _readBattery());
  }

  @override
  void dispose() {
    _bt?.cancel();
    super.dispose();
  }

  Future<void> _readBattery() async {
    try {
      final v = await _device.invokeMethod<int>('battery');
      if (mounted && v != null) setState(() => battery = v);
    } catch (_) {}
  }

  void _buzz() {
    if (widget.settings.haptics) HapticFeedback.selectionClick();
  }

  void _stick(String side, double x, double y) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final zero = x == 0 && y == 0;
    final last = _lastStick[side] ?? 0;
    if (zero || now - last >= 30) {
      _lastStick[side] = now;
      widget.link.stick(side, x, y);
    }
  }

  void _pad(String name, bool down) {
    if (down) _buzz();
    widget.link.pad(name, down);
  }

  Widget _at(double x, double y, Widget child) => Positioned(left: x, top: y, child: child);

  @override
  Widget build(BuildContext context) {
    final connected = widget.link.connected;
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xff061030), Color(0xff08081c), Color(0xff1c0840)],
        ),
      ),
      child: FittedBox(
        fit: BoxFit.contain,
        child: SizedBox(
          width: 1000,
          height: 440,
          child: Stack(children: [
            // دسته‌های شانه‌ای
            _at(18, 12, _Shoulder('L1', kBlue, (d) => _pad('L1', d), 128)),
            _at(156, 12, _Shoulder('L2', kBlue, (d) => _pad('L2', d), 128)),
            _at(716, 12, _Shoulder('R2', kPurple, (d) => _pad('R2', d), 128)),
            _at(854, 12, _Shoulder('R1', kPurple, (d) => _pad('R1', d), 128)),

            // نوار وضعیت بالا
            _at(
              372,
              10,
              Container(
                width: 256,
                height: 46,
                decoration: BoxDecoration(
                  color: const Color(0xff0a0f22),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: kBlue.withOpacity(0.35)),
                ),
                child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  GestureDetector(
                    onTap: widget.onConnect,
                    child: Icon(connected ? Icons.wifi : Icons.wifi_off,
                        size: 26, color: connected ? kCyan : const Color(0xffffa23c)),
                  ),
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.battery_std, size: 22, color: Colors.white70),
                    const SizedBox(width: 4),
                    Text(battery >= 0 ? '$battery%' : '--', style: const TextStyle(color: Colors.white, fontSize: 15)),
                  ]),
                  GestureDetector(
                    onTap: widget.onSettings,
                    child: const Icon(Icons.settings, size: 26, color: Colors.white70),
                  ),
                ]),
              ),
            ),

            // پنل مرکزی «Game Mode» (لمس = منوی حالت‌ها)
            _at(
              352,
              78,
              GestureDetector(
                onTap: widget.onMenu,
                child: CustomPaint(
                  painter: _HexPainter(),
                  child: SizedBox(
                    width: 296,
                    height: 220,
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      const Icon(Icons.sports_esports, size: 84, color: Color(0xff8fc8ff)),
                      const SizedBox(height: 4),
                      const Text('Game Mode',
                          style: TextStyle(fontSize: 24, color: Color(0xff9fd0ff), fontWeight: FontWeight.w500)),
                    ]),
                  ),
                ),
              ),
            ),

            // دی‌پد
            _at(66, 92, DPad(size: 200, onChange: _pad)),

            // دکمه‌های اصلی
            _at(792, 92, FaceButton(kind: 'triangle', color: const Color(0xffffc21a), onChange: (d) => _pad('TRIANGLE', d))),
            _at(724, 160, FaceButton(kind: 'square', color: const Color(0xffff3cae), onChange: (d) => _pad('SQUARE', d))),
            _at(860, 160, FaceButton(kind: 'circle', color: const Color(0xffff2a3c), onChange: (d) => _pad('CIRCLE', d))),
            _at(792, 228, FaceButton(kind: 'cross', color: const Color(0xff2aff6a), onChange: (d) => _pad('CROSS', d))),

            // استیک‌ها
            _at(222, 262, PadStick(color: kBlue, onChanged: (x, y) => _stick('left', x, y))),
            _at(608, 262, PadStick(color: kPurple, onChanged: (x, y) => _stick('right', x, y))),

            // Select / Home / Start
            _at(408, 366, _Pill('Select', Icons.crop_square, (d) => _pad('SELECT', d), 66)),
            _at(476, 358, _RoundBtn(Icons.home, (d) => _pad('MODE', d))),
            _at(528, 366, _Pill('Start', Icons.play_arrow, (d) => _pad('START', d), 66)),
          ]),
        ),
      ),
    );
  }
}

class _HexPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size s) {
    final w = s.width, h = s.height;
    final path = Path()
      ..moveTo(w * 0.04, h * 0.02)
      ..lineTo(w * 0.96, h * 0.02)
      ..lineTo(w * 0.86, h * 0.45)
      ..lineTo(w * 0.80, h * 0.98)
      ..lineTo(w * 0.20, h * 0.98)
      ..lineTo(w * 0.14, h * 0.45)
      ..close();
    canvas.drawPath(path, Paint()..color = const Color(0xff0a0e20));
    final stroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..shader = const LinearGradient(colors: [kBlue, kPurple]).createShader(Offset.zero & s)
      ..maskFilter = const MaskFilter.blur(BlurStyle.solid, 4);
    canvas.drawPath(path, stroke);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

// ---------------- دکمه‌های شانه ----------------
class _Shoulder extends StatefulWidget {
  final String label;
  final Color color;
  final void Function(bool) onChange;
  final double w;
  const _Shoulder(this.label, this.color, this.onChange, this.w);
  @override
  State<_Shoulder> createState() => _ShoulderState();
}

class _ShoulderState extends State<_Shoulder> {
  bool down = false;
  void _set(bool v) {
    if (down == v) return;
    setState(() => down = v);
    widget.onChange(v);
  }

  @override
  Widget build(BuildContext context) => Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (_) => _set(true),
        onPointerUp: (_) => _set(false),
        onPointerCancel: (_) => _set(false),
        child: Container(
          width: widget.w,
          height: 58,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: const BorderRadius.only(
              topLeft: Radius.circular(22),
              topRight: Radius.circular(22),
              bottomLeft: Radius.circular(10),
              bottomRight: Radius.circular(10),
            ),
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: down ? [widget.color, widget.color.withOpacity(0.4)] : const [Color(0xff1b2036), Color(0xff0b0e1c)],
            ),
            border: Border.all(color: widget.color.withOpacity(down ? 1 : 0.5), width: 1.5),
            boxShadow: down ? [BoxShadow(color: widget.color.withOpacity(0.7), blurRadius: 16)] : const [],
          ),
          child: Text(widget.label, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.white)),
        ),
      );
}

class _Pill extends StatefulWidget {
  final String label;
  final IconData icon;
  final void Function(bool) onChange;
  final double w;
  const _Pill(this.label, this.icon, this.onChange, this.w);
  @override
  State<_Pill> createState() => _PillState();
}

class _PillState extends State<_Pill> {
  bool down = false;
  void _set(bool v) {
    if (down == v) return;
    setState(() => down = v);
    widget.onChange(v);
  }

  @override
  Widget build(BuildContext context) => Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (_) => _set(true),
        onPointerUp: (_) => _set(false),
        onPointerCancel: (_) => _set(false),
        child: Container(
          width: widget.w,
          height: 40,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            color: down ? kBlue.withOpacity(0.55) : const Color(0xff12172b),
            border: Border.all(color: kBlue.withOpacity(0.5)),
          ),
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(widget.icon, size: 14, color: Colors.white),
              const SizedBox(width: 3),
              Text(widget.label, style: const TextStyle(fontSize: 14, color: Colors.white)),
            ]),
          ),
        ),
      );
}

class _RoundBtn extends StatefulWidget {
  final IconData icon;
  final void Function(bool) onChange;
  const _RoundBtn(this.icon, this.onChange);
  @override
  State<_RoundBtn> createState() => _RoundBtnState();
}

class _RoundBtnState extends State<_RoundBtn> {
  bool down = false;
  void _set(bool v) {
    if (down == v) return;
    setState(() => down = v);
    widget.onChange(v);
  }

  @override
  Widget build(BuildContext context) => Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (_) => _set(true),
        onPointerUp: (_) => _set(false),
        onPointerCancel: (_) => _set(false),
        child: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: down ? kCyan.withOpacity(0.5) : const Color(0xff12172b),
            border: Border.all(color: Colors.white24),
          ),
          child: Icon(widget.icon, size: 26, color: Colors.white),
        ),
      );
}

// ---------------- دی‌پد ----------------
class DPad extends StatefulWidget {
  final double size;
  final void Function(String name, bool down) onChange;
  const DPad({super.key, required this.size, required this.onChange});
  @override
  State<DPad> createState() => _DPadState();
}

class _DPadState extends State<DPad> {
  final Set<String> _on = {};
  int? _ptr;

  void _eval(Offset p) {
    final c = Offset(widget.size / 2, widget.size / 2);
    final v = p - c;
    final r = widget.size / 2;
    final next = <String>{};
    if (v.distance > r * 0.18) {
      if (v.dx < -r * 0.28) next.add('LEFT');
      if (v.dx > r * 0.28) next.add('RIGHT');
      if (v.dy < -r * 0.28) next.add('UP');
      if (v.dy > r * 0.28) next.add('DOWN');
    }
    for (final n in _on.difference(next)) {
      widget.onChange(n, false);
    }
    for (final n in next.difference(_on)) {
      widget.onChange(n, true);
    }
    setState(() {
      _on
        ..clear()
        ..addAll(next);
    });
  }

  void _release() {
    for (final n in _on) {
      widget.onChange(n, false);
    }
    setState(() => _on.clear());
    _ptr = null;
  }

  @override
  Widget build(BuildContext context) => Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (e) {
          if (_ptr != null) return;
          _ptr = e.pointer;
          _eval(e.localPosition);
        },
        onPointerMove: (e) {
          if (e.pointer == _ptr) _eval(e.localPosition);
        },
        onPointerUp: (e) {
          if (e.pointer == _ptr) _release();
        },
        onPointerCancel: (e) {
          if (e.pointer == _ptr) _release();
        },
        child: CustomPaint(
          size: Size(widget.size, widget.size),
          painter: _DPadPainter(Set.of(_on)),
        ),
      );
}

class _DPadPainter extends CustomPainter {
  final Set<String> on;
  _DPadPainter(this.on);

  @override
  void paint(Canvas canvas, Size s) {
    final c = s.center(Offset.zero);
    final r = s.width / 2;
    // زیرلایه گرد
    canvas.drawCircle(c, r * 0.98, Paint()..color = const Color(0xff0a0e20));
    final arm = r * 0.34; // نصف عرض بازو
    final len = r * 0.92;
    RRect rr(Rect rect) => RRect.fromRectAndRadius(rect, const Radius.circular(14));
    final arms = <String, Rect>{
      'UP': Rect.fromLTRB(c.dx - arm, c.dy - len, c.dx + arm, c.dy - arm * 0.2),
      'DOWN': Rect.fromLTRB(c.dx - arm, c.dy + arm * 0.2, c.dx + arm, c.dy + len),
      'LEFT': Rect.fromLTRB(c.dx - len, c.dy - arm, c.dx - arm * 0.2, c.dy + arm),
      'RIGHT': Rect.fromLTRB(c.dx + arm * 0.2, c.dy - arm, c.dx + len, c.dy + arm),
    };
    final center = Rect.fromCenter(center: c, width: arm * 2, height: arm * 2);
    final glow = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3
      ..color = kCyan
      ..maskFilter = const MaskFilter.blur(BlurStyle.solid, 5);
    for (final e in arms.entries) {
      final lit = on.contains(e.key);
      canvas.drawRRect(rr(e.value), Paint()..color = lit ? kCyan.withOpacity(0.55) : const Color(0xff0f1530));
      canvas.drawRRect(rr(e.value), glow);
    }
    canvas.drawRRect(rr(center), Paint()..color = const Color(0xff0f1530));
    // مثلث‌ها
    final tri = Paint()..color = kBlue;
    void t(Offset p, double ang) {
      canvas.save();
      canvas.translate(p.dx, p.dy);
      canvas.rotate(ang);
      final path = Path()
        ..moveTo(0, -11)
        ..lineTo(11, 9)
        ..lineTo(-11, 9)
        ..close();
      canvas.drawPath(path, tri);
      canvas.restore();
    }

    t(Offset(c.dx, c.dy - len * 0.66), 0);
    t(Offset(c.dx, c.dy + len * 0.66), math.pi);
    t(Offset(c.dx - len * 0.66, c.dy), -math.pi / 2);
    t(Offset(c.dx + len * 0.66, c.dy), math.pi / 2);
  }

  @override
  bool shouldRepaint(covariant _DPadPainter old) => old.on.length != on.length || !old.on.containsAll(on);
}

// ---------------- دکمه‌های اصلی (△ □ ○ ✕) ----------------
class FaceButton extends StatefulWidget {
  final String kind;
  final Color color;
  final void Function(bool) onChange;
  const FaceButton({super.key, required this.kind, required this.color, required this.onChange});
  @override
  State<FaceButton> createState() => _FaceButtonState();
}

class _FaceButtonState extends State<FaceButton> {
  bool down = false;
  void _set(bool v) {
    if (down == v) return;
    setState(() => down = v);
    widget.onChange(v);
  }

  @override
  Widget build(BuildContext context) => Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (_) => _set(true),
        onPointerUp: (_) => _set(false),
        onPointerCancel: (_) => _set(false),
        child: Container(
          width: 76,
          height: 76,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: down ? widget.color.withOpacity(0.35) : const Color(0xff0c1020),
            border: Border.all(color: widget.color.withOpacity(0.35), width: 2),
            boxShadow: down ? [BoxShadow(color: widget.color.withOpacity(0.8), blurRadius: 18)] : const [],
          ),
          child: CustomPaint(painter: _SymbolPainter(widget.kind, widget.color)),
        ),
      );
}

class _SymbolPainter extends CustomPainter {
  final String kind;
  final Color color;
  _SymbolPainter(this.kind, this.color);

  @override
  void paint(Canvas canvas, Size s) {
    final c = s.center(Offset.zero);
    final p = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..color = color;
    final g = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 7
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..color = color.withOpacity(0.6)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 5);
    void draw(Path path) {
      canvas.drawPath(path, g);
      canvas.drawPath(path, p);
    }

    switch (kind) {
      case 'triangle':
        draw(Path()
          ..moveTo(c.dx, c.dy - 20)
          ..lineTo(c.dx + 21, c.dy + 15)
          ..lineTo(c.dx - 21, c.dy + 15)
          ..close());
        break;
      case 'square':
        draw(Path()..addRRect(RRect.fromRectAndRadius(Rect.fromCenter(center: c, width: 36, height: 36), const Radius.circular(3))));
        break;
      case 'circle':
        draw(Path()..addOval(Rect.fromCenter(center: c, width: 40, height: 40)));
        break;
      default:
        draw(Path()
          ..moveTo(c.dx - 18, c.dy - 18)
          ..lineTo(c.dx + 18, c.dy + 18)
          ..moveTo(c.dx + 18, c.dy - 18)
          ..lineTo(c.dx - 18, c.dy + 18));
    }
  }

  @override
  bool shouldRepaint(covariant _SymbolPainter old) => false;
}

// ---------------- استیک آنالوگ ----------------
class PadStick extends StatefulWidget {
  final Color color;
  final void Function(double x, double y) onChanged;
  const PadStick({super.key, required this.color, required this.onChanged});
  @override
  State<PadStick> createState() => _PadStickState();
}

class _PadStickState extends State<PadStick> {
  static const double size = 170;
  static const double maxR = 46;
  Offset knob = Offset.zero;
  int? _ptr;

  void _update(Offset local) {
    var v = local - const Offset(size / 2, size / 2);
    if (v.distance > maxR) v = v / v.distance * maxR;
    setState(() => knob = v);
    widget.onChanged(v.dx / maxR, v.dy / maxR);
  }

  void _release() {
    _ptr = null;
    setState(() => knob = Offset.zero);
    widget.onChanged(0, 0);
  }

  @override
  Widget build(BuildContext context) {
    final active = knob != Offset.zero;
    return Listener(
      behavior: HitTestBehavior.opaque,
      onPointerDown: (e) {
        if (_ptr != null) return;
        _ptr = e.pointer;
        _update(e.localPosition);
      },
      onPointerMove: (e) {
        if (e.pointer == _ptr) _update(e.localPosition);
      },
      onPointerUp: (e) {
        if (e.pointer == _ptr) _release();
      },
      onPointerCancel: (e) {
        if (e.pointer == _ptr) _release();
      },
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: const Color(0xff090c1a),
          border: Border.all(color: widget.color, width: 7),
          boxShadow: [BoxShadow(color: widget.color.withOpacity(active ? 0.85 : 0.5), blurRadius: active ? 22 : 14)],
        ),
        child: Transform.translate(
          offset: knob,
          child: Center(
            child: Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: const RadialGradient(colors: [Color(0xff3a3f55), Color(0xff14172a)]),
                border: Border.all(color: Colors.white12, width: 3),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
