import 'dart:async';

import 'package:flutter/services.dart';

import 'link.dart';

/// موس هوایی: چرخاندن گوشی (حالت عمودی) نشانگر را حرکت می‌دهد.
///  • چرخش به چپ/راست (حول محور عمودی) = حرکت افقی
///  • بالا/پایین کردن سر گوشی = حرکت عمودی
class GyroMouse {
  static const EventChannel _ch = EventChannel('abtin/gyro');
  StreamSubscription<dynamic>? _sub;
  final Stopwatch _sw = Stopwatch();

  bool get running => _sub != null;

  /// [gain] = حساسیت (۱ = پیش‌فرض)
  void start(WifiLink link, double Function() gain, {void Function()? onError}) {
    if (_sub != null) return;
    _sw.reset();
    _sw.start();
    var last = 0;
    _sub = _ch.receiveBroadcastStream().listen((dynamic ev) {
      if (ev is! List || ev.length < 3) return;
      final now = _sw.elapsedMilliseconds;
      final dt = last == 0 ? 0.016 : ((now - last) / 1000.0).clamp(0.004, 0.05);
      last = now;
      final gx = (ev[0] as num).toDouble(); // بالا/پایین
      final gy = (ev[1] as num).toDouble(); // چپ/راست
      const dead = 0.03; // نویز ژیرو
      final fx = gy.abs() < dead ? 0.0 : gy;
      final fy = gx.abs() < dead ? 0.0 : gx;
      if (fx == 0 && fy == 0) return;
      final k = 520.0 * gain() * dt;
      link.move(-fx * k, fy * k);
    }, onError: (Object _) {
      stop();
      onError?.call();
    });
  }

  void stop() {
    _sub?.cancel();
    _sub = null;
    _sw.stop();
  }
}
