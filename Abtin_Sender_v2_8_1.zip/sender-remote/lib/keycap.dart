import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'theme.dart';

/// یک کلید نئونی. با لمس بلافاصله onDown صدا زده می‌شود؛ اگر repeat=true باشد
/// با نگه داشتن، تکرار می‌شود (برای Backspace و جهت‌ها).
class KeyCap extends StatefulWidget {
  final String label;
  final String? sub;
  final IconData? icon;
  final Color color;
  final bool active;
  final bool repeat;
  final bool haptics;
  final double fontScale;
  final Color? iconColor;
  final VoidCallback onDown;

  const KeyCap({
    super.key,
    required this.label,
    required this.color,
    required this.onDown,
    this.sub,
    this.icon,
    this.active = false,
    this.repeat = false,
    this.haptics = true,
    this.fontScale = 1.0,
    this.iconColor,
  });

  @override
  State<KeyCap> createState() => _KeyCapState();
}

class _KeyCapState extends State<KeyCap> {
  bool _down = false;
  Timer? _delay;
  Timer? _rep;

  void _stop() {
    _delay?.cancel();
    _rep?.cancel();
    _delay = null;
    _rep = null;
  }

  void _press() {
    if (_down) return;
    setState(() => _down = true);
    if (widget.haptics) HapticFeedback.selectionClick();
    widget.onDown();
    if (widget.repeat) {
      _delay = Timer(const Duration(milliseconds: 420), () {
        _rep = Timer.periodic(const Duration(milliseconds: 55), (_) => widget.onDown());
      });
    }
  }

  void _release() {
    _stop();
    if (_down && mounted) setState(() => _down = false);
  }

  @override
  void dispose() {
    _stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final lit = _down || widget.active;
    return RepaintBoundary(
      child: Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (_) => _press(),
        onPointerUp: (_) => _release(),
        onPointerCancel: (_) => _release(),
        child: LayoutBuilder(builder: (context, c) {
          final base = (c.maxHeight < c.maxWidth ? c.maxHeight : c.maxWidth);
          final fs = (base * 0.42 * widget.fontScale).clamp(8.0, 26.0);
          final subFs = (base * 0.22).clamp(6.0, 12.0);
          return Container(
            decoration: neonBox(widget.color, pressed: lit),
            child: Stack(children: [
              Center(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 2),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: widget.icon != null
                        ? Icon(widget.icon, size: fs * 1.05, color: widget.iconColor ?? Colors.white)
                        : Text(
                            widget.label,
                            maxLines: 1,
                            style: TextStyle(
                              fontSize: fs,
                              fontWeight: FontWeight.w600,
                              color: Colors.white,
                              shadows: [Shadow(color: widget.color.withOpacity(0.9), blurRadius: 6)],
                            ),
                          ),
                  ),
                ),
              ),
              if (widget.sub != null && widget.sub!.isNotEmpty)
                Positioned(
                  right: 3,
                  top: 1,
                  child: Text(widget.sub!,
                      style: TextStyle(fontSize: subFs, color: Colors.white.withOpacity(0.62), height: 1.1)),
                ),
            ]),
          );
        }),
      ),
    );
  }
}
