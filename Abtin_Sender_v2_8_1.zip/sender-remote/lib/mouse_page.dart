import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'gyro.dart';
import 'keycap.dart';
import 'link.dart';
import 'theme.dart';
import 'touchpad.dart';

class MousePage extends StatelessWidget {
  final WifiLink link;
  final PadSettings settings;
  final VoidCallback onMenu;
  const MousePage({super.key, required this.link, required this.settings, required this.onMenu});

  Widget _hold(String label, String button, Color c, {bool horizontal = false}) => Expanded(
        child: Padding(
          padding: horizontal ? const EdgeInsets.symmetric(horizontal: 3) : const EdgeInsets.symmetric(vertical: 3),
          child: _HoldBtn(label: label, color: c, haptics: settings.haptics, onChange: (d) => link.mouseButton(button, d)),
        ),
      );

  Widget _quick(String label, IconData icon, String key, Color c) => Expanded(
        child: Padding(
          padding: const EdgeInsets.all(3),
          child: KeyCap(
            label: label,
            icon: icon,
            color: c,
            fontScale: 0.7,
            haptics: settings.haptics,
            onDown: () => link.key(key),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    if (MediaQuery.of(context).orientation == Orientation.portrait) return _portrait();
    return _landscape();
  }

  Widget _portrait() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xff070b1c), Color(0xff0d0720)],
        ),
      ),
      padding: const EdgeInsets.all(10),
      child: Column(children: [
        Expanded(child: GestureTouchpad(link: link, settings: settings)),
        const SizedBox(height: 10),
        SizedBox(
          height: 72,
          child: Row(children: [
            _hold('کلیک چپ', 'left', kCyan, horizontal: true),
            _hold('وسط', 'middle', kPurple, horizontal: true),
            _hold('کلیک راست', 'right', kMagenta, horizontal: true),
          ]),
        ),
        const SizedBox(height: 6),
        SizedBox(
          height: 58,
          child: Row(children: [
            _quick('بک', Icons.arrow_back, 'BACK', kBlue),
            _quick('خانه', Icons.home, 'HOME', kBlue),
            _quick('اخیر', Icons.crop_square, 'RECENTS', kBlue),
            _quick('بالا', Icons.keyboard_double_arrow_up, 'PAGEUP', kPurple),
            _quick('پایین', Icons.keyboard_double_arrow_down, 'PAGEDOWN', kPurple),
            Expanded(child: Padding(padding: const EdgeInsets.all(3), child: _GyroToggle(link: link, settings: settings))),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(3),
                child: KeyCap(label: 'منو', icon: Icons.apps, color: kMagenta, fontScale: 0.7, haptics: settings.haptics, onDown: onMenu),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _landscape() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xff070b1c), Color(0xff0d0720)],
        ),
      ),
      padding: const EdgeInsets.all(8),
      child: Row(children: [
        Expanded(child: GestureTouchpad(link: link, settings: settings)),
        const SizedBox(width: 10),
        SizedBox(
          width: 210,
          child: Column(children: [
            _hold('کلیک چپ', 'left', kCyan),
            _hold('وسط', 'middle', kPurple),
            _hold('کلیک راست', 'right', kMagenta),
            SizedBox(
              height: 52,
              child: Row(children: [
                _quick('بک', Icons.arrow_back, 'BACK', kBlue),
                _quick('خانه', Icons.home, 'HOME', kBlue),
                _quick('اخیر', Icons.crop_square, 'RECENTS', kBlue),
              ]),
            ),
            SizedBox(
              height: 52,
              child: Row(children: [
                _quick('بالا', Icons.keyboard_double_arrow_up, 'PAGEUP', kPurple),
                _quick('پایین', Icons.keyboard_double_arrow_down, 'PAGEDOWN', kPurple),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(3),
                    child: KeyCap(label: 'منو', icon: Icons.apps, color: kMagenta, fontScale: 0.7, haptics: settings.haptics, onDown: onMenu),
                  ),
                ),
              ]),
            ),
          ]),
        ),
      ]),
    );
  }
}

class _HoldBtn extends StatefulWidget {
  final String label;
  final Color color;
  final bool haptics;
  final void Function(bool down) onChange;
  const _HoldBtn({required this.label, required this.color, required this.haptics, required this.onChange});
  @override
  State<_HoldBtn> createState() => _HoldBtnState();
}

class _HoldBtnState extends State<_HoldBtn> {
  bool down = false;
  void _set(bool v) {
    if (down == v) return;
    setState(() => down = v);
    widget.onChange(v);
    if (v && widget.haptics) HapticFeedback.selectionClick();
  }

  @override
  Widget build(BuildContext context) => Listener(
        behavior: HitTestBehavior.opaque,
        onPointerDown: (_) => _set(true),
        onPointerUp: (_) => _set(false),
        onPointerCancel: (_) => _set(false),
        child: Container(
          alignment: Alignment.center,
          decoration: neonBox(widget.color, pressed: down, radius: 14),
          child: Text(widget.label, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
        ),
      );
}

/// دکمه‌ی روشن/خاموش موس هوایی (ژیروسکوپ)
class _GyroToggle extends StatefulWidget {
  final WifiLink link;
  final PadSettings settings;
  const _GyroToggle({required this.link, required this.settings});
  @override
  State<_GyroToggle> createState() => _GyroToggleState();
}

class _GyroToggleState extends State<_GyroToggle> {
  final GyroMouse _g = GyroMouse();

  void _toggle() {
    if (_g.running) {
      _g.stop();
    } else {
      _g.start(widget.link, () => widget.settings.gyroSens, onError: () {
        if (mounted) {
          setState(() {});
          ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('این گوشی ژیروسکوپ ندارد')));
        }
      });
    }
    setState(() {});
  }

  @override
  void dispose() {
    _g.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => KeyCap(
        label: 'ژیرو',
        icon: Icons.screen_rotation,
        color: kCyan,
        active: _g.running,
        fontScale: 0.7,
        haptics: widget.settings.haptics,
        onDown: _toggle,
      );
}
