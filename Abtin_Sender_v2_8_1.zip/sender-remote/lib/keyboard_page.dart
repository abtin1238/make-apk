import 'package:flutter/material.dart';

import 'keycap.dart';
import 'link.dart';
import 'theme.dart';
import 'touchpad.dart';

class _Ch {
  final String id; // شناسه (حرف انگلیسی کوچک / نماد)
  final String en, enS, fa, faS;
  final double w;
  const _Ch(this.id, this.en, this.enS, this.fa, this.faS, [this.w = 1]);
  bool get isLetter => RegExp(r'^[a-z]$').hasMatch(en);
}

class _Item {
  final double w;
  final Widget Function(Color c)? build;
  const _Item(this.w, this.build);
}

// ---------- چیدمان حروف (انگلیسی + فارسی استاندارد) ----------
const _rowNum = [
  _Ch('`', '`', '~', '\u200c', '÷'),
  _Ch('1', '1', '!', '۱', '!'),
  _Ch('2', '2', '@', '۲', '٬'),
  _Ch('3', '3', '#', '۳', '٫'),
  _Ch('4', '4', '\$', '۴', '﷼'),
  _Ch('5', '5', '%', '۵', '٪'),
  _Ch('6', '6', '^', '۶', '×'),
  _Ch('7', '7', '&', '۷', '،'),
  _Ch('8', '8', '*', '۸', '*'),
  _Ch('9', '9', '(', '۹', ')'),
  _Ch('0', '0', ')', '۰', '('),
  _Ch('-', '-', '_', '-', '_'),
  _Ch('=', '=', '+', '=', '+'),
];
const _rowQ = [
  _Ch('q', 'q', 'Q', 'ض', 'ْ'),
  _Ch('w', 'w', 'W', 'ص', 'ٌ'),
  _Ch('e', 'e', 'E', 'ث', 'ٍ'),
  _Ch('r', 'r', 'R', 'ق', 'ً'),
  _Ch('t', 't', 'T', 'ف', 'ُ'),
  _Ch('y', 'y', 'Y', 'غ', 'ِ'),
  _Ch('u', 'u', 'U', 'ع', 'َ'),
  _Ch('i', 'i', 'I', 'ه', 'ّ'),
  _Ch('o', 'o', 'O', 'خ', ']'),
  _Ch('p', 'p', 'P', 'ح', '['),
  _Ch('[', '[', '{', 'ج', '}'),
  _Ch(']', ']', '}', 'چ', '{'),
];
const _backslash = _Ch('\\', '\\', '|', '\\', '|', 1.5);
const _rowA = [
  _Ch('a', 'a', 'A', 'ش', 'ؤ'),
  _Ch('s', 's', 'S', 'س', 'ئ'),
  _Ch('d', 'd', 'D', 'ی', 'ي'),
  _Ch('f', 'f', 'F', 'ب', 'إ'),
  _Ch('g', 'g', 'G', 'ل', 'أ'),
  _Ch('h', 'h', 'H', 'ا', 'آ'),
  _Ch('j', 'j', 'J', 'ت', 'ة'),
  _Ch('k', 'k', 'K', 'ن', '»'),
  _Ch('l', 'l', 'L', 'م', '«'),
  _Ch(';', ';', ':', 'ک', ':'),
  _Ch("'", "'", '"', 'گ', '؛'),
];
const _rowZ = [
  _Ch('z', 'z', 'Z', 'ظ', 'ك'),
  _Ch('x', 'x', 'X', 'ط', 'ٓ'),
  _Ch('c', 'c', 'C', 'ز', 'ژ'),
  _Ch('v', 'v', 'V', 'ر', 'ٰ'),
  _Ch('b', 'b', 'B', 'ذ', 'ٔ'),
  _Ch('n', 'n', 'N', 'د', 'ء'),
  _Ch('m', 'm', 'M', 'پ', '>'),
  _Ch(',', ',', '<', 'و', '<'),
  _Ch('.', '.', '>', '.', '>'),
  _Ch('/', '/', '?', '/', '؟'),
];

// کلیدهای F به‌جای F1..F12 کار «سیستم/مدیا» انجام می‌دهند
const _fKeys = <List<String>>[
  ['F1', 'BACK', 'بک'],
  ['F2', 'HOME', 'خانه'],
  ['F3', 'RECENTS', 'اخیر'],
  ['F4', 'QUICK_SETTINGS', 'تنظیم'],
  ['F5', 'PREV', '⏮'],
  ['F6', 'PLAY_PAUSE', '⏯'],
  ['F7', 'NEXT', '⏭'],
  ['F8', 'MUTE', 'بی‌صدا'],
  ['F9', 'VOL_DOWN', 'صدا−'],
  ['F10', 'VOL_UP', 'صدا+'],
  ['F11', 'COPY', 'کپی'],
  ['F12', 'PASTE', 'پیست'],
];

class KeyboardPage extends StatefulWidget {
  final WifiLink link;
  final PadSettings settings;
  final VoidCallback onMenu;
  final VoidCallback onConnect;
  final VoidCallback onSettings;
  const KeyboardPage({
    super.key,
    required this.link,
    required this.settings,
    required this.onMenu,
    required this.onConnect,
    required this.onSettings,
  });
  @override
  State<KeyboardPage> createState() => _KeyboardPageState();
}

class _KeyboardPageState extends State<KeyboardPage> {
  static const double _total = 22.4;
  bool shift = false, caps = false, ctrl = false, alt = false, fa = false;

  WifiLink get link => widget.link;

  // ---------- منطق کلیدها ----------
  String _main(_Ch c) {
    if (fa) return shift ? c.faS : c.fa;
    if (c.isLetter) return (shift != caps) ? c.enS : c.en;
    return shift ? c.enS : c.en;
  }

  String _subOf(_Ch c) {
    final s = fa ? (c.isLetter ? c.en.toUpperCase() : c.en) : c.fa;
    return s == '\u200c' ? '' : s;
  }

  String _display(String s) => s == '\u200c' ? 'ZWNJ' : s;

  void _clearOneShot({bool keepShift = false}) {
    if ((shift && !keepShift) || ctrl || alt) {
      setState(() {
        if (!keepShift) shift = false;
        ctrl = false;
        alt = false;
      });
    }
  }

  void _typeChar(_Ch c) {
    if (ctrl) {
      const map = {'a': 'SELECT_ALL', 'c': 'COPY', 'x': 'CUT', 'v': 'PASTE'};
      final k = map[c.en];
      if (k != null) link.key(k);
    } else {
      final ch = _main(c);
      if (ch.isNotEmpty) link.text(ch);
    }
    _clearOneShot();
  }

  void _sys(String key) {
    link.key(key);
    _clearOneShot();
  }

  void _tab() {
    if (alt) {
      link.key('RECENTS');
    } else {
      link.key('TAB');
    }
    _clearOneShot();
  }

  // ---------- ساخت اجزا ----------
  Widget _charKey(_Ch c, Color col) => KeyCap(
        label: _display(_main(c)),
        sub: _subOf(c),
        color: col,
        haptics: widget.settings.haptics,
        onDown: () => _typeChar(c),
      );

  _Item _ch(_Ch c) => _Item(c.w, (col) => _charKey(c, col));

  _Item _key(
    String label,
    double w,
    VoidCallback onDown, {
    String? sub,
    IconData? icon,
    bool active = false,
    bool repeat = false,
    Color? iconColor,
    double fontScale = 0.8,
  }) =>
      _Item(
        w,
        (col) => KeyCap(
          label: label,
          sub: sub,
          icon: icon,
          color: col,
          active: active,
          repeat: repeat,
          iconColor: iconColor,
          fontScale: fontScale,
          haptics: widget.settings.haptics,
          onDown: onDown,
        ),
      );

  _Item _gap(double w) => _Item(w, null);

  Widget _row(double x0, List<_Item> items, {int flex = 100}) {
    var x = x0;
    final cells = <Widget>[];
    for (final it in items) {
      final col = neonSmooth((x + it.w / 2) / _total);
      x += it.w;
      cells.add(Expanded(
        flex: (it.w * 100).round(),
        child: it.build == null
            ? const SizedBox.shrink()
            : Padding(padding: const EdgeInsets.all(2), child: it.build!(col)),
      ));
    }
    return Expanded(flex: flex, child: Row(children: cells));
  }

  @override
  Widget build(BuildContext context) {
    final connected = link.connected;

    final fRow = <_Item>[
      _key('Esc', 1, () => _sys('ESC'), sub: 'بک'),
      _gap(1),
      for (var i = 0; i < 12; i++) ...[
        if (i == 4 || i == 8) _gap(0.5),
        _key(_fKeys[i][0], 1, () => _sys(_fKeys[i][1]), sub: _fKeys[i][2], fontScale: 0.75),
      ],
    ];

    final rows = <Widget>[
      _row(0, fRow, flex: 80),
      const SizedBox(height: 6),
      _row(0, [
        for (final c in _rowNum) _ch(c),
        _key('⌫', 2, () => _sys('BACKSPACE'), icon: Icons.backspace_outlined, repeat: true),
      ]),
      _row(0, [
        _key('Tab', 1.5, _tab, sub: 'Alt: اخیر'),
        for (final c in _rowQ) _ch(c),
        _ch(_backslash),
      ]),
      _row(0, [
        _key('Caps', 1.75, () => setState(() => caps = !caps), active: caps),
        for (final c in _rowA) _ch(c),
        _key('Enter', 2.25, () => _sys('ENTER'), icon: Icons.keyboard_return),
      ]),
      _row(0, [
        _key('Shift', 2.25, () => setState(() => shift = !shift), icon: Icons.arrow_upward, active: shift),
        for (final c in _rowZ) _ch(c),
        _key('Shift', 2.75, () => setState(() => shift = !shift), icon: Icons.arrow_upward, active: shift),
      ]),
      _row(0, [
        _key('Ctrl', 1.25, () => setState(() => ctrl = !ctrl), active: ctrl, sub: 'C V X A'),
        _key('Win', 1.25, () => _sys('HOME'), icon: Icons.window, sub: 'خانه'),
        _key('Alt', 1.25, () => setState(() => alt = !alt), active: alt),
        _key('Space', 6.25, () => _sys('SPACE'), icon: Icons.space_bar),
        _key('Alt', 1.25, () => setState(() => alt = !alt), active: alt),
        _key('Fn', 1.25, () => setState(() => fa = !fa), active: fa, sub: fa ? 'فا' : 'EN'),
        _key('▤', 1.25, () => _sys('NOTIFICATIONS'), icon: Icons.notifications_none, sub: 'اعلان'),
        _key('Ctrl', 1.25, () => setState(() => ctrl = !ctrl), active: ctrl),
      ]),
    ];

    // ---------- ستون ناوبری ----------
    const nx = 15.3;
    final nav = <Widget>[
      _row(nx, [
        _key('menu', 1, widget.onMenu, icon: Icons.apps),
        _key('wifi', 1, widget.onConnect,
            icon: connected ? Icons.wifi : Icons.wifi_off,
            iconColor: connected ? const Color(0xff3dff8f) : const Color(0xffffa23c)),
        _key('set', 1, widget.onSettings, icon: Icons.settings),
      ], flex: 80),
      const SizedBox(height: 6),
      _row(nx, [
        _key('Paste', 1, () => _sys('PASTE'), sub: 'Ins', fontScale: 0.6),
        _key('Home', 1, () => _sys('LINE_START'), fontScale: 0.6),
        _key('PgUp', 1, () => _sys('PAGEUP'), repeat: true, fontScale: 0.6),
      ]),
      _row(nx, [
        _key('Del', 1, () => _sys('DELETE'), repeat: true, fontScale: 0.6),
        _key('End', 1, () => _sys('LINE_END'), fontScale: 0.6),
        _key('PgDn', 1, () => _sys('PAGEDOWN'), repeat: true, fontScale: 0.6),
      ]),
      Expanded(flex: 100, child: const SizedBox.shrink()),
      _row(nx, [
        _gap(1),
        _key('↑', 1, () => _sys('UP'), icon: Icons.arrow_upward, repeat: true),
        _gap(1),
      ]),
      _row(nx, [
        _key('←', 1, () => _sys('LEFT'), icon: Icons.arrow_back, repeat: true),
        _key('↓', 1, () => _sys('DOWN'), icon: Icons.arrow_downward, repeat: true),
        _key('→', 1, () => _sys('RIGHT'), icon: Icons.arrow_forward, repeat: true),
      ]),
    ];

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xff070b1c), Color(0xff0d0720)],
        ),
      ),
      padding: const EdgeInsets.fromLTRB(6, 4, 6, 4),
      child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Expanded(flex: 1500, child: Column(children: rows)),
        const SizedBox(width: 6),
        Expanded(flex: 300, child: Column(children: nav)),
        const SizedBox(width: 6),
        Expanded(
          flex: 380,
          child: Padding(
            padding: const EdgeInsets.all(2),
            child: GestureTouchpad(link: link, settings: widget.settings, compact: true),
          ),
        ),
      ]),
    );
  }
}
