import 'package:flutter/material.dart';

const Color kBg = Color(0xff05070f);
const Color kPanel = Color(0xff0c1020);
const Color kKey = Color(0xff10152a);
const Color kBlue = Color(0xff2f7bff);
const Color kCyan = Color(0xff18d4ff);
const Color kPurple = Color(0xffa23cff);
const Color kMagenta = Color(0xffff3cf0);
const Color kHint = Color(0xff8fa3d6);

Color neonSmooth(double t) =>
    Color.lerp(kBlue, kMagenta, Curves.easeInOut.transform(t.clamp(0.0, 1.0)))!;

BoxDecoration neonBox(Color c,
    {bool pressed = false, double radius = 8, double glow = 7}) {
  return BoxDecoration(
    borderRadius: BorderRadius.circular(radius),
    gradient: LinearGradient(
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
      colors: pressed
          ? [c.withOpacity(0.85), c.withOpacity(0.45)]
          : const [Color(0xff1a2038), Color(0xff0a0d1c)],
    ),
    border: Border.all(color: c.withOpacity(pressed ? 1 : 0.9), width: 1.4),
    boxShadow: [
      BoxShadow(color: c.withOpacity(pressed ? 0.8 : 0.45), blurRadius: pressed ? glow * 2 : glow),
    ],
  );
}
