#!/bin/sh
# Runs inside an arm64 Alpine container (see .github/workflows/build-proot.yml).
# Builds a fully static PRoot v5.5.0 (has statx support) for Android arm64,
# following upstream's own static recipe (.github/workflows/release.yml).
set -eu
apk add --no-cache build-base linux-headers pkgconf talloc-dev uthash-dev unzip file binutils patch >/dev/null
apk add --no-cache talloc-static >/dev/null 2>&1 || true
rm -rf /tmp/pb && mkdir /tmp/pb && cd /tmp/pb
unzip -q "/w/${ZIP_PATH:-tools/proot/v5_5_0_source_code.zip}"
cd proot-*
patch -p1 < /w/tools/proot/abtin-enosys.patch
export WITHOUT_PYTHON=1
make -C src clean loader.elf build.h WITHOUT_PYTHON=1 CPPFLAGS="-I/usr/include"
LDFLAGS="-static" make -C src proot WITHOUT_PYTHON=1 CPPFLAGS="-I/usr/include"
mkdir -p /w/out
strip src/proot
cp src/proot /w/out/libproot.so
[ -f src/loader.elf ] && cp src/loader.elf /w/out/libproot-loader.so || echo "no separate loader.elf"
file /w/out/libproot.so
src/proot --version | head -3 || true
echo "statx mentions: $(strings -a /w/out/libproot.so | grep -c statx || true)"
ls -la /w/out
