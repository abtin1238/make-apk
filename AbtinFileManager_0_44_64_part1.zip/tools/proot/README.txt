PRoot 5.1.0 (bundled in jniLibs) has no statx support -> GNU tools and Node fail to find any path.
This folder builds PRoot 5.5.0 from the supplied source (v5_5_0_source_code.zip).

1. Push the project to GitHub, open Actions -> "Build PRoot 5.5.0 (arm64, static)" -> Run workflow.
2. Download artifact proot-5.5.0-arm64 (contains libproot.so and, if built, libproot-loader.so).
3. Copy them into android/app/src/main/jniLibs/arm64-v8a/ (replace libproot.so; keep libproot-loader32.so).
4. Rebuild the app. UNTESTED: the build has not been run yet.
