#!/usr/bin/env node
// Abtin Node.js debug adapter (no dependencies): starts SCRIPT with --inspect-brk,
// talks to V8's inspector over a tiny WebSocket client and speaks the same
// terminal protocol as abtin_pydbg.py.
//
//   node abtin_nodedbg.js --root DIR [--entry] [--all] SCRIPT [ARGS...]
//   adapter -> app : \x1fABTIN_DBG:{json}\x1f   (the program writes to the same terminal)
//   app -> adapter : one JSON object per line on stdin (only read while paused)
'use strict';
const cp = require('child_process');
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');
const { pathToFileURL, fileURLToPath } = require('url');

const MARK = '\x1fABTIN_DBG:';
const END = '\x1f';
function emit(o) { process.stdout.write(MARK + JSON.stringify(o) + END); }

// ---------------- arguments ----------------
const argv = process.argv.slice(2);
let ROOT = null, ENTRY = false, ALL = false, i0 = 0;
for (; i0 < argv.length; i0++) {
  if (argv[i0] === '--root') ROOT = argv[++i0];
  else if (argv[i0] === '--entry') ENTRY = true;
  else if (argv[i0] === '--all') ALL = true;
  else break;
}
if (i0 >= argv.length) { process.stderr.write('usage: abtin_nodedbg.js --root DIR [--entry] [--all] SCRIPT [ARGS]\n'); process.exit(2); }
const SCRIPT = path.resolve(argv[i0]);
const ARGS = argv.slice(i0 + 1);
if (!ROOT) ROOT = path.dirname(SCRIPT);
ROOT = path.resolve(ROOT);
let ROOT_REAL = ROOT;
try { ROOT_REAL = fs.realpathSync(ROOT); } catch (e) { /* keep */ }

// script path as V8 reports it -> path the app knows
function toApp(p) {
  if (p === ROOT_REAL) return ROOT;
  if (p.startsWith(ROOT_REAL + path.sep)) return ROOT + p.slice(ROOT_REAL.length);
  return p;
}
function isMine(p) {
  if (!p || p.startsWith('node:')) return false;
  if (ALL) return true;
  if (p.includes(path.sep + 'node_modules' + path.sep)) return false;
  return p.startsWith(ROOT + path.sep) || p.startsWith(ROOT_REAL + path.sep) || p === SCRIPT;
}
function urlToPath(u) {
  if (!u) return '';
  if (u.startsWith('file://')) { try { return fileURLToPath(u); } catch (e) { return u; } }
  return u;
}

// ---------------- minimal WebSocket client ----------------
class Ws extends EventEmitter {
  constructor(sock, head) {
    super();
    this.sock = sock; this.buf = Buffer.alloc(0); this.frag = [];
    sock.on('data', (d) => this._data(d));
    sock.on('close', () => this.emit('close'));
    sock.on('error', () => {});
    if (head && head.length) this._data(head);
  }
  _data(d) {
    this.buf = Buffer.concat([this.buf, d]);
    for (;;) {
      const b = this.buf;
      if (b.length < 2) return;
      const fin = !!(b[0] & 0x80), op = b[0] & 0x0f;
      let len = b[1] & 0x7f, off = 2;
      if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
      const masked = !!(b[1] & 0x80);
      if (masked) off += 4;
      if (b.length < off + len) return;
      let payload = Buffer.from(b.subarray(off, off + len));
      if (masked) { const m = b.subarray(off - 4, off); for (let i = 0; i < payload.length; i++) payload[i] ^= m[i % 4]; }
      this.buf = b.subarray(off + len);
      if (op === 0x8) { this.sock.end(); return; }
      if (op === 0x9) { this._frame(0x8a, payload); continue; }
      if (op === 0x1 || op === 0x0) {
        this.frag.push(payload);
        if (fin) { const msg = Buffer.concat(this.frag).toString('utf8'); this.frag = []; this.emit('message', msg); }
      }
    }
  }
  _frame(first, p) {
    const mask = crypto.randomBytes(4);
    let hdr;
    if (p.length < 126) hdr = Buffer.from([first, 0x80 | p.length]);
    else if (p.length < 65536) { hdr = Buffer.alloc(4); hdr[0] = first; hdr[1] = 0x80 | 126; hdr.writeUInt16BE(p.length, 2); }
    else { hdr = Buffer.alloc(10); hdr[0] = first; hdr[1] = 0x80 | 127; hdr.writeBigUInt64BE(BigInt(p.length), 2); }
    const m = Buffer.alloc(p.length);
    for (let i = 0; i < p.length; i++) m[i] = p[i] ^ mask[i % 4];
    this.sock.write(Buffer.concat([hdr, mask, m]));
  }
  send(str) { this._frame(0x81, Buffer.from(str, 'utf8')); }
  close() { try { this.sock.destroy(); } catch (e) { /* ignore */ } }
}
function wsConnect(wsUrl) {
  return new Promise((resolve, reject) => {
    const u = new URL(wsUrl);
    const req = http.request({
      host: u.hostname, port: u.port, path: u.pathname + u.search,
      headers: { Connection: 'Upgrade', Upgrade: 'websocket', 'Sec-WebSocket-Key': crypto.randomBytes(16).toString('base64'), 'Sec-WebSocket-Version': '13' },
    });
    req.on('upgrade', (res, socket, head) => resolve(new Ws(socket, head)));
    req.on('error', reject);
    req.end();
  });
}

// ---------------- CDP ----------------
let ws = null, seq = 0;
const pending = new Map();
const bus = new EventEmitter();
function call(method, params) {
  return new Promise((resolve, reject) => {
    const id = ++seq;
    pending.set(id, { resolve, reject });
    ws.send(JSON.stringify({ id, method, params: params || {} }));
  });
}
function onWsMessage(msg) {
  let m; try { m = JSON.parse(msg); } catch (e) { return; }
  if (m.id) {
    const p = pending.get(m.id); pending.delete(m.id);
    if (!p) return;
    if (m.error) p.reject(new Error(m.error.message || 'cdp error')); else p.resolve(m.result || {});
  } else if (m.method) bus.emit(m.method, m.params || {});
}

// ---------------- state ----------------
let child = null;
let paused = null;          // Debugger.paused params (null while running)
let frames = [];            // filtered call frames
let refs = new Map(), refN = 0;
let lastCmd = 'entry';
let first = true;
let stdinOn = false;
const bpIds = new Map();    // app file -> [breakpoint ids]
const scripts = new Map();  // scriptId -> url
const NOISE = new Set(['exports', 'require', 'module', '__filename', '__dirname']);

function ref(objectId) { refN++; refs.set(refN, objectId); return refN; }

function short(v, n) { v = String(v); return v.length > n ? v.slice(0, n) + '\u2026' : v; }
function propVal(pp) {
  switch (pp.type) {
    case 'string': return JSON.stringify(short(pp.value, 40));
    case 'object': return pp.subtype === 'null' ? 'null' : (pp.value || 'Object');
    case 'function': return '\u0192';
    default: return pp.value === undefined ? pp.type : String(pp.value);
  }
}
function preview(ro) {
  const pr = ro.preview;
  if (!pr) return ro.description || ro.className || 'Object';
  const isArr = pr.subtype === 'array' || ro.subtype === 'array' || ro.subtype === 'typedarray';
  let items;
  if (pr.entries && pr.entries.length) {
    items = pr.entries.map((e) => (e.key ? propVal(e.key) + ' => ' : '') + propVal(e.value));
  } else {
    items = (pr.properties || []).map((pp) => (isArr ? '' : pp.name + ': ') + propVal(pp));
  }
  if (pr.overflow) items.push('\u2026');
  const body = isArr ? '[' + items.join(', ') + ']' : '{' + items.join(', ') + '}';
  const head = ro.description && ro.description !== 'Object' ? ro.description + ' ' : '';
  return short(head + body, 200);
}
function describe(name, ro) {
  const d = { n: String(name), v: '', t: ro.subtype || ro.className || ro.type, r: 0 };
  switch (ro.type) {
    case 'string': d.v = JSON.stringify(short(ro.value, 200)); d.len = ro.value.length; break;
    case 'number': d.v = ro.unserializableValue || String(ro.value); break;
    case 'boolean': d.v = String(ro.value); break;
    case 'undefined': d.v = 'undefined'; break;
    case 'bigint': d.v = ro.unserializableValue || ro.description; break;
    case 'symbol': d.v = ro.description; break;
    case 'function': d.v = short((ro.description || '').split('\n')[0], 120); break;
    default:
      if (ro.subtype === 'null') d.v = 'null';
      else {
        d.v = preview(ro);
        const m = /\((\d+)\)$/.exec(ro.description || '');
        if (m) d.len = parseInt(m[1], 10);
        if (ro.objectId) d.r = ref(ro.objectId);
      }
  }
  return d;
}

function cfUrl(cf) { return cf.url || scripts.get(cf.location.scriptId) || ''; }
function frameInfo(cf, i) {
  const file = toApp(urlToPath(cfUrl(cf)));
  let name = cf.functionName;
  if (!name) name = file === toApp(SCRIPT) || file === SCRIPT ? '<module>' : '(anonymous)';
  return { i, name, file, line: cf.location.lineNumber + 1, mine: isMine(urlToPath(cfUrl(cf))) };
}

async function varsFor(i) {
  const cf = frames[i];
  const out = [];
  if (!cf) return { frame: i, locals: [], globals: [] };
  for (const sc of cf.scopeChain) {
    if (sc.type === 'global') continue;
    let r;
    try { r = await call('Runtime.getProperties', { objectId: sc.object.objectId, ownProperties: true, generatePreview: true }); }
    catch (e) { continue; }
    for (const p of r.result || []) {
      if (!p.value || p.name === '__proto__' || NOISE.has(p.name)) continue;
      if (p.value.type === 'function') continue;
      out.push(describe(p.name, p.value));
      if (out.length >= 300) break;
    }
    if (out.length >= 300) break;
  }
  const f = frameInfo(cf, i);
  return { frame: i, line: f.line, file: f.file, locals: out, globals: [] };
}

// ---------------- breakpoints ----------------
function esc(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
async function setBps(msg) {
  const file = String(msg.file || '');
  for (const id of bpIds.get(file) || []) { try { await call('Debugger.removeBreakpoint', { breakpointId: id }); } catch (e) { /* gone */ } }
  const ids = [], ok = [], bad = [];
  let rel = path.relative(ROOT, file);
  const under = rel && !rel.startsWith('..') && !path.isAbsolute(rel);
  const conds = msg.conds || {};
  for (const ln of msg.lines || []) {
    if (!under) { bad.push(ln); continue; }
    try {
      const r = await call('Debugger.setBreakpointByUrl', {
        lineNumber: ln - 1,
        urlRegex: '(^|/)' + esc(rel.split(path.sep).join('/')) + '$',
        condition: conds[String(ln)] || '',
      });
      ids.push(r.breakpointId); ok.push(ln);
    } catch (e) { bad.push(ln); }
  }
  bpIds.set(file, ids);
  emit({ e: 'bps', file, ok, bad });
}

// ---------------- stdin (only while paused) ----------------
let inBuf = '';
let queue = Promise.resolve();
function onStdin(d) {
  inBuf += d.toString('utf8');
  let i;
  while ((i = inBuf.search(/[\r\n]/)) >= 0) {
    const line = inBuf.slice(0, i).trim();
    inBuf = inBuf.slice(i + 1);
    if (line) queue = queue.then(() => handle(line)).catch((e) => emit({ e: 'error', msg: String(e && e.message || e) }));
  }
}
function listen(on) {
  if (on === stdinOn) return;
  stdinOn = on;
  if (on) {
    try { if (process.stdin.setRawMode) process.stdin.setRawMode(true); } catch (e) { /* not a tty */ }
    process.stdin.on('data', onStdin);
    process.stdin.resume();
  } else {
    process.stdin.removeListener('data', onStdin);
    process.stdin.pause();
    try { if (process.stdin.setRawMode) process.stdin.setRawMode(false); } catch (e) { /* ignore */ }
  }
}

function die(code) {
  try { listen(false); } catch (e) { /* ignore */ }
  try { if (child) child.kill('SIGKILL'); } catch (e) { /* ignore */ }
  try { fs.unlinkSync(PRE); } catch (e) { /* ignore */ }
  process.exit(code || 0);
}

async function handle(line) {
  let msg; try { msg = JSON.parse(line); } catch (e) { return; }
  if (!msg || typeof msg !== 'object') return;
  switch (msg.cmd) {
    case 'run':
      listen(false);
      lastCmd = 'entry';
      await call('Runtime.runIfWaitingForDebugger');
      return;
    case 'bps': return setBps(msg);
    case 'stop': return die(0);
    case 'frame': { const ev = await varsFor(parseInt(msg.i || 0, 10)); ev.e = 'vars'; emit(ev); return; }
    case 'expand': {
      const oid = refs.get(parseInt(msg.ref || 0, 10));
      const items = [];
      if (oid) {
        try {
          const r = await call('Runtime.getProperties', { objectId: oid, ownProperties: true, generatePreview: true });
          for (const p of r.result || []) {
            if (!p.value || p.name === '__proto__') continue;
            items.push(describe(p.name, p.value));
            if (items.length >= 200) break;
          }
          for (const p of r.internalProperties || []) {
            if (p.value && p.name !== '[[Prototype]]' && items.length < 200) items.push(describe(p.name, p.value));
          }
        } catch (e) { /* object gone */ }
      }
      emit({ e: 'children', id: msg.id, ref: msg.ref, items });
      return;
    }
    case 'eval': {
      const i = parseInt(msg.frame || 0, 10);
      const cf = frames[i];
      if (!paused || !cf) { emit({ e: 'result', id: msg.id, ok: false, v: 'no frame' }); return; }
      try {
        const r = await call('Debugger.evaluateOnCallFrame', { callFrameId: cf.callFrameId, expression: String(msg.expr || ''), generatePreview: true, silent: true });
        if (r.exceptionDetails) {
          const ex = r.exceptionDetails;
          const t = (ex.exception && ex.exception.description) || ex.text || 'error';
          emit({ e: 'result', id: msg.id, ok: false, v: short(String(t).split('\n')[0], 300) });
        } else emit({ e: 'result', id: msg.id, ok: true, frame: i, item: describe(msg.expr, r.result) });
      } catch (e) { emit({ e: 'result', id: msg.id, ok: false, v: String(e.message || e) }); }
      return;
    }
    case 'continue': case 'next': case 'step': case 'out': {
      if (!paused) return;
      const method = { continue: 'Debugger.resume', next: 'Debugger.stepOver', step: 'Debugger.stepInto', out: 'Debugger.stepOut' }[msg.cmd];
      lastCmd = msg.cmd; paused = null; frames = [];
      listen(false);
      await call(method);
      return;
    }
  }
}

// ---------------- paused ----------------
bus.on('Debugger.scriptParsed', (p) => { if (p.scriptId) scripts.set(p.scriptId, p.url || ''); });
bus.on('Debugger.paused', async (p) => {
  const hit = (p.hitBreakpoints || []).length > 0;
  if (first) {
    first = false;
    if (!ENTRY && !hit) { try { await call('Debugger.resume'); } catch (e) { /* ignore */ } return; }
  }
  paused = p; refs = new Map(); refN = 0;
  frames = (p.callFrames || []).filter((cf) => { const u = cfUrl(cf); return u && !u.startsWith('node:'); });
  let reason = 'step';
  if ((p.reason === 'exception' || p.reason === 'promiseRejection') && frames.length === 0) {
    // thrown inside node's own code (no user frame to show): let it die with its normal trace
    paused = null;
    try { await call('Debugger.resume'); } catch (e) { /* ignore */ }
    return;
  }
  if (p.reason === 'exception' || p.reason === 'promiseRejection') reason = 'exception';
  else if (hit) reason = 'breakpoint';
  else if (lastCmd === 'pause') reason = 'pause';
  else if (lastCmd === 'entry') reason = 'entry';
  const ev = await varsFor(0);
  ev.e = 'stopped'; ev.reason = reason;
  ev.frames = frames.map(frameInfo);
  if (reason === 'exception' && p.data) ev.exc = short(String(p.data.description || p.data.value || 'exception').split('\n')[0], 300);
  listen(true);
  emit(ev);
});

// ---------------- start ----------------
const PRE = path.join(os.tmpdir(), 'abtin_pre_' + process.pid + '.js');
fs.writeFileSync(PRE, "process.on('SIGINT',function(){});\n"); // Ctrl+C = "pause", not "kill the program"

process.on('SIGINT', () => {
  if (!paused && ws) { lastCmd = 'pause'; call('Debugger.pause').catch(() => {}); }
});
process.on('SIGTERM', () => die(0));

child = cp.spawn(process.execPath, ['--inspect-brk=127.0.0.1:0', '-r', PRE, SCRIPT, ...ARGS], { stdio: ['inherit', 'inherit', 'pipe'] });
let errBuf = '';
let started = false;
function onErrLine(line) {
  const m = /Debugger listening on (ws:\/\/\S+)/.exec(line);
  if (m) { if (!started) { started = true; connect(m[1]); } return; }
  if (/^(For help, see:|Debugger attached|Waiting for the debugger)/.test(line)) {
    if (/^Waiting for the debugger to disconnect/.test(line) && ws) ws.close(); // script finished
    return;
  }
  process.stderr.write(line);
}
child.stderr.on('data', (d) => {
  errBuf += d.toString('utf8');
  let i;
  while ((i = errBuf.indexOf('\n')) >= 0) { const l = errBuf.slice(0, i + 1); errBuf = errBuf.slice(i + 1); onErrLine(l); }
});
child.stderr.on('end', () => { if (errBuf) process.stderr.write(errBuf); errBuf = ''; });
child.on('error', (e) => { process.stderr.write('cannot start node: ' + e.message + '\n'); emit({ e: 'exited', code: 1 }); die(1); });
child.on('exit', (code, sig) => {
  const c = code === null ? (sig ? 128 : 1) : code;
  try { listen(false); } catch (e) { /* ignore */ }
  try { fs.unlinkSync(PRE); } catch (e) { /* ignore */ }
  emit({ e: 'exited', code: c });
  process.exit(c);
});

async function connect(url) {
  try {
    ws = await wsConnect(url);
    ws.on('message', onWsMessage);
    await call('Runtime.enable');
    await call('Debugger.enable');
    await call('Debugger.setPauseOnExceptions', { state: 'uncaught' });
    if (!ALL) await call('Debugger.setBlackboxPatterns', { patterns: ['^node:', '[\\\\/]node_modules[\\\\/]'] }).catch(() => {});
    listen(true);
    emit({ e: 'ready' });
  } catch (e) {
    process.stderr.write('debugger connection failed: ' + (e && e.message || e) + '\n');
    emit({ e: 'exited', code: 1 });
    die(1);
  }
}
