#!/usr/bin/env python3
# Abtin Python debug adapter (stdlib only, bdb based).
#
# Started by the app inside Alpine:
#   python3 -u abtin_pydbg.py --root DIR [--entry] [--all] SCRIPT [ARGS...]
#
# Talks over the terminal (PTY) it runs in:
#   adapter -> app : \x1fABTIN_DBG:{json}\x1f   (everything else is the program's own output)
#   app -> adapter : one JSON object per line on stdin (only read while paused)
import bdb
import builtins
import dis
import itertools
import json
import os
import signal
import sys
import traceback
import types

MARK = '\x1fABTIN_DBG:'
END = '\x1f'
_OUT = sys.__stdout__
_SELF = os.path.abspath(__file__)

try:
    import termios
    _TFD = sys.stdin.fileno()
    _TSAVED = termios.tcgetattr(_TFD)
    _ECHO = termios.ECHO | termios.ECHOE | termios.ECHOK | termios.ECHONL
except Exception:  # not a tty (tests) or no termios
    termios = None
    _TFD = -1
    _TSAVED = None
    _ECHO = 0


def _echo(on):
    """Typed commands must not be echoed into the program output while paused."""
    if termios is None:
        return
    try:
        a = termios.tcgetattr(_TFD)
        a[3] = (a[3] & ~_ECHO) | ((_TSAVED[3] & _ECHO) if on else 0)
        termios.tcsetattr(_TFD, termios.TCSANOW, a)
    except Exception:
        pass


def emit(obj):
    s = json.dumps(obj, ensure_ascii=True, separators=(',', ':'))
    _OUT.write(MARK + s + END)
    _OUT.flush()


def _repr(v, limit=200):
    try:
        r = repr(v)
    except Exception as e:  # broken __repr__
        r = '<repr failed: %s>' % type(e).__name__
    if len(r) > limit:
        r = r[:limit] + '\u2026'
    return r


class Refs(object):
    """Expandable values of the current stop (valid until the program resumes)."""

    def __init__(self):
        self.items = {}
        self.n = 0

    def add(self, obj):
        self.n += 1
        self.items[self.n] = obj
        return self.n


_SKIP_EXPAND = (types.ModuleType, types.FunctionType, types.BuiltinFunctionType,
                types.MethodType, str, bytes, int, float, bool, complex, type(None))


def _expandable(v):
    if isinstance(v, (dict, list, tuple, set, frozenset)):
        return len(v) > 0
    if isinstance(v, _SKIP_EXPAND):
        return False
    try:
        return bool(vars(v)) or bool(getattr(type(v), '__slots__', None))
    except TypeError:
        return bool(getattr(type(v), '__slots__', None))


def describe(name, v, refs):
    d = {'n': str(name), 'v': _repr(v), 't': type(v).__name__, 'r': 0}
    try:
        if isinstance(v, (dict, list, tuple, set, frozenset, str, bytes)):
            d['len'] = len(v)
    except Exception:
        pass
    if _expandable(v):
        d['r'] = refs.add(v)
    return d


def children(obj, limit=200):
    out = []
    if isinstance(obj, dict):
        for k, v in itertools.islice(list(obj.items()), limit):
            out.append((_repr(k, 60), v))
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(itertools.islice(obj, limit)):
            out.append(('[%d]' % i, v))
    elif isinstance(obj, (set, frozenset)):
        for i, v in enumerate(itertools.islice(list(obj), limit)):
            out.append(('{%d}' % i, v))
    else:
        try:
            d = dict(vars(obj))
        except TypeError:
            d = {}
        for k in getattr(type(obj), '__slots__', ()) or ():
            if isinstance(k, str) and hasattr(obj, k):
                d[k] = getattr(obj, k)
        for k, v in itertools.islice(list(d.items()), limit):
            if not str(k).startswith('__'):
                out.append((k, v))
    return out


def _is_noise(v):
    return isinstance(v, (types.ModuleType, types.FunctionType, types.BuiltinFunctionType, type))


def _var_list(d, refs, hide_noise):
    out = []
    for k, v in list(d.items()):
        if k.startswith('__') and k.endswith('__'):
            continue
        if hide_noise and _is_noise(v):
            continue
        out.append(describe(k, v, refs))
        if len(out) >= 300:
            break
    return out


_CODE_LINES = {}


def code_lines(filename):
    """Line numbers that hold code (None = could not tell)."""
    if filename in _CODE_LINES:
        return _CODE_LINES[filename]
    res = None
    try:
        with open(filename, 'rb') as f:
            src = f.read()
        top = compile(src, filename, 'exec')
        lines = set()
        stack = [top]
        while stack:
            c = stack.pop()
            for _, ln in dis.findlinestarts(c):
                if ln is not None:
                    lines.add(ln)
            for k in c.co_consts:
                if isinstance(k, types.CodeType):
                    stack.append(k)
        res = lines
    except Exception:
        res = None
    _CODE_LINES[filename] = res
    return res


def _die(code=0):
    _echo(True)
    try:
        _OUT.flush()
    except Exception:
        pass
    os._exit(code)


class Dbg(bdb.Bdb):
    def __init__(self, root, entry, all_code):
        bdb.Bdb.__init__(self)
        self.root = os.path.abspath(root).rstrip(os.sep) + os.sep
        self.entry = entry
        self.all_code = all_code
        self.script = ''
        self._first = True
        self._cmd = 'entry'
        self._stack = []
        self._refs = Refs()
        self._paused = False

    # ----- which code is "mine" (library frames are stepped over) -----
    def _mine(self, filename):
        if self.all_code:
            return filename != _SELF and not filename.startswith('<')
        if not filename or filename.startswith('<'):
            return False
        fn = os.path.abspath(filename)
        if fn == _SELF or 'site-packages' in fn or 'dist-packages' in fn:
            return False
        return fn.startswith(self.root) or fn == self.script

    def stop_here(self, frame):
        if not self._mine(frame.f_code.co_filename):
            return False
        return bdb.Bdb.stop_here(self, frame)

    # ----- bdb callbacks -----
    def user_line(self, frame):
        if self._first:
            self._first = False
            if not self.entry and not self.break_here(frame):
                self.set_continue()
                return
        cmd = self._stop_at(frame)
        self.apply(cmd, frame)

    def _stop_at(self, frame, reason=None):
        stack, _ = self.get_stack(frame, None)
        st = []
        for f, ln in reversed(stack):
            fn = f.f_code.co_filename
            if fn == _SELF or fn.endswith(os.sep + 'bdb.py'):
                continue
            st.append((f, ln))
        if not reason:
            top = st[0] if st else (frame, frame.f_lineno)
            has_bp = top[1] in self.breaks.get(self.canonic(top[0].f_code.co_filename), ())
            if self._cmd == 'continue' and has_bp:
                reason = 'breakpoint'
            elif self._cmd == 'pause':
                reason = 'pause'
            elif self._cmd == 'entry':
                reason = 'breakpoint' if has_bp else 'entry'
            else:
                reason = 'step'
        return self._enter(st, reason, None)

    def _enter(self, st, reason, extra):
        self._stack = st
        self._refs = Refs()
        _echo(False)  # before announcing the stop: the app may answer at once
        ev = {'e': 'stopped', 'reason': reason, 'frames': self._frames()}
        ev.update(self._vars(0))
        if extra:
            ev.update(extra)
        emit(ev)
        cmd = self._loop()
        self._cmd = cmd
        self._refs = Refs()
        return cmd

    def _frames(self):
        out = []
        for i, (f, ln) in enumerate(self._stack):
            out.append({'i': i, 'name': f.f_code.co_name, 'file': os.path.abspath(f.f_code.co_filename)
                        if not f.f_code.co_filename.startswith('<') else f.f_code.co_filename,
                        'line': ln, 'mine': self._mine(f.f_code.co_filename)})
        return out

    def _vars(self, i):
        if not (0 <= i < len(self._stack)):
            return {'frame': i, 'locals': [], 'globals': []}
        f, ln = self._stack[i]
        module_level = f.f_locals is f.f_globals
        loc = _var_list(f.f_locals, self._refs, module_level)
        glb = [] if module_level else _var_list(f.f_globals, self._refs, True)
        return {'frame': i, 'line': ln,
                'file': os.path.abspath(f.f_code.co_filename) if not f.f_code.co_filename.startswith('<') else f.f_code.co_filename,
                'locals': loc, 'globals': glb}

    # ----- command loop (only while paused) -----
    def _loop(self):
        _echo(False)
        self._paused = True
        try:
            while True:
                line = sys.__stdin__.readline()
                if not line:
                    _die()
                line = line.strip()
                if not line:
                    continue
                try:
                    msg = json.loads(line)
                except ValueError:
                    continue
                if not isinstance(msg, dict):
                    continue
                cmd = msg.get('cmd')
                if cmd in ('run', 'continue', 'next', 'step', 'out'):
                    return cmd
                if cmd == 'stop':
                    _die()
                try:
                    self._handle(msg, cmd)
                except Exception as e:
                    emit({'e': 'error', 'msg': '%s: %s' % (type(e).__name__, e)})
        finally:
            self._paused = False
            _echo(True)

    def _handle(self, msg, cmd):
        if cmd == 'bps':
            self._set_bps(msg)
        elif cmd == 'frame':
            ev = {'e': 'vars'}
            ev.update(self._vars(int(msg.get('i', 0))))
            emit(ev)
        elif cmd == 'eval':
            self._eval(msg)
        elif cmd == 'expand':
            ref = int(msg.get('ref', 0))
            obj = self._refs.items.get(ref)
            items = [describe(n, v, self._refs) for n, v in children(obj)] if obj is not None else []
            emit({'e': 'children', 'id': msg.get('id'), 'ref': ref, 'items': items})

    def _set_bps(self, msg):
        fn = msg.get('file', '')
        lines = [int(x) for x in msg.get('lines', [])]
        conds = msg.get('conds') or {}
        try:
            self.clear_all_file_breaks(fn)
        except Exception:
            pass
        valid = code_lines(fn)
        ok, bad = [], []
        for ln in lines:
            if valid is not None and ln not in valid:
                bad.append(ln)
                continue
            cond = conds.get(str(ln)) or None
            err = self.set_break(fn, ln, cond=cond)
            if err:
                bad.append(ln)
            else:
                ok.append(ln)
        emit({'e': 'bps', 'file': fn, 'ok': ok, 'bad': bad})

    def _eval(self, msg):
        i = int(msg.get('frame', 0))
        expr = msg.get('expr', '')
        rid = msg.get('id')
        if not (0 <= i < len(self._stack)):
            emit({'e': 'result', 'id': rid, 'ok': False, 'v': 'no frame'})
            return
        f, _ = self._stack[i]
        g, l = f.f_globals, f.f_locals
        try:
            try:
                code = compile(expr, '<watch>', 'eval')
                val = eval(code, g, l)
                emit({'e': 'result', 'id': rid, 'ok': True, 'frame': i, 'item': describe(expr, val, self._refs)})
            except SyntaxError:
                exec(compile(expr, '<watch>', 'exec'), g, l)
                emit({'e': 'result', 'id': rid, 'ok': True, 'frame': i, 'item': {'n': expr, 'v': 'OK', 't': '', 'r': 0}})
        except BaseException as e:
            emit({'e': 'result', 'id': rid, 'ok': False, 'v': '%s: %s' % (type(e).__name__, e)})

    # ----- pause (Ctrl+C from the app) -----
    def arm(self, frame):
        if self._paused:
            return
        self._cmd = 'pause'
        self.set_step()
        f = frame
        while f is not None and f is not self.botframe:
            f.f_trace = self.trace_dispatch
            f = f.f_back
        sys.settrace(self.trace_dispatch)

    # ----- resume -----
    def apply(self, cmd, frame):
        if cmd == 'continue':
            self.set_continue()
        elif cmd == 'next':
            self.set_next(frame)
        elif cmd == 'step':
            self.set_step()
        elif cmd == 'out':
            # like VS Code: leave the function and stop in the caller (next line there)
            caller = frame.f_back
            if caller is None or not self._mine(caller.f_code.co_filename):
                self.set_continue()
            else:
                self.set_next(caller)
        else:  # 'run' / unknown
            self.set_continue()

    def user_call(self, frame, argument_list):
        pass

    def user_return(self, frame, return_value):
        pass

    def user_exception(self, frame, exc_info):
        pass

    def run_script(self, path, args):
        self.script = os.path.abspath(path)
        with open(self.script, 'rb') as f:
            src = f.read()
        try:
            code = compile(src, self.script, 'exec')
        except SyntaxError:
            traceback.print_exc(limit=0)
            tb = sys.exc_info()
            emit({'e': 'exited', 'code': 1})
            return 1
        sys.argv = [self.script] + list(args)
        d = os.path.dirname(self.script)
        if sys.path and sys.path[0] != d:
            sys.path.insert(0, d)
        g = {'__name__': '__main__', '__file__': self.script, '__builtins__': builtins,
             '__package__': None, '__spec__': None, '__doc__': None}
        # wait for the app's breakpoints, then its "run"
        self._enter_config()
        rc = 0
        try:
            self.reset()
            self._first = True
            self._cmd = 'entry'
            sys.settrace(self.trace_dispatch)
            try:
                exec(code, g, g)
            finally:
                sys.settrace(None)
        except SystemExit as e:
            c = e.code
            if c is None:
                rc = 0
            elif isinstance(c, int):
                rc = c
            else:
                sys.stderr.write(str(c) + '\n')
                rc = 1
        except BaseException:
            rc = 1
            et, ev, tb = sys.exc_info()
            self._report(et, ev, tb)
        return rc

    def _enter_config(self):
        self._stack = []
        self._refs = Refs()
        _echo(False)
        emit({'e': 'ready'})
        try:
            while True:
                line = sys.__stdin__.readline()
                if not line:
                    _die()
                try:
                    msg = json.loads(line.strip() or 'null')
                except ValueError:
                    continue
                if not isinstance(msg, dict):
                    continue
                cmd = msg.get('cmd')
                if cmd == 'run':
                    return
                if cmd == 'stop':
                    _die()
                if cmd == 'bps':
                    self._set_bps(msg)
        finally:
            _echo(True)

    def _report(self, et, ev, tb):
        # like Python: print the traceback without the adapter's own frames
        t = tb
        while t is not None and t.tb_frame.f_code.co_filename == _SELF:
            t = t.tb_next
        sys.stderr.write('Traceback (most recent call last):\n')
        sys.stderr.write(''.join(traceback.format_list(traceback.extract_tb(t))))
        sys.stderr.write(''.join(traceback.format_exception_only(et, ev)))
        sys.stderr.flush()
        # post-mortem stop: inspect the frames of the failed call
        chain = []
        x = t
        while x is not None:
            chain.append((x.tb_frame, x.tb_lineno))
            x = x.tb_next
        st = list(reversed(chain))
        if not st:
            return
        self._enter(st, 'exception', {'exc': '%s: %s' % (et.__name__, ev)})


def main(argv):
    root = None
    entry = False
    all_code = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == '--root':
            root = argv[i + 1]
            i += 2
        elif a == '--entry':
            entry = True
            i += 1
        elif a == '--all':
            all_code = True
            i += 1
        else:
            break
    if i >= len(argv):
        sys.stderr.write('usage: abtin_pydbg.py --root DIR [--entry] [--all] SCRIPT [ARGS]\n')
        return 2
    script = argv[i]
    if root is None:
        root = os.path.dirname(os.path.abspath(script))
    dbg = Dbg(root, entry, all_code)

    def on_sigint(signum, frame):
        dbg.arm(frame)

    try:
        signal.signal(signal.SIGINT, on_sigint)
    except Exception:
        pass
    code = 0
    try:
        code = dbg.run_script(script, argv[i + 1:])
    except BaseException:
        traceback.print_exc()
        code = 1
    _echo(True)
    try:
        emit({'e': 'exited', 'code': code})
    except Exception:
        pass
    return code


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
