import 'dart:convert';
import 'dart:io';

import 'package:path/path.dart' as p;

import 'ai_client.dart';

class AiToolResult {
  const AiToolResult(this.text, {this.error = false, this.changed = const []});
  final String text;
  final bool error;

  /// Files created / changed / removed (the editor reloads them).
  final List<String> changed;
}

/// File tools the model can call. Everything is confined to [root] (symlinks included).
class ProjectTools {
  ProjectTools(String root) : root = p.normalize(root) {
    try {
      _realRoot = Directory(this.root).resolveSymbolicLinksSync();
    } catch (_) {
      _realRoot = this.root;
    }
  }

  final String root;
  late final String _realRoot;

  static const _skipDirs = {'.git', 'node_modules', '.dart_tool', 'build', '.gradle', '.idea', '__pycache__', '.cache', '.pub-cache'};
  static const _maxRead = 120 * 1024;
  static const _maxWrite = 2 * 1024 * 1024;

  static const defs = <AiToolDef>[
    AiToolDef('list_dir', 'List files and folders of a project directory (paths are relative to the project root).', {
      'type': 'object',
      'properties': {
        'path': {'type': 'string', 'description': 'Directory, relative to the project root. "." = root.'},
        'depth': {'type': 'integer', 'description': 'How many levels to list (1-4, default 1).'},
      },
    }),
    AiToolDef('read_file', 'Read a text file. Lines are returned with their line numbers (the numbers are not part of the file).', {
      'type': 'object',
      'properties': {
        'path': {'type': 'string'},
        'start_line': {'type': 'integer', 'description': '1-based first line (optional).'},
        'end_line': {'type': 'integer', 'description': '1-based last line (optional).'},
      },
      'required': ['path'],
    }),
    AiToolDef('search', 'Search text files of the project (regular expression, case-insensitive). Returns file:line: text.', {
      'type': 'object',
      'properties': {
        'pattern': {'type': 'string', 'description': 'Regular expression (or plain text).'},
        'path': {'type': 'string', 'description': 'Directory or file to search. Default ".".'},
        'include': {'type': 'string', 'description': 'Only files with this extension, e.g. "dart" or ".py".'},
      },
      'required': ['pattern'],
    }),
    AiToolDef('write_file', 'Create a file or overwrite it completely. Parent folders are created. Prefer edit_file for small changes.', {
      'type': 'object',
      'properties': {
        'path': {'type': 'string'},
        'content': {'type': 'string', 'description': 'Complete new content of the file.'},
      },
      'required': ['path', 'content'],
    }),
    AiToolDef('edit_file', 'Replace text in an existing file. old_text must match exactly (whitespace included) and be unique unless replace_all is true. Read the file first.', {
      'type': 'object',
      'properties': {
        'path': {'type': 'string'},
        'old_text': {'type': 'string'},
        'new_text': {'type': 'string'},
        'replace_all': {'type': 'boolean'},
      },
      'required': ['path', 'old_text', 'new_text'],
    }),
    AiToolDef('move_path', 'Rename or move a file or folder inside the project.', {
      'type': 'object',
      'properties': {
        'from': {'type': 'string'},
        'to': {'type': 'string'},
      },
      'required': ['from', 'to'],
    }),
    AiToolDef('delete_path', 'Delete a file or a folder (with everything in it). Only when the user asked for it.', {
      'type': 'object',
      'properties': {
        'path': {'type': 'string'},
      },
      'required': ['path'],
    }),
  ];

  /// Tools that change files (the user must approve them unless auto-approve is on).
  static bool isWrite(String name) => name == 'write_file' || name == 'edit_file' || name == 'move_path' || name == 'delete_path';

  /// Deleting is always confirmed.
  static bool alwaysAsk(String name) => name == 'delete_path';

  String _arg(AiToolCall c, String k) => '${c.args[k] ?? ''}';

  /// Short one-line description for the chat.
  String label(AiToolCall c) {
    switch (c.name) {
      case 'move_path':
        return 'move_path ${_arg(c, 'from')} → ${_arg(c, 'to')}';
      case 'search':
        return 'search "${_arg(c, 'pattern')}"';
      default:
        final path = _arg(c, 'path');
        return path.isEmpty ? c.name : '${c.name} $path';
    }
  }

  /// Longer preview shown in the approval dialog.
  String preview(AiToolCall c) {
    String cut(String s, int n) => s.length <= n ? s : '${s.substring(0, n)}\n…';
    switch (c.name) {
      case 'write_file':
        final content = _arg(c, 'content');
        return '${_arg(c, 'path')}\n${content.split('\n').length} lines, ${content.length} chars\n\n${cut(content, 700)}';
      case 'edit_file':
        return '${_arg(c, 'path')}\n\n- ${cut(_arg(c, 'old_text'), 500).replaceAll('\n', '\n- ')}\n\n+ ${cut(_arg(c, 'new_text'), 500).replaceAll('\n', '\n+ ')}';
      case 'move_path':
        return '${_arg(c, 'from')}\n→ ${_arg(c, 'to')}';
      case 'delete_path':
        return _arg(c, 'path');
    }
    return label(c);
  }

  // ---------------------------------------------------------------- paths
  String? _resolve(String rel) {
    final s = rel.trim();
    final abs = s.isEmpty || s == '.' ? root : (p.isAbsolute(s) ? p.normalize(s) : p.normalize(p.join(root, s)));
    if (abs != root && !p.isWithin(root, abs)) return null;
    // follow symlinks of the nearest existing ancestor: a link must not lead out of the project
    var cur = abs;
    while (!FileSystemEntity.isLinkSync(cur) && FileSystemEntity.typeSync(cur) == FileSystemEntityType.notFound) {
      final up = p.dirname(cur);
      if (up == cur) break;
      cur = up;
    }
    try {
      final real = Directory(cur).resolveSymbolicLinksSync();
      if (real != _realRoot && !p.isWithin(_realRoot, real)) return null;
    } catch (_) {
      return null;
    }
    return abs;
  }

  String _rel(String abs) => abs == root ? '.' : p.relative(abs, from: root);

  static bool _isBinary(List<int> bytes) {
    final n = bytes.length < 4096 ? bytes.length : 4096;
    for (var i = 0; i < n; i++) {
      if (bytes[i] == 0) return true;
    }
    return false;
  }

  // ---------------------------------------------------------------- run
  Future<AiToolResult> run(AiToolCall c) async {
    if (c.badJson) {
      return const AiToolResult('The tool arguments were not valid JSON. Call the tool again with valid JSON arguments.', error: true);
    }
    try {
      switch (c.name) {
        case 'list_dir':
          return _list(c);
        case 'read_file':
          return await _read(c);
        case 'search':
          return await _search(c);
        case 'write_file':
          return await _write(c);
        case 'edit_file':
          return await _edit(c);
        case 'move_path':
          return await _move(c);
        case 'delete_path':
          return await _delete(c);
      }
      return AiToolResult('Unknown tool: ${c.name}', error: true);
    } on FileSystemException catch (e) {
      return AiToolResult('File error: ${e.message} ${e.path ?? ''}'.trim(), error: true);
    } catch (e) {
      return AiToolResult('Error: $e', error: true);
    }
  }

  AiToolResult _outside(String path) => AiToolResult('"$path" is outside the project folder; only files inside "$root" can be used.', error: true);

  AiToolResult _list(AiToolCall c) {
    final path = _arg(c, 'path');
    final abs = _resolve(path);
    if (abs == null) return _outside(path);
    final dir = Directory(abs);
    if (!dir.existsSync()) return AiToolResult('Directory not found: ${_rel(abs)}', error: true);
    var depth = (c.args['depth'] is num) ? (c.args['depth'] as num).toInt() : 1;
    depth = depth.clamp(1, 4).toInt();
    final out = <String>[];
    var truncated = false;

    void walk(Directory d, int level) {
      if (truncated) return;
      List<FileSystemEntity> items;
      try {
        items = d.listSync(followLinks: false);
      } catch (_) {
        return;
      }
      items.sort((a, b) {
        final ad = a is Directory, bd = b is Directory;
        if (ad != bd) return ad ? -1 : 1;
        return p.basename(a.path).toLowerCase().compareTo(p.basename(b.path).toLowerCase());
      });
      for (final e in items) {
        if (out.length >= 300) {
          truncated = true;
          return;
        }
        final name = p.basename(e.path);
        final pad = '  ' * (level - 1);
        if (e is Directory) {
          out.add('$pad$name/');
          if (level < depth && !_skipDirs.contains(name)) walk(e, level + 1);
        } else if (e is File) {
          int size = 0;
          try {
            size = e.lengthSync();
          } catch (_) {}
          out.add('$pad$name  (${_size(size)})');
        } else {
          out.add('$pad$name@');
        }
      }
    }

    walk(dir, 1);
    if (out.isEmpty) return AiToolResult('${_rel(abs)}: (empty)');
    return AiToolResult('${_rel(abs)}:\n${out.join('\n')}${truncated ? '\n… (list truncated)' : ''}');
  }

  static String _size(int b) {
    if (b < 1024) return '$b B';
    if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} KB';
    return '${(b / 1024 / 1024).toStringAsFixed(1)} MB';
  }

  Future<AiToolResult> _read(AiToolCall c) async {
    final path = _arg(c, 'path');
    final abs = _resolve(path);
    if (abs == null) return _outside(path);
    final f = File(abs);
    if (!f.existsSync()) return AiToolResult('File not found: ${_rel(abs)}', error: true);
    final bytes = await f.readAsBytes();
    if (_isBinary(bytes)) return AiToolResult('${_rel(abs)} is a binary file (${_size(bytes.length)}).', error: true);
    final lines = const LineSplitter().convert(utf8.decode(bytes, allowMalformed: true));
    var a = (c.args['start_line'] is num) ? (c.args['start_line'] as num).toInt() : 1;
    var b = (c.args['end_line'] is num) ? (c.args['end_line'] as num).toInt() : lines.length;
    a = a.clamp(1, lines.isEmpty ? 1 : lines.length).toInt();
    b = b.clamp(a, lines.isEmpty ? 1 : lines.length).toInt();
    final sb = StringBuffer();
    var last = a - 1;
    for (var i = a; i <= b && i <= lines.length; i++) {
      final line = '$i\t${lines[i - 1]}\n';
      if (sb.length + line.length > _maxRead) break;
      sb.write(line);
      last = i;
    }
    final more = last < lines.length ? '\n… (${lines.length - last} more lines; use start_line/end_line)' : '';
    return AiToolResult('${_rel(abs)} (${lines.length} lines)\n$sb$more');
  }

  Future<AiToolResult> _search(AiToolCall c) async {
    final pattern = _arg(c, 'pattern');
    if (pattern.isEmpty) return const AiToolResult('pattern is empty', error: true);
    final path = _arg(c, 'path');
    final abs = _resolve(path);
    if (abs == null) return _outside(path);
    RegExp re;
    try {
      re = RegExp(pattern, caseSensitive: false);
    } catch (_) {
      re = RegExp(RegExp.escape(pattern), caseSensitive: false);
    }
    var inc = _arg(c, 'include').trim().toLowerCase();
    if (inc.startsWith('*')) inc = inc.substring(1);
    if (inc.isNotEmpty && !inc.startsWith('.')) inc = '.$inc';
    final hits = <String>[];
    var scanned = 0;

    Future<void> scan(File f) async {
      if (hits.length >= 80 || scanned > 4000) return;
      if (inc.isNotEmpty && !f.path.toLowerCase().endsWith(inc)) return;
      int len;
      try {
        len = await f.length();
      } catch (_) {
        return;
      }
      if (len > 1024 * 1024) return;
      scanned++;
      List<int> bytes;
      try {
        bytes = await f.readAsBytes();
      } catch (_) {
        return;
      }
      if (_isBinary(bytes)) return;
      final lines = const LineSplitter().convert(utf8.decode(bytes, allowMalformed: true));
      for (var i = 0; i < lines.length && hits.length < 80; i++) {
        if (re.hasMatch(lines[i])) {
          var t = lines[i].trim();
          if (t.length > 200) t = '${t.substring(0, 200)}…';
          hits.add('${_rel(f.path)}:${i + 1}: $t');
        }
      }
    }

    Future<void> walk(Directory d) async {
      List<FileSystemEntity> items;
      try {
        items = d.listSync(followLinks: false);
      } catch (_) {
        return;
      }
      for (final e in items) {
        if (hits.length >= 80 || scanned > 4000) return;
        if (e is Directory) {
          if (!_skipDirs.contains(p.basename(e.path))) await walk(e);
        } else if (e is File) {
          await scan(e);
        }
      }
    }

    if (File(abs).existsSync()) {
      await scan(File(abs));
    } else {
      await walk(Directory(abs));
    }
    if (hits.isEmpty) return AiToolResult('No matches for "$pattern" ($scanned files searched).');
    return AiToolResult('${hits.join('\n')}${hits.length >= 80 ? '\n… (first 80 matches)' : ''}');
  }

  Future<AiToolResult> _write(AiToolCall c) async {
    final path = _arg(c, 'path');
    final abs = _resolve(path);
    if (abs == null || abs == root) return _outside(path);
    final content = _arg(c, 'content');
    if (content.length > _maxWrite) return const AiToolResult('Content is too large (max 2 MB).', error: true);
    final f = File(abs);
    final existed = f.existsSync();
    await f.parent.create(recursive: true);
    await f.writeAsString(content, flush: true);
    return AiToolResult('${existed ? 'Overwrote' : 'Created'} ${_rel(abs)} (${content.split('\n').length} lines).', changed: [abs]);
  }

  Future<AiToolResult> _edit(AiToolCall c) async {
    final path = _arg(c, 'path');
    final abs = _resolve(path);
    if (abs == null || abs == root) return _outside(path);
    final f = File(abs);
    if (!f.existsSync()) return AiToolResult('File not found: ${_rel(abs)}', error: true);
    var oldT = _arg(c, 'old_text');
    var newT = _arg(c, 'new_text');
    if (oldT.isEmpty) return const AiToolResult('old_text is empty. To create or replace a whole file use write_file.', error: true);
    final bytes = await f.readAsBytes();
    if (_isBinary(bytes)) return AiToolResult('${_rel(abs)} is a binary file.', error: true);
    final text = utf8.decode(bytes, allowMalformed: true);
    var count = _count(text, oldT);
    if (count == 0 && text.contains('\r\n') && !oldT.contains('\r\n')) {
      // the file uses Windows line endings and the model wrote \n
      oldT = oldT.replaceAll('\n', '\r\n');
      newT = newT.replaceAll('\n', '\r\n');
      count = _count(text, oldT);
    }
    if (count == 0) {
      return const AiToolResult('old_text was not found. Read the file again and copy the text exactly (indentation included).', error: true);
    }
    final all = c.args['replace_all'] == true;
    if (count > 1 && !all) {
      return AiToolResult('old_text occurs $count times. Add more surrounding lines to make it unique, or set replace_all to true.', error: true);
    }
    final res = all ? text.replaceAll(oldT, newT) : text.replaceFirst(oldT, newT);
    await f.writeAsString(res, flush: true);
    return AiToolResult('Edited ${_rel(abs)} ($count replacement${count == 1 ? '' : 's'}).', changed: [abs]);
  }

  static int _count(String text, String sub) {
    var n = 0, i = 0;
    while (true) {
      i = text.indexOf(sub, i);
      if (i < 0) return n;
      n++;
      i += sub.length;
    }
  }

  Future<AiToolResult> _move(AiToolCall c) async {
    final from = _arg(c, 'from'), to = _arg(c, 'to');
    final a = _resolve(from), b = _resolve(to);
    if (a == null || a == root) return _outside(from);
    if (b == null || b == root) return _outside(to);
    final type = FileSystemEntity.typeSync(a);
    if (type == FileSystemEntityType.notFound) return AiToolResult('Not found: ${_rel(a)}', error: true);
    if (FileSystemEntity.typeSync(b) != FileSystemEntityType.notFound) return AiToolResult('Target already exists: ${_rel(b)}', error: true);
    await Directory(p.dirname(b)).create(recursive: true);
    if (type == FileSystemEntityType.directory) {
      await Directory(a).rename(b);
    } else {
      await File(a).rename(b);
    }
    return AiToolResult('Moved ${_rel(a)} → ${_rel(b)}.', changed: [a, b]);
  }

  Future<AiToolResult> _delete(AiToolCall c) async {
    final path = _arg(c, 'path');
    final abs = _resolve(path);
    if (abs == null || abs == root) return _outside(path);
    final type = FileSystemEntity.typeSync(abs);
    if (type == FileSystemEntityType.notFound) return AiToolResult('Not found: ${_rel(abs)}', error: true);
    if (type == FileSystemEntityType.directory) {
      await Directory(abs).delete(recursive: true);
    } else {
      await File(abs).delete();
    }
    return AiToolResult('Deleted ${_rel(abs)}.', changed: [abs]);
  }
}
