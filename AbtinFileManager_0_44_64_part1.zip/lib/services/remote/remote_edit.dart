import 'dart:convert';
import 'dart:io';
import 'package:crypto/crypto.dart';
import 'package:path/path.dart' as p;
import 'remote_factory.dart';
import 'remote_fs.dart';

/// What the server browser is asked to return to its caller.
enum RemotePickMode { none, file, folder }

/// Result of picking something on a server (a file or a folder path).
/// [profile] already carries the password typed by the user, if one was asked.
class RemotePick {
  final RemoteProfile profile;
  final String path;
  const RemotePick(this.profile, this.path);
}

typedef RemoteFsFactory = RemoteFs Function(RemoteProfile profile);

/// One remote file that is being edited.
///
/// The text editor works on a local cache copy ([cachePath]); [fetch] downloads
/// it and [push] uploads it back. Works with every [RemoteFs] (FTP, SFTP, SMB,
/// WebDAV, Dropbox, Drive).
///
///  * the connection can be handed in (the browser's) or is opened on demand;
///  * if a transfer fails the connection is re-opened ONCE and the transfer is
///    retried (idle FTP/SSH connections are dropped by servers);
///  * [changedRemotely] tells whether somebody else changed the file after it
///    was downloaded (size / modified time of the listing entry).
class RemoteDoc {
  /// Bigger files make the editor slow: the caller asks before opening them.
  static const int maxEditBytes = 2 * 1024 * 1024;

  final RemoteProfile profile;
  final String remotePath;
  final String cachePath;
  final RemoteFsFactory _factory;
  RemoteFs? _fs;
  bool _owns;
  bool _disposed = false;
  int? _baseSize;
  DateTime? _baseModified;

  RemoteDoc({
    required this.profile,
    required this.remotePath,
    required String cacheRoot,
    RemoteFs? fs,
    RemoteFsFactory factory = createRemote,
    String? salt,
  })  : _factory = factory,
        _fs = fs,
        _owns = fs == null,
        cachePath = cachePathFor(cacheRoot, profile, remotePath, salt ?? DateTime.now().microsecondsSinceEpoch.toString());

  /// `<root>/remote_edit/<hash>/<file name>`. [salt] makes every open of the
  /// same file use its own folder (two editors never share or delete each other's copy).
  static String cachePathFor(String root, RemoteProfile pr, String remotePath, String salt) {
    final key = md5.convert(utf8.encode('${pr.id}|${pr.type}|${pr.host}|$remotePath|$salt')).toString().substring(0, 12);
    final n = RPath.name(remotePath);
    return p.join(root, 'remote_edit', key, n.isEmpty ? 'file' : n);
  }

  String get name => RPath.name(remotePath);

  /// Short text for the title bar, e.g. `SFTP • my server`.
  String get label {
    final n = profile.name.isNotEmpty ? profile.name : (profile.host.isNotEmpty ? profile.host : profile.type);
    return '${profile.type.toUpperCase()} • $n';
  }

  /// true when the listing entry differs from the one seen at download time.
  /// Values that are unknown (null) never count as a difference.
  static bool differs(int? baseSize, DateTime? baseTime, int? size, DateTime? time) {
    if (baseSize != null && size != null && baseSize != size) return true;
    if (baseTime != null && time != null && !baseTime.isAtSameMomentAs(time)) return true;
    return false;
  }

  Future<RemoteFs> _live() async {
    final cur = _fs;
    if (cur != null) return cur;
    final fresh = _factory(profile);
    await fresh.connect();
    _fs = fresh;
    _owns = true;
    return fresh;
  }

  /// Runs [job]; on failure re-opens the connection once and runs it again.
  /// When the reconnect itself fails, the ORIGINAL error is reported.
  Future<T> _run<T>(Future<T> Function(RemoteFs fs) job) async {
    final fs = await _live();
    try {
      return await job(fs);
    } catch (first) {
      final fresh = _factory(profile);
      try {
        await fresh.connect();
      } catch (_) {
        throw first;
      }
      if (_owns) {
        try {
          await _fs?.close();
        } catch (_) {}
      }
      _fs = fresh;
      _owns = true;
      return await job(fresh);
    }
  }

  Future<RemoteEntry?> _stat(RemoteFs fs) async {
    try {
      for (final e in await fs.list(RPath.parent(remotePath))) {
        if (e.name == name && !e.dir) return e;
      }
    } catch (_) {}
    return null;
  }

  Future<void> _snapshot() async {
    final e = await _stat(await _live());
    _baseSize = e?.size;
    _baseModified = e?.modified;
  }

  /// Downloads the remote file into [cachePath] and remembers its size / time.
  Future<void> fetch({Prog? onProgress}) async {
    await File(cachePath).parent.create(recursive: true);
    await _run((fs) => fs.download(remotePath, cachePath, onProgress: onProgress));
    await _snapshot();
  }

  /// true = the file on the server is not the one that was downloaded / last saved.
  Future<bool> changedRemotely() async {
    final e = await _stat(await _live());
    return differs(_baseSize, _baseModified, e?.size, e?.modified);
  }

  /// Writes the editor text to the local cache file (no upload).
  Future<void> writeCache(String text) async {
    final f = File(cachePath);
    await f.parent.create(recursive: true);
    await f.writeAsString(text, flush: true);
  }

  /// Uploads the cache file over the remote file, then takes a fresh snapshot.
  Future<void> push({Prog? onProgress}) async {
    await _run((fs) => fs.upload(cachePath, remotePath, onProgress: onProgress));
    await _snapshot();
  }

  /// Closes a connection this object opened itself (a handed-in one is not
  /// ours) and removes the cache copy. Safe to call twice.
  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    if (_owns) {
      try {
        await _fs?.close();
      } catch (_) {}
    }
    _fs = null;
    try {
      final d = File(cachePath).parent;
      if (await d.exists()) await d.delete(recursive: true);
    } catch (_) {}
  }
}
