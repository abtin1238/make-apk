import 'dart:io';

import 'package:path/path.dart' as p;

import 'native.dart';

/// Builds a previewable HTML page from an HTML / SVG / CSS / JS / Markdown file
/// and shows it in Android's own WebView (native `PreviewActivity`).
class WebPreview {
  static const _htmlExts = {'html', 'htm', 'xhtml'};
  static const _mdExts = {'md', 'markdown', 'mdx'};
  static const _jsExts = {'js', 'mjs'};

  static String _ext(String path) {
    final e = p.extension(path).toLowerCase();
    return e.startsWith('.') ? e.substring(1) : e;
  }

  /// true for files that have a preview.
  static bool supportsPath(String path) {
    final e = _ext(path);
    return _htmlExts.contains(e) || _mdExts.contains(e) || _jsExts.contains(e) || e == 'svg' || e == 'css';
  }

  static const _viewport = '<meta name="viewport" content="width=device-width, initial-scale=1">';

  /// Full HTML document to display for [path] whose current (maybe unsaved) text is [text].
  static String build(String path, String text) {
    final e = _ext(path);
    if (_htmlExts.contains(e)) return _withViewport(text);
    if (e == 'svg') return _svgPage(text);
    if (e == 'css') return _cssPage(path, text);
    if (_mdExts.contains(e)) return _mdPage(text);
    if (_jsExts.contains(e)) return _jsPage(text);
    return _withViewport(text);
  }

  static String _withViewport(String html) {
    if (RegExp(r'<meta[^>]+name\s*=\s*["' "'" r']viewport', caseSensitive: false).hasMatch(html)) return html;
    final head = RegExp(r'<head[^>]*>', caseSensitive: false).firstMatch(html);
    if (head != null) return html.replaceRange(head.end, head.end, _viewport);
    final doc = RegExp(r'<html[^>]*>', caseSensitive: false).firstMatch(html);
    if (doc != null) return html.replaceRange(doc.end, doc.end, '<head>$_viewport</head>');
    return '$_viewport\n$html';
  }

  static String _svgPage(String svg) {
    final body = svg
        .replaceAll(RegExp(r'<\?xml[^>]*\?>', caseSensitive: false), '')
        .replaceAll(RegExp(r'<!DOCTYPE[^>]*>', caseSensitive: false), '');
    return '<!doctype html><html><head><meta charset="utf-8">$_viewport'
        '<style>html,body{margin:0;height:100%;background:#fff}'
        'body{display:flex;align-items:center;justify-content:center}'
        'svg{max-width:100%;max-height:100vh}</style></head><body>$body</body></html>';
  }

  static String _jsPage(String code) {
    final safe = code.replaceAll(RegExp(r'</script', caseSensitive: false), r'<\/script');
    return '<!doctype html><html><head><meta charset="utf-8">$_viewport'
        '<style>body{font-family:sans-serif;padding:12px}</style></head><body>'
        '<div id="app"></div><div id="root"></div><script>\n$safe\n</script></body></html>';
  }

  static const _sample = '''
<h1>Heading 1</h1><h2>Heading 2</h2><h3>Heading 3</h3>
<p>A paragraph with a <a href="#">link</a>, <strong>bold</strong>, <em>italic</em> and <code>code</code>.</p>
<ul><li>First</li><li>Second</li><li>Third</li></ul>
<p><button>Button</button> <input placeholder="Input"> <select><option>Select</option></select></p>
<table border="1" cellpadding="6"><tr><th>A</th><th>B</th></tr><tr><td>1</td><td>2</td></tr></table>
<div class="box card container"><p>.box .card .container</p></div>
''';

  static String _cssPage(String path, String css) {
    final dir = p.dirname(path);
    final stem = p.basenameWithoutExtension(path);
    String? page;
    for (final name in ['$stem.html', '$stem.htm', 'index.html']) {
      final f = File(p.join(dir, name));
      try {
        if (f.existsSync()) {
          page = f.readAsStringSync();
          break;
        }
      } catch (_) {}
    }
    final style = '<style>\n$css\n</style>';
    if (page == null) {
      return '<!doctype html><html><head><meta charset="utf-8">$_viewport$style</head><body>$_sample</body></html>';
    }
    page = _withViewport(page);
    final close = RegExp(r'</head>', caseSensitive: false).firstMatch(page);
    if (close != null) return page.replaceRange(close.start, close.start, style);
    return '$page$style';
  }

  // ---- Markdown -------------------------------------------------------------

  static String _esc(String s) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');

  static String _inline(String raw) {
    final codes = <String>[];
    var s = raw.replaceAllMapped(RegExp(r'`([^`\n]+)`'), (m) {
      codes.add('<code>${_esc(m.group(1)!)}</code>');
      return '\u0000${codes.length - 1}\u0000';
    });
    s = _esc(s);
    s = s.replaceAllMapped(RegExp(r'!\[([^\]\n]*)\]\(([^)\s\n]+)(?:\s+&quot;[^\n]*?&quot;)?\)'), (m) => '<img alt="${m.group(1)}" src="${m.group(2)}">');
    s = s.replaceAllMapped(RegExp(r'\[([^\]\n]+)\]\(([^)\s\n]+)(?:\s+&quot;[^\n]*?&quot;)?\)'), (m) => '<a href="${m.group(2)}">${m.group(1)}</a>');
    s = s.replaceAllMapped(RegExp(r'\*\*([^*\n]+)\*\*|__([^_\n]+)__'), (m) => '<strong>${m.group(1) ?? m.group(2)}</strong>');
    s = s.replaceAllMapped(RegExp(r'(?<![\w*])\*([^*\n]+)\*(?![\w*])|(?<![\w_])_([^_\n]+)_(?![\w_])'), (m) => '<em>${m.group(1) ?? m.group(2)}</em>');
    s = s.replaceAllMapped(RegExp(r'~~([^~\n]+)~~'), (m) => '<del>${m.group(1)}</del>');
    s = s.replaceAllMapped(RegExp('\u0000(\\d+)\u0000'), (m) => codes[int.parse(m.group(1)!)]);
    return s;
  }

  static List<String> _cells(String line) {
    var t = line.trim();
    if (t.startsWith('|')) t = t.substring(1);
    if (t.endsWith('|')) t = t.substring(0, t.length - 1);
    return t.split('|').map((c) => c.trim()).toList();
  }

  /// Small Markdown -> HTML converter (headings, lists, code, quotes, tables, links, images, emphasis).
  static String markdown(String src) {
    final lines = src.replaceAll('\r\n', '\n').split('\n');
    final out = StringBuffer();
    final para = <String>[];
    String? list;
    void flushPara() {
      if (para.isNotEmpty) {
        out.write('<p>${_inline(para.join(' '))}</p>\n');
        para.clear();
      }
    }

    void closeList() {
      if (list != null) {
        out.write('</$list>\n');
        list = null;
      }
    }

    final tableSep = RegExp(r'^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$');
    var i = 0;
    while (i < lines.length) {
      final t = lines[i].trimRight();
      if (t.trimLeft().startsWith('```')) {
        flushPara();
        closeList();
        final buf = <String>[];
        i++;
        while (i < lines.length && !lines[i].trimLeft().startsWith('```')) {
          buf.add(lines[i]);
          i++;
        }
        i++;
        out.write('<pre><code>${_esc(buf.join('\n'))}</code></pre>\n');
        continue;
      }
      if (t.trim().isEmpty) {
        flushPara();
        closeList();
        i++;
        continue;
      }
      final h = RegExp(r'^\s{0,3}(#{1,6})\s+(.*?)\s*#*\s*$').firstMatch(t);
      if (h != null) {
        flushPara();
        closeList();
        final n = h.group(1)!.length;
        out.write('<h$n>${_inline(h.group(2)!)}</h$n>\n');
        i++;
        continue;
      }
      if (RegExp(r'^\s*([-*_])(?:\s*\1){2,}\s*$').hasMatch(t)) {
        flushPara();
        closeList();
        out.write('<hr>\n');
        i++;
        continue;
      }
      if (RegExp(r'^\s*>').hasMatch(t)) {
        flushPara();
        closeList();
        final buf = <String>[];
        while (i < lines.length && RegExp(r'^\s*>').hasMatch(lines[i])) {
          buf.add(lines[i].replaceFirst(RegExp(r'^\s*>\s?'), '').trim());
          i++;
        }
        out.write('<blockquote>${_inline(buf.join(' '))}</blockquote>\n');
        continue;
      }
      final li = RegExp(r'^\s*([-*+]|\d+[.)])\s+(.*)$').firstMatch(t);
      if (li != null) {
        flushPara();
        final type = RegExp(r'\d').hasMatch(li.group(1)!) ? 'ol' : 'ul';
        if (list != type) {
          closeList();
          out.write('<$type>\n');
          list = type;
        }
        var item = li.group(2)!;
        final task = RegExp(r'^\[([ xX])\]\s+(.*)$').firstMatch(item);
        if (task != null) {
          item = '<input type="checkbox" disabled${task.group(1) != ' ' ? ' checked' : ''}> ${_inline(task.group(2)!)}';
        } else {
          item = _inline(item);
        }
        out.write('<li>$item</li>\n');
        i++;
        continue;
      }
      if (t.contains('|') && i + 1 < lines.length && tableSep.hasMatch(lines[i + 1])) {
        flushPara();
        closeList();
        final head = _cells(t);
        out.write('<table><thead><tr>${head.map((c) => '<th>${_inline(c)}</th>').join()}</tr></thead><tbody>\n');
        i += 2;
        while (i < lines.length && lines[i].trim().isNotEmpty && lines[i].contains('|')) {
          out.write('<tr>${_cells(lines[i]).map((c) => '<td>${_inline(c)}</td>').join()}</tr>\n');
          i++;
        }
        out.write('</tbody></table>\n');
        continue;
      }
      closeList();
      para.add(t.trim());
      i++;
    }
    flushPara();
    closeList();
    return out.toString();
  }

  static const _mdCss = '''
body{font-family:-apple-system,Roboto,"Vazir",sans-serif;line-height:1.7;max-width:820px;margin:0 auto;padding:16px;color:#1f2328;background:#fff;word-wrap:break-word}
h1,h2{border-bottom:1px solid #d0d7de;padding-bottom:.3em}
p,li,h1,h2,h3,h4,h5,h6,blockquote,td,th{unicode-bidi:plaintext}
code{background:#afb8c133;padding:.15em .4em;border-radius:6px;font-family:monospace;font-size:90%}
pre{background:#f6f8fa;padding:12px;border-radius:8px;overflow:auto}pre code{background:none;padding:0}
blockquote{margin:0;padding:0 1em;color:#59636e;border-left:4px solid #d0d7de}
table{border-collapse:collapse;display:block;overflow:auto}th,td{border:1px solid #d0d7de;padding:6px 12px}
img{max-width:100%}a{color:#0969da}hr{border:0;border-top:1px solid #d0d7de}
@media (prefers-color-scheme:dark){body{color:#e6edf3;background:#0d1117}pre{background:#161b22}h1,h2,th,td,hr{border-color:#30363d}blockquote{color:#9198a1;border-color:#30363d}a{color:#4493f8}}
''';

  static String _mdPage(String md) => '<!doctype html><html><head><meta charset="utf-8">$_viewport'
      '<meta name="color-scheme" content="light dark"><style>$_mdCss</style></head><body>${markdown(md)}</body></html>';

  // ---- opening --------------------------------------------------------------

  static Future<Map<String, String>> _prepare(String path, String text) async {
    final dir = Directory(p.join(Directory.systemTemp.path, 'abtin_preview'));
    if (!dir.existsSync()) dir.createSync(recursive: true);
    final f = File(p.join(dir.path, 'preview.html'));
    await f.writeAsString(build(path, text), flush: true);
    return {'file': f.path, 'base': Uri.directory(p.dirname(path)).toString()};
  }

  /// Opens the preview. [textOf] gives the editor's current text; it is called again on every reload.
  static Future<bool> open(String path, String Function() textOf) async {
    final a = await _prepare(path, textOf());
    Native.previewReload = () => _prepare(path, textOf());
    return Native.openPreview(
      file: a['file']!,
      base: a['base']!,
      title: p.basename(path),
      console: _jsExts.contains(_ext(path)),
    );
  }
}
