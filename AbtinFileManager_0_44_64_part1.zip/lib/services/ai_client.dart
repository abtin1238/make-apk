import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'ai_settings.dart';

/// A tool the model may call (file access inside the project).
class AiToolDef {
  const AiToolDef(this.name, this.description, this.schema);
  final String name;
  final String description;

  /// JSON schema of the arguments (`{"type":"object","properties":{...},"required":[...]}`).
  final Map<String, dynamic> schema;
}

class AiToolCall {
  AiToolCall(this.id, this.name, this.args, {this.rawArgs = ''});
  String id;
  String name;
  Map<String, dynamic> args;
  String rawArgs;
  bool badJson = false;

  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'args': args, 'raw': rawArgs};

  static AiToolCall fromJson(Map<String, dynamic> j) => AiToolCall(
        '${j['id'] ?? ''}',
        '${j['name'] ?? ''}',
        Map<String, dynamic>.from((j['args'] as Map?) ?? const {}),
        rawArgs: '${j['raw'] ?? ''}',
      );
}

/// One message of the conversation (provider independent).
class AiMsg {
  AiMsg._(this.role, this.text, {this.reasoning = '', this.context = '', this.attachLabel = '', List<AiToolCall>? calls, this.callId = '', this.name = '', this.isError = false})
      : calls = calls ?? <AiToolCall>[];

  factory AiMsg.user(String text, {String context = '', String attachLabel = ''}) => AiMsg._('user', text, context: context, attachLabel: attachLabel);
  factory AiMsg.assistant({String text = '', String reasoning = '', List<AiToolCall>? calls}) => AiMsg._('assistant', text, reasoning: reasoning, calls: calls);
  factory AiMsg.tool({required String callId, required String name, required String text, bool isError = false}) =>
      AiMsg._('tool', text, callId: callId, name: name, isError: isError);

  final String role; // user | assistant | tool
  String text;
  String reasoning;

  /// user: extra context sent to the model only (current file / selection); the chat shows [attachLabel].
  String context;
  String attachLabel;
  final List<AiToolCall> calls;
  final String callId;
  final String name;
  final bool isError;

  /// Text as the model sees it.
  String get apiText => context.isEmpty ? text : '$context\n\n$text';

  Map<String, dynamic> toJson() => {
        'role': role,
        'text': text,
        'reasoning': reasoning,
        'context': context,
        'label': attachLabel,
        'calls': [for (final c in calls) c.toJson()],
        'callId': callId,
        'name': name,
        'err': isError,
      };

  static AiMsg fromJson(Map<String, dynamic> j) => AiMsg._(
        '${j['role'] ?? 'user'}',
        '${j['text'] ?? ''}',
        reasoning: '${j['reasoning'] ?? ''}',
        context: '${j['context'] ?? ''}',
        attachLabel: '${j['label'] ?? ''}',
        calls: [for (final c in (j['calls'] as List? ?? const [])) AiToolCall.fromJson(Map<String, dynamic>.from(c as Map))],
        callId: '${j['callId'] ?? ''}',
        name: '${j['name'] ?? ''}',
        isError: j['err'] == true,
      );
}

class AiTurn {
  String text = '';
  String reasoning = '';
  final List<AiToolCall> calls = [];
  String finish = '';
  int inTokens = 0, outTokens = 0;
}

class AiError implements Exception {
  AiError(this.message, {this.status});
  final String message;
  final int? status;
  @override
  String toString() => message;
}

/// Lets the UI abort a running request.
class AiCancel {
  bool cancelled = false;
  HttpClient? _client;
  void cancel() {
    cancelled = true;
    try {
      _client?.close(force: true);
    } catch (_) {}
  }
}

/// Talks to the providers with plain `dart:io` (no extra packages): streaming chat with tool calls.
class AiClient {
  static Uri _endpoint(AiProvider p, String base, String what) {
    var b = base.trim();
    while (b.endsWith('/')) {
      b = b.substring(0, b.length - 1);
    }
    if (p.protocol == AiProtocol.openai) return Uri.parse('$b/$what');
    return Uri.parse(b.endsWith('/v1') ? '$b/$what' : '$b/v1/$what');
  }

  static const _userAgent = 'Mozilla/5.0 (Linux; Android 14; Mobile) AbtinFileManager/0.44 OpenAI-compatible-client';

  static Map<String, String> _headers(AiProvider p, String key) {
    final h = <String, String>{'accept': 'application/json', 'user-agent': _userAgent};
    if (p.protocol == AiProtocol.anthropic) {
      h['anthropic-version'] = '2023-06-01';
      if (key.isNotEmpty) h['x-api-key'] = key;
    } else if (key.isNotEmpty) {
      h['authorization'] = 'Bearer $key';
    }
    if (p.id == 'openrouter') {
      h['x-title'] = 'Abtin File Manager';
    }
    return h;
  }

  static Future<HttpClientResponse> _open(String method, Uri url, Map<String, String> headers, String? body, AiCancel cancel) async {
    // Cloudflare-fronted APIs (Moonshot/Kimi, ...) answer the default "Dart/x (dart:io)" agent with a 403 HTML challenge page.
    final c = HttpClient()
      ..connectionTimeout = const Duration(seconds: 30)
      ..userAgent = _userAgent;
    cancel._client = c;
    try {
      final req = method == 'POST' ? await c.postUrl(url) : await c.getUrl(url);
      headers.forEach((k, v) => req.headers.set(k, v));
      if (body != null) {
        req.headers.contentType = ContentType('application', 'json', charset: 'utf-8');
        final bytes = utf8.encode(body);
        req.contentLength = bytes.length;
        req.add(bytes);
      }
      return await req.close();
    } catch (e) {
      c.close(force: true);
      if (cancel.cancelled) throw AiError('cancelled');
      throw AiError('اتصال برقرار نشد / Connection failed: $e');
    }
  }

  static Future<String> _readAll(HttpClientResponse r) async {
    final b = StringBuffer();
    await for (final s in r.transform(utf8.decoder)) {
      b.write(s);
      if (b.length > 8000) break;
    }
    return b.toString();
  }

  static String _errText(int status, String body) {
    var msg = body.trim();
    final low = msg.toLowerCase();
    if (low.contains('<html') || low.contains('<!doctype') || low.contains('cloudflare')) {
      final cf = low.contains('cloudflare');
      return 'HTTP $status: ${cf ? 'درخواست توسط Cloudflare سرور مسدود شد (مشکل کلید نیست؛ معمولاً به‌خاطر IP/VPN یا کشور). VPN را عوض/خاموش کنید یا نشانی پایه را روی api.moonshot.cn (کلید پلتفرم چین) بگذارید. / Blocked by Cloudflare in front of the API (not a key problem): change/disable VPN, or try another base URL.' : 'پاسخ HTML از سرور (نشانی پایه اشتباه است؟) / Got an HTML page instead of API JSON (wrong base URL?)'}';
    }
    try {
      final j = jsonDecode(body);
      if (j is Map) {
        final e = j['error'];
        if (e is Map && e['message'] != null) {
          msg = '${e['message']}';
        } else if (e is String) {
          msg = e;
        } else if (j['message'] != null) {
          msg = '${j['message']}';
        }
      } else if (j is List && j.isNotEmpty && j.first is Map && (j.first as Map)['error'] is Map) {
        msg = '${((j.first as Map)['error'] as Map)['message']}';
      }
    } catch (_) {}
    if (msg.length > 600) msg = '${msg.substring(0, 600)}…';
    final hint = switch (status) {
      401 || 403 => ' (کلید API نامعتبر یا بدون دسترسی / invalid key)',
      404 => ' (نشانی یا نام مدل اشتباه است / wrong URL or model)',
      429 => ' (محدودیت نرخ یا اعتبار تمام شده / rate limit or no credit)',
      _ => '',
    };
    return 'HTTP $status$hint: $msg';
  }

  /// Model ids offered by the provider (`GET /models`).
  static Future<List<String>> listModels(AiProvider p, String baseUrl, String key) async {
    final cancel = AiCancel();
    final r = await _open('GET', _endpoint(p, baseUrl, 'models'), _headers(p, key), null, cancel);
    try {
      final body = await _readAll(r).timeout(const Duration(seconds: 30));
      if (r.statusCode != 200) throw AiError(_errText(r.statusCode, body), status: r.statusCode);
      final j = jsonDecode(body);
      final data = j is Map ? (j['data'] ?? j['models']) : null;
      final out = <String>[];
      if (data is List) {
        for (final e in data) {
          if (e is Map && e['id'] != null) {
            out.add('${e['id']}');
          } else if (e is Map && e['name'] != null) {
            out.add('${e['name']}'.replaceFirst('models/', ''));
          }
        }
      }
      out.sort();
      return out;
    } finally {
      cancel._client?.close(force: true);
    }
  }

  /// One model turn: streams text/reasoning through [onText]/[onReasoning] and returns the full turn.
  static Future<AiTurn> stream({
    required AiProvider provider,
    required String baseUrl,
    required String apiKey,
    required String model,
    required String system,
    required List<AiMsg> history,
    required List<AiToolDef> tools,
    required int maxTokens,
    required AiCancel cancel,
    required void Function(String) onText,
    required void Function(String) onReasoning,
  }) {
    if (provider.protocol == AiProtocol.anthropic) {
      return _streamAnthropic(provider, baseUrl, apiKey, model, system, history, tools, maxTokens, cancel, onText, onReasoning);
    }
    return _streamOpenAi(provider, baseUrl, apiKey, model, system, history, tools, cancel, onText, onReasoning);
  }

  // ------------------------------------------------------------------ SSE
  static Stream<String> _sseData(HttpClientResponse r) {
    return r
        .transform(utf8.decoder)
        .transform(const LineSplitter())
        .timeout(const Duration(seconds: 180), onTimeout: (s) {
      s.addError(AiError('پاسخی نرسید (timeout) / No data from the server for 3 minutes'));
      s.close();
    }).where((l) => l.startsWith('data:')).map((l) => l.substring(5).trim()).where((l) => l.isNotEmpty);
  }

  // ------------------------------------------------------------------ OpenAI-style
  static List<Map<String, dynamic>> _openAiMessages(String system, List<AiMsg> h) {
    final out = <Map<String, dynamic>>[];
    if (system.isNotEmpty) out.add({'role': 'system', 'content': system});
    final lastUser = h.lastIndexWhere((m) => m.role == 'user');
    for (var i = 0; i < h.length; i++) {
      final m = h[i];
      if (m.role == 'user') {
        out.add({'role': 'user', 'content': m.apiText});
      } else if (m.role == 'assistant') {
        if (m.text.isEmpty && m.calls.isEmpty) continue;
        final o = <String, dynamic>{'role': 'assistant', 'content': m.text};
        if (m.calls.isNotEmpty) {
          o['tool_calls'] = [
            for (final c in m.calls)
              {
                'id': c.id,
                'type': 'function',
                'function': {'name': c.name, 'arguments': c.rawArgs.isNotEmpty && !c.badJson ? c.rawArgs : jsonEncode(c.args)},
              }
          ];
          // Reasoning models (DeepSeek, Kimi) want their own thinking back while a tool loop is running.
          if (m.reasoning.isNotEmpty && i > lastUser) o['reasoning_content'] = m.reasoning;
        }
        out.add(o);
      } else {
        out.add({'role': 'tool', 'tool_call_id': m.callId, 'content': m.text});
      }
    }
    return out;
  }

  static Future<AiTurn> _streamOpenAi(AiProvider p, String baseUrl, String key, String model, String system, List<AiMsg> history,
      List<AiToolDef> tools, AiCancel cancel, void Function(String) onText, void Function(String) onReasoning) async {
    final body = <String, dynamic>{
      'model': model,
      'messages': _openAiMessages(system, history),
      'stream': true,
    };
    if (p.id == 'openai' || p.id == 'xai' || p.id == 'openrouter') body['stream_options'] = {'include_usage': true};
    if (tools.isNotEmpty) {
      body['tools'] = [
        for (final t in tools)
          {
            'type': 'function',
            'function': {'name': t.name, 'description': t.description, 'parameters': t.schema},
          }
      ];
    }
    final r = await _open('POST', _endpoint(p, baseUrl, 'chat/completions'), _headers(p, key), jsonEncode(body), cancel);
    final turn = AiTurn();
    try {
      if (r.statusCode != 200) throw AiError(_errText(r.statusCode, await _readAll(r)), status: r.statusCode);
      final acc = <int, AiToolCall>{};
      final textB = StringBuffer(), thinkB = StringBuffer();
      try {
        await for (final data in _sseData(r)) {
          if (cancel.cancelled) throw AiError('cancelled');
          if (data == '[DONE]') break;
          Map<String, dynamic> j;
          try {
            j = jsonDecode(data) as Map<String, dynamic>;
          } catch (_) {
            continue;
          }
          if (j['error'] != null) {
            final e = j['error'];
            throw AiError(e is Map ? '${e['message']}' : '$e');
          }
          final u = j['usage'];
          if (u is Map) {
            turn.inTokens = (u['prompt_tokens'] as num?)?.toInt() ?? turn.inTokens;
            turn.outTokens = (u['completion_tokens'] as num?)?.toInt() ?? turn.outTokens;
          }
          final choices = j['choices'];
          if (choices is! List || choices.isEmpty) continue;
          final ch = choices.first as Map;
          final fr = ch['finish_reason'];
          if (fr != null) turn.finish = '$fr';
          final d = ch['delta'];
          if (d is! Map) continue;
          final rc = d['reasoning_content'] ?? d['reasoning'];
          if (rc is String && rc.isNotEmpty) {
            thinkB.write(rc);
            onReasoning(rc);
          }
          final c = d['content'];
          if (c is String && c.isNotEmpty) {
            textB.write(c);
            onText(c);
          }
          final tcs = d['tool_calls'];
          if (tcs is List) {
            for (var k = 0; k < tcs.length; k++) {
              final tc = tcs[k] as Map;
              final idx = (tc['index'] as num?)?.toInt() ?? k;
              final call = acc.putIfAbsent(idx, () => AiToolCall('', '', {}));
              final id = tc['id'];
              if (id is String && id.isNotEmpty) call.id = id;
              final f = tc['function'];
              if (f is Map) {
                final n = f['name'];
                if (n is String && n.isNotEmpty && call.name.isEmpty) call.name = n;
                final a = f['arguments'];
                if (a is String) call.rawArgs += a;
              }
            }
          }
        }
      } on AiError {
        rethrow;
      } catch (e) {
        if (cancel.cancelled) throw AiError('cancelled');
        throw AiError('خطا در دریافت پاسخ / Stream error: $e');
      }
      turn.text = textB.toString();
      turn.reasoning = thinkB.toString();
      final keys = acc.keys.toList()..sort();
      var n = 0;
      for (final k in keys) {
        final c = acc[k]!;
        if (c.name.isEmpty) continue;
        if (c.id.isEmpty) c.id = 'call_${DateTime.now().microsecondsSinceEpoch}_${n++}';
        _parseArgs(c);
        turn.calls.add(c);
      }
      return turn;
    } finally {
      cancel._client?.close(force: true);
    }
  }

  static void _parseArgs(AiToolCall c) {
    final raw = c.rawArgs.trim();
    if (raw.isEmpty) {
      c.args = {};
      return;
    }
    try {
      final v = jsonDecode(raw);
      if (v is Map) {
        c.args = Map<String, dynamic>.from(v);
      } else {
        c.badJson = true;
      }
    } catch (_) {
      c.badJson = true;
    }
  }

  // ------------------------------------------------------------------ Anthropic
  static List<Map<String, dynamic>> _anthropicMessages(List<AiMsg> h) {
    final out = <Map<String, dynamic>>[];
    List<Map<String, dynamic>>? results;
    void flush() {
      if (results != null && results!.isNotEmpty) out.add({'role': 'user', 'content': results});
      results = null;
    }

    for (final m in h) {
      if (m.role == 'tool') {
        (results ??= <Map<String, dynamic>>[]).add({
          'type': 'tool_result',
          'tool_use_id': m.callId,
          'content': m.text.isEmpty ? '(empty)' : m.text,
          if (m.isError) 'is_error': true,
        });
        continue;
      }
      flush();
      if (m.role == 'user') {
        out.add({'role': 'user', 'content': m.apiText});
      } else {
        final blocks = <Map<String, dynamic>>[
          if (m.text.trim().isNotEmpty) {'type': 'text', 'text': m.text},
          for (final c in m.calls) {'type': 'tool_use', 'id': c.id, 'name': c.name, 'input': c.args},
        ];
        if (blocks.isEmpty) continue;
        out.add({'role': 'assistant', 'content': blocks});
      }
    }
    flush();
    return out;
  }

  static Future<AiTurn> _streamAnthropic(AiProvider p, String baseUrl, String key, String model, String system, List<AiMsg> history,
      List<AiToolDef> tools, int maxTokens, AiCancel cancel, void Function(String) onText, void Function(String) onReasoning) async {
    final body = <String, dynamic>{
      'model': model,
      'max_tokens': maxTokens,
      'stream': true,
      'messages': _anthropicMessages(history),
      if (system.isNotEmpty) 'system': system,
      if (tools.isNotEmpty) 'tools': [for (final t in tools) {'name': t.name, 'description': t.description, 'input_schema': t.schema}],
    };
    final r = await _open('POST', _endpoint(p, baseUrl, 'messages'), _headers(p, key), jsonEncode(body), cancel);
    final turn = AiTurn();
    try {
      if (r.statusCode != 200) throw AiError(_errText(r.statusCode, await _readAll(r)), status: r.statusCode);
      final blocks = <int, AiToolCall>{};
      final textB = StringBuffer(), thinkB = StringBuffer();
      try {
        await for (final data in _sseData(r)) {
          if (cancel.cancelled) throw AiError('cancelled');
          Map<String, dynamic> j;
          try {
            j = jsonDecode(data) as Map<String, dynamic>;
          } catch (_) {
            continue;
          }
          switch (j['type']) {
            case 'message_start':
              final u = (j['message'] as Map?)?['usage'];
              if (u is Map) turn.inTokens = (u['input_tokens'] as num?)?.toInt() ?? 0;
              break;
            case 'content_block_start':
              final idx = (j['index'] as num?)?.toInt() ?? 0;
              final cb = j['content_block'];
              if (cb is Map && cb['type'] == 'tool_use') {
                blocks[idx] = AiToolCall('${cb['id'] ?? ''}', '${cb['name'] ?? ''}', {});
              }
              break;
            case 'content_block_delta':
              final idx = (j['index'] as num?)?.toInt() ?? 0;
              final d = j['delta'];
              if (d is! Map) break;
              if (d['type'] == 'text_delta') {
                final t = '${d['text'] ?? ''}';
                textB.write(t);
                onText(t);
              } else if (d['type'] == 'thinking_delta') {
                final t = '${d['thinking'] ?? ''}';
                thinkB.write(t);
                onReasoning(t);
              } else if (d['type'] == 'input_json_delta') {
                blocks[idx]?.rawArgs += '${d['partial_json'] ?? ''}';
              }
              break;
            case 'message_delta':
              final d = j['delta'];
              if (d is Map && d['stop_reason'] != null) turn.finish = '${d['stop_reason']}';
              final u = j['usage'];
              if (u is Map) turn.outTokens = (u['output_tokens'] as num?)?.toInt() ?? turn.outTokens;
              break;
            case 'error':
              final e = j['error'];
              throw AiError(e is Map ? '${e['message']}' : '$e');
          }
        }
      } on AiError {
        rethrow;
      } catch (e) {
        if (cancel.cancelled) throw AiError('cancelled');
        throw AiError('خطا در دریافت پاسخ / Stream error: $e');
      }
      turn.text = textB.toString();
      turn.reasoning = thinkB.toString();
      final keys = blocks.keys.toList()..sort();
      for (final k in keys) {
        final c = blocks[k]!;
        if (c.name.isEmpty) continue;
        _parseArgs(c);
        turn.calls.add(c);
      }
      return turn;
    } finally {
      cancel._client?.close(force: true);
    }
  }
}
