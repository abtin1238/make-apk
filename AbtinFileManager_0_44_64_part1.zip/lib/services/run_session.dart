import 'dart:async';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:xterm/xterm.dart';

import 'code_runner.dart';
import 'terminal_native.dart';

enum RunState { idle, starting, running, needAlpine, needInstall, done, error }

/// One "Run code" session: starts a PTY shell in the file's folder, sources a
/// generated script that runs the file inside Alpine (proot) and streams the
/// output into [terminal]. The program's stdin is the PTY, so input() etc. work.
class RunSession extends ChangeNotifier {
  final Terminal terminal = Terminal(maxLines: 5000);
  final TerminalNative _native = TerminalNative();
  StreamSubscription<Map<String, dynamic>>? _sub;
  String? _id;
  RunOutputFilter _filter = RunOutputFilter();
  final Stopwatch _sw = Stopwatch();
  int _cols = 80, _rows = 24;
  bool _disposed = false;

  RunState state = RunState.idle;
  LangRunner? runner;
  int? exitCode;
  String needPkgs = '';
  Duration? elapsed;

  /// Bumped on every run (lets the UI ask about installing only once per run).
  int runId = 0;

  bool get running => state == RunState.starting || state == RunState.running;

  RunSession() {
    terminal.onOutput = (data) {
      final id = _id;
      if (id != null) unawaited(_native.writeRaw(id, data).catchError((_) {}));
    };
    terminal.onResize = (columns, rows, _, __) {
      _cols = columns.clamp(20, 500).toInt();
      _rows = rows.clamp(5, 300).toInt();
      final id = _id;
      if (id != null) unawaited(_native.resize(id, _cols, _rows).catchError((_) {}));
    };
  }

  void _notify() {
    if (!_disposed) notifyListeners();
  }

  Future<void> run({
    required String filePath,
    required LangRunner runner,
    String args = '',
    RunPre pre = RunPre.none,
  }) async {
    await _closeSession();
    this.runner = runner;
    runId++;
    exitCode = null;
    needPkgs = '';
    elapsed = null;
    _filter = RunOutputFilter();
    terminal.write('\x1b[2J\x1b[3J\x1b[H');
    state = RunState.starting;
    _notify();
    try {
      final script = CodeRunner.buildScript(runner: runner, fileName: p.basename(filePath), args: args, pre: pre);
      final f = File(p.join(Directory.systemTemp.path, 'abtin_run', 'run_$runId.sh'));
      await f.parent.create(recursive: true);
      await f.writeAsString(script, flush: true);
      _sub ??= _native.events.listen(_onEvent);
      final s = await _native.start(p.dirname(filePath), columns: _cols, rows: _rows);
      _id = s.id;
      await _native.writeLine(s.id, '. ${CodeRunner.shq(f.path)}');
      _sw
        ..reset()
        ..start();
      if (state == RunState.starting) {
        state = RunState.running;
        _notify();
      }
    } catch (e) {
      _id = null;
      state = RunState.error;
      terminal.write('\r\n[$e]\r\n');
      _notify();
    }
  }

  void _onEvent(Map<String, dynamic> e) {
    final id = _id;
    if (id == null || e['sessionId'] != id) return;
    switch (e['type']) {
      case 'output':
        final t = e['text'];
        if (t is String) {
          final visible = _filter.feed(t);
          if (visible.isNotEmpty) terminal.write(visible);
        }
        break;
      case 'exit':
        _finish(e['exitCode']);
        break;
    }
  }

  void _finish(Object? code) {
    _sw.stop();
    elapsed = _sw.elapsed;
    _id = null;
    if (_filter.needAlpine) {
      state = RunState.needAlpine;
    } else if (_filter.need != null) {
      needPkgs = _filter.need!;
      state = RunState.needInstall;
    } else {
      if (!_filter.started) terminal.write(_filter.unstarted);
      exitCode = _filter.exitCode ?? (code is int ? code : null);
      state = RunState.done;
    }
    _notify();
  }

  /// Sends one line to the program's stdin.
  Future<void> sendLine(String text) async {
    final id = _id;
    if (id == null) return;
    try {
      await _native.writeLine(id, text);
    } catch (e) {
      terminal.write('\r\n[input error] $e\r\n');
    }
  }

  Future<void> interrupt() async {
    final id = _id;
    if (id != null) await _native.interrupt(id).catchError((_) {});
  }

  Future<void> eof() async {
    final id = _id;
    if (id != null) await _native.eof(id).catchError((_) {});
  }

  /// Kills the running program (closes the PTY session).
  Future<void> stop() async {
    if (!running) return;
    await _closeSession();
    _sw.stop();
    elapsed = _sw.elapsed;
    terminal.write('\r\n\x1b[33m[stopped]\x1b[0m\r\n');
    exitCode = null;
    state = RunState.done;
    _notify();
  }

  Future<void> _closeSession() async {
    final id = _id;
    _id = null;
    if (id != null) await _native.close(id).catchError((_) {});
  }

  @override
  void dispose() {
    _disposed = true;
    _sub?.cancel();
    final id = _id;
    _id = null;
    if (id != null) unawaited(_native.close(id).catchError((_) {}));
    super.dispose();
  }
}
