import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

import '../core/l10n.dart';
import 'ai_client.dart';
import 'ai_settings.dart';
import 'ai_tools.dart';

/// Asks the user before a tool changes files. Returns true to allow it.
typedef AiApprove = Future<bool> Function(AiToolCall call, String preview, bool dangerous);

/// One conversation with the assistant: history, streaming, tool loop (read / search / edit project files).
/// The chat of a project folder is saved in app-private storage and restored next time.
class AiSession extends ChangeNotifier {
  AiSession({this.root});

  /// Project folder the tools may touch; null = plain chat without file tools.
  String? root;

  final List<AiMsg> msgs = [];
  bool busy = false;
  String? error;
  int inTokens = 0, outTokens = 0;

  AiApprove? approve;

  /// Called before a request starts (the editor saves unsaved files so the model sees them).
  Future<void> Function()? beforeRun;

  /// Called with the files a tool created / changed / removed.
  void Function(List<String> paths)? onChanged;

  AiCancel? _cancel;
  Timer? _notifyTimer;
  bool _disposed = false;
  static const _maxSteps = 30;

  bool get toolsActive => AiSettings.toolsOn && root != null;

  @override
  void dispose() {
    _disposed = true;
    _notifyTimer?.cancel();
    _cancel?.cancel();
    super.dispose();
  }

  void _mark() {
    if (_notifyTimer != null || _disposed) return;
    _notifyTimer = Timer(const Duration(milliseconds: 70), () {
      _notifyTimer = null;
      if (!_disposed) notifyListeners();
    });
  }

  void _now() {
    _notifyTimer?.cancel();
    _notifyTimer = null;
    if (!_disposed) notifyListeners();
  }

  // ---------------------------------------------------------------- persistence
  static int _fnv(String s) {
    var h = 0x811c9dc5;
    for (final u in s.codeUnits) {
      h ^= u;
      h = (h * 0x01000193) & 0xFFFFFFFF;
    }
    return h;
  }

  Future<File> _file() async {
    final dir = await getApplicationSupportDirectory();
    final d = Directory('${dir.path}/ai_chats');
    await d.create(recursive: true);
    final key = root == null ? 'general' : _fnv(root!).toRadixString(16);
    return File('${d.path}/$key.json');
  }

  Future<void> load() async {
    try {
      final f = await _file();
      if (!f.existsSync()) return;
      final j = jsonDecode(await f.readAsString());
      if (j is! Map) return;
      msgs
        ..clear()
        ..addAll([for (final m in (j['msgs'] as List? ?? const [])) AiMsg.fromJson(Map<String, dynamic>.from(m as Map))]);
      inTokens = (j['in'] as num?)?.toInt() ?? 0;
      outTokens = (j['out'] as num?)?.toInt() ?? 0;
      _dropBrokenTail();
      _now();
    } catch (_) {
      // a damaged history file is simply ignored
    }
  }

  Future<void> _save() async {
    try {
      // keep the file small; always start at a user message so tool results keep their calls
      while (msgs.length > 160) {
        msgs.removeAt(0);
        while (msgs.isNotEmpty && msgs.first.role != 'user') {
          msgs.removeAt(0);
        }
      }
      final f = await _file();
      if (msgs.isEmpty) {
        if (f.existsSync()) await f.delete();
        return;
      }
      await f.writeAsString(jsonEncode({'msgs': [for (final m in msgs) m.toJson()], 'in': inTokens, 'out': outTokens}), flush: true);
    } catch (_) {}
  }

  /// A tool call without its result (app killed mid-run) would make the next request fail.
  void _dropBrokenTail() {
    for (var i = msgs.length - 1; i >= 0; i--) {
      final m = msgs[i];
      if (m.role != 'assistant' || m.calls.isEmpty) continue;
      final ids = {for (var j = i + 1; j < msgs.length; j++) if (msgs[j].role == 'tool') msgs[j].callId};
      if (m.calls.every((c) => ids.contains(c.id))) return;
      msgs.removeRange(i, msgs.length);
      return;
    }
  }

  Future<void> clear() async {
    stop();
    msgs.clear();
    error = null;
    inTokens = 0;
    outTokens = 0;
    _now();
    await _save();
  }

  /// Removes the last user message and everything after it, returning its text (for "edit and resend").
  String? popLastUser() {
    if (busy) return null;
    final i = msgs.lastIndexWhere((m) => m.role == 'user');
    if (i < 0) return null;
    final t = msgs[i].text;
    msgs.removeRange(i, msgs.length);
    error = null;
    _now();
    unawaited(_save());
    return t;
  }

  void stop() {
    _cancel?.cancel();
  }

  // ---------------------------------------------------------------- prompt
  String _system() {
    final b = StringBuffer();
    b.writeln('You are an AI coding assistant built into "Abtin File Manager", an Android file manager with a code editor and terminal. '
        'You help the user write, read, explain, debug, refactor and test code and work with project files.');
    b.writeln('Write the answer in the language the user writes in (Persian if they write Persian); keep code, identifiers, commands and file names in English. '
        'Use fenced code blocks with a language tag. Be concise and concrete; do not repeat code that did not change.');
    if (toolsActive) {
      b.writeln('\nYou can use tools on the user\'s project folder: $root');
      b.writeln('- Paths are relative to that folder. You cannot touch anything outside it.');
      b.writeln('- Explore first (list_dir, search, read_file); read a file before editing it.');
      b.writeln('- Prefer edit_file with a small unique old_text for changes; use write_file only for new files or complete rewrites.');
      b.writeln('- Make the smallest change that solves the task, keep the existing style, and do not delete or move files unless asked.');
      b.writeln('- The user must approve each change. If a change is rejected, do not repeat it; ask what they want instead.');
      b.writeln('- You cannot run programs here; tell the user how to run or test the result.');
      b.writeln('- When you are done, summarize what you changed in a few lines.');
    } else {
      b.writeln('\nNo file tools are available in this chat: you only see what the user pastes or attaches.');
    }
    if (AiSettings.extraPrompt.isNotEmpty) b.writeln('\nUser instructions:\n${AiSettings.extraPrompt}');
    b.writeln('\nUI language of the app: ${L.lang == 'fa' ? 'Persian' : 'English'}.');
    return b.toString();
  }

  /// History as sent to the model: old bulky tool output and old file attachments are shortened.
  List<AiMsg> _forApi() {
    final out = <AiMsg>[];
    final recent = msgs.length - 14;
    for (var i = 0; i < msgs.length; i++) {
      final m = msgs[i];
      if (i < recent && m.role == 'tool' && m.text.length > 1500) {
        out.add(AiMsg.tool(callId: m.callId, name: m.name, text: '${m.text.substring(0, 1500)}\n… (shortened)', isError: m.isError));
      } else if (i < recent && m.role == 'user' && m.context.isNotEmpty) {
        out.add(AiMsg.user(m.text));
      } else {
        out.add(m);
      }
    }
    return out;
  }

  // ---------------------------------------------------------------- run
  Future<void> send(String text, {String context = '', String label = ''}) async {
    final t = text.trim();
    if (busy || t.isEmpty) return;
    await AiSettings.load();
    if (!AiSettings.ready) {
      error = L.lang == 'fa' ? 'ابتدا از تنظیمات، سرویس و کلید API را وارد کنید.' : 'Open the settings and enter a provider and API key first.';
      _now();
      return;
    }
    error = null;
    busy = true;
    final cancel = _cancel = AiCancel();
    try {
      await beforeRun?.call();
    } catch (_) {}
    msgs.add(AiMsg.user(t, context: context, attachLabel: label));
    _now();

    final provider = AiSettings.current;
    final model = AiSettings.modelOf(provider.id);
    final baseUrl = AiSettings.urlOf(provider.id);
    final key = AiSettings.keyOf(provider.id);
    final tools = toolsActive ? ProjectTools(root!) : null;
    final system = _system();
    var changedAny = <String>[];

    try {
      for (var step = 0; step < _maxSteps; step++) {
        if (cancel.cancelled) break;
        final live = AiMsg.assistant();
        final history = _forApi();
        msgs.add(live);
        _now();
        AiTurn turn;
        try {
          turn = await AiClient.stream(
            provider: provider,
            baseUrl: baseUrl,
            apiKey: key,
            model: model,
            system: system,
            history: history,
            tools: tools == null ? const [] : ProjectTools.defs,
            maxTokens: AiSettings.maxTokens,
            cancel: cancel,
            onText: (d) {
              live.text += d;
              _mark();
            },
            onReasoning: (d) {
              live.reasoning += d;
              _mark();
            },
          );
        } catch (_) {
          // keep what was streamed so far (without half-finished calls); drop it when empty
          if (live.text.trim().isEmpty && live.reasoning.trim().isEmpty) msgs.remove(live);
          rethrow;
        }
        live.text = turn.text;
        live.reasoning = turn.reasoning;
        live.calls
          ..clear()
          ..addAll(turn.calls);
        inTokens += turn.inTokens;
        outTokens += turn.outTokens;
        if (turn.calls.isEmpty) {
          if (live.text.trim().isEmpty && live.reasoning.trim().isEmpty) {
            msgs.remove(live);
            error = L.lang == 'fa' ? 'مدل پاسخ خالی داد.' : 'The model returned an empty answer.';
          } else if (turn.finish == 'length' || turn.finish == 'max_tokens') {
            error = L.lang == 'fa' ? 'پاسخ به سقف طول رسید و ناقص ماند (در تنظیمات «حداکثر توکن» را بیشتر کنید).' : 'The answer hit the length limit (raise "max tokens" in settings).';
          }
          _now();
          break;
        }
        _now();
        if (tools == null) break;

        for (final c in turn.calls) {
          if (cancel.cancelled) {
            msgs.add(AiMsg.tool(callId: c.id, name: c.name, text: 'Cancelled by the user.', isError: true));
            continue;
          }
          AiToolResult r;
          try {
            var allowed = true;
            if (ProjectTools.isWrite(c.name) && !c.badJson && (!AiSettings.autoApprove || ProjectTools.alwaysAsk(c.name))) {
              final ask = approve;
              allowed = ask == null ? false : await ask(c, tools.preview(c), ProjectTools.alwaysAsk(c.name));
            }
            r = allowed ? await tools.run(c) : const AiToolResult('The user rejected this change. Do not repeat it.', error: true);
          } catch (e) {
            r = AiToolResult('Error: $e', error: true);
          }
          msgs.add(AiMsg.tool(callId: c.id, name: c.name, text: r.text, isError: r.error));
          if (r.changed.isNotEmpty) {
            changedAny = [...changedAny, ...r.changed];
            onChanged?.call(List.of(r.changed));
          }
          _now();
        }
        if (cancel.cancelled) break;
        if (step == _maxSteps - 1) {
          error = L.lang == 'fa' ? 'تعداد مراحل از حد مجاز گذشت؛ «ادامه بده» را بفرستید.' : 'Step limit reached; send "continue" to go on.';
        }
      }
    } on AiError catch (e) {
      if (e.message != 'cancelled') error = e.message;
    } catch (e) {
      error = '$e';
    } finally {
      busy = false;
      _cancel = null;
      _dropBrokenTail();
      if (changedAny.isNotEmpty) onChanged?.call(changedAny);
      _now();
      unawaited(_save());
    }
  }
}
