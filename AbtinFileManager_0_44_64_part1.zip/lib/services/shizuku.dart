import 'dart:async';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;
import 'file_ops.dart' show OpError;

/// Raw directory entry returned by the shell (FileOps turns it into an FItem).
class ShEntry {
  final String name;
  final bool isDir;
  final int size;
  final DateTime modified;
  const ShEntry(this.name, this.isDir, this.size, this.modified);
}

class ShizuStatus {
  final bool installed, running, granted;
  final int sdk, uid;
  const ShizuStatus(this.installed, this.running, this.granted, this.sdk, this.uid);
  bool get ready => running && granted;
  static const none = ShizuStatus(false, false, false, 0, -1);
}

class _Sh {
  final int code;
  final String out, err;
  const _Sh(this.code, this.out, this.err);
  bool get ok => code == 0;
}

/// Access to `Android/data` and `Android/obb` through Shizuku (https://shizuku.rikka.app).
/// Since Android 11 no normal app can list these folders, even with "all files access", and
/// since Android 13 the Storage Access Framework cannot open them either. Shizuku lets this app
/// run shell commands as the `shell` user, which can. Every file operation below is one such
/// command; arguments are passed as separate `sh` positional parameters, so no quoting is needed.
class Shizu {
  static const _c = MethodChannel('abtin/shizuku');

  /// Folders that only Shizuku can reach (internal storage, any user id).
  static final _covered = RegExp(r'^/(?:storage/emulated/\d+|sdcard|storage/self/primary|data/media/\d+)/Android/(?:data|obb)(?:/|$)');
  static bool covers(String path) => _covered.hasMatch(path);

  /// Hidden scratch folder for files that are opened from a covered folder.
  static const tmpRoot = '/storage/emulated/0/.AbtinShizuTmp';

  // ── status / permission ──
  static ShizuStatus? _st;
  static DateTime _stAt = DateTime.fromMillisecondsSinceEpoch(0);

  static Future<ShizuStatus> status({bool force = false}) async {
    final c = _st;
    if (!force && c != null && DateTime.now().difference(_stAt).inSeconds < 2) return c;
    try {
      final m = await _c.invokeMapMethod<String, dynamic>('status');
      if (m != null) {
        _st = ShizuStatus(m['installed'] == true, m['running'] == true, m['granted'] == true, (m['sdk'] as num?)?.toInt() ?? 0, (m['uid'] as num?)?.toInt() ?? -1);
        _stAt = DateTime.now();
        return _st!;
      }
    } catch (_) {}
    return ShizuStatus.none;
  }

  static Future<bool> request() async {
    try {
      final ok = (await _c.invokeMethod<bool>('request')) ?? false;
      await status(force: true);
      return ok;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> launchApp() async {
    try {
      return (await _c.invokeMethod<bool>('launch')) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// true -> run [path] through Shizuku; false -> the normal File API works (not a covered
  /// folder, or Android 10 and older). Throws OpError `shizuNeed` while Shizuku is not ready.
  static Future<bool> use(String path) async {
    if (!covers(path)) return false;
    final s = await status();
    if (s.sdk > 0 && s.sdk < 30) return false;
    if (!s.ready) throw const OpError('shizuNeed');
    return true;
  }

  // ── shell ──
  static Future<_Sh> _run(String script, List<String> args) async {
    try {
      final m = await _c.invokeMapMethod<String, dynamic>('exec', {'args': ['sh', '-c', script, 'sh', ...args]});
      return _Sh((m?['code'] as num?)?.toInt() ?? -1, '${m?['out'] ?? ''}', '${m?['err'] ?? ''}');
    } on PlatformException catch (e) {
      return _Sh(-1, '', e.message ?? '$e');
    }
  }

  static String _msg(_Sh r) {
    final e = r.err.trim();
    return e.isEmpty ? 'exit ${r.code}' : e.split('\n').first;
  }

  static Never _fail(String key, _Sh r) => throw OpError(key, _msg(r));

  // ── operations ──
  static Future<List<ShEntry>> list(String dir) async {
    const withStat = r'''cd "$1" 2>/dev/null || exit 3
for f in .[!.]* ..?* *; do
  [ -e "$f" ] || [ -L "$f" ] || continue
  stat -c '%F|%s|%Y|%n' -- "$f"
done''';
    const plain = r'''cd "$1" 2>/dev/null || exit 3
for f in .[!.]* ..?* *; do
  [ -e "$f" ] || [ -L "$f" ] || continue
  if [ -d "$f" ]; then echo "directory|0|0|$f"; else echo "regular file|0|0|$f"; fi
done''';
    var r = await _run(withStat, [dir]);
    if (r.code == 3) throw OpError('listFail', dir);
    if (!r.ok && r.out.trim().isEmpty) {
      r = await _run(plain, [dir]); // old toybox without `stat -c`
      if (r.code == 3) throw OpError('listFail', dir);
    }
    final out = <ShEntry>[];
    for (final line in r.out.split('\n')) {
      if (line.isEmpty) continue;
      final a = line.indexOf('|');
      final b = a < 0 ? -1 : line.indexOf('|', a + 1);
      final c = b < 0 ? -1 : line.indexOf('|', b + 1);
      if (c < 0) continue;
      final name = line.substring(c + 1);
      if (name.isEmpty || name == '.' || name == '..') continue;
      out.add(ShEntry(
        name,
        line.substring(0, a).contains('directory'),
        int.tryParse(line.substring(a + 1, b)) ?? 0,
        DateTime.fromMillisecondsSinceEpoch((int.tryParse(line.substring(b + 1, c)) ?? 0) * 1000),
      ));
    }
    return out;
  }

  static Future<bool> exists(String path) async => (await _run(r'[ -e "$1" ] || [ -L "$1" ]', [path])).ok;

  static Future<bool> isDir(String path) async => (await _run(r'[ -d "$1" ]', [path])).ok;

  /// First free name in [dir]: `name`, `name (1).ext`, `name (2).ext` ... (same rule as FileOps.unique).
  static Future<String> unique(String dir, String name) async {
    const script = r'''d="$1"; n="$2"; t="$d/$n"
if [ -e "$t" ] || [ -L "$t" ]; then
  b="$n"; e=""
  case "$n" in
    ?*.*) b="${n%.*}"; e=".${n##*.}";;
  esac
  i=1
  while [ -e "$d/$b ($i)$e" ] || [ -L "$d/$b ($i)$e" ]; do i=$((i+1)); done
  t="$d/$b ($i)$e"
fi
printf '%s' "$t"''';
    final r = await _run(script, [dir, name]);
    if (!r.ok || r.out.isEmpty) return p.join(dir, name);
    return r.out;
  }

  /// Copies [src] into [destDir] (new unique name when it already exists). Returns the new path.
  static Future<String> copy(String src, String destDir) async {
    if (p.isWithin(src, destDir) || p.equals(src, destDir)) throw Exception('Cannot copy a folder into itself');
    final t = await unique(destDir, p.basename(src));
    final r = await _run(r'cp -R -- "$1" "$2"', [src, t]);
    if (!r.ok) _fail('copyFail', r);
    return t;
  }

  static Future<String> move(String src, String destDir) async {
    if (p.equals(p.dirname(src), destDir)) return src;
    final t = await unique(destDir, p.basename(src));
    final r = await _run(r'mv -- "$1" "$2" || { cp -R -- "$1" "$2" && rm -rf -- "$1"; }', [src, t]);
    if (!r.ok) _fail('moveFail', r);
    return t;
  }

  static Future<void> delete(String path) async {
    final r = await _run(r'rm -rf -- "$1"', [path]);
    if (!r.ok) _fail('delFail', r);
  }

  static Future<void> rename(String from, String to) async {
    final r = await _run(r'mv -- "$1" "$2"', [from, to]);
    if (!r.ok) _fail('renameFail', r);
  }

  static Future<void> mkdir(String path) async {
    final r = await _run(r'mkdir -- "$1"', [path]);
    if (!r.ok) _fail('createFail', r);
  }

  static Future<void> touch(String path) async {
    final r = await _run(r'touch -- "$1"', [path]);
    if (!r.ok) _fail('createFail', r);
  }

  /// Total size in bytes (0 when `du` is not usable).
  static Future<int> dirSize(String path) async {
    final r = await _run(r'du -sk -- "$1"', [path]);
    if (!r.ok) return 0;
    final k = int.tryParse(r.out.trim().split(RegExp(r'\s+')).first);
    return (k ?? 0) * 1024;
  }

  // ── opening / editing a file that lives in a covered folder ──
  /// Copies [path] to a readable scratch folder and returns the local copy.
  /// Use [writeBack] afterwards to put an edited copy back.
  static bool _cleaned = false;

  static Future<String> materialize(String path) async {
    if (!_cleaned) {
      _cleaned = true;
      await cleanTmp(); // leftovers of earlier sessions
    }
    final dir = p.join(tmpRoot, '${path.hashCode.toUnsigned(32).toRadixString(16)}');
    final local = p.join(dir, p.basename(path));
    final r = await _run(r'rm -rf -- "$2" && mkdir -p -- "$2" && : > "$3/.nomedia" ; cp -R -- "$1" "$2/"', [path, dir, tmpRoot]);
    if (!r.ok) _fail('copyFail', r);
    return local;
  }

  /// Overwrites [original] (in a covered folder) with the content of the scratch copy [local].
  static Future<void> writeBack(String local, String original) async {
    final r = await _run(r'cp -f -- "$1" "$2"', [local, original]);
    if (!r.ok) _fail('copyFail', r);
  }

  static Future<void> cleanTmp() async {
    try {
      await _run(r'rm -rf -- "$1"', [tmpRoot]);
    } catch (_) {}
  }
}
