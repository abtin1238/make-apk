import 'highlighter.dart';

/// How comments are written in a language. [close] is empty for line comments.
class CommentStyle {
  final String open;
  final String close;
  const CommentStyle(this.open, [this.close = '']);
}

/// Text + selection produced by an edit helper.
class EditResult {
  final String text;
  final int start, end;
  const EditResult(this.text, this.start, this.end);
}

/// What to insert after a typed newline: [insert] goes right after the '\n',
/// the caret is placed [caret] characters into it.
class EnterEdit {
  final String insert;
  final int caret;
  const EnterEdit(this.insert, this.caret);
}

class _Ed {
  final int pos, del;
  final String ins;
  const _Ed(this.pos, this.del, this.ins);
}

/// Pure-Dart helpers for the code editor: comment toggling, smart Enter,
/// bracket/quote pairing rules and word auto-complete.
class CodeAssist {
  // ---- comments -------------------------------------------------------------
  static const _slash = {
    'c', 'cpp', 'cuda', 'java', 'kotlin', 'dart', 'csharp', 'go', 'rust', 'swift', 'scala', 'groovy', 'js', 'ts', 'php',
    'glsl', 'proto', 'solidity', 'd', 'zig', 'haxe', 'verilog', 'scss', 'less', 'pascal', 'fsharp',
  };
  static const _hash = {
    'python', 'ruby', 'julia', 'elixir', 'crystal', 'nim', 'r', 'coffee', 'perl', 'graphql', 'gdscript', 'bash',
    'powershell', 'dockerfile', 'makefile', 'cmake', 'awk', 'tcl', 'fish', 'yaml', 'toml', 'env',
  };
  static const _dash = {'sql', 'lua', 'haskell', 'elm'};
  static const _semi = {'lisp', 'scheme', 'racket', 'clojure', 'elisp', 'asm', 'ini'};
  static const _pct = {'latex', 'matlab', 'erlang', 'prolog'};

  /// Comment syntax of a language id, null when it has none (JSON, plain text).
  static CommentStyle? comment(String lang) {
    if (_slash.contains(lang)) return const CommentStyle('//');
    if (_hash.contains(lang)) return const CommentStyle('#');
    if (_dash.contains(lang)) return const CommentStyle('--');
    if (_semi.contains(lang)) return const CommentStyle(';');
    if (_pct.contains(lang)) return const CommentStyle('%');
    switch (lang) {
      case 'html':
      case 'xml':
      case 'markdown':
        return const CommentStyle('<!--', '-->');
      case 'css':
        return const CommentStyle('/*', '*/');
      case 'ocaml':
        return const CommentStyle('(*', '*)');
      case 'fortran':
        return const CommentStyle('!');
      case 'vb':
        return const CommentStyle("'");
      case 'batch':
        return const CommentStyle('REM');
    }
    return null;
  }

  /// Comments / uncomments the lines touched by the selection [selStart, selEnd].
  /// Returns null when the language has no comment syntax or there is nothing to do.
  static EditResult? toggleComment(String text, int selStart, int selEnd, String lang) {
    final c = comment(lang);
    if (c == null) return null;
    var a = selStart.clamp(0, text.length).toInt();
    var b = selEnd.clamp(0, text.length).toInt();
    if (a > b) {
      final t = a;
      a = b;
      b = t;
    }
    int lineStartOf(int o) => o <= 0 ? 0 : text.lastIndexOf('\n', o - 1) + 1;
    final lastOff = (b > a && b > 0 && text.codeUnitAt(b - 1) == 10) ? b - 1 : b;
    final lastStart = lineStartOf(lastOff);
    final starts = <int>[];
    var cur = lineStartOf(a);
    while (true) {
      starts.add(cur);
      if (cur >= lastStart) break;
      final nl = text.indexOf('\n', cur);
      if (nl < 0) break;
      cur = nl + 1;
    }

    final lines = <(int, int)>[]; // (start, end) of non-blank lines, end excludes '\n' and '\r'
    for (final s in starts) {
      var e = text.indexOf('\n', s);
      if (e < 0) e = text.length;
      if (e > s && text.codeUnitAt(e - 1) == 13) e--;
      if (text.substring(s, e).trim().isNotEmpty) lines.add((s, e));
    }
    if (lines.isEmpty) return null;

    int indentOf(int s, int e) {
      var i = s;
      while (i < e && (text.codeUnitAt(i) == 32 || text.codeUnitAt(i) == 9)) {
        i++;
      }
      return i - s;
    }

    bool isCommented(int s, int e) {
      final t = text.substring(s, e).trim();
      return t.startsWith(c.open) && (c.close.isEmpty || (t.endsWith(c.close) && t.length >= c.open.length + c.close.length));
    }

    final edits = <_Ed>[];
    final uncomment = lines.every((l) => isCommented(l.$1, l.$2));
    if (uncomment) {
      for (final l in lines) {
        final p0 = l.$1 + indentOf(l.$1, l.$2);
        var del = c.open.length;
        if (p0 + del < l.$2 && text.codeUnitAt(p0 + del) == 32) del++;
        edits.add(_Ed(p0, del, ''));
        if (c.close.isNotEmpty) {
          var e2 = l.$2;
          while (e2 > p0 && (text.codeUnitAt(e2 - 1) == 32 || text.codeUnitAt(e2 - 1) == 9)) {
            e2--;
          }
          var ds = e2 - c.close.length;
          if (ds > p0 + del && text.codeUnitAt(ds - 1) == 32) ds--;
          if (ds >= p0 + del) edits.add(_Ed(ds, e2 - ds, ''));
        }
      }
    } else {
      var minIndent = 1 << 30;
      for (final l in lines) {
        final i = indentOf(l.$1, l.$2);
        if (i < minIndent) minIndent = i;
      }
      for (final l in lines) {
        edits.add(_Ed(l.$1 + minIndent, 0, '${c.open} '));
        if (c.close.isNotEmpty) {
          var e2 = l.$2;
          while (e2 > l.$1 && (text.codeUnitAt(e2 - 1) == 32 || text.codeUnitAt(e2 - 1) == 9)) {
            e2--;
          }
          edits.add(_Ed(e2, 0, ' ${c.close}'));
        }
      }
    }
    edits.sort((x, y) => x.pos.compareTo(y.pos));

    var out = text;
    for (final e in edits.reversed) {
      out = out.replaceRange(e.pos, e.pos + e.del, e.ins);
    }
    int map(int o, {bool stickLeft = false}) {
      var r = o;
      for (final e in edits) {
        if (o < e.pos) break;
        if (e.del == 0 && stickLeft && o == e.pos) break;
        if (o >= e.pos + e.del) {
          r += e.ins.length - e.del;
        } else {
          r += e.pos + e.ins.length - o;
        }
      }
      return r;
    }

    final collapsed = a == b;
    return EditResult(out, map(a, stickLeft: !collapsed), map(b));
  }

  // ---- Enter ----------------------------------------------------------------
  static const _colonLangs = {'python', 'yaml', 'nim', 'gdscript'};
  static const _wordLangs = {'lua', 'ruby', 'bash', 'elixir', 'crystal', 'fish'};
  static const _markup = {'html', 'xml'};
  static const _void = {
    'br', 'img', 'input', 'meta', 'link', 'hr', 'area', 'base', 'col', 'embed', 'source', 'track', 'wbr', 'param', 'doctype',
  };
  static const _brackets = {'{': '}', '[': ']', '(': ')'};

  /// Indentation to add after a newline typed at [caret] in the old [text].
  /// [afterFrom] = where the text that follows the new line starts (differs from
  /// [caret] when a selection was replaced).
  static EnterEdit enter(String text, int caret, String lang, int indentWidth, {int? afterFrom}) {
    caret = caret.clamp(0, text.length).toInt();
    final from = (afterFrom ?? caret).clamp(0, text.length).toInt();
    final ls = caret <= 0 ? 0 : text.lastIndexOf('\n', caret - 1) + 1;
    final before = text.substring(ls, caret);
    var le = text.indexOf('\n', from);
    if (le < 0) le = text.length;
    final after = text.substring(from, le);

    var leading = RegExp(r'^[ \t]*').stringMatch(before) ?? '';
    final unit = leading.contains('\t') ? '\t' : ' ' * indentWidth;
    final trimmed = before.trimRight();
    final last = trimmed.isEmpty ? '' : trimmed[trimmed.length - 1];

    var extra = '';
    var closer = '';
    if (_brackets.containsKey(last)) {
      extra = unit;
      closer = _brackets[last]!;
    } else if (_colonLangs.contains(lang) && last == ':' && !trimmed.trimLeft().startsWith('#')) {
      extra = unit;
    } else if (_wordLangs.contains(lang) && RegExp(r'\b(?:then|do|else|elsif|begin|repeat)\s*$').hasMatch(trimmed)) {
      extra = unit;
    } else if (_markup.contains(lang)) {
      final m = RegExp(r'<([A-Za-z][\w:.-]*)(?:\s[^<>]*)?>$').firstMatch(trimmed);
      if (m != null && !trimmed.endsWith('/>') && !_void.contains(m.group(1)!.toLowerCase())) {
        extra = unit;
        closer = '</';
      }
    } else if (lang == 'python' && RegExp(r'^(?:return|pass|break|continue|raise)\b').hasMatch(trimmed.trimLeft())) {
      final cut = unit.length;
      if (leading.length >= cut) leading = leading.substring(0, leading.length - cut);
    }

    final base = leading + extra;
    if (extra.isNotEmpty && closer.isNotEmpty && after.trimLeft().startsWith(closer)) {
      return EnterEdit('$base\n$leading', base.length);
    }
    return EnterEdit(base, base.length);
  }

  // ---- pairing --------------------------------------------------------------
  static const _noSingleQuote = {
    'lisp', 'scheme', 'racket', 'clojure', 'elisp', 'rust', 'ocaml', 'fsharp', 'haskell', 'elm', 'vb', 'matlab', 'erlang',
    'prolog', 'pascal', 'latex', 'markdown', 'batch',
  };
  static const _closerOf = {'(': ')', '[': ']', '{': '}', '"': '"', "'": "'", '`': '`'};

  static bool _isWordChar(String c) {
    if (c.isEmpty) return false;
    final u = c.codeUnitAt(0);
    return (u >= 48 && u <= 57) || (u >= 65 && u <= 90) || (u >= 97 && u <= 122) || u == 95 || u >= 0xC0;
  }

  /// Should typing [typed] also insert its closing character?
  static bool shouldPair(String typed, String prev, String next, String lang) {
    final close = _closerOf[typed];
    if (close == null) return false;
    final isQuote = typed == '"' || typed == "'" || typed == '`';
    if (isQuote) {
      if (lang.isEmpty || lang == 'latex') return false;
      if (typed == "'" && _noSingleQuote.contains(lang)) return false;
      if (_isWordChar(prev) || prev == typed || prev == '\\') return false;
    }
    return !_isWordChar(next);
  }

  /// Backspace removed [removed]; should the closer [nextChar] that follows go too?
  static bool deletesPair(String removed, String nextChar, String lang) {
    final close = _closerOf[removed];
    if (close == null || close != nextChar) return false;
    final isQuote = removed == '"' || removed == "'" || removed == '`';
    return !isQuote || lang.isNotEmpty;
  }

  // ---- auto-complete --------------------------------------------------------
  static bool isWordUnit(int c) =>
      (c >= 48 && c <= 57) ||
      (c >= 65 && c <= 90) ||
      (c >= 97 && c <= 122) ||
      c == 95 ||
      c == 36 ||
      (c >= 0xC0 && !(c >= 0x2000 && c <= 0x2BFF) && c != 0x060C && c != 0x061B && c != 0x061F);

  /// Start of the identifier that ends at [caret].
  static int wordStart(String text, int caret) {
    var i = caret.clamp(0, text.length).toInt();
    while (i > 0 && isWordUnit(text.codeUnitAt(i - 1))) {
      i--;
    }
    return i;
  }

  static final _wordRe = RegExp(r'[\p{L}_$][\p{L}\p{N}_$]*', unicode: true);

  /// Completions for the identifier typed before [caret]: language keywords and
  /// words that already occur in the file. Needs at least 2 typed characters.
  static List<String> suggest(String text, int caret, String lang, {int max = 8}) {
    caret = caret.clamp(0, text.length).toInt();
    final start = wordStart(text, caret);
    final prefix = text.substring(start, caret);
    if (prefix.length < 2) return const [];
    final f = prefix.codeUnitAt(0);
    if (f >= 48 && f <= 57) return const [];
    final pl = prefix.toLowerCase();

    final big = text.length > 120000;
    final lo = big ? (caret - 60000).clamp(0, text.length).toInt() : 0;
    final hi = big ? (caret + 60000).clamp(0, text.length).toInt() : text.length;
    final counts = <String, int>{};
    for (final m in _wordRe.allMatches(text.substring(lo, hi))) {
      final s = lo + m.start, e = lo + m.end;
      if (s <= caret && e >= caret) continue; // the word being typed
      final w = m.group(0)!;
      if (w.length < 3 || w.length > 40) continue;
      counts[w] = (counts[w] ?? 0) + 1;
    }

    final scored = <String, double>{};
    for (final k in Hl.keywordsOf(lang)) {
      if (k.length > prefix.length && k.toLowerCase().startsWith(pl)) {
        scored[k] = (k.startsWith(prefix) ? 0 : 100) + 5 + k.length / 100;
      }
    }
    counts.forEach((w, n) {
      if (w.length > prefix.length && w.toLowerCase().startsWith(pl) && !scored.containsKey(w)) {
        scored[w] = (w.startsWith(prefix) ? 0 : 100) + 10 - (n > 5 ? 5 : n) * 2 + w.length / 100;
      }
    });
    final keys = scored.keys.toList()
      ..sort((x, y) {
        final c = scored[x]!.compareTo(scored[y]!);
        return c != 0 ? c : x.compareTo(y);
      });
    return keys.length > max ? keys.sublist(0, max) : keys;
  }
}
