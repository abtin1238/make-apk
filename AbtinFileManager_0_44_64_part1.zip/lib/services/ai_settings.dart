import 'package:shared_preferences/shared_preferences.dart';

/// Wire format of a provider's chat API.
enum AiProtocol {
  /// `POST {base}/chat/completions` (OpenAI, DeepSeek, Kimi, Gemini, Mistral, Groq, OpenRouter, Ollama, ...).
  openai,

  /// `POST {base}/v1/messages` (Anthropic / Claude).
  anthropic,
}

/// One AI service the in-app assistant can talk to.
class AiProvider {
  const AiProvider({
    required this.id,
    required this.name,
    required this.baseUrl,
    required this.protocol,
    required this.defaultModel,
    this.models = const [],
    this.keyUrl = '',
    this.needsKey = true,
    this.editableUrl = false,
  });

  final String id;
  final String name;
  final String baseUrl;
  final AiProtocol protocol;
  final String defaultModel;

  /// Suggested model ids (the user can type any other id; "fetch list" asks the provider).
  final List<String> models;

  /// Where the user creates an API key (shown as a hint).
  final String keyUrl;
  final bool needsKey;

  /// Custom providers: the base URL must be typed by the user.
  final bool editableUrl;
}

/// Settings of the in-app AI assistant (ChatGPT, DeepSeek, Kimi, Claude, Gemini ... through their APIs).
/// Everything is stored in app-private SharedPreferences; keys are per provider.
class AiSettings {
  static const providers = <AiProvider>[
    AiProvider(
      id: 'openai',
      name: 'OpenAI (ChatGPT)',
      baseUrl: 'https://api.openai.com/v1',
      protocol: AiProtocol.openai,
      defaultModel: 'gpt-5',
      models: ['gpt-5', 'gpt-5-mini', 'gpt-4.1', 'gpt-4o'],
      keyUrl: 'platform.openai.com/api-keys',
    ),
    AiProvider(
      id: 'anthropic',
      name: 'Anthropic (Claude)',
      baseUrl: 'https://api.anthropic.com',
      protocol: AiProtocol.anthropic,
      defaultModel: 'claude-sonnet-5-5',
      models: ['claude-sonnet-5-5', 'claude-opus-5-5', 'claude-haiku-5-5'],
      keyUrl: 'console.anthropic.com',
    ),
    AiProvider(
      id: 'deepseek',
      name: 'DeepSeek',
      baseUrl: 'https://api.deepseek.com',
      protocol: AiProtocol.openai,
      defaultModel: 'deepseek-chat',
      models: ['deepseek-chat', 'deepseek-reasoner'],
      keyUrl: 'platform.deepseek.com/api_keys',
    ),
    AiProvider(
      id: 'kimi',
      name: 'Kimi K3 (Moonshot, platform.kimi.ai)',
      baseUrl: 'https://api.moonshot.ai/v1',
      protocol: AiProtocol.openai,
      defaultModel: 'kimi-k3',
      models: ['kimi-k3'],
      keyUrl: 'platform.kimi.ai/console/api-keys',
    ),
    AiProvider(
      id: 'kimi_cn',
      name: 'Kimi (Moonshot China, platform.moonshot.cn)',
      baseUrl: 'https://api.moonshot.cn/v1',
      protocol: AiProtocol.openai,
      defaultModel: 'kimi-k3',
      models: ['kimi-k3'],
      keyUrl: 'platform.moonshot.cn',
    ),
    AiProvider(
      id: 'gemini',
      name: 'Google Gemini',
      baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai',
      protocol: AiProtocol.openai,
      defaultModel: 'gemini-2.5-pro',
      models: ['gemini-2.5-pro', 'gemini-2.5-flash'],
      keyUrl: 'aistudio.google.com/apikey',
    ),
    AiProvider(
      id: 'zai',
      name: 'Z.ai (GLM)',
      baseUrl: 'https://api.z.ai/api/paas/v4',
      protocol: AiProtocol.openai,
      defaultModel: 'glm-5.1',
      models: ['glm-5.1'],
      keyUrl: 'z.ai',
    ),
    AiProvider(
      id: 'qwen',
      name: 'Qwen (Alibaba DashScope)',
      baseUrl: 'https://dashscope-intl.aliyuncs.com/compatible-mode/v1',
      protocol: AiProtocol.openai,
      defaultModel: 'qwen3-coder-plus',
      models: ['qwen3-coder-plus', 'qwen-max'],
      keyUrl: 'bailian.console.alibabacloud.com',
    ),
    AiProvider(
      id: 'mistral',
      name: 'Mistral (Codestral / Devstral)',
      baseUrl: 'https://api.mistral.ai/v1',
      protocol: AiProtocol.openai,
      defaultModel: 'codestral-latest',
      models: ['codestral-latest', 'devstral-medium-latest', 'mistral-large-latest'],
      keyUrl: 'console.mistral.ai',
    ),
    AiProvider(
      id: 'xai',
      name: 'xAI (Grok)',
      baseUrl: 'https://api.x.ai/v1',
      protocol: AiProtocol.openai,
      defaultModel: 'grok-4',
      models: ['grok-4', 'grok-code-fast-1'],
      keyUrl: 'console.x.ai',
    ),
    AiProvider(
      id: 'groq',
      name: 'Groq',
      baseUrl: 'https://api.groq.com/openai/v1',
      protocol: AiProtocol.openai,
      defaultModel: 'llama-3.3-70b-versatile',
      models: ['llama-3.3-70b-versatile'],
      keyUrl: 'console.groq.com/keys',
    ),
    AiProvider(
      id: 'openrouter',
      name: 'OpenRouter (any model)',
      baseUrl: 'https://openrouter.ai/api/v1',
      protocol: AiProtocol.openai,
      defaultModel: 'moonshotai/kimi-k3',
      models: ['moonshotai/kimi-k3', 'deepseek/deepseek-chat', 'openai/gpt-5', 'anthropic/claude-sonnet-5-5'],
      keyUrl: 'openrouter.ai/keys',
    ),
    AiProvider(
      id: 'ollama',
      name: 'Ollama / LM Studio (local, OpenAI-compatible)',
      baseUrl: 'http://127.0.0.1:11434/v1',
      protocol: AiProtocol.openai,
      defaultModel: 'qwen2.5-coder',
      needsKey: false,
      editableUrl: true,
    ),
    AiProvider(
      id: 'custom_openai',
      name: 'Custom (OpenAI-compatible URL)',
      baseUrl: '',
      protocol: AiProtocol.openai,
      defaultModel: '',
      editableUrl: true,
    ),
    AiProvider(
      id: 'custom_anthropic',
      name: 'Custom (Anthropic-compatible URL)',
      baseUrl: '',
      protocol: AiProtocol.anthropic,
      defaultModel: '',
      editableUrl: true,
    ),
  ];

  static const _kActive = 'ai_active';
  static const _kAuto = 'ai_auto_approve';
  static const _kTools = 'ai_tools_on';
  static const _kExtra = 'ai_extra_prompt';
  static const _kMaxTok = 'ai_max_tokens';

  static String active = 'deepseek';
  static bool autoApprove = false;
  static bool toolsOn = true;
  static String extraPrompt = '';
  static int maxTokens = 8192;
  static final Map<String, String> _keys = {};
  static final Map<String, String> _models = {};
  static final Map<String, String> _urls = {};
  static bool _loaded = false;

  static AiProvider byId(String id) => providers.firstWhere((e) => e.id == id, orElse: () => providers.first);
  static AiProvider get current => byId(active);

  static String keyOf(String id) => _keys[id] ?? '';
  static String modelOf(String id) {
    final m = (_models[id] ?? '').trim();
    return m.isNotEmpty ? m : byId(id).defaultModel;
  }

  static String urlOf(String id) {
    final u = (_urls[id] ?? '').trim();
    return u.isNotEmpty ? u : byId(id).baseUrl;
  }

  /// A provider is usable when it has a key (or needs none), a model and a URL.
  static bool isReady(String id) {
    final p = byId(id);
    if (p.needsKey && keyOf(id).trim().isEmpty) return false;
    return urlOf(id).isNotEmpty && modelOf(id).isNotEmpty;
  }

  static bool get ready => isReady(active);

  static Future<void> load({bool force = false}) async {
    if (_loaded && !force) return;
    final sp = await SharedPreferences.getInstance();
    active = sp.getString(_kActive) ?? active;
    autoApprove = sp.getBool(_kAuto) ?? false;
    toolsOn = sp.getBool(_kTools) ?? true;
    extraPrompt = sp.getString(_kExtra) ?? '';
    maxTokens = sp.getInt(_kMaxTok) ?? 8192;
    for (final p in providers) {
      _keys[p.id] = sp.getString('ai_key_${p.id}') ?? '';
      _models[p.id] = sp.getString('ai_model_${p.id}') ?? '';
      _urls[p.id] = sp.getString('ai_url_${p.id}') ?? '';
    }
    _loaded = true;
  }

  static Future<void> saveProvider(String id, {required String key, required String model, required String url}) async {
    _keys[id] = key.trim();
    _models[id] = model.trim();
    _urls[id] = url.trim();
    final sp = await SharedPreferences.getInstance();
    await sp.setString('ai_key_$id', _keys[id]!);
    await sp.setString('ai_model_$id', _models[id]!);
    await sp.setString('ai_url_$id', _urls[id]!);
  }

  static Future<void> setActive(String id) async {
    active = id;
    final sp = await SharedPreferences.getInstance();
    await sp.setString(_kActive, id);
  }

  static Future<void> setModel(String id, String model) async {
    _models[id] = model.trim();
    final sp = await SharedPreferences.getInstance();
    await sp.setString('ai_model_$id', _models[id]!);
  }

  static Future<void> saveGeneral({bool? autoApprove, bool? toolsOn, String? extraPrompt, int? maxTokens}) async {
    final sp = await SharedPreferences.getInstance();
    if (autoApprove != null) {
      AiSettings.autoApprove = autoApprove;
      await sp.setBool(_kAuto, autoApprove);
    }
    if (toolsOn != null) {
      AiSettings.toolsOn = toolsOn;
      await sp.setBool(_kTools, toolsOn);
    }
    if (extraPrompt != null) {
      AiSettings.extraPrompt = extraPrompt.trim();
      await sp.setString(_kExtra, AiSettings.extraPrompt);
    }
    if (maxTokens != null) {
      AiSettings.maxTokens = maxTokens.clamp(256, 64000).toInt();
      await sp.setInt(_kMaxTok, AiSettings.maxTokens);
    }
  }
}
