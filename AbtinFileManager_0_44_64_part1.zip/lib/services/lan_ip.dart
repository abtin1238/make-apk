import 'dart:io';
import 'package:network_info_plus/network_info_plus.dart';

/// True for RFC1918 / link-local style LAN addresses.
bool isLanIp(String a) {
  final p = a.split('.').map(int.tryParse).toList();
  if (p.length != 4 || p.any((e) => e == null)) return false;
  final x = p[0]!, y = p[1]!;
  return x == 10 || (x == 172 && y >= 16 && y <= 31) || (x == 192 && y == 168) || (x == 169 && y == 254);
}

int _rank(String ifName, String ip) {
  final n = ifName.toLowerCase();
  // Wi-Fi client first, then hotspot (this phone is the router), USB/BT tether, Ethernet.
  if (n.startsWith('wlan')) return 0;
  if (n.startsWith('ap') || n.startsWith('swlan') || n.startsWith('softap') || n.startsWith('wigig')) return 1;
  if (n.startsWith('rndis') || n.startsWith('usb') || n.startsWith('bt-pan') || n.startsWith('bnep')) return 2;
  if (n.startsWith('eth') || n.startsWith('en')) return 3;
  if (n.startsWith('p2p')) return 4;
  return 9;
}

/// Finds this device's LAN IPv4 address.
/// Works with: Wi-Fi without internet, own hotspot (no Wi-Fi client at all),
/// USB tethering and Ethernet. `getWifiIP()` alone returns null in the
/// hotspot / tethering cases, which is why no address was shown offline.
Future<String?> lanIp() async {
  try {
    final ip = await NetworkInfo().getWifiIP();
    if (ip != null && ip.isNotEmpty && ip != '0.0.0.0') return ip;
  } catch (_) {}
  try {
    final list = await NetworkInterface.list(type: InternetAddressType.IPv4, includeLoopback: false, includeLinkLocal: true);
    final cands = <MapEntry<int, String>>[];
    for (final i in list) {
      for (final a in i.addresses) {
        if (a.isLoopback) continue;
        final s = a.address;
        if (s == '0.0.0.0') continue;
        // skip mobile data / VPN interfaces (rmnet, ccmni, tun, ...) – only LAN-ish ones
        var r = _rank(i.name, s);
        if (r == 9 && !isLanIp(s)) continue;
        if (a.isLinkLocal) r += 20; // 169.254.x only as last resort
        cands.add(MapEntry(r, s));
      }
    }
    if (cands.isEmpty) return null;
    cands.sort((a, b) => a.key.compareTo(b.key));
    return cands.first.value;
  } catch (_) {
    return null;
  }
}
