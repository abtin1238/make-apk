import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;

/// One supported language. [family] picks the regex builder, [kw] = keywords.
class LangDef {
  final String id, name, family, kw;
  final List<String> exts;
  final List<String> files;
  final List<String> shebang;
  const LangDef(this.id, this.name, this.family, this.exts, this.kw, {this.files = const [], this.shebang = const []});
}

class _Lang {
  final RegExp re;
  final List<String> names;
  _Lang(this.re, this.names);
}

/// Lightweight regex-based syntax highlighter (no external package), 70+ languages.
class Hl {
  static const maxLen = 300000;

  static const _dark = {
    'c': Color(0xFF6A9955), 's': Color(0xFFCE9178), 'n': Color(0xFFB5CEA8),
    'k': Color(0xFF569CD6), 't': Color(0xFF4EC9B0), 'a': Color(0xFF9CDCFE),
  };
  static const _light = {
    'c': Color(0xFF008000), 's': Color(0xFFA31515), 'n': Color(0xFF098658),
    'k': Color(0xFF0000FF), 't': Color(0xFF267F99), 'a': Color(0xFF001080),
  };

  // ---- keyword sets -------------------------------------------------------
  static const _kwC = 'auto break case char const continue default do double else enum extern float for goto if inline int long register restrict return short signed sizeof static struct switch typedef union unsigned void volatile while NULL true false bool';
  static const _kwCpp = 'alignas alignof and asm auto bool break case catch char class const constexpr const_cast continue decltype default delete do double dynamic_cast else enum explicit export extern false final float for friend goto if inline int long mutable namespace new noexcept not nullptr operator or override private protected public register reinterpret_cast return short signed sizeof static static_assert static_cast struct switch template this throw true try typedef typeid typename union unsigned using virtual void volatile while concept requires co_await co_return co_yield';
  static const _kwJava = 'abstract assert boolean break byte case catch char class const continue default do double else enum extends final finally float for goto if implements import instanceof int interface long native new null package private protected public return short static strictfp super switch synchronized this throw throws transient true false try void volatile while var record sealed permits yield';
  static const _kwKotlin = 'abstract annotation as break by catch class companion const constructor continue crossinline data do else enum external false final finally for fun get if import in infix init inline inner interface internal is lateinit noinline null object open operator out override package private protected public reified return sealed set super suspend this throw true try typealias val var vararg when where while';
  static const _kwDart = 'abstract as assert async await base break case catch class const continue covariant default deferred do dynamic else enum export extends extension external factory false final finally for Function get hide if implements import in interface is late library mixin new null on operator part required rethrow return sealed set show static super switch sync this throw true try typedef var void when while with yield';
  static const _kwCs = 'abstract as async await base bool break byte case catch char checked class const continue decimal default delegate do double else enum event explicit extern false finally fixed float for foreach goto if implicit in int interface internal is lock long namespace new null object operator out override params private protected public readonly record ref return sbyte sealed short sizeof stackalloc static string struct switch this throw true try typeof uint ulong unchecked unsafe ushort using var virtual void volatile when while yield';
  static const _kwGo = 'break case chan const continue default defer else fallthrough for func go goto if import interface map package range return select struct switch type var true false nil iota int int8 int16 int32 int64 uint uint8 uint16 uint32 uint64 float32 float64 string bool byte rune error any';
  static const _kwRust = 'as async await break const continue crate dyn else enum extern false fn for if impl in let loop match mod move mut pub ref return self Self static struct super trait true type unsafe use where while i8 i16 i32 i64 i128 isize u8 u16 u32 u64 u128 usize f32 f64 bool char str String Vec Option Result Some None Ok Err Box';
  static const _kwSwift = 'actor any as associatedtype async await break case catch class continue default defer deinit do else enum extension fallthrough false fileprivate final for func guard if import in indirect init inout internal is lazy let mutating nil nonmutating open operator override private protocol public repeat required rethrows return self Self set some static struct subscript super switch throw throws true try typealias var weak where while Int Double Float String Bool Array Dictionary Optional';
  static const _kwScala = 'abstract case catch class def do else enum export extends false final finally for given if implicit import lazy match new null object override package private protected return sealed super then this throw trait true try type using val var while with yield';
  static const _kwGroovy = 'abstract as assert boolean break byte case catch char class const continue def default do double else enum extends false final finally float for goto if implements import in instanceof int interface long native new null package private protected public return short static strictfp super switch synchronized this threadsafe throw throws transient true try void volatile while apply plugin dependencies repositories implementation api compileOnly testImplementation';
  static const _kwJs = 'abstract any as async await boolean break case catch class const constructor continue debugger declare default delete do else enum export extends false finally for from function get if implements import in instanceof interface is keyof let module namespace new null number of override package private protected public readonly require return set static string super switch symbol this throw true try type typeof undefined unknown var void while with yield never object';
  static const _kwPhp = 'abstract and array as break callable case catch class clone const continue declare default die do echo else elseif empty enddeclare endfor endforeach endif endswitch endwhile enum eval exit extends false final finally fn for foreach function global goto if implements include include_once instanceof insteadof interface isset list match namespace new null or print private protected public readonly require require_once return static switch throw trait true try unset use var while xor yield';
  static const _kwGlsl = 'attribute bool break const continue discard do else false float for highp if in inout int layout lowp mat2 mat3 mat4 mediump out precision return sampler2D struct true uniform varying vec2 vec3 vec4 void while';
  static const _kwProto = 'syntax package import option message enum service rpc returns stream repeated optional required oneof map reserved extensions extend double float int32 int64 uint32 uint64 sint32 sint64 fixed32 fixed64 sfixed32 sfixed64 bool string bytes true false';
  static const _kwSol = 'abstract address anonymous bool break bytes calldata catch constant constructor continue contract delete do else emit enum event external fallback false for function if immutable import indexed int interface internal is library mapping memory modifier new override payable pragma private public pure receive return returns revert require storage string struct this throw true try uint unchecked using view virtual while';
  static const _kwD = 'abstract alias align assert auto body bool break byte case cast catch char class const continue default delegate delete do double else enum export extern false final finally float for foreach function goto if immutable import in inout int interface is lazy long module new nothrow null out override package pragma private protected public pure real return scope shared short static struct super switch synchronized template this throw true try typeid typeof ubyte uint ulong union unittest ushort version void while with';
  static const _kwZig = 'addrspace align allowzero and anyframe anytype asm async await break callconv catch comptime const continue defer else enum errdefer error export extern fn for if inline linksection noalias nosuspend opaque or orelse packed pub resume return struct suspend switch test threadlocal try union unreachable usingnamespace var volatile while true false null undefined';
  static const _kwHaxe = 'abstract break case cast catch class continue default do dynamic else enum extends extern false final for function if implements import in inline interface macro new null override package private public return static super switch this throw true try typedef untyped using var while';
  static const _kwVerilog = 'always and assign begin buf case casex casez deassign default defparam disable else end endcase endfunction endgenerate endmodule endtask for force forever fork function generate genvar if initial inout input integer join localparam module negedge nor not or output parameter posedge real reg release repeat signed task time timescale wait wire while xnor xor logic always_comb always_ff always_latch bit byte int interface endinterface package endpackage typedef struct enum';

  static const _kwPy = 'and as assert async await break class continue def del elif else except finally for from global if import in is lambda None nonlocal not or pass raise return try while with yield True False self cls match case print';
  static const _kwRuby = 'BEGIN END alias and begin break case class def defined? do else elsif end ensure false for if in module next nil not or redo rescue retry return self super then true undef unless until when while yield require require_relative include extend attr_reader attr_writer attr_accessor puts private public protected lambda proc';
  static const _kwJulia = 'abstract baremodule begin break catch const continue do else elseif end export false finally for function global if import let local macro module mutable quote return struct true try using where while in isa nothing missing';
  static const _kwElixir = 'after alias and case catch cond def defmacro defmodule defp defstruct do else end false fn for if import in nil not or quote raise receive require rescue true try unless unquote use when with';
  static const _kwCrystal = 'abstract alias annotation as asm begin break case class def do else elsif end ensure enum extend false for fun if in include instance_sizeof is_a? lib macro module next nil of out pointerof private protected require rescue responds_to? return select self sizeof struct super then true type typeof union uninitialized unless until when while with yield';
  static const _kwNim = 'addr and as asm bind block break case cast concept const continue converter defer discard distinct div do elif else end enum except export finally for from func if import in include interface is isnot iterator let macro method mixin mod nil not notin object of or out proc ptr raise ref return shl shr static template try tuple type using var when while xor yield true false echo';
  static const _kwR = 'if else repeat while function for next break TRUE FALSE NULL Inf NaN NA NA_integer_ NA_real_ NA_character_ in library require return switch tryCatch stop warning';
  static const _kwCoffee = 'and break by catch class continue delete do else extends false finally for if in instanceof is isnt loop new no not null of off on or return super switch then this throw true try typeof undefined unless until when while yes';
  static const _kwPerl = 'and bless chomp chop close cmp continue defined delete die do each else elsif eq eval exists exit for foreach ge gt if keys last le lc lt my ne next no not open or our package pop print printf push qw redo ref require return reverse scalar shift sort splice split sprintf sub tr uc undef unless until use values wantarray warn while xor';
  static const _kwGql = 'query mutation subscription fragment on type interface union enum input scalar schema extend directive implements true false null ID Int Float String Boolean';
  static const _kwGd = 'and as assert await break breakpoint class class_name const continue elif else enum export extends for func if in is match not onready or pass preload return setget signal static super tool var void while yield true false null self';

  static const _kwSh = 'if then else elif fi for while until do done case esac function in select time echo export local return exit cd set unset source alias read shift trap eval exec test declare readonly printf true false';
  static const _kwPs = 'begin break catch class continue data do dynamicparam else elseif end enum exit filter finally for foreach from function if in param process return switch throw trap try until using var while workflow';
  static const _kwDocker = 'FROM RUN CMD LABEL MAINTAINER EXPOSE ENV ADD COPY ENTRYPOINT VOLUME USER WORKDIR ARG ONBUILD STOPSIGNAL HEALTHCHECK SHELL AS';
  static const _kwMake = 'ifeq ifneq ifdef ifndef else endif include sinclude override export unexport define endef vpath .PHONY .DEFAULT .SUFFIXES wildcard subst patsubst filter foreach call shell';
  static const _kwCmake = 'if else elseif endif foreach endforeach while endwhile function endfunction macro endmacro return set unset option project cmake_minimum_required add_executable add_library add_subdirectory add_definitions target_link_libraries target_include_directories find_package include message install file list string TRUE FALSE ON OFF';
  static const _kwAwk = 'BEGIN END function if else for while do break continue next exit return in delete getline print printf NR NF FS OFS RS ORS FNR FILENAME length substr index split sub gsub match sprintf tolower toupper';
  static const _kwTcl = 'after append array break case catch continue else elseif error eval exec exit expr for foreach format global if incr info join lappend lindex linsert list llength lrange lreplace lsearch lsort namespace proc puts regexp regsub return scan set split string switch then unset uplevel upvar variable while';
  static const _kwFish = 'and argparse begin break builtin case command continue else end exit for function if in not or return set switch while echo test string status read';

  static const _kwData = 'true false null yes no on off True False None';
  static const _kwSql = 'select from where and or not insert into values update set delete create table alter drop index join left right inner outer full cross on group by order having limit offset as distinct null is in like between union all primary key foreign references default unique case when then else end exists view trigger begin commit rollback with count sum avg min max asc desc check constraint autoincrement pragma';
  static const _kwLua = 'and break do else elseif end false for function goto if in local nil not or repeat return then true until while self require';
  static const _kwOcaml = 'and as assert begin class constraint do done downto else end exception external false for fun function functor if in include inherit initializer lazy let match method module mutable new nonrec object of open or private rec sig struct then to true try type val virtual when while with int float string bool unit list option ref';
  static const _kwHs = 'case class data default deriving do else family forall foreign hiding if import in infix infixl infixr instance let module newtype of qualified then type where Int Integer Double Float Char String Bool True False Maybe Just Nothing Either Left Right IO';
  static const _kwLisp = 'defun defmacro defvar defparameter defconstant defstruct defclass defgeneric defmethod defmodule define define-syntax define-record-type lambda let let* letrec if cond case when unless do loop progn setq setf set! begin and or not quote quasiquote unquote nil t true false else import require provide fn def defn ns';
  static const _kwBat = 'if else for in do goto call exit not exist defined echo set setlocal endlocal rem pause shift start cd md mkdir rd rmdir del copy move ren type cls title errorlevel equ neq lss leq gtr geq off on';
  static const _kwVb = 'addhandler andalso as boolean byref byte byval call case catch class const continue date decimal declare default delegate dim do double each else elseif end enum erase error event exit false finally for friend function get global gosub goto handles if implements imports in inherits integer interface is let lib like long loop me mod module mustinherit mustoverride mybase myclass namespace new next not nothing notinheritable notoverridable of on option optional or orelse overloads overridable overrides paramarray preserve private property protected public raiseevent readonly redim rem removehandler resume return select set shadows shared short single static step stop string structure sub synclock then throw to true try typeof until using variant wend when while with withevents writeonly xor';
  static const _kwPas = 'and array as asm begin case class const constructor destructor div do downto else end except exports file finalization finally for function goto if implementation in inherited initialization inline interface is label library mod nil not object of on or out packed private procedure program property protected public raise record repeat resourcestring set shl shr string then threadvar to try type unit until uses var while with xor integer boolean char real byte true false';
  static const _kwFort = 'allocatable allocate assign backspace block call case character close common complex contains continue cycle data deallocate default dimension do double else elseif end endif enddo entry equivalence exit external format function goto if implicit in inout integer intent interface intrinsic kind logical module namelist nullify only open optional out parameter pause pointer precision print private program public read real recursive result return rewind save select sequence stop subroutine target then type use where while write';
  static const _kwAsm = 'mov add sub mul div imul idiv inc dec and or xor not neg shl shr sal sar rol ror push pop call ret jmp je jne jz jnz jg jge jl jle ja jae jb jbe cmp test lea nop int syscall leave enter loop xchg cmov hlt cli sti ldr str ldp stp bl br b cbz cbnz adr adrp eor orr lsl lsr asr svc section segment global extern db dw dd dq resb resw resd resq equ times align bits org default rel .text .data .bss .globl .global .section .byte .word .long .quad .ascii .asciz .align';
  static const _kwMatlab = 'break case catch classdef continue else elseif end for function global if methods otherwise parfor persistent properties return switch try while true false pi Inf NaN eps zeros ones eye rand size length disp fprintf plot';
  static const _kwErlang = 'after and andalso band begin bnot bor bsl bsr bxor case catch cond div end fun if let not of or orelse receive rem try when xor module export import include define spec type record true false';
  static const _kwProlog = 'is mod rem not dynamic discontiguous initialization module use_module ensure_loaded op assert asserta assertz retract findall bagof setof forall between length append member format write nl true fail halt';

  // ---- language table -----------------------------------------------------
  static const List<LangDef> all = [
    // C-like
    LangDef('c', 'C', 'clike', ['c', 'h'], _kwC),
    LangDef('cpp', 'C++', 'clike', ['cpp', 'cc', 'cxx', 'hpp', 'hh', 'hxx', 'ino', 'inl'], _kwCpp),
    LangDef('cuda', 'CUDA', 'clike', ['cu', 'cuh'], _kwCpp),
    LangDef('java', 'Java', 'clike', ['java'], _kwJava),
    LangDef('kotlin', 'Kotlin', 'clike', ['kt', 'kts'], _kwKotlin),
    LangDef('dart', 'Dart', 'clike', ['dart'], _kwDart),
    LangDef('csharp', 'C#', 'clike', ['cs', 'csx'], _kwCs),
    LangDef('go', 'Go', 'clike', ['go'], _kwGo),
    LangDef('rust', 'Rust', 'rust', ['rs'], _kwRust),
    LangDef('swift', 'Swift', 'clike', ['swift'], _kwSwift),
    LangDef('scala', 'Scala', 'clike', ['scala', 'sc'], _kwScala),
    LangDef('groovy', 'Groovy / Gradle', 'clike', ['groovy', 'gvy', 'gradle'], _kwGroovy),
    LangDef('js', 'JavaScript', 'clike', ['js', 'mjs', 'cjs', 'jsx'], _kwJs, shebang: ['node']),
    LangDef('ts', 'TypeScript', 'clike', ['ts', 'tsx', 'mts', 'cts'], _kwJs, shebang: ['deno', 'ts-node']),
    LangDef('php', 'PHP', 'php', ['php', 'phtml', 'php5'], _kwPhp, shebang: ['php']),
    LangDef('glsl', 'GLSL', 'clike', ['glsl', 'vert', 'frag', 'geom', 'comp'], _kwGlsl),
    LangDef('proto', 'Protocol Buffers', 'clike', ['proto'], _kwProto),
    LangDef('solidity', 'Solidity', 'clike', ['sol'], _kwSol),
    LangDef('d', 'D', 'clike', ['d'], _kwD),
    LangDef('zig', 'Zig', 'clike', ['zig'], _kwZig),
    LangDef('haxe', 'Haxe', 'clike', ['hx'], _kwHaxe),
    LangDef('verilog', 'Verilog / SystemVerilog', 'clike', ['v', 'sv', 'svh', 'vh'], _kwVerilog),
    // # comment languages
    LangDef('python', 'Python', 'py', ['py', 'pyw', 'pyi'], _kwPy, shebang: ['python']),
    LangDef('ruby', 'Ruby', 'py', ['rb', 'rake', 'gemspec', 'ru'], _kwRuby, files: ['gemfile', 'rakefile'], shebang: ['ruby']),
    LangDef('julia', 'Julia', 'py', ['jl'], _kwJulia, shebang: ['julia']),
    LangDef('elixir', 'Elixir', 'py', ['ex', 'exs', 'eex'], _kwElixir),
    LangDef('crystal', 'Crystal', 'py', ['cr'], _kwCrystal),
    LangDef('nim', 'Nim', 'py', ['nim', 'nims'], _kwNim),
    LangDef('r', 'R', 'py', ['r', 'rmd'], _kwR, shebang: ['Rscript']),
    LangDef('coffee', 'CoffeeScript', 'py', ['coffee'], _kwCoffee),
    LangDef('perl', 'Perl', 'perl', ['pl', 'pm', 't'], _kwPerl, shebang: ['perl']),
    LangDef('graphql', 'GraphQL', 'py', ['graphql', 'gql'], _kwGql),
    LangDef('gdscript', 'GDScript', 'py', ['gd'], _kwGd),
    // shell-like
    LangDef('bash', 'Shell (Bash)', 'sh', ['sh', 'bash', 'zsh', 'ksh', 'command'], _kwSh, files: ['.bashrc', '.zshrc', '.profile', '.bash_profile', '.bash_aliases'], shebang: ['sh', 'bash', 'zsh', 'ksh', 'dash']),
    LangDef('powershell', 'PowerShell', 'ps', ['ps1', 'psm1', 'psd1'], _kwPs, shebang: ['pwsh']),
    LangDef('dockerfile', 'Dockerfile', 'sh', ['dockerfile'], _kwDocker, files: ['dockerfile']),
    LangDef('makefile', 'Makefile', 'sh', ['mk', 'mak'], _kwMake, files: ['makefile', 'gnumakefile']),
    LangDef('cmake', 'CMake', 'sh', ['cmake'], _kwCmake, files: ['cmakelists.txt']),
    LangDef('awk', 'AWK', 'sh', ['awk'], _kwAwk, shebang: ['awk']),
    LangDef('tcl', 'Tcl', 'sh', ['tcl'], _kwTcl, shebang: ['tclsh', 'wish']),
    LangDef('fish', 'Fish', 'sh', ['fish'], _kwFish, shebang: ['fish']),
    // config / data / markup
    LangDef('yaml', 'YAML', 'data', ['yaml', 'yml'], _kwData),
    LangDef('toml', 'TOML', 'data', ['toml'], _kwData, files: ['cargo.lock', 'pipfile']),
    LangDef('ini', 'INI / Properties', 'data', ['ini', 'cfg', 'conf', 'properties', 'desktop', 'editorconfig'], _kwData),
    LangDef('env', 'Env', 'data', ['env'], _kwData, files: ['.env', '.gitignore', '.dockerignore']),
    LangDef('html', 'HTML', 'xml', ['html', 'htm', 'xhtml', 'vue', 'svelte'], ''),
    LangDef('xml', 'XML', 'xml', ['xml', 'svg', 'xsd', 'xsl', 'xslt', 'plist', 'iml', 'rss', 'kml', 'xaml', 'csproj'], ''),
    LangDef('json', 'JSON', 'json', ['json', 'jsonc', 'json5', 'map', 'arb', 'ipynb', 'webmanifest'], ''),
    LangDef('css', 'CSS', 'css', ['css'], ''),
    LangDef('scss', 'SCSS / Sass', 'css', ['scss', 'sass'], ''),
    LangDef('less', 'Less', 'css', ['less'], ''),
    LangDef('sql', 'SQL', 'sql', ['sql', 'ddl', 'dml'], _kwSql),
    LangDef('markdown', 'Markdown', 'md', ['md', 'markdown', 'mdx'], ''),
    // other families
    LangDef('lua', 'Lua', 'lua', ['lua'], _kwLua, shebang: ['lua']),
    LangDef('ocaml', 'OCaml', 'ml', ['ml', 'mli'], _kwOcaml),
    LangDef('fsharp', 'F#', 'ml', ['fs', 'fsx', 'fsi'], _kwOcaml),
    LangDef('haskell', 'Haskell', 'hs', ['hs', 'lhs'], _kwHs),
    LangDef('elm', 'Elm', 'hs', ['elm'], _kwHs),
    LangDef('lisp', 'Common Lisp', 'lisp', ['lisp', 'lsp', 'cl'], _kwLisp),
    LangDef('scheme', 'Scheme', 'lisp', ['scm', 'ss'], _kwLisp),
    LangDef('racket', 'Racket', 'lisp', ['rkt'], _kwLisp),
    LangDef('clojure', 'Clojure', 'lisp', ['clj', 'cljs', 'cljc', 'edn'], _kwLisp),
    LangDef('elisp', 'Emacs Lisp', 'lisp', ['el'], _kwLisp),
    LangDef('batch', 'Batch', 'bat', ['bat', 'cmd'], _kwBat),
    LangDef('vb', 'Visual Basic', 'vb', ['vb', 'vbs', 'bas', 'vba'], _kwVb),
    LangDef('pascal', 'Pascal / Delphi', 'pas', ['pas', 'pp', 'dpr', 'lpr', 'dfm'], _kwPas),
    LangDef('fortran', 'Fortran', 'fort', ['f90', 'f95', 'f03', 'f08', 'f', 'for'], _kwFort),
    LangDef('asm', 'Assembly', 'asm', ['asm', 's', 'nasm', 'inc'], _kwAsm),
    LangDef('latex', 'LaTeX', 'tex', ['tex', 'sty', 'bib'], ''),
    LangDef('matlab', 'MATLAB / Octave', 'pct', ['m', 'mlx'], _kwMatlab),
    LangDef('erlang', 'Erlang', 'pct', ['erl', 'hrl'], _kwErlang),
    LangDef('prolog', 'Prolog', 'pct', ['pro', 'prolog'], _kwProlog),
  ];

  static final Map<String, LangDef> _byId = {for (final d in all) d.id: d};
  static final Map<String, LangDef> _byExt = () {
    final m = <String, LangDef>{};
    for (final d in all) {
      for (final e in d.exts) {
        m.putIfAbsent(e, () => d);
      }
    }
    return m;
  }();
  static final Map<String, LangDef> _byFile = () {
    final m = <String, LangDef>{};
    for (final d in all) {
      for (final f in d.files) {
        m.putIfAbsent(f, () => d);
      }
    }
    return m;
  }();

  /// Language id for a file path, '' when no highlighting applies.
  static String langOf(String path) {
    final base = p.basename(path).toLowerCase();
    final f = _byFile[base];
    if (f != null) return f.id;
    var e = p.extension(base).toLowerCase();
    if (e.startsWith('.')) e = e.substring(1);
    return _byExt[e]?.id ?? '';
  }

  /// Like [langOf] but falls back to the `#!` line for files without a known extension.
  static String langOfContent(String path, String firstLine) {
    final l = langOf(path);
    if (l.isNotEmpty || !firstLine.startsWith('#!')) return l;
    final line = firstLine.toLowerCase();
    for (final d in all) {
      for (final s in d.shebang) {
        final t = s.toLowerCase();
        if (RegExp('(?:/|\\s)${RegExp.escape(t)}(?:[\\d.]*)(?:\\s|\$)').hasMatch(line)) return d.id;
      }
    }
    return l;
  }

  /// Definition of a language id (null when unknown).
  static LangDef? def(String id) => _byId[id];

  static final Map<String, List<String>> _kwCache = {};

  /// Keywords of a language id (used by auto-complete).
  static List<String> keywordsOf(String id) {
    return _kwCache.putIfAbsent(id, () {
      final d = _byId[id];
      if (d == null) return const <String>[];
      return d.kw.split(' ').where((w) => w.isNotEmpty).toSet().toList();
    });
  }

  /// Display name of a language id ('' for unknown).
  static String nameOf(String id) => _byId[id]?.name ?? '';

  // ---- regex building -----------------------------------------------------
  static const _dq = r'"(?:\\.|[^"\\\n])*"?';
  static const _sq = r"'(?:\\.|[^'\\\n])*'?";
  static const _chr = r"'(?:\\.|[^'\\\n])'";
  static const _bt = r'`(?:\\.|[^`\\])*`?';
  static const _tdq = r'"""[\s\S]*?(?:"""|$)';
  static const _tsq = r"'''[\s\S]*?(?:'''|$)";
  static const _num = r'\b(?:0[xX][0-9a-fA-F_]+|0[bB][01_]+|\d[\d_]*(?:\.\d+)?(?:[eE][+-]?\d+)?[fFlLuU]*)\b';
  static const _cline = r'//[^\n]*';
  static const _cblock = r'/\*[\s\S]*?(?:\*/|$)';

  static final _cache = <String, _Lang?>{};

  static String _g(String n, String pat) => '(?<$n>$pat)';
  static String _kw(String words, {bool dotted = false}) {
    final ws = words.split(' ').where((w) => w.isNotEmpty).map(RegExp.escape);
    return dotted ? '(?<![\\w.])(?:${ws.join('|')})(?![\\w])' : '\\b(?:${ws.join('|')})\\b';
  }

  static _Lang? _build(String id) {
    final d = _byId[id];
    if (d == null) return null;
    try {
      return _buildDef(d);
    } catch (_) {
      return null; // a bad pattern must never break the editor
    }
  }

  static _Lang? _buildDef(LangDef d) {
    final parts = <String>[];
    final names = <String>[];
    void add(String n, String pat) {
      parts.add(_g(n, pat));
      names.add(n);
    }

    var multi = false, icase = false;
    switch (d.family) {
      case 'clike':
        add('c', '$_cline|$_cblock');
        add('s', '$_tdq|$_dq|$_sq|$_bt');
        add('a', const {'c', 'cpp', 'cuda', 'glsl'}.contains(d.id) ? r'@[A-Za-z_]\w*|(?<![^\n])[ \t]*#[ \t]*[a-z]+' : r'@[A-Za-z_]\w*');
        add('n', _num);
        add('k', _kw(d.kw));
        add('t', r'\b[A-Z][A-Za-z0-9_]*\b');
      case 'rust':
        add('c', '$_cline|$_cblock');
        add('s', '$_dq|$_chr');
        add('a', r'#!?\[[^\]\n]*\]');
        add('n', _num);
        add('k', _kw(d.kw));
        add('t', r'\b[A-Z][A-Za-z0-9_]*\b|\b\w+!');
      case 'php':
        add('c', '$_cline|#[^\\n]*|$_cblock');
        add('s', '$_dq|$_sq');
        add('a', r'\$[A-Za-z_]\w*');
        add('n', _num);
        add('k', _kw(d.kw));
        add('t', r'\b[A-Z][A-Za-z0-9_]*\b');
      case 'py':
        add('c', r'#[^\n]*');
        add('s', '$_tdq|$_tsq|$_dq|$_sq');
        add('a', r'@[A-Za-z_][\w.]*|:[A-Za-z_]\w*');
        add('n', _num);
        add('k', _kw(d.kw));
        if (d.id == 'ruby' || d.id == 'crystal' || d.id == 'elixir') add('t', r'\b[A-Z][A-Za-z0-9_]*\b');
      case 'perl':
        add('c', r'#[^\n]*');
        add('s', '$_dq|$_sq');
        add('a', r'[$@%][A-Za-z_]\w*');
        add('n', _num);
        add('k', _kw(d.kw));
      case 'sh':
        multi = true;
        add('c', r'#[^\n]*');
        add('s', '$_dq|$_sq');
        add('a', r'\$\{?[A-Za-z_]\w*\}?|\$[0-9@#?*!$]');
        add('n', _num);
        add('k', _kw(d.kw, dotted: true));
        if (d.id == 'makefile') add('t', r'^[A-Za-z0-9_.%/-]+(?=\s*:(?!=))');
      case 'ps':
        icase = true;
        add('c', r'<#[\s\S]*?(?:#>|$)|#[^\n]*');
        add('s', '$_dq|$_sq');
        add('a', r'\$\{?[A-Za-z_][\w:]*\}?');
        add('n', _num);
        add('k', _kw(d.kw));
        add('t', r'\b[A-Za-z]+-[A-Za-z]\w*\b');
      case 'data':
        multi = true;
        add('c', r'(?:^|(?<=\s))#[^\n]*|^;[^\n]*');
        add('s', '$_dq|$_sq');
        add('a', r'^[ \t-]*[\w.\-]+(?=[ \t]*[:=])|^\[[^\]\n]+\]');
        add('n', _num);
        add('k', _kw(d.kw));
      case 'xml':
        add('c', r'<!--[\s\S]*?(?:-->|$)');
        add('s', r'''(?<==)(?:"[^"]*"?|'[^']*'?)''');
        add('t', r'</?[A-Za-z][\w:.-]*|/?>');
        add('a', r'\b[\w:.@-]+(?==)');
      case 'json':
        add('c', '$_cline|$_cblock');
        add('a', r'"(?:\\.|[^"\\\n])*"(?=\s*:)');
        add('s', _dq);
        add('n', r'-?\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b');
        add('k', r'\b(?:true|false|null)\b');
      case 'css':
        add('c', d.id == 'css' ? _cblock : '$_cline|$_cblock');
        add('s', '$_dq|$_sq');
        add('n', r'#[0-9a-fA-F]{3,8}\b|-?\b\d+(?:\.\d+)?(?:px|em|rem|%|vh|vw|s|ms|deg|pt|fr)?\b');
        add('a', r'[\w-]+(?=\s*:)');
        add('t', r'[.#][A-Za-z_][\w-]*|\$[\w-]+');
        add('k', r'@[\w-]+');
      case 'sql':
        icase = true;
        add('c', r'--[^\n]*|#[^\n]*|/\*[\s\S]*?(?:\*/|$)');
        add('s', r"'(?:''|[^'])*'?|" + _dq);
        add('n', _num);
        add('k', _kw(d.kw));
      case 'md':
        multi = true;
        add('c', r'<!--[\s\S]*?(?:-->|$)');
        add('k', r'^#{1,6}[^\n]*|^[ \t]*(?:[-*+]|\d+\.)(?=[ \t])');
        add('s', r'```[\s\S]*?(?:```|$)|`[^`\n]+`');
        add('a', r'\*\*[^*\n]+\*\*|__[^_\n]+__|\[[^\]\n]*\]\([^)\n]*\)');
      case 'lua':
        add('c', r'--\[\[[\s\S]*?(?:\]\]|$)|--[^\n]*');
        add('s', r'\[\[[\s\S]*?(?:\]\]|$)|' '$_dq|$_sq');
        add('n', _num);
        add('k', _kw(d.kw));
      case 'ml':
        add('c', r'\(\*[\s\S]*?(?:\*\)|$)|//[^\n]*');
        add('s', '$_dq|$_chr');
        add('a', r"'[a-z_]\w*|\[<[^\]\n]*>\]");
        add('n', _num);
        add('k', _kw(d.kw));
        add('t', r'\b[A-Z][A-Za-z0-9_]*\b');
      case 'hs':
        add('c', r'\{-[\s\S]*?(?:-\}|$)|--[^\n]*');
        add('s', '$_dq|$_chr');
        add('n', _num);
        add('k', _kw(d.kw));
        add('t', r'\b[A-Z][A-Za-z0-9_]*\b');
      case 'lisp':
        add('c', r'#\|[\s\S]*?(?:\|#|$)|;[^\n]*');
        add('s', _dq);
        add('a', r':[\w!?*<>=/+-]+|#:[\w-]+');
        add('n', r'(?<![\w-])-?\d+(?:\.\d+)?(?![\w-])');
        add('k', '(?<![\\w!?*-])(?:${d.kw.split(' ').map(RegExp.escape).join('|')})(?![\\w!?*-])');
      case 'bat':
        multi = true;
        icase = true;
        add('c', r'^[ \t]*(?:@?rem\b|::)[^\n]*');
        add('s', _dq);
        add('a', r'%[\w~:*]+%|%%?[~\w]+|![\w]+!');
        add('t', r'^[ \t]*:[\w.-]+');
        add('n', _num);
        add('k', _kw(d.kw));
      case 'vb':
        icase = true;
        add('c', r"(?:'|\brem\b)[^\n]*");
        add('s', r'"(?:""|[^"\n])*"?');
        add('n', _num);
        add('k', _kw(d.kw));
      case 'pas':
        icase = true;
        add('c', r'//[^\n]*|\{[\s\S]*?(?:\}|$)|\(\*[\s\S]*?(?:\*\)|$)');
        add('s', r"'(?:''|[^'\n])*'?");
        add('n', r'\b\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b|\$[0-9a-fA-F]+');
        add('k', _kw(d.kw));
      case 'fort':
        icase = true;
        add('c', r'![^\n]*');
        add('s', '$_dq|$_sq');
        add('n', _num);
        add('k', _kw(d.kw));
      case 'asm':
        multi = true;
        icase = true;
        add('c', r';[^\n]*|//[^\n]*|/\*[\s\S]*?(?:\*/|$)|(?:^|(?<=\s))#[^\n]*');
        add('s', '$_dq|$_sq');
        add('t', r'^[ \t]*[\w.$@]+(?=:)');
        add('a', r'\b(?:[re]?[abcd]x|[abcd][lh]|[re]?[sd]i|[re]?[sb]p|r\d{1,2}[dwb]?|[xwq]\d{1,2}|xmm\d+|ymm\d+|sp|lr|pc)\b|%[a-z]\w*');
        add('n', r'\b0[xX][0-9a-fA-F]+\b|\$[0-9a-fA-F]+\b|\b\d[0-9a-fA-F]*[hH]\b|#?\b\d+\b');
        add('k', _kw(d.kw, dotted: false) + r'|\.[a-z]+\b');
      case 'tex':
        add('c', r'%[^\n]*');
        add('s', r'\$\$[\s\S]*?(?:\$\$|$)|\$[^$\n]*\$?');
        add('k', r'\\[A-Za-z@]+\*?|\\[^A-Za-z]');
        add('a', r'\\(?:begin|end)\{[^}\n]*\}');
      case 'pct':
        add('c', r'%\{[\s\S]*?(?:%\}|$)|%[^\n]*|/\*[\s\S]*?(?:\*/|$)');
        add('s', d.id == 'matlab' ? r"""(?<![\w)\]}'.])'(?:''|[^'\n])*'|"(?:""|[^"\n])*"?""" : '$_dq|$_sq');
        add('n', _num);
        add('k', _kw(d.kw));
        if (d.id == 'erlang' || d.id == 'prolog') add('t', r'\b[A-Z_][A-Za-z0-9_]*\b');
      default:
        return null;
    }
    return _Lang(RegExp(parts.join('|'), multiLine: multi, caseSensitive: !icase), names);
  }

  static List<TextSpan> spans(String text, String lang, bool dark) {
    final l = _cache.putIfAbsent(lang, () => _build(lang));
    if (l == null) return [TextSpan(text: text)];
    final pal = dark ? _dark : _light;
    final out = <TextSpan>[];
    var last = 0;
    for (final m in l.re.allMatches(text)) {
      if (m.end == m.start) continue;
      if (m.start > last) out.add(TextSpan(text: text.substring(last, m.start)));
      String? g;
      for (final n in l.names) {
        if (m.namedGroup(n) != null) {
          g = n;
          break;
        }
      }
      out.add(TextSpan(
        text: text.substring(m.start, m.end),
        style: TextStyle(color: pal[g], fontStyle: g == 'c' ? FontStyle.italic : null),
      ));
      last = m.end;
    }
    if (last < text.length) out.add(TextSpan(text: text.substring(last)));
    return out;
  }
}

/// TextEditingController that paints syntax colours (falls back to plain text
/// while an IME composition is active or when the file is very large).
class CodeController extends TextEditingController {
  String lang;
  bool dark;
  bool enabled = true;
  CodeController({super.text, this.lang = '', this.dark = true});

  String? _t;
  String? _l;
  bool? _d;
  List<TextSpan>? _cached;

  @override
  TextSpan buildTextSpan({required BuildContext context, TextStyle? style, required bool withComposing}) {
    if (!enabled || lang.isEmpty || text.length > Hl.maxLen || (withComposing && value.composing.isValid && !value.composing.isCollapsed)) {
      return super.buildTextSpan(context: context, style: style, withComposing: withComposing);
    }
    if (_t != text || _l != lang || _d != dark || _cached == null) {
      _cached = Hl.spans(text, lang, dark);
      _t = text;
      _l = lang;
      _d = dark;
    }
    return TextSpan(style: style, children: _cached);
  }
}
