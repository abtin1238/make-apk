import 'dart:io';
import 'package:flutter/material.dart' hide Icon;
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../services/folder_sizes.dart';
import 'browser_screen.dart';
import 'hash_screen.dart';
import 'hex_viewer_screen.dart';

/// Details dialog shared by the browser and the gallery.
class FileDetails {
  static Future<void> show(BuildContext context, FItem i) async {
    int size = i.size;
    if (i.isDir) size = await FolderSizes.get(i.path, mtime: i.modified, force: true);
    if (!context.mounted) return;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(i.name),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          SelectableText('${L.t('path')}: ${i.path}'),
          const SizedBox(height: 6),
          Text('${L.t('size')}: ${FileOps.fmt(size)}'),
          Text('${L.t('modified')}: ${i.modified.toString().split('.').first}'),
        ]),
        actions: [
          if (!i.isDir) TextButton(onPressed: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => HashScreen(path: i.path))); }, child: Text(L.t('hash'))),
          if (!i.isDir) TextButton(onPressed: () { Navigator.pop(context); Navigator.push(context, MaterialPageRoute(builder: (_) => HexViewerScreen(path: i.path))); }, child: Text(L.t('hex'))),
          TextButton(onPressed: () => Navigator.pop(context), child: Text(L.t('ok'))),
        ],
      ),
    );
  }

  /// For viewers / players that only know a path.
  static Future<void> showPath(BuildContext context, String path) {
    final st = FileStat.statSync(path);
    return show(context, FItem(File(path), false, st.size < 0 ? 0 : st.size, st.changed.year < 1971 ? DateTime.now() : st.modified));
  }

  static void showInFolder(BuildContext context, String path) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => BrowserScreen(initialPath: p.dirname(path))));
  }
}
