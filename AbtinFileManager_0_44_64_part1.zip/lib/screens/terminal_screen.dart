import 'package:flutter/material.dart';

import '../core/layouts.dart' show tr2;
import '../services/term_tab.dart';
import '../widgets/terminal_tabs_view.dart';

/// Full-screen terminal with several tabs. Every tab is its own PTY session and
/// enters Termux by default (see PkgEnv's shell init).
class TerminalScreen extends StatefulWidget {
  final String cwd;
  const TerminalScreen({super.key, required this.cwd});

  @override
  State<TerminalScreen> createState() => _TerminalScreenState();
}

class _TerminalScreenState extends State<TerminalScreen> {
  late final TermTabs _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TermTabs(cwd: widget.cwd, onEmpty: _onEmpty);
    _tabs.add();
  }

  void _onEmpty() {
    if (mounted) Navigator.of(context).maybePop();
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = ThemeData.dark(useMaterial3: true).copyWith(
      scaffoldBackgroundColor: TermStyle.bg,
      colorScheme: const ColorScheme.dark(
        primary: TermStyle.accent,
        secondary: TermStyle.dim,
        surface: Color(0xFF111111),
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: Color(0xFF101010),
        foregroundColor: Colors.white,
        elevation: 0,
        toolbarHeight: 48,
      ),
    );
    return Theme(
      data: theme,
      child: Scaffold(
        backgroundColor: TermStyle.bg,
        appBar: AppBar(
          title: Text(tr2('ترمینال', 'Terminal'), style: const TextStyle(fontSize: 17)),
          actions: [
            IconButton(
              tooltip: tr2('راهنما', 'Help'),
              onPressed: () => showTermHelp(context),
              icon: const Icon(Icons.info_outline_rounded),
            ),
            IconButton(
              tooltip: tr2('بستن صفحه', 'Close'),
              onPressed: () => Navigator.of(context).maybePop(),
              icon: const Icon(Icons.close_rounded),
            ),
          ],
        ),
        body: SafeArea(
          child: Column(
            children: [
              TermTabStrip(tabs: _tabs),
              Expanded(child: TermTabBody(tabs: _tabs, compact: true)),
            ],
          ),
        ),
      ),
    );
  }
}
