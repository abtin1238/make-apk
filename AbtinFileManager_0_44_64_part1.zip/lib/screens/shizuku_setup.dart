import 'dart:async';
import 'package:flutter/material.dart' hide Icon;
import '../core/l10n.dart';
import '../services/native.dart';
import '../services/shizuku.dart';
import '../widgets/app_icon.dart';
import '../widgets/ui.dart';
import 'browser_screen.dart';

const _shizukuSite = 'https://shizuku.rikka.app/download/';

/// Three-step guide (install -> start -> allow) that follows the real Shizuku state.
/// [onReady] fires once, as soon as everything works (the browser reloads its folder then).
class ShizukuSetupCard extends StatefulWidget {
  final VoidCallback? onReady;
  const ShizukuSetupCard({super.key, this.onReady});
  @override
  State<ShizukuSetupCard> createState() => _ShizukuSetupCardState();
}

class _ShizukuSetupCardState extends State<ShizukuSetupCard> with WidgetsBindingObserver {
  ShizuStatus st = ShizuStatus.none;
  bool fired = false, busyReq = false;
  Timer? _poll;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _check();
    _poll = Timer.periodic(const Duration(seconds: 3), (_) => _check());
  }

  @override
  void dispose() {
    _poll?.cancel();
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) _check();
  }

  Future<void> _check() async {
    final s = await Shizu.status(force: true);
    if (!mounted) return;
    setState(() => st = s);
    if (s.ready && !fired) {
      fired = true;
      widget.onReady?.call();
    }
  }

  Future<void> _grant() async {
    setState(() => busyReq = true);
    await Shizu.request();
    if (mounted) setState(() => busyReq = false);
    await _check();
  }

  Widget _step(BuildContext context, {required int n, required String title, required bool done, required bool current, String? body, List<Widget> actions = const []}) {
    final cs = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 5),
      color: done ? cs.primaryContainer.withOpacity(.35) : null,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(done ? Icons.check_circle_rounded : (current ? Icons.radio_button_checked_rounded : Icons.radio_button_unchecked_rounded),
                color: done ? Colors.green : (current ? cs.primary : cs.outline)),
            const SizedBox(width: 10),
            Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15))),
          ]),
          if (current && body != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(body, style: const TextStyle(fontSize: 13, height: 1.5))),
          if (current && actions.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Wrap(spacing: 8, runSpacing: 6, children: actions)),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final installed = st.installed || st.running;
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        Row(children: [
          const Icon(Icons.admin_panel_settings_rounded, size: 30),
          const SizedBox(width: 10),
          Expanded(child: Text(L.t('shizuTitle'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800), textDirection: TextDirection.ltr)),
        ]),
        const SizedBox(height: 8),
        Text(L.t('shizuIntro'), style: const TextStyle(height: 1.55)),
        const SizedBox(height: 10),
        _step(context,
            n: 1,
            title: L.t('shizuStep1'),
            done: installed,
            current: !installed,
            actions: [FilledButton.icon(onPressed: () => Native.openUrl(_shizukuSite), icon: const Icon(Icons.download_rounded), label: Text(L.t('shizuInstallBtn')))]),
        _step(context,
            n: 2,
            title: L.t('shizuStep2'),
            done: st.running,
            current: installed && !st.running,
            body: L.t('shizuHowStart'),
            actions: [FilledButton.icon(onPressed: Shizu.launchApp, icon: const Icon(Icons.open_in_new_rounded), label: Text(L.t('shizuOpenBtn')))]),
        _step(context,
            n: 3,
            title: L.t('shizuStep3'),
            done: st.ready,
            current: st.running && !st.granted,
            actions: [FilledButton.icon(onPressed: busyReq ? null : _grant, icon: const Icon(Icons.verified_user_rounded), label: Text(L.t('shizuGrantBtn')))]),
        const SizedBox(height: 6),
        if (st.ready)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Row(children: [const Icon(Icons.check_circle_rounded, color: Colors.green), const SizedBox(width: 8), Text(L.t('shizuReady'), style: const TextStyle(fontWeight: FontWeight.w700))]),
          ),
        Align(alignment: AlignmentDirectional.centerStart, child: TextButton.icon(onPressed: _check, icon: const Icon(Icons.refresh_rounded), label: Text(L.t('shizuRecheck')))),
      ],
    );
  }
}

/// Full page: the setup guide, plus shortcuts to the two folders once Shizuku works.
class ShizukuScreen extends StatefulWidget {
  const ShizukuScreen({super.key});
  @override
  State<ShizukuScreen> createState() => _ShizukuScreenState();
}

class _ShizukuScreenState extends State<ShizukuScreen> {
  bool ready = false;

  void _open(String path) =>
      Navigator.push(context, MaterialPageRoute(builder: (_) => BrowserScreen(initialPath: path)));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(L.t('shizuTitle'), textDirection: TextDirection.ltr)),
        body: Column(children: [
          Expanded(child: ShizukuSetupCard(onReady: () => setState(() => ready = true))),
          if (ready)
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(L.t('shizuOpenNote'), style: const TextStyle(fontSize: 12))),
                  FilledButton.icon(onPressed: () => _open('/storage/emulated/0/Android/data'), icon: const Icon(Icons.folder_special_rounded), label: Text(L.t('shizuOpenData'), textDirection: TextDirection.ltr)),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(onPressed: () => _open('/storage/emulated/0/Android/obb'), icon: const Icon(Icons.folder_zip_rounded), label: Text(L.t('shizuOpenObb'), textDirection: TextDirection.ltr)),
                ]),
              ),
            ),
        ]),
      );
}
