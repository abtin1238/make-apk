import 'package:flutter/material.dart' hide Icon;
import '../core/l10n.dart';
import '../services/file_ops.dart' show OpError;
import '../services/native.dart';
import '../services/update_service.dart';
import '../widgets/ui.dart';

String _err(Object e) => e is OpError ? (e.arg == null ? L.t(e.key) : '${L.t(e.key)}: ${e.arg}') : '${L.t('updFailed')}: $e';

/// Looks at the GitHub releases. [manual] = the user tapped "Check for updates": say so when there is
/// nothing new or when the check failed; the automatic start-up check stays silent in those cases.
Future<void> checkForUpdate(BuildContext context, {bool manual = false}) async {
  UpdateInfo? u;
  try {
    u = await UpdateService.check(force: manual);
  } catch (e) {
    if (manual && context.mounted) snack(context, _err(e));
    return;
  }
  if (!context.mounted) return;
  if (u == null) {
    if (manual) snack(context, L.t('updUpToDate'));
    return;
  }
  await _offer(context, u);
}

Future<void> _offer(BuildContext context, UpdateInfo u) async {
  final cur = await UpdateService.currentVersion();
  if (!context.mounted) return;
  final go = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: Text(L.t('updAvailable')),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${L.t('updRelease')}: ${u.name}', style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text('${L.t('updCurrent')}: $cur', style: const TextStyle(fontSize: 12)),
          if (u.assetSize > 0) Text('${(u.assetSize / (1 << 20)).toStringAsFixed(1)} MB', style: const TextStyle(fontSize: 12)),
          if (u.notes.trim().isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(u.notes.trim(), maxLines: 8, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
          ],
        ]),
      ),
      actions: [
        CancelButton(label: L.t('updLater'), onPressed: () {
          UpdateService.skip(u.tag);
          Navigator.pop(ctx, false);
        }),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: Text(L.t('updNow'))),
      ],
    ),
  );
  if (go != true || !context.mounted) return;
  // no in-app download: the releases page opens in the browser and the user picks the file there
  if (!await Native.openUrl(u.releaseUrl) && context.mounted) snack(context, u.releaseUrl);
}
