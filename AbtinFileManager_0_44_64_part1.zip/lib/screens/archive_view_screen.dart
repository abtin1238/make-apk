import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart' hide Icon;
import '../widgets/app_icon.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;
import '../core/l10n.dart';
import '../services/archive_service.dart';
import '../services/file_ops.dart';
import '../widgets/ui.dart';
import 'archive_dialog.dart';
import 'opener.dart';
import 'saf_prompt.dart';
import 'text_editor_screen.dart';
import '../services/saf.dart';

class _Node {
  final String name; // one path segment
  final String full; // entry name inside the archive; folders end with '/'
  final bool dir;
  int size;
  _Node(this.name, this.full, this.dir, this.size);
}

/// Browse the contents of an archive without extracting it, tick entries and extract only those.
class ArchiveViewScreen extends StatefulWidget {
  final String path;
  final String? password;
  final VoidCallback? onChanged;
  const ArchiveViewScreen({super.key, required this.path, this.password, this.onChanged});
  @override
  State<ArchiveViewScreen> createState() => _ArchiveViewState();
}

class _ArchiveViewState extends State<ArchiveViewScreen> {
  List<ArchiveEntry>? _all;
  String? _err;
  String? _pw;
  String _cwd = '';
  bool _canEdit = false;
  final Set<String> _sel = {};

  @override
  void initState() {
    super.initState();
    _pw = widget.password;
    _load();
  }

  String _msg(Object e) => e is OpError ? (e.arg == null ? L.t(e.key) : '${L.t(e.key)}: ${e.arg}') : '${L.t('error')}: $e';

  Future<void> _load() async {
    setState(() {
      _all = null;
      _err = null;
    });
    try {
      final l = await ArchiveService.list(widget.path, password: _pw);
      if (!mounted) return;
      if (_pw == null && l.any((e) => e.enc)) {
        // the names are readable, the content needs the password: ask now so "extract" just works
        final pw = await _askPassword();
        if (pw != null) _pw = pw;
      }
      if (mounted) {
        setState(() {
          _all = l;
          _canEdit = _pw == null && !l.any((e) => e.enc) && ArchiveService.canEditInPlace(widget.path);
        });
      }
    } on OpError catch (e) {
      if (e.key == 'wrongPassword' && mounted) {
        final pw = await _askPassword();
        if (pw != null && mounted) {
          _pw = pw;
          return _load();
        }
      }
      if (mounted) setState(() => _err = _msg(e));
    } catch (e) {
      if (mounted) setState(() => _err = _msg(e));
    }
  }

  Future<String?> _askPassword() {
    final c = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(L.t('password')),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(L.t('needPassword')),
          const SizedBox(height: 8),
          TextField(controller: c, obscureText: true, autofocus: true, onSubmitted: (v) => Navigator.pop(ctx, v)),
        ]),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(ctx)),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: Text(L.t('ok'))),
        ],
      ),
    ).then((v) => v == null || v.isEmpty ? null : v);
  }

  List<_Node> _children() {
    final m = <String, _Node>{};
    for (final e in _all ?? const <ArchiveEntry>[]) {
      if (!e.name.startsWith(_cwd) || e.name == _cwd) continue;
      final rest = e.name.substring(_cwd.length);
      final i = rest.indexOf('/');
      if (i < 0) {
        m[rest] = _Node(rest, '$_cwd$rest', false, e.size);
      } else {
        final seg = rest.substring(0, i);
        final n = m.putIfAbsent(seg, () => _Node(seg, '$_cwd$seg/', true, 0));
        if (!e.dir) n.size += e.size;
      }
    }
    final l = m.values.toList()
      ..sort((a, b) {
        if (a.dir != b.dir) return a.dir ? -1 : 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });
    return l;
  }

  bool _checked(_Node n) => ArchiveService.matches(n.full, _sel.toList());

  void _toggle(_Node n) {
    setState(() {
      if (_sel.contains(n.full)) {
        _sel.remove(n.full);
      } else if (!_checked(n)) {
        _sel.add(n.full); // already covered by a ticked parent folder: nothing to add
      }
    });
  }

  String _up(String c) {
    final t = c.endsWith('/') ? c.substring(0, c.length - 1) : c;
    final i = t.lastIndexOf('/');
    return i < 0 ? '' : t.substring(0, i + 1);
  }

  /// Unpacks just one entry to a temporary folder (the rest of the archive is never touched).
  Future<String?> _extractOne(_Node n) async {
    final tmp = await getTemporaryDirectory();
    final root = Directory(p.join(tmp.path, 'archive_open'));
    try {
      if (root.existsSync()) {
        final now = DateTime.now();
        for (final d in root.listSync()) {
          if (now.difference(d.statSync().modified).inHours >= 24) d.deleteSync(recursive: true);
        }
      }
    } catch (_) {}
    final dir = Directory(p.join(root.path, '${DateTime.now().microsecondsSinceEpoch}'));
    if (!mounted) return null;
    showDialog(context: context, barrierDismissible: false, builder: (_) => const Center(child: CircularProgressIndicator()));
    String? out;
    Object? err;
    try {
      await ArchiveService.extract(widget.path, dir.path, password: _pw, only: [n.full]);
      final guess = p.join(dir.path, ArchiveService.normName(n.full));
      if (File(guess).existsSync()) {
        out = guess;
      } else if (dir.existsSync()) {
        for (final f in dir.listSync(recursive: true)) {
          if (f is File) {
            out = f.path;
            break;
          }
        }
      }
    } catch (e) {
      err = e;
    }
    if (mounted) Navigator.of(context, rootNavigator: true).pop();
    if (!mounted) return null;
    if (out == null) {
      snack(context, err != null ? _msg(err) : L.t('error'));
      return null;
    }
    return out;
  }

  /// Tap on a file: unpack just that entry and open it with the normal viewer,
  /// so the user never has to extract the whole archive to look at one file.
  Future<void> _openEntry(_Node n) async {
    final out = await _extractOne(n);
    if (out == null || !mounted) return;
    await Opener.open(context, out);
  }

  // ───────────── edit the zip in place (delete / add / replace / rename / edit text) ─────────────

  Future<bool> _apply({List<String> remove = const [], Map<String, String> add = const {}, Map<String, String> rename = const {}}) async {
    if (!await ensureSdAll(context, [widget.path])) return false;
    if (!mounted) return false;
    final ok = await busy(context, () async {
      if (await Saf.needsSaf(widget.path)) {
        // SD card without direct write access: edit a temporary copy, then write it back through SAF
        final t = p.join(Directory.systemTemp.path, 'abtin_zipedit_${DateTime.now().microsecondsSinceEpoch}.zip');
        try {
          await File(widget.path).copy(t);
          await ArchiveService.zipEdit(t, remove: remove, add: add, rename: rename);
          await Saf.writeBytes(widget.path, await File(t).readAsBytes());
        } finally {
          try { File(t).deleteSync(); } catch (_) {}
        }
      } else {
        await ArchiveService.zipEdit(widget.path, remove: remove, add: add, rename: rename);
      }
    });
    if (ok) {
      widget.onChanged?.call();
      if (mounted) {
        _sel.clear();
        await _load();
      }
    }
    return ok;
  }

  bool _exists(String full) => (_all ?? const <ArchiveEntry>[]).any((e) => e.name == full || e.name == '$full/');

  Future<void> _addFiles() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true);
    if (r == null || !mounted) return;
    final add = <String, String>{};
    for (final f in r.files) {
      if (f.path != null) add['$_cwd${p.basename(f.path!)}'] = f.path!;
    }
    if (add.isEmpty) return;
    final dup = add.keys.where(_exists).length;
    if (dup > 0 && !await confirm(context, L.tr('zipReplaceExisting', {'n': dup}))) return;
    if (!mounted) return;
    if (await _apply(add: add) && mounted) snack(context, L.tr('zipAdded', {'n': add.length}));
  }

  Future<void> _replaceWith(_Node n) async {
    final r = await FilePicker.platform.pickFiles();
    final path = r?.files.single.path;
    if (path == null || !mounted) return;
    if (await _apply(add: {n.full: path}) && mounted) snack(context, L.t('zipSaved'));
  }

  Future<void> _deleteNodes(List<String> names) async {
    if (names.isEmpty) return;
    if (!await confirm(context, L.tr('zipDeleteConfirm', {'n': names.length}))) return;
    if (!mounted) return;
    if (await _apply(remove: names) && mounted) snack(context, L.t('zipDeleted'));
  }

  Future<void> _renameNode(_Node n) async {
    final c = TextEditingController(text: n.name);
    final nv = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(L.t('rename')),
        content: TextField(controller: c, autofocus: true, onSubmitted: (v) => Navigator.pop(ctx, v)),
        actions: [
          CancelButton(onPressed: () => Navigator.pop(ctx)),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: Text(L.t('ok'))),
        ],
      ),
    );
    final name = nv?.trim().replaceAll('/', '');
    if (name == null || name.isEmpty || name == n.name || !mounted) return;
    final parent = n.full.substring(0, n.full.length - (n.dir ? n.name.length + 1 : n.name.length));
    final to = '$parent$name${n.dir ? '/' : ''}';
    if (_exists(n.dir ? to.substring(0, to.length - 1) : to)) {
      snack(context, L.t('zipNameExists'));
      return;
    }
    await _apply(rename: {n.full: to});
  }

  /// Unpacks the entry to a temp file, opens the text editor, and when the text was changed
  /// puts it back into the zip (the rest of the zip is never extracted).
  Future<void> _editText(_Node n) async {
    final out = await _extractOne(n);
    if (out == null || !mounted) return;
    final before = await File(out).readAsBytes();
    if (!mounted) return;
    await Navigator.push(context, MaterialPageRoute(builder: (_) => TextEditorScreen(path: out)));
    if (!mounted) return;
    final after = await File(out).readAsBytes();
    var same = before.length == after.length;
    for (var i = 0; same && i < before.length; i++) {
      if (before[i] != after[i]) same = false;
    }
    if (same) return;
    if (!await confirm(context, L.t('zipSaveChanges'))) return;
    if (!mounted) return;
    if (await _apply(add: {n.full: out}) && mounted) snack(context, L.t('zipSaved'));
  }

  Widget _entryMenu(_Node n) => PopupMenuButton<String>(
        tooltip: L.t('zipEdit'),
        icon: const Icon(Icons.more_vert_rounded),
        onSelected: (v) {
          switch (v) {
            case 'edit':
              _editText(n);
            case 'replace':
              _replaceWith(n);
            case 'rename':
              _renameNode(n);
            case 'delete':
              _deleteNodes([n.full]);
          }
        },
        itemBuilder: (_) => [
          if (!n.dir) PopupMenuItem(value: 'edit', child: Text(L.t('zipEditText'))),
          if (!n.dir) PopupMenuItem(value: 'replace', child: Text(L.t('zipReplaceFile'))),
          PopupMenuItem(value: 'rename', child: Text(L.t('rename'))),
          PopupMenuItem(value: 'delete', child: Text(L.t('delete'), style: const TextStyle(color: Colors.redAccent))),
        ],
      );

  Future<void> _extract(List<String>? only) async {
    await showArchiveDialog(context, widget.path, widget.onChanged, only: only, password: _pw);
  }

  @override
  Widget build(BuildContext context) {
    final kids = _all == null ? const <_Node>[] : _children();
    return PopScope(
      canPop: _cwd.isEmpty,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) setState(() => _cwd = _up(_cwd));
      },
      child: Scaffold(
        appBar: AppBar(
          title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(p.basename(widget.path), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16)),
            Text(_cwd.isEmpty ? L.t('archiveContents') : '/$_cwd', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
          ]),
          actions: [
            if (_canEdit) IconButton(tooltip: L.t('zipAddFiles'), icon: const Icon(Icons.note_add_rounded), onPressed: _addFiles),
            if (_all != null)
              IconButton(
                tooltip: L.t('selectAll'),
                icon: const Icon(Icons.select_all_rounded),
                onPressed: () => setState(() {
                  for (final n in kids) {
                    _sel.add(n.full);
                  }
                }),
              ),
            if (_sel.isNotEmpty)
              IconButton(tooltip: L.t('selectNone'), icon: const Icon(Icons.deselect_rounded), onPressed: () => setState(_sel.clear)),
          ],
        ),
        body: _body(kids),
        bottomNavigationBar: _all == null
            ? null
            : SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Row(children: [
                    Expanded(child: OutlinedButton(onPressed: () => _extract(null), child: Text(L.t('extractAll')))),
                    const SizedBox(width: 10),
                    Expanded(
                      child: FilledButton(
                        onPressed: _sel.isEmpty ? null : () => _extract(_sel.toList()),
                        child: Text(L.tr('extractSelected', {'n': _sel.length})),
                      ),
                    ),
                    if (_canEdit && _sel.isNotEmpty) ...[
                      const SizedBox(width: 10),
                      IconButton.filled(
                        tooltip: L.t('delete'),
                        style: IconButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white),
                        icon: const Icon(Icons.delete_rounded),
                        onPressed: () => _deleteNodes(_sel.toList()),
                      ),
                    ],
                  ]),
                ),
              ),
      ),
    );
  }

  Widget _body(List<_Node> kids) {
    if (_err != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(_err!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.redAccent)),
        ),
      );
    }
    if (_all == null) return const Center(child: CircularProgressIndicator());
    if (kids.isEmpty) return Center(child: Text(L.t('empty')));
    return ListView.builder(
      itemCount: kids.length + (_cwd.isEmpty ? 0 : 1),
      itemBuilder: (_, i) {
        if (_cwd.isNotEmpty) {
          if (i == 0) {
            return ListTile(
              leading: const Icon(Icons.folder_open_rounded),
              title: const Text('..'),
              onTap: () => setState(() => _cwd = _up(_cwd)),
            );
          }
          i--;
        }
        final n = kids[i];
        final on = _checked(n);
        return ListTile(
          leading: TypeIcon(n.name, n.dir),
          title: Text(n.name, maxLines: 2, overflow: TextOverflow.ellipsis),
          subtitle: Text(n.dir ? (n.size > 0 ? FileOps.fmt(n.size) : '') : FileOps.fmt(n.size), style: const TextStyle(fontSize: 11)),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: [
            if (_canEdit) _entryMenu(n),
            Checkbox(value: on, onChanged: (_) => _toggle(n)),
          ]),
          onTap: n.dir ? () => setState(() => _cwd = n.full) : (_sel.isNotEmpty ? () => _toggle(n) : () => _openEntry(n)),
          onLongPress: () => _toggle(n),
        );
      },
    );
  }
}
