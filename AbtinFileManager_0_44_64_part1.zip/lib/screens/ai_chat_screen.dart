import 'package:flutter/material.dart';

import '../core/layouts.dart' show tr2;
import '../services/ai_session.dart';
import '../widgets/ai_chat_panel.dart';
import 'folder_picker.dart';

/// Full-screen AI chat (ChatGPT / DeepSeek / Kimi / Claude ... through their APIs).
/// Without a project folder it is a plain chat; with one the model can read, search and edit its files.
class AiChatScreen extends StatefulWidget {
  const AiChatScreen({super.key, this.root});
  final String? root;

  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<AiChatScreen> {
  late AiSession _s = AiSession(root: widget.root);

  @override
  void dispose() {
    _s.dispose();
    super.dispose();
  }

  Future<void> _pick() async {
    final r = await pickFolder(context, start: _s.root, title: tr2('پوشهٔ پروژه', 'Project folder'));
    if (r == null || !mounted) return;
    final old = _s;
    setState(() => _s = AiSession(root: r));
    old.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final root = _s.root;
    return Scaffold(
      appBar: AppBar(
        title: Text(tr2('هوش مصنوعی', 'AI assistant')),
        bottom: root == null
            ? null
            : PreferredSize(
                preferredSize: const Size.fromHeight(22),
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 4, left: 12, right: 12),
                  child: Text(root, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11)),
                ),
              ),
      ),
      body: SafeArea(child: AiChatPanel(key: ValueKey(root), session: _s, onPickFolder: _pick)),
    );
  }
}
