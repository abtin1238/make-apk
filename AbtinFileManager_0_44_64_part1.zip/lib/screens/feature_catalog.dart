import 'package:flutter/material.dart' hide Icon;
import '../core/l10n.dart';
import '../services/file_ops.dart';
import '../widgets/app_icon.dart';
import 'analyzer_screen.dart';
import 'ai_chat_screen.dart';
import 'apps_screen.dart';
import 'category_screen.dart';
import 'duplicates_screen.dart';
import 'equalizer_screen.dart';
import 'ext_screen.dart';
import 'media_screen.dart';
import 'more_screen.dart';
import 'music_library_screen.dart';
import 'nearby_screen.dart';
import 'office_hub_screen.dart';
import 'path_list_screen.dart';
import 'photo_albums_screen.dart';
import 'remote_screen.dart';
import 'search_screen.dart';
import 'security_screen.dart';
import 'shizuku_setup.dart';
import 'terminal_screen.dart';
import 'transfer_screen.dart';
import 'trash_screen.dart';
import 'update_dialog.dart';
import 'vault_screen.dart';

String _t(String fa, String en) => L.lang == 'fa' ? fa : en;

/// One feature of the app, defined ONCE here and shown by every home screen / launcher.
/// To add a feature to the home screen add one [Feature] to [FeatureCatalog.groups].
class Feature {
  final String id;
  final IconData icon;
  final String fa, en;
  final Color color;
  final void Function(BuildContext) open;
  const Feature(this.id, this.icon, this.fa, this.en, this.color, this.open);
  String get label => _t(fa, en);
}

class FeatureGroup {
  final String id, fa, en;
  final List<Feature> features;
  const FeatureGroup(this.id, this.fa, this.en, this.features);
  String get title => _t(fa, en);
}

void _go(BuildContext c, Widget page) => Navigator.push(c, MaterialPageRoute(builder: (_) => page));

class FeatureCatalog {
  static List<FeatureGroup> groups() => [
        FeatureGroup('office', 'آفیس و اسناد', 'Office & documents', [
          Feature('word', Icons.article_rounded, 'Word', 'Word', const Color(0xFF1375E8),
              (c) => _go(c, ExtScreen(title: 'Word', exts: const {'docx', 'docm', 'dotx', 'dotm', 'doc', 'rtf'}))),
          Feature('excel', Icons.table_chart_rounded, 'Excel', 'Excel', const Color(0xFF00A965),
              (c) => _go(c, ExtScreen(title: 'Excel', exts: const {'xlsx', 'xlsm', 'xltx', 'xls', 'csv', 'tsv'}))),
          Feature('pptx', Icons.slideshow_rounded, 'PowerPoint', 'PowerPoint', const Color(0xFFE95624),
              (c) => _go(c, ExtScreen(title: 'PowerPoint', exts: const {'pptx', 'potx', 'ppt'}))),
          Feature('pdf', Icons.picture_as_pdf_rounded, 'PDF', 'PDF', const Color(0xFFED2339),
              (c) => _go(c, ExtScreen(title: 'PDF', exts: const {'pdf'}))),
          Feature('newdoc', Icons.note_add_rounded, 'سند جدید', 'New document', const Color(0xFF00B8D9),
              (c) => _go(c, OfficeHubScreen(directory: FileOps.root))),
          Feature('text', Icons.code_rounded, 'ویرایشگر کد', 'Code editor', const Color(0xFF7C5CFF),
              (c) => _go(c, ExtScreen(title: _t('ویرایشگر کد', 'Code editor'), exts: FileOps.textExts))),
          Feature('zip', Icons.folder_zip_rounded, 'زیپ', 'Zip', const Color(0xFFFFB81C),
              (c) => _go(c, const CategoryScreen(cat: Cat.archives))),
          Feature('ai', Icons.smart_toy_rounded, 'هوش مصنوعی', 'AI assistant', const Color(0xFFD97757),
              (c) => _go(c, const AiChatScreen())),
          Feature('terminal', Icons.terminal_rounded, 'ترمینال', 'Terminal', const Color(0xFF22D3A5),
              (c) => _go(c, const TerminalScreen(cwd: FileOps.root))),
        ]),
        FeatureGroup('media', 'رسانه', 'Media', [
          Feature('photos', Icons.photo_library_rounded, 'تصاویر', 'Photos', const Color(0xFF22C8D5), (c) => _go(c, const PhotoAlbumsScreen())),
          Feature('videos', Icons.movie_rounded, 'ویدیوها', 'Videos', const Color(0xFF833BFF), (c) => _go(c, const CategoryScreen(cat: Cat.videos))),
          Feature('music', Icons.library_music_rounded, 'موسیقی', 'Music', const Color(0xFFFF8A00), (c) => _go(c, const MusicLibraryScreen())),
          Feature('media', Icons.perm_media_rounded, 'همهٔ رسانه', 'All media', const Color(0xFFB04DFF), (c) => _go(c, const MediaScreen())),
          Feature('eq', Icons.equalizer_rounded, 'اکولایزر', 'Equalizer', const Color(0xFF2E7DFF), (c) => _go(c, const EqualizerScreen())),
        ]),
        FeatureGroup('tools', 'ابزارهای فایل', 'File tools', [
          Feature('search', Icons.manage_search_rounded, 'جستجو', 'Search', const Color(0xFF3D9BFF), (c) => _go(c, const SearchScreen())),
          Feature('dups', Icons.content_copy_rounded, 'فایل تکراری', 'Duplicates', const Color(0xFFFF5C7A), (c) => _go(c, const DuplicatesScreen())),
          Feature('analyzer', Icons.donut_large_rounded, 'تحلیل حافظه', 'Storage', const Color(0xFF14C9A0), (c) => _go(c, const AnalyzerScreen())),
          Feature('apps', Icons.android_rounded, 'برنامه‌ها', 'Apps / APK', const Color(0xFF3DDC84), (c) => _go(c, const AppsScreen())),
          Feature('fav', Icons.star_rounded, 'علاقه‌مندی', 'Favorites', const Color(0xFFFFC928), (c) => _go(c, PathListScreen(title: L.t('favorites'), fav: true))),
          Feature('recent', Icons.history_rounded, 'اخیر', 'Recent', const Color(0xFF00C2E0), (c) => _go(c, PathListScreen(title: L.t('recents'), fav: false))),
          Feature('trash', Icons.delete_rounded, 'سطل زباله', 'Trash', const Color(0xFF8A94B8), (c) => _go(c, const TrashScreen())),
        ]),
        FeatureGroup('network', 'شبکه و ابر', 'Network & cloud', [
          Feature('transfer', Icons.wifi_tethering_rounded, 'انتقال شبکه‌ای', 'Transfer', const Color(0xFF2D7BFF), (c) => _go(c, const TransferScreen())),
          Feature('remote', Icons.cloud_rounded, 'ابر و سرور', 'Cloud / FTP', const Color(0xFF5B8CFF), (c) => _go(c, const RemoteScreen())),
          Feature('nearby', Icons.radar_rounded, 'اطراف', 'Nearby', const Color(0xFF8D36FF), (c) => _go(c, const NearbyScreen())),
        ]),
        FeatureGroup('security', 'امنیت و سیستم', 'Security & system', [
          Feature('vault', Icons.lock_rounded, 'صندوق امن', 'Vault', const Color(0xFF16B8A6), (c) => _go(c, const VaultScreen())),
          Feature('security', Icons.shield_rounded, 'امنیت', 'Security', const Color(0xFF1E88E5), (c) => _go(c, const SecurityScreen())),
          Feature('shizuku', Icons.admin_panel_settings_rounded, 'Android/data', 'Android/data', const Color(0xFF00A3FF), (c) => _go(c, const ShizukuScreen())),
          Feature('settings', Icons.settings_rounded, 'تنظیمات', 'Settings', const Color(0xFF7D8AA8), (c) => _go(c, const MoreScreen())),
          Feature('update', Icons.system_update_rounded, 'آپدیت', 'Update', const Color(0xFFFF8A3D), (c) => checkForUpdate(c, manual: true)),
        ]),
      ];
}

/// Tile of one [Feature]: gradient icon plate + label. Colours follow the light / dark theme.
class FeatureTile extends StatelessWidget {
  final Feature feature;
  final double k;
  final bool dark;
  const FeatureTile({super.key, required this.feature, required this.k, required this.dark});

  @override
  Widget build(BuildContext context) {
    final color = feature.color;
    return InkWell(
      borderRadius: BorderRadius.circular(17 * k),
      onTap: () => feature.open(context),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(17 * k),
          gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: dark ? const [Color(0xFF151643), Color(0xFF061637)] : const [Color(0xFFF5F3FF), Color(0xFFE4F2FF)]),
          border: Border.all(color: color.withOpacity(dark ? .7 : .55), width: 1.05),
          boxShadow: [BoxShadow(color: color.withOpacity(dark ? .20 : .11), blurRadius: 10 * k)],
        ),
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(
            width: 43 * k,
            height: 43 * k,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12 * k),
              gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color.lerp(color, Colors.white, .22)!, color, Color.lerp(color, Colors.black, .18)!]),
              boxShadow: [BoxShadow(color: color.withOpacity(.34), blurRadius: 9 * k, offset: Offset(0, 3 * k))],
            ),
            child: Icon(feature.icon, size: 25 * k, color: Colors.white),
          ),
          SizedBox(height: 5 * k),
          Padding(
              padding: EdgeInsets.symmetric(horizontal: 3 * k),
              child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(feature.label,
                      maxLines: 1,
                      style: TextStyle(
                          color: dark ? const Color(0xFFF4F5FF) : const Color(0xFF162649),
                          fontSize: 10.7 * k,
                          fontWeight: FontWeight.w600)))),
        ]),
      ),
    );
  }
}

/// Every group of [FeatureCatalog] as a titled grid. Used by the Abtin home screen.
class FeatureSections extends StatelessWidget {
  final double k;
  final bool dark;
  const FeatureSections({super.key, required this.k, required this.dark});

  @override
  Widget build(BuildContext context) {
    final ink = dark ? const Color(0xFFE4E8FA) : const Color(0xFF17264D);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      for (final g in FeatureCatalog.groups()) ...[
        Padding(
            padding: EdgeInsets.only(top: 14 * k, bottom: 8 * k),
            child: Row(children: [
              Container(width: 4 * k, height: 15 * k, decoration: BoxDecoration(color: const Color(0xFF08D5F1), borderRadius: BorderRadius.circular(3))),
              SizedBox(width: 7 * k),
              Expanded(child: Text(g.title, style: TextStyle(color: ink, fontSize: 13.5 * k, fontWeight: FontWeight.w700))),
            ])),
        GridView.builder(
          itemCount: g.features.length,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, crossAxisSpacing: 8 * k, mainAxisSpacing: 7 * k, childAspectRatio: .94),
          itemBuilder: (_, i) => FeatureTile(feature: g.features[i], k: k, dark: dark),
        ),
      ],
    ]);
  }
}
