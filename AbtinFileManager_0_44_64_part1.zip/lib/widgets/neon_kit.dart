import 'package:flutter/material.dart';
import '../core/looks.dart';
import 'adaptive_nav.dart';
import 'mock_icons.dart';
import 'mock_svg.dart';
import 'rail_kit.dart';

// Building blocks of the Neon look (pixel-matched to the supplied mockup):
//   NeonCutCard  – glowing card with two bevelled (cut) corners
//   NeonBackdrop – black background with diagonal glowing light lines
//   NeonRail     – slim side rail with a glowing selected icon

/// Outline of a card with the top-left and bottom-right corners cut by [cut] and
/// the other two corners cut by a smaller amount.
Path neonCutPath(Size s, double cut, {bool uniform = false}) {
  final big = cut;
  final small = uniform ? cut : cut * .4;
  return Path()
    ..moveTo(big, 0)
    ..lineTo(s.width - small, 0)
    ..lineTo(s.width, small)
    ..lineTo(s.width, s.height - big)
    ..lineTo(s.width - big, s.height)
    ..lineTo(small, s.height)
    ..lineTo(0, s.height - small)
    ..lineTo(0, big)
    ..close();
}

class _CutClipper extends CustomClipper<Path> {
  final double cut;
  final bool uniform;
  const _CutClipper(this.cut, this.uniform);
  @override
  Path getClip(Size size) => neonCutPath(size, cut, uniform: uniform);
  @override
  bool shouldReclip(_CutClipper old) => old.cut != cut || old.uniform != uniform;
}

class _NeonCutPainter extends CustomPainter {
  final List<Color> colors;
  final double cut;
  final bool dark;
  final bool uniform;
  final double line;
  _NeonCutPainter(this.colors, this.cut, this.dark, {this.uniform = false, this.line = 1.6});

  @override
  void paint(Canvas canvas, Size size) {
    final path = neonCutPath(size, cut, uniform: uniform);
    final rect = Offset.zero & size;
    final a = colors.first;
    final b = colors.last;
    // fill
    canvas.drawPath(
      path,
      Paint()
        ..shader = LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: dark
              ? [Color.alphaBlend(a.withOpacity(.16), const Color(0xFF070B1A)), Color.alphaBlend(b.withOpacity(.14), const Color(0xFF0B0820))]
              : [Color.alphaBlend(a.withOpacity(.08), Colors.white), Color.alphaBlend(b.withOpacity(.08), Colors.white)],
        ).createShader(rect),
    );
    // soft outer glow
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 5
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 9)
        ..shader = LinearGradient(colors: [a.withOpacity(dark ? .55 : .35), b.withOpacity(dark ? .55 : .35)], begin: Alignment.topLeft, end: Alignment.bottomRight).createShader(rect),
    );
    // crisp gradient outline
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = line
        ..strokeJoin = StrokeJoin.round
        ..shader = LinearGradient(colors: [a, b], begin: Alignment.topLeft, end: Alignment.bottomRight).createShader(rect),
    );
  }

  @override
  bool shouldRepaint(_NeonCutPainter o) => o.cut != cut || o.dark != dark || o.uniform != uniform || o.line != line || o.colors.first != colors.first || o.colors.last != colors.last;
}

/// Glowing card with bevelled corners.
class NeonCutCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double cut;
  final VoidCallback? onTap;

  /// true: all four corners are cut by the same amount (storage card of the mockup).
  final bool uniform;
  final double line;
  const NeonCutCard({super.key, required this.child, this.padding = const EdgeInsets.all(18), this.cut = 26, this.onTap, this.uniform = false, this.line = 1.6});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    return CustomPaint(
      painter: _NeonCutPainter(Looks.accentColors(t.colorScheme), cut, t.brightness == Brightness.dark, uniform: uniform, line: line),
      child: ClipPath(
        clipper: _CutClipper(cut, uniform),
        child: Material(
          type: MaterialType.transparency,
          child: InkWell(onTap: onTap, child: Padding(padding: padding, child: child)),
        ),
      ),
    );
  }
}

class _BackdropPainter extends CustomPainter {
  final Color a, b;
  _BackdropPainter(this.a, this.b);

  void _line(Canvas canvas, Path p, Color c, double w, double glow) {
    canvas.drawPath(p, Paint()..style = PaintingStyle.stroke..strokeWidth = w + 5..color = c.withOpacity(.35)..maskFilter = MaskFilter.blur(BlurStyle.normal, glow));
    canvas.drawPath(p, Paint()..style = PaintingStyle.stroke..strokeWidth = w..strokeJoin = StrokeJoin.round..color = c.withOpacity(.9));
  }

  @override
  void paint(Canvas canvas, Size s) {
    final w = s.width, h = s.height;
    Offset o(double x, double y) => Offset(x / 842 * w, y / 1869 * h);
    Path poly(List<List<double>> pts) {
      final p = Path()..moveTo(o(pts.first[0], pts.first[1]).dx, o(pts.first[0], pts.first[1]).dy);
      for (final q in pts.skip(1)) {
        final t = o(q[0], q[1]);
        p.lineTo(t.dx, t.dy);
      }
      return p;
    }

    // page background exactly as in the mockup: radial-gradient(900px 700px at 20% 30%, #050a18, #010206 60%, #000)
    canvas.save();
    canvas.scale(w / 842, h / 1869);
    canvas.translate(842 * .2, 1869 * .3);
    canvas.scale(1, 700 / 900);
    canvas.drawRect(
      Rect.fromLTRB(-842 * .2, -1869 * .3 * 900 / 700, 842 * .8, 1869 * .7 * 900 / 700),
      Paint()..shader = const RadialGradient(colors: [Color(0xFF050A18), Color(0xFF010206), Color(0xFF000000)], stops: [0, .6, 1]).createShader(Rect.fromCircle(center: Offset.zero, radius: 900)),
    );
    canvas.restore();
    // right-hand outlines next to the rail
    canvas.drawPath(poly([[842, 680], [800, 720], [800, 1100], [742, 1150]]), Paint()..style = PaintingStyle.stroke..strokeWidth = 1.4..color = a.withOpacity(.45));
    // cyan corner bottom-left + long diagonal
    _line(canvas, poly([[0, 1640], [180, 1780], [80, 1800], [0, 1800]]), a, 1.8, 7);
    canvas.drawPath(poly([[0, 1800], [80, 1800], [420, 1450], [842, 1000]]), Paint()..style = PaintingStyle.stroke..strokeWidth = 1.2..color = a.withOpacity(.4));
    // purple bottom lines
    _line(canvas, poly([[330, 1869], [380, 1820], [620, 1820], [842, 1590]]), b, 1.8, 8);
    _line(canvas, poly([[745, 1869], [745, 1560], [770, 1500], [842, 1440]]), b, 1.8, 8);
    // faint floor glow
    final rect = Rect.fromLTWH(0, h * .70, w, h * .30);
    canvas.drawRect(rect, Paint()..shader = LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, b.withOpacity(.10)]).createShader(rect));
  }

  @override
  bool shouldRepaint(_BackdropPainter o) => o.a != a || o.b != b;
}

/// Diagonal glowing lines behind the content (only drawn in dark mode).
class NeonBackdrop extends StatelessWidget {
  final Widget child;
  const NeonBackdrop({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    if (t.brightness != Brightness.dark) return child;
    final c = Looks.accentColors(t.colorScheme);
    return Stack(children: [
      Positioned.fill(child: IgnorePointer(child: RepaintBoundary(child: CustomPaint(painter: _BackdropPainter(c.first, c.last))))),
      child,
    ]);
  }
}

/// Slim rail with the destination icons; the selected one sits in a glowing rounded square.
class NeonRail extends StatelessWidget {
  final int selected; // index inside [items]; -1 = none
  final ValueChanged<int> onSelect;
  final List<NavItem> items;
  final VoidCallback? onStorage; // 3D drive button: opens the storage
  const NeonRail({super.key, required this.selected, required this.onSelect, required this.items, this.onStorage});

  @override
  Widget build(BuildContext context) {
    final t = Theme.of(context);
    final dark = t.brightness == Brightness.dark;
    final sw = MediaQuery.of(context).size.width;
    final k = (sw > 600 ? 600.0 : sw) / 842;
    Widget item(int i) => Padding(
          padding: EdgeInsets.only(bottom: (i == 0 ? 43 : 25) * k),
          child: RailButton(
            neon: true,
            icon: items[i].icon,
            tooltip: items[i].label,
            selected: i == selected,
            onTap: () => onSelect(i),
            width: 86 * k,
            height: 83 * k,
            iconSize: 46 * k,
            radius: 24 * k,
          ),
        );
    return Container(
      width: 100 * k,
      // the mockup's rail has no panel of its own: no fill, border or shadow, just the page background
      color: dark ? const Color(0xFF000000) : t.scaffoldBackgroundColor,
      child: SafeArea(
        child: Column(children: [
          SizedBox(height: 129 * k),
          if (items.isNotEmpty) item(0),
          if (onStorage != null) ...[
            Tooltip(
              message: 'Storage',
              child: InkWell(
                borderRadius: BorderRadius.circular(24 * k),
                onTap: onStorage,
                child: SizedBox(
                  width: 86 * k,
                  height: 88 * k,
                  child: Center(child: MockSvg(mockDrive3d, width: 56 * k, height: 61 * k, glow: const Color(0xFF288CFF).withOpacity(.55), glowBlur: 8 * k)),
                ),
              ),
            ),
            SizedBox(height: 25 * k),
          ],
          for (var i = 1; i < items.length; i++) item(i),
        ]),
      ),
    );
  }
}
