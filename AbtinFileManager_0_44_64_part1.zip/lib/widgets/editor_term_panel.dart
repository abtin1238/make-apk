import 'package:flutter/material.dart';

import '../core/layouts.dart' show tr2;
import '../services/debug_session.dart';
import '../services/run_session.dart';
import '../services/code_runner.dart';
import '../services/term_tab.dart';
import 'debug_widgets.dart';
import 'run_panel.dart';
import 'terminal_tabs_view.dart';

/// VS Code style bottom panel of the text editor: one tab strip holding the
/// "Run" output tab (when code was run) and any number of terminal tabs.
class EditorTermPanel extends StatelessWidget {
  final TermTabs terms;
  final RunSession? run;
  final TextEditingController runArgs;

  /// Debug tab (null = never used in this editor).
  final DebugSession? debug;
  final BreakpointStore? bps;
  final bool debugSelected;
  final bool canDebug;
  final VoidCallback? onSelectDebug;
  final VoidCallback? onCloseDebug;
  final void Function(RunPre pre)? onDebugStart;
  final void Function(String file, int line)? onGoto;
  final void Function(String file, int line)? onEditCondition;

  /// true = the Run tab is shown, false = the selected terminal tab.
  final bool runSelected;
  final bool big;
  final VoidCallback onSelectRun;
  final VoidCallback onCloseRun;
  final void Function(RunPre pre) onRun;
  final VoidCallback onTerminalSelected;
  final VoidCallback onToggleSize;
  final VoidCallback onClose;

  const EditorTermPanel({
    super.key,
    required this.terms,
    required this.run,
    required this.runArgs,
    this.debug,
    this.bps,
    this.debugSelected = false,
    this.canDebug = false,
    this.onSelectDebug,
    this.onCloseDebug,
    this.onDebugStart,
    this.onGoto,
    this.onEditCondition,
    required this.runSelected,
    required this.big,
    required this.onSelectRun,
    required this.onCloseRun,
    required this.onRun,
    required this.onTerminalSelected,
    required this.onToggleSize,
    required this.onClose,
  });

  Widget _act(IconData i, String tip, VoidCallback f) => IconButton(
        tooltip: tip,
        icon: Icon(i, size: 18, color: Colors.white70),
        visualDensity: VisualDensity.compact,
        padding: EdgeInsets.zero,
        constraints: const BoxConstraints(minWidth: 34, minHeight: 36),
        onPressed: f,
      );

  @override
  Widget build(BuildContext context) {
    final r = run;
    final d = debug;
    final showDbg = d != null && debugSelected;
    final showRun = r != null && runSelected && !showDbg;
    return Column(
      children: [
        TermTabStrip(
          tabs: terms,
          terminalSelected: !showRun && !showDbg,
          onSelect: (_) => onTerminalSelected(),
          leading: [
            if (d != null)
              AnimatedBuilder(
                animation: d,
                builder: (context, _) => TermChip(
                  label: tr2('دیباگ', 'Debug'),
                  icon: Icons.bug_report_rounded,
                  selected: showDbg,
                  dot: d.active ? const Color(0xFFE3B341) : null,
                  onTap: onSelectDebug ?? () {},
                  onClose: onCloseDebug,
                ),
              ),
            if (r != null)
              AnimatedBuilder(
                animation: r,
                builder: (context, _) => TermChip(
                  label: tr2('اجرا', 'Run'),
                  icon: Icons.play_arrow_rounded,
                  selected: showRun,
                  dot: r.running ? const Color(0xFF58A6FF) : null,
                  onTap: onSelectRun,
                  onClose: onCloseRun,
                ),
              ),
          ],
          actions: [
            _act(big ? Icons.close_fullscreen_rounded : Icons.open_in_full_rounded, tr2('تغییر اندازه', 'Resize'), onToggleSize),
            _act(Icons.close_rounded, tr2('پنهان‌کردن پنل', 'Hide panel'), onClose),
          ],
        ),
        Expanded(
          child: showDbg
              ? DebugPanel(
                  session: d!,
                  bps: bps!,
                  canDebug: canDebug,
                  onStart: onDebugStart ?? (_) {},
                  onGoto: onGoto ?? (_, __) {},
                  onEditCondition: onEditCondition ?? (_, __) {},
                )
              : showRun
              ? RunPanel(
                  session: r!,
                  args: runArgs,
                  big: big,
                  embedded: true,
                  onRun: onRun,
                  onClose: onClose,
                  onToggleSize: onToggleSize,
                )
              : TermTabBody(tabs: terms, fontSize: 13, compact: true),
        ),
      ],
    );
  }
}
