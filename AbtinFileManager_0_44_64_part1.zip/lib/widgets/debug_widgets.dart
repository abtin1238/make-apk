import 'package:flutter/material.dart';
import 'package:xterm/xterm.dart';

import '../core/layouts.dart' show tr2;
import '../services/code_runner.dart' show RunPre;
import '../services/debug_session.dart';
import 'debug_view.dart';

const TerminalTheme _dbgTheme = TerminalTheme(
  cursor: Color(0xFF39D353),
  selection: Color(0x8039D353),
  foreground: Color(0xFFE6EDF3),
  background: Color(0xFF0B0F14),
  black: Color(0xFF000000),
  red: Color(0xFFCC4444),
  green: Color(0xFF39D353),
  yellow: Color(0xFFE3B341),
  blue: Color(0xFF58A6FF),
  magenta: Color(0xFFD2A8FF),
  cyan: Color(0xFF39C5CF),
  white: Color(0xFFE6EDF3),
  brightBlack: Color(0xFF6E7681),
  brightRed: Color(0xFFFF7B72),
  brightGreen: Color(0xFF56D364),
  brightYellow: Color(0xFFEAC54F),
  brightBlue: Color(0xFF79C0FF),
  brightMagenta: Color(0xFFD2A8FF),
  brightCyan: Color(0xFF56D4DD),
  brightWhite: Color(0xFFFFFFFF),
  searchHitBackground: Color(0xFFFFFF2B),
  searchHitBackgroundCurrent: Color(0xFF31FF26),
  searchHitForeground: Color(0xFF000000),
);

String debugStatusText(DebugSession s) {
  switch (s.state) {
    case DebugState.idle:
      return '';
    case DebugState.starting:
      return tr2('در حال شروع دیباگ…', 'Starting debugger…');
    case DebugState.running:
      return tr2('در حال اجرا…', 'Running…');
    case DebugState.paused:
      switch (s.stopReason) {
        case 'breakpoint':
          return tr2('توقف در بریک‌پوینت', 'Paused on breakpoint');
        case 'exception':
          return s.exceptionText.isEmpty ? tr2('خطا', 'Exception') : s.exceptionText;
        case 'pause':
          return tr2('متوقف شد', 'Paused');
        case 'entry':
          return tr2('توقف در خط اول', 'Paused at start');
        default:
          return tr2('متوقف (گام)', 'Paused (step)');
      }
    case DebugState.ended:
      final t = s.elapsed == null ? '' : ' • ${(s.elapsed!.inMilliseconds / 1000).toStringAsFixed(1)}s';
      if (s.exitCode == null) return tr2('دیباگ متوقف شد', 'Debug stopped') + t;
      if (s.exitCode == 0) return tr2('پایان موفق (کد 0)', 'Finished (exit 0)') + t;
      return tr2('پایان با خطا (کد ${s.exitCode})', 'Failed (exit ${s.exitCode})') + t;
    case DebugState.needAlpine:
    case DebugState.needInstall:
      return tr2('نیاز به نصب', 'Needs install');
    case DebugState.error:
      return tr2('خطا در شروع دیباگ', 'Could not start the debugger');
  }
}

/// Floating VS Code style control bar of a debug session.
class DebugToolbar extends StatelessWidget {
  final DebugSession session;
  final VoidCallback onRestart;
  final VoidCallback onStop;
  const DebugToolbar({super.key, required this.session, required this.onRestart, required this.onStop});

  Widget _b(IconData i, String tip, VoidCallback? f, {Color? color}) => IconButton(
        icon: Icon(i, size: 21, color: f == null ? Colors.white24 : color ?? Colors.white),
        tooltip: tip,
        visualDensity: VisualDensity.compact,
        padding: EdgeInsets.zero,
        constraints: const BoxConstraints(minWidth: 38, minHeight: 36),
        onPressed: f,
      );

  Color _dot(DebugSession s) {
    switch (s.state) {
      case DebugState.running:
      case DebugState.starting:
        return const Color(0xFF58A6FF);
      case DebugState.paused:
        return s.stopReason == 'exception' ? const Color(0xFFFF7B72) : const Color(0xFFE3B341);
      case DebugState.ended:
        return s.exitCode == 0 ? const Color(0xFF39D353) : const Color(0xFF8B949E);
      default:
        return Colors.orangeAccent;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: AnimatedBuilder(
        animation: session,
        builder: (context, _) {
          final s = session;
          final paused = s.paused;
          final running = s.state == DebugState.running;
          return Container(
            color: const Color(0xFF161B22),
            padding: const EdgeInsets.symmetric(horizontal: 6),
            height: 40,
            child: Row(
              children: [
                Icon(Icons.circle, size: 10, color: _dot(s)),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    debugStatusText(s),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: s.stopReason == 'exception' && paused ? const Color(0xFFFF7B72) : const Color(0xFFB1BAC4), fontSize: 12),
                  ),
                ),
                if (running)
                  _b(Icons.pause_rounded, tr2('توقف موقت', 'Pause'), s.pause, color: const Color(0xFFE3B341))
                else
                  _b(Icons.play_arrow_rounded, tr2('ادامه', 'Continue'), paused ? () => s.resume('continue') : null, color: const Color(0xFF39D353)),
                _b(Icons.redo_rounded, tr2('گام بعدی (Step over)', 'Step over'), paused ? () => s.resume('next') : null),
                _b(Icons.south_rounded, tr2('ورود به تابع (Step into)', 'Step into'), paused ? () => s.resume('step') : null),
                _b(Icons.north_rounded, tr2('خروج از تابع (Step out)', 'Step out'), paused ? () => s.resume('out') : null),
                _b(Icons.restart_alt_rounded, tr2('شروع دوباره', 'Restart'), onRestart, color: const Color(0xFF58A6FF)),
                _b(Icons.stop_rounded, tr2('توقف دیباگ', 'Stop'), s.active ? onStop : null, color: Colors.redAccent),
              ],
            ),
          );
        },
      ),
    );
  }
}

/// Body of the editor's "Debug" bottom tab: program output + expression console,
/// and a second sub-tab with variables / watch / call stack.
class DebugPanel extends StatefulWidget {
  final DebugSession session;
  final BreakpointStore bps;
  final bool canDebug;
  final void Function(RunPre pre) onStart;
  final void Function(String file, int line) onGoto;
  final void Function(String file, int line) onEditCondition;
  const DebugPanel({
    super.key,
    required this.session,
    required this.bps,
    required this.canDebug,
    required this.onStart,
    required this.onGoto,
    required this.onEditCondition,
  });

  @override
  State<DebugPanel> createState() => _DebugPanelState();
}

class _DebugPanelState extends State<DebugPanel> {
  final TextEditingController _input = TextEditingController();
  final FocusNode _focus = FocusNode();
  int _sub = 0;
  int _prompted = -1;

  @override
  void initState() {
    super.initState();
    widget.session.addListener(_onSession);
  }

  @override
  void didUpdateWidget(DebugPanel old) {
    super.didUpdateWidget(old);
    if (old.session != widget.session) {
      old.session.removeListener(_onSession);
      widget.session.addListener(_onSession);
    }
  }

  @override
  void dispose() {
    widget.session.removeListener(_onSession);
    _input.dispose();
    _focus.dispose();
    super.dispose();
  }

  void _onSession() {
    final s = widget.session;
    if (s.runId != _prompted && (s.state == DebugState.needAlpine || s.state == DebugState.needInstall)) {
      _prompted = s.runId;
      WidgetsBinding.instance.addPostFrameCallback((_) => _ask());
    }
  }

  Future<void> _ask() async {
    if (!mounted) return;
    final s = widget.session;
    final alpine = s.state == DebugState.needAlpine;
    final js = s.lang == 'js';
    final body = js
        ? (alpine
            ? tr2('برای دیباگ JavaScript محیط Termux (همراه برنامه، بدون دانلود) و سپس بستهٔ Node.js (دانلود حدود ۵۰ مگابایت، نیاز به اینترنت) نصب می‌شود. ادامه؟',
                'JavaScript debugging needs the Termux environment (bundled) and then Node.js (about 50 MB download, internet needed). Continue?')
            : tr2('برای دیباگ JavaScript باید «${s.needPkgs}» در Termux نصب شود (حدود ۵۰ مگابایت). نصب شود؟',
                'JavaScript debugging needs "${s.needPkgs}" in Termux (about 50 MB). Install it?'))
        : alpine
            ? tr2('برای دیباگ، محیط لینوکس Alpine (همراه با Python) باید نصب شود. حدود ۱۵۰ تا ۲۰۰ مگابایت دانلود می‌شود و به اینترنت نیاز دارد. نصب شود؟',
                'Debugging needs the Alpine Linux environment (with Python). It downloads about 150-200 MB and needs internet. Install it?')
            : tr2('برای دیباگ Python باید بسته‌های «${s.needPkgs}» نصب شوند (حدود ۴۰ مگابایت). نصب شود؟',
                'Debugging Python needs the packages "${s.needPkgs}" (about 40 MB). Install them?');
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(tr2('نصب ابزار دیباگ', 'Install debug tools')),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(tr2('انصراف', 'Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(tr2('نصب و دیباگ', 'Install & debug'))),
        ],
      ),
    );
    if (ok == true && mounted) widget.onStart(alpine ? RunPre.bootstrap : RunPre.install);
  }

  void _submit() {
    final t = _input.text;
    final s = widget.session;
    if (s.paused) {
      s.evaluate(t);
    } else if (s.state == DebugState.running) {
      s.sendStdin(t);
    } else {
      return;
    }
    _input.clear();
    _focus.requestFocus();
  }

  Widget _chip(String label, int i) {
    final sel = _sub == i;
    return InkWell(
      onTap: () => setState(() => _sub = i),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: sel ? const Color(0xFF58A6FF) : Colors.transparent, width: 2)),
        ),
        child: Text(label, style: TextStyle(fontSize: 12, color: sel ? Colors.white : const Color(0xFF8B949E), fontWeight: sel ? FontWeight.w600 : null)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.session;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Material(
        color: _dbgTheme.background,
        child: Column(
          children: [
            Container(
              height: 32,
              color: const Color(0xFF161B22),
              child: Row(children: [_chip(tr2('کنسول', 'Console'), 0), _chip(tr2('متغیرها و پشته', 'Variables & stack'), 1)]),
            ),
            Expanded(
              child: _sub == 1
                  ? Material(
                      color: Theme.of(context).colorScheme.surface,
                      child: DebugView(
                        session: s,
                        bps: widget.bps,
                        canDebug: widget.canDebug,
                        compact: true,
                        onStart: () => widget.onStart(RunPre.none),
                        onGoto: widget.onGoto,
                        onEditCondition: widget.onEditCondition,
                      ),
                    )
                  : Column(
                      children: [
                        Expanded(
                          child: TerminalView(
                            s.terminal,
                            theme: _dbgTheme,
                            textStyle: const TerminalStyle(fontSize: 13, height: 1.2),
                            readOnly: true,
                            autoResize: true,
                            padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
                          ),
                        ),
                        AnimatedBuilder(
                          animation: s,
                          builder: (context, _) {
                            final canType = s.paused || s.state == DebugState.running;
                            return Container(
                              height: 44,
                              color: const Color(0xFF161B22),
                              padding: const EdgeInsets.symmetric(horizontal: 8),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: TextField(
                                      controller: _input,
                                      focusNode: _focus,
                                      enabled: canType,
                                      textInputAction: TextInputAction.send,
                                      onSubmitted: (_) => _submit(),
                                      style: const TextStyle(fontFamily: 'monospace', fontSize: 13, color: Color(0xFFE6EDF3)),
                                      decoration: InputDecoration(
                                        isDense: true,
                                        hintText: s.paused
                                            ? tr2('عبارت پایتون را اجرا کنید…', 'evaluate a Python expression…')
                                            : tr2('ورودی برنامه (stdin) …', 'stdin …'),
                                        hintStyle: const TextStyle(fontSize: 13, color: Color(0xFF6E7681)),
                                        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                                        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFF30363D))),
                                        disabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFF21262D))),
                                        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFF58A6FF))),
                                      ),
                                    ),
                                  ),
                                  IconButton(
                                    icon: const Icon(Icons.send_rounded, size: 20),
                                    tooltip: tr2('ارسال', 'Send'),
                                    visualDensity: VisualDensity.compact,
                                    onPressed: canType ? _submit : null,
                                  ),
                                ],
                              ),
                            );
                          },
                        ),
                      ],
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
