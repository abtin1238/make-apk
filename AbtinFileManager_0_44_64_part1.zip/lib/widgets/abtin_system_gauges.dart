import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import '../core/l10n.dart';
import '../services/native.dart';
import 'rail_kit.dart';

String _tr(String fa, String en) => L.lang == 'fa' ? fa : en;

/// Three small round gauges (temperature, CPU, RAM) shown under the Abtin Pulse side rail.
/// Only the home page asks for them (see [AbtinRailLane.extra]); values refresh every 2 s.
class AbtinSystemGauges extends StatefulWidget {
  const AbtinSystemGauges({super.key});
  @override
  State<AbtinSystemGauges> createState() => _AbtinSystemGaugesState();
}

class _AbtinSystemGaugesState extends State<AbtinSystemGauges> {
  Timer? _t;
  double? _temp; // °C
  double? _cpu; // 0..1
  double? _ram; // 0..1
  int? _lastTotal, _lastIdle;

  @override
  void initState() {
    super.initState();
    _tick();
    Future<void>.delayed(const Duration(milliseconds: 700), _tick);
    _t = Timer.periodic(const Duration(seconds: 2), (_) => _tick());
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _tick() async {
    final cpu = _readCpu();
    final ram = _readRam();
    final temp = await _readTemp();
    if (!mounted) return;
    setState(() {
      _cpu = cpu ?? _cpu;
      _ram = ram ?? _ram;
      _temp = temp ?? _temp;
    });
  }

  double? _readRam() {
    int total = 0, avail = 0;
    try {
      for (final l in File('/proc/meminfo').readAsLinesSync()) {
        final m = RegExp(r'^(MemTotal|MemAvailable):\s+(\d+)').firstMatch(l);
        if (m == null) continue;
        if (m.group(1) == 'MemTotal') total = int.parse(m.group(2)!);
        if (m.group(1) == 'MemAvailable') avail = int.parse(m.group(2)!);
      }
    } catch (_) {}
    if (total <= 0) return null;
    return ((total - avail) / total).clamp(0.0, 1.0).toDouble();
  }

  /// CPU load from /proc/stat deltas. Newer Android versions hide that file from apps, so when it
  /// can't be read the average core clock (current / max frequency) is shown instead.
  double? _readCpu() {
    try {
      final line = File('/proc/stat').readAsLinesSync().first;
      final v = line.trim().split(RegExp(r'\s+')).skip(1).take(8).map(int.parse).toList();
      final total = v.fold<int>(0, (a, b) => a + b);
      final idle = v[3] + v[4];
      final lt = _lastTotal, li = _lastIdle;
      _lastTotal = total;
      _lastIdle = idle;
      if (lt != null && li != null && total > lt) {
        return (1 - (idle - li) / (total - lt)).clamp(0.0, 1.0).toDouble();
      }
      if (lt != null) return null;
    } catch (_) {}
    try {
      var sum = 0.0;
      var n = 0;
      for (var i = 0; i < 16; i++) {
        final base = '/sys/devices/system/cpu/cpu$i/cpufreq';
        final cur = File('$base/scaling_cur_freq');
        final max = File('$base/cpuinfo_max_freq');
        if (!cur.existsSync() || !max.existsSync()) continue;
        final c = double.parse(cur.readAsStringSync().trim());
        final m = double.parse(max.readAsStringSync().trim());
        if (m > 0) {
          sum += c / m;
          n++;
        }
      }
      if (n > 0) return (sum / n).clamp(0.0, 1.0).toDouble();
    } catch (_) {}
    return null;
  }

  Future<double?> _readTemp() async {
    final t = await Native.batteryTemp();
    if (t != null) return t;
    try {
      final raw = double.parse(File('/sys/class/power_supply/battery/temp').readAsStringSync().trim());
      return raw > 150 ? raw / 10 : raw;
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final temp = _temp;
    final tempColor = temp == null
        ? const Color(0xFF8FA3D8)
        : temp < 38
            ? const Color(0xFF22D3EE)
            : temp < 43
                ? const Color(0xFFFFA62B)
                : const Color(0xFFFF4D4D);
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        _Gauge(
            value: temp == null ? 0 : (temp / 60).clamp(0.0, 1.0).toDouble(),
            center: temp == null ? '–' : '${temp.round()}°',
            label: _tr('دما', 'TEMP'),
            color: tempColor),
        const SizedBox(height: 8),
        _Gauge(
            value: _cpu ?? 0,
            center: _cpu == null ? '–' : '${(_cpu! * 100).round()}%',
            label: 'CPU',
            color: const Color(0xFFB25BFF)),
        const SizedBox(height: 8),
        _Gauge(
            value: _ram ?? 0,
            center: _ram == null ? '–' : '${(_ram! * 100).round()}%',
            label: 'RAM',
            color: const Color(0xFFFF9A2E)),
      ]),
    );
  }
}

class _Gauge extends StatelessWidget {
  final double value;
  final String center, label;
  final Color color;
  const _Gauge({required this.value, required this.center, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    final p = RailPalette.of(context);
    final dark = Theme.of(context).brightness == Brightness.dark;
    final ink = dark ? const Color(0xFFF2F5FF) : const Color(0xFF172447);
    return Container(
      width: 52,
      height: 52,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [p.panelTop, p.panelBottom]),
        border: Border.all(color: p.panelBorder, width: 1.1),
        boxShadow: [BoxShadow(color: p.panelGlow, blurRadius: 12)],
      ),
      child: CustomPaint(
        painter: _RingPainter(value, color, dark),
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(center, style: TextStyle(color: ink, fontSize: 12, fontWeight: FontWeight.w700, height: 1.05)),
            Text(label, style: TextStyle(color: ink.withOpacity(.7), fontSize: 8, fontWeight: FontWeight.w600, height: 1.1)),
          ]),
        ),
      ),
    );
  }
}

class _RingPainter extends CustomPainter {
  final double value;
  final Color color;
  final bool dark;
  const _RingPainter(this.value, this.color, this.dark);

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromCircle(center: size.center(Offset.zero), radius: size.width / 2 - 4.5);
    canvas.drawArc(
        rect,
        0,
        math.pi * 2,
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3.4
          ..color = (dark ? const Color(0xFF233B88) : const Color(0xFFB9C7F2)).withOpacity(dark ? .9 : .7));
    if (value <= 0) return;
    canvas.drawArc(
        rect,
        -math.pi / 2,
        math.pi * 2 * value.clamp(0.02, 1.0),
        false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3.4
          ..strokeCap = StrokeCap.round
          ..color = color);
  }

  @override
  bool shouldRepaint(covariant _RingPainter o) => o.value != value || o.color != color || o.dark != dark;
}
