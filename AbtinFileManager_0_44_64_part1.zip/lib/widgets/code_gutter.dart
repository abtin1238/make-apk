import 'dart:math' as math;

import 'package:flutter/material.dart';

/// One pass over the text: number of lines, longest line (in columns) and whether it
/// holds non-ASCII characters (their width in a monospace font is not exact).
class CodeMetrics {
  final int lines;
  final int maxCols;
  final bool wide;
  const CodeMetrics(this.lines, this.maxCols, this.wide);

  static CodeMetrics scan(String t) {
    var lines = 1, col = 0, max = 0;
    var wide = false;
    for (var i = 0; i < t.length; i++) {
      final c = t.codeUnitAt(i);
      if (c == 10) {
        lines++;
        if (col > max) max = col;
        col = 0;
      } else {
        col += c == 9 ? 4 : 1;
        if (c > 127) wide = true;
      }
    }
    if (col > max) max = col;
    return CodeMetrics(lines, max, wide);
  }
}

double _scrollOffset(ScrollController c) {
  if (!c.hasClients || c.positions.length != 1) return 0;
  return c.offset;
}

/// Line numbers, breakpoint dots and the "execution arrow" next to the editor.
/// Only the visible lines are painted; it follows the text field's vertical scroll.
class GutterPainter extends CustomPainter {
  final ScrollController scroll;
  final int lines;
  final double lineHeight;
  final double fontSize;
  final Map<int, String?> breakpoints;
  final Set<int> unverified;
  final int? current;
  final Color numberColor;
  final Color currentColor;

  GutterPainter({
    required this.scroll,
    required this.lines,
    required this.lineHeight,
    required this.fontSize,
    required this.breakpoints,
    required this.unverified,
    required this.current,
    required this.numberColor,
    required this.currentColor,
  }) : super(repaint: scroll);

  @override
  void paint(Canvas canvas, Size size) {
    canvas.clipRect(Offset.zero & size);
    final off = _scrollOffset(scroll);
    final first = math.max(0, (off / lineHeight).floor());
    final last = math.min(lines, ((off + size.height) / lineHeight).ceil() + 1);
    final numStyle = TextStyle(fontFamily: 'monospace', fontSize: fontSize * 0.85, color: numberColor);
    final curStyle = TextStyle(fontFamily: 'monospace', fontSize: fontSize * 0.85, color: currentColor, fontWeight: FontWeight.bold);
    for (var i = first; i < last; i++) {
      final line = i + 1;
      final y = i * lineHeight - off;
      final isCur = current == line;
      final tp = TextPainter(
        text: TextSpan(text: '$line', style: isCur ? curStyle : numStyle),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset(size.width - 8 - tp.width, y + (lineHeight - tp.height) / 2));
      tp.dispose();
      final cy = y + lineHeight / 2;
      if (breakpoints.containsKey(line)) {
        final bad = unverified.contains(line);
        final cond = breakpoints[line] != null;
        final fill = Paint()
          ..color = bad ? const Color(0xFF8B949E) : (cond ? const Color(0xFFE3B341) : const Color(0xFFE5534B))
          ..style = bad ? PaintingStyle.stroke : PaintingStyle.fill
          ..strokeWidth = 1.6;
        canvas.drawCircle(Offset(10, cy), 5.2, fill);
      }
      if (isCur) {
        final path = Path()
          ..moveTo(4, cy - 5.5)
          ..lineTo(15, cy)
          ..lineTo(4, cy + 5.5)
          ..close();
        canvas.drawPath(path, Paint()..color = currentColor);
      }
    }
  }

  @override
  bool shouldRepaint(GutterPainter old) => true;
}

/// Coloured band behind the line where the program is stopped.
class LineBandPainter extends CustomPainter {
  final ScrollController scroll;
  final double lineHeight;
  final int? line;
  final Color color;

  LineBandPainter({required this.scroll, required this.lineHeight, required this.line, required this.color})
      : super(repaint: scroll);

  @override
  void paint(Canvas canvas, Size size) {
    final l = line;
    if (l == null) return;
    final y = (l - 1) * lineHeight - _scrollOffset(scroll);
    if (y + lineHeight < 0 || y > size.height) return;
    canvas.drawRect(Rect.fromLTWH(0, y, size.width, lineHeight), Paint()..color = color);
  }

  @override
  bool shouldRepaint(LineBandPainter old) => old.line != line || old.color != color || old.lineHeight != lineHeight;
}
