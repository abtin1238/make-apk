import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:xterm/xterm.dart';

import '../core/layouts.dart' show tr2;
import '../services/term_tab.dart';

/// Shared colours / terminal theme (GitHub-dark like the rest of the app terminal).
class TermStyle {
  static const bg = Color(0xFF080808);
  static const bar = Color(0xFF161B22);
  static const border = Color(0xFF30363D);
  static const accent = Color(0xFF39D353);
  static const dim = Color(0xFF8B949E);

  static const theme = TerminalTheme(
    cursor: Color(0xFF39D353),
    selection: Color(0x8039D353),
    foreground: Color(0xFFE6EDF3),
    background: Color(0xFF080808),
    black: Color(0xFF000000),
    red: Color(0xFFCC4444),
    green: Color(0xFF39D353),
    yellow: Color(0xFFE3B341),
    blue: Color(0xFF58A6FF),
    magenta: Color(0xFFD2A8FF),
    cyan: Color(0xFF39C5CF),
    white: Color(0xFFE6EDF3),
    brightBlack: Color(0xFF6E7681),
    brightRed: Color(0xFFFF7B72),
    brightGreen: Color(0xFF56D364),
    brightYellow: Color(0xFFEAC54F),
    brightBlue: Color(0xFF79C0FF),
    brightMagenta: Color(0xFFD2A8FF),
    brightCyan: Color(0xFF56D4DD),
    brightWhite: Color(0xFFFFFFFF),
    searchHitBackground: Color(0xFFFFFF2B),
    searchHitBackgroundCurrent: Color(0xFF31FF26),
    searchHitForeground: Color(0xFF000000),
  );
}

/// One chip of the tab strip (also used by the editor for its "Run" tab).
class TermChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final Color? dot;
  final VoidCallback onTap;
  final VoidCallback? onClose;
  final VoidCallback? onLongPress;
  const TermChip({
    super.key,
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
    this.dot,
    this.onClose,
    this.onLongPress,
  });

  @override
  Widget build(BuildContext context) {
    final fg = selected ? Colors.white : TermStyle.dim;
    return InkWell(
      onTap: onTap,
      onLongPress: onLongPress,
      child: Container(
        constraints: const BoxConstraints(minWidth: 70, maxWidth: 170),
        padding: const EdgeInsets.only(left: 10, right: 4),
        decoration: BoxDecoration(
          color: selected ? TermStyle.bg : Colors.transparent,
          border: Border(
            top: BorderSide(color: selected ? TermStyle.accent : Colors.transparent, width: 2),
            right: const BorderSide(color: TermStyle.border, width: .5),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 14, color: fg),
            const SizedBox(width: 6),
            if (dot != null) ...[
              Icon(Icons.circle, size: 7, color: dot),
              const SizedBox(width: 5),
            ],
            Flexible(
              child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 12.5, color: fg)),
            ),
            if (onClose != null)
              InkWell(
                onTap: onClose,
                borderRadius: BorderRadius.circular(10),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(Icons.close_rounded, size: 14, color: fg),
                ),
              )
            else
              const SizedBox(width: 8),
          ],
        ),
      ),
    );
  }
}

/// VS Code style tab strip: [leading chips] [terminal tabs] [+ ⌄]   [actions].
class TermTabStrip extends StatelessWidget {
  final TermTabs tabs;

  /// false while a non-terminal tab (the editor's Run tab) is the selected one.
  final bool terminalSelected;

  /// Called when a terminal tab is chosen (the owner may switch away from its own tab).
  final ValueChanged<int>? onSelect;

  /// Extra chips before the terminal tabs (the editor's Run tab).
  final List<Widget> leading;

  /// Buttons at the right end (maximise / close).
  final List<Widget> actions;

  const TermTabStrip({
    super.key,
    required this.tabs,
    this.terminalSelected = true,
    this.onSelect,
    this.leading = const [],
    this.actions = const [],
  });

  Future<void> _rename(BuildContext context, TermTab t) async {
    final c = TextEditingController(text: t.customTitle ?? '');
    final v = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(tr2('نام تب', 'Tab name')),
        content: TextField(
          controller: c,
          autofocus: true,
          textDirection: TextDirection.ltr,
          decoration: InputDecoration(hintText: t.title),
          onSubmitted: (s) => Navigator.pop(ctx, s),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text(tr2('انصراف', 'Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text), child: Text(tr2('تأیید', 'OK'))),
        ],
      ),
    );
    c.dispose();
    if (v != null) t.rename(v);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Material(
        color: TermStyle.bar,
        child: AnimatedBuilder(
          animation: tabs,
          builder: (context, _) {
            return Container(
              height: 36,
              decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: TermStyle.border, width: .5))),
              child: Row(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: Row(
                        children: [
                          ...leading,
                          for (var i = 0; i < tabs.tabs.length; i++)
                            TermChip(
                              label: tabs.tabs[i].title,
                              icon: Icons.terminal_rounded,
                              selected: terminalSelected && i == tabs.active,
                              dot: tabs.tabs[i].ended ? Colors.orangeAccent : null,
                              onTap: () {
                                tabs.select(i);
                                onSelect?.call(i);
                              },
                              onLongPress: () => _rename(context, tabs.tabs[i]),
                              onClose: () => tabs.close(i),
                            ),
                          IconButton(
                            tooltip: tr2('ترمینال جدید', 'New terminal'),
                            icon: const Icon(Icons.add_rounded, size: 20, color: Colors.white70),
                            visualDensity: VisualDensity.compact,
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                            onPressed: () {
                              tabs.add();
                              onSelect?.call(tabs.active);
                            },
                          ),
                          // VS Code style: arrow next to "+" = pick the profile of the new terminal / choose the default.
                          Builder(
                            builder: (ctx) => PopupMenuButton<String>(
                              tooltip: tr2('پروفایل ترمینال', 'Terminal profiles'),
                              icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 20, color: Colors.white70),
                              padding: EdgeInsets.zero,
                              constraints: const BoxConstraints(minWidth: 28, minHeight: 36),
                              onSelected: (v) {
                                if (v == 'default') {
                                  _pickDefault(ctx);
                                } else {
                                  tabs.add(profile: v);
                                  onSelect?.call(tabs.active);
                                }
                              },
                              itemBuilder: (_) => [
                                for (final pr in TermProfiles.all)
                                  PopupMenuItem(
                                    value: pr.id,
                                    child: Row(children: [
                                      const Icon(Icons.terminal_rounded, size: 18),
                                      const SizedBox(width: 8),
                                      Expanded(child: Text(pr.title)),
                                      if (pr.id == TermProfiles.current) const Icon(Icons.check_rounded, size: 18),
                                    ]),
                                  ),
                                const PopupMenuDivider(),
                                PopupMenuItem(value: 'default', child: Text(tr2('انتخاب پروفایل پیش‌فرض…', 'Select Default Profile…'))),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  PopupMenuButton<int>(
                    tooltip: tr2('گزینه‌های ترمینال', 'Terminal options'),
                    icon: const Icon(Icons.more_vert_rounded, size: 18, color: Colors.white70),
                    padding: EdgeInsets.zero,
                    onSelected: (v) {
                      final t = tabs.current;
                      if (v == 0) {
                        tabs.add();
                        onSelect?.call(tabs.active);
                      } else if (v == 1 && t != null) {
                        _rename(context, t);
                      } else if (v == 2 && t != null) {
                        t.clearScreen();
                      } else if (v == 3) {
                        tabs.closeAll();
                      } else if (v == 4) {
                        _pickDefault(context);
                      }
                    },
                    itemBuilder: (_) => [
                      PopupMenuItem(value: 0, child: Text(tr2('ترمینال جدید', 'New terminal'))),
                      PopupMenuItem(value: 1, child: Text(tr2('تغییر نام تب', 'Rename tab'))),
                      PopupMenuItem(value: 2, child: Text(tr2('پاک‌کردن صفحه', 'Clear screen'))),
                      PopupMenuItem(value: 3, child: Text(tr2('بستن همهٔ ترمینال‌ها', 'Close all terminals'))),
                      PopupMenuItem(value: 4, child: Text(tr2('انتخاب پروفایل پیش‌فرض…', 'Select Default Profile…'))),
                    ],
                  ),
                  ...actions,
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}

/// "Select Default Profile" dialog (like VS Code). Applies to every new terminal.
Future<void> _pickDefault(BuildContext context) async {
  await TermProfiles.load();
  if (!context.mounted) return;
  await showDialog<void>(
    context: context,
    builder: (dc) => SimpleDialog(
      backgroundColor: TermStyle.bar,
      title: Text(tr2('پروفایل پیش‌فرض ترمینال', 'Default terminal profile'), style: const TextStyle(color: Colors.white, fontSize: 16)),
      children: [
        for (final pr in TermProfiles.all)
          SimpleDialogOption(
            onPressed: () async {
              await TermProfiles.setDefault(pr.id);
              if (dc.mounted) Navigator.pop(dc);
            },
            child: Row(children: [
              Icon(pr.id == TermProfiles.current ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded,
                  size: 20, color: TermStyle.accent),
              const SizedBox(width: 10),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(pr.title, style: const TextStyle(color: Colors.white)),
                  Text(pr.desc, style: const TextStyle(color: TermStyle.dim, fontSize: 12)),
                ]),
              ),
            ]),
          ),
      ],
    ),
  );
}

/// Help text for the app terminal (Termux is the default shell).
Future<void> showTermHelp(BuildContext context) {
  return showDialog<void>(
    context: context,
    builder: (context) => AlertDialog(
      title: Text(tr2('ترمینال', 'Terminal')),
      content: SingleChildScrollView(
        child: Text(tr2(
          'این ترمینال از PTY واقعی Android استفاده می‌کند و برنامه‌های تعاملی و ANSI را اجرا می‌کند.\n\n'
              'تب‌ها: با «+» تب جدید باز کن، روی تب بزن تا عوض شود، ضربدر تب را می‌بندد و نگه‌داشتن روی تب نامش را عوض می‌کند. هر تب یک نشست مستقل دارد.\n\n'
              'ترموکس پیش‌فرض است: هر تب جدید خودش وارد Termux (bash، pkg، apt) می‌شود. اگر Termux هنوز نصب نیست، همراه خود برنامه نصب می‌شود (بدون دانلود). با exit از Termux به شل اندروید برمی‌گردی. اگر ترجیح می‌دهی به‌جای Termux وارد Alpine شود: autoshell alpine. برای خاموش‌کردن ورود خودکار: autobash off (و autobash on برای روشن‌کردن).\n\n'
              'دستورهای دستی: termux (ورود)، termux pkg install <بسته>، bash (Alpine)، alpine bootstrap. حافظهٔ داخلی در /sdcard در دسترس است.\n\n'
              'محدودیت‌های sandbox اندروید برقرار است و این محیط root واقعی اندروید نیست.',
          'This terminal uses a real Android PTY and runs interactive / ANSI programs.\n\n'
              'Tabs: "+" opens a new tab, tap a tab to switch, the × closes it and a long-press renames it. Every tab is an independent session.\n\n'
              'Termux is the default: every new tab enters Termux (bash, pkg, apt) by itself. If Termux is not installed yet it is installed from the copy bundled in the app (no download). exit leaves Termux and returns to the Android shell. To enter Alpine instead of Termux: autoshell alpine. To turn auto-entering off: autobash off (autobash on turns it back on).\n\n'
              'Manual commands: termux (enter), termux pkg install <package>, bash (Alpine), alpine bootstrap. Shared storage is available at /sdcard.\n\n'
              'Android sandbox limits apply; this is not real root.',
        )),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: Text(tr2('بستن', 'Close')))],
    ),
  );
}

/// Body of the terminal: slim toolbar, the stacked terminal views and the extra keys row.
class TermTabBody extends StatelessWidget {
  final TermTabs tabs;
  final double fontSize;
  final bool compact;
  const TermTabBody({super.key, required this.tabs, this.fontSize = 14, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Material(
        color: TermStyle.bg,
        child: AnimatedBuilder(
          animation: tabs,
          builder: (context, _) {
            final cur = tabs.current;
            if (cur == null) return const SizedBox.shrink();
            return Column(
              children: [
                _Toolbar(tab: cur, compact: compact),
                Expanded(
                  child: IndexedStack(
                    sizing: StackFit.expand,
                    index: tabs.active.clamp(0, tabs.tabs.length - 1),
                    children: [
                      for (final t in tabs.tabs)
                        Container(
                          key: ObjectKey(t),
                          color: TermStyle.bg,
                          alignment: Alignment.topLeft,
                          child: TerminalView(
                            t.terminal,
                            controller: t.controller,
                            focusNode: t.focus,
                            theme: TermStyle.theme,
                            textStyle: TerminalStyle(fontSize: fontSize, height: 1.25),
                            autofocus: t == cur,
                            autoResize: true,
                            deleteDetection: true,
                            padding: const EdgeInsets.fromLTRB(10, 6, 10, 4),
                            keyboardAppearance: Brightness.dark,
                          ),
                        ),
                    ],
                  ),
                ),
                _ExtraKeys(tab: cur),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _Toolbar extends StatelessWidget {
  final TermTab tab;
  final bool compact;
  const _Toolbar({required this.tab, required this.compact});

  void _snack(BuildContext c, String m) {
    ScaffoldMessenger.maybeOf(c)
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(m), duration: const Duration(seconds: 2)));
  }

  Future<void> _copy(BuildContext context, {bool all = false}) async {
    final sel = tab.controller.selection;
    String text;
    if (sel != null && !all) {
      text = tab.terminal.buffer.getText(sel);
    } else if (all) {
      text = tab.terminal.buffer.getText();
    } else {
      _snack(context, tr2('ابتدا متن را انتخاب کنید (نگه‌داشتن روی متن یا دکمهٔ «انتخاب همه»)', 'Select text first (long-press the text or use Select all)'));
      return;
    }
    text = text.replaceAll(RegExp(r'[ \t]+\n'), '\n').trimRight();
    if (text.isEmpty) {
      _snack(context, tr2('متنی برای کپی نیست', 'Nothing to copy'));
      return;
    }
    await Clipboard.setData(ClipboardData(text: text));
    tab.controller.clearSelection();
    if (context.mounted) _snack(context, tr2('کپی شد', 'Copied'));
  }

  Future<void> _paste(BuildContext context) async {
    final d = await Clipboard.getData(Clipboard.kTextPlain);
    final t = d?.text;
    if (t == null || t.isEmpty) {
      if (context.mounted) _snack(context, tr2('کلیپ‌بورد خالی است', 'Clipboard is empty'));
      return;
    }
    tab.terminal.paste(t);
  }

  void _selectAll() {
    final b = tab.terminal.buffer;
    tab.controller.setSelection(
      b.createAnchor(0, 0),
      b.createAnchor(tab.terminal.viewWidth, b.height - 1),
    );
  }

  Future<void> _history(BuildContext context) async {
    if (tab.history.isEmpty) {
      _snack(context, tr2('تاریخچهٔ فرمان‌ها خالی است', 'Command history is empty'));
      return;
    }
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            ListTile(title: Text(tr2('تاریخچهٔ فرمان‌ها', 'Command history'))),
            for (final command in tab.history.reversed)
              ListTile(
                dense: true,
                title: Text(command, textDirection: TextDirection.ltr, maxLines: 2, overflow: TextOverflow.ellipsis),
                onTap: () => Navigator.pop(context, command),
              ),
          ],
        ),
      ),
    );
    if (selected != null) tab.terminal.textInput(selected);
  }

  Widget _ic(IconData i, String tip, VoidCallback? f, {Color? color}) => IconButton(
        tooltip: tip,
        visualDensity: VisualDensity.compact,
        padding: EdgeInsets.zero,
        constraints: const BoxConstraints(minWidth: 34, minHeight: 32),
        onPressed: f,
        icon: Icon(i, size: 19, color: color),
      );

  @override
  Widget build(BuildContext context) {
    final run = tab.running;
    return Container(
      height: 32,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      child: Row(
        children: [
          Icon(Icons.circle, size: 9, color: run ? TermStyle.accent : Colors.orangeAccent),
          const SizedBox(width: 7),
          Expanded(
            child: Text(
              '${tab.status.toLowerCase()}  •  ${tab.sessionCwd.isEmpty ? tab.cwd : tab.sessionCwd}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 10.5, color: TermStyle.dim, fontFamily: 'monospace'),
            ),
          ),
          if (run)
            _ic(Icons.stop_rounded, tr2('توقف نشست', 'Stop session'), tab.stop, color: Colors.redAccent)
          else
            _ic(Icons.play_arrow_rounded, tr2('شروع نشست', 'Start session'), tab.starting ? null : tab.start),
          _ic(Icons.history_rounded, tr2('تاریخچه', 'History'), () => _history(context)),
          GestureDetector(
            onLongPress: () => _copy(context, all: true),
            child: _ic(Icons.copy_rounded, tr2('کپی (نگه‌داشتن = کپی کل خروجی)', 'Copy (long-press = copy all output)'), () => _copy(context)),
          ),
          _ic(Icons.content_paste_rounded, tr2('چسباندن', 'Paste'), () => _paste(context)),
          _ic(Icons.select_all_rounded, tr2('انتخاب همه', 'Select all'), _selectAll),
          _ic(Icons.delete_sweep_outlined, tr2('پاک‌کردن صفحه', 'Clear screen'), tab.clearScreen),
          if (!compact) _ic(Icons.info_outline_rounded, tr2('راهنما', 'Help'), () => showTermHelp(context)),
        ],
      ),
    );
  }
}

class _ExtraKeys extends StatelessWidget {
  final TermTab tab;
  const _ExtraKeys({required this.tab});

  Widget _key(String label, {String? input, String? control, bool wide = false}) => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 3),
        child: OutlinedButton(
          onPressed: !tab.running
              ? null
              : control != null
                  ? () => tab.control(control)
                  : () => tab.sendRaw(input ?? label),
          style: OutlinedButton.styleFrom(
            foregroundColor: const Color(0xFFB1BAC4),
            side: const BorderSide(color: TermStyle.border),
            padding: const EdgeInsets.symmetric(horizontal: 10),
            minimumSize: Size(wide ? 56 : 38, 31),
            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
            visualDensity: VisualDensity.compact,
          ),
          child: Text(label, style: const TextStyle(fontFamily: 'monospace', fontSize: 11)),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 42,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
        children: [
          _key('ESC', input: '\u001b'),
          _key('TAB', input: '\t'),
          _key('CTRL+C', control: 'C', wide: true),
          _key('CTRL+D', control: 'D', wide: true),
          _key('CTRL+L', control: 'L', wide: true),
          _key('CTRL+A', control: 'A', wide: true),
          _key('CTRL+U', control: 'U', wide: true),
          _key('CTRL+W', control: 'W', wide: true),
          _key('termux', input: 'termux\r', wide: true),
          _key('alpine', input: 'bash\r', wide: true),
          _key('↑', input: '\u001b[A'),
          _key('↓', input: '\u001b[B'),
          _key('←', input: '\u001b[D'),
          _key('→', input: '\u001b[C'),
          _key('|'),
          _key('/'),
          _key('~'),
          _key('-'),
        ],
      ),
    );
  }
}
