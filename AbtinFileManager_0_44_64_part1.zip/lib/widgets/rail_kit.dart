import 'package:flutter/material.dart';

// Shared building blocks of every side rail (Abtin Pulse floating rail, Neon rail).
// All colours of a rail live in ONE place - [RailPalette] - and follow the light / dark theme,
// so no rail widget may hard-code a colour again.

/// Colour set of a rail for the current theme brightness and look.
class RailPalette {
  final Color panelTop, panelBottom, panelBorder, panelGlow;
  final Color idleFill, idleIcon;
  final Color selFillA, selFillB, selBorder, selGlow, selIcon;
  const RailPalette({
    required this.panelTop,
    required this.panelBottom,
    required this.panelBorder,
    required this.panelGlow,
    required this.idleFill,
    required this.idleIcon,
    required this.selFillA,
    required this.selFillB,
    required this.selBorder,
    required this.selGlow,
    required this.selIcon,
  });

  /// [neon]: the Neon look keeps its idle buttons transparent and its selected icon white;
  /// the Abtin look has filled idle buttons and a cyan selected icon (dark theme).
  factory RailPalette.of(BuildContext context, {bool neon = false}) {
    final t = Theme.of(context);
    final dark = t.brightness == Brightness.dark;
    final accent = t.colorScheme.primary;
    if (dark) {
      return RailPalette(
        panelTop: const Color(0xFF1A1D82),
        panelBottom: const Color(0xFF10125E),
        panelBorder: const Color(0x665B78FF),
        panelGlow: const Color(0x553C4BFF),
        idleFill: neon ? Colors.transparent : const Color(0xFF1C1F8E),
        idleIcon: neon ? Colors.white : const Color(0xFFE5E8FF),
        selFillA: neon ? const Color(0xFF1B46FF) : const Color(0xFF1C3FD8),
        selFillB: neon ? const Color(0xFF1031C9) : const Color(0xFF1C3FD8),
        selBorder: neon ? const Color(0xFF2F7BFF) : const Color(0xFF3DA3FF),
        selGlow: neon ? const Color(0xCC1E64FF) : const Color(0xAA2D7BFF),
        selIcon: neon ? Colors.white : const Color(0xFF33D6FF),
      );
    }
    // light theme: pale glass panel, dark-navy icons, the selected button stays a saturated blue
    return RailPalette(
      panelTop: Colors.white,
      panelBottom: const Color(0xFFE6EDFF),
      panelBorder: accent.withOpacity(.45),
      panelGlow: accent.withOpacity(.20),
      idleFill: neon ? Colors.transparent : const Color(0xFFE9EEFF),
      idleIcon: const Color(0xFF1B2A5C),
      selFillA: const Color(0xFF2A55FF),
      selFillB: const Color(0xFF1B3BDD),
      selBorder: const Color(0xFF2F7BFF),
      selGlow: const Color(0x802D7BFF),
      selIcon: Colors.white,
    );
  }
}

/// The floating rounded panel behind a group of [RailButton]s.
class RailPanel extends StatelessWidget {
  final Widget child;
  final double width;
  const RailPanel({super.key, required this.child, this.width = 52});

  @override
  Widget build(BuildContext context) {
    final p = RailPalette.of(context);
    return Container(
      width: width,
      padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 3),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(27),
        gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [p.panelTop, p.panelBottom]),
        border: Border.all(color: p.panelBorder, width: 1.1),
        boxShadow: [
          BoxShadow(color: p.panelGlow, blurRadius: 16),
          BoxShadow(color: p.panelGlow.withOpacity(.6), blurRadius: 14, spreadRadius: -4, offset: const Offset(0, 2)),
        ],
      ),
      child: child,
    );
  }
}

/// One rail button (circle, or a rounded square when [radius] is given).
class RailButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final bool selected;
  final VoidCallback onTap;
  final double width, height, iconSize;
  final double? radius;
  final bool neon;
  const RailButton({
    super.key,
    required this.icon,
    required this.tooltip,
    required this.selected,
    required this.onTap,
    this.width = 44,
    this.height = 44,
    this.iconSize = 25,
    this.radius,
    this.neon = false,
  });

  @override
  Widget build(BuildContext context) {
    final p = RailPalette.of(context, neon: neon);
    final br = radius == null ? null : BorderRadius.circular(radius!);
    final shape = radius == null ? BoxShape.circle : BoxShape.rectangle;
    return Tooltip(
      message: tooltip,
      child: InkWell(
        customBorder: radius == null ? const CircleBorder() : RoundedRectangleBorder(borderRadius: br!),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          width: width,
          height: height,
          decoration: BoxDecoration(
            shape: shape,
            borderRadius: br,
            gradient: selected ? LinearGradient(colors: [p.selFillA, p.selFillB], begin: Alignment.topLeft, end: Alignment.bottomRight) : null,
            color: selected ? null : p.idleFill,
            border: selected ? Border.all(color: p.selBorder, width: neon ? 2 : 1.5) : null,
            boxShadow: selected ? [BoxShadow(color: p.selGlow, blurRadius: 12)] : null,
          ),
          child: Icon(icon, size: iconSize, color: selected ? p.selIcon : p.idleIcon),
        ),
      ),
    );
  }
}

/// Paints the page background under a rail lane, so a pushed route (which has no Scaffold behind the
/// lane) never shows the black window background next to the rail.
class RailLaneBackground extends StatelessWidget {
  const RailLaneBackground({super.key});
  @override
  Widget build(BuildContext context) => ColoredBox(color: Theme.of(context).scaffoldBackgroundColor);
}
