import 'package:flutter/material.dart';

import '../core/layouts.dart' show tr2;
import '../services/ai_client.dart';
import '../services/ai_settings.dart';

/// Settings of the AI assistant: provider, API key, model, URL, tool permissions.
/// Returns true when saved.
Future<bool> showAiSettings(BuildContext context) async {
  await AiSettings.load();
  if (!context.mounted) return false;
  final r = await showDialog<bool>(context: context, builder: (_) => const _AiSettingsDialog());
  return r == true;
}

class _Draft {
  _Draft(this.key, this.url, this.model);
  String key, url, model;
}

class _AiSettingsDialog extends StatefulWidget {
  const _AiSettingsDialog();
  @override
  State<_AiSettingsDialog> createState() => _AiSettingsDialogState();
}

class _AiSettingsDialogState extends State<_AiSettingsDialog> {
  late String _prov = AiSettings.active;
  final Map<String, _Draft> _drafts = {};
  final _key = TextEditingController();
  final _url = TextEditingController();
  final _model = TextEditingController();
  late final _extra = TextEditingController(text: AiSettings.extraPrompt);
  late final _maxTok = TextEditingController(text: '${AiSettings.maxTokens}');
  late bool _tools = AiSettings.toolsOn;
  late bool _auto = AiSettings.autoApprove;
  bool _hide = true;
  bool _fetching = false;
  String? _fetchErr;
  List<String> _fetched = const [];

  AiProvider get _p => AiSettings.byId(_prov);

  @override
  void initState() {
    super.initState();
    _loadFields();
  }

  @override
  void dispose() {
    _key.dispose();
    _url.dispose();
    _model.dispose();
    _extra.dispose();
    _maxTok.dispose();
    super.dispose();
  }

  void _loadFields() {
    final d = _drafts[_prov];
    _key.text = d?.key ?? AiSettings.keyOf(_prov);
    _url.text = d?.url ?? (AiSettings.urlOf(_prov) == _p.baseUrl ? '' : AiSettings.urlOf(_prov));
    _model.text = d?.model ?? AiSettings.modelOf(_prov);
    _fetched = const [];
    _fetchErr = null;
  }

  void _stash() {
    _drafts[_prov] = _Draft(_key.text, _url.text, _model.text);
  }

  String _effectiveUrl() => _url.text.trim().isNotEmpty ? _url.text.trim() : _p.baseUrl;

  Future<void> _fetch() async {
    setState(() {
      _fetching = true;
      _fetchErr = null;
    });
    try {
      final l = await AiClient.listModels(_p, _effectiveUrl(), _key.text.trim());
      if (!mounted) return;
      setState(() {
        _fetched = l;
        if (l.isEmpty) _fetchErr = tr2('فهرستی برنگشت', 'The provider returned no models');
      });
    } catch (e) {
      if (mounted) setState(() => _fetchErr = '$e');
    } finally {
      if (mounted) setState(() => _fetching = false);
    }
  }

  Future<void> _save() async {
    _stash();
    for (final e in _drafts.entries) {
      await AiSettings.saveProvider(e.key, key: e.value.key, model: e.value.model, url: e.value.url);
    }
    await AiSettings.setActive(_prov);
    await AiSettings.saveGeneral(
      toolsOn: _tools,
      autoApprove: _auto,
      extraPrompt: _extra.text,
      maxTokens: int.tryParse(_maxTok.text.trim()) ?? AiSettings.maxTokens,
    );
    if (mounted) Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final p = _p;
    final suggestions = {...p.models, ..._fetched}.toList();
    final canSave = (!p.needsKey || _key.text.trim().isNotEmpty) && _effectiveUrl().isNotEmpty && _model.text.trim().isNotEmpty;
    return AlertDialog(
      title: Text(tr2('تنظیمات هوش مصنوعی', 'AI assistant settings')),
      content: SizedBox(
        width: 460,
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            DropdownButtonFormField<String>(
              value: _prov,
              isExpanded: true,
              decoration: InputDecoration(labelText: tr2('سرویس', 'Provider')),
              items: [
                for (final e in AiSettings.providers)
                  DropdownMenuItem(
                    value: e.id,
                    child: Text('${AiSettings.isReady(e.id) ? '● ' : ''}${e.name}', overflow: TextOverflow.ellipsis),
                  ),
              ],
              onChanged: (v) {
                if (v == null || v == _prov) return;
                _stash();
                setState(() {
                  _prov = v;
                  _loadFields();
                });
              },
            ),
            const SizedBox(height: 10),
            if (p.needsKey)
              TextField(
                controller: _key,
                obscureText: _hide,
                autocorrect: false,
                enableSuggestions: false,
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  labelText: tr2('کلید API', 'API key'),
                  helperText: p.keyUrl.isEmpty ? null : tr2('کلید را از ${p.keyUrl} بسازید', 'Create a key at ${p.keyUrl}'),
                  suffixIcon: IconButton(
                    icon: Icon(_hide ? Icons.visibility_rounded : Icons.visibility_off_rounded),
                    onPressed: () => setState(() => _hide = !_hide),
                  ),
                ),
              ),
            const SizedBox(height: 8),
            TextField(
              controller: _url,
              keyboardType: TextInputType.url,
              autocorrect: false,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                labelText: p.editableUrl ? 'Base URL' : tr2('Base URL (اختیاری)', 'Base URL (optional)'),
                hintText: p.baseUrl.isEmpty ? 'https://…/v1' : p.baseUrl,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _model,
              autocorrect: false,
              onChanged: (_) => setState(() {}),
              decoration: InputDecoration(
                labelText: tr2('مدل', 'Model'),
                hintText: p.defaultModel,
                suffixIcon: _fetching
                    ? const Padding(padding: EdgeInsets.all(12), child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)))
                    : IconButton(
                        icon: const Icon(Icons.cloud_download_rounded),
                        tooltip: tr2('دریافت فهرست مدل‌ها از سرویس', 'Fetch the model list'),
                        onPressed: (p.needsKey && _key.text.trim().isEmpty) || _effectiveUrl().isEmpty ? null : _fetch,
                      ),
              ),
            ),
            if (suggestions.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 130),
                  child: SingleChildScrollView(
                    child: Wrap(spacing: 6, runSpacing: 0, children: [
                      for (final m in suggestions.take(60))
                        ActionChip(
                          label: Text(m, style: const TextStyle(fontSize: 12)),
                          visualDensity: VisualDensity.compact,
                          onPressed: () => setState(() => _model.text = m),
                        ),
                    ]),
                  ),
                ),
              ),
            if (_fetchErr != null)
              Padding(padding: const EdgeInsets.only(top: 6), child: Text(_fetchErr!, style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.error))),
            const Divider(height: 24),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(tr2('ابزارهای فایل (حالت ایجنت)', 'File tools (agent mode)')),
              subtitle: Text(tr2('مدل بتواند فایل‌های پوشهٔ پروژه را بخواند، جست‌وجو و ویرایش کند', 'The model can read, search and edit files of the project folder')),
              value: _tools,
              onChanged: (v) => setState(() => _tools = v),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: Text(tr2('تأیید خودکار ویرایش‌ها', 'Auto-approve edits')),
              subtitle: Text(tr2('بدون پرسیدن، فایل بنویسد و ویرایش کند (حذف همیشه پرسیده می‌شود)', 'Write and edit files without asking (deleting always asks)')),
              value: _auto,
              onChanged: _tools ? (v) => setState(() => _auto = v) : null,
            ),
            TextField(
              controller: _maxTok,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: tr2('حداکثر توکن پاسخ (Claude)', 'Max answer tokens (Claude)')),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _extra,
              minLines: 2,
              maxLines: 5,
              decoration: InputDecoration(
                labelText: tr2('دستور دائمی برای مدل (اختیاری)', 'Standing instructions (optional)'),
                hintText: tr2('مثلاً: همیشه فارسی توضیح بده', 'e.g. explain in Persian'),
              ),
            ),
            const SizedBox(height: 10),
            Text(
              tr2('کلیدها فقط در حافظهٔ خصوصی همین اپ ذخیره می‌شوند. پیام‌ها و کدهایی که می‌فرستید (و فایل‌هایی که مدل می‌خواند) مستقیم به سرویس انتخابی می‌روند.',
                  'Keys are stored only in this app\'s private storage. Your messages, attached code and any file the model reads go directly to the chosen provider.'),
              style: const TextStyle(fontSize: 12),
            ),
          ]),
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context, false), child: Text(tr2('لغو', 'Cancel'))),
        FilledButton(onPressed: canSave ? _save : null, child: Text(tr2('ذخیره', 'Save'))),
      ],
    );
  }
}
