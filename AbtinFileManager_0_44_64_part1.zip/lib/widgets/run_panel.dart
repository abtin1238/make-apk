import 'package:flutter/material.dart';
import 'package:xterm/xterm.dart';

import '../core/layouts.dart' show tr2;
import '../services/code_runner.dart';
import '../services/run_session.dart';

/// Output panel of "Run code": an ANSI terminal view, a stdin line, and
/// run / stop / Ctrl+C / EOF buttons. Asks before installing Alpine or packages.
class RunPanel extends StatefulWidget {
  final RunSession session;
  final TextEditingController args;
  final bool big;

  /// true = shown inside the editor's tabbed panel (resize / close live in the tab strip).
  final bool embedded;
  final void Function(RunPre pre) onRun;
  final VoidCallback onClose;
  final VoidCallback onToggleSize;
  const RunPanel({
    super.key,
    required this.session,
    required this.args,
    required this.big,
    this.embedded = false,
    required this.onRun,
    required this.onClose,
    required this.onToggleSize,
  });

  @override
  State<RunPanel> createState() => _RunPanelState();
}

class _RunPanelState extends State<RunPanel> {
  static const _theme = TerminalTheme(
    cursor: Color(0xFF39D353),
    selection: Color(0x8039D353),
    foreground: Color(0xFFE6EDF3),
    background: Color(0xFF0B0F14),
    black: Color(0xFF000000),
    red: Color(0xFFCC4444),
    green: Color(0xFF39D353),
    yellow: Color(0xFFE3B341),
    blue: Color(0xFF58A6FF),
    magenta: Color(0xFFD2A8FF),
    cyan: Color(0xFF39C5CF),
    white: Color(0xFFE6EDF3),
    brightBlack: Color(0xFF6E7681),
    brightRed: Color(0xFFFF7B72),
    brightGreen: Color(0xFF56D364),
    brightYellow: Color(0xFFEAC54F),
    brightBlue: Color(0xFF79C0FF),
    brightMagenta: Color(0xFFD2A8FF),
    brightCyan: Color(0xFF56D4DD),
    brightWhite: Color(0xFFFFFFFF),
    searchHitBackground: Color(0xFFFFFF2B),
    searchHitBackgroundCurrent: Color(0xFF31FF26),
    searchHitForeground: Color(0xFF000000),
  );

  final _input = TextEditingController();
  final _inputFocus = FocusNode();
  int _prompted = -1;

  @override
  void initState() {
    super.initState();
    widget.session.addListener(_onSession);
  }

  @override
  void didUpdateWidget(RunPanel old) {
    super.didUpdateWidget(old);
    if (old.session != widget.session) {
      old.session.removeListener(_onSession);
      widget.session.addListener(_onSession);
    }
  }

  @override
  void dispose() {
    widget.session.removeListener(_onSession);
    _input.dispose();
    _inputFocus.dispose();
    super.dispose();
  }

  void _onSession() {
    final s = widget.session;
    if (s.runId != _prompted && (s.state == RunState.needAlpine || s.state == RunState.needInstall)) {
      _prompted = s.runId;
      WidgetsBinding.instance.addPostFrameCallback((_) => _ask());
    }
  }

  Future<void> _ask() async {
    if (!mounted) return;
    final s = widget.session;
    final r = s.runner;
    final alpine = s.state == RunState.needAlpine;
    final title = r?.title ?? '';
    final body = alpine
        ? tr2(
            'برای اجرای کد، محیط لینوکس Alpine (همراه با Python و Node.js) باید نصب شود. حدود ۱۵۰ تا ۲۰۰ مگابایت دانلود می‌شود و به اینترنت نیاز دارد. نصب شود؟',
            'Running code needs the Alpine Linux environment (with Python and Node.js). It downloads about 150-200 MB and needs internet. Install it?')
        : tr2(
            'برای اجرای $title باید بسته‌های «${s.needPkgs}» نصب شوند${(r?.mb ?? 0) > 0 ? ' (حدود ${r!.mb} مگابایت)' : ''}. نصب شود؟',
            'Running $title needs the packages "${s.needPkgs}" ${(r?.mb ?? 0) > 0 ? '(about ${r!.mb} MB) ' : ''}to be installed. Install them?');
    final ok = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: Text(alpine ? tr2('نصب محیط لینوکس', 'Install Linux environment') : tr2('نصب ابزار $title', 'Install $title tools')),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: Text(tr2('انصراف', 'Cancel'))),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: Text(tr2('نصب و اجرا', 'Install & run'))),
        ],
      ),
    );
    if (ok == true && mounted) widget.onRun(alpine ? RunPre.bootstrap : RunPre.install);
  }

  String _status(RunSession s) {
    switch (s.state) {
      case RunState.idle:
        return '';
      case RunState.starting:
        return tr2('در حال شروع…', 'Starting…');
      case RunState.running:
        return tr2('در حال اجرا…', 'Running…');
      case RunState.needAlpine:
      case RunState.needInstall:
        return tr2('نیاز به نصب', 'Needs install');
      case RunState.error:
        return tr2('خطا در اجرا', 'Could not run');
      case RunState.done:
        final t = s.elapsed == null ? '' : ' • ${(s.elapsed!.inMilliseconds / 1000).toStringAsFixed(1)}s';
        if (s.exitCode == null) return tr2('متوقف شد', 'Stopped') + t;
        if (s.exitCode == 0) return tr2('پایان موفق (کد 0)', 'Finished (exit 0)') + t;
        return tr2('پایان با خطا (کد ${s.exitCode})', 'Failed (exit ${s.exitCode})') + t;
    }
  }

  Color _dot(RunSession s) {
    switch (s.state) {
      case RunState.running:
      case RunState.starting:
        return const Color(0xFF58A6FF);
      case RunState.done:
        return s.exitCode == 0 ? const Color(0xFF39D353) : (s.exitCode == null ? Colors.orangeAccent : const Color(0xFFFF7B72));
      case RunState.error:
        return const Color(0xFFFF7B72);
      default:
        return Colors.orangeAccent;
    }
  }

  void _send() {
    final t = _input.text;
    if (!widget.session.running) return;
    widget.session.sendLine(t);
    _input.clear();
    _inputFocus.requestFocus();
  }

  Widget _btn(IconData icon, String tip, VoidCallback? onTap, {Color? color}) => IconButton(
        icon: Icon(icon, size: 20, color: color),
        tooltip: tip,
        visualDensity: VisualDensity.compact,
        padding: EdgeInsets.zero,
        constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
        onPressed: onTap,
      );

  @override
  Widget build(BuildContext context) {
    final s = widget.session;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Material(
        color: _theme.background,
        child: AnimatedBuilder(
          animation: s,
          builder: (context, _) {
            final running = s.running;
            return Column(
              children: [
                Container(
                  height: 40,
                  color: const Color(0xFF161B22),
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Row(
                    children: [
                      Icon(Icons.circle, size: 10, color: _dot(s)),
                      const SizedBox(width: 6),
                      Flexible(
                        flex: 3,
                        child: Text(
                          _status(s),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Color(0xFFB1BAC4), fontSize: 12),
                        ),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        flex: 2,
                        child: TextField(
                          controller: widget.args,
                          enabled: !running,
                          style: const TextStyle(fontFamily: 'monospace', fontSize: 12, color: Color(0xFFE6EDF3)),
                          decoration: InputDecoration(
                            isDense: true,
                            hintText: tr2('آرگومان‌ها', 'args'),
                            hintStyle: const TextStyle(fontSize: 12, color: Color(0xFF6E7681)),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(6), borderSide: const BorderSide(color: Color(0xFF30363D))),
                            disabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(6), borderSide: const BorderSide(color: Color(0xFF21262D))),
                            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(6), borderSide: const BorderSide(color: Color(0xFF58A6FF))),
                          ),
                        ),
                      ),
                      if (running)
                        _btn(Icons.stop_rounded, tr2('توقف', 'Stop'), s.stop, color: Colors.redAccent)
                      else
                        _btn(Icons.play_arrow_rounded, tr2('اجرای دوباره', 'Run again'), () => widget.onRun(RunPre.none), color: const Color(0xFF39D353)),
                      if (!widget.embedded) ...[
                        _btn(widget.big ? Icons.close_fullscreen_rounded : Icons.open_in_full_rounded, tr2('تغییر اندازه', 'Resize'), widget.onToggleSize),
                        _btn(Icons.close_rounded, tr2('بستن', 'Close'), widget.onClose),
                      ],
                    ],
                  ),
                ),
                Expanded(
                  child: TerminalView(
                    s.terminal,
                    theme: _theme,
                    textStyle: const TerminalStyle(fontSize: 13, height: 1.2),
                    readOnly: true,
                    autoResize: true,
                    padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
                  ),
                ),
                Container(
                  height: 44,
                  color: const Color(0xFF161B22),
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _input,
                          focusNode: _inputFocus,
                          enabled: running,
                          textInputAction: TextInputAction.send,
                          onSubmitted: (_) => _send(),
                          style: const TextStyle(fontFamily: 'monospace', fontSize: 13, color: Color(0xFFE6EDF3)),
                          decoration: InputDecoration(
                            isDense: true,
                            hintText: tr2('ورودی برنامه (stdin) …', 'stdin …'),
                            hintStyle: const TextStyle(fontSize: 13, color: Color(0xFF6E7681)),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFF30363D))),
                            disabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFF21262D))),
                            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(8), borderSide: const BorderSide(color: Color(0xFF58A6FF))),
                          ),
                        ),
                      ),
                      _btn(Icons.send_rounded, tr2('ارسال', 'Send'), running ? _send : null),
                      TextButton(
                        onPressed: running ? s.interrupt : null,
                        style: TextButton.styleFrom(visualDensity: VisualDensity.compact, minimumSize: const Size(40, 32), padding: const EdgeInsets.symmetric(horizontal: 6)),
                        child: const Text('^C', style: TextStyle(fontFamily: 'monospace', fontSize: 13)),
                      ),
                      TextButton(
                        onPressed: running ? s.eof : null,
                        style: TextButton.styleFrom(visualDensity: VisualDensity.compact, minimumSize: const Size(40, 32), padding: const EdgeInsets.symmetric(horizontal: 6)),
                        child: const Text('^D', style: TextStyle(fontFamily: 'monospace', fontSize: 13)),
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
