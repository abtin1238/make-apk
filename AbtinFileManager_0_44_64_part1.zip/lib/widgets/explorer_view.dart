
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;

import '../core/l10n.dart';
import '../core/layouts.dart' show tr2;
import '../services/file_ops.dart';
import 'ui.dart';

class _Row {
  final FItem item;
  final int depth;
  const _Row(this.item, this.depth);
}

/// VS Code style file tree for the text editor: folders expand in place, a tap
/// on a file opens it in a tab, long press / the menu button manages it.
class ExplorerView extends StatefulWidget {
  final String root;
  final String? activePath;

  /// Files with unsaved changes (shown with a dot).
  final Set<String> dirty;
  final void Function(String path) onOpen;
  final void Function(String from, String to) onRenamed;
  final void Function(String path) onDeleted;

  /// Changes every few seconds while a terminal is open: reload the visible folders.
  final int refreshTick;
  const ExplorerView({
    super.key,
    required this.root,
    required this.activePath,
    required this.dirty,
    required this.onOpen,
    required this.onRenamed,
    required this.onDeleted,
    this.refreshTick = 0,
  });

  @override
  State<ExplorerView> createState() => _ExplorerViewState();
}

class _ExplorerViewState extends State<ExplorerView> {
  late String _root = widget.root;
  final Set<String> _open = <String>{};
  final Map<String, List<FItem>> _cache = <String, List<FItem>>{};
  List<_Row> _rows = const <_Row>[];
  String? _err;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load(_root);
  }

  @override
  void didUpdateWidget(ExplorerView old) {
    super.didUpdateWidget(old);
    if (old.refreshTick != widget.refreshTick && !_busy) _refreshAll();
    if (old.root != widget.root) {
      _root = widget.root;
      _open.clear();
      _cache.clear();
      _load(_root);
    }
  }

  Future<void> _load(String dir) async {
    try {
      _cache[dir] = await FileOps.list(dir, hidden: true);
      _err = null;
    } catch (e) {
      _err = '$e';
    }
    _rebuild();
  }

  void _rebuild() {
    final out = <_Row>[];
    void walk(String dir, int depth) {
      for (final it in _cache[dir] ?? const <FItem>[]) {
        out.add(_Row(it, depth));
        if (it.isDir && _open.contains(it.path)) walk(it.path, depth + 1);
      }
    }

    walk(_root, 0);
    _rows = out;
    if (mounted) setState(() {});
  }

  Future<void> _refreshAll() async {
    final dirs = <String>{_root, ..._open};
    for (final d in dirs) {
      try {
        _cache[d] = await FileOps.list(d, hidden: true);
      } catch (_) {
        _cache.remove(d);
      }
    }
    _err = null;
    _rebuild();
  }

  Future<void> _toggle(FItem it) async {
    if (it.isDir) {
      if (_open.contains(it.path)) {
        _open.remove(it.path);
        _rebuild();
      } else {
        _open.add(it.path);
        if (!_cache.containsKey(it.path)) await _load(it.path);
        _rebuild();
      }
    } else {
      widget.onOpen(it.path);
    }
  }

  void _up() {
    final parent = p.dirname(_root);
    if (parent == _root) return;
    _root = parent;
    _open.clear();
    _load(_root);
  }

  Future<void> _guard(Future<void> Function() job) async {
    if (_busy) return;
    _busy = true;
    try {
      await job();
    } on OpError catch (e) {
      if (mounted) snack(context, e.arg == null ? L.t(e.key) : '${L.t(e.key)}: ${e.arg}');
    } catch (e) {
      if (mounted) snack(context, '$e');
    } finally {
      _busy = false;
    }
  }

  Future<void> _newFile(String dir) => _guard(() async {
        final name = await promptText(context, tr2('نام فایل جدید', 'New file name'));
        if (name == null || name.isEmpty || !mounted) return;
        await FileOps.touch(dir, name);
        _open.add(dir);
        await _load(dir);
        widget.onOpen(p.join(dir, FileOps.checkName(name)));
      });

  Future<void> _newFolder(String dir) => _guard(() async {
        final name = await promptText(context, tr2('نام پوشهٔ جدید', 'New folder name'));
        if (name == null || name.isEmpty || !mounted) return;
        await FileOps.mkdir(dir, name);
        _open.add(dir);
        await _load(dir);
        _open.add(p.join(dir, FileOps.checkName(name)));
        await _load(p.join(dir, FileOps.checkName(name)));
      });

  Future<void> _rename(FItem it) => _guard(() async {
        final name = await promptText(context, tr2('تغییر نام', 'Rename'), initial: it.name);
        if (name == null || name.isEmpty || name == it.name || !mounted) return;
        final to = p.join(p.dirname(it.path), FileOps.checkName(name));
        await FileOps.rename(it.entity, name);
        widget.onRenamed(it.path, to);
        _open.remove(it.path);
        _cache.remove(it.path);
        await _refreshAll();
      });

  Future<void> _delete(FItem it) => _guard(() async {
        final ok = await confirm(context, tr2('«${it.name}» حذف شود؟', 'Delete "${it.name}"?'));
        if (!ok || !mounted) return;
        await FileOps.delete(it.entity);
        widget.onDeleted(it.path);
        _open.remove(it.path);
        _cache.remove(it.path);
        await _refreshAll();
      });

  Future<void> _menu(FItem it) async {
    final dir = it.isDir ? it.path : p.dirname(it.path);
    final act = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              dense: true,
              leading: Icon(it.isDir ? Icons.folder_rounded : Icons.insert_drive_file_outlined),
              title: Text(it.name, maxLines: 1, overflow: TextOverflow.ellipsis),
            ),
            const Divider(height: 1),
            ListTile(leading: const Icon(Icons.note_add_outlined), title: Text(tr2('فایل جدید', 'New file')), onTap: () => Navigator.pop(ctx, 'nf')),
            ListTile(leading: const Icon(Icons.create_new_folder_outlined), title: Text(tr2('پوشهٔ جدید', 'New folder')), onTap: () => Navigator.pop(ctx, 'nd')),
            ListTile(leading: const Icon(Icons.drive_file_rename_outline_rounded), title: Text(tr2('تغییر نام', 'Rename')), onTap: () => Navigator.pop(ctx, 'rn')),
            ListTile(leading: const Icon(Icons.copy_rounded), title: Text(tr2('کپی مسیر', 'Copy path')), onTap: () => Navigator.pop(ctx, 'cp')),
            ListTile(
              leading: const Icon(Icons.delete_outline_rounded, color: Colors.redAccent),
              title: Text(tr2('حذف', 'Delete'), style: const TextStyle(color: Colors.redAccent)),
              onTap: () => Navigator.pop(ctx, 'rm'),
            ),
          ],
        ),
      ),
    );
    if (act == null || !mounted) return;
    switch (act) {
      case 'nf':
        await _newFile(dir);
        break;
      case 'nd':
        await _newFolder(dir);
        break;
      case 'rn':
        await _rename(it);
        break;
      case 'cp':
        await Clipboard.setData(ClipboardData(text: it.path));
        if (mounted) snack(context, L.t('done'));
        break;
      case 'rm':
        await _delete(it);
        break;
    }
  }

  Widget _head(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    Widget b(IconData i, String tip, VoidCallback f) => IconButton(
          icon: Icon(i, size: 18),
          tooltip: tip,
          visualDensity: VisualDensity.compact,
          padding: EdgeInsets.zero,
          constraints: const BoxConstraints(minWidth: 32, minHeight: 34),
          onPressed: f,
        );
    return Container(
      height: 38,
      padding: const EdgeInsets.only(left: 12, right: 2),
      color: cs.surfaceContainerHighest.withOpacity(.5),
      child: Row(
        children: [
          Expanded(
            child: Tooltip(
              message: _root,
              child: Text(
                (p.basename(_root).isEmpty ? _root : p.basename(_root)).toUpperCase(),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, letterSpacing: .6),
              ),
            ),
          ),
          b(Icons.note_add_outlined, tr2('فایل جدید', 'New file'), () => _newFile(_root)),
          b(Icons.create_new_folder_outlined, tr2('پوشهٔ جدید', 'New folder'), () => _newFolder(_root)),
          b(Icons.arrow_upward_rounded, tr2('پوشهٔ بالاتر', 'Parent folder'), _up),
          b(Icons.refresh_rounded, tr2('تازه‌سازی', 'Refresh'), _refreshAll),
        ],
      ),
    );
  }

  IconData _iconFor(FItem it, bool open) {
    if (it.isDir) return open ? Icons.folder_open_rounded : Icons.folder_rounded;
    switch (FileOps.ext(it.path)) {
      case 'py':
      case 'js':
      case 'ts':
      case 'dart':
      case 'java':
      case 'kt':
      case 'c':
      case 'cpp':
      case 'go':
      case 'rs':
      case 'php':
      case 'rb':
      case 'sh':
        return Icons.code_rounded;
      case 'json':
      case 'xml':
      case 'yaml':
      case 'yml':
      case 'toml':
        return Icons.data_object_rounded;
      case 'md':
      case 'txt':
      case 'log':
        return Icons.description_outlined;
      case 'png':
      case 'jpg':
      case 'jpeg':
      case 'gif':
      case 'webp':
        return Icons.image_outlined;
      default:
        return Icons.insert_drive_file_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _head(context),
          if (_err != null)
            Padding(
              padding: const EdgeInsets.all(10),
              child: Text(_err!, style: const TextStyle(color: Colors.redAccent, fontSize: 12)),
            ),
          Expanded(
            child: _rows.isEmpty && _err == null
                ? Center(child: Text(tr2('پوشه خالی است', 'Empty folder'), style: Theme.of(context).textTheme.bodySmall))
                : ListView.builder(
                    itemCount: _rows.length,
                    itemExtent: 34,
                    itemBuilder: (context, i) {
                      final r = _rows[i];
                      final it = r.item;
                      final open = it.isDir && _open.contains(it.path);
                      final active = widget.activePath == it.path;
                      final dirty = widget.dirty.contains(it.path);
                      return InkWell(
                        onTap: () => _toggle(it),
                        onLongPress: () => _menu(it),
                        child: Container(
                          color: active ? cs.primary.withOpacity(.16) : null,
                          padding: EdgeInsets.only(left: 6.0 + r.depth * 14),
                          child: Row(
                            children: [
                              SizedBox(
                                width: 16,
                                child: it.isDir ? Icon(open ? Icons.expand_more_rounded : Icons.chevron_right_rounded, size: 16) : null,
                              ),
                              Icon(
                                _iconFor(it, open),
                                size: 17,
                                color: it.isDir ? const Color(0xFFE3B341) : cs.onSurfaceVariant,
                              ),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  it.name,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 13, fontWeight: active ? FontWeight.w600 : null),
                                ),
                              ),
                              if (dirty)
                                Container(
                                  width: 8,
                                  height: 8,
                                  margin: const EdgeInsets.only(right: 4),
                                  decoration: const BoxDecoration(color: Colors.amber, shape: BoxShape.circle),
                                ),
                              InkResponse(
                                onTap: () => _menu(it),
                                radius: 16,
                                child: const Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 6),
                                  child: Icon(Icons.more_vert_rounded, size: 16),
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
