import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart' as p;

import '../core/layouts.dart' show tr2;
import '../services/debug_session.dart';

/// "Run and debug" side view (also used as the Variables tab of the bottom panel):
/// variables, watch expressions, call stack and the breakpoint list.
class DebugView extends StatefulWidget {
  final DebugSession session;
  final BreakpointStore bps;

  /// The current file can be debugged (Python).
  final bool canDebug;
  final bool compact;
  final VoidCallback onStart;
  final void Function(String file, int line) onGoto;
  final void Function(String file, int line)? onEditCondition;
  const DebugView({
    super.key,
    required this.session,
    required this.bps,
    required this.canDebug,
    required this.onStart,
    required this.onGoto,
    this.onEditCondition,
    this.compact = false,
  });

  @override
  State<DebugView> createState() => _DebugViewState();
}

class _DebugViewState extends State<DebugView> {
  final Map<String, bool> _closed = <String, bool>{};
  final TextEditingController _watchCtl = TextEditingController();

  @override
  void dispose() {
    _watchCtl.dispose();
    super.dispose();
  }

  bool _isOpen(String k) => !(_closed[k] ?? false);

  Widget _section(BuildContext context, String key, String title, List<Widget> body, {List<Widget> actions = const []}) {
    final cs = Theme.of(context).colorScheme;
    final open = _isOpen(key);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        InkWell(
          onTap: () => setState(() => _closed[key] = open),
          child: Container(
            height: 32,
            padding: const EdgeInsets.only(left: 6, right: 2),
            color: cs.surfaceContainerHighest.withOpacity(.45),
            child: Row(
              children: [
                Icon(open ? Icons.expand_more_rounded : Icons.chevron_right_rounded, size: 18),
                const SizedBox(width: 2),
                Expanded(
                  child: Text(title.toUpperCase(), style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, letterSpacing: .5)),
                ),
                ...actions,
              ],
            ),
          ),
        ),
        if (open) ...body,
      ],
    );
  }

  Widget _hint(BuildContext context, String t) => Padding(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 10),
        child: Text(t, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Theme.of(context).hintColor)),
      );

  List<Widget> _vars(DebugSession s, List<DebugVar> vars, int depth) {
    final out = <Widget>[];
    for (final v in vars) {
      out.add(_VarTile(v: v, depth: depth, s: s));
      if (v.expanded && v.children != null) out.addAll(_vars(s, v.children!, depth + 1));
    }
    return out;
  }

  Widget _small(IconData i, String tip, VoidCallback f) => IconButton(
        icon: Icon(i, size: 16),
        tooltip: tip,
        visualDensity: VisualDensity.compact,
        padding: EdgeInsets.zero,
        constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
        onPressed: f,
      );

  @override
  Widget build(BuildContext context) {
    final s = widget.session;
    final cs = Theme.of(context).colorScheme;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: AnimatedBuilder(
        animation: Listenable.merge(<Listenable>[s, widget.bps]),
        builder: (context, _) {
          final active = s.active;
          final paused = s.paused;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (!widget.compact)
                Container(
                  padding: const EdgeInsets.fromLTRB(12, 8, 8, 8),
                  color: cs.surfaceContainerHighest.withOpacity(.5),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                          tr2('اجرا و دیباگ', 'RUN AND DEBUG'),
                          style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, letterSpacing: .6),
                        ),
                      ),
                      FilledButton.icon(
                        onPressed: widget.canDebug && !s.active ? widget.onStart : null,
                        style: FilledButton.styleFrom(visualDensity: VisualDensity.compact, padding: const EdgeInsets.symmetric(horizontal: 10)),
                        icon: const Icon(Icons.bug_report_rounded, size: 16),
                        label: Text(tr2('شروع دیباگ', 'Start')),
                      ),
                    ],
                  ),
                ),
              if (!widget.canDebug && !active)
                _hint(context, tr2('دیباگر برای فایل‌های Python و JavaScript کار می‌کند. یک فایل .py یا .js را باز کنید.', 'The debugger runs Python and JavaScript files. Open a .py or .js file.')),
              Expanded(
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    _section(context, 'vars', tr2('متغیرها', 'Variables'), [
                      if (!paused)
                        _hint(context, active ? tr2('برنامه در حال اجراست…', 'Running…') : tr2('برای دیدن متغیرها، برنامه را در یک بریک‌پوینت متوقف کنید.', 'Stop the program at a breakpoint to see variables.'))
                      else ...[
                        if (s.locals.isEmpty && s.globals.isEmpty) _hint(context, tr2('متغیری نیست', 'No variables')),
                        if (s.locals.isNotEmpty) ..._vars(s, s.locals, 0),
                        if (s.globals.isNotEmpty) ...[
                          Padding(
                            padding: const EdgeInsets.fromLTRB(14, 8, 8, 2),
                            child: Text(tr2('سراسری (Globals)', 'Globals'), style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
                          ),
                          ..._vars(s, s.globals, 0),
                        ],
                      ],
                    ]),
                    _section(
                      context,
                      'watch',
                      tr2('دیده‌بان (Watch)', 'Watch'),
                      [
                        Padding(
                          padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
                          child: TextField(
                            controller: _watchCtl,
                            style: const TextStyle(fontFamily: 'monospace', fontSize: 12.5),
                            textInputAction: TextInputAction.done,
                            onSubmitted: (v) {
                              s.addWatch(v);
                              _watchCtl.clear();
                            },
                            decoration: InputDecoration(
                              isDense: true,
                              hintText: tr2('عبارت…  (مثلاً  x + 1)', 'expression…  (e.g.  x + 1)'),
                              contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                        ),
                        if (s.watches.isEmpty)
                          _hint(context, tr2('عبارتی که می‌خواهید در هر توقف ببینید را اضافه کنید.', 'Add expressions you want to see at every stop.'))
                        else
                          for (var i = 0; i < s.watches.length; i++) _WatchTile(w: s.watches[i], onRemove: () => s.removeWatch(i)),
                      ],
                    ),
                    _section(context, 'stack', tr2('پشتهٔ فراخوانی', 'Call stack'), [
                      if (!paused)
                        _hint(context, '—')
                      else
                        for (final f in s.frames)
                          InkWell(
                            onTap: () {
                              s.selectFrame(f.index);
                              widget.onGoto(f.file, f.line);
                            },
                            child: Container(
                              color: f.index == s.selFrame ? cs.primary.withOpacity(.16) : null,
                              padding: const EdgeInsets.fromLTRB(14, 6, 10, 6),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      f.name,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(fontFamily: 'monospace', fontSize: 12.5, color: f.mine ? null : Theme.of(context).hintColor),
                                    ),
                                  ),
                                  Text('${p.basename(f.file)}:${f.line}', style: TextStyle(fontSize: 11, color: Theme.of(context).hintColor)),
                                ],
                              ),
                            ),
                          ),
                    ]),
                    _section(
                      context,
                      'bps',
                      '${tr2('بریک‌پوینت‌ها', 'Breakpoints')} (${widget.bps.count})',
                      [
                        if (widget.bps.isEmpty)
                          _hint(context, tr2('روی شمارهٔ خط در ویرایشگر بزنید تا بریک‌پوینت گذاشته شود. نگه‌داشتن = شرط.', 'Tap a line number in the editor to set a breakpoint. Long press = condition.'))
                        else
                          for (final f in widget.bps.files)
                            for (final line in (widget.bps.of(f).keys.toList()..sort()))
                              InkWell(
                                onTap: () => widget.onGoto(f, line),
                                onLongPress: widget.onEditCondition == null ? null : () => widget.onEditCondition!(f, line),
                                child: Padding(
                                  padding: const EdgeInsets.fromLTRB(14, 4, 4, 4),
                                  child: Row(
                                    children: [
                                      Icon(
                                        widget.bps.unverified[f]?.contains(line) == true ? Icons.radio_button_unchecked_rounded : Icons.circle,
                                        size: 11,
                                        color: widget.bps.of(f)[line] != null ? const Color(0xFFE3B341) : const Color(0xFFE5534B),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          '${p.basename(f)}:$line${widget.bps.of(f)[line] == null ? '' : '   if ${widget.bps.of(f)[line]}'}',
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: const TextStyle(fontFamily: 'monospace', fontSize: 12.5),
                                        ),
                                      ),
                                      _small(Icons.close_rounded, tr2('حذف', 'Remove'), () {
                                        widget.bps.remove(f, line);
                                        s.breakpointsChanged();
                                      }),
                                    ],
                                  ),
                                ),
                              ),
                      ],
                      actions: [
                        if (!widget.bps.isEmpty)
                          _small(Icons.delete_sweep_outlined, tr2('حذف همه', 'Remove all'), () {
                            widget.bps.clear();
                            s.breakpointsChanged();
                          }),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _VarTile extends StatelessWidget {
  final DebugVar v;
  final int depth;
  final DebugSession s;
  const _VarTile({required this.v, required this.depth, required this.s});

  @override
  Widget build(BuildContext context) {
    final hint = Theme.of(context).hintColor;
    return InkWell(
      onTap: v.ref == 0 ? null : () => s.toggleExpand(v),
      onLongPress: () {
        Clipboard.setData(ClipboardData(text: '${v.name} = ${v.value}'));
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(tr2('کپی شد', 'Copied')), duration: const Duration(milliseconds: 900)));
      },
      child: Padding(
        padding: EdgeInsets.fromLTRB(6.0 + depth * 14, 3, 8, 3),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              width: 18,
              child: v.ref == 0
                  ? null
                  : v.loading
                      ? const Padding(padding: EdgeInsets.all(4), child: CircularProgressIndicator(strokeWidth: 1.5))
                      : Icon(v.expanded ? Icons.expand_more_rounded : Icons.chevron_right_rounded, size: 18),
            ),
            Expanded(
              child: Text.rich(
                TextSpan(
                  children: [
                    TextSpan(text: v.name, style: const TextStyle(color: Color(0xFF79C0FF))),
                    TextSpan(text: ' = ', style: TextStyle(color: hint)),
                    TextSpan(text: v.value),
                    if (v.type.isNotEmpty) TextSpan(text: '   ${v.type}', style: TextStyle(color: hint, fontSize: 10.5)),
                  ],
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontFamily: 'monospace', fontSize: 12.5),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WatchTile extends StatelessWidget {
  final DebugWatch w;
  final VoidCallback onRemove;
  const _WatchTile({required this.w, required this.onRemove});

  @override
  Widget build(BuildContext context) {
    final hint = Theme.of(context).hintColor;
    final err = w.error;
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 3, 2, 3),
      child: Row(
        children: [
          Expanded(
            child: Text.rich(
              TextSpan(
                children: [
                  TextSpan(text: w.expr, style: const TextStyle(color: Color(0xFFD2A8FF))),
                  TextSpan(text: ' = ', style: TextStyle(color: hint)),
                  if (err != null)
                    TextSpan(text: err, style: const TextStyle(color: Color(0xFFFF7B72)))
                  else
                    TextSpan(text: w.value?.value ?? '…'),
                ],
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 12.5),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close_rounded, size: 16),
            visualDensity: VisualDensity.compact,
            padding: EdgeInsets.zero,
            constraints: const BoxConstraints(minWidth: 28, minHeight: 28),
            onPressed: onRemove,
          ),
        ],
      ),
    );
  }
}
