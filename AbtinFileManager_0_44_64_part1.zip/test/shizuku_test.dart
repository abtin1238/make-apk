import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/shizuku.dart';

void main() {
  test('only Android/data and Android/obb of internal storage need Shizuku', () {
    for (final p in [
      '/storage/emulated/0/Android/data',
      '/storage/emulated/0/Android/data/com.whatsapp/files',
      '/storage/emulated/0/Android/obb',
      '/storage/emulated/0/Android/obb/com.game/main.1.obb',
      '/storage/emulated/10/Android/data/x',
      '/sdcard/Android/data/x',
      '/storage/self/primary/Android/obb',
    ]) {
      expect(Shizu.covers(p), isTrue, reason: p);
    }
    for (final p in [
      '/storage/emulated/0',
      '/storage/emulated/0/Android',
      '/storage/emulated/0/Android/media/x',
      '/storage/emulated/0/Android/database',
      '/storage/emulated/0/Download/Android/data',
      '/storage/emulated/0/Android/dataX',
      '/storage/ABCD-1234/Android/data',
    ]) {
      expect(Shizu.covers(p), isFalse, reason: p);
    }
  });
}
