import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/ai_client.dart';
import 'package:abtin_file_manager/services/ai_tools.dart';

AiToolCall _c(String n, Map<String, dynamic> a) => AiToolCall('1', n, a);

void main() {
  late Directory dir;
  late ProjectTools t;

  setUp(() {
    dir = Directory.systemTemp.createTempSync('ai_tools');
    File('${dir.path}/a.txt').writeAsStringSync('hello\nworld\nhello\n');
    t = ProjectTools(dir.path);
  });
  tearDown(() => dir.deleteSync(recursive: true));

  test('paths outside the project are refused', () async {
    final r = await t.run(_c('read_file', {'path': '../etc/passwd'}));
    expect(r.error, isTrue);
    final w = await t.run(_c('write_file', {'path': '/tmp/x.txt', 'content': 'x'}));
    expect(w.error, isTrue);
  });

  test('edit_file needs a unique match', () async {
    var r = await t.run(_c('edit_file', {'path': 'a.txt', 'old_text': 'hello', 'new_text': 'bye'}));
    expect(r.error, isTrue);
    r = await t.run(_c('edit_file', {'path': 'a.txt', 'old_text': 'world', 'new_text': 'dart'}));
    expect(r.error, isFalse);
    expect(File('${dir.path}/a.txt').readAsStringSync(), contains('dart'));
    r = await t.run(_c('edit_file', {'path': 'a.txt', 'old_text': 'hello', 'new_text': 'bye', 'replace_all': true}));
    expect(File('${dir.path}/a.txt').readAsStringSync(), 'bye\ndart\nbye\n');
  });

  test('write, search, list, delete', () async {
    await t.run(_c('write_file', {'path': 'sub/b.py', 'content': 'print(1)\n'}));
    expect((await t.run(_c('search', {'pattern': 'print'}))).text, contains('sub/b.py:1'));
    expect((await t.run(_c('list_dir', {'path': '.', 'depth': 2}))).text, contains('b.py'));
    expect((await t.run(_c('delete_path', {'path': 'sub'}))).error, isFalse);
    expect(Directory('${dir.path}/sub').existsSync(), isFalse);
  });
}
