import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/remote/remote_edit.dart';
import 'package:abtin_file_manager/services/remote/remote_fs.dart';

/// In-memory server: path -> text. Several instances can share one [files] map
/// (= "the same server, another connection").
class FakeFs extends RemoteFs {
  final Map<String, String> files;
  final Map<String, DateTime> times;
  int connects = 0, closes = 0, uploads = 0;
  int failUploads = 0; // how many upload() calls throw before one works
  bool failConnect = false;
  FakeFs(this.files, this.times);

  @override
  Future<void> connect() async {
    if (failConnect) throw const RemoteError('connect failed');
    connects++;
  }

  @override
  Future<List<RemoteEntry>> list(String path) async => [
        for (final e in files.entries)
          if (RPath.parent(e.key) == path) RemoteEntry(RPath.name(e.key), false, size: e.value.length, modified: times[e.key]),
      ];

  @override
  Future<void> download(String path, String local, {Prog? onProgress}) async {
    await File(local).writeAsString(files[path]!);
    onProgress?.call(1, 1);
  }

  @override
  Future<void> upload(String local, String path, {Prog? onProgress}) async {
    uploads++;
    if (failUploads > 0) {
      failUploads--;
      throw const RemoteError('connection lost');
    }
    files[path] = await File(local).readAsString();
    times[path] = DateTime.now();
  }

  @override
  Future<void> mkdir(String path) async {}
  @override
  Future<void> delete(String path, bool dir) async => files.remove(path);
  @override
  Future<void> rename(String from, String to) async {}
  @override
  Future<void> close() async => closes++;
}

void main() {
  late Directory tmp;
  late Map<String, String> files;
  late Map<String, DateTime> times;
  final profile = RemoteProfile(id: '7', name: 'srv', type: 'sftp', host: 'example.org', port: 22);

  setUp(() {
    tmp = Directory.systemTemp.createTempSync('remote_edit_test');
    files = {'/www/index.html': '<h1>hi</h1>'};
    times = {'/www/index.html': DateTime.utc(2025, 1, 1, 10)};
  });
  tearDown(() {
    if (tmp.existsSync()) tmp.deleteSync(recursive: true);
  });

  test('differs: unknown values never count as a change', () {
    final t = DateTime.utc(2025, 1, 1);
    expect(RemoteDoc.differs(5, t, 5, t), isFalse);
    expect(RemoteDoc.differs(5, t, 6, t), isTrue);
    expect(RemoteDoc.differs(5, t, 5, t.add(const Duration(seconds: 1))), isTrue);
    expect(RemoteDoc.differs(null, null, 6, t), isFalse);
    expect(RemoteDoc.differs(5, t, null, null), isFalse);
  });

  test('cachePathFor keeps the file name and is unique per salt', () {
    final a = RemoteDoc.cachePathFor('/tmp', profile, '/www/index.html', '1');
    final b = RemoteDoc.cachePathFor('/tmp', profile, '/www/index.html', '1');
    final c = RemoteDoc.cachePathFor('/tmp', profile, '/www/index.html', '2');
    expect(a, b);
    expect(a == c, isFalse);
    expect(a.endsWith('index.html'), isTrue);
  });

  test('fetch -> edit -> push round trip, conflict check follows the server', () async {
    final fs = FakeFs(files, times);
    final doc = RemoteDoc(profile: profile, remotePath: '/www/index.html', cacheRoot: tmp.path, fs: fs);
    await doc.fetch();
    expect(File(doc.cachePath).readAsStringSync(), '<h1>hi</h1>');
    expect(await doc.changedRemotely(), isFalse);

    await doc.writeCache('<h1>edited</h1>');
    await doc.push();
    expect(files['/www/index.html'], '<h1>edited</h1>');
    expect(await doc.changedRemotely(), isFalse); // our own upload is the new baseline

    files['/www/index.html'] = 'someone else wrote this';
    expect(await doc.changedRemotely(), isTrue);
  });

  test('a failed upload re-opens the connection once and retries', () async {
    final first = FakeFs(files, times)..failUploads = 1;
    final second = FakeFs(files, times);
    final doc = RemoteDoc(
      profile: profile,
      remotePath: '/www/index.html',
      cacheRoot: tmp.path,
      fs: first,
      factory: (_) => second,
    );
    await doc.fetch();
    await doc.writeCache('v2');
    await doc.push();
    expect(files['/www/index.html'], 'v2');
    expect(first.uploads, 1);
    expect(second.connects, 1);
    expect(second.uploads, 1);
  });

  test('when the reconnect fails too, the ORIGINAL error is reported', () async {
    final first = FakeFs(files, times)..failUploads = 5;
    final dead = FakeFs(files, times)..failConnect = true;
    final doc = RemoteDoc(
      profile: profile,
      remotePath: '/www/index.html',
      cacheRoot: tmp.path,
      fs: first,
      factory: (_) => dead,
    );
    await doc.fetch();
    await doc.writeCache('v2');
    await expectLater(doc.push(), throwsA(isA<RemoteError>().having((e) => e.msg, 'msg', 'connection lost')));
    expect(files['/www/index.html'], '<h1>hi</h1>'); // server file untouched
  });

  test('dispose removes the cache; a handed-in connection is not closed', () async {
    final fs = FakeFs(files, times);
    final doc = RemoteDoc(profile: profile, remotePath: '/www/index.html', cacheRoot: tmp.path, fs: fs);
    await doc.fetch();
    final dir = File(doc.cachePath).parent;
    expect(dir.existsSync(), isTrue);
    await doc.dispose();
    await doc.dispose(); // twice is fine
    expect(dir.existsSync(), isFalse);
    expect(fs.closes, 0);
  });

  test('without a handed-in connection one is opened on demand and closed on dispose', () async {
    final made = FakeFs(files, times);
    final doc = RemoteDoc(
      profile: profile,
      remotePath: '/www/index.html',
      cacheRoot: tmp.path,
      factory: (_) => made,
    );
    await doc.fetch();
    expect(made.connects, 1);
    await doc.dispose();
    expect(made.closes, 1);
  });
}
