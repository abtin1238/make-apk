import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/update_service.dart';

void main() {
  test('version comes from the asset name, never from the ABI or build number', () {
    expect(UpdateService.versionOfAsset('AbtinFileManager_0_44_12.zip'), '0.44.12');
    expect(UpdateService.versionOfAsset('AbtinFileManager_0_44_12_x86_64.zip'), '0.44.12');
    expect(UpdateService.versionOfAsset('AbtinFileManager_x86_64_0_44_13.zip'), '0.44.13');
    expect(UpdateService.versionOfAsset('AbtinFileManager-0.45.0-arm64-v8a.apk'), '0.45.0');
    expect(UpdateService.versionOfAsset('AbtinFileManager_0_44_12_build86.zip'), '0.44.12');
    expect(UpdateService.versionOfAsset('AbtinFileManager_x86_64.zip'), isNull);
    expect(UpdateService.versionOfAsset('notes.zip'), isNull);
  });
}
