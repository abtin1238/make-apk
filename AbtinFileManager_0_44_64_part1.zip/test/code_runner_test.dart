import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/code_runner.dart';
import 'package:abtin_file_manager/services/highlighter.dart';

void main() {
  test('runner table: unique ids, known to the highlighter, sane templates', () {
    final seen = <String>{};
    for (final r in CodeRunner.runners) {
      expect(seen.add(r.lang), true, reason: 'duplicate ${r.lang}');
      expect(Hl.def(r.lang) != null, true, reason: '${r.lang} is not a highlighter language');
      expect(r.cmd.contains('{f}'), true, reason: r.lang);
      expect(r.probe.isNotEmpty, true, reason: r.lang);
    }
    expect(CodeRunner.runners.length >= 15, true);
    expect(CodeRunner.supports('python'), true);
    expect(CodeRunner.supports('html'), false);
    expect(CodeRunner.runnerFor('cpp')!.probe, 'g++');
    expect(CodeRunner.runnerFor('nope'), null);
  });

  test('shq quotes single quotes', () {
    expect(CodeRunner.shq('a b'), "'a b'");
    expect(CodeRunner.shq("it's"), "'it'\\''s'");
  });

  group('buildScript', () {
    final py = CodeRunner.runnerFor('python')!;
    final c = CodeRunner.runnerFor('c')!;

    test('run: start marker, alpine check, one proot call, exit marker', () {
      final s = CodeRunner.buildScript(runner: py, fileName: 'main.py', args: 'a b');
      expect(s.startsWith(r"printf '\037ABTIN_RUN\037'"), true);
      expect(s.contains('alpine-release'), true);
      expect(s.contains('ABTIN_NEED_ALPINE'), true);
      expect(s.contains("_alpine_run sh -c 'command -v python3 >/dev/null 2>&1 || exit 199; python3 -u '\\''main.py'\\'' a b'"), true);
      expect(s.contains('ABTIN_NEED:%s'), true);
      expect(s.contains('ABTIN_EXIT:%s'), true);
      expect(s.contains('apk add'), false);
      expect(s.contains('alpine bootstrap'), false);
    });

    test('compiled languages build into /tmp and run the binary, args go to the program', () {
      final s = CodeRunner.buildScript(runner: c, fileName: 'a.c', args: '5');
      expect(s.contains('gcc -O1 -Wall '), true);
      expect(s.contains('-o ${CodeRunner.out} -lm && ${CodeRunner.out} 5'), true);
      expect(s.contains("'gcc musl-dev'"), true);
    });

    test('install mode adds apk add before the run', () {
      final s = CodeRunner.buildScript(runner: c, fileName: 'a.c', pre: RunPre.install);
      final i = s.indexOf('apk add --no-cache gcc musl-dev');
      expect(i > 0, true);
      expect(i < s.indexOf("command -v gcc"), true);
    });

    test('bootstrap mode runs alpine bootstrap and skips the alpine check', () {
      final s = CodeRunner.buildScript(runner: py, fileName: 'a.py', pre: RunPre.bootstrap);
      expect(s.contains('alpine bootstrap ||'), true);
      expect(s.contains('ABTIN_NEED_ALPINE'), false);
    });

    test('file names with quotes and spaces are quoted twice correctly', () {
      final s = CodeRunner.buildScript(runner: py, fileName: "it's me.py");
      expect(s.contains("python3 -u '\\''it'\\''\\'\\'''\\''s me.py'\\'''"), true);
    });
  });

  group('RunOutputFilter', () {
    test('drops everything before the start marker', () {
      final f = RunOutputFilter();
      expect(f.feed('banner\r\n. /tmp/run.sh\r\n'), '');
      expect(f.started, false);
      expect(f.feed('x${RunOutputFilter.start}hello\r\n'), 'hello\r\n');
      expect(f.started, true);
    });

    test('start marker split over chunks', () {
      final f = RunOutputFilter();
      expect(f.feed('junk\u001fABTIN_'), '');
      expect(f.feed('RUN\u001fhi'), 'hi');
    });

    test('exit marker is parsed and removed, also when split', () {
      final f = RunOutputFilter();
      f.feed(RunOutputFilter.start);
      expect(f.feed('out\n\u001fABTIN_EX'), 'out\n');
      expect(f.feed('IT:3\u001f'), '');
      expect(f.exitCode, 3);
      final g = RunOutputFilter();
      expect(g.feed('${RunOutputFilter.start}a\u001fABTIN_EXIT:0\u001fb'), 'ab');
      expect(g.exitCode, 0);
    });

    test('need markers', () {
      final f = RunOutputFilter();
      f.feed('${RunOutputFilter.start}\u001fABTIN_NEED:gcc musl-dev\u001f');
      expect(f.need, 'gcc musl-dev');
      expect(f.needAlpine, false);
      final g = RunOutputFilter();
      g.feed('${RunOutputFilter.start}\u001fABTIN_NEED_ALPINE\u001f');
      expect(g.needAlpine, true);
      expect(g.need, null);
    });

    test('output of a script that never started is kept for display', () {
      final f = RunOutputFilter();
      f.feed('sh: /tmp/run.sh: not found\r\n');
      expect(f.started, false);
      expect(f.unstarted.contains('not found'), true);
    });

    test('ordinary text passes through untouched', () {
      final f = RunOutputFilter();
      f.feed(RunOutputFilter.start);
      expect(f.feed('line 1\r\nline 2\r\n'), 'line 1\r\nline 2\r\n');
    });
  });
}
