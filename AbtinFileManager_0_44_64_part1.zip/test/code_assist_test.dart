import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/code_assist.dart';

void main() {
  group('comment', () {
    test('known styles', () {
      expect(CodeAssist.comment('python')!.open, '#');
      expect(CodeAssist.comment('dart')!.open, '//');
      expect(CodeAssist.comment('sql')!.open, '--');
      expect(CodeAssist.comment('html')!.close, '-->');
      expect(CodeAssist.comment('json'), null);
      expect(CodeAssist.comment(''), null);
    });

    test('comment and uncomment lines with a line prefix', () {
      const src = 'a\n  b\n\nc';
      final r = CodeAssist.toggleComment(src, 0, src.length, 'dart')!;
      expect(r.text, '// a\n  // b\n\n// c'.replaceFirst('  // b', '//   b'));
      final back = CodeAssist.toggleComment(r.text, 0, r.text.length, 'dart')!;
      expect(back.text, src);
    });

    test('indent of the least indented line is kept', () {
      const src = '    x\n      y';
      final r = CodeAssist.toggleComment(src, 0, src.length, 'python')!;
      expect(r.text, '    # x\n    #   y');
      expect(CodeAssist.toggleComment(r.text, 0, r.text.length, 'python')!.text, src);
    });

    test('mixed lines get commented, caret follows the text', () {
      const src = '# a\nb';
      final r = CodeAssist.toggleComment(src, 4, 4, 'python')!;
      expect(r.text, '# a\n# b');
      expect(r.start, 6);
      expect(r.end, 6);
      final one = CodeAssist.toggleComment('x = 1', 3, 3, 'python')!;
      expect(one.text, '# x = 1');
      expect(one.start, 5);
    });

    test('block style wraps every line', () {
      final r = CodeAssist.toggleComment('<p>x</p>', 0, 0, 'html')!;
      expect(r.text, '<!-- <p>x</p> -->');
      expect(CodeAssist.toggleComment(r.text, 0, 0, 'html')!.text, '<p>x</p>');
    });

    test('selection ending after a final newline does not touch the next line', () {
      const src = 'a\nb\nc';
      final r = CodeAssist.toggleComment(src, 0, 4, 'dart')!;
      expect(r.text, '// a\n// b\nc');
    });

    test('nothing to do for blank text or unknown language', () {
      expect(CodeAssist.toggleComment('\n\n', 0, 1, 'dart'), null);
      expect(CodeAssist.toggleComment('x', 0, 1, 'json'), null);
    });
  });

  group('enter', () {
    test('keeps indentation', () {
      final e = CodeAssist.enter('    foo();', 10, 'dart', 4);
      expect(e.insert, '    ');
      expect(e.caret, 4);
    });

    test('indents after an opening bracket and splits {|}', () {
      final a = CodeAssist.enter('if (x) {', 8, 'dart', 2);
      expect(a.insert, '  ');
      final b = CodeAssist.enter('  f() {}', 7, 'dart', 2);
      expect(b.insert, '    \n  ');
      expect(b.caret, 4);
    });

    test('python colon and dedent after return', () {
      expect(CodeAssist.enter('def f():', 8, 'python', 4).insert, '    ');
      expect(CodeAssist.enter('    return 1', 12, 'python', 4).insert, '');
      expect(CodeAssist.enter('        pass', 12, 'python', 4).insert, '    ');
      expect(CodeAssist.enter('x = {', 5, 'python', 4).insert, '    ');
      expect(CodeAssist.enter('# note:', 7, 'python', 4).insert, '');
    });

    test('html opening tag indents, void and closing tags do not', () {
      expect(CodeAssist.enter('<div>', 5, 'html', 2).insert, '  ');
      expect(CodeAssist.enter('<br>', 4, 'html', 2).insert, '');
      expect(CodeAssist.enter('<img src="a" />', 15, 'html', 2).insert, '');
      expect(CodeAssist.enter('</div>', 6, 'html', 2).insert, '');
      expect(CodeAssist.enter('<div></div>', 5, 'html', 2).insert, '  \n');
    });

    test('lua then/do', () {
      expect(CodeAssist.enter('if x then', 9, 'lua', 2).insert, '  ');
    });

    test('tabs are kept when the line uses them', () {
      expect(CodeAssist.enter('\tif (x) {', 9, 'c', 4).insert, '\t\t');
    });
  });

  group('pairing', () {
    test('brackets pair unless a word follows', () {
      expect(CodeAssist.shouldPair('(', 'f', '', 'dart'), true);
      expect(CodeAssist.shouldPair('(', ' ', 'x', 'dart'), false);
      expect(CodeAssist.shouldPair('{', ' ', ')', 'dart'), true);
    });

    test('quotes do not pair inside words or in plain text', () {
      expect(CodeAssist.shouldPair('"', ' ', '', 'dart'), true);
      expect(CodeAssist.shouldPair("'", 'n', '', 'dart'), false);
      expect(CodeAssist.shouldPair('"', '"', '', 'python'), false);
      expect(CodeAssist.shouldPair('"', ' ', '', ''), false);
      expect(CodeAssist.shouldPair("'", ' ', '', 'rust'), false);
      expect(CodeAssist.shouldPair('x', ' ', '', 'dart'), false);
    });

    test('backspace removes the matching closer', () {
      expect(CodeAssist.deletesPair('(', ')', 'dart'), true);
      expect(CodeAssist.deletesPair('(', ']', 'dart'), false);
      expect(CodeAssist.deletesPair('"', '"', 'dart'), true);
      expect(CodeAssist.deletesPair('"', '"', ''), false);
    });
  });

  group('suggest', () {
    test('keywords and words of the file', () {
      const text = 'int counter = 0;\ncounter++;\nretu';
      final r = CodeAssist.suggest(text, text.length, 'c');
      expect(r.contains('return'), true);
      final w = CodeAssist.suggest('counter = 1\ncou', 15, 'python');
      expect(w, ['counter']);
    });

    test('never suggests the word being typed and needs two characters', () {
      expect(CodeAssist.suggest('fo', 2, 'python'), isNot(contains('fo')));
      expect(CodeAssist.suggest('f', 1, 'python'), isEmpty);
      expect(CodeAssist.suggest('abc 12', 6, 'python'), isEmpty);
      expect(CodeAssist.suggest('foobar foo', 10, 'python'), ['foobar']);
      expect(CodeAssist.suggest('foo|bar', 3, ''), isEmpty);
    });

    test('ordering: frequent words, case-matching prefix first', () {
      const text = 'alpha alpha alpha alphabet Alpine\nalp';
      final r = CodeAssist.suggest(text, text.length, '');
      expect(r.first, 'alpha');
      expect(r.contains('Alpine'), true);
      expect(r.indexOf('Alpine') > r.indexOf('alphabet'), true);
    });

    test('wordStart', () {
      expect(CodeAssist.wordStart('x = foo_bar', 11), 4);
      expect(CodeAssist.wordStart('x = foo_bar', 3), 3);
    });
  });
}
