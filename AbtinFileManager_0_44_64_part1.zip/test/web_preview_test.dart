import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/web_preview.dart';

void main() {
  test('supportsPath knows previewable files', () {
    for (final f in ['a.html', 'a.HTM', 'a.svg', 'a.css', 'a.md', 'a.js', 'a.mjs']) {
      expect(WebPreview.supportsPath('/x/$f'), true, reason: f);
    }
    for (final f in ['a.py', 'a.txt', 'a.scss', 'a.json']) {
      expect(WebPreview.supportsPath('/x/$f'), false, reason: f);
    }
  });

  test('html gets a viewport tag once', () {
    final a = WebPreview.build('/x/a.html', '<html><head><title>t</title></head><body>hi</body></html>');
    expect(a.contains('name="viewport"'), true);
    expect(a.contains('<body>hi</body>'), true);
    final b = WebPreview.build('/x/a.html', a);
    expect('viewport'.allMatches(b).length, 'viewport'.allMatches(a).length);
    final c = WebPreview.build('/x/a.html', '<p>fragment</p>');
    expect(c.contains('viewport'), true);
    expect(c.contains('<p>fragment</p>'), true);
  });

  test('svg is wrapped in a page without the xml header', () {
    final s = WebPreview.build('/x/a.svg', '<?xml version="1.0"?>\n<svg width="10" height="10"></svg>');
    expect(s.contains('<?xml'), false);
    expect(s.contains('<svg width="10"'), true);
  });

  test('js is wrapped and cannot close the script tag early', () {
    final s = WebPreview.build('/x/a.js', 'console.log("</script>");');
    expect(s.contains('console.log('), true);
    expect(s.contains(r'<\/script'), true);
    expect('</script>'.allMatches(s).length, 1);
  });

  test('css uses the sibling html page, else a sample page', () {
    final dir = Directory.systemTemp.createTempSync('wp_test');
    try {
      final alone = WebPreview.build('${dir.path}/style.css', 'h1{color:red}');
      expect(alone.contains('h1{color:red}'), true);
      expect(alone.contains('Heading 1'), true);
      File('${dir.path}/style.html').writeAsStringSync('<html><head></head><body><b id="mine">x</b></body></html>');
      final withPage = WebPreview.build('${dir.path}/style.css', 'h1{color:red}');
      expect(withPage.contains('id="mine"'), true);
      expect(withPage.contains('h1{color:red}'), true);
      expect(withPage.contains('Heading 1'), false);
      expect(withPage.indexOf('h1{color:red}') < withPage.indexOf('<body>'), true);
    } finally {
      dir.deleteSync(recursive: true);
    }
  });

  test('markdown converter', () {
    const md = '# Title\n\nHello **bold** and *it* and `a<b` [l](http://x.y)\n\n- one\n- two\n\n1. a\n2. b\n\n> quote\n\n```\nx < y\n```\n\n| A | B |\n|---|---|\n| 1 | 2 |\n\n---\n![img](pic.png)\n';
    final h = WebPreview.markdown(md);
    expect(h.contains('<h1>Title</h1>'), true);
    expect(h.contains('<strong>bold</strong>'), true);
    expect(h.contains('<em>it</em>'), true);
    expect(h.contains('<code>a&lt;b</code>'), true);
    expect(h.contains('<a href="http://x.y">l</a>'), true);
    expect(h.contains('<ul>'), true);
    expect(h.contains('<ol>'), true);
    expect(h.contains('<li>two</li>'), true);
    expect(h.contains('<blockquote>quote</blockquote>'), true);
    expect(h.contains('<pre><code>x &lt; y</code></pre>'), true);
    expect(h.contains('<th>A</th>'), true);
    expect(h.contains('<td>2</td>'), true);
    expect(h.contains('<hr>'), true);
    expect(h.contains('<img alt="img" src="pic.png">'), true);
  });

  test('markdown escapes raw html', () {
    final h = WebPreview.markdown('<script>alert(1)</script>');
    expect(h.contains('<script>'), false);
    expect(h.contains('&lt;script&gt;'), true);
  });
}
