import 'package:flutter_test/flutter_test.dart';
import 'package:abtin_file_manager/services/highlighter.dart';

void main() {
  test('at least 50 languages with unique ids', () {
    expect(Hl.all.length >= 50, true);
    expect(Hl.all.map((d) => d.id).toSet().length, Hl.all.length);
  });

  test('language detection by extension, file name and shebang', () {
    expect(Hl.langOf('/a/b/main.py'), 'python');
    expect(Hl.langOf('/a/b/Main.CPP'), 'cpp');
    expect(Hl.langOf('/a/b/App.java'), 'java');
    expect(Hl.langOf('/a/Dockerfile'), 'dockerfile');
    expect(Hl.langOf('/a/Makefile'), 'makefile');
    expect(Hl.langOf('/a/CMakeLists.txt'), 'cmake');
    expect(Hl.langOf('/a/.bashrc'), 'bash');
    expect(Hl.langOf('/a/notes.txt'), '');
    expect(Hl.langOfContent('/a/run', '#!/usr/bin/env python3'), 'python');
    expect(Hl.langOfContent('/a/run', '#!/bin/bash'), 'bash');
    expect(Hl.langOfContent('/a/run', 'hello'), '');
    expect(Hl.nameOf('cpp'), 'C++');
  });

  test('every language builds a regex and spans always rebuild the exact text', () {
    const sample = '''#!/bin/sh
// line "str" 'c' 1234 0xFF 3.14e5
/* block */ -- sql comment
% percent  ; semi  ! bang  REM batch
<div class="a">text</div> <!-- c -->
{"k": [1, true, null], "s": 'x'}
def foo(self): return @dec \$var ::label
.text mov eax, 1 \\begin{x} \$x\$
\'\'\'unterminated
"open string
/* open block''';
    for (final d in Hl.all) {
      for (final dark in [true, false]) {
        final spans = Hl.spans(sample, d.id, dark);
        expect(spans.map((s) => s.text).join(), sample, reason: d.id);
      }
    }
  });

  test('keywords, strings and comments get colours', () {
    final sp = Hl.spans('int x = 1; // hi', 'c', true);
    expect(sp.any((s) => s.text == 'int' && s.style?.color != null), true);
    expect(sp.any((s) => s.text == '// hi' && s.style?.color != null), true);
    final py = Hl.spans('x = "a" # c', 'python', true);
    expect(py.any((s) => s.text == '"a"' && s.style?.color != null), true);
  });

  test('unknown language returns the plain text', () {
    final sp = Hl.spans('abc', 'nope', true);
    expect(sp.length, 1);
    expect(sp.first.text, 'abc');
  });
}
