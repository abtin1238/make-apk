package ir.abtin.filemanager;

import java.io.File;
import java.io.IOException;

/** Prepares the private package prefix and the shell init file used by the app terminal. */
public final class PkgEnv {
    private PkgEnv() {}

    /**
     * Creates $filesDir/usr, (re)writes etc/shrc and etc/aliases.sh and returns the extra
     * environment for the PTY child ("KEY=VALUE" lines; PATH_PREPEND is handled natively).
     */
    public static String prepare(String filesDir, String apkPath, String androidAbi) throws IOException {
        return prepare(filesDir, apkPath, androidAbi, "");
    }

    /** nativeDir = ApplicationInfo.nativeLibraryDir (executable even on Android 10+; holds libproot.so if bundled). */
    public static String prepare(String filesDir, String apkPath, String androidAbi, String nativeDir) throws IOException {
        return prepare(filesDir, apkPath, androidAbi, nativeDir, false);
    }

    /** bashFirst = the app terminal screen: after the init file the shell enters Alpine's bash when it is installed. */
    public static String prepare(String filesDir, String apkPath, String androidAbi, String nativeDir, boolean bashFirst) throws IOException {
        return prepare(filesDir, apkPath, androidAbi, nativeDir, bashFirst, false);
    }

    /** claudeMode = editor "Claude Code" tab: the shell installs Termux + Node + Claude Code by itself and starts it. */
    public static String prepare(String filesDir, String apkPath, String androidAbi, String nativeDir, boolean bashFirst, boolean claudeMode) throws IOException {
        return prepare(filesDir, apkPath, androidAbi, nativeDir, bashFirst, claudeMode, "");
    }

    /** profile = "termux" | "alpine" | "sh" (VS Code style default terminal profile; empty = legacy autoshell/autobash files). */
    public static String prepare(String filesDir, String apkPath, String androidAbi, String nativeDir, boolean bashFirst, boolean claudeMode, String profile) throws IOException {
        File prefix = new File(filesDir, "usr");
        PkgCli cli = new PkgCli(prefix);
        cli.ensureDirs();
        String linker = new File("/system/bin/linker64").exists() ? "/system/bin/linker64" : "/system/bin/linker";
        String p = prefix.getPath();
        String shrc =
                "# Abtin terminal init (generated at every session start; put your own settings in $PREFIX/etc/shrc.local)\n"
                        + "export PREFIX='" + p + "'\n"
                        + "export ABTIN_LINKER='" + linker + "'\n"
                        + "export ABTIN_ABI='" + androidAbi.replace("'", "'\\''") + "'\n"
                        + "export ABTIN_APK='" + apkPath.replace("'", "'\\''") + "'\n"
                        + "export ABTIN_NATIVE='" + nativeDir.replace("'", "'\\''") + "'\n"
                        + "export LD_LIBRARY_PATH=\"$PREFIX/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}\"\n"
                        + "pkgnative() {\n"
                        + "  CLASSPATH=\"$ABTIN_APK\" /system/bin/app_process /system/bin ir.abtin.filemanager.PkgCli \"$@\"\n"
                        + "  _pkg_rc=$?\n"
                        + "  [ -r \"$PREFIX/etc/aliases.sh\" ] && . \"$PREFIX/etc/aliases.sh\"\n"
                        + "  return $_pkg_rc\n"
                        + "}\n"
                        + "pkg() {\n"
                        + "  if [ -f \"$PREFIX/alpine/etc/alpine-release\" ]; then\n"
                        + "    case \"$1\" in\n"
                        + "      install|i|add) shift; _alpine_run apk add --no-cache \"$@\"; _p_rc=$?; _alpine_aliases; return $_p_rc ;;\n"
                        + "      uninstall|remove|rm|purge|del) shift; _alpine_run apk del \"$@\"; _p_rc=$?; _alpine_aliases; return $_p_rc ;;\n"
                        + "      update|upgrade|up|full-upgrade|dist-upgrade) _alpine_run apk upgrade --no-cache ;;\n"
                        + "      search|s) shift; _alpine_run apk search --no-cache -v \"$@\" ;;\n"
                        + "      show|info) shift; _alpine_run apk info --no-cache -a \"$@\" ;;\n"
                        + "      list-installed|list|ls) _alpine_run apk info -v ;;\n"
                        + "      files) shift; _alpine_run apk info -L \"$@\" ;;\n"
                        + "      *) pkgnative \"$@\" ;;\n"
                        + "    esac\n"
                        + "    return $?\n"
                        + "  fi\n"
                        + "  pkgnative \"$@\"; _p_rc=$?\n"
                        + "  if [ $_p_rc -ne 0 ]; then echo \"Tip: type 'bash' to install the full Linux environment; then 'pkg install <package>' installs real packages (apk).\" >&2; fi\n"
                        + "  return $_p_rc\n"
                        + "}\n"
                        + "alias apt=pkg\n"
                        + "_alpine_run() {\n"
                        + "  _AR=\"$PREFIX/alpine\"\n"
                        + "  [ -f \"$_AR/etc/alpine-release\" ] || { echo 'alpine: not installed (run: alpine setup)' >&2; return 1; }\n"
                        + "  if [ -n \"$ABTIN_NATIVE\" ] && [ -x \"$ABTIN_NATIVE/libproot.so\" ]; then\n"
                        + "    _PR=\"$ABTIN_NATIVE/libproot.so\"; _PX=''\n"
                        + "    [ -x \"$ABTIN_NATIVE/libproot-loader.so\" ] && export PROOT_LOADER=\"$ABTIN_NATIVE/libproot-loader.so\"\n"
                        + "    [ -x \"$ABTIN_NATIVE/libproot-loader32.so\" ] && export PROOT_LOADER_32=\"$ABTIN_NATIVE/libproot-loader32.so\"\n"
                        + "  elif [ -f \"$PREFIX/bin/proot\" ]; then _PR=\"$PREFIX/bin/proot\"; _PX=\"$ABTIN_LINKER\"\n"
                        + "  else echo 'alpine: proot missing (run: alpine bootstrap)' >&2; return 1; fi\n"
                        + "  export PROOT_TMP_DIR=\"$PREFIX/tmp\"\n"
                        + "  [ -f \"$PREFIX/etc/proot-noseccomp\" ] && export PROOT_NO_SECCOMP=1\n"
                        + "  [ -n \"$_PX\" ] && [ -f \"$PREFIX/libexec/proot-loader\" ] && export PROOT_LOADER=\"$PREFIX/libexec/proot-loader\"\n"
                        + "  [ -d \"$_AR/workspace\" ] || mkdir -p \"$_AR/workspace\"\n"
                        + "  [ -f \"$PREFIX/etc/abtin-npm-fix\" ] && [ -d \"$_AR/usr/local/bin\" ] && cp -f \"$PREFIX/etc/abtin-npm-fix\" \"$_AR/usr/local/bin/abtin-npm-fix\" 2>/dev/null && chmod 755 \"$_AR/usr/local/bin/abtin-npm-fix\" 2>/dev/null\n"
                        + "  _SD=''; [ -d /storage/emulated/0 ] && _SD='-b /storage/emulated/0:/sdcard'\n"
                        + "  _ASH=/bin/sh; [ -x \"$_AR/bin/bash\" ] && _ASH=/bin/bash\n"
                        + "  $_PX \"$_PR\" ${ABTIN_PROOT_V:+-v \"$ABTIN_PROOT_V\"} --kill-on-exit --link2symlink -0 -r \"$_AR\" -b /dev -b /proc -b /sys -b \"$PWD:/workspace\" $_SD -w /workspace /usr/bin/env -i HOME=/root USER=root SHELL=\"$_ASH\" LANG=C.UTF-8 UV_USE_IO_URING=0 PIP_BREAK_SYSTEM_PACKAGES=1 TERM=\"${TERM:-xterm-256color}\" PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin \"$@\"\n"
                        + "}\n"
                        + "_npm_repair() {\n"
                        + "  mkdir -p \"$PREFIX/alpine/usr/local/bin\"\n"
                        + "  cp -f \"$PREFIX/etc/abtin-npm-fix\" \"$PREFIX/alpine/usr/local/bin/abtin-npm-fix\" && chmod 755 \"$PREFIX/alpine/usr/local/bin/abtin-npm-fix\"\n"
                        + "  _alpine_run /usr/local/bin/abtin-npm-fix\n"
                        + "}\n"
                        + "_alpine_aliases() {\n"
                        + "  [ -f \"$PREFIX/alpine/etc/alpine-release\" ] || return 0\n"
                        + "  for _c in apk python3 python pip pip3 git node npm npx curl wget nano vim make gcc; do\n"
                        + "    for _p in /sbin /usr/bin /bin /usr/local/bin; do\n"
                        + "      if [ -e \"$PREFIX/alpine$_p/$_c\" ] || [ -L \"$PREFIX/alpine$_p/$_c\" ]; then alias \"$_c=_alpine_run $_c\"; break; fi\n"
                        + "    done\n"
                        + "  done\n"
                        + "  [ -x \"$PREFIX/alpine/usr/bin/python3\" ] && alias python='_alpine_run python3'\n"
                        + "  [ -x \"$PREFIX/alpine/usr/bin/pip3\" ] && alias pip='_alpine_run pip3'\n"
                        + "  if [ -e \"$PREFIX/alpine/usr/bin/node\" ]; then\n"
                        + "    _NB=/usr/lib/node_modules/npm/bin\n"
                        + "    unalias npm npx 2>/dev/null\n"
                        + "    if [ -f \"$PREFIX/alpine$_NB/npm-cli.js\" ]; then\n"
                        + "      alias npm=\"_alpine_run node $_NB/npm-cli.js\"\n"
                        + "      alias npx=\"_alpine_run node $_NB/npx-cli.js\"\n"
                        + "    else\n"
                        + "      npm() { _npm_repair && _alpine_run node /usr/lib/node_modules/npm/bin/npm-cli.js \"$@\"; }\n"
                        + "      npx() { _npm_repair && _alpine_run node /usr/lib/node_modules/npm/bin/npx-cli.js \"$@\"; }\n"
                        + "    fi\n"
                        + "  fi\n"
                        + "}\n"
                        + "_alpine_prep_bash() {\n"
                        + "  _AR=\"$PREFIX/alpine\"\n"
                        + "  [ -x \"$_AR/bin/bash\" ] || return 0\n"
                        + "  [ -f \"$_AR/root/.bashrc\" ] || cp \"$PREFIX/etc/abtin-bashrc\" \"$_AR/root/.bashrc\" 2>/dev/null\n"
                        + "  [ -f \"$_AR/root/.bashrc\" ] && grep -q '^PS1=.*root@abtin' \"$_AR/root/.bashrc\" 2>/dev/null && sed -i -e '/^PS1=.*root@abtin/{r '\"$PREFIX/etc/abtin-ps1\" -e 'd;}' \"$_AR/root/.bashrc\" 2>/dev/null\n"
                        + "  [ -f \"$_AR/root/.bashrc\" ] && grep -q -F '\\\\[' \"$_AR/root/.bashrc\" 2>/dev/null && sed -i -e '/^PS1=.*0;32m/{r '\"$PREFIX/etc/abtin-ps1\" -e 'd;}' \"$_AR/root/.bashrc\" 2>/dev/null\n"
                        + "  [ -f \"$_AR/root/.bash_profile\" ] || cp \"$PREFIX/etc/abtin-bash_profile\" \"$_AR/root/.bash_profile\" 2>/dev/null\n"
                        + "  [ -f \"$_AR/etc/passwd\" ] && sed -i 's#^\\(root:[^:]*:[^:]*:[^:]*:[^:]*:[^:]*\\):/bin/ash$#\\1:/bin/bash#' \"$_AR/etc/passwd\" 2>/dev/null\n"
                        + "  mkdir -p \"$_AR/usr/local/bin\" 2>/dev/null\n"
                        + "  cp \"$PREFIX/etc/abtin-full-install\" \"$_AR/usr/local/bin/abtin-full-install\" 2>/dev/null && chmod 755 \"$_AR/usr/local/bin/abtin-full-install\" 2>/dev/null\n"
                        + "  cp -f \"$PREFIX/etc/abtin-npm-fix\" \"$_AR/usr/local/bin/abtin-npm-fix\" 2>/dev/null && chmod 755 \"$_AR/usr/local/bin/abtin-npm-fix\" 2>/dev/null\n"
                        + "  cp \"$PREFIX/etc/abtin-bash-extras\" \"$_AR/root/.abtin_bash_extras\" 2>/dev/null\n"
                        + "  [ -f \"$_AR/root/.inputrc\" ] || cp \"$PREFIX/etc/abtin-inputrc\" \"$_AR/root/.inputrc\" 2>/dev/null\n"
                        + "  grep -q abtin_bash_extras \"$_AR/root/.bashrc\" 2>/dev/null || echo '[ -r ~/.abtin_bash_extras ] && . ~/.abtin_bash_extras' >> \"$_AR/root/.bashrc\" 2>/dev/null\n"
                        + "  return 0\n"
                        + "}\n"
                        + "_alpine_bash_pkgs() {\n"
                        + "  _alpine_run apk add --no-cache bash bash-completion coreutils findutils grep sed gawk less nano curl wget openssh-client tar ncurses || return 1\n"
                        + "  _alpine_prep_bash\n"
                        + "  _alpine_run /usr/local/bin/abtin-full-install\n"
                        + "  return 0\n"
                        + "}\n"
                        + "bash() {\n"
                        + "  if [ ! -f \"$PREFIX/alpine/etc/alpine-release\" ]; then _abtin_need_alpine bash \"$@\"; return $?; fi\n"
                        + "  if [ ! -x \"$PREFIX/alpine/bin/bash\" ]; then\n"
                        + "    echo 'bash: installing a real bash (and basic tools) from the Alpine repository, one time...' >&2\n"
                        + "    _alpine_bash_pkgs || { echo 'bash: install failed (check the internet connection)' >&2; return 1; }\n"
                        + "  fi\n"
                        + "  _alpine_prep_bash\n"
                        + "  if [ $# -eq 0 ]; then _alpine_run /bin/bash -l; else _alpine_run /bin/bash \"$@\"; fi\n"
                        + "}\n"
                        + "autobash() {\n"
                        + "  case \"$1\" in\n"
                        + "    off) : > \"$PREFIX/etc/no-auto-bash\"; echo 'autobash: off - the terminal now starts in the Android shell (type bash to enter bash)' ;;\n"
                        + "    on) rm -f \"$PREFIX/etc/no-auto-bash\"; echo 'autobash: on - the terminal starts in bash' ;;\n"
                        + "    *) echo 'usage: autobash on|off' >&2; return 2 ;;\n"
                        + "  esac\n"
                        + "}\n"
                        + "autoshell() {\n"
                        + "  case \"$1\" in\n"
                        + "    termux) rm -f \"$PREFIX/etc/auto-alpine\"; echo 'autoshell: termux - new terminals start in Termux (default)' ;;\n"
                        + "    alpine) : > \"$PREFIX/etc/auto-alpine\"; echo 'autoshell: alpine - new terminals start in Alpine bash' ;;\n"
                        + "    *) if [ -f \"$PREFIX/etc/auto-alpine\" ]; then echo 'autoshell: alpine'; else echo 'autoshell: termux'; fi; echo 'usage: autoshell termux|alpine' >&2 ;;\n"
                        + "  esac\n"
                        + "}\n"
                        + "alpine() {\n"
                        + "  case \"$1\" in\n"
                        + "    setup|status|proot|remove|doctor)\n"
                        + "      CLASSPATH=\"$ABTIN_APK\" /system/bin/app_process /system/bin ir.abtin.filemanager.AlpineCli \"$@\"\n"
                        + "      _a_rc=$?; _alpine_aliases; return $_a_rc ;;\n"
                        + "    ''|shell) bash ;;\n"
                        + "    sh) _alpine_run /bin/sh -l ;;\n"
                        + "    run) shift; _alpine_run \"$@\" ;;\n"
                        + "    update) _alpine_run apk update ;;\n"
                        + "    upgrade) _alpine_run apk upgrade ;;\n"
                        + "    install|add) shift; _alpine_run apk add --no-cache \"$@\"; _a_rc=$?; _alpine_aliases; return $_a_rc ;;\n"
                        + "    uninstall|del) shift; _alpine_run apk del \"$@\"; _a_rc=$?; _alpine_aliases; return $_a_rc ;;\n"
                        + "    npm-fix) _npm_repair; _a_rc=$?; _alpine_aliases; return $_a_rc ;;\n"
                        + "    node-reset)\n"
                        + "      echo 'Removing Node.js and npm completely, then reinstalling...'\n"
                        + "      _alpine_run apk del nodejs npm >/dev/null 2>&1\n"
                        + "      if [ -n \"$PREFIX\" ] && [ -d \"$PREFIX/alpine/usr\" ]; then\n"
                        + "        rm -rf \"$PREFIX/alpine/usr/lib/node_modules\" \"$PREFIX/alpine/usr/include/node\"\n"
                        + "        rm -f \"$PREFIX/alpine/usr/bin/node\" \"$PREFIX/alpine/usr/bin/npm\" \"$PREFIX/alpine/usr/bin/npx\" \"$PREFIX/alpine/usr/bin/corepack\"\n"
                        + "      fi\n"
                        + "      _alpine_run apk add --no-cache nodejs npm; _a_rc=$?\n"
                        + "      _alpine_aliases\n"
                        + "      if [ $_a_rc -eq 0 ]; then\n"
                        + "        echo \"node: $(_alpine_run node -v)\"; echo \"npm:  $(_alpine_run node /usr/lib/node_modules/npm/bin/npm-cli.js -v)\"\n"
                        + "      fi\n"
                        + "      return $_a_rc ;;\n"
                        + "    bootstrap)\n"
                        + "      if [ -f \"$PREFIX/alpine/.abtin-alpine\" ] && ! grep -q '^branch=v3\\.22$' \"$PREFIX/alpine/.abtin-alpine\"; then\n"
                        + "        echo 'Replacing the installed Alpine (apk v3 fails under proot) with Alpine v3.22 (apk 2)...'\n"
                        + "        alpine remove -y || return 1\n"
                        + "      fi\n"
                        + "      [ -f \"$PREFIX/alpine/etc/alpine-release\" ] || alpine setup -y || return 1\n"
                        + "      if [ ! -x \"$PREFIX/bin/proot\" ] && [ ! -x \"$ABTIN_NATIVE/libproot.so\" ]; then\n"
                        + "        _abi=\"$ABTIN_ABI\"\n"
                        + "        case \"$_abi\" in arm64-v8a) _pa=aarch64 ;; armeabi-v7a) _pa=armv7 ;; x86_64) _pa=x86_64 ;; x86) _pa=x86 ;; *) echo \"Unsupported Android ABI: $_abi\" >&2; return 1 ;; esac\n"
                        + "        alpine proot \"https://skirsten.github.io/proot-portable-android-binaries/$_pa/proot\" || return 1\n"
                        + "      fi\n"
                        + "      _alpine_run apk update && _alpine_run apk add --no-cache python3 py3-pip git nodejs npm && _alpine_bash_pkgs; _a_rc=$?; _alpine_prep_bash; _alpine_aliases; return $_a_rc ;;\n"
                        + "    *) echo 'usage: alpine [shell|sh|run CMD|npm-fix|install PKG..|uninstall PKG..|update|upgrade|bootstrap|node-reset|setup|proot FILE|status|remove|doctor]' >&2; return 2 ;;\n"
                        + "  esac\n"
                        + "}\n"
                        + "_proot_prep() {\n"
                        + "  if [ -n \"$ABTIN_NATIVE\" ] && [ -x \"$ABTIN_NATIVE/libproot.so\" ]; then\n"
                        + "    _PR=\"$ABTIN_NATIVE/libproot.so\"; _PX=''\n"
                        + "    [ -x \"$ABTIN_NATIVE/libproot-loader.so\" ] && export PROOT_LOADER=\"$ABTIN_NATIVE/libproot-loader.so\"\n"
                        + "    [ -x \"$ABTIN_NATIVE/libproot-loader32.so\" ] && export PROOT_LOADER_32=\"$ABTIN_NATIVE/libproot-loader32.so\"\n"
                        + "  elif [ -f \"$PREFIX/bin/proot\" ]; then _PR=\"$PREFIX/bin/proot\"; _PX=\"$ABTIN_LINKER\"\n"
                        + "  else echo 'termux: proot missing' >&2; return 1; fi\n"
                        + "  export PROOT_TMP_DIR=\"$PREFIX/tmp\"\n"
                        + "  [ -f \"$PREFIX/etc/proot-noseccomp\" ] && export PROOT_NO_SECCOMP=1\n"
                        + "  [ -n \"$_PX\" ] && [ -f \"$PREFIX/libexec/proot-loader\" ] && export PROOT_LOADER=\"$PREFIX/libexec/proot-loader\"\n"
                        + "  return 0\n"
                        + "}\n"
                        // NB: do not use /system/bin/env to drop LD_*: nativeLibraryDir contains "==" so env takes the proot path for NAME=VALUE.
                        + "_termux_run() {\n"
                        + "  _TR=\"$PREFIX/termux/files\"\n"
                        + "  { [ -e \"$_TR/usr/bin/sh\" ] || [ -L \"$_TR/usr/bin/sh\" ]; } || { echo 'termux: not installed (run: termux setup)' >&2; return 1; }\n"
                        + "  _proot_prep || return 1\n"
                        + "  mkdir -p \"$_TR/home\" \"$_TR/usr/tmp\" \"$_TR/usr/var/log/apt\" \"$PREFIX/termux/cache/apt/archives/partial\" 2>/dev/null\n"
                        // The bootstrap's second-stage script reads `id -u 2>&1`; Android's "linker: failed to find generated
                        // linker configuration" warning lands in that capture and the uid check fails. Keep stderr out of it.
                        + "  _S2=\"$_TR/usr/etc/termux/termux-bootstrap/second-stage/termux-bootstrap-second-stage.sh\"\n"
                        + "  [ -f \"$_S2\" ] && grep -q 'id -u 2>&1' \"$_S2\" 2>/dev/null && sed -i 's#id -u 2>&1#id -u 2>/dev/null#' \"$_S2\" 2>/dev/null\n"
                        + "  _TT=/data/data/com.termux/files\n"
                        + "  _SD=''; [ -d /storage/emulated/0 ] && _SD='-b /storage/emulated/0:/sdcard'\n"
                        + "  _LC=''; [ -d /linkerconfig ] && _LC='-b /linkerconfig'\n"
                        // start in the folder the command was run from when it is on shared storage (shown as /sdcard/...), else in Termux's home
                        + "  _WD=\"$_TT/home\"\n"
                        + "  case \"$PWD\" in /storage/emulated/0|/storage/emulated/0/*) [ -n \"$_SD\" ] && _WD=\"/sdcard${PWD#/storage/emulated/0}\" ;; esac\n"
                        + "  ( unset LD_LIBRARY_PATH LD_PRELOAD; $_PX \"$_PR\" ${ABTIN_PROOT_V:+-v \"$ABTIN_PROOT_V\"} --kill-on-exit --link2symlink -r / -b \"$_TR:$_TT\" -b \"$PREFIX/termux/cache:/data/data/com.termux/cache\" $_LC $_SD -w \"$_WD\" \"$_TT/usr/bin/env\" HOME=\"$_TT/home\" PREFIX=\"$_TT/usr\" TMPDIR=\"$_TT/usr/tmp\" PATH=\"$_TT/usr/bin\" LANG=en_US.UTF-8 TERM=\"${TERM:-xterm-256color}\" SHELL=\"$_TT/usr/bin/bash\" ANDROID_ROOT=\"${ANDROID_ROOT:-/system}\" ANDROID_DATA=\"${ANDROID_DATA:-/data}\" ABTIN_TERMUX=1 \"$@\" )\n"
                        + "}\n"
                        + "_termux_aliases() {\n"
                        + "  [ -f \"$PREFIX/termux/.abtin-termux\" ] || return 0\n"
                        + "  for _c in node npm npx python python3 pip pip3 git; do\n"
                        + "    { [ -e \"$PREFIX/termux/files/usr/bin/$_c\" ] || [ -L \"$PREFIX/termux/files/usr/bin/$_c\" ]; } && alias \"$_c=_termux_run $_c\"\n"
                        + "  done\n"
                        + "  return 0\n"
                        + "}\n"
                        + "termux() {\n"
                        + "  case \"$1\" in\n"
                        + "    setup|status|remove)\n"
                        + "      CLASSPATH=\"$ABTIN_APK\" /system/bin/app_process /system/bin ir.abtin.filemanager.TermuxCli \"$@\"\n"
                        + "      _t_rc=$?; _termux_aliases; return $_t_rc ;;\n"
                        + "    ''|shell)\n"
                        + "      if [ ! -f \"$PREFIX/termux/.abtin-termux\" ]; then\n"
                        + "        printf 'Install the Termux environment now (bundled with the app, no download)? [Y/n] ' >&2\n"
                        + "        read _ans\n"
                        + "        case \"$_ans\" in n|N|no|NO) return 1 ;; esac\n"
                        + "        termux setup -y || return 1\n"
                        + "      fi\n"
                        + "      if [ -e \"$PREFIX/termux/files/usr/bin/bash\" ] || [ -L \"$PREFIX/termux/files/usr/bin/bash\" ]; then _termux_run bash -l; else _termux_run sh -l; fi ;;\n"
                        + "    run) shift; _termux_run \"$@\" ;;\n"
                        + "    pkg|apt|apt-get|dpkg)\n"
                        + "      _termux_run \"$@\"; _t_rc=$?; _termux_aliases; return $_t_rc ;;\n"
                        + "    *) echo 'usage: termux [shell|run CMD|pkg install PKG..|setup [file|url]|status|remove]' >&2; return 2 ;;\n"
                        + "  esac\n"
                        + "}\n"
                        + "_abtin_need_alpine() {\n"
                        + "  _cmd=\"$1\"; shift\n"
                        + "  echo \"$_cmd: the Linux environment (Alpine: bash, Python, Node.js, apk packages) is not installed yet.\" >&2\n"
                        + "  printf 'Install it now (alpine bootstrap, ~100-200 MB download)? [Y/n] ' >&2\n"
                        + "  read _ans\n"
                        + "  case \"$_ans\" in n|N|no|NO) return 1 ;; esac\n"
                        + "  alpine bootstrap || return 1\n"
                        + "  _alpine_run \"$_cmd\" \"$@\"\n"
                        + "}\n"
                        + "python() { _abtin_need_alpine python3 \"$@\"; }\n"
                        + "python3() { _abtin_need_alpine python3 \"$@\"; }\n"
                        + "pip() { _abtin_need_alpine pip3 \"$@\"; }\n"
                        + "pip3() { _abtin_need_alpine pip3 \"$@\"; }\n"
                        + "node() { _abtin_need_alpine node \"$@\"; }\n"
                        + "npm() { _abtin_need_alpine npm \"$@\"; }\n"
                        + "npx() { _abtin_need_alpine npx \"$@\"; }\n"
                        + "# Termux-style prompt: green working directory (~ for home), then $\n"
                        + "_abtin_ps1_pwd() {\n"
                        + "  case \"$PWD\" in\n"
                        + "    \"$HOME\") printf '~' ;;\n"
                        + "    \"$HOME\"/*) printf '~/%s' \"${PWD#\"$HOME\"/}\" ;;\n"
                        + "    *) printf '%s' \"$PWD\" ;;\n"
                        + "  esac\n"
                        + "}\n"
                        + "_e=$(printf '\\033')\n"
                        + "PS1=\"${_e}[0;32m\\$(_abtin_ps1_pwd)${_e}[0m ${_e}[0;97m\\$${_e}[0m \"\n"
                        + "alias ls='ls --color=auto'\n"
                        + "if [ -n \"$ABTIN_BASH\" ] && [ -z \"$ABTIN_WELCOME_DONE\" ]; then\n"
                        + "  export ABTIN_WELCOME_DONE=1\n"
                        + "  printf 'Welcome to Abtin Terminal\\n\\nWorking with packages:\\n - Search:  pkg search <query>\\n - Install: pkg install <package>\\n - Upgrade: pkg upgrade\\n\\n'\n"
                        + "fi\n"
                        + "alias ll='ls -lA'\n"
                        + "[ -r \"$PREFIX/etc/aliases.sh\" ] && . \"$PREFIX/etc/aliases.sh\"\n"
                        + "_alpine_aliases\n"
                        + "_termux_aliases\n"
                        + "[ -r \"$PREFIX/etc/shrc.local\" ] && . \"$PREFIX/etc/shrc.local\"\n"
                        // Claude Code tab: install Termux (bundled), Node.js and Claude Code without any prompt, then start it.
                        // The install script runs INSIDE Termux (the outer helpers such as _termux_run do not exist there).
                        + "abtin_claude() {\n"
                        + "  { [ -f \"$PREFIX/termux/.abtin-termux\" ] || termux setup -y; } || { echo '[x] Termux install failed' >&2; return 1; }\n"
                        + "  _termux_aliases\n"
                        + "  _CS=\"$PREFIX/termux/files/home/.abtin-claude.sh\"\n"
                        + "  mkdir -p \"$PREFIX/termux/files/home\"\n"
                        + "  cat > \"$_CS\" <<'ABTIN_CLAUDE_EOF'\n"
                        + "export DISABLE_AUTOUPDATER=1 CLAUDE_CODE_DISABLE_AUTOUPDATER=1\n"
                        + "CLI=\"$PREFIX/lib/node_modules/@anthropic-ai/claude-code/cli.js\"\n"
                        + "[ -f \"$HOME/.abtin-claude.env\" ] && . \"$HOME/.abtin-claude.env\"\n"
                        + "chmod 600 \"$HOME/.abtin-claude.env\" 2>/dev/null\n"
                        + "fail() { echo \"[x] $1\"; echo \"    retry: bash ~/.abtin-claude.sh\"; exec bash -l; }\n"
                        + "if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then\n"
                        + "  echo '== Installing Node.js (one time) =='\n"
                        + "  pkg update -y >/dev/null 2>&1\n"
                        + "  pkg install -y nodejs git ripgrep || fail 'Node.js install failed - check the internet'\n"
                        + "fi\n"
                        + "if [ ! -f \"$CLI\" ]; then\n"
                        + "  echo '== Installing Claude Code (one time, needs internet) =='\n"
                        + "  npm install -g @anthropic-ai/claude-code@2.1.112 || fail 'Claude Code install failed'\n"
                        + "fi\n"
                        + "[ -f \"$CLI\" ] || { echo \"package folder:\"; ls \"$(dirname \"$CLI\")\" 2>&1 | head -20; fail 'cli.js not found in the package'; }\n"
                        + "# npm's claude link starts with #!/usr/bin/env node, which does not exist here: use our own launcher with an absolute shebang\n"
                        + "rm -f \"$PREFIX/bin/claude\"\n"
                        + "echo \"#!$PREFIX/bin/sh\" > \"$PREFIX/bin/claude\"\n"
                        + "echo \"exec node \\\"$CLI\\\" \\\"\\$@\\\"\" >> \"$PREFIX/bin/claude\"\n"
                        + "chmod 755 \"$PREFIX/bin/claude\"\n"
                        + "# Browser hand-over: Claude Code calls $BROWSER <url>; this writes the url to a file that the app watches and opens in the phone browser\n"
                        + "echo \"#!$PREFIX/bin/sh\" > \"$PREFIX/bin/abtin-open\"\n"
                        + "echo 'echo \"$1\" > \"$HOME/.abtin-open-url\"' >> \"$PREFIX/bin/abtin-open\"\n"
                        + "echo 'echo \"Opening your browser...\" >&2' >> \"$PREFIX/bin/abtin-open\"\n"
                        + "chmod 755 \"$PREFIX/bin/abtin-open\"\n"
                        + "cp -f \"$PREFIX/bin/abtin-open\" \"$PREFIX/bin/xdg-open\" 2>/dev/null\n"
                        + "export BROWSER=\"$PREFIX/bin/abtin-open\"\n"
                        + "if node \"$CLI\" --version; then\n"
                        + "  echo '== Starting Claude Code (log in with your own account) =='\n"
                        + "  claude\n"
                        + "else\n"
                        + "  echo \"node: $(node -v 2>&1)\"\n"
                        + "  fail 'claude does not start (error above)'\n"
                        + "fi\n"
                        + "exec bash -l\n"
                        + "ABTIN_CLAUDE_EOF\n"
                        + "  _termux_run bash /data/data/com.termux/files/home/.abtin-claude.sh\n"
                        + "}\n"
                        + "if [ -n \"$ABTIN_CLAUDE\" ] && [ -z \"$ABTIN_CLAUDE_DONE\" ]; then\n"
                        + "  export ABTIN_CLAUDE_DONE=1 ABTIN_BASH_DONE=1\n"
                        + "  abtin_claude\n"
                        + "fi\n"
                        + "[ \"$ABTIN_PROFILE\" = sh ] && ABTIN_BASH_DONE=1\n"
                        + "if [ -n \"$ABTIN_BASH\" ] && [ -z \"$ABTIN_BASH_DONE\" ] && { [ ! -f \"$PREFIX/etc/no-auto-bash\" ] || [ -n \"$ABTIN_PROFILE\" ]; }; then\n"
                        + "  export ABTIN_BASH_DONE=1\n"
                        // Default: Termux (bundled with the app). 'autoshell alpine' switches new terminals back to Alpine bash.
                        + "  if [ \"$ABTIN_PROFILE\" = termux ] || { [ -z \"$ABTIN_PROFILE\" ] && [ ! -f \"$PREFIX/etc/auto-alpine\" ]; }; then\n"
                        + "    if [ -f \"$PREFIX/termux/.abtin-termux\" ]; then\n"
                        + "      termux\n"
                        + "    else\n"
                        + "      echo 'Termux is not installed yet (it is bundled with the app, no download).' >&2\n"
                        + "      printf 'Install it now? [Y/n] ' >&2\n"
                        + "      read _ans\n"
                        + "      case \"$_ans\" in\n"
                        + "        n|N|no|NO) : > \"$PREFIX/etc/no-auto-bash\"; echo \"Skipped. Type 'termux' any time to install and enter it ('autobash on' = ask at every start).\" >&2 ;;\n"
                        + "        *) termux setup -y && termux ;;\n"
                        + "      esac\n"
                        + "    fi\n"
                        + "  elif [ -x \"$PREFIX/alpine/bin/bash\" ]; then\n"
                        + "    bash\n"
                        + "  else\n"
                        + "    echo 'The full Linux environment (bash, git, python, node, pkg/apk packages) is not installed yet.' >&2\n"
                        + "    printf 'Install it now (about 200 MB download)? [Y/n] ' >&2\n"
                        + "    read _ans\n"
                        + "    case \"$_ans\" in\n"
                        + "      n|N|no|NO) : > \"$PREFIX/etc/no-auto-bash\"; echo \"Skipped. Type 'bash' any time to install it ('autobash on' = ask at every start).\" >&2 ;;\n"
                        + "      *) { [ -f \"$PREFIX/alpine/etc/alpine-release\" ] || alpine bootstrap; } && bash ;;\n"
                        + "    esac\n"
                        + "  fi\n"
                        + "fi\n";
        PkgCli.writeText(new File(prefix, "etc/shrc"), shrc);
        PkgCli.writeText(new File(prefix, "etc/abtin-bashrc"), "# Abtin bash - created once inside Alpine (/root/.bashrc); edit freely, it is never overwritten.\ncase $- in *i*) ;; *) return ;; esac\nexport HISTFILE=/root/.bash_history HISTSIZE=5000 HISTFILESIZE=20000 HISTCONTROL=ignoreboth\nexport EDITOR=nano PAGER=less\nshopt -s histappend checkwinsize cdspell globstar 2>/dev/null\nPS1='\\[\\e[0;32m\\]\\w\\[\\e[0m\\] \\[\\e[0;97m\\]\\$\\[\\e[0m\\] '\nalias ls='ls --color=auto'\nalias ll='ls -lAh'\nalias la='ls -A'\nalias grep='grep --color=auto'\nalias ..='cd ..'\napt() {\n  case \"$1\" in\n    install) shift; apk add \"$@\" ;;\n    remove|purge) shift; apk del \"$@\" ;;\n    update) apk update ;;\n    upgrade) apk upgrade ;;\n    search) shift; apk search \"$@\" ;;\n    show) shift; apk info -a \"$@\" ;;\n    *) apk \"$@\" ;;\n  esac\n}\n[ -r /usr/share/bash-completion/bash_completion ] && . /usr/share/bash-completion/bash_completion\n[ -d /sdcard ] && export SDCARD=/sdcard\n[ -r ~/.bashrc.local ] && . ~/.bashrc.local\n");
        PkgCli.writeText(new File(prefix, "etc/abtin-full-install"),
                "#!/bin/sh\n" +
                "# Abtin: installs the full command set (Termux-like). Safe to run again.\n" +
                "MARK=/etc/.abtin-fullpkgs-1\n" +
                "PKGS=\"bash bash-completion coreutils findutils grep sed gawk less nano curl wget openssh-client tar ncurses util-linux procps-ng htop git diffutils patch file tree which jq zip unzip bzip2 xz gzip p7zip rsync bind-tools iputils net-tools iproute2 mandoc man-pages openssl ca-certificates tmux make bc lsof psmisc sqlite ripgrep strace tzdata vim\"\n" +
                "echo 'Installing the full command set from the Alpine repository (one time, about 150 MB)...'\n" +
                "if apk add --no-cache $PKGS; then\n" +
                "  : > \"$MARK\"\n" +
                "  echo 'Done. Open a new bash session (type: exec bash) to use everything.'\n" +
                "  exit 0\n" +
                "fi\n" +
                "echo 'A package failed - retrying one by one...' >&2\n" +
                "ok=0; bad=0\n" +
                "for p in $PKGS; do\n" +
                "  if apk add --no-cache \"$p\" >/dev/null 2>&1; then\n" +
                "    ok=$((ok+1))\n" +
                "  else\n" +
                "    bad=$((bad+1)); echo \"  skipped: $p\" >&2\n" +
                "    if [ \"$ok\" -eq 0 ] && [ \"$bad\" -ge 3 ]; then\n" +
                "      echo 'No package could be installed - check the internet connection and run abtin-full-install again.' >&2\n" +
                "      exit 1\n" +
                "    fi\n" +
                "  fi\n" +
                "done\n" +
                ": > \"$MARK\"\n" +
                "echo \"Done: $ok installed, $bad skipped.\"\n");
        PkgCli.writeText(new File(prefix, "etc/abtin-npm-fix"),
                "#!/bin/sh\n" +
                "# Abtin: repairs npm inside Alpine.\n" +
                "NM=/usr/lib/node_modules\n" +
                "ok() { [ -f \"$1/bin/npm-cli.js\" ] && node \"$1/bin/npm-cli.js\" -v >/dev/null 2>&1; }\n" +
                "diag() {\n" +
                "  echo \"--- diagnostics for $1 ---\" >&2\n" +
                "  ls -la \"$1\" \"$1/bin\" 2>&1 | head -20 >&2\n" +
                "  node \"$1/bin/npm-cli.js\" -v 2>&1 | head -8 >&2\n" +
                "  echo \"node: $(node -v 2>&1)  disk:\" >&2\n" +
                "  df -h / /tmp 2>&1 | head -4 >&2\n" +
                "}\n" +
                "command -v node >/dev/null 2>&1 || { echo 'node: not installed, installing...'; apk add --no-cache nodejs || exit 1; }\n" +
                "ok $NM/npm && { echo \"npm $(node $NM/npm/bin/npm-cli.js -v) is fine\"; exit 0; }\n" +
                "echo 'npm: broken - repairing...'\n" +
                "rm -f /usr/local/bin/npm /usr/local/bin/npx /usr/bin/npm /usr/bin/npx\n" +
                "rm -rf $NM/npm\n" +
                "apk fix --reinstall npm >/dev/null 2>&1 || { apk del npm >/dev/null 2>&1; apk add --no-cache npm >/dev/null 2>&1; }\n" +
                "DEST=$NM/npm\n" +
                "if ! ok $DEST; then\n" +
                "  echo 'npm: apk did not restore it - downloading npm from registry.npmjs.org...'\n" +
                "  mkdir -p /root/npmfix && cd /root/npmfix || exit 1\n" +
                "  rm -rf package npm.tgz\n" +
                "  U=https://registry.npmjs.org/npm/-/npm-10.9.2.tgz\n" +
                "  { wget -O npm.tgz $U || curl -fL -o npm.tgz $U; } || { echo 'npm: download failed (check the internet connection)' >&2; exit 1; }\n" +
                "  ls -la npm.tgz\n" +
                "  tar xzf npm.tgz || { echo 'npm: unpack failed' >&2; exit 1; }\n" +
                "  mkdir -p $NM && rm -rf $NM/npm && mv package $NM/npm\n" +
                "  if ! ok $NM/npm; then\n" +
                "    diag $NM/npm\n" +
                "    echo \"npm: $NM did not work - trying /opt/npm ...\" >&2\n" +
                "    rm -rf /opt/npm; mkdir -p /opt && cp -r $NM/npm /opt/npm 2>/dev/null || { rm -rf /opt/npm; mv package /opt/npm 2>/dev/null; }\n" +
                "    DEST=/opt/npm\n" +
                "  fi\n" +
                "fi\n" +
                "if [ \"$DEST\" = /opt/npm ] || ! ok $NM/npm; then\n" +
                "  ok /opt/npm || { diag /opt/npm; echo 'npm: still broken - send this text to the developer' >&2; exit 1; }\n" +
                "  printf '#!/bin/sh\\nexec node /opt/npm/bin/npm-cli.js \"$@\"\\n' > /usr/local/bin/npm\n" +
                "  printf '#!/bin/sh\\nexec node /opt/npm/bin/npx-cli.js \"$@\"\\n' > /usr/local/bin/npx\n" +
                "  chmod 755 /usr/local/bin/npm /usr/local/bin/npx\n" +
                "  echo \"npm $(node /opt/npm/bin/npm-cli.js -v) is ready (in /opt/npm)\"\n" +
                "  exit 0\n" +
                "fi\n" +
                "ln -sf ../lib/node_modules/npm/bin/npm-cli.js /usr/bin/npm\n" +
                "ln -sf ../lib/node_modules/npm/bin/npx-cli.js /usr/bin/npx\n" +
                "echo \"npm $(node $NM/npm/bin/npm-cli.js -v) is ready\"\n");
        PkgCli.writeText(new File(prefix, "etc/abtin-bash-extras"),
                "# Abtin bash extras (rewritten at every start; put your own settings in ~/.bashrc.local)\n" +
                "case $- in *i*) ;; *) return ;; esac\n" +
                "export LESS=-R MANPAGER=less\n" +
                "alias ls='ls --color=auto'\n" +
                "alias ll='ls -lAh'\n" +
                "alias la='ls -A'\n" +
                "alias l='ls -CF'\n" +
                "alias ..='cd ..'\n" +
                "alias ...='cd ../..'\n" +
                "alias cls=clear\n" +
                "alias grep='grep --color=auto'\n" +
                "alias egrep='grep -E --color=auto'\n" +
                "alias fgrep='grep -F --color=auto'\n" +
                "alias df='df -h'\n" +
                "alias du='du -h'\n" +
                "# Termux-like \"pkg\" (uses the Alpine repository)\n" +
                "pkg() {\n" +
                "  case \"$1\" in\n" +
                "    install|i|add) shift; apk add --no-cache \"$@\" ;;\n" +
                "    uninstall|remove|rm|purge) shift; apk del \"$@\" ;;\n" +
                "    update|upgrade|up|full-upgrade) apk upgrade --no-cache ;;\n" +
                "    search|s) shift; apk search --no-cache -v \"$@\" ;;\n" +
                "    show|info) shift; apk info --no-cache -a \"$@\" ;;\n" +
                "    list-installed|list|ls) apk info -v ;;\n" +
                "    files) shift; apk info -L \"$@\" ;;\n" +
                "    *) echo 'usage: pkg install|uninstall|update|upgrade|search|show|list-installed|files [packages]' >&2; return 2 ;;\n" +
                "  esac\n" +
                "}\n" +
                "# suggest the package that provides a missing command\n" +
                "command_not_found_handle() {\n" +
                "  echo \"bash: $1: command not found\" >&2\n" +
                "  if command -v apk >/dev/null 2>&1; then\n" +
                "    _p=$(apk search -x \"cmd:$1\" 2>/dev/null | sed 's/-[0-9][^-]*-r[0-9]*$//' | head -3 | tr '\\n' ' ')\n" +
                "    [ -n \"$_p\" ] && echo \"You can install it with: apk add $_p\" >&2\n" +
                "  fi\n" +
                "  return 127\n" +
                "}\n" +
                "# npm self-heal: if npm is missing or broken, repair it on first use (also: run abtin-npm-fix)\n" +
                "if command -v node >/dev/null 2>&1 && [ ! -f /usr/lib/node_modules/npm/bin/npm-cli.js ]; then\n" +
                "  npm() { abtin-npm-fix || return 1; unset -f npm npx; hash -r; npm \"$@\"; }\n" +
                "  npx() { abtin-npm-fix || return 1; unset -f npm npx; hash -r; npx \"$@\"; }\n" +
                "fi\n" +
                "[ -f /etc/.abtin-fullpkgs-1 ] || echo \"Tip: run 'abtin-full-install' to get the full command set (git, vim, htop, ps, top, rsync, jq, zip, man ...).\"\n");
        PkgCli.writeText(new File(prefix, "etc/abtin-inputrc"),
                "set completion-ignore-case on\n" +
                "set show-all-if-ambiguous on\n" +
                "set colored-stats on\n" +
                "set colored-completion-prefix on\n" +
                "set mark-symlinked-directories on\n" +
                "set bell-style none\n");
        PkgCli.writeText(new File(prefix, "etc/abtin-ps1"), "PS1='\\[\\e[0;32m\\]\\w\\[\\e[0m\\] \\[\\e[0;97m\\]\\$\\[\\e[0m\\] '\n");
        PkgCli.writeText(new File(prefix, "etc/abtin-bash_profile"), "# Abtin bash login shell: load .bashrc\n[ -r ~/.bashrc ] && . ~/.bashrc\n");
        cli.regenAliases(java.util.Collections.<String>emptySet());
        String ld = System.getenv("LD_LIBRARY_PATH");
        StringBuilder env = new StringBuilder();
        env.append("PREFIX=").append(p).append('\n');
        env.append("ENV=").append(p).append("/etc/shrc\n");
        env.append("ABTIN_APK=").append(apkPath).append('\n');
        env.append("ABTIN_ABI=").append(androidAbi).append('\n');
        env.append("ABTIN_LINKER=").append(linker).append('\n');
        env.append("LD_LIBRARY_PATH=").append(p).append("/lib").append(ld == null || ld.isEmpty() ? "" : ":" + ld).append('\n');
        env.append("PATH_PREPEND=").append(p).append("/bin\n");
        if (bashFirst) env.append("ABTIN_BASH=1\n");
        if (claudeMode) env.append("ABTIN_CLAUDE=1\n");
        if (profile != null && (profile.equals("termux") || profile.equals("alpine") || profile.equals("sh"))) env.append("ABTIN_PROFILE=").append(profile).append('\n');
        return env.toString();
    }
}
