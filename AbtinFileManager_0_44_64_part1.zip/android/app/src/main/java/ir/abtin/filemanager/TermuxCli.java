package ir.abtin.filemanager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * "termux" command backend: downloads the official Termux bootstrap archive (bionic-native bash, apt,
 * coreutils ...), extracts it safely into $PREFIX/termux/files/usr and rebuilds its symlinks
 * (SYMLINKS.txt). Running it is done by the shell functions generated in PkgEnv: proot binds
 * $PREFIX/termux/files onto /data/data/com.termux/files, so the official Termux packages work unchanged.
 * Unlike Alpine (musl) these binaries only use syscalls that Android's seccomp filter allows.
 *
 * Subcommands (run through app_process): setup [file|url] | status | remove
 */
public final class TermuxCli {
    static final String DEFAULT_URL_FMT = "https://github.com/termux/termux-packages/releases/latest/download/bootstrap-%s.zip";

    final File prefix;
    final File root;   // $PREFIX/termux
    final PkgCli cli;
    PrintStream out = System.out;
    boolean yes;
    String symlinkText = "";

    TermuxCli(File prefix) {
        this.prefix = prefix;
        this.root = new File(prefix, "termux");
        this.cli = new PkgCli(prefix);
    }

    public static void main(String[] args) {
        int code;
        try {
            String p = System.getenv("PREFIX");
            if (p == null || p.length() == 0) {
                System.err.println("termux: PREFIX is not set (use the app terminal)");
                System.exit(2);
                return;
            }
            TermuxCli t = new TermuxCli(new File(p));
            t.out = new PrintStream(new FileOutputStream(java.io.FileDescriptor.out), true, "UTF-8");
            t.cli.out = t.out;
            String term = System.getenv("TERM");
            t.cli.ansi = term != null && !term.equals("dumb");
            code = t.run(args);
            t.out.flush();
        } catch (PkgCli.PkgException e) {
            System.err.println("termux: " + e.getMessage());
            code = 1;
        } catch (Throwable t) {
            System.err.println("termux: internal error: " + t);
            code = 1;
        }
        System.exit(code);
    }

    int run(String[] argv) throws Exception {
        cli.ensureDirs();
        List<String> args = new ArrayList<String>();
        for (String a : argv) {
            if (a.equals("-y") || a.equals("--yes")) { yes = true; cli.yes = true; }
            else args.add(a);
        }
        if (args.isEmpty()) throw new PkgCli.PkgException("usage: termux setup [file|url] | status | remove");
        String cmd = args.remove(0);
        if (cmd.equals("setup")) return setup(args);
        if (cmd.equals("status")) return status();
        if (cmd.equals("remove")) return remove();
        throw new PkgCli.PkgException("unknown subcommand '" + cmd + "'");
    }

    File usr() { return new File(root, "files/usr"); }

    static String defaultUrl() {
        String o = System.getenv("ABTIN_TERMUX_BOOTSTRAP");
        if (o != null && o.length() > 0) return o;
        return String.format(DEFAULT_URL_FMT, PkgCli.detectArch());
    }

    // ------------------------------------------------------------------ setup

    int setup(List<String> args) throws Exception {
        if (new File(root, ".abtin-termux").exists()) {
            out.println("Termux environment is already installed in " + root.getPath() + " (use: termux remove)");
            return 0;
        }
        File zip = null;
        boolean temp = false;
        String spec;
        if (args.isEmpty()) {
            // Offline first: the bootstrap is bundled inside the APK (assets/termux-bootstrap-<arch>.zip).
            zip = extractEmbedded();
            if (zip != null) { temp = true; spec = "embedded:" + zip.getName(); out.println("Using the Termux bootstrap bundled with the app (no download needed)."); }
            else spec = defaultUrl();
        } else {
            spec = args.get(0);
        }
        if (zip != null) {
            // embedded archive already in the cache
        } else if (spec.matches("(?i)https?://.*")) {
            out.println("Downloading Termux bootstrap: " + spec);
            if (!yes && !cli.confirm("Download the Termux bootstrap (about 25-30 MB) and install?")) {
                out.println("Aborted.");
                return 1;
            }
            zip = new File(cli.cacheDir, "termux-bootstrap.zip");
            File part = new File(cli.cacheDir, "termux-bootstrap.zip.part");
            FileOutputStream fos = new FileOutputStream(part);
            try {
                cli.download(spec, fos, "termux-bootstrap.zip", true);
            } catch (IOException e) {
                PkgCli.closeQuiet(fos);
                part.delete();
                throw new PkgCli.PkgException("download failed: " + e.getMessage()
                        + "\nTip: download bootstrap-" + PkgCli.detectArch() + ".zip another way, put it in /sdcard/Download and run:\n"
                        + "  termux setup /sdcard/Download/bootstrap-" + PkgCli.detectArch() + ".zip");
            }
            fos.close();
            if (zip.exists()) zip.delete();
            if (!part.renameTo(zip)) throw new PkgCli.PkgException("cannot move download into cache");
            temp = true;
        } else {
            zip = new File(spec);
            if (!zip.isFile()) throw new PkgCli.PkgException("file not found: " + spec);
        }
        out.println("archive SHA-256: " + PkgCli.sha256(zip));

        File staging = new File(prefix, "termux.staging");
        AlpineCli.forceDelete(staging);
        PkgCli.mkdirs(staging);
        File sUsr = new File(staging, "files/usr");
        try {
            PkgCli.mkdirs(sUsr);
            int n = extract(zip, sUsr);
            out.println("Extracted " + n + " files.");
            int l = symlinks(sUsr);
            out.println("Created " + l + " symlinks.");
            int x = fixModes(sUsr);
            out.println("Marked " + x + " executables.");
            if (!new File(sUsr, "bin/sh").exists() && !symlinkText.contains("\u2190./bin/sh") && !symlinkText.contains("\u2190bin/sh"))
                throw new PkgCli.PkgException("this archive does not look like a Termux bootstrap (no bin/sh)");
            PkgCli.mkdirs(new File(staging, "files/home"));
            PkgCli.mkdirs(new File(sUsr, "tmp"));
            PkgCli.chmod(new File(sUsr, "tmp"), 0777);
            PkgCli.writeText(new File(staging, ".abtin-termux"), "source=" + spec + "\narch=" + PkgCli.detectArch() + "\n");
            if (root.exists()) AlpineCli.forceDelete(root);
            if (!staging.renameTo(root)) throw new PkgCli.PkgException("cannot move the environment into place");
        } catch (Exception e) {
            AlpineCli.forceDelete(staging);
            throw e;
        }
        if (temp) zip.delete();
        cli.ok("Termux environment installed. Next: termux  (opens its bash), then: pkg install nodejs python");
        return 0;
    }

    /** Copies the bootstrap bundled in the APK (assets/termux-bootstrap-ARCH.zip) into the cache; null if absent. */
    File extractEmbedded() {
        String apk = System.getenv("ABTIN_APK");
        if (apk == null || apk.length() == 0) return null;
        ZipFile zf = null;
        try {
            zf = new ZipFile(apk);
            String base = "assets/termux-bootstrap-" + PkgCli.detectArch() + ".zip";
            File dest = new File(cli.cacheDir, "termux-bootstrap-embedded.zip");
            // Stored either as one entry or as numbered parts (.001, .002 ...) that are joined here.
            List<ZipEntry> parts = new ArrayList<ZipEntry>();
            ZipEntry whole = zf.getEntry(base);
            if (whole != null) parts.add(whole);
            else for (int i = 1; i < 100; i++) {
                ZipEntry pe = zf.getEntry(base + String.format("." + "%03d", i));
                if (pe == null) break;
                parts.add(pe);
            }
            if (parts.isEmpty()) return null;
            FileOutputStream o = new FileOutputStream(dest);
            try {
                byte[] buf = new byte[65536];
                for (ZipEntry pe : parts) {
                    InputStream in = zf.getInputStream(pe);
                    try {
                        int r;
                        while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
                    } finally { in.close(); }
                }
            } finally { o.close(); }
            return dest;
        } catch (IOException ex) {
            out.println("Bundled bootstrap could not be read (" + ex.getMessage() + "), falling back to download.");
            return null;
        } finally {
            if (zf != null) try { zf.close(); } catch (IOException ignored) { }
        }
    }

    /** Safe zip extraction: no "..", nothing written below symlinks, setuid bits not applied. */
    int extract(File zip, File dest) throws IOException, PkgCli.PkgException {
        int count = 0;
        ZipFile zf = new ZipFile(zip);
        try {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                String rel = AlpineCli.clean(e.getName());
                if (rel == null) continue;
                if (rel.equals("SYMLINKS.txt")) { symlinkText = readAll(zf.getInputStream(e)); continue; }
                File f = new File(dest, rel);
                AlpineCli.checkParents(dest, rel);
                if (e.isDirectory()) { PkgCli.mkdirs(f); PkgCli.chmod(f, 0700); continue; }
                PkgCli.mkdirs(f.getParentFile());
                PkgCli.deleteRecursive(f);
                InputStream in = zf.getInputStream(e);
                FileOutputStream o = new FileOutputStream(f);
                try {
                    byte[] buf = new byte[65536];
                    int r;
                    while ((r = in.read(buf)) > 0) o.write(buf, 0, r);
                } finally { o.close(); in.close(); }
                PkgCli.chmod(f, 0600);
                count++;
            }
        } finally {
            zf.close();
        }
        return count;
    }

    static String readAll(InputStream in) throws IOException {
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            char[] buf = new char[8192];
            int n;
            while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
            return sb.toString();
        } finally { in.close(); }
    }

    /** SYMLINKS.txt holds one "target<-link" per line (U+2190); link is relative to usr/. */
    int symlinks(File dest) throws IOException, PkgCli.PkgException {
        int count = 0;
        for (String line : symlinkText.split("\r?\n")) {
            int i = line.indexOf('\u2190');
            if (i <= 0) continue;
            String target = line.substring(0, i);
            String rel = AlpineCli.clean(line.substring(i + 1));
            if (rel == null || target.length() == 0) continue;
            File link = new File(dest, rel);
            AlpineCli.checkParents(dest, rel);
            PkgCli.mkdirs(link.getParentFile());
            PkgCli.deleteRecursive(link);
            PkgCli.symlink(target, link);
            count++;
        }
        return count;
    }

    int fixModes(File dest) throws IOException {
        return fixModesRec(dest);
    }

    int fixModesRec(File d) throws IOException {
        int n = 0;
        File[] kids = d.listFiles();
        if (kids == null) return 0;
        for (File k : kids) {
            // dangling links (absolute /data/data/com.termux/... targets only resolve inside proot) fail exists()
            if (!k.exists() || PkgCli.isLink(k)) continue;
            if (k.isDirectory()) { n += fixModesRec(k); continue; }
            if (looksExecutable(k)) { PkgCli.chmod(k, 0700); n++; }
        }
        return n;
    }

    static boolean looksExecutable(File f) throws IOException {
        byte[] h = new byte[4];
        InputStream in = new FileInputStream(f);
        try {
            int r = PkgCli.readUpTo(in, h);
            if (r >= 2 && h[0] == '#' && h[1] == '!') return true;
            return r == 4 && h[0] == 0x7f && h[1] == 'E' && h[2] == 'L' && h[3] == 'F';
        } finally { in.close(); }
    }

    // ------------------------------------------------------------------ status / remove

    int status() throws Exception {
        File meta = new File(root, ".abtin-termux");
        if (!meta.exists()) { out.println("Termux: not installed (run: termux setup)"); return 1; }
        out.println("Termux:   installed at " + root.getPath());
        for (String l : PkgCli.readLines(meta)) if (l.length() > 0) out.println("  " + l);
        File db = new File(usr(), "var/lib/dpkg/status");
        if (db.exists()) {
            int n = 0;
            for (String l : PkgCli.readLines(db)) if (l.startsWith("Package:")) n++;
            out.println("  dpkg packages=" + n);
        }
        out.println("proot:    " + (new File(prefix, "bin/proot").exists() ? "present" : "bundled/MISSING"));
        out.println("free:     " + PkgCli.humanSize(prefix.getUsableSpace()));
        return 0;
    }

    int remove() throws Exception {
        if (!root.exists()) { out.println("Termux environment is not installed."); return 0; }
        if (!cli.confirm("Delete " + root.getPath() + " (including its home folder) and everything inside?")) { out.println("Aborted."); return 1; }
        AlpineCli.forceDelete(root);
        cli.ok("Termux environment removed.");
        return 0;
    }
}
