cmake_minimum_required(VERSION 3.22.1)
project(abtin_terminal_pty LANGUAGES C CXX)

add_library(terminal_pty SHARED terminal_pty.cpp)
target_compile_features(terminal_pty PRIVATE cxx_std_17)
target_compile_options(terminal_pty PRIVATE -Wall -Wextra -Werror=return-type)
