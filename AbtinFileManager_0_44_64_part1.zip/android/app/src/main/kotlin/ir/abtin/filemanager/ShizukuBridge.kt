package ir.abtin.filemanager

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodChannel
import rikka.shizuku.Shizuku
import java.io.ByteArrayOutputStream
import java.io.InputStream

/**
 * Shizuku bridge: runs shell commands (uid 2000 / root) so the app can reach Android/data and Android/obb,
 * which Android 11+ hides from every normal app. Dart (lib/services/shizuku.dart) builds the commands.
 *
 * Channel "abtin/shizuku":
 *   status  -> {installed, running, granted, sdk, uid}
 *   request -> true when the permission was granted
 *   exec    -> {args: [String]} -> {code, out, err}
 *   launch  -> opens the Shizuku app
 */
class ShizukuBridge(private val ctx: Context, messenger: BinaryMessenger) {
    private val ch = MethodChannel(messenger, "abtin/shizuku")
    private val ui = Handler(Looper.getMainLooper())
    private var pending: MethodChannel.Result? = null
    private val reqCode = 7731

    private val permListener = Shizuku.OnRequestPermissionResultListener { code, grant ->
        if (code == reqCode) {
            val r = pending
            pending = null
            ui.post { r?.success(grant == PackageManager.PERMISSION_GRANTED) }
        }
    }

    init {
        try { Shizuku.addRequestPermissionResultListener(permListener) } catch (e: Throwable) {}
        ch.setMethodCallHandler { call, result ->
            when (call.method) {
                "status" -> result.success(status())
                "request" -> request(result)
                "launch" -> result.success(launch())
                "exec" -> {
                    val args = (call.argument<List<String>>("args") ?: emptyList()).toTypedArray()
                    Thread {
                        val r: Any = try { exec(args) } catch (e: Throwable) {
                            mapOf("code" to -1, "out" to "", "err" to (e.message ?: e.javaClass.simpleName))
                        }
                        ui.post { result.success(r) }
                    }.start()
                }
                else -> result.notImplemented()
            }
        }
    }

    fun dispose() {
        try { Shizuku.removeRequestPermissionResultListener(permListener) } catch (e: Throwable) {}
        ch.setMethodCallHandler(null)
    }

    private fun installed(): Boolean = try {
        ctx.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0)
        true
    } catch (e: Throwable) { false }

    private fun running(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    private fun granted(): Boolean = try {
        running() && !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    private fun status(): Map<String, Any> {
        val run = running()
        val uid = try { if (run) Shizuku.getUid() else -1 } catch (e: Throwable) { -1 }
        return mapOf(
            "installed" to installed(),
            "running" to run,
            "granted" to granted(),
            "sdk" to Build.VERSION.SDK_INT,
            "uid" to uid,
        )
    }

    private fun request(result: MethodChannel.Result) {
        try {
            if (!running()) { result.success(false); return }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) { result.success(true); return }
            if (Shizuku.shouldShowRequestPermissionRationale()) { result.success(false); return }
            pending?.success(false)
            pending = result
            Shizuku.requestPermission(reqCode)
        } catch (e: Throwable) {
            pending = null
            result.success(false)
        }
    }

    private fun launch(): Boolean = try {
        val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i == null) false else { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i); true }
    } catch (e: Throwable) { false }

    /** Shizuku.newProcess is private since API 13, so it is reached by reflection. */
    private fun newProcess(cmd: Array<String>): Process {
        val m = try {
            Shizuku::class.java.getDeclaredMethod("newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java)
        } catch (e: NoSuchMethodException) {
            Shizuku::class.java.declaredMethods.first { it.name == "newProcess" && it.parameterTypes.size == 3 }
        }
        m.isAccessible = true
        return m.invoke(null, cmd, null, null) as Process
    }

    private fun drain(s: InputStream, into: ByteArrayOutputStream): Thread {
        val t = Thread {
            try {
                val buf = ByteArray(16 * 1024)
                while (true) {
                    val n = s.read(buf)
                    if (n < 0) break
                    synchronized(into) { into.write(buf, 0, n) }
                }
            } catch (e: Throwable) {}
        }
        t.start()
        return t
    }

    private fun exec(args: Array<String>): Map<String, Any> {
        if (!granted()) return mapOf("code" to -2, "out" to "", "err" to "shizuku not ready")
        val p = newProcess(args)
        val out = ByteArrayOutputStream()
        val err = ByteArrayOutputStream()
        try { p.outputStream.close() } catch (e: Throwable) {}
        val a = drain(p.inputStream, out)
        val b = drain(p.errorStream, err)
        val code = p.waitFor()
        a.join(5000)
        b.join(5000)
        return mapOf("code" to code, "out" to String(out.toByteArray(), Charsets.UTF_8), "err" to String(err.toByteArray(), Charsets.UTF_8))
    }
}
