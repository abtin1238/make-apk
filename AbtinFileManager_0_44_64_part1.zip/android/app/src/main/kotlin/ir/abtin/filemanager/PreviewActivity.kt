package ir.abtin.filemanager

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.JsPromptResult
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/**
 * HTML / CSS / JS / Markdown / SVG preview in Android's own [WebView].
 * Intent extras: file (HTML on disk), base (base URL, file:///dir/), title, console (open console panel).
 * The reload button asks Dart (through [reloadHook]) for a fresh HTML file made from the editor's current text.
 */
class PreviewActivity : Activity() {
    companion object {
        /** Set by MainActivity: asks Dart for {file, base}; the callback gets null when it fails. */
        var reloadHook: (((Map<*, *>?) -> Unit) -> Unit)? = null
    }

    private lateinit var web: WebView
    private lateinit var consoleScroll: ScrollView
    private lateinit var consoleText: TextView
    private lateinit var consoleBtn: TextView
    private lateinit var titleView: TextView
    private var file = ""
    private var base = ""
    private var count = 0
    private var errors = 0

    private fun dp(v: Int) = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun barButton(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 18f
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14), 0, dp(14), 0)
        t.setOnClickListener { onClick() }
        return t
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        file = intent.getStringExtra("file") ?: ""
        base = intent.getStringExtra("base") ?: "about:blank"
        val title = intent.getStringExtra("title") ?: "Preview"

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.fitsSystemWindows = true
        root.setBackgroundColor(0xFF1E1E1E.toInt())

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(0xFF1E1E1E.toInt())
        titleView = TextView(this)
        titleView.text = title
        titleView.setTextColor(Color.WHITE)
        titleView.textSize = 15f
        titleView.maxLines = 1
        titleView.ellipsize = android.text.TextUtils.TruncateAt.END
        titleView.setPadding(dp(14), 0, dp(8), 0)
        bar.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        bar.addView(barButton("\u27F3") { reload() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        consoleBtn = barButton(">_") { toggleConsole() }
        bar.addView(consoleBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        bar.addView(barButton("\u2715") { finish() }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        consoleText = TextView(this)
        consoleText.setTextColor(0xFFDDDDDD.toInt())
        consoleText.typeface = Typeface.MONOSPACE
        consoleText.textSize = 12f
        consoleText.setTextIsSelectable(true)
        consoleText.setPadding(dp(10), dp(6), dp(10), dp(6))
        consoleScroll = ScrollView(this)
        consoleScroll.setBackgroundColor(0xFF111111.toInt())
        consoleScroll.addView(consoleText)
        consoleScroll.visibility = View.GONE
        root.addView(consoleScroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(170)))

        setContentView(root)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = true
        @Suppress("DEPRECATION")
        s.allowFileAccessFromFileURLs = true
        @Suppress("DEPRECATION")
        s.allowUniversalAccessFromFileURLs = true
        s.allowContentAccess = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.setSupportZoom(true)
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = false

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                // a new page = a new console
                if (url != null && url != "about:blank") clearConsole()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                val u = request?.url?.toString() ?: ""
                val shown = if (request?.isForMainFrame == true) "page" else u.substringAfterLast('/')
                addLog("error", "Failed to load $shown: ${error?.description ?: ""}")
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                val lvl = when (m.messageLevel()) {
                    ConsoleMessage.MessageLevel.ERROR -> "error"
                    ConsoleMessage.MessageLevel.WARNING -> "warn"
                    ConsoleMessage.MessageLevel.DEBUG -> "debug"
                    else -> "log"
                }
                val src = m.sourceId()?.substringAfterLast('/')?.takeIf { it.isNotEmpty() }
                val where = if (lvl == "error" || lvl == "warn") "  (${src ?: "page"}:${m.lineNumber()})" else ""
                addLog(lvl, m.message() + where)
                return true
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@PreviewActivity).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@PreviewActivity).setMessage(message)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }

            override fun onJsPrompt(view: WebView?, url: String?, message: String?, defaultValue: String?, result: JsPromptResult): Boolean {
                val input = EditText(this@PreviewActivity)
                input.setText(defaultValue ?: "")
                AlertDialog.Builder(this@PreviewActivity).setMessage(message).setView(input)
                    .setPositiveButton(android.R.string.ok) { _, _ -> result.confirm(input.text.toString()) }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }.show()
                return true
            }
        }

        if (intent.getBooleanExtra("console", false)) consoleScroll.visibility = View.VISIBLE
        load()
    }

    private fun load() {
        try {
            val html = File(file).readText(Charsets.UTF_8)
            web.loadDataWithBaseURL(base, html, "text/html", "utf-8", null)
        } catch (e: Exception) {
            addLog("error", "Cannot read preview file: ${e.message}")
        }
    }

    private fun reload() {
        val hook = reloadHook
        if (hook == null) {
            load()
            return
        }
        hook { m ->
            runOnUiThread {
                if (m != null) {
                    (m["file"] as? String)?.let { file = it }
                    (m["base"] as? String)?.let { base = it }
                }
                load()
            }
        }
    }

    private fun toggleConsole() {
        consoleScroll.visibility = if (consoleScroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun clearConsole() {
        count = 0
        errors = 0
        consoleText.text = ""
        refreshBadge()
    }

    private fun refreshBadge() {
        consoleBtn.text = if (errors > 0) ">_ $errors" else if (count > 0) ">_ $count" else ">_"
        consoleBtn.setTextColor(if (errors > 0) 0xFFFF6E6E.toInt() else Color.WHITE)
    }

    private fun addLog(level: String, msg: String) {
        runOnUiThread {
            count++
            if (level == "error") errors++
            val color = when (level) {
                "error" -> 0xFFFF6E6E.toInt()
                "warn" -> 0xFFFFC857.toInt()
                "debug" -> 0xFF9AA0A6.toInt()
                else -> 0xFFDDDDDD.toInt()
            }
            val sb = SpannableStringBuilder(consoleText.text)
            val start = sb.length
            sb.append(msg).append('\n')
            sb.setSpan(ForegroundColorSpan(color), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (sb.length > 60000) sb.delete(0, sb.length - 40000)
            consoleText.text = sb
            consoleScroll.post { consoleScroll.fullScroll(View.FOCUS_DOWN) }
            refreshBadge()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        try {
            (web.parent as? ViewGroup)?.removeView(web)
            web.stopLoading()
            web.destroy()
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }
}
