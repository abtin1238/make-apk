arm64-v8a/libproot.so          = PRoot 5.5.0 (static aarch64, built from proot-me/proot v5.5.0 source via .github/workflows/build-proot.yml, GPL-2.0; has statx support). Replaces 5.1.0.
arm64-v8a/libproot-loader.so   = loader.elf built together with that proot 5.5.0
arm64-v8a/libproot-loader32.so = 32-bit loader carved out of the same binary
The terminal uses them automatically (PROOT_LOADER / PROOT_LOADER_32), so nothing is extracted/executed from app data.
32-bit-only phones (armeabi-v7a) have no bundled proot: they fall back to the download in `alpine bootstrap`.
