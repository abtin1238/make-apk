import 'dart:convert';
import 'dart:io';
import 'saf.dart';
import 'dart:typed_data';
import 'package:archive/archive.dart';
import 'package:path/path.dart' as p;
import 'package:xml/xml.dart';
import 'file_ops.dart';

/// A zip-based office file (xlsx / pptx / odt) opened for reading and for "save as edited copy".
class OfficeZip {
  final String path;
  final Archive arc;
  final Map<String, XmlDocument> _docs = {};
  final Set<String> _dirty = {};
  final Set<String> drop = {};
  OfficeZip._(this.path, this.arc);

  static Future<OfficeZip> open(String path) async => OfficeZip._(path, ZipDecoder().decodeBytes(await File(path).readAsBytes()));

  ArchiveFile? file(String name) {
    for (final f in arc.files) {
      if (f.isFile && f.name == name) return f;
    }
    return null;
  }

  Uint8List? bytes(String name) {
    final f = file(name);
    return f == null ? null : Uint8List.fromList(f.content as List<int>);
  }

  XmlDocument? xml(String name) {
    final c = _docs[name];
    if (c != null) return c;
    final b = bytes(name);
    if (b == null) return null;
    return _docs[name] = XmlDocument.parse(utf8.decode(b, allowMalformed: true));
  }

  /// Adds (or replaces) a part.
  void put(String name, List<int> data) {
    arc.files.removeWhere((f) => f.name == name);
    arc.addFile(ArchiveFile(name, data.length, data));
    _docs.remove(name);
    drop.remove(name);
  }

  /// "[Content_Types].xml" helpers.
  void addOverride(String partName, String type) {
    final ct = xml('[Content_Types].xml');
    if (ct == null) return;
    ct.rootElement.children.add(XmlElement(XmlName('Override'), [XmlAttribute(XmlName('PartName'), partName), XmlAttribute(XmlName('ContentType'), type)]));
    touch('[Content_Types].xml');
  }

  void removeOverride(String partName) {
    final ct = xml('[Content_Types].xml');
    if (ct == null) return;
    ct.findAllElements('Override', namespace: '*').where((e) => e.getAttribute('PartName') == '/$partName').toList().forEach((e) => e.parent!.children.remove(e));
    touch('[Content_Types].xml');
  }

  void touch(String name) => _dirty.add(name);
  bool get changed => _dirty.isNotEmpty;

  /// Full copy of the current state (used for undo).
  (List<int>, Set<String>) snapshot() => (_encode(), {..._dirty});

  /// Goes back to a state taken with [snapshot].
  void restore((List<int>, Set<String>) snap) {
    final a = ZipDecoder().decodeBytes(snap.$1);
    arc.files.clear();
    arc.files.addAll(a.files);
    _docs.clear();
    drop.clear();
    _dirty
      ..clear()
      ..addAll(snap.$2);
  }

  /// Relationship targets of a part, resolved against the part's folder: rId -> full path inside the zip.
  Map<String, String> rels(String part) {
    final dir = p.posix.dirname(part);
    final d = xml('$dir/_rels/${p.posix.basename(part)}.rels');
    final m = <String, String>{};
    if (d == null) return m;
    for (final r in d.findAllElements('Relationship', namespace: '*')) {
      final id = r.getAttribute('Id'), t = r.getAttribute('Target');
      if (id == null || t == null) continue;
      m[id] = t.startsWith('/') ? t.substring(1) : p.posix.normalize(p.posix.join(dir, t));
    }
    return m;
  }

  List<int> _encode() {
    final out = Archive();
    for (final f in arc.files) {
      if (!f.isFile || drop.contains(f.name)) continue;
      final doc = _docs[f.name];
      final data = (doc != null && _dirty.contains(f.name)) ? utf8.encode(doc.toXmlString()) : (f.content as List<int>);
      final af = ArchiveFile(f.name, data.length, data);
      if (f.name == 'mimetype') af.compress = false; // ODF requirement
      out.addFile(af);
    }
    return ZipEncoder().encode(out)!;
  }

  /// Writes a new file next to the original: "<name> (edited).<ext>".
  Future<String> saveCopy() async {
    final target = FileOps.unique(p.dirname(path), '${p.basenameWithoutExtension(path)} (edited)${p.extension(path)}');
    await Saf.writeBytes(target, _encode());
    return target;
  }

  /// Overwrites the original file with the edited one.
  Future<void> saveInPlace() async {
    await Saf.writeBytes(path, _encode());
    _dirty.clear();
  }
}

// ---------------------------------------------------------------- XLSX
int colIndex(String letters) {
  var n = 0;
  for (final c in letters.toUpperCase().codeUnits) {
    n = n * 26 + (c - 64);
  }
  return n - 1;
}

String colName(int i) {
  var s = '';
  var n = i + 1;
  while (n > 0) {
    final r = (n - 1) % 26;
    s = String.fromCharCode(65 + r) + s;
    n = (n - 1) ~/ 26;
  }
  return s;
}

class XSheet {
  final String name, part;
  final XmlDocument doc;
  final Map<String, String> cells = {};
  final Map<String, String> formulas = {}; // ref -> formula (without '=')
  final Map<String, ({bool bold, int? fill})> styles = {};
  int rows = 0, cols = 0;
  XSheet(this.name, this.part, this.doc);
}

class XlsxFile {
  final OfficeZip z;
  final sheets = <XSheet>[];
  final shared = <String>[];
  final _xfStyle = <({bool bold, int? fill})>[];
  XlsxFile._(this.z);

  void _loadStyles() {
    final st = z.xml('xl/styles.xml');
    if (st == null) return;
    final fonts = [for (final f in st.findAllElements('font', namespace: '*')) f.findElements('b', namespace: '*').isNotEmpty && f.findElements('b', namespace: '*').first.getAttribute('val') != '0'];
    final fills = <int?>[];
    for (final f in st.findAllElements('fill', namespace: '*')) {
      int? rgb;
      final pf = f.findElements('patternFill', namespace: '*');
      if (pf.isNotEmpty && pf.first.getAttribute('patternType') == 'solid') {
        final fg = pf.first.findElements('fgColor', namespace: '*');
        final v = fg.isEmpty ? null : fg.first.getAttribute('rgb');
        if (v != null && v.length >= 6) rgb = int.tryParse(v.substring(v.length - 6), radix: 16);
      }
      fills.add(rgb);
    }
    final xfs = st.findAllElements('cellXfs', namespace: '*');
    if (xfs.isEmpty) return;
    for (final xf in xfs.first.findElements('xf', namespace: '*')) {
      final fi = int.tryParse(xf.getAttribute('fontId') ?? '0') ?? 0, fl = int.tryParse(xf.getAttribute('fillId') ?? '0') ?? 0;
      _xfStyle.add((bold: fi < fonts.length && fonts[fi], fill: fl < fills.length ? fills[fl] : null));
    }
  }

  static Future<XlsxFile> open(String path) async {
    final x = XlsxFile._(await OfficeZip.open(path));
    final ss = x.z.xml('xl/sharedStrings.xml');
    if (ss != null) {
      for (final si in ss.findAllElements('si', namespace: '*')) {
        x.shared.add(si.findAllElements('t', namespace: '*').map((e) => e.innerText).join());
      }
    }
    x._loadStyles();
    final wb = x.z.xml('xl/workbook.xml');
    if (wb == null) throw 'Not a valid xlsx';
    final rels = x.z.rels('xl/workbook.xml');
    for (final s in wb.findAllElements('sheet', namespace: '*')) {
      String? rid;
      for (final a in s.attributes) {
        if (a.name.local == 'id') rid = a.value;
      }
      final part = rels[rid];
      final doc = part == null ? null : x.z.xml(part);
      if (doc == null) continue;
      final sh = XSheet(s.getAttribute('name') ?? 'Sheet', part!, doc);
      for (final c in doc.findAllElements('c', namespace: '*')) {
        final ref = c.getAttribute('r');
        if (ref == null) continue;
        final m = RegExp(r'^([A-Za-z]+)(\d+)$').firstMatch(ref);
        if (m == null) continue;
        final fe = c.findElements('f', namespace: '*');
        if (fe.isNotEmpty && fe.first.innerText.isNotEmpty) sh.formulas[ref.toUpperCase()] = fe.first.innerText;
        final sIdx = int.tryParse(c.getAttribute('s') ?? '');
        if (sIdx != null && sIdx > 0 && sIdx < x._xfStyle.length) {
          final st = x._xfStyle[sIdx];
          if (st.bold || st.fill != null) sh.styles[ref.toUpperCase()] = st;
        }
        final v = x._value(c);
        if (v.isEmpty) continue;
        sh.cells[ref.toUpperCase()] = v;
        sh.cols = sh.cols > colIndex(m[1]!) + 1 ? sh.cols : colIndex(m[1]!) + 1;
        final r = int.parse(m[2]!);
        if (r > sh.rows) sh.rows = r;
      }
      x.sheets.add(sh);
    }
    return x;
  }

  String _value(XmlElement c) {
    final t = c.getAttribute('t');
    if (t == 'inlineStr') return c.findAllElements('t', namespace: '*').map((e) => e.innerText).join();
    final v = c.findElements('v', namespace: '*').map((e) => e.innerText).join();
    if (t == 's') {
      final k = int.tryParse(v);
      return k != null && k >= 0 && k < shared.length ? shared[k] : '';
    }
    if (t == 'b') return v == '1' ? 'TRUE' : 'FALSE';
    return v;
  }

  XmlElement _cellEl(XSheet sh, String ref) {
    final m = RegExp(r'^([A-Za-z]+)(\d+)$').firstMatch(ref)!;
    final rowNo = int.parse(m[2]!), ci = colIndex(m[1]!);
    final data = sh.doc.findAllElements('sheetData', namespace: '*').first;
    XmlElement? row;
    for (final r in data.findElements('row', namespace: '*')) {
      if (int.tryParse(r.getAttribute('r') ?? '') == rowNo) row = r;
    }
    if (row == null) {
      row = XmlElement(XmlName('row'), [XmlAttribute(XmlName('r'), '$rowNo')]);
      final rows = data.findElements('row', namespace: '*').toList();
      final after = rows.where((r) => (int.tryParse(r.getAttribute('r') ?? '') ?? 0) > rowNo).toList();
      if (after.isEmpty) {
        data.children.add(row);
      } else {
        data.children.insert(data.children.indexOf(after.first), row);
      }
    }
    XmlElement? cell;
    for (final c in row.findElements('c', namespace: '*')) {
      if ((c.getAttribute('r') ?? '').toUpperCase() == ref) cell = c;
    }
    if (cell == null) {
      cell = XmlElement(XmlName('c'), [XmlAttribute(XmlName('r'), ref)]);
      final after = row.findElements('c', namespace: '*').where((c) {
        final mm = RegExp(r'^([A-Za-z]+)').firstMatch(c.getAttribute('r') ?? '');
        return mm != null && colIndex(mm[1]!) > ci;
      }).toList();
      if (after.isEmpty) {
        row.children.add(cell);
      } else {
        row.children.insert(row.children.indexOf(after.first), cell);
      }
    }
    return cell;
  }

  /// Sets a cell (number, text or "=formula"; empty clears it) in the sheet XML and in the display map.
  void setCell(XSheet sh, String ref, String text) {
    ref = ref.toUpperCase();
    final m = RegExp(r'^([A-Za-z]+)(\d+)$').firstMatch(ref)!;
    final rowNo = int.parse(m[2]!);
    final cell = _cellEl(sh, ref);
    cell.children.clear();
    cell.attributes.removeWhere((a) => a.name.local == 't');
    sh.formulas.remove(ref);
    if (text.startsWith('=') && text.length > 1) {
      final fml = text.substring(1);
      cell.children.add(XmlElement(XmlName('f'), [], [XmlText(fml)]));
      sh.formulas[ref] = fml;
      sh.cells[ref] = text;
    } else if (text.isNotEmpty) {
      if (double.tryParse(text) != null) {
        cell.children.add(XmlElement(XmlName('v'), [], [XmlText(text)]));
      } else {
        cell.attributes.add(XmlAttribute(XmlName('t'), 'inlineStr'));
        cell.children.add(XmlElement(XmlName('is'), [], [
          XmlElement(XmlName('t'), [XmlAttribute(XmlName('xml:space'), 'preserve')], [XmlText(text)])
        ]));
      }
      sh.cells[ref] = text;
    } else {
      sh.cells.remove(ref);
    }
    if (colIndex(m[1]!) + 1 > sh.cols) sh.cols = colIndex(m[1]!) + 1;
    if (rowNo > sh.rows) sh.rows = rowNo;
    z.touch(sh.part);
  }

  // ---- structure: rows / columns (formula references are NOT rewritten; Excel recalculates values on open)
  void _remap(XSheet sh, String? Function(String col, int row) f) {
    // rebuilds display maps after a shift; f returns new ref or null to drop
    Map<String, T> go<T>(Map<String, T> m) {
      final o = <String, T>{};
      m.forEach((k, v) {
        final mm = RegExp(r'^([A-Z]+)(\d+)$').firstMatch(k)!;
        final nk = f(mm[1]!, int.parse(mm[2]!));
        if (nk != null) o[nk] = v;
      });
      return o;
    }

    final c = go(sh.cells), fm = go(sh.formulas), st = go(sh.styles);
    sh.cells..clear()..addAll(c);
    sh.formulas..clear()..addAll(fm);
    sh.styles..clear()..addAll(st);
    sh.rows = 0;
    sh.cols = 0;
    for (final k in sh.cells.keys) {
      final mm = RegExp(r'^([A-Z]+)(\d+)$').firstMatch(k)!;
      sh.rows = sh.rows > int.parse(mm[2]!) ? sh.rows : int.parse(mm[2]!);
      sh.cols = sh.cols > colIndex(mm[1]!) + 1 ? sh.cols : colIndex(mm[1]!) + 1;
    }
  }

  /// Inserts an empty row before [at] (1-based) or removes row [at] when [insert] is false.
  void shiftRows(XSheet sh, int at, {required bool insert}) {
    final data = sh.doc.findAllElements('sheetData', namespace: '*').first;
    for (final r in data.findElements('row', namespace: '*').toList()) {
      final n = int.tryParse(r.getAttribute('r') ?? '') ?? 0;
      if (!insert && n == at) {
        data.children.remove(r);
        continue;
      }
      if (n >= at) {
        final nn = insert ? n + 1 : n - 1;
        r.setAttribute('r', '$nn');
        for (final c in r.findElements('c', namespace: '*')) {
          final mm = RegExp(r'^([A-Za-z]+)\d+$').firstMatch(c.getAttribute('r') ?? '');
          if (mm != null) c.setAttribute('r', '${mm[1]}$nn');
        }
      }
    }
    _remap(sh, (col, row) {
      if (!insert && row == at) return null;
      return row >= at ? '$col${insert ? row + 1 : row - 1}' : '$col$row';
    });
    z.touch(sh.part);
  }

  /// Inserts an empty column before [at] (0-based) or removes column [at].
  void shiftCols(XSheet sh, int at, {required bool insert}) {
    final data = sh.doc.findAllElements('sheetData', namespace: '*').first;
    for (final r in data.findElements('row', namespace: '*')) {
      final rowNo = r.getAttribute('r') ?? '';
      for (final c in r.findElements('c', namespace: '*').toList()) {
        final mm = RegExp(r'^([A-Za-z]+)(\d+)$').firstMatch(c.getAttribute('r') ?? '');
        if (mm == null) continue;
        final ci = colIndex(mm[1]!);
        if (!insert && ci == at) {
          r.children.remove(c);
        } else if (ci >= at) {
          c.setAttribute('r', '${colName(insert ? ci + 1 : ci - 1)}$rowNo');
        }
      }
      r.removeAttribute('spans');
    }
    _remap(sh, (col, row) {
      final ci = colIndex(col);
      if (!insert && ci == at) return null;
      return ci >= at ? '${colName(insert ? ci + 1 : ci - 1)}$row' : '$col$row';
    });
    z.touch(sh.part);
  }

  /// Bold on/off and solid fill (RGB, or -1 to clear) for one cell. Creates new styles in styles.xml.
  void setStyle(XSheet sh, String ref, {bool? bold, int? fill}) {
    ref = ref.toUpperCase();
    final st = z.xml('xl/styles.xml');
    if (st == null) return;
    final root = st.rootElement;
    final xfsEl = root.findElements('cellXfs', namespace: '*').firstOrNull;
    final fontsEl = root.findElements('fonts', namespace: '*').firstOrNull;
    final fillsEl = root.findElements('fills', namespace: '*').firstOrNull;
    if (xfsEl == null || fontsEl == null || fillsEl == null) return;
    final cell = _cellEl(sh, ref);
    final cur = int.tryParse(cell.getAttribute('s') ?? '0') ?? 0;
    final xfList = xfsEl.findElements('xf', namespace: '*').toList();
    final xf = (cur < xfList.length ? xfList[cur] : xfList.first).copy();
    if (bold != null) {
      final fl = fontsEl.findElements('font', namespace: '*').toList();
      final fi = int.tryParse(xf.getAttribute('fontId') ?? '0') ?? 0;
      final nf = (fi < fl.length ? fl[fi] : fl.first).copy();
      nf.children.removeWhere((e) => e is XmlElement && e.name.local == 'b');
      if (bold) nf.children.insert(0, XmlElement(XmlName('b')));
      fontsEl.children.add(nf);
      final cnt = fontsEl.findElements('font', namespace: '*').length;
      fontsEl.setAttribute('count', '$cnt');
      xf.setAttribute('fontId', '${cnt - 1}');
      xf.setAttribute('applyFont', '1');
    }
    if (fill != null) {
      if (fill < 0) {
        xf.setAttribute('fillId', '0');
      } else {
        final hex = 'FF${fill.toRadixString(16).padLeft(6, '0').toUpperCase()}';
        fillsEl.children.add(XmlElement(XmlName('fill'), [], [
          XmlElement(XmlName('patternFill'), [XmlAttribute(XmlName('patternType'), 'solid')], [
            XmlElement(XmlName('fgColor'), [XmlAttribute(XmlName('rgb'), hex)]),
            XmlElement(XmlName('bgColor'), [XmlAttribute(XmlName('indexed'), '64')]),
          ])
        ]));
        final cnt = fillsEl.findElements('fill', namespace: '*').length;
        fillsEl.setAttribute('count', '$cnt');
        xf.setAttribute('fillId', '${cnt - 1}');
      }
      xf.setAttribute('applyFill', '1');
    }
    xfsEl.children.add(xf);
    final n = xfsEl.findElements('xf', namespace: '*').length;
    xfsEl.setAttribute('count', '$n');
    cell.setAttribute('s', '${n - 1}');
    final old = sh.styles[ref];
    sh.styles[ref] = (bold: bold ?? old?.bold ?? false, fill: fill == null ? old?.fill : (fill < 0 ? null : fill));
    z.touch('xl/styles.xml');
    z.touch(sh.part);
  }

  /// Adds an empty worksheet at the end and returns it (the workbook, its relationships and content types are updated).
  XSheet addSheet(String name, {bool rtl = false}) {
    final wb = z.xml('xl/workbook.xml')!;
    final sheetsEl = wb.findAllElements('sheets', namespace: '*').first;
    var maxId = 0;
    for (final e in sheetsEl.findElements('sheet', namespace: '*')) {
      final v = int.tryParse(e.getAttribute('sheetId') ?? '') ?? 0;
      if (v > maxId) maxId = v;
    }
    var k = sheets.length + 1;
    while (z.file('xl/worksheets/sheet$k.xml') != null) {
      k++;
    }
    final part = 'xl/worksheets/sheet$k.xml';
    z.put(part, utf8.encode('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetViews><sheetView${rtl ? ' rightToLeft="1"' : ''} workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><sheetData/></worksheet>'));
    final rl = z.xml('xl/_rels/workbook.xml.rels')!;
    var n = 1;
    final used = {for (final r in rl.findAllElements('Relationship', namespace: '*')) r.getAttribute('Id') ?? ''};
    while (used.contains('rId$n')) {
      n++;
    }
    rl.rootElement.children.add(XmlElement(XmlName('Relationship'), [
      XmlAttribute(XmlName('Id'), 'rId$n'),
      XmlAttribute(XmlName('Type'), 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet'),
      XmlAttribute(XmlName('Target'), 'worksheets/sheet$k.xml'),
    ]));
    z.touch('xl/_rels/workbook.xml.rels');
    sheetsEl.children.add(XmlElement(XmlName('sheet'), [
      XmlAttribute(XmlName('name'), name),
      XmlAttribute(XmlName('sheetId'), '${maxId + 1}'),
      XmlAttribute(XmlName.parse('r:id'), 'rId$n'),
    ]));
    z.touch('xl/workbook.xml');
    z.addOverride('/$part', 'application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml');
    z.touch(part);
    final sh = XSheet(name, part, z.xml(part)!);
    sheets.add(sh);
    return sh;
  }

  /// First free "Sheet N" style name.
  String freeSheetName(String base) {
    var i = sheets.length + 1;
    while (sheets.any((s) => s.name == '$base$i')) {
      i++;
    }
    return '$base$i';
  }

  void _prepareSave() {
    // formulas must be recalculated and the calc chain (now stale) is dropped; Excel rebuilds it
    final wb = z.xml('xl/workbook.xml')!;
    final calc = wb.findAllElements('calcPr', namespace: '*').toList();
    if (calc.isNotEmpty) {
      calc.first.setAttribute('fullCalcOnLoad', '1');
    } else {
      wb.rootElement.children.add(XmlElement(XmlName('calcPr'), [XmlAttribute(XmlName('fullCalcOnLoad'), '1')]));
    }
    z.touch('xl/workbook.xml');
    if (z.file('xl/calcChain.xml') != null) {
      z.drop.add('xl/calcChain.xml');
      final ct = z.xml('[Content_Types].xml');
      ct?.findAllElements('Override', namespace: '*').where((e) => e.getAttribute('PartName') == '/xl/calcChain.xml').toList().forEach((e) => e.parent!.children.remove(e));
      z.touch('[Content_Types].xml');
      final rl = z.xml('xl/_rels/workbook.xml.rels');
      rl?.findAllElements('Relationship', namespace: '*').where((e) => (e.getAttribute('Target') ?? '').endsWith('calcChain.xml')).toList().forEach((e) => e.parent!.children.remove(e));
      z.touch('xl/_rels/workbook.xml.rels');
    }
  }

  Future<String> saveCopy() async {
    _prepareSave();
    return z.saveCopy();
  }

  /// Overwrites the opened file.
  Future<void> saveInPlace() async {
    _prepareSave();
    await z.saveInPlace();
  }
}

// ---------------------------------------------------------------- shared paragraph helpers
String paraText(XmlElement p) {
  final b = StringBuffer();
  void walk(XmlNode n) {
    if (n is XmlText) {
      b.write(n.value);
    } else if (n is XmlElement) {
      final l = n.name.local;
      if (l == 's') {
        b.write(' ' * (int.tryParse(n.getAttribute('c') ?? '1') ?? 1));
      } else if (l == 'tab') {
        b.write('\t');
      } else if (l == 'line-break' || l == 'br') {
        b.write('\n');
      } else {
        n.children.forEach(walk);
      }
    }
  }
  p.children.forEach(walk);
  return b.toString();
}

// ---------------------------------------------------------------- ODT
class OBlock {
  final XmlElement? para; // paragraph / heading
  final List<List<List<XmlElement>>>? table; // rows -> cells -> paragraphs
  final Uint8List? image;
  OBlock({this.para, this.table, this.image});
}

class OdtFile {
  final OfficeZip z;
  final paras = <XmlElement>[];
  final blocks = <OBlock>[];
  OdtFile._(this.z);

  static bool _isPara(XmlElement e) => e.name.prefix == 'text' && (e.name.local == 'p' || e.name.local == 'h');

  Uint8List? _img(XmlElement e) {
    for (final im in e.findAllElements('image', namespace: '*')) {
      final h = im.getAttribute('xlink:href');
      if (h == null || h.startsWith('http')) continue;
      final b = z.bytes(h.startsWith('./') ? h.substring(2) : h);
      if (b != null) return b;
    }
    return null;
  }

  List<XmlElement> _paraIn(XmlElement root) => [
        for (final e in root.findAllElements('*', namespace: '*'))
          if (_isPara(e) && !e.ancestors.whereType<XmlElement>().takeWhile((a) => a != root).any(_isPara)) e
      ];

  void _walk(XmlElement parent) {
    for (final e in parent.children.whereType<XmlElement>()) {
      final l = e.name.local, pf = e.name.prefix;
      if (_isPara(e)) {
        blocks.add(OBlock(para: e));
        final im = _img(e);
        if (im != null) blocks.add(OBlock(image: im));
      } else if (pf == 'table' && l == 'table') {
        final rows = <List<List<XmlElement>>>[];
        for (final r in e.findAllElements('table-row', namespace: '*')) {
          rows.add([for (final c in r.children.whereType<XmlElement>().where((c) => c.name.local == 'table-cell' || c.name.local == 'covered-table-cell')) _paraIn(c)]);
        }
        blocks.add(OBlock(table: rows));
      } else if (pf == 'draw' && (l == 'frame' || l == 'image')) {
        final im = _img(e);
        if (im != null) blocks.add(OBlock(image: im));
      } else if (l == 'list' || l == 'list-item' || l == 'list-header' || l == 'section') {
        _walk(e);
      }
    }
  }

  static Future<OdtFile> open(String path) async {
    final x = OdtFile._(await OfficeZip.open(path));
    final d = x.z.xml('content.xml');
    if (d == null) throw 'Not a valid odt';
    for (final e in d.findAllElements('*', namespace: '*')) {
      if (e.name.prefix == 'text' && (e.name.local == 'p' || e.name.local == 'h')) {
        if (!e.ancestors.whereType<XmlElement>().any((a) => a.name.prefix == 'text' && (a.name.local == 'p' || a.name.local == 'h'))) x.paras.add(e);
      }
    }
    final body = d.findAllElements('text', namespace: '*').where((e) => e.name.prefix == 'office').firstOrNull;
    if (body != null) x._walk(body);
    return x;
  }

  bool isHeading(XmlElement e) => e.name.local == 'h';

  void setText(XmlElement para, String text) {
    para.children
      ..clear()
      ..add(XmlText(text));
    z.touch('content.xml');
  }
}

// ---------------------------------------------------------------- RTF
String rtfToText(String s) {
  const skipDest = {'fonttbl', 'colortbl', 'stylesheet', 'info', 'pict', 'header', 'footer', 'headerl', 'headerr', 'footerl', 'footerr', 'fldinst', 'listtable', 'listoverridetable', 'rsidtbl', 'generator', 'themedata', 'colorschememapping', 'datastore', 'latentstyles', 'xmlnstbl', 'object', 'private'};
  const map = {'emdash': '—', 'endash': '–', 'bullet': '•', 'lquote': '‘', 'rquote': '’', 'ldblquote': '“', 'rdblquote': '”', 'tab': '\t', 'par': '\n', 'line': '\n', 'sect': '\n', 'page': '\n', 'cell': '\t', 'row': '\n'};
  final out = StringBuffer();
  final stack = <bool>[];
  var skip = false;
  var uc = 1, pend = 0;
  var i = 0;
  bool isL(int c) => (c >= 65 && c <= 90) || (c >= 97 && c <= 122);
  void emit(String t) {
    if (skip) return;
    if (pend > 0) { pend--; return; }
    out.write(t);
  }
  while (i < s.length) {
    final c = s[i];
    if (c == '{') {
      stack.add(skip);
      i++;
    } else if (c == '}') {
      if (stack.isNotEmpty) skip = stack.removeLast();
      i++;
    } else if (c == '\\') {
      if (i + 1 >= s.length) break;
      final n = s[i + 1];
      if (n == '\\' || n == '{' || n == '}') {
        emit(n);
        i += 2;
      } else if (n == "'") {
        final h = i + 3 <= s.length ? int.tryParse(s.substring(i + 2, i + 4), radix: 16) : null;
        if (h != null) emit(String.fromCharCode(h));
        i += 4;
      } else if (n == '*') {
        skip = true;
        i += 2;
      } else if (n == '~') {
        emit('\u00A0');
        i += 2;
      } else if (n == '-' || n == '_') {
        emit(n == '_' ? '-' : '');
        i += 2;
      } else if (isL(n.codeUnitAt(0))) {
        var j = i + 1;
        while (j < s.length && isL(s.codeUnitAt(j))) {
          j++;
        }
        final w = s.substring(i + 1, j);
        var k = j;
        if (k < s.length && (s[k] == '-' || (s.codeUnitAt(k) >= 48 && s.codeUnitAt(k) <= 57))) {
          k++;
          while (k < s.length && s.codeUnitAt(k) >= 48 && s.codeUnitAt(k) <= 57) {
            k++;
          }
        }
        final param = k > j ? int.tryParse(s.substring(j, k)) : null;
        if (k < s.length && s[k] == ' ') k++;
        if (w == 'u' && param != null) {
          emit(String.fromCharCode(param < 0 ? param + 65536 : param));
          if (!skip) pend = uc;
        } else if (w == 'uc' && param != null) {
          uc = param;
        } else if (skipDest.contains(w)) {
          skip = true;
        } else if (map.containsKey(w)) {
          emit(map[w]!);
        }
        i = k;
      } else {
        i += 2;
      }
    } else if (c == '\n' || c == '\r') {
      i++;
    } else {
      emit(c);
      i++;
    }
  }
  return out.toString();
}

String textToRtf(String t) {
  final b = StringBuffer(r'{\rtf1\ansi\ansicpg1252\deff0{\fonttbl{\f0\fnil Arial;}}\f0\fs24 ');
  for (final u in t.codeUnits) {
    if (u == 10) {
      b.write('\\par\n');
    } else if (u == 13) {
      continue;
    } else if (u == 9) {
      b.write('\\tab ');
    } else if (u == 92 || u == 123 || u == 125) {
      b.write('\\${String.fromCharCode(u)}');
    } else if (u < 128) {
      b.writeCharCode(u);
    } else {
      b.write('\\u${u > 32767 ? u - 65536 : u}?');
    }
  }
  b.write('}');
  return b.toString();
}
