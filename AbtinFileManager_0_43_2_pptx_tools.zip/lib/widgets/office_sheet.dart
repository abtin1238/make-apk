import 'package:flutter/material.dart' hide Icon;
import 'app_icon.dart';
import '../core/office_prefs.dart';
import '../services/office_service.dart' show colName;
import 'office_chrome.dart';

/// Spreadsheet chrome shared by .xlsx / .xls / .ods: formula bar, grid and sheet tabs.
/// Like the design, the grid is right-to-left: column A is the right-most one and the row numbers sit on the right.

/// Cell-address box ("A1 ▾") + "fx" box with the cell content. [onSubmit] == null makes the field read-only.
class OfficeFormulaBar extends StatelessWidget {
  final String refName, value;
  final VoidCallback? onGoto;
  final ValueChanged<String>? onSubmit;
  const OfficeFormulaBar({super.key, required this.refName, required this.value, this.onGoto, this.onSubmit});

  @override
  Widget build(BuildContext context) {
    final border = Color.lerp(OfficePrefs.line, OfficePrefs.ink, .25)!;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
        decoration: BoxDecoration(color: OfficePrefs.cell, border: Border(bottom: BorderSide(color: OfficePrefs.line))),
        child: Row(children: [
          InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: onGoto,
            child: Container(
              width: 84,
              height: 44,
              padding: const EdgeInsets.only(left: 12, right: 4),
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), border: Border.all(color: border)),
              child: Row(children: [
                Expanded(child: Text(refName, style: TextStyle(fontSize: 17, color: OfficePrefs.ink))),
                Icon(Icons.arrow_drop_down_rounded, color: OfficePrefs.ink),
              ]),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Container(
              height: 44,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(8), border: Border.all(color: border)),
              child: Row(children: [
                Container(
                  width: 52,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: OfficePrefs.head, borderRadius: const BorderRadius.horizontal(left: Radius.circular(7)), border: Border(right: BorderSide(color: border))),
                  child: officeFx(OfficePrefs.ink, size: 24),
                ),
                Expanded(
                  child: TextFormField(
                    key: ValueKey('$refName:$value'),
                    initialValue: value,
                    readOnly: onSubmit == null,
                    maxLines: 1,
                    textInputAction: TextInputAction.done,
                    style: TextStyle(fontSize: 16, color: OfficePrefs.ink),
                    decoration: const InputDecoration(isDense: true, filled: false, border: InputBorder.none, contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12)),
                    onFieldSubmitted: onSubmit,
                  ),
                ),
              ]),
            ),
          ),
        ]),
      ),
    );
  }
}

/// The grid. Rows are 1-based in callbacks, columns 0-based.
class OfficeGrid extends StatelessWidget {
  final int rows, cols;
  final String selected; // e.g. "A1"
  final String Function(int c, int r) text;
  final Color? Function(int c, int r) fill;
  final bool Function(int c, int r) bold;
  final void Function(int c, int r) onTap;
  final void Function(int c, int r)? onDouble, onLong;
  const OfficeGrid({
    super.key,
    required this.rows,
    required this.cols,
    required this.selected,
    required this.text,
    required this.fill,
    required this.bold,
    required this.onTap,
    this.onDouble,
    this.onLong,
  });

  static const double rh = 34, hh = 32, hw = 34;

  (int, int) get _sel {
    final m = RegExp(r'^([A-Z]+)(\d+)$').firstMatch(selected);
    if (m == null) return (0, 1);
    var n = 0;
    for (final u in m[1]!.codeUnits) {
      n = n * 26 + (u - 64);
    }
    return (n - 1, int.parse(m[2]!));
  }

  @override
  Widget build(BuildContext context) {
    final (selC, selR) = _sel;
    final line = OfficePrefs.line, head = OfficePrefs.head, green = OfficePrefs.green, ink = OfficePrefs.ink;
    final hot = OfficePrefs.greenTint;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: LayoutBuilder(builder: (context, cons) {
        final fit = (cons.maxWidth - hw) / 4;
        final cw = fit < 76 ? 76.0 : fit;
        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SizedBox(
            width: hw + cols * cw,
            height: cons.maxHeight,
            child: Column(children: [
              SizedBox(
                height: hh,
                child: Row(children: [
                  Container(width: hw, height: hh, decoration: BoxDecoration(color: head, border: Border.all(color: line, width: .5))),
                  for (var c = 0; c < cols; c++)
                    Container(
                      width: cw,
                      height: hh,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(color: c == selC ? hot : head, border: Border.all(color: line, width: .5)),
                      child: Text(colName(c), style: TextStyle(fontSize: 15, color: c == selC ? green : ink, fontWeight: c == selC ? FontWeight.w800 : FontWeight.w500)),
                    ),
                ]),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: rows,
                  itemExtent: rh,
                  itemBuilder: (_, i) {
                    final r = i + 1;
                    return Row(children: [
                      Container(
                        width: hw,
                        height: rh,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(color: r == selR ? hot : head, border: Border.all(color: line, width: .5)),
                        child: Text('$r', style: TextStyle(fontSize: 14, color: r == selR ? green : ink, fontWeight: r == selR ? FontWeight.w800 : FontWeight.w500)),
                      ),
                      for (var c = 0; c < cols; c++) _cell(c, r, cw, line, green),
                    ]);
                  },
                ),
              ),
            ]),
          ),
        );
      }),
    );
  }

  Widget _cell(int c, int r, double cw, Color line, Color green) {
    final sel = selected == '${colName(c)}$r';
    final fl = fill(c, r);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => onTap(c, r),
      onDoubleTap: onDouble == null ? null : () => onDouble!(c, r),
      onLongPress: onLong == null ? null : () => onLong!(c, r),
      child: Container(
        width: cw,
        height: rh,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        alignment: Alignment.center,
        decoration: BoxDecoration(color: fl ?? OfficePrefs.cell, border: Border.all(color: sel ? green : line, width: sel ? 2.2 : .5)),
        child: Stack(clipBehavior: Clip.none, alignment: Alignment.center, children: [
          Text(text(c, r), maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: TextStyle(fontSize: 15, fontWeight: bold(c, r) ? FontWeight.w700 : FontWeight.w400, color: fl != null ? Colors.black87 : OfficePrefs.cellInk)),
          if (sel) Positioned(left: -7, bottom: -9, child: Container(width: 10, height: 10, color: green)),
        ]),
      ),
    );
  }
}

/// Bottom tab strip of the sheet: list button, tabs, "+" button (always laid out left-to-right like the design).
class OfficeSheetTabs extends StatelessWidget {
  final List<String> names;
  final int current;
  final ValueChanged<int> onSelect;
  final VoidCallback onList;
  final VoidCallback? onAdd;
  final ValueChanged<int>? onLong;
  const OfficeSheetTabs({super.key, required this.names, required this.current, required this.onSelect, required this.onList, this.onAdd, this.onLong});

  @override
  Widget build(BuildContext context) {
    final green = OfficePrefs.green, ink = OfficePrefs.ink;
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
        height: 50,
        decoration: BoxDecoration(color: OfficePrefs.head, border: Border(top: BorderSide(color: OfficePrefs.line))),
        child: Row(children: [
          IconButton(icon: Icon(Icons.menu_rounded, color: ink), onPressed: onList),
          Flexible(
            child: ListView(scrollDirection: Axis.horizontal, shrinkWrap: true, children: [
              for (var i = 0; i < names.length; i++)
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => onSelect(i),
                  onLongPress: onLong == null ? null : () => onLong!(i),
                  child: Container(
                    alignment: Alignment.center,
                    padding: const EdgeInsets.symmetric(horizontal: 22),
                    decoration: BoxDecoration(
                      color: i == current ? OfficePrefs.cell : null,
                      border: Border(bottom: BorderSide(color: i == current ? green : Colors.transparent, width: 3)),
                    ),
                    child: Text(names[i], style: TextStyle(fontSize: 17, fontWeight: i == current ? FontWeight.w800 : FontWeight.w500, color: i == current ? green : ink)),
                  ),
                ),
            ]),
          ),
          IconButton(icon: Icon(Icons.add_rounded, color: onAdd == null ? ink.withOpacity(.3) : ink, size: 30), onPressed: onAdd),
        ]),
      ),
    );
  }
}

/// Bottom sheet that lists the sheets of a workbook; returns the chosen index.
Future<void> officeSheetList(BuildContext context, List<String> names, int current, ValueChanged<int> onPick) {
  return showModalBottomSheet<void>(
    context: context,
    showDragHandle: true,
    builder: (c) => Theme(
      data: officeTheme(context),
      child: SafeArea(
        child: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            for (var i = 0; i < names.length; i++)
              ListTile(
                leading: Icon(Icons.grid_on_rounded, color: i == current ? OfficePrefs.green : null),
                title: Text(names[i], style: TextStyle(fontWeight: i == current ? FontWeight.w800 : FontWeight.w400, color: i == current ? OfficePrefs.green : null)),
                onTap: () {
                  Navigator.pop(c);
                  onPick(i);
                },
              ),
            const SizedBox(height: 8),
          ]),
        ),
      ),
    ),
  );
}
