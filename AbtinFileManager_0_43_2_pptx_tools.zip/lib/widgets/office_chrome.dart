import 'package:flutter/material.dart' hide Icon;
import 'package:flutter/services.dart';
import 'app_icon.dart';
import '../core/l10n.dart';
import '../core/office_prefs.dart';

/// Shared look of the Office screens (Word / Excel / PowerPoint): navy title bar, light tool strip,
/// light paper background and a labelled bottom bar.
Color get kOfficeNavy => OfficePrefs.navy;
Color get kOfficeNavyDeep => OfficePrefs.navyDeep;
Color get kOfficeBlue => OfficePrefs.blue;
Color get kOfficeGreen => OfficePrefs.green;
Color get kOfficeBg => OfficePrefs.bg;
Color get kOfficeStrip => OfficePrefs.strip;
Color get kOfficeInk => OfficePrefs.ink;

/// Office pages follow their own light / dark mode (Settings -> Office appearance), independent of the app theme.
ThemeData officeTheme(BuildContext c) {
  OfficePrefs.resolve(MediaQuery.platformBrightnessOf(c));
  final br = OfficePrefs.dark ? Brightness.dark : Brightness.light;
  final ff = Theme.of(c).textTheme.bodyMedium?.fontFamily;
  return ThemeData(
    useMaterial3: true,
    brightness: br,
    fontFamily: ff,
    colorScheme: ColorScheme.fromSeed(seedColor: kOfficeBlue, brightness: br, surface: OfficePrefs.dark ? OfficePrefs.strip : null),
    scaffoldBackgroundColor: kOfficeBg,
    dividerColor: OfficePrefs.line,
  );
}

bool _hasArabic(String s) => RegExp(r'[؀-ۿ]').hasMatch(s);

/// Persian digits when the UI language is Persian.
String faDigits(Object v) {
  final s = '$v';
  if (L.lang != 'fa') return s;
  const d = '۰۱۲۳۴۵۶۷۸۹';
  return s.replaceAllMapped(RegExp(r'\d'), (m) => d[int.parse(m[0]!)]);
}

/// Navy title bar: back arrow, file name, actions. Always laid out left-to-right like the design.
class OfficeTopBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final List<Widget> actions;
  final VoidCallback? onBack;
  const OfficeTopBar({super.key, required this.title, this.actions = const [], this.onBack});

  @override
  Size get preferredSize => const Size.fromHeight(56);

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Directionality(
      textDirection: TextDirection.ltr,
      child: Container(
        color: kOfficeNavy,
        padding: EdgeInsets.only(top: top),
        height: 56 + top,
        child: Row(children: [
          IconButton(
            iconSize: 28,
            color: Colors.white,
            icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
            onPressed: onBack ?? () => Navigator.maybePop(context),
          ),
          Expanded(
            child: Text(
              title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
              textDirection: _hasArabic(title) ? TextDirection.rtl : TextDirection.ltr,
              style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600),
            ),
          ),
          IconTheme(data: const IconThemeData(color: Colors.white, size: 26), child: Row(mainAxisSize: MainAxisSize.min, children: actions)),
          const SizedBox(width: 4),
        ]),
      ),
    ));
  }
}

/// A white icon button for [OfficeTopBar].
Widget officeAction(IconData icon, VoidCallback? onTap, {String? tip, Color? color}) => IconButton(
      tooltip: tip,
      iconSize: 26,
      icon: Icon(icon, color: onTap == null ? Colors.white38 : (color ?? Colors.white)),
      onPressed: onTap,
    );

class OfficeBarItem {
  final IconData icon;
  final String label;
  final VoidCallback? onTap;

  /// Optional custom glyph (e.g. the italic "fx"); receives the colour to draw with.
  final Widget Function(Color color)? glyph;
  const OfficeBarItem(this.icon, this.label, this.onTap, {this.glyph});
}

/// Italic serif "fx" glyph used by the Excel formula bar and bottom bar.
Widget officeFx(Color c, {double size = 26}) => Text('fx', style: TextStyle(fontSize: size, fontStyle: FontStyle.italic, fontFamily: 'serif', color: c, height: 1));

/// "A" with a small drop-down arrow (cell format button of the Excel bottom bar).
Widget officeFormatGlyph(Color c) => Row(mainAxisSize: MainAxisSize.min, children: [
      Text('A', style: TextStyle(fontSize: 26, color: c, height: 1, decoration: TextDecoration.underline, decorationThickness: 2)),
      Icon(Icons.arrow_drop_down_rounded, size: 22, color: c),
    ]);

/// Bottom bar with icon + label items. [items] are given in right-to-left reading order (first = rightmost).
class OfficeBottomBar extends StatelessWidget {
  final List<OfficeBarItem> items;
  final bool dark;
  const OfficeBottomBar({super.key, required this.items, this.dark = false});

  @override
  Widget build(BuildContext context) {
    final fg = dark ? Colors.white : kOfficeInk;
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Material(
        color: dark ? kOfficeNavyDeep : kOfficeStrip,
        borderRadius: dark ? null : const BorderRadius.vertical(top: Radius.circular(22)),
        elevation: dark ? 0 : 6,
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 60,
            child: Row(children: [
              for (final it in items)
                Expanded(
                  child: InkWell(
                    onTap: it.onTap,
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      SizedBox(height: 28, child: Center(child: it.glyph != null ? it.glyph!(it.onTap == null ? fg.withOpacity(.35) : fg) : Icon(it.icon, size: 26, color: it.onTap == null ? fg.withOpacity(.35) : fg))),
                      const SizedBox(height: 3),
                      Text(it.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.5, color: it.onTap == null ? fg.withOpacity(.35) : fg.withOpacity(dark ? .92 : .75))),
                    ]),
                  ),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Square-ish toggle used in the Word tool strip (selected = tinted rounded square).
class OfficeToolButton extends StatelessWidget {
  final Widget child;
  final bool selected;
  final VoidCallback? onTap;
  final String? tip;
  final double width;
  const OfficeToolButton({super.key, required this.child, this.selected = false, this.onTap, this.tip, this.width = 48});

  @override
  Widget build(BuildContext context) {
    final w = Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 6),
      child: Material(
        color: selected ? OfficePrefs.blueTint : Colors.transparent,
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: SizedBox(width: width, height: 36, child: Center(child: child)),
        ),
      ),
    );
    return tip == null ? w : Tooltip(message: tip!, child: w);
  }
}

/// Plain white "paper" page on the workspace background (used by the Word-like screens).
class OfficePaper extends StatelessWidget {
  final Widget child;
  const OfficePaper({super.key, required this.child});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(11, 11, 11, 0),
        child: Material(color: OfficePrefs.paper, elevation: 1.5, borderRadius: const BorderRadius.vertical(top: Radius.circular(6)), clipBehavior: Clip.antiAlias, child: child),
      );
}

/// Popup menu (three dots) of the title bar.
Widget officeMore<T>({required List<PopupMenuEntry<T>> Function(BuildContext) items, required void Function(T) onSelected}) => PopupMenuButton<T>(
      icon: const Icon(Icons.more_vert_rounded, color: Colors.white, size: 26),
      onSelected: onSelected,
      itemBuilder: items,
    );
