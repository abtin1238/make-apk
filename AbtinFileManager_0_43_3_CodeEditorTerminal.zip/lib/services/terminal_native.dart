import 'package:flutter/services.dart';

/// Native /system/bin/sh bridge. The shell has pipes, not a PTY/TTY.
class TerminalNative {
  static const MethodChannel _methods = MethodChannel('abtin/terminal');
  static const EventChannel _eventChannel =
      EventChannel('abtin/terminal/events');

  Stream<Map<String, dynamic>> get events => _eventChannel
      .receiveBroadcastStream()
      .map((event) => Map<String, dynamic>.from(event as Map));

  Future<TerminalSession> start(String cwd) async {
    final value = await _methods.invokeMapMethod<String, dynamic>(
      'start',
      {'cwd': cwd},
    );
    if (value == null || value['sessionId'] is! String || value['cwd'] is! String) {
      throw const PlatformException(
        code: 'TERMINAL_START',
        message: 'Native shell returned an invalid session',
      );
    }
    return TerminalSession(
      id: value['sessionId'] as String,
      cwd: value['cwd'] as String,
    );
  }

  Future<void> writeLine(String sessionId, String text) async {
    await _methods.invokeMethod<bool>(
      'writeLine',
      {'sessionId': sessionId, 'text': text},
    );
  }

  /// Writes exactly [text], without appending a line ending.
  Future<void> writeRaw(String sessionId, String text) async {
    await _methods.invokeMethod<bool>(
      'writeRaw',
      {'sessionId': sessionId, 'text': text},
    );
  }

  Future<void> close(String sessionId) async {
    await _methods.invokeMethod<bool>('close', {'sessionId': sessionId});
  }

  Future<void> closeAll() async {
    await _methods.invokeMethod<bool>('closeAll');
  }
}

class TerminalSession {
  final String id;
  final String cwd;
  const TerminalSession({required this.id, required this.cwd});
}
